package com.ey.advisory.asp.notification.dto;

import java.io.Serializable;

/**
 * This is a simple SMS class with mobile number and message is the content.
 * 
 * @author Prakash.Naik
 *
 */
public class SmsDto implements Serializable {

	/**
	 * Mobile number
	 */
	private String mobileNumber;

	/**
	 * Message
	 */
	private String message;

	/**
	 * Getter method for mobile number.
	 * 
	 * @return
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * Setter method for mobile number.
	 * 
	 * @param mobileNumber
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * Getter method for message.
	 * 
	 * @return
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Setter method for message.
	 * 
	 * @param message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
