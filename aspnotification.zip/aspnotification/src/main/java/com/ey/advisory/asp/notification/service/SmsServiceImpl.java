package com.ey.advisory.asp.notification.service;

import java.io.IOException;
import java.util.Date;

import org.jsmpp.InvalidResponseException;
import org.jsmpp.PDUException;
import org.jsmpp.bean.BindType;
import org.jsmpp.bean.DataCoding;
import org.jsmpp.bean.DataCodings;
import org.jsmpp.bean.ESMClass;
import org.jsmpp.bean.NumberingPlanIndicator;
import org.jsmpp.bean.RegisteredDelivery;
import org.jsmpp.bean.SMSCDeliveryReceipt;
import org.jsmpp.bean.TypeOfNumber;
import org.jsmpp.extra.NegativeResponseException;
import org.jsmpp.extra.ResponseTimeoutException;
import org.jsmpp.session.BindParameter;
import org.jsmpp.session.SMPPSession;
import org.jsmpp.util.AbsoluteTimeFormatter;
import org.jsmpp.util.TimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.notification.constants.NotificationConstants;
import com.ey.advisory.asp.notification.dto.SmsDto;

/**
 * This is a SMS service implementation class.
 * 
 * @author Prakash.Naik
 *
 */
@Service("smsService")
@PropertySource("classpath:NotificationConfig.properties")
public class SmsServiceImpl implements SmsService {

	private static final Logger logger = LoggerFactory.getLogger(SmsServiceImpl.class);

	private static TimeFormatter timeFormatter = new AbsoluteTimeFormatter();

	@Value("${smscHostServer}")
	private String smscHostServer;

	@Value("${smscPort}")
	private String smscPort;

	@Value("${systemId}")
	private String systemId;

	@Value("${systemPassword}")
	private String systemPassword;

	@Value("${systemType}")
	private String systemType;

	@Override
	public String generateSms(SmsDto sms) {

		if(logger.isInfoEnabled()){
		logger.info("Start of generateSms method ");
		}

		/*
		 * Response message
		 */
		String responseMessage = null;

		/*
		 * Create SMPP session object
		 */
		SMPPSession session = new SMPPSession();

		try {

			/*
			 * Connect and bind SMPP parameter.
			 */
			if(logger.isInfoEnabled()){
			logger.info("connectAndBindSmppParameter method is called");
			}
			session = connectAndBindSmppParameter(session);
			if(logger.isInfoEnabled()){
			logger.info("connectAndBindSmppParameter method is ended");
			}

			/*
			 * Set registered delivery.
			 */
			final RegisteredDelivery registeredDelivery = new RegisteredDelivery(SMSCDeliveryReceipt.DEFAULT);

			String messageId = submitMessageWithAdditionalDetails(session, registeredDelivery, sms);

			responseMessage = NotificationConstants.SMS_SUCCESS_MESSAGE;

			if(logger.isInfoEnabled()){
			logger.info("Message submitted, message_id is " + messageId);
			}

		} catch (PDUException e) {
			// Invalid PDU parameter
			logger.error("Invalid PDU parameter " + e);

			responseMessage = NotificationConstants.SMS_PDU_EXCEPTION;

			return responseMessage;

		} catch (ResponseTimeoutException e) {
			// Response timeout
			logger.error("Response timeout " + e);

			responseMessage = NotificationConstants.SMS_RESPONSE_TIME_OUT_EXCEPTION;

			return responseMessage;

		} catch (InvalidResponseException e) {
			// Invalid response
			logger.error("Receive invalid respose " + e);

			responseMessage = NotificationConstants.SMS_INVALID_RESPONSE_EXCEPTION;

			return responseMessage;

		} catch (NegativeResponseException e) {
			// Receiving negative response (non-zero command_status)
			logger.error("Receive negative response " + e);

			responseMessage = NotificationConstants.SMS_NEGATIVE_RESPONSE_EXCEPTION;

			return responseMessage;

		} catch (IOException e) {

			logger.error("Failed connect and bind to host " + e);

			responseMessage = NotificationConstants.SMS_IO_EXCEPTION;

			return responseMessage;

		} catch (Exception e) {

			logger.error("Exception occured in while sending SMS " + e);

			responseMessage = NotificationConstants.SMS_GENERAL_EXCEPTION;

			return responseMessage;

		}

		finally {
			// unbind(disconnect)
			if(logger.isInfoEnabled()){
			logger.info("Unbind the session");
			}
			session.unbindAndClose();
		}

		if(logger.isInfoEnabled()){
		logger.info("End of generateSms method ");
		}

		return responseMessage;

	}

	/**
	 * This method is to submit short message with additional parameter.
	 * 
	 * @param session
	 * @param registeredDelivery
	 * @param sms
	 * @return
	 * @throws IOException
	 * @throws NegativeResponseException
	 * @throws InvalidResponseException
	 * @throws ResponseTimeoutException
	 * @throws PDUException
	 */
	private String submitMessageWithAdditionalDetails(SMPPSession session, RegisteredDelivery registeredDelivery,
			SmsDto sms) throws PDUException, ResponseTimeoutException, InvalidResponseException,
			NegativeResponseException, IOException {

		if(logger.isInfoEnabled()){
		logger.info("Start of submitMessageWithAdditionalDetails method");
		}
		/*
		 * Set additional details.
		 */
		String serviceType = "CMT";
		TypeOfNumber typeOfNumberForSourceAddress = TypeOfNumber.NATIONAL;
		NumberingPlanIndicator numberingPlanIndicatorForSource = NumberingPlanIndicator.ISDN;
		String sourceAddress = "<MSISDN>";
		TypeOfNumber typeOfNumberForDestinationAddress = TypeOfNumber.NATIONAL;
		NumberingPlanIndicator numberingPlanIndicatorForDestination = NumberingPlanIndicator.ISDN;
		String destinationMobileNumber = sms.getMobileNumber();
		ESMClass esmForEnhancedNetwork = new ESMClass();
		byte networkProtocolId = 0;
		byte priorityFlag = 0;
		String scheduleDeliveryTime = timeFormatter.format(new Date());
		String validityPeriod = null;
		byte replaceIfPresentFlag = 0;
		DataCoding dataCoding = DataCodings.ZERO;
		byte smsDefaultMessageId = 0;
		byte[] shortMessage = sms.getMessage().getBytes();

		/*
		 * submitShortMessage method will take additional parameter and returns
		 * the message id.
		 */
		String messageId = session.submitShortMessage(serviceType, typeOfNumberForSourceAddress,
				numberingPlanIndicatorForSource, sourceAddress, typeOfNumberForDestinationAddress,
				numberingPlanIndicatorForDestination, destinationMobileNumber, esmForEnhancedNetwork, networkProtocolId,
				priorityFlag, scheduleDeliveryTime, validityPeriod, registeredDelivery, replaceIfPresentFlag,
				dataCoding, smsDefaultMessageId, shortMessage);

		if(logger.isInfoEnabled()){
		logger.info("Message is send and message id is " + messageId);
		}

		if(logger.isInfoEnabled()){
		logger.info("End of submitMessageWithAdditionalDetails method");
		}

		return messageId;

	}

	/**
	 * This method is to connect and bind SMPP parameter.
	 * 
	 * @param session
	 * @return
	 * @throws IOException
	 */
	private SMPPSession connectAndBindSmppParameter(SMPPSession session) throws IOException {

		BindType bindType = BindType.BIND_TRX;
		TypeOfNumber typeOfNumber = TypeOfNumber.UNKNOWN;
		NumberingPlanIndicator numberPlanIndicator = NumberingPlanIndicator.UNKNOWN;
		String addressRange = null;

		int smscServerPort = 0;
		if (null != smscPort) {
			smscServerPort = Integer.valueOf(smscPort.trim());
		}
		if(logger.isInfoEnabled()){
		logger.info("Trying to connect and bind the session object");
		}
		session.connectAndBind(smscHostServer, smscServerPort, new BindParameter(bindType, systemId, systemPassword,
				systemType, typeOfNumber, numberPlanIndicator, addressRange));

		if(logger.isInfoEnabled()){
		logger.info("Session object connect and bind is completed.");
		}

		return session;
	}

	/**
	 * This method is to validate SMS and Mobile number.
	 */
	@Override
	public boolean validateSmsAndMobileNumber(SmsDto sms) {

		/*
		 * Validate mobile number
		 */
		if (isValidMobileNumber(sms.getMobileNumber()) && hasIndianCode(sms.getMobileNumber())) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * This method is to check mobile number contains 91 or not.
	 */
	private boolean hasIndianCode(String mobileNumber) {
		if (null != mobileNumber
				&& mobileNumber.substring(0, 2).equals(Integer.toString(NotificationConstants.MOBILE_INDIA_CODE))) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * This method is to validate the number of digit in mobile number
	 * 
	 */
	public boolean isValidMobileNumber(String mobileNumber) {

		if (mobileNumber.matches("\\d{12}")) {
			return true;
		} else {
			return false;
		}

	}

}
