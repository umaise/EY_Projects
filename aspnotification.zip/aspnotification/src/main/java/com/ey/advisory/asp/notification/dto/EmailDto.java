package com.ey.advisory.asp.notification.dto;

import java.io.File;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * This is Email Dto class with required attributes.
 * 
 * @author Prakash.Naik
 *
 */
public class EmailDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String from;

	private List<String> to;

	private String subject;

	private String body;

	private List<String> cc;

	private List<String> bcc;

	private List<File> attachedFiles;

	private String templateName;

	private Map<String, Object> templatePlaceHolders;

	private String contentType;

	private boolean htmlContent;

	private boolean sendEmail;

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public List<String> getTo() {
		return to;
	}

	public void setTo(List<String> to) {
		this.to = to;
	}
	
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public List<String> getCc() {
		return cc;
	}

	public void setCc(List<String> cc) {
		this.cc = cc;
	}

	public List<String> getBcc() {
		return bcc;
	}

	public void setBcc(List<String> bcc) {
		this.bcc = bcc;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Map<String, Object> getTemplatePlaceHolders() {
		return templatePlaceHolders;
	}

	public void setTemplatePlaceHolders(Map<String, Object> templatePlaceHolders) {
		this.templatePlaceHolders = templatePlaceHolders;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public boolean isHtmlContent() {
		return htmlContent;
	}

	public void setHtmlContent(boolean htmlContent) {
		this.htmlContent = htmlContent;
	}

	public boolean isSendEmail() {
		return sendEmail;
	}

	public void setSendEmail(boolean sendEmail) {
		this.sendEmail = sendEmail;
	}

	public List<File> getAttachedFiles() {
		return attachedFiles;
	}

	public void setAttachedFiles(List<File> attachedFiles) {
		this.attachedFiles = attachedFiles;
	}
}
