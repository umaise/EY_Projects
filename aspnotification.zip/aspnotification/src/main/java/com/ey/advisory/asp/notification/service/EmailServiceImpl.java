package com.ey.advisory.asp.notification.service;

import java.io.File;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.ey.advisory.asp.notification.constants.NotificationConstants;
import com.ey.advisory.asp.notification.dto.EmailDto;

/**
 * This is email service implementation class.
 * 
 * @author Prakash.Naik
 *
 */

@Service("emailService")
@PropertySource("classpath:NotificationConfig.properties")
public class EmailServiceImpl implements EmailService {

	@Value("${email.host}")
	private String host;
	@Value("${email.userName}")
	private String username;
	@Value("${email.password}")
	private String password;

	@Value("${email.smtp.port}")
	private int port;
	@Value("${email.debug}")
	private boolean debug;
	@Value("${email.smtp.auth}")
	private boolean auth;
	@Value("${email.smtp.starttls.enable}")
	private boolean starttls;

	private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	private JavaMailSender javaMailSender;

	@Bean
	public JavaMailSender javaMailSender() {

		JavaMailSenderImpl javaMailSender = new JavaMailSenderImpl();

		Properties mailProperties = new Properties();
		mailProperties.put("mail.smtp.port", port);
		mailProperties.put("mail.debug", debug);
		mailProperties.put("mail.smtp.auth", auth);
		mailProperties.put("mail.smtp.starttls.enable", starttls);

		javaMailSender.setJavaMailProperties(mailProperties);

		javaMailSender.setHost(host);
		javaMailSender.setPort(port);
		javaMailSender.setUsername(username);
		javaMailSender.setPassword(password);

		return javaMailSender;
	}

	@Autowired
	private VelocityEngine velocityEngine;

	/**
	 * This method will send email without template.
	 * 
	 */
	@Override
	public String sendEmail(final EmailDto email) {

		if (logger.isInfoEnabled())
			logger.info("Started sendEmail method");

		String responseMessage = null;

		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {

				if (logger.isInfoEnabled())
					logger.info("MimeMessagePreparator prepare method is called.");

				MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);

				if (null != email) {

					// Set from email id from the NotificaitonConfig.properties
					message.setFrom(username);

					// Set to email id
					message.setTo(email.getTo().toArray(new String[email.getTo().size()]));

					// Set cc email id
					if (null != email.getCc()) {
						message.setCc(email.getCc().toArray(new String[email.getCc().size()]));
					}

					// Set bcc email id
					if (null != email.getBcc()) {
						message.setBcc(email.getBcc().toArray(new String[email.getBcc().size()]));
					}

					// Set subject email id
					message.setSubject(email.getSubject());

					// Set email body
					message = addEmailBody(email.getTemplateName(), email.getTemplatePlaceHolders(), email.getBody(),
							message);


					// Add attachments

					if (null != email.getAttachedFiles()) {
						for (File attachedFile : email.getAttachedFiles()) {
							message.addAttachment(attachedFile.getName(), attachedFile);
						}
					}
				}


				if (logger.isInfoEnabled())
					logger.info("MimeMessagePreparator prepare method is ended.");
			}

			/**
			 * This method is to form the email body.
			 * 
			 * @param templateName
			 * @param templatePlaceHolders
			 * @param body
			 * @param message
			 * @return
			 * @throws MessagingException
			 */
			private MimeMessageHelper addEmailBody(String templateName, Map<String, Object> templatePlaceHolders,
					String body, MimeMessageHelper message) throws MessagingException {

				if (logger.isInfoEnabled())
					logger.info("Start : addEmailBody method to form preparator and message object");

				if (null != templateName) {

					if (logger.isInfoEnabled())
						logger.info("Forming the email body using template " + templateName);

					/*
					 * All the email templates are placed into emailTemplates
					 * folder.
					 */
					String messageBody = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
							"/emailTemplates/" + templateName + "", templatePlaceHolders);

					message.setText(messageBody, true);

				} else {

					if (logger.isInfoEnabled())
						logger.info("Forming the email body without template");

					// Set email body without using template
					message.setText(body, true);
				}

				if (logger.isInfoEnabled())
					logger.info("End : addEmailBody method to form preparator and message object");

				return message;
			}
		};
		try {

			if (logger.isInfoEnabled())
				logger.info("JavaMailSender send method is called with preparator object");
			javaMailSender.send(preparator);

			responseMessage = NotificationConstants.EMAIL_SUCCESS_MESSAGE;

			if (logger.isInfoEnabled())
				logger.info("JavaMailSender send method is ended.");

		} catch (MailException mailException) {

			if (logger.isErrorEnabled())
				logger.error("Couldn't send email.Email exception occured. " + mailException);

			responseMessage = NotificationConstants.EMAIL_EXCEPTION;

			return responseMessage;

		} catch (Exception exception) {

			if (logger.isErrorEnabled())
				logger.error("Couldn't send email.General exception occured. " + exception);

			responseMessage = NotificationConstants.EMAIL_GENERAL_EXCEPTION;

			return responseMessage;
		}

		if (logger.isInfoEnabled())
			logger.info("Ended sendEmail method successfully");

		return responseMessage;

	}

	/**
	 * This method is to validate email addresses.
	 * 
	 */
	@Override
	public String isValiEmailAddresses(EmailDto email) {

		if (logger.isInfoEnabled())
			logger.info("Start : isValiEmailAddresses method is started");
		
		String validEmailStatus = null;

		if (null != email && null != email.getTo()) {
			for (String toEmailId : email.getTo()) {
				if (!isValidEmailAddress(toEmailId)) {
					validEmailStatus = NotificationConstants.EMAIL_TO_ADDRESS_INVALID;
					break;
				} else {
					validEmailStatus = NotificationConstants.EMAIL_VALID_ADDRESS;
				}
			}

		}

		if (logger.isInfoEnabled())
			logger.info("End : isValiEmailAddresses method is started");
		
		return validEmailStatus;
	}

	/**
	 * This method is to validate email using regular expression.
	 * 
	 * @param from
	 */
	private boolean isValidEmailAddress(String emailAddress) {

		final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		;
		Matcher matcher;

		matcher = pattern.matcher(emailAddress);

		return matcher.matches();
	}

	/**
	 * This method is to check the all attachment file size.
	 * 
	 * If the all file size > 10MB then it returns false.
	 * 
	 */
	@Override
	public boolean checkAttachedFileSizes(EmailDto email) {

		boolean validFileSizeAttached = true;

		double allFilesSizeInMB = 0.0;

		if (null != email.getAttachedFiles()) {

			for (File attachedFile : email.getAttachedFiles()) {

				if (attachedFile.exists()) {

					allFilesSizeInMB = allFilesSizeInMB + (((attachedFile.length()) / 1024.0) / 1024.0);
				}

			}
		}

		if (allFilesSizeInMB > NotificationConstants.EMAIL_ALL_ATTACHMENT_FILESIZE) {
			validFileSizeAttached = false;
		}

		return validFileSizeAttached;
	}
}
