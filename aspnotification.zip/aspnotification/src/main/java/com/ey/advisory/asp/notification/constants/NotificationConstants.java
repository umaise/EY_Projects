package com.ey.advisory.asp.notification.constants;

/**
 * This class contains notification service related constants.
 * 
 * @author Prakash.Naik
 *
 */
public class NotificationConstants {

	private NotificationConstants()
	{
		
	}
	/**
	 * Mobile number length
	 */
	public static final int MOBILE_NUMBER_LENGTH = 12;

	/**
	 * Indian mobile number code
	 */
	public static final int MOBILE_INDIA_CODE = 91;

	/**
	 * SMS success message
	 */
	public static final String SMS_SUCCESS_MESSAGE = "SMS sent successfully";

	/**
	 * SMS invalid mobile number response message
	 */
	public static final String SMS_INVALID_MOBILE_NUMBER = " : the mobile number is not valid. Kindly enter 12 digit mobile number with 91 (Code) at beginning. Ex: 918176651234.";

	/**
	 * SMS pdu exception
	 */
	public static final String SMS_PDU_EXCEPTION = "Couldn't send SMS. Error: Invalid PDU parameter. Kindly contact administration team.";

	/**
	 * SMS response time out exception
	 */
	public static final String SMS_RESPONSE_TIME_OUT_EXCEPTION = "Couldn't send SMS. Error: Response timeout. Kindly contact administration team.";

	/**
	 * SMS invalid response exception
	 */
	public static final String SMS_INVALID_RESPONSE_EXCEPTION = "Couldn't send SMS. Error: Receive invalid respose. Kindly contact administration team.";

	/**
	 * SMS negative response exception
	 */
	public static final String SMS_NEGATIVE_RESPONSE_EXCEPTION = "Couldn't send SMS. Error: Receive negative response. Kindly contact administration team.";

	/**
	 * SMS IO exception
	 */
	public static final String SMS_IO_EXCEPTION = "Couldn't send SMS. Error: Failed connect and bind to host. Kindly contact administration team.";

	/**
	 * SMS general exception
	 */
	public static final String SMS_GENERAL_EXCEPTION = "Couldn't send SMS. Kindly contact administration team.";

	/**
	 * Email exception
	 */
	public static final String EMAIL_EXCEPTION = "Couldn't send Email. Kindly contact administration team.";

	/**
	 * Email general exception
	 */
	public static final String EMAIL_GENERAL_EXCEPTION = "Couldn't send Email. Kindly contact administration team.";

	/**
	 * Email success message
	 */
	public static final String EMAIL_SUCCESS_MESSAGE = "Email sent successfully";

	/**
	 * From email from address is not valid
	 */
	public static final String EMAIL_FROM_ADDRESS_INVALID = "Email from address is invalid";

	/**
	 * To email from address is not valid
	 */
	public static final String EMAIL_TO_ADDRESS_INVALID = "Email to address is invalid";

	/**
	 * Valid email addresses
	 */
	public static final String EMAIL_VALID_ADDRESS = "EMAIL_VALID_ADDRESS";

	/**
	 * Total email attachment file size in MB
	 */
	public static final int EMAIL_ALL_ATTACHMENT_FILESIZE = 10;

	/**
	 * Attachment file size is greater than 10MB.
	 * 
	 */
	public static final String EMAIL_ATTACHMENT_GREATER_MESSAGE = "Email has attachment greater than "
			+ EMAIL_ALL_ATTACHMENT_FILESIZE + " MB. Kindly attache the files less than or equal to "+EMAIL_ALL_ATTACHMENT_FILESIZE+" MB";
}
