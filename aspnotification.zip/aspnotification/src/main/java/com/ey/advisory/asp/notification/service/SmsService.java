package com.ey.advisory.asp.notification.service;

import com.ey.advisory.asp.notification.dto.SmsDto;

public interface SmsService {


	public String generateSms(SmsDto sms);

	public boolean validateSmsAndMobileNumber(SmsDto sms);
}
