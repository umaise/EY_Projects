package com.ey.advisory.asp.notification.service;

import com.ey.advisory.asp.notification.dto.EmailDto;

public interface EmailService {

	public String sendEmail(EmailDto email);
	
	public String isValiEmailAddresses(EmailDto email);
	
	public boolean checkAttachedFileSizes(EmailDto email);
}
