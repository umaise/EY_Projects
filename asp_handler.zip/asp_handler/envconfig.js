var envconfig = {}

envconfig.env = process.env.NODE_ENV || "development";
global.__basedir = __dirname;

module.exports = envconfig;
