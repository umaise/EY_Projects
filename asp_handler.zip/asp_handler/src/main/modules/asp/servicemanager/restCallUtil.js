var http = require('http');
var request = require('request');
var appconfig = require('../config/appconfig.js');
var logger = require('../logger/logger.js')

var RestCallUtil = {
executePostCall : function (inreqJsonVO, headers, body , url, successCallback, errorCallBack ) {

  var responseString= '';
  var responseContentType = null;
  request.post({
                headers: headers,
                url:     url,
                body:    body,
                proxy : appconfig.proxy,
             })
              // .on('request', function (request) {
              //
              // })
             .on('response', function (response) {
               responseContentType = JSON.parse(JSON.stringify(response.headers))["content-type"];
             })
             .on('data', function(data) {
                 responseString += data;
             })
             .on('end', function() {
                if(responseContentType.indexOf("application/json") != -1) {
                  var responseObject = JSON.parse(responseString);
                  successCallback(responseObject, inreqJsonVO);
                } else{
                  errorCallBack("Error while getting response.", inreqJsonVO);
                }
             })

           .on('error', function (err) {
             errorCallBack(err, inreqJsonVO);
         });
},
executePostCallGSTN : function (inreqJsonVO, headers, body , url, proxy, successCallback, errorCallBack ) {

  var responseString= '';
  var responseContentType = null;
  request.post({
                proxy : proxy,
                headers: headers,
                url:     url,
                body:    body
             })
              // .on('request', function (request) {
              //
              // })
             .on('response', function (response) {
               responseContentType = JSON.parse(JSON.stringify(response.headers))["content-type"];
             })
             .on('data', function(data) {
                 responseString += data;
             })
             .on('end', function() {
                if(responseContentType.indexOf("application/json") != -1) {
                  var responseObject = JSON.parse(responseString);
                  successCallback(responseObject, inreqJsonVO);
                } else{
                  errorCallBack("Error getting response from Stubs");
                }
             })
           .on('error', function (err) {
             errorCallBack(err, inreqJsonVO);
         });
},
executePostCallAsp : function(message, headers, body , url, successCallback, errorCallBack){

      request.post({
                    headers: headers,
                    url:     url,
                    body:    body
                },function(error, data){
                  if(null != error){
                    logger.error("Error calling ASPAPP for Save. "+error);
                  }else{
                     var value = JSON.parse(message.value);
                     var chunkId = value[0].chunkId;
                     logger.info("Successfully called ASPAPP for Save-->"+ chunkId);
                  }
                });
}
};
module.exports = RestCallUtil;
