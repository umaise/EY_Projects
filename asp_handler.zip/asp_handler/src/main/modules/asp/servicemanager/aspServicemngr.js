
var http = require('http');
var logger = require('../logger/logger.js');
var KafkaLogger = require('../msghandler/aspProducer.js');
var redisUtils = require('../redisdbhandlr/redisUtil.js');
var appconfig = require('../config/appconfig.js');
var async = require('async');


var RefTknServiceMngr = {
  handleRequest: function(reqJsonVO,successCallbk,errorCallbk){

   var checkJson = RefTknServiceMngr.checkAction(reqJsonVO.ORIGINALURL);
   var newInvOrder= null;
   var invOrder= null;

    if(checkJson.ADDTOREDIS){
        logger.debug("Saving to Redis");
        var key = reqJsonVO.PAYLOAD.uk;
	  	  var value = reqJsonVO.PAYLOAD.invoiceCount;
        var groupCode= reqJsonVO.PAYLOAD.groupCode;

        if(typeof groupCode != 'undefined' && groupCode != null ){
            redisUtils.saveToRedis(key + "_GroupCode", groupCode,function(){
                logger.debug("Successfully saved groupcode to Redis.");
            },function(error){
              logger.error(error);
            });
          }

      redisUtils.saveToRedis(key + "_InvCount", value,successCallbk,errorCallbk);
    }else if(checkJson.ADDTOKAFKA){
      //If the payload is coming as an array
      if(Array.isArray(reqJsonVO.PAYLOAD)){
        logger.debug("Payload is an array");
          if(null != reqJsonVO.PAYLOAD && undefined != reqJsonVO.PAYLOAD){
                async.forEach(reqJsonVO.PAYLOAD,function(invoiceJson, callback){
                            appconfig.gstrList.forEach(function(element) {
                              if(Object.keys(invoiceJson).includes(element)){
                                if(null!= invoiceJson[element][0] && undefined != invoiceJson[element][0]){
                                  newInvOrder = invoiceJson[element][0].NewInvOrder;

                                }   
                              }
                            }, this);
                            logger.debug("Adding to kafka!!!! UK:: "+invoiceJson.uk+", NewInvOrder:: "+newInvOrder);

                      KafkaLogger.addReqDetails(invoiceJson,checkJson.TOPIC,function(success){
                         
                      },function(err, nInvOrder){
                        //In case of failure on pushing to kafka, update in redis                      
                        redisUtils.saveFailedInvToRedis(invoiceJson.uk ,nInvOrder , function(success){}, function(error){});
                      }, newInvOrder);
                      callback();
                    }, function(err){
                          if(err){
                            errorCallbk('F');
                          }
                          else{         
                             successCallbk('S');
                           }
                        });
                }else{
                            logger.debug("Adding to kafka: Null payload");
                }
      }else{
        //Handle if the payload is coming as a json
            if(null != reqJsonVO.PAYLOAD && undefined != reqJsonVO.PAYLOAD){
                appconfig.gstrList.forEach(function(element) {
                  if(Object.keys(reqJsonVO.PAYLOAD).includes(element)){
                    if(null!= reqJsonVO.PAYLOAD[element][0] && undefined != reqJsonVO.PAYLOAD[element][0]){
                      invOrder = reqJsonVO.PAYLOAD[element][0].NewInvOrder;
                    }   
                  }
                }, this);
                logger.debug("Adding to kafka!!!! UK::"+reqJsonVO.PAYLOAD.uk+", Invorder:: "+invOrder);
            }else{
              logger.debug("Adding to kafka: Null payload");
            }
            KafkaLogger.addReqDetails(reqJsonVO.PAYLOAD,checkJson.TOPIC,successCallbk,errorCallbk);
        }
    }else if(checkforcontains(reqJsonVO.ORIGINALURL, appconfig.refreshTokenEndpoint)){
        logger.debug("Saving AuthToken for RefreshToken API");
        redisUtils.saveAuthToken(reqJsonVO ,appconfig.activeStatus , appconfig.activeStatusDesc, successCallbk, errorCallbk);
    }else if(checkforcontains(reqJsonVO.ORIGINALURL, appconfig.gspRefreshTokenEndpoint)){
        logger.debug("Saving GSP details for GSPRefreshToken");
        redisUtils.saveGspDetailsToRedis(reqJsonVO ,appconfig.activeStatus , appconfig.activeStatusDesc, successCallbk, errorCallbk);
    }else if(checkforcontains(reqJsonVO.ORIGINALURL, appconfig.getFailedInvEndpoint)){
        logger.debug("Getting the list of failed invoices from Redis");
        var uk;
        if(null != reqJsonVO.PAYLOAD && undefined != reqJsonVO.PAYLOAD){
           uk = reqJsonVO.PAYLOAD.uk;
           if(null != uk && undefined != uk){
             redisUtils.getFailedInvFromRedis(uk, successCallbk, errorCallbk);
           }else{
             logger.error("No uk value passed in the payload.");
             errorCallbk("No uk value passed in the payload.");
           }
        }else{
          logger.error("No uk value passed in the payload.");
          errorCallbk("No uk value passed in the payload.");
        }
        
    }else{
       errorCallbk("Invalid URL");
    }

    function checkforcontains(term, containstr) {
          return term.indexOf(containstr) == 0;
        };

  },

  getRequestInfosAsJsonVO : function(restReq) {
      var json = JSON.parse("{}");
        json.REQUEST_HEADER = JSON.parse(JSON.stringify(restReq.headers));
        json.REQUEST_PARAMS = JSON.parse(JSON.stringify(restReq.params));
        json.PAYLOAD = JSON.parse(JSON.stringify(restReq.body));
        json.ORIGINALURL = restReq.originalUrl;
        return json;
      },

 checkAction : function(url){
        var json = JSON.parse("{}");
        var topic = '';
        var addToKafka = false;
        var addToRedis = false;

        //Check if the data needs to be sent to kafka
        appconfig.urls.some(function(value){
          if(value.endpoint.indexOf(url) == 0 ){
              topic= value.topic;
              addToKafka = true;
              return true;
          }
        });

        //Check if the data needs to be sent to redis
        appconfig.addToRedisList.find(function(value){
          if(value.indexOf(url)== 0){
            addToRedis = true;
            return true;
          }

        });

        json.ADDTOKAFKA = addToKafka;
        json.ADDTOREDIS = addToRedis;
        json.TOPIC = topic;

        return json;
 }


};

module.exports = RefTknServiceMngr;
