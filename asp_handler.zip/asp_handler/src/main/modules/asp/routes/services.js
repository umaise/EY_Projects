
var express = require('express');
var http = require('http');
var request = require('request');
var logger = require('../logger/logger.js')
var KafkaLogger = require('../msghandler/aspProducer.js');
var servicemngr = require('../servicemanager/aspServicemngr.js');
var appconfig = require('../config/appconfig.js')
var router = express.Router();

var interceptFunction = function(req, res, next) {

  //Added params for RefreshToken
  if(req.originalUrl.indexOf("getrefreshtoken") != -1){

         //var expiryOffset = (parseInt(req.body['expiry'])/appconfig.gstnRefreshTokenInMins)*60000;// FINAL
         var expiryOffset = (appconfig.gstnRefreshInHours*60)*60000;// Refresh every 3 hours
         var currentTimeMs = new Date().getTime();
         var timeToexpireMs = expiryOffset + currentTimeMs;
         req.params['EXPIRY_IN_MS'] = timeToexpireMs;
         req.params['REFRESH_TYPE'] = 'GSTN';
         req.params['RETRY_COUNT'] = 0;

         KafkaLogger.addReqDetails(servicemngr.getRequestInfosAsJsonVO(req),appconfig.auditLogtopicID,
            function(success) {
              logger.debug(success);
            },
            function(error) {
              logger.error( error );
            });
      }

    //Refresh Token for GSP
    if(req.originalUrl.indexOf("gsprefreshtoken") != -1){
        //3419-3000
         var expiryOffset = (parseInt(req.body['expiry'])/appconfig.gspRefreshTokenInSecs);// TODO currently for 30 mins.
         var currentTimeMs = new Date().getTime()/1000;
         var timeToexpireSec = expiryOffset + currentTimeMs;
         req.params['EXPIRY_IN_S'] = timeToexpireSec;
         req.params['REFRESH_TYPE'] = 'GSP';
         req.params['RETRY_COUNT'] = 0;

         KafkaLogger.addReqDetails(servicemngr.getRequestInfosAsJsonVO(req),appconfig.gspRefreshTopicID,
            function(success) {
              logger.debug(success);
            },
            function(error) {
              logger.error( error );
            });
      }
  next();
};

/* post method */
router.post('/*', interceptFunction, function(req, res, next) {
    servicemngr.handleRequest(
    servicemngr.getRequestInfosAsJsonVO(req),
      function(success) {
        logger.debug(success);
        res.send(success);
        res.end();
      },
      function(err) {
        logger.error(err);
        res.send(err);
        res.end();
      }
    );
});

module.exports = router;
