var logger = require('../logger/logger.js')
var appconfig = require('../config/appconfig.js');
var cryptor = require('./cryptor.js');
var redisUtils = require('../redisdbhandlr/redisUtil.js');
var restCallUtil = require('../servicemanager/restCallUtil.js');

var refreshTokenUtil = {
  getHeadersGSP : function(inreqJsonVO) {
            var headers = {
           "username" :  inreqJsonVO.REQUEST_HEADER["username"],
           "state-cd" : inreqJsonVO.REQUEST_HEADER["state-cd"],
           "txn" :   inreqJsonVO.REQUEST_HEADER["txn"],
           "digigst_username" : inreqJsonVO.REQUEST_HEADER["digigst_username"],
           "api_key" : inreqJsonVO.REQUEST_HEADER["api_key"],
		   "api_secret" : inreqJsonVO.REQUEST_HEADER["api_secret"],
           "ip-usr" : inreqJsonVO.REQUEST_HEADER["ip-usr"],
           "access_token" :inreqJsonVO.REQUEST_HEADER["access_token"],
           "Content-Type" :  "application/json;charset=UTF-8"
         }
      return headers;
  },
  getHeadersGSTN : function(inreqJsonVO) {
    var headers = {
      "clientid" : appconfig.clientId,
      "client-secret" : appconfig.clientSecret,
      "txn" :  appconfig.txn,
      "ip-usr" : appconfig.ipUsr,
      "state-cd" : inreqJsonVO.PAYLOAD["state-cd"],
      "org":"TENANTID_01",
      "Content-Type" : appconfig.contentType
    }
    return headers;
  },
  getRequestPayloadGSP : function(inreqJsonVO, encAppKey) {
    var payload = {
      "action" : inreqJsonVO.PAYLOAD.action,
      "app_key" : encAppKey,
      "username" : inreqJsonVO.PAYLOAD.username,
      "auth_token" : inreqJsonVO.PAYLOAD.auth_token
    }
    return JSON.stringify(payload);
  },

  updateRedis : function(inreqJsonVO, sk, authToken, flag, errorCode, successCallback, errorCallBack) {
    redisUtils.updateAuthToken( inreqJsonVO.PAYLOAD.gstin, inreqJsonVO.PAYLOAD.username, sk, authToken,flag, errorCode, function  ( success ){
        successCallback("Updated data in redis for gstin : " + inreqJsonVO.PAYLOAD.gstin, inreqJsonVO);
    }, function(error){
        errorCallBack("Error in updating data in Redis : " + error, inreqJsonVO);
    }  ) ;
  },

  getrefreshtokenGSP : function(inreqJsonVO, encData, successCallback, errorCallBack){

    if(appconfig.apiCall !=null && appconfig.apiCall == "GSP" ){
      var  headers = this.getHeadersGSP(inreqJsonVO);
      var  url = appconfig.host_gsp_local + appconfig.resource_gsp_local;
      var encAppKey = encData.data;
      var appKey = encData.key;
      var body = this.getRequestPayloadGSP(inreqJsonVO, encAppKey);
      var responseObjectRefAPICall = restCallUtil.executePostCall(inreqJsonVO, headers, body, url, successCallback, errorCallBack);

    } else if(appconfig.apiCall !=null && appconfig.apiCall == "GSTN" ){
      var  headers = this.getHeadersGSTN(inreqJsonVO);
      var  url = "http://devapi.gstsystem.co.in/taxpayerapi/v0.2/authenticate";
      var encAppKey = encData.data;
      var appKey = encData.key;
      var proxy = "http://ingssweb.ey.net:8080";
      var body = this.getRequestPayloadGSP(inreqJsonVO, encAppKey);
      var responseObjectRefAPICall = restCallUtil.executePostCallGSTN(inreqJsonVO, headers, body, url, proxy, successCallback, errorCallBack);
    }
  },
  handleReftknRequest: function(reqJsonVO, successCallback, errorCallBack) {
    var self = this;
    var responseObjectEncryptCall = cryptor.getEncryptedAPPkey(reqJsonVO,
      function(successEncp, inreqJsonVO ) {
          self.getrefreshtokenGSP(inreqJsonVO, successEncp,
                function(successGsp, inreqJsonVO) {
                        if(successGsp.status_cd == 1) {
                            var responseOutput =  {
                              "appkey" : inreqJsonVO.PAYLOAD.app_key,
                              "sek" : successGsp.sek,
                              "auth_token" : successGsp.auth_token,
                              "expiry" : successGsp.expiry
                            }
                             var temp = successGsp.expiry;
                             var responseObjectDecrypt = cryptor.getDecryptedSEK(inreqJsonVO, responseOutput,
                                    function(successSEK, inreqJsonVO) {
                                        self.updateRedis(inreqJsonVO,
                                         successSEK.data, responseOutput.auth_token, appconfig.activeStatus,appconfig.activeStatusDesc,
                                         function(updateRedisSuccess, inreqJsonVO){
                                           successCallback(successSEK, responseOutput);
                                      }, function (updateRedisError, inreqJsonVO){
                                          errorCallBack(updateRedisError,inreqJsonVO );
                                      });
                                    },
                                    function(errSEK, inreqJsonVO) {
                                       logger.error("Error while decryption" + errSEK);
                                       errorCallBack(errSEK, inreqJsonVO);
                                    });
                        } else {
                            // error callback for status 0
                            var errorMsg = JSON.parse(JSON.stringify(successGsp.error)).message;
                            logger.error("Response with status-cd : '0' : " + errorMsg);
                            errorCallBack(errorMsg , inreqJsonVO);
                        }
                },
                function(errGSTN, inreqJsonVO) {
                  // error callback for getrefreshtokenGSTN
                    logger.error("Error in refreshToken GSTN call:  " + errGSTN);
                    //Retry refresh call
                    errorCallBack(errGSTN, inreqJsonVO, true);
                });
            },
            function(errEncp,inreqJsonVO) {
              // error callback for getEncryptedAPPkey
                logger.error("Error in Encrypt GSTN call:  " + errEncp);
                errorCallBack(errEncp, inreqJsonVO);
            });
   }
};
module.exports = refreshTokenUtil;
