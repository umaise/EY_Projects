var crypto = require("crypto");
var appconfig = require('../config/appconfig.js');

var cryptoutil = {
    cipher: function (reqJsonVO, successCallback, errorCallBack) {
        try {
            var algorithm = appconfig.encryptionAlgorithm;
            var cipher = crypto.createCipheriv(algorithm, new Buffer(reqJsonVO.PAYLOAD.sk, 'base64'), new Buffer(''));
            var crypted = cipher.update(reqJsonVO.PAYLOAD.app_key, 'base64', 'base64');
            crypted += cipher.final('base64');
            successCallback(cryptoutil.getEncryptedInfoAsJsonVO(reqJsonVO, crypted),reqJsonVO);
        }
        catch (err) {
            errorCallBack(err,reqJsonVO);
        }
    },
    decipher: function (reqJsonVO,responseOutput, successCallback, errorCallBack) {
        try {
            var algorithm = appconfig.encryptionAlgorithm;
            var decipher = crypto.createDecipheriv(algorithm, new Buffer(responseOutput.appkey, 'base64'), new Buffer(''))
            var dec = Buffer.concat([decipher.update((new Buffer(responseOutput.sek, 'base64'))), decipher.final()]).toString('base64');
            successCallback(cryptoutil.getDecryptedInfoAsJsonVO(responseOutput, dec));
        }
        catch (err) {
            errorCallBack(err);
        }
    },
    getEncryptedInfoAsJsonVO: function (reqJsonVO, response) {
        var json = JSON.parse("{}");
        json['data'] = response;
        json['key'] = reqJsonVO.PAYLOAD.app_key;
        return json;
    },
    getDecryptedInfoAsJsonVO: function (reqJsonVO, response) {
        var json = JSON.parse("{}");
        json['data'] = response;
        json['key'] = reqJsonVO.appkey;
        return json;
    }
}
module.exports = cryptoutil;
