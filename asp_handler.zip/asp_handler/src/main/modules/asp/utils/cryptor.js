var appconfig = require('../config/appconfig.js');
var restCallUtil = require('../servicemanager/restCallUtil.js');
var cryptoutil = require('./cryptoutil.js');

var cryptor = {
  getEncryptedAPPkey: function (reqJsonVO, successCallback, errorCallBack) {
    if (appconfig.restCall) {
      var headers = {
        "content-type": "application/json;charset=UTF-8"
      }
      var body = cryptor.getPayloadForEncrypt(reqJsonVO);
      var url = appconfig.host_asp + appconfig.resource_asp_encrypt;
      var responseObjectOne = restCallUtil.executePostCall(reqJsonVO, headers, body, url, function (success, reqJsonVO) {
        successCallback(success, reqJsonVO);
      },
        function (err, reqJsonVO) {
          errorCallBack(err, reqJsonVO);
        });
    }
    else {
      var responseObjectOne = cryptoutil.cipher(reqJsonVO, function (success, reqJsonVO) {
        successCallback(success, reqJsonVO);
      },
        function (err, reqJsonVO) {
          errorCallBack(err, reqJsonVO);
        });
    }
    return responseObjectOne;
  },
  getPayloadForEncrypt: function (reqJsonVO) {
    var payload = {
      "key": reqJsonVO.PAYLOAD.sk,
      "data": reqJsonVO.PAYLOAD.app_key
    }
    return JSON.stringify(payload);
  },
  getPayloadForDecrypt: function (sek, appKey) {
    var payload = {
      "key": appKey,
      "data": sek
    }
    return JSON.stringify(payload);
  },
  getDecryptedSEK: function (inreqJsonVO, resOutput, successCallback, errorCallBack) {
    if (appconfig.restCall) {
      var headers = {
        "content-type": "application/json;charset=UTF-8"
      }
      var body = cryptor.getPayloadForDecrypt(resOutput.sek, resOutput.appkey);
      var url = appconfig.host_asp + appconfig.resource_asp_decrypt;
      var responseObject = restCallUtil.executePostCall(inreqJsonVO, headers, body, url, function (success) {
        successCallback(success, inreqJsonVO);
      },
        function (err) {
          errorCallBack(err, inreqJsonVO);
        });
    }
    else {
      var responseObject = cryptoutil.decipher(inreqJsonVO, resOutput, function (success) {
        successCallback(success, inreqJsonVO);
      },
        function (err) {
          errorCallBack(err, inreqJsonVO);
        });
    }
  }
};
module.exports = cryptor;
