var kafka = require('kafka-node');
var http = require('http');
var request = require('request');
var appconfig = require('../config/appconfig.js');

var logger = require('../logger/logger.js')

var KafkaUtils = {
  senddata: function(kafkaproducer, payloads, callBck, retryCnt) {
    retryCnt++;
    kafkaproducer.send(payloads, function (err, data) {
      if (null != err && undefined != err) {
        logger.error("Retry Count:: "+retryCnt+" Error:: " + err);
        setTimeout(function () {
          if (retryCnt <= appconfig.kafkaMaxRetry)
            KafkaUtils.senddata(kafkaproducer, payloads, callBck, retryCnt);
          else
            callBck(err, data);

        }, 2000);
      }else
        callBck(err, data);
    //kafkaproducer.send(payloads, function(err, data) {
      //callBck(err, data);
    });
  },
  consume: function(kafkaClient, successCallbck, errorCallBck) {},
  createProducer: function(kafkaZks, successCallbck, errorCallBck) {
    logger.debug("Initializing kafka logger : hosts[" + kafkaZks + "]");
    var client = new kafka.Client(kafkaZks);
    var kafkaproducer = new kafka.HighLevelProducer(client);
    kafkaproducer.on('ready', function() {
      successCallbck();
    });
    kafkaproducer.on('error', function(err) {
      errorCallBck(err);
    });
    return kafkaproducer;
  },

  createConsumer: function(kafkaZks, topics, consumerGroupId) {
	logger.debug("Initializing kafka log consumer : hosts[" + kafkaZks + "], topic [" + topics + "]" + " consumerGroupId : " +consumerGroupId);
    var client = new kafka.Client(kafkaZks);
    var options = {

      /* TODO : For development change group id to dynamic number */
      groupId: 'ASPHAND-node-group',
	  sessionTimeout: 60000,
      /* Auto commit config */
      autoCommit: true,
      autoCommitMsgCount: 100,
      autoCommitIntervalMs: 10000,

      /* Fetch message config */
      fetchMaxWaitMs: 100,
      fetchMinBytes: 1,
      fetchMaxBytes: 20 * 1024 * 1024 ,
      fromOffset: 'latest',
      fromBeginning: false
    };
	
	var options1 = {

      host: kafkaZks,
      groupId: consumerGroupId,
	  sessionTimeout: 60000,
      /* Auto commit config */
      autoCommit: true,
      autoCommitMsgCount: 100,
      autoCommitIntervalMs: 10000,
	  
	  protocol: ['roundrobin'],

      /* Fetch message config */
      fetchMaxWaitMs: 100,
      fetchMinBytes: 1,
      fetchMaxBytes: 20 * 1024 * 1024 ,
      fromOffset: 'earliest',
      //fromBeginning: false
	  migrateHLC: false,
	  migrateRolling: true
    };

    
         var topicArray =[];
		 var topicArray1 =[];
     topics.forEach(function(topic){
     var opt = {};
      opt.topic = topic;
      topicArray.push(opt);
	  topicArray1.push(topic);
     });
	 
	 logger.debug("topicArray1 " + topicArray1);
	 
	/* 
    var consumer = new kafka.HighLevelConsumer (
      client, topicArray,
      options
    ); */
	
	var consumer = new kafka.ConsumerGroup(options1,topicArray1);
	
      consumer.on('error', function(err) {
        logger.error('kafka error: ' + JSON.stringify(err, null, 4));
      });
      consumer.on('offsetOutOfRange', function (topic) {
        logger.error('kafka offsetOutOfRange: ' + JSON.stringify(err, null, 4));
        topic.maxNum = 2;
        offset.fetch([topic], function (err, offsets) {
        var min = Math.min.apply(null, offsets[topic.topic][topic.partition]);
        consumer.setOffset(topic.topic, topic.partition, min);
        });
      });
    return consumer;
  }
};

module.exports = KafkaUtils;
