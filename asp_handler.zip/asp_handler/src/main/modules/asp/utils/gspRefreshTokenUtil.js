var logger = require('../logger/logger.js')
var appconfig = require('../config/appconfig.js');
var cryptor = require('./cryptor.js');
var redisUtils = require('../redisdbhandlr/redisUtil.js');
var restCallUtil = require('../servicemanager/restCallUtil.js');

var gspRefreshTokenUtil = {
  getHeaders : function(inreqJsonVO) {
        var headers = {
           "digigst_username" : inreqJsonVO.REQUEST_HEADER["digigst_username"],
           "api_key" : inreqJsonVO.REQUEST_HEADER["api_key"],
           "api_secret" : inreqJsonVO.REQUEST_HEADER["api_secret"],
		   "access_token" :inreqJsonVO.REQUEST_HEADER["access_token"],
           "Content-Type" :  "application/json;charset=UTF-8"
         }
      return headers;
  },

  getRequestPayloadGSP : function(inreqJsonVO) {
        var payload = {
        "REFRESH_TOKEN" : inreqJsonVO.PAYLOAD['refresh_token']
        }

     return JSON.stringify(payload);
  },

  updateRedis : function(reqJsonVO, respJson, flag, errorCode, successCallback, errorCallBack) {
      
    redisUtils.updateGspDetailsToRedis(reqJsonVO, respJson, flag, errorCode, function  ( success ){
        successCallback("Updated data in redis for gsp : " + reqJsonVO.REQUEST_HEADER['digigst_username'], respJson);
    }, function(error){
        errorCallBack("Error in updating data in Redis : " + error, reqJsonVO);
    }  ) ;
  },

  getrefreshtokenGSP : function(inreqJsonVO, successCallback, errorCallBack){

      var  headers = this.getHeaders(inreqJsonVO);
      var  url = appconfig.host_gsp_local + appconfig.resource_gspRefresh;
      var body = this.getRequestPayloadGSP(inreqJsonVO);
      var responseObjectRefAPICall = restCallUtil.executePostCall(inreqJsonVO, headers, body, url, successCallback, errorCallBack);
   },

  handleRefreshTokenForGSP: function(reqJsonVO, successCallback, errorCallBack) {
    var self = this;

          self.getrefreshtokenGSP(reqJsonVO,
                function(successGsp, reqJsonVO) {

                        if(successGsp.gsp_status_cd == 1) {
                            var responseOutput =  {
                              "access_token" : successGsp['access_token'],
                              "refresh_token" : successGsp['refresh_token'],
                              "expiry" : successGsp['expiry']
                            }

                             self.updateRedis(reqJsonVO, successGsp, appconfig.activeStatus,appconfig.activeStatusDesc,
                                         function(updateRedisSuccess, reqJsonVO){
                                           successCallback(responseOutput);
                                      }, function (updateRedisError, reqJsonVO){
                                          errorCallBack(updateRedisError,reqJsonVO );
                                      });
                                    
                        } else {
                            // error callback for status 0
                            var errorMsg = successGsp['err_desc'];
                            logger.error("Response with gsp_status-cd : '0' : " + errorMsg);
                            errorCallBack(errorMsg , reqJsonVO);
                        }
                },
                function(errGSP, reqJsonVO) {
                  // error callback for getrefreshtokenGSP
                    logger.error("Error in refreshToken GSP call:  " + errGSP);
                    //Retry refresh call
                    errorCallBack(errGSP, reqJsonVO, true);
                });
   }
};
module.exports = gspRefreshTokenUtil;
