var logger = require('../logger/logger.js')
var appconfig = require('../config/appconfig.js');
var cryptor = require('./cryptor.js');
var redisUtils = require('../redisdbhandlr/redisUtil.js');
var restCallUtil = require('../servicemanager/restCallUtil.js');

var aspAppUtil = {
  getHeaders : function(message, successCallBack, errorCallBack) {
      var headers;
      this.getXTenantId(message, function(groupCode){
            headers = {
                "X-TENANT-ID": groupCode,
                "Content-Type" :  "application/json;charset=UTF-8"
            }
            successCallBack(headers);
        }, function(){
            errorCallBack();
        });

  },

  getXTenantId : function(message, successCallBack, errorCallBack){
    var value = JSON.parse(message.value);
    var groupCode = value[0].groupCode;
    if(null != groupCode && undefined != groupCode){
        successCallBack(groupCode);
    }else{
        errorCallBack();
    }

  },


  executeSaveGstr : function(message, successCallback, errorCallBack){

      var  headers;
      this.getHeaders(message, function(headersJson){
          headers = headersJson;
      }, function(){
        logger.error("Error getting X-TENANT-ID");
        headers = {};
      });

      var  url = appconfig.aspAppHost + appconfig.aspAppSaveResource;
      var body = JSON.stringify(JSON.parse(message.value));
      var responseObjectRefAPICall = restCallUtil.executePostCallAsp(message, headers, body, url, successCallback, errorCallBack);
   }
};
module.exports = aspAppUtil;
