var redisUtils = {}
var redisClient = require('../redisdbhandlr/redisClient.js');
var appconfig = require('../config/appconfig.js');
var dateFormat = require('dateformat');

var client = redisClient;
var redisUtils = {
  saveAuthToken: function(inreqJsonVO, flag, errorCode, successCallback, errorCallBack) {

     client.hmset(inreqJsonVO.PAYLOAD.gstin,
         {
            'userName': inreqJsonVO.PAYLOAD.username,
            'sk': inreqJsonVO.PAYLOAD.sk,
            'auth-token':  inreqJsonVO.PAYLOAD.auth_token,
            'group_code': inreqJsonVO.REQUEST_HEADER.group_code,
            'state-cd': inreqJsonVO.REQUEST_HEADER["state-cd"],
            'status' : flag,
            'errorCode' : errorCode,
            'dateModified' : dateFormat(new Date(), 'yyyy-mm-dd HH:MM:ss')
          } , function (error, success ) {
            if(success){
              successCallback("Data Saved in Redis");
            } else {
              errorCallBack("Error while save data in Redis..")
            }
          }
        );
  },
  updateAuthToken: function(gstin, userName, sk, authToken,  flag, errorCode, successCallback, errorCallBack) {
     client.hmset(gstin, {
       'userName': userName,
       'sk': sk,
       'auth-token': authToken,
       'status' : flag,
       'errorCode' : errorCode.toString(),
       'dateModified' : dateFormat(new Date(), 'yyyy-mm-dd HH:MM:ss')
     }, function (error,success) {
         if(success){
           successCallback("Data updated in Redis");
         } else {
           errorCallBack("Error while updating data in Redis..")
         }
       }
    );
  },
  updateAuthTokenError: function(gstin ,flag, errorCode, successCallback, errorCallBack ) {
    client.hmset(gstin, {
      'status' : flag,
      'errorCode' : errorCode.toString()
      //'dateModified' : dateFormat(new Date(), 'yyyy-mm-dd HH:MM:ss')
    },
    function (error, success ) {
        if(success){
          successCallback("Error code updated in Redis !!" );
        } else {
          errorCallBack("Error while updating error code in Redis !!")
        }
      }
    );
  },
  getAuthDetails: function(gstin, callback) {
    client.hgetall(gstin, function(err, object) {
      callback(JSON.stringify(object));
    });
  },

  saveToRedis : function(key, value,successCallback,errorCallBack) {
    client.set(key, value,function (error, success ) {
        if(success){
          successCallback("S" );
        } else {
          errorCallBack("F")
        }
      });
  //  successCallbk('Data saved in redis.. ');
},

  saveGspDetailsToRedis : function(reqJsonVO, flag, errorCode, successCallback, errorCallBack) {
         client.hmset(reqJsonVO.PAYLOAD['groupCode'].toLowerCase()+'_GSP_USERDETAILS',
         {
            'access_token': reqJsonVO.PAYLOAD['access_token'],
            'refresh_token': reqJsonVO.PAYLOAD['refresh_token'],
            'api_key':  reqJsonVO.PAYLOAD['api_key'],
            'api_secret':  reqJsonVO.PAYLOAD['api_secret'],
            'digigst_username': reqJsonVO.REQUEST_HEADER['digigst_username'],
            'expiry': reqJsonVO.PAYLOAD["expiry"],
            'status' : flag,
            'errorCode' : errorCode,
            'dateModified' : dateFormat(new Date(), 'yyyy-mm-dd HH:MM:ss')
          } , function (error, success ) {
            if(success){
              successCallback("Data Saved in Redis");
            } else {
              errorCallBack("Error while save data in Redis..")
            }
          }
        );
  },

    updateGspDetailsToRedis : function(reqJsonVO, respJson, flag, errorCode, successCallback, errorCallBack) {
      
         client.hmset(reqJsonVO.PAYLOAD['groupCode'].toLowerCase()+'_GSP_USERDETAILS',
         {
            'access_token': respJson['access_token'],
            'refresh_token': respJson['refresh_token'],
            'expiry': respJson["expiry"],
            'status' : flag,
            'errorCode' : errorCode,
            'dateModified' : dateFormat(new Date(), 'yyyy-mm-dd HH:MM:ss')
          } , function (error, success ) {
            if(success){
              successCallback("Updated data in Redis");
            } else {
              errorCallBack("Error while updating data in Redis..")
            }
          }
        );
  },

    updateGspDetailsError: function(groupCode, flag, errorCode, successCallback, errorCallBack ) {
      client.hmset(groupCode.toLowerCase()+'_GSP_USERDETAILS', {
        'status' : flag,
        'errorCode' : errorCode.toString()
        //'dateModified' : dateFormat(new Date(), 'yyyy-mm-dd HH:MM:ss')
      },
      function (error, success ) {
          if(success){
            successCallback("Error code updated in Redis !!" );
          } else {
            errorCallBack("Error while updating error code in Redis !!")
          }
        });
  },

  saveFailedInvToRedis : function(key, value,successCallback,errorCallBack) {
    client.sadd(key+"_FAILED_INV", value,function (error, success ) {
        if(success){
          successCallback("S" );
        } else {
          errorCallBack("F")
        }
      });
  //  successCallbk('Data saved in redis.. ');
  },

  getFailedInvFromRedis : function(key, successCallback, errorCallBack) {
    client.smembers(key+"_FAILED_INV", function (error, failedInvSet) {
        if(null != error && undefined != error){
           errorCallBack("Error fetching the list of failed Invoices from redis.")
        }else {
          var arrayOfNumbers = failedInvSet.map(Number);
          successCallback(arrayOfNumbers);
        }
      });
  //  successCallbk('Data saved in redis.. ');
  }

}
module.exports = redisUtils;
