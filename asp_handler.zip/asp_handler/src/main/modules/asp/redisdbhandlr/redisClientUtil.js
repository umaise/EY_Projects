var redisClientUtil = {}
var redis = require('redis');
var redisClient = require('../redisdbhandlr/redisClient.js');

 var redisClientUtil = {
 init :  function (successCallBack, errorCallBack ) {
      var client =  redisClient;
     client.on('connect', function() {
       successCallBack();
     });
     client.on('error', function(err) {
       errorCallBack(err);
     });
   return client;
}
}
module.exports = redisClientUtil;
