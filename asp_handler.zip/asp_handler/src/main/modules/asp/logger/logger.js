var winston = require('winston');
var appconfig = require('../config/appconfig.js');
var dateFormat = require('dateformat');

var logFilePath = __basedir.replace(/\\/g,"/") +"/.."+appconfig.logFilePath+".log";
var logger = new (winston.Logger)({
  transports: [
    //new (winston.transports.Console)({ json: false, timestamp: true, colorize: true }),
    new (require('winston-daily-rotate-file'))({ filename: logFilePath, datePattern: '.yyyy-MM-dd', maxFiles: 10, maxsize: 10240000, level: appconfig.logLevel, json:false  
    ,timestamp: function() {
        return dateFormat(Date.now(), 'yyyy-mm-dd HH:MM:ss');
    }
    ,formatter: function(options) {
        return '['+options.timestamp() +'] ['+ options.level.toUpperCase() +'] ASPHandler - '+ (options.message ? options.message : '')
      } 
    })
  
  ],
  exitOnError: false
});


module.exports = logger;