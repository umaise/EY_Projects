var appconfigs = {}
var commonConfig = require('../config/commonConfig.js');
var config = commonConfig.config();

appconfigs.urls =
  [{   endpoint : "/gstr1/rulesOnRawData",    topic : "gstr1-rulesonRawData"    },
  {   endpoint : "/gstr1/interfaceGSTN",      topic : "gstr1-interfaceGSTN1"     },
  {   endpoint : "/gstr1/applyStage2rules",   topic : "gstr1-applyStage2rulesTopic"  },
  {   endpoint : "/gstr2/rulesOnRawData",     topic : "gstr2-rulesonRawData"    },
  {   endpoint : "/gstr2/interfaceGSTN",      topic : "gstr2-interfaceGSTN"     },
  {   endpoint : "/gstr2a/reconciliation",    topic : "gstr2a-reconciliation"     },
  {   endpoint : "/gstr6/rulesOnRawData",    topic : "gstr6-rulesOnRawData"     },
  {   endpoint : "/gstr7/rulesOnRawData",    topic : "gstr7-rulesOnRawData"     }
   ];
appconfigs.addToRedisList = process.env.ADDTOREDISLIST || config.addToRedisList;

appconfigs.gstrList = process.env.GSTRLIST || config.gstrList;
appconfigs.logFilePath = process.env.LOGFILEPATH || config.logFilePath;
appconfigs.logLevel = process.env.ASPHDLR_LOGLEVEL || config.logLevel;
appconfigs.kafkaZKList = process.env.KAFKAZKLIST || config.kafkaZKList;
appconfigs.kafkaMaxRetry = process.env.KAFKA_MAX_RETRY || config.kafkaMaxRetry;
appconfigs.consumerGroupId = config.consumerGroupId; 
appconfigs.auditLogtopicID = process.env.AUDITLOGTOPICID || config.auditLogtopicID;
appconfigs.auditLogpartitions = process.env.AUDITLOGPARTITIONS || config.auditLogpartitions;
appconfigs.refreshTokenEndpoint = process.env.REFRESHTOKENENDPOINT || config.refreshTokenEndpoint;

appconfigs.redisHost = process.env.REDIS_HOST || config.redisHost;
appconfigs.redisPort = process.env.REDIS_PORT || config.redisPort;
appconfigs.redisAuth= process.env.REDIS_AUTH || config.redisAuth;

appconfigs.host_gsp_local =  process.env.HOST_GSP || config.host_gsp_local;
appconfigs.resource_gsp_local = process.env.RESOURCE_GSP || config.resource_gsp_local;
appconfigs.refreshTokenAction = process.env.REFRESH_TOKEN_ACTION || config.refreshTokenAction;

appconfigs.aspAppHost =  process.env.ASP_APP_HOST || config.aspAppHost;
appconfigs.aspAppSaveResource =  process.env.ASP_APP_SAVE_RSRC || config.aspAppSaveResource;

//headers fro gstn
appconfigs.clientId = "l7xxb80f74e32f3846cea73b7acdb62491dc";
appconfigs.clientSecret = "2870611482b74016b15b25a6e229a740";
appconfigs.ipUsr = "12.8.9l.80";
appconfigs.txn = "returns";
appconfigs.contentType = "application/json;charset=UTF-8";
//error codes and desc
appconfigs.inactiveStatus = 'N';
appconfigs.activeStatus = 'Y';
appconfigs.activeStatusDesc = 'No Error';

appconfigs.host_asp = process.env.HOST_ASP || config.host_asp;
appconfigs.resource_asp_encrypt = process.env.RESOURCE_ASP_ENCRYPT || config.resource_asp_encrypt;
appconfigs.resource_asp_decrypt = process.env.RESOURCE_ASP_DECRYPT || config.resource_asp_decrypt;
appconfigs.apiCall =   process.env.apiCall || config.apiCall;

appconfigs.restCall = process.env.restCall || config.restCall;
appconfigs.encryptionAlgorithm = process.env.encryptionAlgorithm || config.encryptionAlgorithm

appconfigs.gspRefreshTopicID = process.env.GSPREFRESHTOPICID || config.gspRefreshTopicID;
appconfigs.gspRefreshTokenEndpoint = process.env.GSPREFRESHTOKENENDPOINT || config.gspRefreshTokenEndpoint;
appconfigs.resource_gspRefresh = process.env.RESOURCE_GSPREFRESH || config.resource_gspRefresh;
appconfigs.kafkaTopicList = process.env.KAFKATOPICLIST || config.kafkaTopicList;

appconfigs.gspRefreshTokenInSecs = process.env.GSP_REFTKN_SEC || config.gspRefreshTokenInSecs;

appconfigs.gstnRefreshAction = process.env.GSTN_REFRESH_ACTION || config.gstnRefreshAction;
appconfigs.gspRefreshAction = process.env.GSP_REFRESH_ACTION || config.gspRefreshAction;

appconfigs.setTimeOutIntervalInMin = process.env.SETTIMEOUT_IN_MINS || config.setTimeOutIntervalInMin;
appconfigs.proxy = process.env.NODE_PROXY || config.proxy;

appconfigs.getFailedInvEndpoint = process.env.GET_FAILED_INV_EP || config.getFailedInvEndpoint;
appconfigs.gstnRefreshInHours = process.env.GSTN_REFTKN_HOUR || config.gstnRefreshInHours;

appconfigs.refreshGSTNMaxRetry = process.env.REFRESH_GSTN_MAX_RETRY || config.refreshGSTNMaxRetry;
appconfigs.refreshGSPMaxRetry = process.env.REFRESH_GSP_MAX_RETRY || config.refreshGSPMaxRetry;
appconfigs.setGSTNRefreshTimeOutInHours = process.env.GSTN_REF_TIMEOUT_HOUR || config.setGSTNRefreshTimeOutInHours;
appconfigs.setGSPRefreshTimeOutInHours = process.env.GSP_REF_TIMEOUT_HOUR || config.setGSPRefreshTimeOutInHours;

module.exports = appconfigs;
