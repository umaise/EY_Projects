var logger = require('../logger/logger.js')
var kafkautil = require('../utils/kafkautil');
var refreshTokenUtil = require('../utils/refreshTokenUtil.js');
var KafkaLogger = require('../msghandler/aspProducer.js')
var redisUtils = require('../redisdbhandlr/redisUtil.js');
var servicemngr = require('../servicemanager/aspServicemngr.js');
var appconfig = require('../config/appconfig.js');
var gspRefreshTokenUtil = require('../utils/gspRefreshTokenUtil.js');
var aspAppUtil = require('../utils/aspAppUtil.js');


var kafkalogconsumer = function() {
  this.kafkaZks = null;
  this.logTopic = null;
  this.consumerGroupId = null;
}
kafkalogconsumer.prototype = {
  init: function(kafkaZks, logTopic,consumerGroupId, callbackfunc) {
    var self = this;
    this.kafkaZks = kafkaZks;
    this.logTopic = logTopic;
    this.consumerGroupId = consumerGroupId;
    self.kafkaconsumer = kafkautil.createConsumer(self.kafkaZks, self.logTopic, self.consumerGroupId);
  },
  processLogMessages: function() {
    var self = this;
    self.kafkaconsumer.on('message', function(message) {
      var messagejson = JSON.parse(message.value);
      var action = (null != messagejson && undefined != messagejson &&  null != messagejson.REQUEST_PARAMS && undefined != messagejson.REQUEST_PARAMS)?messagejson.REQUEST_PARAMS['REFRESH_TYPE'] : null;
       var topic = message.topic;
 
      //GSTN Refresh Token
      if(appconfig.gstnRefreshAction.indexOf(action) == 0){
          var tokenExpTimeMS = messagejson.REQUEST_PARAMS['EXPIRY_IN_MS'];
          var currentTimeMs = new Date().getTime();
          if ((currentTimeMs + 1000) >= tokenExpTimeMS || (null != messagejson.REQUEST_PARAMS['RETRY_COUNT'] && undefined != messagejson.REQUEST_PARAMS['RETRY_COUNT'] && messagejson.REQUEST_PARAMS['RETRY_COUNT'] > 0)) {
              refreshTokenUtil.handleReftknRequest(messagejson, function(success, response) {
                  //messagejson.REQUEST_PARAMS['EXPIRY_IN_MS'] = (new Date().getTime()) + (response.expiry/appconfig.gstnRefreshTokenInMins)*60000;//TODO : 30 mins refresh approach
                  messagejson.REQUEST_PARAMS['EXPIRY_IN_MS'] = (new Date().getTime()) + (appconfig.gstnRefreshInHours*60)*60000;//Refresh every 3 hours
                  messagejson.PAYLOAD['sk'] = success.data;
                  messagejson.PAYLOAD['app_key'] = success.key;
                  messagejson.PAYLOAD['auth_token'] = response.auth_token;
                  //Reset the retry count
                  messagejson.REQUEST_PARAMS['RETRY_COUNT'] = 0;

                  KafkaLogger.addReqDetails(messagejson,topic,function(success) {},function(error) {});
                  logger.debug("Session is refreshed successfully for GSTIN :" + messagejson.PAYLOAD.gstin);
            },
            function(err, reqJsonVO, retryFlag) {
                //logger.error("Session couldn't be refreshed !! " + err.toString()) ;

                if (retryFlag && (null != messagejson.REQUEST_PARAMS['RETRY_COUNT']) && (undefined != messagejson.REQUEST_PARAMS['RETRY_COUNT']) 
                  && (messagejson.REQUEST_PARAMS['RETRY_COUNT'] < appconfig.refreshGSTNMaxRetry)){
                    logger.debug("Retry count: "+messagejson.REQUEST_PARAMS['RETRY_COUNT']+" for GSTN: "+messagejson.PAYLOAD.gstin);
                    setTimeout(function(){
                      messagejson.REQUEST_PARAMS['RETRY_COUNT'] = messagejson.REQUEST_PARAMS['RETRY_COUNT'] + 1;
                      KafkaLogger.addReqDetails(messagejson,topic,function(success) {},function(error) {});},(appconfig.setGSTNRefreshTimeOutInHours * 60 * 60 * 1000));
                }else{
                    //Update the error details in redis
                      redisUtils.updateAuthTokenError(reqJsonVO.PAYLOAD.gstin, appconfig.inactiveStatus, err,
                        function(success) {},
                        function(error) {});
                }
            });
        } else {

            //KafkaLogger.addReqDetails(messagejson,topic,function(success) {},function(error) {});
           setTimeout(function(){
             KafkaLogger.addReqDetails(messagejson,topic,function(success) {},function(error) {});},(appconfig.setTimeOutIntervalInMin * 60 * 1000));
        }
    }
    //GSP Refresh Token
    else if(appconfig.gspRefreshAction.indexOf(action) == 0){
      var currentTime = Math.floor(new Date().getTime()/1000);
      var tokenExpTime = messagejson.REQUEST_PARAMS['EXPIRY_IN_S'];
        if ((currentTime) >= tokenExpTime || (null != messagejson.REQUEST_PARAMS['RETRY_COUNT'] && undefined != messagejson.REQUEST_PARAMS['RETRY_COUNT'] && messagejson.REQUEST_PARAMS['RETRY_COUNT'] > 0)) {
            gspRefreshTokenUtil.handleRefreshTokenForGSP(messagejson, function(response) {

             messagejson.REQUEST_PARAMS['EXPIRY_IN_S'] =(new Date().getTime()/1000) + (response['expiry']/appconfig.gspRefreshTokenInSecs);//In seconds
             messagejson.REQUEST_PARAMS['REFRESH_TYPE'] = 'GSP';
             messagejson.PAYLOAD['refresh_token'] = response['refresh_token'];
             //Reset the retry count
             messagejson.REQUEST_PARAMS['RETRY_COUNT'] = 0;
             
             KafkaLogger.addReqDetails(messagejson,topic,function(success) {},function(error) {});
             logger.debug("Session is refreshed successfully for GSP :" + messagejson.PAYLOAD['groupCode']+" username: "+messagejson.REQUEST_HEADER["digigst_username"]);//TODO remove GSTIN from logs
          },
          function(err, reqJsonVO, retryFlag) {
            console.log("GSP Retry:: ");
                if (retryFlag && (null != messagejson.REQUEST_PARAMS['RETRY_COUNT']) && (undefined != messagejson.REQUEST_PARAMS['RETRY_COUNT']) 
                  && (messagejson.REQUEST_PARAMS['RETRY_COUNT'] < appconfig.refreshGSTNMaxRetry)){
                    logger.debug("Retry count:"+messagejson.REQUEST_PARAMS['RETRY_COUNT']+" for GSP: "+messagejson.REQUEST_HEADER["digigst_username"]);
                    setTimeout(function(){
                      messagejson.REQUEST_PARAMS['RETRY_COUNT'] = messagejson.REQUEST_PARAMS['RETRY_COUNT'] + 1;
                      KafkaLogger.addReqDetails(messagejson,topic,function(success) {},function(error) {});},(appconfig.setGSPRefreshTimeOutInHours * 60 * 60 * 1000));
                }else{
                    //Update the error details in redis
                      redisUtils.updateGspDetailsError(reqJsonVO.PAYLOAD['groupCode'], appconfig.inactiveStatus, err,
                        function(success) {},
                        function(error) {});
                }
          }
        );
      } else {

            //KafkaLogger.addReqDetails(messagejson,topic,function(success) {},function(error) {});
          setTimeout(function(){
             KafkaLogger.addReqDetails(messagejson,topic,function(success) {},function(error) {});},(appconfig.setTimeOutIntervalInMin * 60 * 1000));
      }
    }
    //SaveGSTR
    else {
      logger.info("Executing savegstr1");
      aspAppUtil.executeSaveGstr(message, function(success){
        logger.debug("SaveGstr1 Success");
      }, function(error){
        logger.debug("SaveGstr1 Error");
      });
    }
    });
  },
  exithndlrFunc: function(callbackFunc) {
    var self = this;
    logger.error("Closing Kafka Log consumer !");
    self.kafkaconsumer.close(true, callbackFunc);
  }
}
module.exports = new kafkalogconsumer();
