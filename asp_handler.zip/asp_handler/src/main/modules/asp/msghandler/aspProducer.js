var logger = require('../logger/logger.js')
var kafkautil = require('../utils/kafkautil');

function KafkaLogger() {
  this.RESP_INFO = "RESP_INFO";
  this.auditlogTopic = null;
  this.kafkaproducer = null;
}

KafkaLogger.prototype = {
  init: function(kafkaZks, successCallbck, errorCallBck) {
    var self = this;

    self.kafkaproducer = kafkautil.createProducer(kafkaZks, function() {
      self.producerReady = true;
      successCallbck();
    }, errorCallBck)
  },

  addReqDetails: function(reqMsgJsonVO,toTopic , successCallBack , errorCallBack, nInvOrder ) {
    var self = this;
    payloads = [{
      topic: toTopic,
      messages: JSON.stringify(reqMsgJsonVO)
    }];
    if (typeof self.producerReady !== 'undefined' && self.producerReady != null) {
      
      kafkautil.senddata(self.kafkaproducer, payloads, function(err, data) {
        if (err !== 'undefined' && err != null) {
           logger.error("Error: kafka logger is not ready yet, failed to produce message to Kafka.");
           errorCallBack(err, nInvOrder);
        }
        else {     
           successCallBack("S");
        }
      }, 0);
    } else {
      logger.error("Error: kafka logger is not ready yet, failed to produce message to Kafka.");
       errorCallBack("F", nInvOrder);
    }
  }
};

var loggerObject = (function() {
  var instance;

  function createInstance() {
    instance = new KafkaLogger();
    return instance;
  }
  return {
    getInstance: function() {
      if (!instance) {
        instance = createInstance();
      }
      return instance;
    }
  };
})();

module.exports = loggerObject.getInstance();
