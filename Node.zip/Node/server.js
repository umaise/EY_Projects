var Neo4jURL = "bolt://localhost:7687";;
var username = "neo4j";
var pw = "Winter2020!radius";

var sql = require('mssql');
var config = {
    server: 'localhost',
    database: 'ReportingRadius',
    user: 'sa',
    password: '$Karishmarajesh456',
    port: 1433,
    options: {
        encrypt: true,
        enableArithAbort: true,
        requestTimeout: 130000,
        idleTimeoutMillis: 130000
    },
    multipleStatements: true,
    queryFormat: function (query, values) {
        if (!values) return query;
        return query.replace(/\:(\w+)/g, function (txt, key) {
            if (values.hasOwnProperty(key)) {
                return this.escape(values[key]);
            }
            return txt;
        }.bind(this));
    }
};

var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var neo4j = require('neo4j-driver');
var app = express();
const cors = require('cors');
app.use(cors());
app.options('*', cors());

const fs = require("fs");
const {
    Readable
} = require('stream');
const inputfile = "FFIEC002_202006_f-converted (003)_17th Dec (1).xlsx";
const outputfile = inputfile + "_result.xlsx";

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));

var driver1 = neo4j.driver(Neo4jURL, neo4j.auth.basic(username, pw));
var session1 = driver1.session();
var session2 = driver1.session();
var session3 = driver1.session();
var session4 = driver1.session();

// ** USED FOR DASHBOARD DROPDOWNS ** //

app.get('/GetLineItems', function (req, res) {
    var count = 0;
    var result;
    session1
        .run('MATCH (R:Report) RETURN COUNT(DISTINCT R)')
        .then(function (result) {
            console.log(result.records.length);
            res.header("Access-Control-Allow-Origin", "*");
            return res.status(200).json(result.records.length);
        })

});

app.get('/GetIndexSummaryStats', function (req, res) {
    // var report_name = req.body.reportName;
    // var schedule_name = req.body.scheduleName;
    // var reporting_line = req.body.reportingLine;
    var output = {};
    // res.header("Access-Control-Allow-Origin", "*");
    session1
        //   .run('match(n) return labels(n)[0] as Type,count(n)')
        .run('Match (s:Data_Source)-->(a:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) return count(distinct t.report) as Report_count, count (distinct rl.mdrm) as line_count, count(distinct a.data_attribute) as data_count, count(distinct s.Source) as source_count, count(distinct sc.schedule) as schedule_count, count(distinct br.id) as BusinessRequirement_count, count(distinct ba.BusinessElementName) as BusinessElement_count')
        .then(function (result) {
            result.records.forEach(function (record) {
                //output[record._fields[0]] = record._fields[1].low;
                output["ReportCount"] = record._fields[0];
                output["LineCount"] = record._fields[1];
                output["DataCount"] = record._fields[2];
                output["SourceCount"] = record._fields[3];
                output["ScheduleCount"] = record._fields[4];
                output["BusinessReqCount"] = record._fields[5];
                output["BusinessEleCount"] = record._fields[6];
                console.log(output);
            })
            res.send(output);
            console.log(output);
            return res.status(200).json(output);
        })

        .catch(function (err) {
            console.log(err);
        })
})

app.get('/GetHomeSummaryAnalytics', function (req, res) {
    var dict_name = ["ReportName", "ScheduleName", "MDRM", "ReportingLine", "GapCount", "BusinessElement"];
    var row_count = 0;
    var dict_li = {};
    var LINames = [];
    session1
        // .run('Match (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) return distinct t.report, sc.schedule, rl.mdrm, rl.reportingline, ba.Gap_Match_Cat, count(ba.Gap_Match_Cat), ba.BusinessElementName order by t.report, sc.schedule, rl.mdrm, rl.reportingline, ba.Gap_Match_Cat, count(ba.Gap_Match_Cat) , ba.BusinessElementName')
        .run('Match (s:Data_Source)--> (a:Data_Attributes)--> (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) Match (g:Gap_No)-[:Related_To]->(a) return distinct t.report, sc.schedule, rl.mdrm, rl.reportingline, sum( CASE WHEN g.Conf_Analysis = "Not Started" THEN 1 ELSE 0 END) as gap_count , ba.BusinessElementName order by t.report, sc.schedule, rl.mdrm, rl.reportingline, gap_count , ba.BusinessElementName')
        .then(function (result) {
            result.records.forEach(function (record) {
                for (var i = 0; i < record._fields.length; i++) {
                    if (typeof record._fields[i] == 'object') {
                        dict_li[dict_name[i]] = record._fields[i].low;
                    } else {
                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                LINames.push(dict_li);
                dict_li = {};
                console.log(LINames);
            })
            return res.json(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.get('/GetHomeSummaryGapAnalytics', function (req, res) {
    var dict_name = ["ReportName", "ScheduleName", "GapCount", "DataAttributeCount"];
    var row_count = 0;
    var dict_li = {};
    var LINames = [];
    session1
        // .run('Match (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) return distinct t.report, sc.schedule, rl.mdrm, rl.reportingline, ba.Gap_Match_Cat, count(ba.Gap_Match_Cat), ba.BusinessElementName order by t.report, sc.schedule, rl.mdrm, rl.reportingline, ba.Gap_Match_Cat, count(ba.Gap_Match_Cat) , ba.BusinessElementName')
        .run('Match (a:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) optional Match (g:Gap_No)-[:Related_To]->(a) return distinct t.report, sc.schedule, sum( CASE WHEN g.Conf_Analysis = "Not Started" THEN 1 ELSE 0 END) as gap_count , count( distinct a.data_attribute)')
        .then(function (result) {
            result.records.forEach(function (record) {
                for (var i = 0; i < record._fields.length; i++) {
                    if (typeof record._fields[i] == 'object') {
                        dict_li[dict_name[i]] = record._fields[i].low;
                    } else {
                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                LINames.push(dict_li);
                dict_li = {};
                console.log(LINames);
            })
            return res.json(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.get('/GetReportNames', function (req, res) {
    var ReportNames = [];
    var dict = {};
    res.header("Access-Control-Allow-Origin", "*");
    var row_count = 0;

    session4
        .run('Match (r:Report) where r.report IS NOT NULL return distinct r.report')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict = {
                    "rowID": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    // dict["rowID"] = record._fields[0];
                    // dict["id"] = record._fields[0];
                    dict["text"] = record._fields[0];
                    // dict["tag"] = record._fields[1];
                }
                row_count++;
                ReportNames.push(dict);
            })
            res.send(ReportNames);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetReportSectionNamesForReport', function (req, res) {
    var report_name = req.body.reportName;
    var LINames = [];
    var dict = {}
    var row_count = 0;
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'content-type');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    session2
        .run('match (s:Schedule)-->(r:Report) where r.report= "' + report_name + '" return distinct s.schedule')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict = {
                    "rowID": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    // dict["id"] = record._fields[0];
                    dict["text"] = record._fields[0];
                    // dict["tag"] = record._fields[1];
                }
                row_count++;
                LINames.push(dict);
                // LINames.push(record._fields[0]);
            })
            res.send(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetLineItemNamesForReportSection', function (req, res) {
    var report_name = req.body.reportName;
    var report_section_name = req.body.reportSectionName;
    var report_section_names = [];
    var row_count = 0;
    var dict = {}
    var LINames = []
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'content-type');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    session3
        .run('match (r:MDRM)-->(s:Schedule)-->(t:Report) where t.report= "' + report_name + '" AND s.schedule ="' + report_section_name + '" return distinct r.reportingline')
        .then(function (result) {
            result.records.forEach(function (record) {
                // report_section_names.push(record._fields[0]);
                dict = {
                    "rowID": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    dict["id"] = record._fields[0];
                    dict["text"] = record._fields[0];
                    // dict["tag"] = record._fields[1];
                }
                row_count++;
                LINames.push(dict);
                // LINames.push(record._fields[0]);
            })
            res.send(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetGapCategory', function (req, res) {
    var report_name = req.body.reportName;
    var report_schedule_name = req.body.reportSectionName;
    var reporting_line = req.body.lineItem;
    var row_count = 0;
    var dict = {}
    var LINames = []
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'content-type');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    session1
        .run('match (g:Gap_No)-->()-->(ba:Business_Attributes)-->(br:Business_Rule)-->(m:MDRM)-->(s:Schedule)-->(r:Report) where r.report= "' + report_name + '" AND s.schedule ="' + report_schedule_name + '" AND m.reportingline ="' + reporting_line + '" return distinct g.GapMatchCategory')
        .then(function (result) {
            result.records.forEach(function (record) {
                // report_section_names.push(record._fields[0]);
                dict = {
                    "rowID": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    dict["id"] = record._fields[0];
                    dict["text"] = record._fields[0];
                    // dict["tag"] = record._fields[1];
                }
                row_count++;
                LINames.push(dict);
                // LINames.push(record._fields[0]);
            })
            res.send(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetGap', function (req, res) {
    var report_name = req.body.reportName;
    var report_schedule_name = req.body.reportSectionName;
    var reporting_line = req.body.lineItem;
    var Gap_Category = req.body.gapCategory;
    var row_count = 0;
    var dict = {}
    var LINames = []
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'content-type');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    session3
        .run('match (g:Gap_No)-->()-->(ba:Business_Attributes)-->(br:Business_Rule)-->(m:MDRM)-->(s:Schedule)-->(r:Report) where r.report= "' + report_name + '" AND s.schedule ="' + report_schedule_name + '" AND m.reportingline ="' + reporting_line + '" AND g.GapMatchCategory = "' + Gap_Category + '" return distinct g.Gap_No')
        .then(function (result) {
            result.records.forEach(function (record) {
                // report_section_names.push(record._fields[0]);
                dict = {
                    "rowID": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    dict["id"] = record._fields[0];
                    dict["text"] = record._fields[0];
                    // dict["tag"] = record._fields[1];
                }
                row_count++;
                LINames.push(dict);
                // LINames.push(record._fields[0]);
            })
            res.send(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})

// Return list of all Functionalities
app.post('/GetReportCardInfo', function (req, res) {
    var report_name = req.body.reportName;
    var info = {};
    session2
        .run('MATCH  (r:MDRM)-->(s:Schedule)-->(t:Report) where t.report="' + report_name + '" return count(distinct s.schedule) as NumSections, count(distinct r.reportingline) as NumLineItems')
        .then(function (result) {
            result.records.forEach(function (record) {

                info["reportSections"] = record._fields[0].low;
                console.log(record._fieldLookup.NumSections);
                info["lineItems"] = record._fields[1].low;
            })
            return res.json(info);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetReportCardInfoFromReportAndSchedule', function (req, res) {
    var report_name = req.body.reportName;
    var schedule_name = req.body.scheduleName;
    var info = {};
    session2
        .run('MATCH  (r:MDRM)-->(s:Schedule)-->(t:Report) where t.report="' + report_name + '" return count(distinct s) as NumSections, count(distinct r.reportingline) as NumLineItems')
        .then(function (result) {
            result.records.forEach(function (record) {

                info["reportSections"] = record._fields[0].low;
                console.log(record._fieldLookup.NumSections);
                info["lineItems"] = record._fields[1].low;
            })
            return res.json(info);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetTableDetailsFromReportName', function (req, res) {
    var dict_name = ["ReportName", "ScheduleName", "ScheduleProduct", "ScheduleOwner", "MDRM", "ReportingLine", "ReportingInstruction", "AllowableValues", "FAQReference", "ID", "BussinessRequirements", "AdditionalRequirementInformation", "BusinessElementName", "BusinessElementDefination", "ConstructionLogic", "BusinessTranslation", "Status", "BusinessAttribute", "AxiomShorthandTransformationLogic", "data_attribute", "TableName", "Data_Provider_Name", "DataSourcingTransformation", "DataProviderInterpretation", "StandardizationLogic", "StandardStagingTable", "StandardStagingField", "DataAttributeDefination", "Gap_No", "Conf_Analysis", "Conf_Analysis_review", "GapMatchCategory", "Source"];
    var row_count = 0;
    var dict_li = {};
    var report_name = req.body.reportName;
    var LINames = [];
    session2
        .run('Match (s:Data_Source)--> (a:Data_Attributes)--> (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) Match (g:Gap_No)-[:Related_To]->(a)-->(st:Staging)-->(sm:StandardModel) where t.report="' + report_name + '" Return distinct t.report,sc.schedule,sc.ScheduleProduct,sc.ScheduleOwner,rl.mdrm,rl.reportingline,rl.repinst,rl.allowablevalues,rl.FAQReference,br.id,br.bus_requirements,br.addreq,ba.BusinessElementName,ba.BEDefinition,ba.ConsructionLogic,ba.Business_Translation,ba.Status,ba.BusinessAttribute,ba.AxiomShorthandTransformationLogic,a.data_attribute,a.Table_Name,a.Data_Provider_Name, a.DataSourcingTransformation, a.DataProviderInterpretation, sm.StandardizationLogic, st.StandardStagingTable, st.StandardStagingField, a.DataAttributeDefination, g.Gap_No,  g.Conf_Analysis, g.Conf_Analysis_review, g.GapMatchCategory, s.Source')
        .then(function (result) {
            // result.records.forEach(function (record) {
            //     dict_li = { "S.No": row_count };
            //     for (var i = 0; i < record._fields.length; i++) {
            //         if (Array.isArray(record._fields[i])) {
            //             dict_li[dict_name[i]] = record._fields[i][0];
            //         } else {
            //             dict_li[dict_name[i]] = record._fields[i];
            //         }
            //     }
            //     row_count = row_count + 1;
            //     LINames.push(dict_li);
            //     console.log(LINames);
            // })
            //return res.json(LINames);
            return res.json(result.records);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetTableDetailsFromReportAndSchedule', async function (req, res) {
    var dict_name = ["ReportName", "ScheduleName", "ScheduleProduct", "ScheduleOwner", "MDRM", "ReportingLine", "ReportingInstruction", "AllowableValues", "FAQReference", "ID", "BussinessRequirements", "AdditionalRequirementInformation", "BusinessElementName", "BusinessElementDefination", "ConstructionLogic", "BusinessTranslation", "Status", "BusinessAttribute", "AxiomShorthandTransformationLogic", "data_attribute", "TableName", "Data_Provider_Name", "DataSourcingTransformation", "DataProviderInterpretation", "StandardizationLogic", "StandardStagingTable", "StandardStagingField", "DataAttributeDefination", "Gap_No", "Conf_Analysis", "Conf_Analysis_review", "GapMatchCategory", "Source"];
    var row_count = 0;
    var dict_li = {};
    var report_name = req.body.reportName;
    var schedule_name = req.body.scheduleName;
    var LINames = [];
    session2
        .run('Match (s:Data_Source)--> (a:Data_Attributes)--> (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) Match (g:Gap_No)-[:Related_To]->(a)-->(st:Staging)-->(sm:StandardModel) where t.report="' + report_name + '" And sc.schedule = "' + schedule_name + '" Return distinct t.report,sc.schedule,sc.ScheduleProduct,sc.ScheduleOwner,rl.mdrm,rl.reportingline,rl.repinst,rl.allowablevalues,rl.FAQReference,br.id,br.bus_requirements,br.addreq,ba.BusinessElementName,ba.BEDefinition,ba.ConsructionLogic,ba.Business_Translation,ba.Status,ba.BusinessAttribute,ba.AxiomShorthandTransformationLogic,a.data_attribute,a.Table_Name,a.Data_Provider_Name, a.DataSourcingTransformation, a.DataProviderInterpretation, sm.StandardizationLogic, st.StandardStagingTable, st.StandardStagingField, a.DataAttributeDefination, g.Gap_No,  g.Conf_Analysis, g.Conf_Analysis_review, g.GapMatchCategory, s.Source')
        .then(function (result) {
            // result.records.forEach(function (record) {
            //     dict_li = { "S.No": row_count };
            //     for (var i = 0; i < record._fields.length; i++) {
            //         if (Array.isArray(record._fields[i])) {
            //             dict_li[dict_name[i]] = record._fields[i][0];
            //         } else {
            //             dict_li[dict_name[i]] = record._fields[i];
            //         }
            //     }
            //     row_count = row_count + 1;
            //     LINames.push(dict_li);
            //     console.log(LINames);
            // })
            // return res.json(LINames);
            return res.json(result.records);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetTableDetailsFromReportAndScheduleAndLineItem', function (req, res) {
    var dict_name = ["ReportName", "ScheduleName", "ScheduleProduct", "ScheduleOwner", "MDRM", "ReportingLine", "ReportingInstruction", "AllowableValues", "FAQReference", "ID", "BussinessRequirements", "AdditionalRequirementInformation", "BusinessElementName", "BusinessElementDefination", "ConstructionLogic", "BusinessTranslation", "Status", "BusinessAttribute", "AxiomShorthandTransformationLogic", "data_attribute", "TableName", "Data_Provider_Name", "DataSourcingTransformation", "DataProviderInterpretation", "StandardizationLogic", "StandardStagingTable", "StandardStagingField", "DataAttributeDefination", "Gap_No", "Conf_Analysis", "Conf_Analysis_review", "GapMatchCategory", "Source"];
    var row_count = 0;
    var dict_li = {};
    var report_name = req.body.reportName;
    var schedule_name = req.body.scheduleName;
    var reporting_line = req.body.lineItem;
    var LINames = [];
    session2
        .run('Match (s:Data_Source)--> (a:Data_Attributes)--> (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) Match (g:Gap_No)-[:Related_To]->(a)-->(st:Staging)-->(sm:StandardModel) where t.report="' + report_name + '" And sc.schedule = "' + schedule_name + '" And rl.reportingline = "' + reporting_line + '" Return distinct t.report,sc.schedule,sc.ScheduleProduct,sc.ScheduleOwner,rl.mdrm,rl.reportingline,rl.repinst,rl.allowablevalues,rl.FAQReference,br.id,br.bus_requirements,br.addreq,ba.BusinessElementName,ba.BEDefinition,ba.ConsructionLogic,ba.Business_Translation,ba.Status,ba.BusinessAttribute,ba.AxiomShorthandTransformationLogic,a.data_attribute,a.Table_Name,a.Data_Provider_Name, a.DataSourcingTransformation, a.DataProviderInterpretation, sm.StandardizationLogic, st.StandardStagingTable, st.StandardStagingField, a.DataAttributeDefination, g.Gap_No,  g.Conf_Analysis, g.Conf_Analysis_review, g.GapMatchCategory, s.Source')
        .then(function (result) {
            // result.records.forEach(function (record) {
            //     dict_li = { "S.No": row_count };
            //     for (var i = 0; i < record._fields.length; i++) {
            //         if (Array.isArray(record._fields[i])) {
            //             dict_li[dict_name[i]] = record._fields[i][0];
            //         } else {
            //             dict_li[dict_name[i]] = record._fields[i];
            //         }
            //     }
            //     row_count = row_count + 1;
            //     LINames.push(dict_li);
            //     console.log(LINames);
            // })
            return res.json(result.records);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.get('/GetTotalLineItems', function (req, res) {
    var count = 0;
    var dict = {}
    var result;
    session1
        .run('match (a:MDRM) return count(distinct a.reportingline)')
        .then(function (result) {
            dict = {
                "lineCount": result.records[0]._fields[0].low
            };
            return res.status(200).json(dict);
        })
});

app.post('/GetLineDescription', function (req, res) {
    var report_name = req.body.reportName;
    var schedule_name = req.body.scheduleName;
    var reporting_line = req.body.lineItem;
    var dict = {};
    session1
        .run('match (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) where t.report="' + report_name + '"  AND sc.schedule = "' + schedule_name + '" AND rl.reportingline = "' + reporting_line + '" Return distinct ba.BEDefinition')
        .then(function (result) {
            result.records.forEach(function (record) {
                console.log(record);
                for (var i = 0; i < record._fields.length; i++) {
                    dict = {
                        "lineDescription": record._fields[0]
                    };
                }
            })
            return res.status(200).json(dict);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetTileDetailsFromReportName', function (req, res) {
    var report_name = req.body.reportName;
    var info = {};
    session2
        .run('Match (s:Data_Source)-->(a:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) Match (a)-->(st:Staging)-->(sm:StandardModel)-->(ax:Axiom)  Where t.report="' + report_name + '" Return count (distinct s.Source), Count (Distinct ba.BusinessElementName), Count (Distinct a.data_attribute), count (distinct rl.reportingline), count (distinct br.id), count (distinct st.StandardStagingField), count(distinct sm.FactField), count (distinct ax.AxiomField)')
        .then(function (result) {
            console.log(result);
            result.records.forEach(function (record) {
                console.log(result);
                console.log(record);
                info["source"] = record._fields[0].low;
                info["businessElementName"] = record._fields[1].low;
                info["dataAttribute"] = record._fields[2].low;
                info["reportingLine"] = record._fields[3].low;
                info["crrid"] = record._fields[4].low;
                info["StandardStagingField"] = record._fields[5].low;
                info["FactField"] = record._fields[6].low;
                info["AxiomField"] = record._fields[7].low;
            })
            return res.json(info);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetTileDetailsFromReportAndSchedule', function (req, res) {
    var report_name = req.body.reportName;
    var schedule_name = req.body.scheduleName;
    var info = {};
    session2
        .run('Match (s:Data_Source)-->(a:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report)  Match (a)-->(st:Staging)-->(sm:StandardModel)-->(ax:Axiom) Where t.report="' + report_name + '" And sc.schedule = "' + schedule_name + '" Return count (distinct s.Source), Count (Distinct ba.BusinessElementName), Count (Distinct a.data_attribute), count (distinct rl.reportingline), count (distinct br.id), count (distinct st.StandardStagingField), count(distinct sm.FactField), count (distinct ax.AxiomField)')
        .then(function (result) {
            console.log(result);
            result.records.forEach(function (record) {
                console.log(result);
                console.log(record);
                info["source"] = record._fields[0].low;
                info["businessElementName"] = record._fields[1].low;
                info["dataAttribute"] = record._fields[2].low;
                info["reportingLine"] = record._fields[3].low;
                info["crrid"] = record._fields[4].low;
                info["StandardStagingField"] = record._fields[5].low;
                info["FactField"] = record._fields[6].low;
                info["AxiomField"] = record._fields[7].low;
            })
            return res.json(info);
        })
        .catch(function (err) {
            console.log(err);
        })
})


app.post('/GetTileDetailsFromReportAndScheduleAndLineItem', function (req, res) {
    var report_name = req.body.reportName;
    var schedule_name = req.body.scheduleName;
    var reporting_line = req.body.lineItem;
    var info = {};
    session2
        .run('Match (s:Data_Source)-->(a:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report)  Match (a)-->(st:Staging)-->(sm:StandardModel)-->(ax:Axiom)  Where t.report="' + report_name + '" And sc.schedule = "' + schedule_name + '" And rl.reportingline = "' + reporting_line + '" Return count (distinct s.Source), Count (Distinct ba.BusinessElementName), Count (Distinct a.data_attribute), count (distinct rl.reportingline), count (distinct br.id), count (distinct st.StandardStagingField), count(distinct sm.FactField), count (distinct ax.AxiomField)')
        .then(function (result) {
            console.log(result);
            result.records.forEach(function (record) {
                console.log(result);
                console.log(record);
                info["source"] = record._fields[0].low;
                info["businessElementName"] = record._fields[1].low;
                info["dataAttribute"] = record._fields[2].low;
                info["reportingLine"] = record._fields[3].low;
                info["crrid"] = record._fields[4].low;
                info["StandardStagingField"] = record._fields[5].low;
                info["FactField"] = record._fields[6].low;
                info["AxiomField"] = record._fields[7].low;
            })
            return res.json(info);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.get('/GetAttributeSummaryDropDown', function (req, res) {
    var count = 0;
    var dict = {}
    var AttributeNames = [];
    var row_count = 0;
    session3
        .run('match (a: Data_Attributes) return distinct a.data_attribute')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict = {
                    "rowID": row_count
                };
                console.log(record);
                for (var i = 0; i < record._fields.length; i++) {
                    dict["attributeName"] = record._fields[0];
                }
                row_count++;
                AttributeNames.push(dict);
            })
            return res.status(200).json(AttributeNames);
        })
});

app.post('/GetTileDetailsForAttributeSummary', function (req, res) {
    var attribute_name = req.body.attributeName;
    var info = {};
    session3
        .run('match (s:Data_Source)--> (a:Data_Attributes)--> (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) optional Match (g:Gap_No)-[:Related_To]->(a) where a.attribute= "' + attribute_name + '" return count(distinct t.report), count(distinct s.Source), count(distinct sc.schedule), count(distinct rl.reportingline), count(distinct br.id), count(distinct ba.BusinessElementName)')
        .then(function (result) {
            result.records.forEach(function (record) {
                info["report"] = record._fields[0].low;
                info["source"] = record._fields[1].low;
                info["schedule"] = record._fields[2].low;
                info["reportingLine"] = record._fields[3].low;
                info["crrid"] = record._fields[4].low;
                info["businessElementName"] = record._fields[5].low;
            })
            return res.json(info);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetDonutChartDetails', function (req, res) {
    var report_name = req.body.reportName;
    var info = {};
    var chartDetails = [];
    var row_count = 0;
    session3
        .run('Match (r:Report)<--(sc:Schedule)<--(rl:REPORTINGLINE)<--(a:Attribute) Where a.gapanalysiscategory <> "Not Applicable" AND r.report="' + report_name + '" Return r.report, sc.schedule,count (distinct a.gapanalysiscategory)')
        .then(function (result) {
            result.records.forEach(function (record) {
                info = {
                    "rowID": row_count
                };
                info["reportName"] = record._fields[0];
                info["scheduleName"] = record._fields[1];
                info["count"] = record._fields[2].low;
                row_count++;
                chartDetails.push(info);
            })
            return res.json(chartDetails);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetTableDetailsFromAttributeName', function (req, res) {
    var row_count = 0;
    var dict_li = {};
    var attribute_name = req.body.attributeName;
    var LINames = [];
    session3
        .run('Match (s:Data_Source)--> (da:Data_Attributes)--> (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(t:Report) Match(da:Data_Attributes)-->(st:Staging)-->(sm:StandardModel)-->(a:Axiom) where da.data_attribute = "' + attribute_name + '" Return distinct t.report, sc.schedule,rl.mdrm,rl.reportingline,rl.repinst,br.id,br.bus_requirements,rl.FAQReference,ba.BusinessElementName,ba.ConsructionLogic,sc.ScheduleProduct,da.data_attribute,sc.ScheduleOwner,rl.allowablevalues,br.addreq,ba.BEDefinition,ba.Business_Translation,ba.Status, sm.StandardizationLogic,ba.BusinessAttribute,da.Table_Name,a.AxiomShorthandTransformationLogic,da.DataSourcingTransformation, da.DataProviderInterpretation, st.StandardStagingTable, st.StandardStagingField,da.DataAttributeDefination,s.Source')
        .then(function (result) {
            // result.records.forEach(function (record) {
            //     dict_li = { "S.No": row_count };
            //     for (var i = 0; i < record._fields.length; i++) {
            //         if (Array.isArray(record._fields[i])) {
            //             dict_li[dict_name[i]] = record._fields[i][0];
            //         } else {
            //             dict_li[dict_name[i]] = record._fields[i];
            //         }
            //     }
            //     row_count = row_count + 1;
            //     LINames.push(dict_li);
            //     console.log(LINames);
            // })
            // return res.json(LINames);
            return res.json(result.records);
        })
        .catch(function (err) {
            console.log(err);
        })
})



// app.post('/GetGraphValuesForReportAnalyticspage', function(req, res) {
//     var nodes = [];
//     var edges = [];
//     var nodevalues =[];
//     var edgevalues =[];
//     var node ={};
//     var edge=[];
//     var data={};
//     var edgedata={};
//     var graph={};
//     var report_name = req.body.reportName;
//     var schedule_name = req.body.scheduleName;
//     var reporting_line = req.body.lineItem;
//     session1
//         .run('Match p = (r:Report)<--(sc:Schedule)<--(rl)-[:CONSISTS_OF|:MOVES_TO|:CONTAINS_FAQ]-(x)-[:CONSISTS_OF*0..1]-(y) Where r.report="'+report_name+'" AND sc.schedule="'+schedule_name+'" and rl.reportingline="'+reporting_line+'" return nodes(p) as nodes, relationships(p) as relationships')
//         .then(function(result) {
//             console.log(JSON.stringify(result));

//               result.records.forEach(function(record) {
//                 nodevalues =record._fields[0];
//                    node['nodes'] = nodevalues;
//                    edgevalues=record._fields[1];
//                    node['edges'] = edgevalues;
//                    nodes.push(node); 
//                    node={};  
//          })
//        graph["nodes"]=nodes;
//       //  graph["edges"]= edge;
//       return res.json(graph);FF
//        //return res.json(result); 
//     })
// })

app.post('/GetGraphValuesForReportAnalyticspage', function (req, res) {
    var nodes = [];
    var edges = [];
    var nodevalues = [];
    var edgevalues = [];
    var node = {};
    var edge = {};
    var data = {};
    var edgedata = {};
    var graph = {};
    var report_name = req.body.reportName;
    var schedule_name = req.body.scheduleName;
    var reporting_line = req.body.lineItem;
    session4
        .run('match p = ()-[:CONSISTS_OF|Related_To*..3]-(a:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(r:Report) Where r.report="' + report_name + '" AND sc.schedule="' + schedule_name + '" and rl.reportingline="' + reporting_line + '"  return nodes(p) as nodes, relationships(p) as relationships')
        .then(function (result) {
            //  console.log(JSON.stringify(result));
            //  return res.json(result);
            result.records.forEach(function (record) {
                nodevalues = record._fields[0];
                //  console.log("-------------------------------------");
                //  console.log("Node Value "+nodevalues);

                //  console.log("-------------------------------------");
                //  console.log("Edge Value "+record._fields[1]);
                for (var i = 0; i < nodevalues.length; i++) {
                    node["id"] = nodevalues[i].identity.low;
                    data = nodevalues[i].properties;
                    data["labels"] = nodevalues[i].labels[0];
                    node["data"] = data;
                    data = {};
                    nodes.push(node);
                    node = {};
                }
                edgevalues = record._fields[1];
                for (var i = 0; i < edgevalues.length; i++) {
                    edge["source"] = edgevalues[i].start.low;
                    edge["target"] = edgevalues[i].end.low;
                    edgedata["type"] = edgevalues[i].type;
                    edge["data"] = edgedata;
                    edgedata = {};
                    edges.push(edge);
                    edge = {};
                }
                //   console.log(edges); 
            })

            // Display the unique objects 

            var distinctValues = {};
            for (var i = 0; i < edges.length; i++) {
                if (distinctValues.hasOwnProperty(edges[i].source + "" + edges[i].target)) {
                    //already has it
                    edges.splice(i, 1);
                    i--;
                } else {
                    distinctValues[edges[i].source + "" + edges[i].target] = true;
                }
            }
            console.log(" Unique Array " + JSON.stringify(distinctValues));

            graph["nodes"] = nodes;
            graph["edges"] = edges;
            return res.json(graph);

            return res.json(result)
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetGraphValuesForAttributeSummarypage', function (req, res) {
    var nodes = [];
    var edges = [];
    var nodevalues = [];
    var edgevalues = [];
    var node = {};
    var edge = {};
    var data = {};
    var edgedata = {};
    var graph = {};
    // var report_name = req.body.reportName;
    // var schedule_name = req.body.scheduleName;
    var attribute_name = req.body.attributeName;
    session4
        .run('match p = ()-[:CONSISTS_OF|Related_To*..3]-(a:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(r:Report) where a.data_attribute = "' + attribute_name + '" return nodes(p) as nodes, relationships(p) as relationships')
        .then(function (result) {
            //  console.log(JSON.stringify(result));
            //  return res.json(result);
            result.records.forEach(function (record) {
                nodevalues = record._fields[0];
                //  console.log("-------------------------------------");
                //  console.log("Node Value "+nodevalues);

                //  console.log("-------------------------------------");
                //  console.log("Edge Value "+record._fields[1]);
                for (var i = 0; i < nodevalues.length; i++) {
                    node["id"] = nodevalues[i].identity.low;
                    data = nodevalues[i].properties;
                    data["labels"] = nodevalues[i].labels[0];
                    node["data"] = data;
                    data = {};
                    nodes.push(node);
                    node = {};
                }
                edgevalues = record._fields[1];
                for (var i = 0; i < edgevalues.length; i++) {
                    edge["source"] = edgevalues[i].start.low;
                    edge["target"] = edgevalues[i].end.low;
                    edgedata["type"] = edgevalues[i].type;
                    edge["data"] = edgedata;
                    edgedata = {};
                    edges.push(edge);
                    edge = {};
                }
                //   console.log(edges); 
            })

            // Display the unique objects 

            var distinctValues = {};
            for (var i = 0; i < edges.length; i++) {
                if (distinctValues.hasOwnProperty(edges[i].source + "" + edges[i].target)) {
                    //already has it
                    edges.splice(i, 1);
                    i--;
                } else {
                    distinctValues[edges[i].source + "" + edges[i].target] = true;
                }
            }
            console.log(" Unique Array " + JSON.stringify(distinctValues));

            graph["nodes"] = nodes;
            graph["edges"] = edges;
            return res.json(graph);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetMasterSearchList', function (req, res) {
    var search = req.body.q;
    var MasterSearchData = [];
    var dict = {};
    var row_count = 0;
    var ReportNames = [];
    session1
        .run('match (r:Report) where toLower(r.report) contains toLower("' + search + '") return distinct r.report')
        .then(function (result) {
            console.log(JSON.stringify(result));
            result.records.forEach(function (record) {
                dict = {
                    "rowID": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {

                    dict["id"] = record._fields[i];
                    dict["text"] = record._fields[i];
                    dict["tag"] = "Report";
                    dict["href"] = "report_analytics.html";
                }
                row_count++;
                MasterSearchData.push(dict);
                ReportNames.push(record._fields[0]);
            })
        })
        .catch(function (err) {
            console.log(err);
        })
    var Schedule = [];
    session2
        .run('match (s:Schedule)-->(r) where toLower(s.schedule) contains toLower("' + search + '") return distinct s.schedule, r.report')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict = {
                    "rowID": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    dict["id"] = record._fields[0];
                    dict["text"] = record._fields[0];
                    dict["tag"] = "Report Section";
                    dict["sub_tag_report"] = record._fields[1];
                    dict["href"] = "report_analytics.html";
                }
                row_count++;
                MasterSearchData.push(dict);
                Schedule.push(record._fields[0]);
            })

        })
        .catch(function (err) {
            console.log(err);
        })
    var ReportingLine = [];
    session3
        .run('match (rl:REPORTINGLINE)-->(sc:Schedule)-->(r:Report) where toLower(rl.reportingline) contains toLower("' + search + '") return distinct (rl.reportingline), sc.schedule, r.report')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict = {
                    "rowID": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    dict["id"] = record._fields[0];
                    dict["text"] = record._fields[0];
                    dict["tag"] = "Line Item";
                    dict["sub_tag_report"] = record._fields[1];
                    dict["sub_tag_report_section"] = record._fields[2];
                    dict["href"] = "report_analytics.html";
                }
                row_count++;
                MasterSearchData.push(dict);
                ReportingLine.push(record._fields[0]);
            })
        })
        .catch(function (err) {
            console.log(err);
        })
    var Attribute = [];
    session4
        .run('match (a:Attribute)-->(:REPORTINGLINE) where toLower(a.attribute) contains toLower("' + search + '")return distinct(a.attribute)')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict = {
                    "rowID": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    dict["id"] = record._fields[i];
                    dict["text"] = record._fields[i];
                    dict["tag"] = "Application";
                    dict["href"] = "application_360.html";
                }
                row_count++;
                MasterSearchData.push(dict);
                Attribute.push(record._fields[0]);
            })
            return res.json(MasterSearchData);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetGapView', function (req, res) {
    var report_name = req.body.reportName;
    var report_schedule_name = req.body.reportSectionName;
    var reporting_line = req.body.lineItem;
    var Gap_Category = req.body.gapCategory;
    var Gap_No = req.body.gap;
    var info = {};
    session3
        .run('match (g:Gap_No)-->()-->()-->()-->(r:MDRM)-->(s:Schedule)-->(t:Report) where t.report= "' + report_name + '" AND s.schedule = "' + report_schedule_name + '" AND r.reportingline ="' + reporting_line + '" AND g.GapMatchCategory = "' + Gap_Category + '" AND g.Gap_No= "' + Gap_No + '" return distinct g.Conf_Analysis,g.Conf_Analysis_review,g.GapMatchCategory,g.Gap_No')
        .then(function (result) {
            console.log(result);
            result.records.forEach(function (record) {
                console.log(result);
                console.log(record);
                info["Conf_Analysis"] = record._fields[0];
                info["Conf_Analysis_review"] = record._fields[1];
                info["GapMatchCategory"] = record._fields[2];
                info["Gap_No"] = record._fields[3];
                // info["GapSubCategory"] = record._fields[4];
                // info["GapDescription"] = record._fields[5];
                // info["ApplicableAttributes"] = record._fields[6];
                // info["IssueSeverity"] = record._fields[7];
                // info["ScopeOfRemediation"] = record._fields[8];
                // info["RemediationStatus"] = record._fields[9];
                // info["RemediationDate"] = record._fields[10];
                // info["ModifiedBy"] = record._fields[11];
                // info["ConformanceReviewStatus"] = record._fields[12];
            })
            return res.json(info);

        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/updateGapView', function (req, res) {
    var Gap_No = req.body.Gap_No;
    var Conf_Analysis = req.body.Conf_Analysis;
    var Conf_Analysis_review = req.body.Conf_Analysis_review;
    var GapMatchCategory = req.body.GapMatchCategory;
    var d = new Date();
    var datetime = d.toJSON().slice(0, 19).replace('T', ':');
    const dataGaps = require("./datagap.json");
    console.log("dataGaps :" + JSON.stringify(dataGaps));

    let dataGap = {
        Gap_No: req.body.Gap_No,
        Conf_Analysis: req.body.Conf_Analysis,
        Conf_Analysis_review: req.body.Conf_Analysis_review,
        GapMatchCategory: req.body.GapMatchCategory,
        modifiedon: datetime
    };
    dataGaps.push(dataGap);

    fs.writeFile("datagap.json", JSON.stringify(dataGaps), err => {

        // Checking for errors 
        if (err) throwerr;
        console.log("Done writing"); // Success 
    });

    session3
        .run('match (g:Gap_No) where g.Gap_No= "' + Gap_No + '" set g.Conf_Analysis= "' + Conf_Analysis + '", g.Conf_Analysis_review= "' + Conf_Analysis_review + '", g.GapMatchCategory= "' + GapMatchCategory + '"')
        .then(function (result) {
            console.log("update table" + result);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetUpdateDataGapHistory', function (req, res) {

    const dataGaps = require("./datagap.json");
    return res.json(dataGaps);

})


app.get('/GetDataGapTable', function (req, res) {
    var dict_name = ["GapNo", "Conf_Analysis", "Conf_Analysis_review", "GapMatchCategory"];
    var row_count = 0;
    var dict_li = {};
    var LINames = [];
    session4
        .run('Match (g:Gap_No) return distinct g.Gap_No,g.Conf_Analysis,g.Conf_Analysis_review,g.GapMatchCategory')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict_li = {
                    "S.No": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    if (Array.isArray(record._fields[i])) {
                        dict_li[dict_name[i]] = record._fields[i][0];
                    } else {
                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                row_count = row_count + 1;
                LINames.push(dict_li);
                console.log(LINames);
            })
            return res.json(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetReportGapTable', function (req, res) {
    var dict_name = ["Report", "Schedule", "MDRM", "GapNo", "ConfAnalysis", "ConfAnalysisreview", "GapMatchCategory"];
    var row_count = 0;
    var dict_li = {};
    var report_name = req.body.report_name;
    var LINames = [];
    session4
        .run('Match  (g:Gap_No)-->()-->()-->()-->(r:MDRM)-->(s:Schedule)-->(t:Report) where t.report="' + report_name + '" return distinct t.report, s.schedule, r.mdrm, g.Gap_No, g.Conf_Analysis, g.Conf_Analysis_review, g.GapMatchCategory')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict_li = {
                    "S.No": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    if (Array.isArray(record._fields[i])) {
                        dict_li[dict_name[i]] = record._fields[i][0];
                    } else {
                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                row_count = row_count + 1;
                LINames.push(dict_li);
                console.log(LINames);
            })
            return res.json(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/GetScheduleGapTable', function (req, res) {
    var dict_name = ["Report", "Schedule", "MDRM", "GapNo", "ConfAnalysis", "ConfAnalysisreview", "GapMatchCategory"];
    var row_count = 0;
    var dict_li = {};
    var report_name = req.body.report_name;
    var schedule_name = req.body.schedule_name
    var LINames = [];
    session4
        .run('Match  (g:Gap_No)-->()-->()-->()-->(r:MDRM)-->(s:Schedule)-->(t:Report) where t.report="' + report_name + '" AND s.schedule="' + schedule_name + '" return distinct t.report, s.schedule, r.mdrm, g.Gap_No, g.Conf_Analysis, g.Conf_Analysis_review, g.GapMatchCategory')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict_li = {
                    "S.No": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    if (Array.isArray(record._fields[i])) {
                        dict_li[dict_name[i]] = record._fields[i][0];
                    } else {
                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                row_count = row_count + 1;
                LINames.push(dict_li);
                console.log(LINames);
            })
            return res.json(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})



app.post('/GetReportingLineGapTable', function (req, res) {
    var dict_name = ["Report", "Schedule", "MDRM", "GapNo", "ConfAnalysis", "ConfAnalysisreview", "GapMatchCategory"];
    var row_count = 0;
    var dict_li = {};
    var report_name = req.body.report_name;
    var schedule_name = req.body.schedule_name;
    var reporting_line = req.body.reporting_line;
    var LINames = [];
    session4
        .run('Match  (g:Gap_No)-->()-->()-->()-->(r:MDRM)-->(s:Schedule)-->(t:Report) where t.report="' + report_name + '" AND s.schedule="' + schedule_name + '" and r.reportingline="' + reporting_line + '" return distinct t.report, s.schedule, r.mdrm, g.Gap_No, g.Conf_Analysis, g.Conf_Analysis_review, g.GapMatchCategory')
        .then(function (result) {
            // result.records.forEach(function (record) {
            //     dict_li = { "S.No": row_count };
            //     for (var i = 0; i < record._fields.length; i++) {
            //         if (Array.isArray(record._fields[i])) {
            //             dict_li[dict_name[i]] = record._fields[i][0];
            //         } else {
            //             dict_li[dict_name[i]] = record._fields[i];
            //         }
            //     }
            //     row_count = row_count + 1;
            //     LINames.push(dict_li);
            //     console.log(LINames);
            // })
            // return res.json(LINames);
            return res.json(result.records);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.get('/GetBussinessRuleTable', function (req, res) {
    var dict_name = ["Report", "Schedule", "RuleCount", "CountCompleted"];
    var row_count = 0;
    var dict_li = {};
    var LINames = [];
    session4
        .run('Match (g:Gap_No)-->()-->(ba:Business_Attributes)-->(br:Business_Rule)-->(m:MDRM)-->(s:Schedule)-->(r:Report) return distinct r.report, s.schedule, count(distinct ba.ConsructionLogic) as rules_count,  sum( CASE WHEN g.Conf_Analysis_review = "Approved" THEN 1 ELSE 0 END) as count_complete')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict_li = {
                    "S.No": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    if (Array.isArray(record._fields[i])) {
                        dict_li[dict_name[i]] = record._fields[i][0];
                    } else {
                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                row_count = row_count + 1;
                LINames.push(dict_li);
                console.log(LINames);
            })
            return res.json(LINames);
        })
        .catch(function (err) {
            console.log(err);
        })
})



app.get('/GetTotalGap', function (req, res) {
    var dict_name = ["TotalGapsClosed"];
    var row_count = 0;
    var dict_li = {};
    var gap = [];
    session4
        .run('Match (da:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(m:MDRM)-->(s:Schedule)-->(r:Report)return sum(CASE WHEN ba.Status= "Closed" THEN 1 ELSE 0 END) as Total_Gaps_Closed')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict_li = {
                    "S.No": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    if (Array.isArray(record._fields[i])) {
                        dict_li[dict_name[i]] = record._fields[i][0];
                    } else {
                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                row_count = row_count + 1;
                gap.push(dict_li);
            })
            return res.json(gap);
        })
        .catch(function (err) {
            console.log(err);
        })
})


app.get('/GetRemediationStatus', function (req, res) {
    var dict_name = ["RemediationStatus", "TotalGapsOpen", "TotalGapsClosed"];
    var row_count = 0;
    var dict_li = {};
    var status = [];
    session1
        .run('Match (g:Gap_No)<--(ba:Business_Attributes)-->(br:Business_Rule)-->(m:MDRM)-->(s:Schedule)-->(r:Report) Match (ba)<--(da:Data_Attributes) return distinct g.Remediation_Status, sum( CASE WHEN da.Gap_Match_Status= "Open" THEN 1 ELSE 0 END) as Total_Gaps_Open, sum( CASE WHEN da.Gap_Match_Status= "Closed" THEN 1 ELSE 0 END) as Total_Gaps_Closed')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict_li = {
                    "S.No": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    if (Array.isArray(record._fields[i])) {
                        dict_li[dict_name[i]] = record._fields[i][0];
                    } else {
                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                row_count = row_count + 1;
                status.push(dict_li);
            })
            return res.json(status);
        })
        .catch(function (err) {
            console.log(err);
        })
})
app.post('/GetGraphValuesDataGap', function (req, res) {
    var nodes = [];
    var edges = [];
    var nodevalues = [];
    var edgevalues = [];
    var node = {};
    var edge = {};
    var data = {};
    var edgedata = {};
    var graph = {};
    var report_name = req.body.reportName;
    var schedule_name = req.body.scheduleName;
    var reporting_line = req.body.reportingLine;
    session4
        .run('match p = ()-[:CONSISTS_OF|Related_To*..3]-(a:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule)-->(r:Report) Where r.report="' + report_name + '" AND sc.schedule="' + schedule_name + '" and rl.reportingline="' + reporting_line + '"  return nodes(p) as nodes, relationships(p) as relationships')
        .then(function (result) {
            //  console.log(JSON.stringify(result));
            //  return res.json(result);
            result.records.forEach(function (record) {
                nodevalues = record._fields[0];
                //  console.log("-------------------------------------");
                //  console.log("Node Value "+nodevalues);

                //  console.log("-------------------------------------");
                //  console.log("Edge Value "+record._fields[1]);
                for (var i = 0; i < nodevalues.length; i++) {
                    node["id"] = nodevalues[i].identity.low;
                    data = nodevalues[i].properties;
                    data["labels"] = nodevalues[i].labels[0];
                    node["data"] = data;
                    data = {};
                    nodes.push(node);
                    node = {};
                }
                edgevalues = record._fields[1];
                for (var i = 0; i < edgevalues.length; i++) {
                    edge["source"] = edgevalues[i].start.low;
                    edge["target"] = edgevalues[i].end.low;
                    edgedata["type"] = edgevalues[i].type;
                    edge["data"] = edgedata;
                    edgedata = {};
                    edges.push(edge);
                    edge = {};
                }
                //   console.log(edges); 
            })

            // Display the unique objects 

            var distinctValues = {};
            for (var i = 0; i < edges.length; i++) {
                if (distinctValues.hasOwnProperty(edges[i].source + "" + edges[i].target)) {
                    //already has it
                    edges.splice(i, 1);
                    i--;
                } else {
                    distinctValues[edges[i].source + "" + edges[i].target] = true;
                }
            }
            console.log(" Unique Array " + JSON.stringify(distinctValues));

            graph["nodes"] = nodes;
            graph["edges"] = edges;
            return res.json(graph);

            return res.json(result)
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.post('/CheckCredential', function (req, res) {
    var user_name = req.body.userName;
    var password = req.body.password;
    var dict = {};
    var userResult = [];
    session1
        .run('match (n:User) with collect(n.email) as x, collect(n.password) as y Return (case when "' + user_name + '" in x and "' + password + '" in y then True ELSE FALSE END) as rule')
        .then(function (result) {
            result.records.forEach(function (record) {
                console.log(record);
                for (var i = 0; i < record._fields.length; i++) {
                    dict["value"] = record._fields[0];
                }
                userResult.push(dict);
            })
            return res.status(200).json(userResult);
        })
});
app.get('/GetOutstandingBalance', function (req, res) {
    var balanceResult = [];
    var info = {};
    session1
        .run('match (m:MDRM) with collect(m.mdrm) as mdrms unwind mdrms as n with n match (m:MDRM)<--(a:Attribute) where m.mdrm= n  with n, count(DISTINCT a.attribute_name) as count_of_attribute match (s:Schedule)<--(m:MDRM)<--(a)<--()<--(r:LedgerAccount) where m.mdrm= n with m.mdrm as mdrm, r.Ledger_Account_ID as Ledger_Account_ID, r.Book_Balance as balance, count(DISTINCT a.attribute_name) as count_of_attribute_per_Ledger_Account_ID,count_of_attribute as limit_value, s.schedule as Schedule where count_of_attribute_per_Ledger_Account_ID = limit_value return mdrm,  Sum (balance), Schedule')
        .then(function (result) {
            console.log(result);

            result.records.forEach(function (record) {
                //  dict = { "rowID": row_count };
                console.log(record);
                for (var i = 0; i < record._fields.length; i++) {
                    info["mdrm"] = record._fields[0];
                    info["sum"] = record._fields[1].low;
                    info["Balance"] = record._fields[2];
                }
                balanceResult.push(info);
                info = {};
            })

            return res.json(balanceResult);
        })
        .catch(function (err) {
            console.log(err);
        })
})

app.get('/HistoryMetrics', function (req, res) {
    var output = {};
    sql.connect(config, function (err, results) {
        if (err) console.log(err);

        //Report cnt
        let sqlRequest = new sql.Request();
        let sqlQuery = "select count(distinct(REPORT)) as reportcnt from RR_AUDIT_TABLE_TEST where CHANGETYPE != 'Initial Load';select (count(distinct(REPORT)) * 100 /(select count(distinct(REPORT)) as recPer from dbo.RR_AUDIT_TABLE_TEST)) as recPer from dbo.RR_AUDIT_TABLE_TEST  where CHANGETYPE != 'Initial Load';select count(distinct(SCHEDULENAME)) as scheduleCnt from dbo.RR_AUDIT_TABLE_TEST where CHANGETYPE != 'Initial Load';select (count(distinct(SCHEDULENAME))*100/(select count(distinct(SCHEDULENAME))  from dbo.RR_AUDIT_TABLE_TEST)) as schedulePer from dbo.RR_AUDIT_TABLE_TEST where CHANGETYPE != 'Initial Load';select count(distinct(MDRM)) as mdrmCnt from dbo.RR_AUDIT_TABLE_TEST where CHANGETYPE != 'Initial Load';select (count(distinct(MDRM))*100/(select count(distinct(MDRM)) from dbo.RR_AUDIT_TABLE_TEST)) as mdrmPer from dbo.RR_AUDIT_TABLE_TEST where CHANGETYPE != 'Initial Load';";
        sqlRequest.query(sqlQuery, function (err, data) {

            console.log(data.recordsets[0]);
            data.recordsets[0].forEach(function (record) {

                output["ReportCnt"] = record.reportcnt;
            })

            data.recordsets[1].forEach(function (record) {
                output["ReportPer"] = record.recPer;
            })

            data.recordsets[2].forEach(function (record) {
                output["ScheduleCnt"] = record.scheduleCnt;
            })
            data.recordsets[3].forEach(function (record) {
                output["SchedulePer"] = record.schedulePer;
            })
            data.recordsets[4].forEach(function (record) {
                output["MdrmCnt"] = record.mdrmCnt;
            })
            data.recordsets[5].forEach(function (record) {
                output["MdrmPer"] = record.mdrmPer;
            })

            console.log(output);
            // })
            res.send(output)
            sql.close();
        })
    });

});


app.get('/HistoryChangeType', function (req, res) {

    sql.connect(config, function (err, results) {
        if (err) console.log(err);

        //Report cnt
        let sqlRequest = new sql.Request();
        let sqlQuery = "select CHANGETYPE, count(distinct(MDRM)) as cnt from dbo.RR_AUDIT_TABLE_TEST where CHANGETYPE != 'Initial Load' GROUP BY CHANGETYPE;";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            res.send(data.recordset);
            sql.close();
        })
    });

});

app.get('/HistoryProductAlignment', function (req, res) {

    sql.connect(config, function (err, results) {
        if (err) console.log(err);

        //Report cnt
        let sqlRequest = new sql.Request();
        let sqlQuery = "select ScheduleProduct, count(distinct(MDRM)) as cnt from dbo.RR_AUDIT_TABLE_TEST where CHANGETYPE != 'Initial Load' GROUP BY ScheduleProduct;";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            res.send(data.recordset);
            sql.close();
        })
    });

});


app.get('/HistoryChangeRank', function (req, res) {

    sql.connect(config, function (err, results) {
        if (err) console.log(err);

        //Report cnt
        let sqlRequest = new sql.Request();
        let sqlQuery = "select CHANGERANK, count(distinct(MDRM))  as cnt from dbo.RR_AUDIT_TABLE_TEST where CHANGETYPE != 'Initial Load' GROUP BY CHANGERANK;";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            res.send(data.recordset);
            sql.close();
        })
    });

});
app.get('/HistoryReportDropdown', function (req, res) {
    sql.connect(config, function (err, results) {
        if (err) console.log(err);
        let sqlRequest = new sql.Request();
        let sqlQuery = "Select distinct(REPORT) from dbo.RR_AUDIT_TABLE_TEST";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            res.send(data.recordset);
            sql.close();
        })
    });

});

app.post('/HistoryScheduleDropdown', function (req, res) {
    var reportName = req.body.reportName;
    sql.connect(config, function (err, results) {
        if (err) console.log(err);
        let sqlRequest = new sql.Request();
        let sqlQuery = "Select distinct(SCHEDULE_NAME) from dbo.RR_AUDIT_TABLE_TEST where REPORT = '" + reportName + "'";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            res.send(data.recordset);
            sql.close();
        })
    });

});

app.post('/HistoryLineItemDropdown', function (req, res) {
    var reportName = req.body.reportName;
    var scheduleName = req.body.scheduleName;
    sql.connect(config, function (err, results) {
        if (err) console.log(err);
        let sqlRequest = new sql.Request();
        let sqlQuery = "Select distinct(REPORTING_LINE) from dbo.RR_AUDIT_TABLE_TEST where REPORT = '" + reportName + "' and SCHEDULE_NAME = '" + scheduleName + "'";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            res.send(data.recordset);
            sql.close();
        })
    });

});


app.post('/HistoryReportTable', function (req, res) {
    var reportName = req.body.reportName;
    sql.connect(config, function (err, results) {
        if (err) console.log(err);
        let sqlRequest = new sql.Request();
        let sqlQuery = "SELECT Report,ScheduleName ,MDRM,ReportingLine,ReportingInstructions,ID,BusinessRequirements,FAQReference,BusinessElementName,RequirementConstructionLogic,ScheduleProduct,DataAttribute,ProvisioningSystem ,ScheduleOwner,ChangeType,LastUpdateDT,RecordStartDate,RecordEndDate,Changerank,AllowableValues,AdditionalRequirementInformation,BusinessElementDefination,BusinessTranslation,Status,StandardizationLogic,BusinessAttribute,TableName,AxiomShorthandTransformationLogic,DataSourcingTransformation,DataProviderInterpretation,StandardStagingTable,StandardStagingField,DataAttributeDefination FROM RR_AUDIT_TABLE_TEST where Report = '" + reportName + "'";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            res.send(data);
            sql.close();
        })
    });

});

app.post('/HistoryScheduleTable', function (req, res) {
    var reportName = req.body.reportName;
    var scheduleName = req.body.scheduleName;
    sql.connect(config, function (err, results) {
        if (err) console.log(err);
        let sqlRequest = new sql.Request();
        let sqlQuery = "SELECT Report,ScheduleName ,MDRM,ReportingLine,ReportingInstructions,ID,BusinessRequirements,FAQReference,BusinessElementName,RequirementConstructionLogic,ScheduleProduct,DataAttribute,ProvisioningSystem ,ScheduleOwner,ChangeType,LastUpdateDT,RecordStartDate,RecordEndDate,Changerank,AllowableValues,AdditionalRequirementInformation,BusinessElementDefination,BusinessTranslation,Status,StandardizationLogic,BusinessAttribute,TableName,AxiomShorthandTransformationLogic,DataSourcingTransformation,DataProviderInterpretation,StandardStagingTable,StandardStagingField,DataAttributeDefination  FROM RR_AUDIT_TABLE_TEST where Report = '" + reportName + "' and ScheduleName = '" + scheduleName + "'";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            res.send(data);
            sql.close();
        })
    });

});

app.post('/HistoryLineItemTable', function (req, res) {
    var reportName = req.body.reportName;
    var scheduleName = req.body.scheduleName;
    var lineItem = req.body.lineItem;
    sql.connect(config, function (err, results) {
        if (err) console.log(err);
        let sqlRequest = new sql.Request();
        let sqlQuery = "SELECT Report,ScheduleName ,MDRM,ReportingLine,ReportingInstructions,ID,BusinessRequirements,FAQReference,BusinessElementName,RequirementConstructionLogic,ScheduleProduct,DataAttribute,ProvisioningSystem ,ScheduleOwner,ChangeType,LastUpdateDT,RecordStartDate,RecordEndDate,Changerank,AllowableValues,AdditionalRequirementInformation,BusinessElementDefination,BusinessTranslation,Status,StandardizationLogic,BusinessAttribute,TableName,AxiomShorthandTransformationLogic,DataSourcingTransformation,DataProviderInterpretation,StandardStagingTable,StandardStagingField,DataAttributeDefination  FROM RR_AUDIT_TABLE_TEST where Report = '" + reportName + "' and ScheduleName = '" + scheduleName + "' and ReportingLine = '" + lineItem + "'";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            res.send(data);
            sql.close();
        })
    });

});

app.post('/updateAttributeSumDataAtt', function (req, res) {

    // var Old_Value = req.body.oldValue;
    // var New_Value = req.body.newValue;
    var oldData = req.body.oldData;
    var newData = req.body.newData;

    console.log(oldData);
    console.log(newData);

    console.log("Inside API");


    sql.connect(config, function (err, results) {
        if (err) console.log(err);
        let sqlRequest = new sql.Request();
        let sqlQuery = "Update dbo.RR_AUDIT_TABLE_TEST SET RecordEndDate = GETDATE() , LastUpdateDT = GETDATE() where RecordEndDate = '1900-01-02 00:00:00.000' and MDRM ='" + oldData[4] + "' and ID = '" + oldData[9] + "';INSERT INTO dbo.RR_AUDIT_TABLE_TEST  VALUES (next value FOR [dbo].[RR_SEQ],'" + newData[0] + "','" + newData[1] + "','" + newData[2] + "','" + newData[3] + "','" + newData[4] + "','" + newData[5] + "','" + newData[6] + "','" + newData[7] + "','" + newData[8] + "','" + newData[9] + "','" + newData[10] + "','" + newData[11] + "','" + newData[27] + "','" + newData[12] + "','sourcing Change',GETDATE(),GETDATE(),GETDATE(),'M','" + newData[13] + "','" + newData[14] + "','" + newData[15] + "','" + newData[16] + "','" + newData[17] + "','" + newData[18] + "','" + newData[19] + "','" + newData[20] + "','" + newData[21] + "','" + newData[22] + "','" + newData[23] + "','" + newData[24] + "','" + newData[25] + "','" + newData[26] + "')";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            console.log(data)
            sql.close();
        })
    });
    session3
        .run('match (da:Data_Attributes)-->(ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM)-->(sc:Schedule) where rl.mdrm = "' + oldData[2] + '" AND sc.schedule="' + oldData[1] + '" set sc.ScheduleOwner= "' + newData[12] + '", rl.mdrm= "' + newData[2] + '", rl.reportingline= "' + newData[3] + '", rl.repinst= "' + newData[4] + '", rl.allowablevalues= "' + newData[13] + '", ba.BusinessElementName = "' + newData[8] + '", ba.BusinessAttribute ="' + newData[19] + '", da.data_attribute="' + newData[11] + '"')
        .then(function (result) {
            console.log("update table" + result);
        })
        .catch(function (err) {
            console.log(err);
        })


    session4
        .run('Match (s:Data_Source)--> (a:Data_Attributes)--> (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM) where rl.mdrm= "' + oldData[4] + '" and ba.BusinessElementName= "' + oldData[12] + '" and a.data_attribute= "' + oldData[17] + '" and s.Source= "' + oldData[20] + '" set ba.Business_Translation= "' + newData[5] + '", a.Table_Name= "' + newData[18] + '", s.Source= "' + newData[20] + '", a.Data_Provider_Name= "' + newData[19] + '", br.bus_requirements= "' + newData[10] + '", br.addreq= "' + newData[11] + '", ba.BusinessElementName= "' + newData[12] + '",  ba.BEDefinition= "' + newData[13] + '", ba.ConsructionLogic= "' + newData[14] + '", ba.Status= "' + newData[16] + '", ba.AxiomShorthandTransformationLogic= "' + newData[17] + '", ba.BusinessAttribute= "' + newData[18] + '", a.DataSourcingTransformation= "' + newData[22] + '", a.DataProviderInterpretation= "' + newData[23] + '", a.StandardizationLogic= "' + newData[24] + '", a.StandardStagingTable= "' + newData[25] + '", a.StandardStagingField= "' + newData[26] + '", a.DataAttributeDefination= "' + newData[27] + '"')
        .then(function (result) {
            console.log("update table called " + newData[17]);
            console.log("update table called " + result);
        })
        .catch(function (err) {
            console.log(err);
        })
})

// app.post('/updateAttributeSumSource', function (req, res) {
//     var Old_Value = req.body.oldValue;
//     var source = req.body.newValue;
//     var data = req.body.data;
//     var MDRM = req.body.data.MDRM;

//     sql.connect(config, function (err, results) {
//      //   if (err) console.log(err);
//         let sqlRequest = new sql.Request();

//         let sqlQuery = "Update dbo.RR_AUDIT_TABLE_TEST SET RECORD_END_DATE = GETDATE() , LAST_UPDATE_DT = GETDATE() where RECORD_END_DATE ='1900-01-02 00:00:00.000' and MDRM ='"+data.MDRM+"';INSERT INTO dbo.RR_AUDIT_TABLE_TEST  VALUES (next value FOR [dbo].[RR_SEQ],'"+data.ReportName+"','"+data.ScheduleName+"','"+data.MDRM+"','"+data.ReportingLine+"','"+data.ReportingInstruction+"', '"+data.CRRID+"','"+data.CRRBussinessRequirements+"','"+data.FAQReference+"','"+data.BusinessElementName+"','"+data.CRR_ConsructionLogic+"','"+data.ScheduleProduct+"','"+data.DataAttribute+"','"+source+"','"+data.ScheduleOwner+"','sourcing Change',GETDATE(),GETDATE(),'1900-01-02 00:00:00.000','M')";
//         sqlRequest.query(sqlQuery, function (err, data) {
//             if (err) console.log(err);
//         //    console.log(data)
//             sql.close();
//         })
//     });

//     console.log(data.MDRM);
//     console.log(source);

//     session4
//         .run('Match (s:Data_Source)--> (a:Data_Attributes)--> (ba:Business_Attributes)-->(br:Business_Rule)-->(rl:MDRM) where rl.mdrm= "'+MDRM_OLD_Value+'" and ba.BusinessElementName= "'+BusinessElementName_old_Value+'" and a.data_attribute= "'+data_attribute_old_value+'" and s.Source= "'+Source_old_value+'" set ba.Business_Translation= "'+Business_Translation_new_value+'", a.Table_Name= "'+Table_Name_New_value+'", s.Source= "'+Source_new_value+'", a.Data_Provider_Name= "'+Data_Provider_Name_new_value+'", br.crrid= "'+crrid_New_Value+'", br.bus_requirements= "'+bus_requirements_new_Value+'", br.addreq= "'+addreq_new_Value+'", ba.BusinessElementName= "'+BusinessElementName_New_Value+'", ba.BEDefination= "'+BEDefination_New_Value+'",ba.CRR_ConsructionLogic= "'+CRR_ConsructionLogic_New_Value+'", a.data_attribute= "'+data_attribute_New_Value+'"')
//         .then(function (result) {
//             console.log("update table" + result);
//         })
//         .catch(function (err) {
//             console.log(err);
//         })
// })

app.post('/uploadFile', function (req, res) {

    const excelData = readFile(inputfile);
    sql.connect(config, function (err, results) {
        if (err) console.log(err);
        let sqlRequest = new sql.Request();
        let sqlQuery = "INSERT INTO Document VALUES('xlsx','" + inputfile + "','" + excelData + "')";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) console.log(err);
            sql.close();
        })
    });

});

app.post('/retriveFile', function (req, res) {

    var output = {};
    sql.connect(config, function (err, results) {
        let fileName = inputfile;
        if (err) console.log(err);
        let sqlRequest = new sql.Request();
        let sqlQuery = "select Doc_Content from Document where FileName ='" + fileName + "'";
        sqlRequest.query(sqlQuery, function (err, data) {
            if (err) throw err;
            //  console.log(data.recordset[0].Doc_Content);
            data.recordset.forEach(function (record) {
                const bufData = Buffer.from(record.Doc_Content, 'base64')
                // const originalData = Buffer.from(bufData,'binary')
                fs.writeFileSync(outputfile, bufData);

                res.attachment('inline');
                res.contentType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                res.download(outputfile);
            })
            sql.close();
        })
    });

});


app.post('/GetDrillDownDataLevel1', function (req, res) {
    var dict_name = ["Ledger_Account","Balance"];
    var mdrm = req.body.mdrm;
    //var mdrm = 'RCFD2151';
    var  row_count = 0;
    var dict_li = {};
    var LINames = [];
    session4
        .run('match (m:MDRM)<--(a:Attribute) where m.mdrm= "' + mdrm + '" with count(DISTINCT a.attribute_name) as count_of_attribute match (s:Schedule)<--(m)<--(a)<--()<--(r:Transaction) where m.mdrm= "' + mdrm + '" with m.mdrm as mdrm, r.Ledger_Account as Ledger_Account, r.BookBalance as balance, count(DISTINCT a.attribute_name) as count_of_attribute_per_Ledger_Account_ID, count_of_attribute as limit_value, s.schedule as Schedule where count_of_attribute_per_Ledger_Account_ID = limit_value return Ledger_Account,SUM(balance)')
        .then(function (result) {
            result.records.forEach(function (record) {
                dict_li = {
                    "S.No": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {
                    if (Array.isArray(record._fields[i])) {
                        dict_li[dict_name[i]] = record._fields[i][0];
                    }
                    else {
                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                row_count = row_count + 1;
                LINames.push(dict_li);
                console.log(LINames);
            })
            return res.json(LINames);
        })
        .catch(function (err) {

            console.log(err);
        })
})


app.post('/GetDrillDownDataLevel2', function (req, res) {

    var  dict_name = ["Company", "Ledger_Account", "Journal_Source", "Customer", "Counterparty_Domicile", "Counterparty_Sector", "Counterparty_Name", "balance", "Source_File_Name", "Start_Time"];
    var mdrm = req.body.mdrm;
    //var mdrm = 'RCFD2151';
    var row_count = 0;
    var dict_li = {
    };
    var LINames = [];
    session4
        .run('match (m:MDRM)<--(a:Attribute) where m.mdrm=  "' + mdrm + '" with count(DISTINCT a.attribute_name) as count_of_attribute match (s:Schedule)<--(m)<--(a)<--()<--(r:Transaction) where m.mdrm=  "' + mdrm + '"  with m.mdrm as mdrm, r.Ledger_Account as Ledger_Account, r.BookBalance as balance, count(DISTINCT a.attribute_name) as count_of_attribute_per_Ledger_Account_ID, count_of_attribute as limit_value, s.schedule as Schedule, r.Transaction_ID as Transaction_ID, r.Company as Company, r.Journal_Source as Journal_Source, r.Customer as Customer, r.CounterpartyDomicile as Counterparty_Domicile, r.CounterpartySector as Counterparty_Sector, r.Counterparty_Name as Counterparty_Name, r.Source_File_Name as Source_File_Name, r.StartTime as Start_Time   where count_of_attribute_per_Ledger_Account_ID = limit_value return Company, Ledger_Account, Journal_Source, Customer, Counterparty_Domicile, Counterparty_Sector, Counterparty_Name, balance, Source_File_Name, Start_Time')
        .then(function (result) {

            result.records.forEach(function (record) {

                dict_li = {

                    "S.No": row_count
                };
                for (var i = 0; i < record._fields.length; i++) {

                    if (Array.isArray(record._fields[i])) {

                        dict_li[dict_name[i]] = record._fields[i][0];
                    }
                    else {

                        dict_li[dict_name[i]] = record._fields[i];
                    }
                }
                row_count = row_count + 1;
                LINames.push(dict_li);
                console.log(LINames);
            })
            return res.json(LINames);
        })
        .catch(function (err) {

            console.log(err);
        })
});


app.get('/GetVarianceAnalysisReport', function (req, res) {
    var balanceResult = [];
    var output = {};
    sql.connect(config, function (err, results) {
        if (err) console.log(err);
 
        //Report cnt
        let sqlRequest = new sql.Request();
        let sqlQuery = "SELECT LTRIM(RTRIM(MDRM)) as MDRM ,Previous_Quarter_1,Previous_Quarter_2,Previous_Quarter_3,Previous_Quarter_4 FROM [ReportingRadius].[dbo].[VarianceAnalysis]";
        sqlRequest.query(sqlQuery, function (err, data) {
 
            //console.log(data.recordsets[0]);
            data.recordsets[0].forEach(function (record) {
                output["mdrm"] = record.MDRM;
                output["Previous_Quarter_1"] = record.Previous_Quarter_1;
                output["Previous_Quarter_2"] = record.Previous_Quarter_2;
                output["Previous_Quarter_3"] = record.Previous_Quarter_3;
                output["Previous_Quarter_4"] = record.Previous_Quarter_4;
                balanceResult.push(output);
                output = {};
            })
            //console.log(output);
            // res.send(output)
            // sql.close();
            return res.json(balanceResult)
        })
    });
 
});




function readFile(file) {
    // read binary data from a file:
    const bitmap = fs.readFileSync(file);
    var base64data = Buffer.from(bitmap, 'binary').toString('base64');
    return base64data;
}
app.listen(3001);
console.log("Running on port 3001...");
module.exports = app;
