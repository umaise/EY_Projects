var aad = require('azure-ad-jwt');
var logger = require('../logger/logger.js');
var appconfig = require('../config/appconfig.js');
var redisUtil = require('../redisdbhandlr/redisUtil.js');
var cryptoutil = require('./cryptoutil.js');
var restCallUtil = require('./restCallUtil.js');

var supplyRegisterUtil = {

  checkHmac: function(reqJsonVO, successCallback, errorCallback) {
     var keydetails = JSON.parse("{}");

     keydetails.AUTH_TOKEN =  reqJsonVO.REQUEST_HEADER["auth_token"];
     keydetails.ENC_DATA =  reqJsonVO.PAYLOAD.data;
     keydetails.HMAC_PAYLOAD =  reqJsonVO.PAYLOAD.hmac;
    // keydetails.HMAC_PAYLOAD = "ilPVTPPQvfHwLJRR3vW6J3Qdzq4=";
     keydetails.USERNAME = reqJsonVO.REQUEST_HEADER["digigst_username"];

     redisUtil.getDetailsFromRedis(keydetails.USERNAME+"_encAPIUser",
          function (value) {
           keydetails.SK = value["sk"];
           //console.log("keydetails.SK : " + keydetails.SK);
           //console.log("keydetails.ENC_DATA : " + keydetails.ENC_DATA);

          // var data = "{\"gstin\":\"33GSPTN0481G1ZA\",\"fp\":\"122016\",\"gt\":\"39999990196444\"}";
          //
          //  cryptoutil.cipher(new Buffer(data).toString('base64') ,keydetails.SK,
          //  function(Crypteddata) {
          //     keydetails.ENC_DATA =Crypteddata;
          //     console.log("enc data : " + keydetails.ENC_DATA);
          //  },
          //  function(error) {
          //    console.log("Error in data enc:" + error);// TODO remove temporary
          //  });
              cryptoutil.decipher(new Buffer(keydetails.ENC_DATA, 'base64') ,keydetails.SK,
              function (decryptedData) {
                keydetails.DEC_DATA = decryptedData.toString('utf8');
                //console.log("encoded : " + keydetails.DEC_DATA);
                cryptoutil.generateHmacForData(keydetails.SK, keydetails.DEC_DATA,
                  function (hmacSuccess) {
                    logger.debug("HMAC is generated !! " );
                    console.log("HMAC is generated : " + hmacSuccess);
                    keydetails.HMAC_PAYLOAD = hmacSuccess;// TODO remove this later
                    keydetails.HMAC_DATA = hmacSuccess;
                   if(hmacSuccess.indexOf(keydetails.HMAC_PAYLOAD) == 0) {
                      successCallback(keydetails);
                   } else {
                     logger.debug("HMAC is not same..");
                     errorCallback(supplyRegisterUtil.generateResponseSaveData(0,"ERRHMAC01", "HMAC is not same !!"));
                   }
                }, function (hmacError){
                    //console.log("HMAC error: " + hmacError);
                    logger.error("HMAC error: " + hmacError);
                    errorCallback(supplyRegisterUtil.generateResponseSaveData(0,"ERRHMAC02", "Error creating hmac, please check data!!"));
                });
              }, function (deciperError) {
                //console.log("Error in decrypting data: " + deciperError);
                logger.error("Error in decrypting data.. " + deciperError);
                errorCallback(supplyRegisterUtil.generateResponseSaveData(0,"ERRDATA01", "Error while decrypting the data, please check !!"));
              });

     },
     function(errorInRedis) {
          errorCallback(supplyRegisterUtil.generateResponseSaveData(0,"ERRSK", "Session doesn't exist!!"))
     });
  },
  saveFileInward : function (reqJsonVO, keyDetails,successCallBack, errorCallBack ) {

     var saveInwardBody = {
                "data" :  (keyDetails.DEC_DATA).toString(),
                "emailId" :  reqJsonVO.REQUEST_HEADER['digigst_username'],
                "sourceType"	:  appconfig.sourceType
              };

     var headers = {
             "content-type": "application/json;charset=UTF-8",
             "X-TENANT-ID" : reqJsonVO.REQUEST_HEADER.orgid
     };

     restCallUtil.executePostRestCall(appconfig.insertInwardFileURL, headers,  JSON.stringify(saveInwardBody) ,function (res, body) {
          logger.debug("Insert inward API call respose : " + body);
         successCallBack (body);
     } , function(err) {
         logger.error("Unable to call insertInwardFile API..");
         logger.error(err);
         errorCallBack(supplyRegisterUtil.generateResponseSaveData(0,"ERRINSERT", "Error in InsertInwardAPI"));
     });
  },
  saveFileOutward : function (reqJsonVO, keyDetails,successCallBack, errorCallBack ) {

     var saveOutwardBody = {
                 "data" :  (keyDetails.DEC_DATA).toString(),
                 "emailId" :  reqJsonVO.REQUEST_HEADER['digigst_username'],
                 "sourceType"	:  appconfig.sourceType
              }
     var headers = {
             "content-type": "application/json;charset=UTF-8",
             "X-TENANT-ID" : reqJsonVO.REQUEST_HEADER.orgid
     };
     restCallUtil.executePostRestCall(appconfig.insertOutwardFileURL, headers, JSON.stringify(saveOutwardBody) ,function (res, body) {
          logger.debug("Insert outward API call respose : " + body);
         successCallBack (body);
     } , function(err) {
         logger.error("Unable to call insertOutwardFile API..");
         logger.error(err);
         errorCallBack(supplyRegisterUtil.generateResponseSaveData(0,"ERRINSERT", "Error in InsertOutwardAPI"));
     });
  },
  generateResponseSaveData :  function (resStatus ,err_cd , desc) {
    var responseJSON = JSON.parse("{}");
      if(resStatus == 0) {
            responseJSON.STATUS_CD = "0";
            responseJSON.ERR_CD = err_cd;
            responseJSON.ERR_DESC = desc;
      } else {
        //responseJSON.STATUS_CD = "1";
        responseJSON.RESPONSE = desc;
      }
      return responseJSON;
  }
}
module.exports = supplyRegisterUtil;
