var aad = require('azure-ad-jwt');
var logger = require('../logger/logger.js');
var appconfig = require('../config/appconfig.js');
var redisUtil = require('../redisdbhandlr/redisUtil.js');
var cryptoutil = require('./cryptoutil.js');
var restCallUtil = require('./restCallUtil.js');
var jwt = require('jsonwebtoken');
var dateFormat = require('dateformat');


var authenticateUserUtil = {

    getToken : function(reqJson, decPassword, decryptedAppkey, successCallBack, errorCallBack ){

        var bodyParams = "grant_type="+appconfig.grant_accessToken
                         +"&username="+reqJson.REQUEST_HEADER['digigst_username']
                         +"&password="+decPassword
                         +"&client_id="+appconfig.clientId
                         +"&client_secret="+appconfig.clientSecret
                         +"&resource="+appconfig.resource
                         +"&scope="+appconfig.scope;

        var headers = {
                "Content-Type" :   "application/x-www-form-urlencoded"
        };
    restCallUtil.executePostRestCall(appconfig.azureADTokenEndpoint, JSON.stringify(headers), bodyParams,
                    function(res, body){
                        var responseObject = JSON.parse(body);
                        var sek;
                        var auth_token;
                        authenticateUserUtil.signToken(responseObject['access_token'], function(signedToken){
                            //Generate auth_token
                            authenticateUserUtil.generateAuthToken(decryptedAppkey, signedToken, function(hmac){
                                    auth_token = hmac;
                                    //generate sek
                                var sk = cryptoutil.generateRandomKey(appconfig.keySize);
                                logger.debug("SK fetched successfully!!");
                                authenticateUserUtil.generateSek(sk,decryptedAppkey, function(sessionEncKey){
                                        sek = sessionEncKey;
                                        //Save to Redis
                                        authenticateUserUtil.saveToRedis(auth_token , reqJson.REQUEST_HEADER['digigst_username'], sk, responseObject, signedToken, function(success){
                                            logger.info("Successfully saved data in Redis!!");
                                            successCallBack(authenticateUserUtil.generateSuccessResponse(auth_token, sek,sk, responseObject['expires_in']));
                                        }, function(err){
                                            logger.error("Error saving data to Redis : " + err);
                                            errorCallBack(authenticateUserUtil.generateErrorResponse("ERRGETTOKEN", "Error generating Access Token"));
                                        });
                                    }, function(err){
                                        logger.error("Error generating sek : " + err);
                                        errorCallBack(authenticateUserUtil.generateErrorResponse("ERRGETTOKEN", "Error generating Access Token"));
                                    });
                                }, function(err){
                                    logger.error("Error generating auth_token : " + err);
                                    errorCallBack(authenticateUserUtil.generateErrorResponse("ERRGETTOKEN", "Error generating Access Token"));
                                });
                       }, function(error){
                           logger.error("Error generating signed token : " + err);
                           errorCallBack(authenticateUserUtil.generateErrorResponse("ERRGETTOKEN", "Error generating Access Token"));
                    });
                    }, function(err){
                        logger.error("Unable to get Access token details : " + err);
                        errorCallBack(authenticateUserUtil.generateErrorResponse("ERRGETTOKEN", "Error generating Access Token"));
                    });
    },

    validateToken : function(validateToken, reqJson, successCallBack, errorCallBack) {
      if(validateToken){   
            var auth_token = reqJson.PAYLOAD['auth_token'];
            var audience = appconfig.resource;

            if (auth_token) {

                redisUtil.getDetailsFromRedis(reqJson.REQUEST_HEADER['digigst_username'] + "_encAPIUser", function(tokenDetails){

                        if(auth_token.indexOf(tokenDetails["auth_token"]) > -1){
                            logger.debug("Token details for validation received!! ");
                            var jwtToken = tokenDetails["access_token"];

                            if (jwtToken) {
                                var tokenSigningKey = redisUtil.getValue(appconfig.tokenSigningKey,function(signingKey){
                                    //Verify the signature of the key
                                    jwt.verify(jwtToken, signingKey, function(err, decoded) {
                                        if(err){
                                            errorCallBack(authenticateUserUtil.generateErrorResponse("ERRINVALIDTOKEN", "Validation failed. Invalid token."));
                                        }else{
                                            logger.debug("Token signature verified.");
                                            var decodedAcc = jwt.decode(decoded.data);

                                            //Verify the Token Claims
                                            authenticateUserUtil.verifyTokenClaims(decodedAcc, function(tokenValidation){
                                                if(tokenValidation){
                                                    logger.info("Token validation successful.");
                                                    successCallBack();
                                                }else{
                                                    errorCallBack(authenticateUserUtil.generateErrorResponse("ERRINVALIDTOKEN", "Validation failed. Invalid token."));
                                                }
                                            });
                                        }
                                    });
                                },function(error){
                                    logger.error("Error getting the token signing key from redis.");
                                    errorCallBack(authenticateUserUtil.generateErrorResponse("ERRINVALIDTOKEN", "No token signing key found in redis"));
                                });
                                
                            } else {
                                logger.error("No token found in the request");
                                errorCallBack(authenticateUserUtil.generateErrorResponse("ERRINVALIDTOKEN", "No token found in the request"));
                            }
                    }else{
                        logger.error("Invalid Auth token!!");
                        errorCallBack(authenticateUserUtil.generateErrorResponse("ERRINVALIDTOKEN", "User isn't authorized!"));
                    }
                }, function(err){
                        logger.error("Unable to get Token details : " + err);
                        errorCallBack(authenticateUserUtil.generateErrorResponse("ERRGETDETREDIS", "Error getting details from Redis"));

                });
            } else {
                logger.error("No authorization header in the request");
                errorCallBack(authenticateUserUtil.generateErrorResponse("ERRINVALIDTOKEN", "No authorization header in the request"));
            }
        }else{
          logger.debug("Skipping Token Validation");
          successCallBack();
      }
    },

    refreshToken : function(reqJson, decryptedAppkey, tokenDetails, successCallBack, errorCallBack){

                var bodyParams = "grant_type="+appconfig.grant_refreshToken
                         +"&client_id="+appconfig.clientId
                         +"&client_secret="+appconfig.clientSecret
                         +"&resource="+appconfig.resource
                         +"&refresh_token="+tokenDetails["refresh_token"];

                var headers = {
                        "Content-Type" :   "application/x-www-form-urlencoded"
                };

            restCallUtil.executePostRestCall(appconfig.azureADTokenEndpoint, JSON.stringify(headers), bodyParams,
                     function(res, body){
                            var responseObject = JSON.parse(body);
                            authenticateUserUtil.signToken(responseObject['access_token'], function(signedToken){
                            //Generate auth_token
                            authenticateUserUtil.generateAuthToken(decryptedAppkey, signedToken, function(hmac){
                                  auth_token = hmac;
                                  var sk = cryptoutil.generateRandomKey(appconfig.keySize);
                                  logger.debug("SK succesfully fetched..!!");
                                //generate sek
                                authenticateUserUtil.generateSek(sk, decryptedAppkey, function(sessionEncKey){
                                        sek = sessionEncKey;

                                    //Update details in Redis
                                    authenticateUserUtil.updateDetailsInRedis(auth_token ,reqJson.REQUEST_HEADER['digigst_username'], sk, responseObject, signedToken, function(success){
                                        logger.info("Successfully updated data in Redis.");
                                        successCallBack(authenticateUserUtil.generateSuccessResponse(auth_token, sek,sk, responseObject['expires_in']));
                                    }, function(err){
                                        logger.error("Error updating data to Redis : " + err);
                                        errorCallBack(authenticateUserUtil.generateErrorResponse("ERRREFRESHTOKEN", "Error refreshing Access Token"));
                                    });
                                }, function(err){
                                    logger.error("Error generating sek for refresh token."+err);
                                    errorCallBack(authenticateUserUtil.generateErrorResponse("ERRREFRESHTOKEN", "Error refreshing Access Token"));
                                });
                            }, function(err){
                                logger.error("Error generating auth_token for refresh token : " + err);
                                errorCallBack(authenticateUserUtil.generateErrorResponse("ERRREFRESHTOKEN", "Error refreshing Access Token"));
                            });
                       }, function(err){
                           logger.error("Error getting a signed token for refresh: " +err);
                           errorCallBack(authenticateUserUtil.generateErrorResponse("ERRREFRESHTOKEN", "Error refreshing Access Token"));
                    });     

                    }, function(err){
                            logger.error("Unable to refresh access token details : " + err);
                            errorCallBack(authenticateUserUtil.generateErrorResponse("ERRREFRESHTOKEN", "Error refreshing Access Token"));
                    });


    },

  decryptWithPrivateKey : function (encryptedData){
      var pathToPEMFile = "C:\\Users\\priyanka.arora3\\Desktop\\1007\\cer\\testpri.pem";//TODO
      var decryptedDataSt;
      cryptoutil.decryptWithRsaPrivateKey(encryptedData, pathToPEMFile,
      function(decryptedData){
          decryptedDataSt = decryptedData;
      }, function(error){
        logger.error("Error decrypting data cryptoutil.decryptWithRsaPrivateKey() : " + error);
      });
    return decryptedDataSt;
  },
  getDecryptedPassword : function (encryptedPassword,appKey, successCallBack, errorCallBack){
    cryptoutil.decipher(encryptedPassword, appKey, successCallBack, errorCallBack )
  },
 decryptWithSK : function (encryptedData,key, successCallBack, errorCallBack){
    cryptoutil.decipher(encryptedData, key, successCallBack, errorCallBack )
  },
  generateAuthToken : function(decryptedAppkey, access_token, successCallBack, errorCallBack){
      cryptoutil.generateHmac(decryptedAppkey, access_token, successCallBack, errorCallBack);
  },

  generateSek : function(sk,decryptedAppkey, successCallBack, errorCallBack){
    cryptoutil.cipher(sk, decryptedAppkey, successCallBack, errorCallBack);
  },

  saveToRedis : function(auth_token ,digigstUsername, sk, responseObj, signedToken, successCallBack, errorCallBack){
      var tokenDetails = JSON.parse("{}");
      tokenDetails["digigst_username"] = digigstUsername;
      tokenDetails["auth_token"] = auth_token;
      tokenDetails["access_token"] = signedToken;
      tokenDetails["refresh_token"] = responseObj['refresh_token'];
      tokenDetails["expires_in"] = responseObj['expires_in'];
      tokenDetails["sk"] = sk;
      tokenDetails["dateModified"] = dateFormat(new Date(), 'yyyy-mm-dd HH:MM:ss')
      logger.debug("Saving details in redis.. ");
      redisUtil.saveToRedis((digigstUsername + "_encAPIUser" ) , tokenDetails,successCallBack,errorCallBack);
  },

    updateDetailsInRedis : function(auth_token, digigstUsername, sk, responseObj, signedToken, successCallBack, errorCallBack){
      var tokenDetails = JSON.parse("{}");
      tokenDetails["digigst_username"] = digigstUsername;
      tokenDetails["auth_token"] = auth_token;
      tokenDetails["access_token"] = signedToken;
      tokenDetails["refresh_token"] = responseObj['refresh_token'];
      tokenDetails["expires_in"] = responseObj['expires_in'];
      tokenDetails["sk"] = sk;
      tokenDetails["dateModified"] = dateFormat(new Date(), 'yyyy-mm-dd HH:MM:ss')
      logger.debug("Updating details from redis.. ");
      redisUtil.updateDetailsInRedis((digigstUsername + "_encAPIUser" ) , tokenDetails,successCallBack,errorCallBack);
  },

  getDetailsFromRedis : function(digigstUsername, successCallBack, errorCallBack){
     logger.debug("Getting details from redis.. ");
     redisUtil.getDetailsFromRedis(digigstUsername, successCallBack, errorCallBack);
  },

 generateSuccessResponse : function (auth_token, sek, sk, expiryTime) {
      var responseJSON = JSON.parse("{}");

      responseJSON["status_cd"] = "1";
      responseJSON["auth_token"] = auth_token;
      responseJSON["expiry"] = expiryTime;// in secss
      responseJSON["sek"] = sek;
      //responseJSON["sk"] = sk;
      return responseJSON;
    },

 generateErrorResponse : function(err_cd, err_desc){
    var responseJSON = JSON.parse("{}");

    responseJSON["status_cd"] = "0";
    responseJSON["err_cd"] = err_cd;
    responseJSON["err_desc"] = err_desc;
    
    return responseJSON;
 },

 signToken : function(access_token, successCallBack, errorCallBack){
     
     redisUtil.getValue(appconfig.tokenSigningKey, function(signingKey){
         if(null != signingKey && undefined!=signingKey){
             var signedToken = jwt.sign({data: access_token}, signingKey);
             successCallBack(signedToken);
         }else{
            logger.error("Token signing key in redis is either null or undefined.");
            errorCallBack("Token signing key in redis is either null or undefined.");
         }
     }, function(error){
         logger.error("Error getting Token signing key from Redis. "+error);
         errorCallBack(error);
     })
     
 },

verifyTokenClaims : function(token, callBack){
    var validToken = false;
    var dateNow = new Date();
    var currTime = Math.floor(dateNow.getTime()/1000);

    //Verify the expiry of the token
    if(token.exp >= currTime){
        //Verify the Audience and Issuer
        if((appconfig.azureAppAudience.indexOf(token.aud) > -1) && (appconfig.azureAppIssuer.indexOf(token.tid) > -1)){
            logger.debug("Audience and Issuer verified.");
            validToken = true;
            callBack(validToken);
        }else{
            logger.debug("Claims Validation failed.");
            callBack(validToken);
        }
    }else{
        logger.debug("Token has expired.");
        callBack(validToken);
    }
}
}
module.exports = authenticateUserUtil;
