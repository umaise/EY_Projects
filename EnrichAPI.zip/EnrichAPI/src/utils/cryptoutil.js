var crypto = require("crypto");
var path = require("path");
var fs = require("fs");
var forge = require("node-forge");
var appconfig = require('../config/appconfig.js');
var logger = require('../logger/logger.js');

var cryptoutil = {

  cipher: function (data, appKey, successCallback, errorCallBack) {
    try {
        var algorithm = appconfig.encryptionAlgorithm;
        var cipher = crypto.createCipheriv(algorithm, new Buffer(appKey, 'base64'), new Buffer(''));//TODO add string to encrypt
        var crypted = cipher.update(data, 'base64', 'base64');//TODO add key
        crypted += cipher.final('base64');
      //  console.log("crypted: " + crypted);
        successCallback(crypted);
    } catch (err) {
      logger.error("Error in cipher: " + err);
      errorCallBack(err);
    }
  },
  decipher: function (data, appKey, successCallback, errorCallBack) {
        try {
            var algorithm = appconfig.encryptionAlgorithm;
            var decipher=crypto.createDecipheriv(algorithm,new Buffer(appKey,"base64"),new Buffer(''))
            var dec=Buffer.concat([decipher.update(data) ,decipher.final()]);
           //console.log(dec);
            successCallback(dec);
        }
        catch (err) {
          logger.error("Error in decipher: " + err);
            //console.log("error: " + err );
            errorCallBack(err);
        }
    },
    getDecryptedInfoAsJsonVO: function (reqJsonVO, response) {
        var json = JSON.parse("{}");
        json['data'] = response;
        json['key'] = reqJsonVO.appkey;
        return json;
    },
    encryptwithRsaPublicKey : function(toEncrypt, relativeOrAbsolutePathToPublicKey, successCallback, errorCallBack) {
      var der = fs.readFileSync(relativeOrAbsolutePathToPublicKey,  {encoding: 'binary'});
      try {
        var asnObj = forge.asn1.fromDer(der);
        var asn1Cert = forge.pki.certificateFromAsn1(asnObj);
        var publicKey = forge.pki.certificateToPem(asn1Cert);
        var buffer = new Buffer(toEncrypt);
          var obj ={
              key :  publicKey,
              padding :crypto.constants.RSA_PKCS1_PADDING
              }
          var encrypted = crypto.publicEncrypt(obj, buffer);
        //  console.log("encryptwithRsaPublicKey:  " + encrypted.toString("base64"));
          successCallback(encrypted.toString("base64"));
        } catch (err) {
          logger.error("Error in encryptwithRsaPublicKey() : " + err);
          errorCallBack(err);
         }
       },

    decryptWithRsaPrivateKey : function(toDecrypt, relativeOrAbsolutePathtoPrivateKey, successCallback, errorCallBack) {
      try {
          var absolutePath = path.resolve(relativeOrAbsolutePathtoPrivateKey);
          var privateKey = fs.readFileSync(absolutePath, "utf8");
          var obj ={
            key :  privateKey,
            padding : crypto.constants.RSA_PKCS1_PADDING
          }
          var buffer = new Buffer(toDecrypt, "base64");
          var decrypted = crypto.privateDecrypt(obj, buffer);
          successCallback(decrypted.toString("utf8"));
          //return decrypted.toString("utf8");
    } catch (err) {
        logger.error("Error in decryptWithRsaPrivateKey() : " + err);
      errorCallBack(err);
    }
  },
  generateHmac : function(appKey, accessToken, successCallBack, errorCallBack){
        var algorithm = appconfig.hmacAlgorithm;
        try {
            var hmac = crypto.createHmac(algorithm, appKey);
            hmac.update(accessToken);
            var hash = hmac.digest('base64');
            successCallBack(hash);
        } catch(err){
          logger.error("Error in generateHmac() : " + err);
            errorCallBack(err);
        }

  },
  generateHmacForData : function(key, data, successCallBack, errorCallBack){
        var algorithm = appconfig.hmacAlgorithm;
        try {
            var hmac = crypto.createHmac(algorithm, key);
            hmac.update(data);
            var hash = hmac.digest('base64');
            successCallBack(hash);
        } catch(err){
            logger.error("Error in generateHmacForData() : " + err);
            errorCallBack(err);
        }
  },
  generateRandomKey : function(keySize) {
    var buff = crypto.randomBytes(keySize);
    var token = buff.toString("base64");
    return token;
  },
  decodeBase64String : function (base64String){
    return new Buffer(base64String, "base64");
  }
};
module.exports = cryptoutil;
