var request = require('request');
var logger = require('../logger/logger.js');


var restCallUtil = {

    executePostRestCall : function(url, headers, bodyParams, successCallBack, errorCallBack){
        request.post({
           headers: headers,
           url:     url,
           body:    bodyParams,
           //proxy : "http://ingssweb.ey.net:8080"
         },function(err,res,body){
                if(err){
                  logger.error("Unable to execute POST call: "+err);
                  errorCallBack(err);
                }
                else{
                  logger.info("Successfully executed POST call");
                  successCallBack(res, body);
                }
         }
        );
    }
}
module.exports = restCallUtil;
