var logger = require('../logger/logger.js')
var express = require('express');
var http = require('http');
var request = require('request');
var json2csv = require('json2csv');
var fs = require('fs');
var csv2json = require('csvtojson');

var ConversionUtil = {

jsontocsv : function (json, successCallback, errorCallBack) {
  var up = ['colors','price'];
  var csv = json2csv({ data: json, unwindPath: 'price' });
  var nano = process.hrtime()[1];
  fs.writeFile(nano + '.csv', csv, function (err) {
    if (err) {
      logger.error("Error saving as csv.");
      errorCallBack(err);
    }
    else {
      logger.info('file saved');
      successCallback("file converted and saved");
    }
  });
},
csvTojson : function (csvFilePath, successCallback,errorCallBack){
//var csvFilePath = 'C:\\Users\\kamalanathan.v\\Desktop\\GSPAPP1\\551257805.csv'//TODO change path
var jsonArray = [];
  csv2json()
    .fromFile(csvFilePath)
    .on('json', (jsonObj) => {
      // combine csv header row and csv line to a json object
      // jsonObj.a ==> 1 or 4
      logger.info(jsonObj);
      jsonArray.push(jsonObj);
    })
    .on('done', (error) => {
      if (error) {
        logger.error("Error converting file");
        errorCallBack(error);
      }
      else{
        successCallback(jsonArray);
      }
    });
  }
};
module.exports = ConversionUtil;
