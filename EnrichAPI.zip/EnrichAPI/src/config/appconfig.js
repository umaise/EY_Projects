var appconfigs = {}
var commonConfig = require('../config/commonConfig.js');
var config = commonConfig.config();
const path = require('path');

appconfigs.appContext = process.env.APPCONTEXT || config.appContext;
appconfigs.logFilePath = process.env.LOGFILEPATH || config.logFilePath;
appconfigs.logLevel = process.env.ASPHDLR_LOGLEVEL || config.logLevel;
appconfigs.redisHost = process.env.REDIS_HOST || config.redisHost;
appconfigs.redisPort = process.env.REDIS_PORT || config.redisPort;
appconfigs.redisAuth= process.env.REDIS_AUTH || config.redisAuth;
appconfigs.host_asp = process.env.HOST_ASP || config.host_asp;
//appconfigs.resource_asp_encrypt = process.env.RESOURCE_ASP_ENCRYPT || config.resource_asp_encrypt;
//appconfigs.resource_asp_decrypt = process.env.RESOURCE_ASP_DECRYPT || config.resource_asp_decrypt;
appconfigs.restCall = process.env.restCall || config.restCall;
appconfigs.encryptionAlgorithm = process.env.encryptionAlgorithm || config.encryptionAlgorithm;
appconfigs.hmacAlgorithm = process.env.HMACALGORITHM || config.hmacAlgorithm;

appconfigs.authAppContext = process.env.AUTHAPPCNTXT || config.authAppContext;
appconfigs.unAuthAppContext = process.env.UNAUTHAPPCNTXT || config.unAuthAppContext;
appconfigs.utilityContext = process.env.UTILITYCNTXT || config.utilityContext;
appconfigs.getAccessTokenUrl = process.env.ACCTOKENURL || config.getAccessTokenUrl;
appconfigs.refreshTokenUrl = process.env.REFTOKENURL || config.refreshTokenUrl;
appconfigs.inwardSupplyUrl =  process.env.INWRDSUPPURL || config.inwardSupplyUrl;
appconfigs.outwardSupplyUrl =  process.env.OUTWRDSUPPURL || config.outwardSupplyUrl;
appconfigs.decryptUrl =  process.env.DECRYPTURL || config.decryptUrl;
appconfigs.encryptUrl =  process.env.ENCRYPTURL || config.encryptUrl;
appconfigs.encryptWithPCUrl =  process.env.ENCRYPTPCTURL || config.encryptWithPCUrl;
appconfigs.genAppkeyUrl =  process.env.GENAPPKEYURL || config.genAppkeyUrl;

appconfigs.keySize = process.env.KEYSIZE || config.keySize;
appconfigs.fileType_inward = process.env.FILETYPINWRD || config.fileType_inward;
appconfigs.fileType_outward = process.env.FILETYPOUTWRD || config.fileType_outward;
appconfigs.sourceType = process.env.SOURCETYP || config.sourceType;

//Azure AD Oauth2/token details
appconfigs.azureADTokenEndpoint = process.env.AZUREADTOKENEP || config.azureADTokenEndpoint;
appconfigs.resource = process.env.RESOURCE || config.resource;
appconfigs.clientId = process.env.CLIENTID || config.clientId;
appconfigs.clientSecret = process.env.CLIENTSECRET || config.clientSecret;
appconfigs.grant_accessToken = process.env.GRANTACCTOKEN || config.grant_accessToken;
appconfigs.grant_refreshToken = process.env.GRANTREFTOKEN || config.grant_refreshToken;
appconfigs.scope = process.env.SCOPE || config.scope;
appconfigs.tokenSigningKey = process.env.TOKEN_SIGNING_KEY || config.tokenSigningKey;
appconfigs.azureAppAudience = process.env.AZURE_APP_AUDIENCE || config.azureAppAudience;
appconfigs.azureAppIssuer = process.env.AZURE_APP_ISSUER || config.azureAppIssuer;

appconfigs.enableTokenValidation = process.env.ENABLE_TOKEN_VALIDATION || config.enableTokenValidation;

// ASP API params
appconfigs.insertOutwardFileURL =  process.env.OUTWARDURL || config.insertOutwardFileURL;
appconfigs.insertInwardFileURL =  process.env.INWARDURL || config.insertInwardFileURL;


module.exports = appconfigs;
