var env = require('../../env.json');
var envconfig = require('../../envconfig.js')

exports.config = function() {
  var node_env = envconfig.env;
  return env[node_env];
};
