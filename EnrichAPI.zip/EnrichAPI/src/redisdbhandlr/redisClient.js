var redisClient = {}

var redis = require('redis');
var appconfig = require('../config/appconfig.js')

var redisClient = ( function() {
  var client;
  function createInstance() {
    client = redis.createClient(appconfig.redisPort, appconfig.redisHost);
    if (typeof appconfig.redisAuth !== 'undefined' && appconfig.redisAuth != null) {
          client.auth(appconfig.redisAuth);
    }
    return client;
  }
  return {
    getInstance: function() {
      if (!client) {
        client = createInstance();
      }
      return client;
    }
  };
})();
module.exports = redisClient.getInstance();
