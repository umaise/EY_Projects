var redisUtils = {}
var redisClient = require('../redisdbhandlr/redisClient.js');
var appconfig = require('../config/appconfig.js');
var dateFormat = require('dateformat');
var logger = require('../logger/logger.js')

var client = redisClient;
var redisUtils = {

  saveToRedis : function(key, value, successCallBack, errorCallBack) {
    client.hmset(key, value, function (error, success ) {
        if(success){
          successCallBack(success);
        } else {
          logger.error("Error while data saving in redis : " + error);
          errorCallBack(error);
        }
      });
  },

  getDetailsFromRedis : function(key, successCallBack, errorCallBack) {
    client.hgetall(key, function(err, object) {
        if(object != null && object != 'undefined') {
          successCallBack(object);
        } else {
          logger.error("No data found!");
          errorCallBack("No data found!");
        }
      });
  },

  updateDetailsInRedis: function(key, value, successCallBack, errorCallBack) {
     client.hmset(key, value, function (error,success) {
         if(success){
           successCallBack(success);
         } else {
          logger.error("Error while updating data in redis : " + error);
          errorCallBack(error);
         }
       });
  },

  getValue: function(key, successCallBack, errorCallBack){
    client.get(key, function(error, success){
      if(success){
        successCallBack(success);
      }else{
        logger.error("No data found for the key!");
         errorCallBack(error);
      }
    });

  }
}
module.exports = redisUtils;
