
var express = require('express');
var http = require('http');
var request = require('request');
var logger = require('../logger/logger.js')
var servicemngr = require('../servicemanager/enrichAPIServicemngr.js');
var appconfig = require('../config/appconfig.js');
var router = express.Router();
var authenticateUserUtil = require('../utils/authenticateUserUtil.js');


var interceptFunction = function(req, res, next) {
   next();
};

/* post method for calls where validation is required*/
router.post('/services/*', interceptFunction, function(req, res, next) {

   authenticateUserUtil.validateToken(appconfig.enableTokenValidation, servicemngr.getRequestInfosAsJsonVO(req),function(){
      logger.debug("Token validation successful.");
      servicemngr.handleRequest(
      servicemngr.getRequestInfosAsJsonVO(req),
        function(success) {
          logger.debug(success);
          res.send(success);
          res.end();
        },
        function(err) {
          logger.error(err);
          res.send(err);
          res.end();
        }
      );
  },
  function(msg){
    res.status(401).send(msg);
    res.end();
  });
});

/* post method for calls where validation isn't required*/
router.post('/authServices/getToken', interceptFunction, function(req, res, next) {

  //logger.debug("Inside Router for Auth Services......");
      servicemngr.handleRequest(
      servicemngr.getRequestInfosAsJsonVO(req),
        function(success) {
          logger.debug(success);
          res.send(success);
          res.end();
        },
        function(err) {
          logger.error(err);
          res.send(err);
          res.end();
        }
      );
});

/* post method to decrypt */
router.post('/utilityServices/*', interceptFunction, function(req, res, next) {

  logger.debug("Inside Router for Auth Services......");
      servicemngr.handleRequest(
      servicemngr.getRequestInfosAsJsonVO(req),
        function(success) {
          logger.debug(success);
          res.send(success);
           res.end();
        },
        function(err) {
          logger.error(err);
          res.send(err);
          res.end();
        }
      );
});
module.exports = router;
