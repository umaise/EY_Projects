var http = require('http');
var logger = require('../logger/logger.js');
var appconfig = require('../config/appconfig.js');
var cryptoUtil = require('../utils/cryptoutil.js');
var supplyRegUtil = require('../utils/supplyRegisterUtil.js');
const fs = require('fs');
var path = require('path');
var pathSep = path.sep;

var SupplyRegisterServiceMngr = {
   outwardSupplyAPIcall: function(reqJsonVO,successCallback,errorCallback) {
   supplyRegUtil.checkHmac(reqJsonVO,
     function(keyDetails) {
       logger.debug("HMAC matched..");

         supplyRegUtil.saveFileOutward(reqJsonVO, keyDetails, function(successSaveFile) {
           logger.debug("Outward supply register file saved successfully!!" +successSaveFile);
             successCallback(supplyRegUtil.generateResponseSaveData("1","",successSaveFile));

         }, function (erorrSaveJSON){
           logger.debug("Error in outward java api call" + erorrSaveJSON);
            errorCallback(erorrSaveJSON);
         });
       }, function(errorHmacPresent) {
          logger.error("Error in supplyRegUtil.checkHmac() call" + errorHmacPresent);
             errorCallback(errorHmacPresent);
       });
  },
  inwardSupplyAPIcall: function(reqJsonVO,successCallback,errorCallback) {

    logger.debug("In InwardSupplyAPIcall..");
    supplyRegUtil.checkHmac(reqJsonVO,
      function(keyDetails) {
          logger.debug("HMAC matched..");
          supplyRegUtil.saveFileInward(reqJsonVO, keyDetails, function(successSaveFile) {
            logger.debug("Inward supply register file saved successfully!!" +successSaveFile);
            successCallback(supplyRegUtil.generateResponseSaveData(1,"Success",successSaveFile));
          }, function (erorrSaveJSON) {
           logger.error("Error in inward java api call" + erorrSaveJSON);
            errorCallback(erorrSaveJSON);
          });
        }, function(errorHmacPresent) {
          logger.error("Error in supplyRegUtil.checkHmac() call" + errorHmacPresent);
              errorCallback(errorHmacPresent);
        });
 }
};
module.exports = SupplyRegisterServiceMngr;
