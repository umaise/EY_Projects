var http = require('http');
var logger = require('../logger/logger.js');
var appconfig = require('../config/appconfig.js');
var authenticationServicemngr = require('../servicemanager/authenticationServicemngr.js');
var suppliesRegisterServicemngr = require('../servicemanager/supplyRegisterServicemngr.js');
var utilityServicemngr = require('../servicemanager/utilityServicemngr.js');

var EnrichAPIServiceMngr = {
  handleRequest: function(reqJsonVO,successCallbk,errorCallbk){

   var checkJson = EnrichAPIServiceMngr.checkAction(reqJsonVO.ORIGINALURL);

   if(checkJson.GETACCESSTOKEN){
     logger.debug("Calling Azure AD API to get access token!");
     authenticationServicemngr.getTokenAPIcall(reqJsonVO, successCallbk, errorCallbk);

   } if(checkJson.REFRESHTOKEN){
     logger.debug("Calling Azure AD API to refresh the access token!");
     authenticationServicemngr.refreshTokenAPIcall(reqJsonVO, successCallbk, errorCallbk);

   } if(checkJson.OUTWARDSUPPLY) {
     logger.debug("Save outward supply register call received..");
     suppliesRegisterServicemngr.outwardSupplyAPIcall(reqJsonVO,successCallbk,errorCallbk);

   } if(checkJson.INWARDSUPPLY) {
     logger.debug("Save inward supply register call received..");
     suppliesRegisterServicemngr.inwardSupplyAPIcall(reqJsonVO,successCallbk,errorCallbk);

   } if(checkJson.DECRYPT) {
     logger.debug("Decrypt call received..");
     utilityServicemngr.decrypt(reqJsonVO,successCallbk,errorCallbk);

   } if(checkJson.ENCRYPT) {
     logger.debug("Encrypt call received..");
     utilityServicemngr.encrypt(reqJsonVO,successCallbk,errorCallbk);

   } if(checkJson.ENCRYPTPC) {
     logger.debug("Encrypt with PC call received..");
     utilityServicemngr.encryptWithPublicCert(reqJsonVO,successCallbk,errorCallbk);

   } if(checkJson.GENAPPKEY) {
     logger.debug("Genarate appkey call received..");
     utilityServicemngr.generateAppKey(reqJsonVO,successCallbk,errorCallbk);
   }

},
  getRequestInfosAsJsonVO : function(restReq) {
      var json = JSON.parse("{}");
        json.REQUEST_HEADER = JSON.parse(JSON.stringify(restReq.headers));
        json.REQUEST_PARAMS = JSON.parse(JSON.stringify(restReq.params));
        json.PAYLOAD = JSON.parse(JSON.stringify(restReq.body));

        var orgUrl = restReq.originalUrl.replace(appconfig.appContext,'');
        orgUrl = orgUrl.replace(appconfig.authAppContext,'');
        orgUrl = orgUrl.replace(appconfig.unAuthAppContext,'');
        orgUrl = orgUrl.replace(appconfig.utilityContext,'');
        json.ORIGINALURL = orgUrl;
        return json;
      },

 checkAction : function(url){
        var json = JSON.parse("{}");
        var getAccessToken = false;
        var refreshToken = false;
        var inwardSupply = false;
        var outwardSupply = false;
        var decryptRequest = false;
        var encryptRequest = false;
        var encryptPCRequest = false;
        var genAppkeyRequest = false;

        //check the action to be performed.
         if(appconfig.getAccessTokenUrl.indexOf(url)== 0){
            getAccessToken = true;
          } if(appconfig.refreshTokenUrl.indexOf(url)== 0){
            refreshToken = true;
          }if(appconfig.inwardSupplyUrl.indexOf(url)== 0){
            inwardSupply = true;
          } if(appconfig.outwardSupplyUrl.indexOf(url)== 0){
            outwardSupply = true;
          } if(appconfig.decryptUrl.indexOf(url)== 0){
            decryptRequest = true;
          } if(appconfig.encryptUrl.indexOf(url)== 0){
            encryptRequest = true;
          } if(appconfig.genAppkeyUrl.indexOf(url)== 0){
            genAppkeyRequest = true;
          } if(appconfig.encryptWithPCUrl.indexOf(url)== 0){
            encryptPCRequest = true;
          }
        json.OUTWARDSUPPLY = outwardSupply;
        json.INWARDSUPPLY = inwardSupply;
        json.GETACCESSTOKEN = getAccessToken;
        json.REFRESHTOKEN = refreshToken;
        json.DECRYPT = decryptRequest;
        json.ENCRYPT = encryptRequest;
        json.ENCRYPTPC = encryptPCRequest;
        json.GENAPPKEY = genAppkeyRequest;
        return json;
 }
};
module.exports = EnrichAPIServiceMngr;
