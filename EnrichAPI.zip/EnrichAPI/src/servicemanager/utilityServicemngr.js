
var http = require('http');
var logger = require('../logger/logger.js');
var appconfig = require('../config/appconfig.js');
var authenticateUserUtil = require('../utils/authenticateUserUtil.js');
var cryptoutil = require('../utils/cryptoutil.js');

var UtilityServiceMngr = {

  decrypt: function(reqJsonVO,successCallBack,errorCallBack) {
    logger.debug("Trying to decrypt!!");
    var dataToDecrypt = reqJsonVO.PAYLOAD['data'];
    var decryptWith = reqJsonVO.PAYLOAD['decryptWith'];
    var dataType = reqJsonVO.PAYLOAD['type'];
    cryptoutil.decipher(new Buffer(dataToDecrypt,'base64'),decryptWith,
    function(decryptedVal) {
        logger.debug("Successfully decrypted!!");
         successCallBack(UtilityServiceMngr.generateSuccessResponse("DECRYPTED_VALUE", decryptedVal.toString(dataType)));
    },function(errorInDec) {
         logger.error("Failed to decrypt !!" + errorInDec);
         errorCallBack(UtilityServiceMngr.generateErrorResponse("ERR_DEC001", "Bad Decrypt!!"));
    });
  },
  encrypt: function(reqJsonVO,successCallBack,errorCallBack) {
    logger.debug("Trying to encrypt !!");

    var dataToEncrypt = reqJsonVO.PAYLOAD['data'];
    var encryptWith = reqJsonVO.PAYLOAD['encryptWith'];
    var encDataType = reqJsonVO.PAYLOAD['type'];

    cryptoutil.cipher(new Buffer(dataToEncrypt,encDataType).toString('base64'), encryptWith,
    function(encValue) {
        logger.debug("Successfully encrypted !!");
         successCallBack(UtilityServiceMngr.generateSuccessResponse("ENRYPTED_VALUE", encValue));
    },function(errorInEnc) {
         logger.error("Failed to encrypt !!" + errorInEnc);
         errorCallBack(UtilityServiceMngr.generateErrorResponse("ERR_ENC001", "Bad Encrypt!!"));
    });
  },
  encryptWithPublicCert: function(reqJsonVO,successCallBack,errorCallBack) {
    logger.debug("Trying to encrypt with public certificate !!");
    var dataToEncrypt = reqJsonVO.PAYLOAD['data'];
    var filename = '\\ASP_Public.cer';
    var path = __dirname + filename;
    //console.log("path  : " + path);
    cryptoutil.encryptwithRsaPublicKey(dataToEncrypt,path,
    function(encValue) {
        logger.debug("Successfully encrypted !!");
         successCallBack(UtilityServiceMngr.generateSuccessResponse("ENCRYPTED_VALUE", encValue));
    },function(errorInEnc) {
         logger.error("Failed to encrypt !!" + errorInEnc);
         errorCallBack(UtilityServiceMngr.generateErrorResponse("ERR_ENC002", "Bad Encrypt!!"));
    });
  },
  generateAppKey : function(reqJsonVO,successCallBack,errorCallBack) {
    logger.debug("generateAppKey appkey called !!");
    //var keysize = reqJsonVO.PAYLOAD.keysize;
  //  console.log(keysize);
    try {
      var appKey = cryptoutil.generateRandomKey(32);
      successCallBack(UtilityServiceMngr.generateSuccessResponse("APPKEY_VALUE", appKey));
    } catch (err){
      logger.error("Failed to generate appkey !!" + err);
      errorCallBack(UtilityServiceMngr.generateErrorResponse("ERR_APP001", "Error in Appkey generation!!"));
    }
  },
  generateSuccessResponse : function (code , value) {
       var responseJSON = JSON.parse("{}");
       responseJSON.STATUS_CD = "1";
       responseJSON.VALUE = value;
       return responseJSON;
  },
  generateErrorResponse : function(err_cd, err_desc) {
     var responseJSON = JSON.parse("{}");
     responseJSON.STATUS_CD = "0";
     responseJSON.ERR_CD = err_cd;
     responseJSON.ERR_DESC = err_desc;
     return responseJSON;
   }
};
module.exports = UtilityServiceMngr;
