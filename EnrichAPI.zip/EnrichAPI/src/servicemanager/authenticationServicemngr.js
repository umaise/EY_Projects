
var http = require('http');
var logger = require('../logger/logger.js');
var appconfig = require('../config/appconfig.js');
var authenticateUserUtil = require('../utils/authenticateUserUtil.js');
var cryptoutil = require('../utils/cryptoutil.js');
//var sha1 = require('sha1');
var AuthenticationServiceMngr = {

   getTokenAPIcall: function(reqJsonVO,successCallBack,errorCallBack){
      //logger.debug("In authTokenAPIcall..");

      var decryptedAppkey = reqJsonVO.PAYLOAD['app_key'];
      var decPassword = "";
        //Decrypt the password using decrypted appkey
        authenticateUserUtil.getDecryptedPassword(new Buffer(reqJsonVO.PAYLOAD['digigst_password'],'base64'), decryptedAppkey,
            function (decPass){
                decPassword = decPass.toString('utf8');
            }, function (errorDecPass){
              logger.error("Error in decrypting the password.." + errorDecPass);
                errorCallBack(authenticateUserUtil.generateErrorResponse("ERRDECRYPTPASS", "Error decrypting password"));
        });

      if(decryptedAppkey != null || decryptedAppkey!= undefined){
          authenticateUserUtil.getToken(reqJsonVO, decPassword, decryptedAppkey, function(response){
              successCallBack(response);
          }, function(err){
            logger.error("Error in AuthenticationServiceMngr.getTokenAPIcall() call .." + err);
              errorCallBack(err);
          });
      }
  },

  refreshTokenAPIcall : function(reqJsonVO,successCallBack,errorCallBack) {

        var sk;
        var decryptedAppKey;
        authenticateUserUtil.getDetailsFromRedis(reqJsonVO.REQUEST_HEADER['digigst_username']+ "_encAPIUser", function(tokenDetails){

                  sk = tokenDetails["sk"];
                  authenticateUserUtil.decryptWithSK(new Buffer(reqJsonVO.PAYLOAD['app_key'],'base64'), sk, function(success){
                          
                            decryptedAppKey = success.toString('base64');
                             logger.debug("Decrypted appkey for refresh token successfully!! ");

                                authenticateUserUtil.refreshToken(reqJsonVO, decryptedAppKey, tokenDetails,  function(response){
                                        successCallBack(response);
                                    }, function(err){
                                        logger.error("Error in authenticateUserUtil.refreshToken() call .." + err);
                                        errorCallBack(err);
                                    });
                        },function(err){
                             logger.error("Error decrypting appkey");
                            errorCallBack(authenticateUserUtil.generateErrorResponse("ERRDECRYPTAPPKEY", "Error decypting appkey"));
                        })

        }, function(err){
                        logger.error("Unable to get Token details" + err);
                        errorCallBack(authenticateUserUtil.generateErrorResponse("ERRGETDETREDIS", "Error getting details from Redis"));
        });
  }
};
module.exports = AuthenticationServiceMngr;
