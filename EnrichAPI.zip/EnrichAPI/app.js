
var express = require('express');
var  http = require('http');
var  path = require('path');
var bodyParser = require('body-parser');
var redis = require('redis');
var logger = require('./src/logger/logger.js')
var appconfig = require('./src/config/appconfig.js')
//var redisUtil = require('./src/redisdbhandlr/redisUtil.js');
var redisClientUtil = require('./src/redisdbhandlr/redisClientUtil.js')
var services = require('./src/routes/services.js');
var cookieParser = require('cookie-parser');

var app = express();
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true, parameterLimit:50000})); 

//Redis init
redisClientUtil.init(
  function success() {
   logger.debug('Redis connected successfully');
 },
 function error(err) {
   logger.error('Error on Redis Connection' + err);
 });
app.use(appconfig.appContext, services);
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error');
});

app.all('/', function(req, res, next) {
	  // CORS headers
	  res.header("Access-Control-Allow-Origin", "*"); // restrict it to the required domain
	  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST');
	  // Set custom headers for CORS
	  res.header('Access-Control-Allow-Headers', 'Content-type,Accept,X-Access-Token,X-Key');
	  if (req.method == 'OPTIONS' ) {
	    res.status(200).end();
	  } else {
		  next();
	  }
	});

function errorHandler(err, req, res, next) {
	  // err is either obj or string
	console.log("app: "+err.status)
	console.log("app: "+err.message )
	  res.status(err.status || 500).send(err.message || err);
	};
	// routes here..
	app.use(errorHandler);

  process.on('SIGINT', function() {
        process.exit();
  });


module.exports = app;
