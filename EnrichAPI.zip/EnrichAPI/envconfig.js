var envconfig = {}

envconfig.env = process.env.NODE_ENV || "uat";
global.__basedir = __dirname;

module.exports = envconfig;
