import { Component, OnInit, ViewChild, AfterContentInit, Input, } from '@angular/core';
import { ApiService } from '../shared-service/api.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { OgmaService } from '../ogma.service';
import { NodeId, InputTarget, RawGraph } from 'ogma';
import { ButtonRendererComponent } from "./row-edit.component";


interface HoverEvent {
  target: InputTarget;
  x: number;
  y: number;
}
@Component({
  selector: 'attribute-summary',
  templateUrl: './attribute-summary.component.html',
  styleUrls: ['./attribute-summary.component.css']
})
export class AttributeSummaryComponent implements OnInit, AfterContentInit {

  attributeData: AttributeData[];
  attributeSummary: AttributeSummary;
  attributeName: string;
  editAttForm: FormGroup;
  data: any;
  isDisabled;
  errorMsg: string;
  displayModal: boolean = false;
  isLoadingResult: boolean;
  gridApi;
  gridColumnApi;
  attView: AttForm;
  attViewOld: any;
  items = [];
  columnDefs = [
    { headerName: 'Report Name', field: 'ReportName', sortable: true, filter: true, resizable: true },
    { headerName: 'Schedule Name', field: 'ScheduleName', sortable: true, filter: true, resizable: true },
    { headerName: 'MDRM', field: 'MDRM', sortable: true, filter: true, resizable: true },
    { headerName: 'Reporting Line', field: 'ReportingLine', sortable: true, filter: true, resizable: true },
    { headerName: 'Gap Count', field: 'GapCount', sortable: true, filter: true, resizable: true },
    { headerName: 'Business Element', field: 'BusinessElement', sortable: true, filter: true, resizable: true },
  ];
  rowData: any;
  // private overlayNoRowsTemplate;
  // private overlayLoadingTemplate;
  TabGroup;
  frameworkComponents: any;

  //Ogmaservice

  @ViewChild('ogmaContainer', { static: true })
  private container;

  @Input() currentLayout = 'force';
  layouts: string[] = ['force', 'hierarchical'];
  ogmaContainer;
  graph;
  hoveredContent: { id: NodeId; data };
  hoveredPosition: { x: number; y: number };
  //end
  //table details for tabview 
  columnDefsTab = [
    {
      headerName: "Edit",
      cellRenderer: "buttonRenderer",
      cellRendererParams: {
        onClick: this.onEditButtonClick.bind(this),
        label: "Edit"
      }
    },
    { headerName: 'ReportName', field: '0', sortable: true, filter: true, resizable: true },
    { headerName: 'ScheduleName', field: '1', sortable: true, filter: true, resizable: true },
    { headerName: 'MDRM', field: '2', sortable: true, filter: true, resizable: true },
    { headerName: 'ReportingLine', field: '3', sortable: true, filter: true, resizable: true },
    { headerName: 'ReportingInstruction', field: '4', sortable: true, filter: true, resizable: true },
    { headerName: 'ID', field: '5', sortable: true, filter: true, resizable: true },
    { headerName: 'BussinessRequirements', field: '6', sortable: true, filter: true, resizable: true },
    { headerName: 'FAQReference', field: '7', sortable: true, filter: true, resizable: true },
    { headerName: 'BusinessElementName', field: '8', sortable: true, filter: true, resizable: true },
    { headerName: 'Consruction Logic', field: '9', sortable: true, filter: true, resizable: true },
    { headerName: 'ScheduleProduct', field: '10', sortable: true, filter: true, resizable: true },
    { headerName: 'DataAttribute', field: '11', sortable: true, filter: true, resizable: true, editable: true },
    { headerName: 'ScheduleOwner', field: '12', sortable: true, filter: true, resizable: true },
    { headerName: 'AllowableValues', field: '13', sortable: true, filter: true, resizable: true },
    { headerName: 'AdditionalRequirementInformation', field: '14', sortable: true, filter: true, resizable: true },
    { headerName: 'BusinessElementDefination', field: '15', sortable: true, filter: true, resizable: true },
    { headerName: 'BusinessTranslation', field: '16', sortable: true, filter: true, resizable: true },
    { headerName: 'Status', field: '17', sortable: true, filter: true, resizable: true },
    { headerName: 'StandardizationLogic', field: '18', sortable: true, filter: true, resizable: true },
    { headerName: 'BusinessAttribute', field: '19', sortable: true, filter: true, resizable: true },
    { headerName: 'Table Name', field: '20', sortable: true, filter: true, resizable: true },
    { headerName: 'AxiomShorthandTransformationLogic', field: '21', sortable: true, filter: true, resizable: true },
    { headerName: 'DataSourcingTransformation', field: '22', sortable: true, filter: true, resizable: true },
    { headerName: 'DataProviderInterpretation', field: '23', sortable: true, filter: true, resizable: true },
    { headerName: 'StandardStagingTable', field: '24', sortable: true, filter: true, resizable: true },
    { headerName: 'StandardStagingField', field: '25', sortable: true, filter: true, resizable: true },
    { headerName: 'DataAttributeDefination', field: '26', sortable: true, filter: true, resizable: true },
    { headerName: 'Source', field: '27', sortable: true, filter: true, resizable: true },
  ];
  rowDataTab: any;
  selectedIndex;
  //end
  constructor(private apiService: ApiService, private http: HttpClient, private ogmaService: OgmaService, private _formBuilder: FormBuilder) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit() {
    this.getAttributesList();
    this.isDisabled = true;
    this.editAttForm = this._formBuilder.group({
      ReportName: [{ value: '', disabled: this.isDisabled }],
      ScheduleName: [{ value: '', disabled: this.isDisabled }, Validators.required],
      MDRM: [{ value: '', disabled: this.isDisabled }, Validators.required],
      ReportingLine: [{ value: '', disabled: this.isDisabled }, Validators.required],
      ReportingInstruction: [{ value: '', disabled: this.isDisabled }, Validators.required],
      ID: [{ value: '', disabled: this.isDisabled }, Validators.required],
      BussinessRequirements: [{ value: '', disabled: this.isDisabled }, Validators.required],
      FAQReference: [{ value: '', disabled: this.isDisabled }, Validators.required],
      BusinessElementName: [{ value: '', disabled: this.isDisabled }, Validators.required],
      ConsructionLogic: [{ value: '', disabled: this.isDisabled }, Validators.required],
      ScheduleProduct: [{ value: '', disabled: this.isDisabled }, Validators.required],
      DataAttribute: [{ value: '', disabled: this.isDisabled }, Validators.required],
      ScheduleOwner: [{ value: '', disabled: this.isDisabled }, Validators.required],
      AllowableValues: [{ value: '', disabled: this.isDisabled }, Validators.required],
      AdditionalRequirementInformation: [{ value: '', disabled: this.isDisabled }, Validators.required],
      BusinessElementDefination: [{ value: '', disabled: this.isDisabled }, Validators.required],
      BusinessTranslation: [{ value: '', disabled: this.isDisabled }, Validators.required],
      Status: [{ value: '', disabled: this.isDisabled }, Validators.required],
      StandardizationLogic: [{ value: '', disabled: this.isDisabled }, Validators.required],
      BusinessAttribute: [{ value: '', disabled: this.isDisabled }, Validators.required],
      TableName: [{ value: '', disabled: this.isDisabled }, Validators.required],
      AxiomShorthandTransformationLogic: [{ value: '', disabled: this.isDisabled }, Validators.required],
      DataSourcingTransformation: [{ value: '', disabled: this.isDisabled }, Validators.required],
      DataProviderInterpretation: [{ value: '', disabled: this.isDisabled }, Validators.required],
      StandardStagingTable: [{ value: '', disabled: this.isDisabled }, Validators.required],
      StandardStagingField: [{ value: '', disabled: this.isDisabled }, Validators.required],
      DataAttributeDefination: [{ value: '', disabled: this.isDisabled }, Validators.required],
      Source: [{ value: '', disabled: this.isDisabled }, Validators.required],
    });

    this.ogmaService.initConfig({
      options: {
        backgroundColor: 'rgb(240, 240, 240)',
        minimumHeight: 400,
        minimumWidth: 1300,
      }
    }
    );


    this.ogmaService.ogma.events.onHover(({ x, y, target }: HoverEvent) => {
      if (target.isNode) {
        // save the tooltip state (offset by 20px the vertical position)
        this.hoveredContent = {
          id: target.getId(),
          data: target.getData()
        };
        this.hoveredPosition = { x, y: y + 40 };
      }
    });

    this.ogmaService.ogma.events.onUnhover((_: HoverEvent) => {
      // clear the tooltip state
      this.hoveredContent = null;
    });
  }

  getAttributesList() {
    this.apiService.getAttributeList().subscribe((data: AttributeData[]) => {
      this.attributeData = data;
      this.attributeData.sort((a, b) => a.attributeName.localeCompare(b.attributeName));
      // this.apiService.getHomeSummaryAnalytics().subscribe((data: Summary) => {
      //   this.rowData = data;
      // })
    })
  }

  // getAttributeMetrics(attributeName){
  //   this.attributeName = attributeName;
  //   this.rowData="";
  //   this.apiService.getAttributeMetrics(attributeName).subscribe((data: AttributeSummary) => {
  //     this.attributeSummary = data;
  //   })
  // }
  modalClicked() {
    this.displayModal = !this.displayModal;
  }

  onEditButtonClick(params) {
    this.attView = params.data;
    localStorage.setItem("attViewOld", JSON.stringify(this.attView));
    this.displayModal = !this.displayModal;
  }

  updateModal() {
    console.log(JSON.parse(localStorage.getItem('attViewOld')));
    this.apiService.updateAttributeSumDataAtt(JSON.parse(localStorage.getItem('attViewOld')), this.attView).subscribe((data: any) => {
      console.log("updated");
    });
    this.selectedIndex = this.selectedIndex - 1;
    this.displayModal = !this.displayModal;
  }
  editForm() {
    this.isDisabled = !this.isDisabled;
    const state = this.isDisabled ? 'disable' : 'enable';
    Object.keys(this.editAttForm.controls).forEach((controlName) => {
      if (controlName != 'ReportName' && controlName != 'ScheduleName' && controlName != 'MDRM' && controlName != 'ID'
        && controlName != 'ReportingLine' && controlName != 'AxiomShorthandTransformationLogic' && controlName != 'ReportingLine'
        ) {
        this.editAttForm.controls[controlName][state]();
      }
      // disables/enables each form control based on 'this.formDisabled'
    });
  }
  getTableDetailsByAttribute(attributeName) {
    this.attributeName = attributeName;
    this.apiService.getTableDetailByAttribute(this.attributeName).subscribe((data: any) => {
      this.items = [];
      for (let i = 0; i < data.length; i++) {
        this.items.push(data[i]._fields);
      }
      this.rowDataTab = this.items;
      this.DisplayAll();
    });
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  onBtnExport() {
    this.gridApi.exportDataAsCsv();
  }

  // onCellValueChanged(event) {
  //   var header = event.colDef.headerName;
  //   var oldValue = event.oldValue;
  //   var newValue = event.newValue;
  //   var data = event.data;
  //   if (header == 'Source') {
  //     //call Souce update API  updateAttributeSumSource
  //     this.apiService.updateAttributeSumSource(this.attViewOld, this.attView).subscribe((data: any) => {
  //       console.log("updated");
  //     });
  //   } else if (header == 'DataAttribute') {
  //     //call attribute update API updateAttributeSumDataAtt
  //     this.apiService.updateAttributeSumDataAtt(this.attViewOld, this.attView).subscribe((data: any) => {
  //       console.log("updated");
  //     });
  //   }
  //   console.log(event);
  //   // handle the rest here
  // }

  onReset() {
    this.attributeData = [];
    this.getAttributesList();
    this.attributeSummary = new AttributeSummary();
    this.attributeName = "";
    this.rowData = [];
  }

  onTabClick(event) {
    if (event.index === 0) {
      this.DisplayAll();
    } else {
      this.getTableDetailsByAttribute(this.attributeName);
    }

  }
  zoomIn(){
    this.ogmaService.ogma.view.zoomIn({ duration: 200 }).then(function () { console.log('zoom done') });
}
 zoomOut() {
  this.ogmaService.ogma.view.zoomOut({ duration: 200 }).then(function () { console.log('zoom done') });
}

  public DisplayAll() {
    this.apiService.GetGraphValuesForAttributeSummarypage(this.attributeName).subscribe((data: RawGraph) => {
      this.ogmaService.ogma.setGraph(data);
      return this.runLayout();
    });

  }
  public ResetGraph() {
    this.ogmaService.ogma.clearGraph();
  }


  public runLayout(): Promise<void> {
    return this.ogmaService.runLayout(this.currentLayout);
  }

  /**
   * Ogma container must be set when content is initialized
   */
  ngAfterContentInit() {
    this.ogmaService.ogma.setContainer(this.container.nativeElement);
    return this.runLayout();
  }
}

export class AttributeData {
  rowID: number;
  attributeName: string
}

export class AttributeSummary {
  report: number;
  source: number;
  schedule: number;
  reportingLine: number;
  dataConcept: number;
  dataElement: number;
}

export class Summary {
  reportName: string;
  scheduleName: string;
  reportLine: number;
  reportLineDes: string;
  gap: number;
  businessElementName: string;
}

export class AttForm {
  ReportName: string
  ScheduleName: string
  ScheduleProduct: string
  ScheduleOwner: string
  MDRM: string
  ReportingLine: string
  ReportingInstruction: string
  AllowableValues: string
  FAQReference: string
  ID: string
  BussinessRequirements: string
  AdditionalRequirementInformation: string
  BusinessElementName: string
  BusinessElementDefination: string
  ConsructionLogic: string
  BusinessTranslation: string
  Status: string
  DSTLogic: string
  AxiomShorthandTransformationLogic: string
  BusinessAttribute: string
  DataAttribute: string
  TableName: string
  DataProviderName: string
  // Gap_No: string
  // Conf_Analysis: string
  // Conf_Analysis_review: string
  // GapMatchCategory: string
  Source: string
}

