import { Component, OnInit } from '@angular/core';
import { ApiService } from '../shared-service/api.service';
import { saveAs } from 'file-saver';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-excel',
  templateUrl: './excel.component.html',
  styleUrls: ['./excel.component.css']
})
export class ExcelComponent implements OnInit {
  selectedFileBLOB:any;
  constructor(private apiService: ApiService,private sanitizer: DomSanitizer) { }

  ngOnInit() {

    this.apiService.downloadExcel("data").subscribe((data: any) => {

      // const reader = new FileReader();
      // reader.onload = (e: any) => {
     
		  // const blob = new Blob(data, { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      // var url = window.URL.createObjectURL(blob);

      // //  this.selectedFileBLOB = this.sanitizer.bypassSecurityTrustUrl(url);
      // const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      // };
      // reader.readAsDataURL(this.selectedFileBLOB);
    // reader.readAsArrayBuffer(data)
  // this.downloadFile(data);
     // this.displayExcel();
     //Excel.Workbooks.Open("E:\\test.xlsx");
    });

    this.OpenAnExternalFile()
  }

  downloadFile(data: any) {
    const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
   
    //const file  = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
   //  const url = window.URL.createObjectURL(blob);

   // const file = new File([blob], 'test' + '.xlsx', { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  //  saveAs(file);
  //var blob = new Blob([this.response], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
  var url = window.URL.createObjectURL(blob);
  window.location.href = url;
 // var w = window.open(url,'_blank');
//  window.location.href = "C:\\CITI\\Excel_Changes\\Node\\FFIEC002_202006_f-converted_result.xlsx";
 // window.open("C:\\CITI\\Excel_Changes\\Node\\FFIEC002_202006_f-converted_result.xlsx");
  }

  displayExcel() {
    var request = new XMLHttpRequest();
    request.open("GET", "test.xls");
    request.responseType = "blob";
    
    
    request.onload = function () {
      // set `blob` `type` to `"text/html"`
      var blob = new Blob([this.response], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
      var url = URL.createObjectURL(blob);
      
      var w = window.open(url,'_blank');
      window.focus();
    }
    request.send();
  }

  OpenAnExternalFile (){
   // const URL = encodeURIComponent('C:/CITI/Excel_Changes/Node/FFIEC002_202006_f-converted_result.xlsx')
   // var URL = 'C:/CITI/Excel_Changes/Node?filename='+encodeURIComponent('FFIEC002_202006_f-converted_result.xlsx');
   //const URL = encodeURIComponent('/assets/FFIEC002_202006_f-converted_result.xlsx')
  // window.open(URL,'_blank');

  
		var objExcel;
                //Create EXCEL object
		objExcel = new ActiveXObject("Excel.Application");
		objExcel.Visible = true;
		objExcel.Workbooks.Open('C:/CITI/Excel_Changes/Node/FFIEC002_202006_f-converted_result.xlsx', false, false);

  }
}
