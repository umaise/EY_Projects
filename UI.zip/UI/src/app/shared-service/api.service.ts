import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataGap } from '../data-gap/data-gap.component';


@Injectable({
  providedIn: 'root'
})
export class ApiService {
  token: any;
  private SERVER_URL = "http://localhost:3001";
  // private SERVER_URL = "https://13.90.155.173:3100";

  constructor(private httpClient: HttpClient) { }

  //   public get(){  
  // 		return this.httpClient.get(this.SERVER_URL +'/GetReportCount');  
  // }

  //Start of dashboard page
  getIndexSummary() {
    return this.httpClient.get(this.SERVER_URL + '/GetIndexSummaryStats');
  }


  getHomeSummaryAnalytics() {
    return this.httpClient.get(this.SERVER_URL + '/GetHomeSummaryAnalytics');
  }

  getHomeSummaryGapAnalytics() {
    return this.httpClient.get(this.SERVER_URL + '/GetHomeSummaryGapAnalytics');
  }

  //end of Dashboard page
  //Start of Report page
  getReportNames() {
    // const headers = new HttpHeaders(("Content-Type", "application/json");
    return this.httpClient.get(this.SERVER_URL + '/GetReportNames');
  }

  getSectionNamesFromReport(reportName) {
    // const headers = new HttpHeaders(("Content-Type", "application/json");
    const report = { reportName: reportName };
    return this.httpClient.post(this.SERVER_URL + '/GetReportSectionNamesForReport', report);
  }

  getDataGapValues(reportName: string, reportSectionName: string, lineItem: string, gapCategory: string, gap: string) {
    const report = { reportName: reportName, reportSectionName: reportSectionName, lineItem: lineItem, gapCategory: gapCategory, gap: gap };
    return this.httpClient.post(this.SERVER_URL + '/GetDataGapTable', report);
  }

  getLineItemsForSection(reportName: string, reportSectionName: string) {
    // const headers = new HttpHeaders(("Content-Type", "application/json");
    const report = { reportName: reportName, reportSectionName: reportSectionName };
    return this.httpClient.post(this.SERVER_URL + '/GetLineItemNamesForReportSection', report);
  }
  getGapCategory(reportName: string, reportSectionName: string, lineItem: string) {
    // const headers = new HttpHeaders(("Content-Type", "application/json");
    const report = { reportName: reportName, reportSectionName: reportSectionName, lineItem: lineItem };
    return this.httpClient.post(this.SERVER_URL + '/GetGapCategory', report);
  }

  getGap(reportName: string, reportSectionName: string, lineItem: string, gapCategory: string) {
    // const headers = new HttpHeaders(("Content-Type", "application/json");
    const report = { reportName: reportName, reportSectionName: reportSectionName, lineItem: lineItem, gapCategory: gapCategory };
    return this.httpClient.post(this.SERVER_URL + '/GetGap', report);
  }

  getGapView(reportName: string, reportSectionName: string, lineItem: string, gapCategory: string, gap: string) {
    // const headers = new HttpHeaders(("Content-Type", "application/json");
    const report = { reportName: reportName, reportSectionName: reportSectionName, lineItem: lineItem, gapCategory: gapCategory, gap: gap };
    return this.httpClient.post(this.SERVER_URL + '/GetGapView', report);
  }
  updateGapView(dataGap: DataGap) {
    const dataGapObj = { Conf_Analysis: dataGap.Conf_Analysis, Conf_Analysis_review: dataGap.Conf_Analysis_review, GapMatchCategory: dataGap.GapMatchCategory, Gap_No: dataGap.Gap_No };
    return this.httpClient.post(this.SERVER_URL + '/updateGapView', dataGapObj);
  }
  //Get Report Card Info
  getReportCardInfo(reportName) {
    // const headers = new HttpHeaders(("Content-Type", "application/json");
    const report = { reportName: reportName };
    return this.httpClient.post(this.SERVER_URL + '/GetReportCardInfo', report);
  }

  getUpdateDataGapHistory() {
    // const headers = new HttpHeaders(("Content-Type", "application/json");
    const report = { reportName: "reportName" };
    return this.httpClient.post(this.SERVER_URL + '/GetUpdateDataGapHistory', report);
  }


  getTableViewDataReport(reportName) {
    const report = { reportName: reportName };
    return this.httpClient.post(this.SERVER_URL + '/GetTableDetailsFromReportName', report);
  }
  getTableViewDataSchedule(reportName, scheduleName) {
    const report = { reportName: reportName, scheduleName: scheduleName };
    return this.httpClient.post(this.SERVER_URL + '/GetTableDetailsFromReportAndSchedule', report);
  }
  getTableViewDataLineItem(reportName, scheduleName, lineItem) {
    const report = { reportName: reportName, scheduleName: scheduleName, lineItem: lineItem };
    return this.httpClient.post(this.SERVER_URL + '/GetTableDetailsFromReportAndScheduleAndLineItem', report);
  }


  getMetricDetailByReportName(reportName) {
    const report = { reportName: reportName };
    return this.httpClient.post(this.SERVER_URL + '/GetTileDetailsFromReportName', report);
  }

  getMetricDetailBySchedule(reportName, schedule) {
    const report = { reportName: reportName, scheduleName: schedule };
    return this.httpClient.post(this.SERVER_URL + '/GetTileDetailsFromReportAndSchedule', report);
  }

  getMetricDetailByLineItem(reportName, scheduleName, lineItem) {
    const report = { reportName: reportName, scheduleName: scheduleName, lineItem: lineItem };
    return this.httpClient.post(this.SERVER_URL + '/GetTileDetailsFromReportAndScheduleAndLineItem', report);
  }

  getLineItemDescription(reportName, scheduleName, lineItem) {
    const report = { reportName: reportName, scheduleName: scheduleName, lineItem: lineItem };
    return this.httpClient.post(this.SERVER_URL + '/GetLineDescription', report);
  }

  //get Donut graph
  getDonutCharDetails(reportName) {
    const report = { reportName: reportName };
    return this.httpClient.post(this.SERVER_URL + '/GetDonutChartDetails', report);
  }

  //end of Report summary page

  //Attribute Summary page
  getAttributeList() {
    return this.httpClient.get(this.SERVER_URL + '/GetAttributeSummaryDropDown');
  }

  getAttributeMetrics(attributeName) {
    const attribute = { attributeName: attributeName };
    return this.httpClient.post(this.SERVER_URL + '/GetTileDetailsForAttributeSummary', attribute);
  }

  getTableDetailByAttribute(attributeName) {
    const attribute = { attributeName: attributeName };
    return this.httpClient.post(this.SERVER_URL + '/GetTableDetailsFromAttributeName', attribute);
  }
  //End of Attribute summary page

  //Start of FAQ page
  getSchedule() {
    return this.httpClient.get(this.SERVER_URL + '/GetReportNames');
  }

  getFAQMetrics(scheduleName) {
    const faq = { scheduleName: scheduleName };
    return this.httpClient.post(this.SERVER_URL + '/GetTileDetailsForAttributeSummary', faq);
  }

  getTableDetailForFAQ(scheduleName) {
    const faq = { scheduleName: scheduleName };
    return this.httpClient.post(this.SERVER_URL + '/GetTableDetailsFromAttributeName', faq);
  }
  // GetGraphValuesForReportAnalyticspage(reportName, scheduleName, lineItem){
  //   const report ={reportName: reportName, scheduleName: scheduleName, lineItem: lineItem};
  //   return this.httpClient.post(this.SERVER_URL + '/GetGraphValuesForReportAnalyticspage', report);

  // }

  GetGraphValuesForReportAnalyticspage(reportName, scheduleName, lineItem) {
    const report = { reportName: reportName, scheduleName: scheduleName, lineItem: lineItem };
    return this.httpClient.post(this.SERVER_URL + '/GetGraphValuesForReportAnalyticspage', report);
  }
  GetGraphValuesForAttributeSummarypage(attributeName) {
    const attribute = { attributeName: attributeName };
    return this.httpClient.post(this.SERVER_URL + '/GetGraphValuesForAttributeSummarypage', attribute);
  }
  getReportingLineGapTable(reportName: string, scheduleName: string, reportingLine: string) {
    const report = { report_name: reportName, schedule_name: scheduleName, reporting_line: reportingLine };
    return this.httpClient.post(this.SERVER_URL + '/GetReportingLineGapTable', report);
  }
  getReportGapTable(reportName: string) {
    const report = { report_name: reportName };
    return this.httpClient.post(this.SERVER_URL + '/GetReportGapTable', report);
  }
  getScheduleGapTable(reportName: string, scheduleName: string) {
    const report = { report_name: reportName, schedule_name: scheduleName };
    return this.httpClient.post(this.SERVER_URL + '/GetScheduleGapTable', report);
  }
  getBussinessRulesValue() {
    return this.httpClient.get(this.SERVER_URL + '/GetBussinessRuleTable');
  }

  getTotalGapValue() {
    return this.httpClient.get(this.SERVER_URL + '/GetTotalGap');
  }

  getRemediationStatusValue() {
    return this.httpClient.get(this.SERVER_URL + '/GetRemediationStatus');
  }
  GetGraphValuesForDataspage(reportName, scheduleName, lineItem) {
    const report = { reportName: reportName, scheduleName: scheduleName, reportingLine: lineItem };
    return this.httpClient.post(this.SERVER_URL + '/GetGraphValuesDataGap', report);
  }
  isLoggedIn() {
    return this.token
  }
  login(usrname, password) {
    const login = { userName: usrname, password: password };
    return this.httpClient.post(this.SERVER_URL + '/CheckCredential', login);
  }
  getBalance() {
    return this.httpClient.get(this.SERVER_URL + '/GetOutstandingBalance');
  }
  getHistCard() {
    return this.httpClient.get(this.SERVER_URL + '/HistoryMetrics');
  }
  getHistTable() {
    return this.httpClient.get(this.SERVER_URL + '/HistoryTable');
  }


  getReportNamesDashboard() {
    return this.httpClient.get(this.SERVER_URL + '/HistoryReportDropdown');
  }


  getReportTab(reportName: string) {
    const report = { reportName: reportName };
    return this.httpClient.post(this.SERVER_URL + '/HistoryReportTable', report);
  }
  getScheduleHistTable(reportName, schedule) {
    const report = { reportName: reportName, scheduleName: schedule };
    return this.httpClient.post(this.SERVER_URL + '/HistoryScheduleTable', report);
  }

  getLineHistTable(reportName, scheduleName, lineItem) {
    const report = { reportName: reportName, scheduleName: scheduleName, lineItem: lineItem };
    return this.httpClient.post(this.SERVER_URL + '/HistoryLineItemTable', report);
  }

  getHistoryProductAlignment() {
    return this.httpClient.get(this.SERVER_URL + '/HistoryProductAlignment');
  }

  updateAttributeSumDataAtt(oldData, newData) {
    const updateObj = { oldData: oldData, newData: newData};
    return this.httpClient.post(this.SERVER_URL + '/updateAttributeSumDataAtt', updateObj);
  }

  updateAttributeSumSource(oldData, newData) {
    const updateObj = { oldData: oldData, newData: newData};
    return this.httpClient.post(this.SERVER_URL + '/updateAttributeSumSource', updateObj);
  }
  getHistoryChangeType() {
    return this.httpClient.get(this.SERVER_URL + '/HistoryChangeType');
  }
  getHistoryChangeRank() {
    return this.httpClient.get(this.SERVER_URL + '/HistoryChangeRank');
  }
  downloadExcel(data) {
    const dataObj = { data: data};
    return this.httpClient.post(this.SERVER_URL + '/retriveFile',dataObj,{ responseType: 'blob'} );
  }
  getdrilldowndatalevel1(mdrm: string) {
    const mdrmval = { mdrm: mdrm};
    return this.httpClient.post(this.SERVER_URL + '/GetDrillDownDataLevel1', mdrmval);
  }
  getdrilldowndatalevel2(mdrm: string) {
    const mdrmval = { mdrm: mdrm};
    return this.httpClient.post(this.SERVER_URL + '/GetDrillDownDataLevel2', mdrmval);
  }
  getVarianceReport() {
    return this.httpClient.get(this.SERVER_URL + '/GetVarianceAnalysisReport');
  }
}