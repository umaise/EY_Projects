import { Component, OnInit, ViewEncapsulation, Inject, ViewChild, AfterViewInit, OnChanges, AfterViewChecked, AfterContentInit, AfterContentChecked } from '@angular/core';
//import { getDefaultData } from './data';
import { ApiService } from '../shared-service/api.service';
import { SpreadSheetsModule } from '@grapecity/spread-sheets-angular';
import * as ExcelIO from "@grapecity/spread-excelio";
import GC from '@grapecity/spread-sheets';
declare var saveAs: any;

const spreadNS = GC.Spread.Sheets, SheetArea = spreadNS.SheetArea;
@Component({
    selector: 'app-sheet',
    templateUrl: './sheet.component.html',
    styleUrls: ['./sheet.component.css']
})

export class SheetComponent implements OnInit, AfterViewChecked {
    spread: GC.Spread.Sheets.Workbook;
    items: any;
    importExcelFile: any;
    gridApi;
    gridColumnApi;
    exportFileName = "result.xlsx";
    blob: any;
    a:any;
    mdrmValue: any;
    mdrmLable: any;
    sheetName: any;
    currentSheet: any;
    dataRetrieved: boolean = true;
    hostStyle = {
        width: 'calc(100% - 280px)',
        height: '100%',
        overflow: 'hidden',
        float: 'left'
    };
    showLevel1: boolean = false;
    showLevel2: boolean = false;
    displayIcon: any;
    showOverlay:boolean = false;
    enableButton:boolean = true;
    rowOneData: any;
    rowTwoData: any;

    columnOneDefs = [
        { headerName: 'Ledger Account', field: 'Ledger_Account', sortable: true, filter: true, resizable: true },
        { headerName: 'Balance', field: 'Balance', sortable: true, filter: true, resizable: true }
    ];

    columnTwoDefs = [
        { headerName: 'Company', field: 'Company', sortable: true, filter: true, resizable: true },
        { headerName: 'Ledger Account', field: 'Ledger_Account', sortable: true, filter: true, resizable: true },
        { headerName: 'Journal Source', field: 'Journal_Source', sortable: true, filter: true, resizable: true },
        { headerName: 'Customer', field: 'Customer', sortable: true, filter: true, resizable: true },
        { headerName: 'Counterparty Domicile', field: 'Counterparty_Domicile', sortable: true, filter: true, resizable: true },
        { headerName: 'Counterparty Sector', field: 'Counterparty_Sector', sortable: true, filter: true, resizable: true },
        { headerName: 'Counterparty Name', field: 'Counterparty_Name', sortable: true, filter: true, resizable: true },
        { headerName: 'Balance', field: 'balance', sortable: true, filter: true, resizable: true },
        { headerName: 'Source File Name', field: 'Source_File_Name', sortable: true, filter: true, resizable: true },
        { headerName: 'Start Time', field: 'Start_Time', sortable: true, filter: true, resizable: true },
    ];


    constructor(private apiService: ApiService) { }
    ngOnInit() {
        this.apiService.downloadExcel("data").subscribe((data: any) => {
            // this.blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            this.blob = data;
            this.importExcelFile = this.blob;
            // this.importExcelFile = 'C:/CITI/Excel_Changes/Node/FFIEC002_202006_f-converted_result.xlsx';
            this.loadExcel();
            
        });
        // this.spread = new GC.Spread.Sheets.Workbook(document.getElementById('ss'), { calcOnDemand: true });
        // this.spread.bind(GC.Spread.Sheets.Events.SheetTabClick, function (e: any, args: any) {
        //     this.getOutstandingBalance();
        // });
              
    }

    onGridReadyLevelOne(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        params.api.sizeColumnsToFit() 
    }
    onGridReadyLevelTwo(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }

    initSpread() {
        this.spread = GC.Spread.Sheets.findControl(document.getElementById('ss'));
        let spread = this.spread;
        //spread.options.calcOnDemand = true;
        //this.spread.bind(GC.Spread.Sheets.Events.SheetTabClick, function (e: any, args: any) {
      //  this.getOutstandingBalance();
        //});
    }



    getvarianceanalysis() {
        this.apiService.getVarianceReport().subscribe((data: any) => {
            var spread2 =  GC.Spread.Sheets.findControl(document.getElementById('ss'));
            console.log(spread2);
            console.log(spread2.getSheetCount());
            var activeSheet = spread2.getSheet(spread2.getSheetCount() - 1);
            //var activeSheet = spread2.getSheetFromName('Variance Analysis Report');
            spread2.suspendPaint();
            console.log(activeSheet);
            var actual_JSON = data;
            console.log(actual_JSON);
            var MDRM = { name: "mdrm", displayName: "MDRM", size: "150" };
            var Previous_Quarter_1 = { name: "Previous_Quarter_1", displayName: "Previous_Quarter_1", size: "150" };
            var Previous_Quarter_2 = { name: "Previous_Quarter_2", displayName: "Previous_Quarter_2", size: "150" };
            var Previous_Quarter_3 = { name: "Previous_Quarter_3", displayName: "Previous_Quarter_3", size: "150" };
            var Previous_Quarter_4 = { name: "Previous_Quarter_4", displayName: "Previous_Quarter_4", size: "150" };
            // activeSheet.setRowCount(50, GC.Spread.Sheets.SheetArea.viewport);
            // activeSheet.setColumnCount(50, GC.Spread.Sheets.SheetArea.viewport);
            activeSheet.autoGenerateColumns = true;
            activeSheet.autoFitRow(0)
            activeSheet.setDataSource(actual_JSON);
 
            activeSheet.bindColumn(0, MDRM);
            activeSheet.bindColumn(1, Previous_Quarter_1);
            activeSheet.bindColumn(2, Previous_Quarter_2);
            activeSheet.bindColumn(3, Previous_Quarter_3);
            activeSheet.bindColumn(4, Previous_Quarter_4);
            activeSheet.addRows(activeSheet.getRowCount(SheetArea.viewport), 1);
            spread2.resumePaint();
        });
    }

    loadExcel() {
        // console.log(GC.Spread.Sheets.Workbook);
        let spread = new GC.Spread.Sheets.Workbook(document.getElementById('ss'), { calcOnDemand: true });
        localStorage.setItem("instance", JSON.stringify(spread));
        let excelIo = new ExcelIO.IO();
        let excelFile = this.importExcelFile;
        // here is excel IO API
        excelIo.open(excelFile, function (json: any) {
            let workbookObj = json;
            console.log(json)
            spread.fromJSON(workbookObj);
            // this.getOutstandingBalance();
        }, function (e: any) {
            // process error
            //  console.log(e)
            //  alert(e.errorMessage);
        });
    }

    saveExcel(e: any) {
        var spread1 = GC.Spread.Sheets.findControl(document.getElementById('ss'));
        var jsonString = spread1.toJSON(serializationOption);
        var serializationOption = {
            includeBindingSource: true, // include binding source when converting the workbook to json, default value is false
            ignoreStyle: false, // ignore styles when converting workbook to json, default value is false
            ignoreFormula: false, // ignore formulas when converting workbook to json, default value is false
            saveAsView: false, //include the format string formatting result when converting workbook to json, default value is false
            rowHeadersAsFrozenColumns: false, // treat row headers as frozen columns when converting workbook to json, default value is false
            columnHeadersAsFrozenRows: false, // treat column headers as frozen rows when converting workbook to json, default value is false
            includeAutoMergedCells: false // include the automatically merged cells to the real merged cells when converting the workbook to json.
        }
        let fileName = this.exportFileName;

        if (fileName.substr(-5, 5) !== '.xlsx') {
            fileName += '.xlsx';
        }

        this.blob = new Blob([JSON.stringify(jsonString)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        let excelIo = new ExcelIO.IO();
        excelIo.save(JSON.stringify(jsonString), function (blob) {
            //do whatever you want with blob
            //such as you can save it
            saveAs(blob, fileName);
        }, function (e) {
            //process error
            console.log(e);
        });
        // this.apiService.saveFile(jsonString).subscribe((data: any) => {
        //     console.log("save file successfully" + data)
        // });
    }

    onBtnExport() {
        this.gridApi.exportDataAsCsv();
      }

      onBtnExport2() {
        this.gridApi.exportDataAsCsv();
      }

    getOutstandingBalance() {
        this.apiService.getBalance().subscribe((data: any) => {
            var spread1 = GC.Spread.Sheets.findControl(document.getElementById('ss'));
            console.log(spread1.getSheetCount());
            var activeSheet = spread1.getSheet(spread1.getSheetCount() - 1);
            spread1.suspendPaint();
            var actual_JSON = data;
            console.log(actual_JSON);
            var mdrm = { name: "mdrm", displayName: "Mdrm", size: "150" };
            var sum = { name: "sum", displayName: "Sum", size: "110" };
            var schedule = { name: "Schedule", displayName: "Schedule", size: "100" };
            // activeSheet.setRowCount(50, GC.Spread.Sheets.SheetArea.viewport);
            // activeSheet.setColumnCount(50, GC.Spread.Sheets.SheetArea.viewport);
            activeSheet.autoGenerateColumns = true;
            activeSheet.autoFitRow(0)
            activeSheet.setDataSource(actual_JSON);
            activeSheet.bindColumn(0, mdrm);
            activeSheet.bindColumn(1, sum);
            activeSheet.bindColumn(2, schedule);
            activeSheet.addRows(activeSheet.getRowCount(SheetArea.viewport), 1);
            spread1.resumePaint();
            // spread1.addSheet(34,activeSheet);
        });
    }

    formatSpread(activeSheet) {
        for (var i = 0; i < activeSheet.getRowCount(); i++) {
            //activeSheet.getColumn(0).wordWrap(true);
            activeSheet.getRow(i).font("12pt arial");
            activeSheet.setRowHeight(i, 210);
            activeSheet.getRow(i).borderBottom(new GC.Spread.Sheets.LineBorder("Green", GC.Spread.Sheets.LineStyle.thick));
            if (activeSheet.getValue(i, 9) != null) {
                var carImage = activeSheet.getValue(i, 9);
                activeSheet.setValue(i, 9, null);
                activeSheet.getCell(i, 9).backgroundImage(carImage);
            }
            activeSheet.getRow(i).vAlign(GC.Spread.Sheets.VerticalAlign.center);
            activeSheet.getRow(i).hAlign(GC.Spread.Sheets.HorizontalAlign.center);
        }

        var cellRange = new GC.Spread.Sheets.Range(0, 0, activeSheet.getRowCount(), 10);
        // var hideRowFilter = new GC.Spread.Sheets.HideRowFilter(cellRange);
        // activeSheet.rowFilter(hideRowFilter);

        activeSheet.setRowCount(2, GC.Spread.Sheets.SheetArea.colHeader);
        activeSheet.getColumn(0).borderRight(new GC.Spread.Sheets.LineBorder("Green", GC.Spread.Sheets.LineStyle.thin));
        activeSheet.setRowHeight(0, 30, GC.Spread.Sheets.SheetArea.colHeader);
        activeSheet.addSpan(0, 1, 1, 2, GC.Spread.Sheets.SheetArea.colHeader);
        activeSheet.getCell(0, 1, GC.Spread.Sheets.SheetArea.colHeader).value("Fuel Economy & Acceleration");
        activeSheet.colRangeGroup.group(1, 2);
        activeSheet.getColumn(2).borderRight(new GC.Spread.Sheets.LineBorder("Green", GC.Spread.Sheets.LineStyle.thin));
        activeSheet.addSpan(0, 3, 1, 3, GC.Spread.Sheets.SheetArea.colHeader);
        activeSheet.getCell(0, 3, GC.Spread.Sheets.SheetArea.colHeader).value("Engine Details");
        activeSheet.addSpan(0, 6, 1, 4, GC.Spread.Sheets.SheetArea.colHeader);
        activeSheet.getCell(0, 6, GC.Spread.Sheets.SheetArea.colHeader).value("Car Details");
        activeSheet.getColumn(5).borderRight(new GC.Spread.Sheets.LineBorder("Green", GC.Spread.Sheets.LineStyle.thin));
        activeSheet.setRowHeight(1, 30, GC.Spread.Sheets.SheetArea.colHeader);
        var headerStyle = new GC.Spread.Sheets.Style();
        headerStyle.backColor = "Green";
        headerStyle.foreColor = "White";
        headerStyle.hAlign = GC.Spread.Sheets.HorizontalAlign.center;
        headerStyle.vAlign = GC.Spread.Sheets.VerticalAlign.center;

        for (var i = 0; i < activeSheet.getColumnCount(); i++) {
            activeSheet.setStyle(0, i, headerStyle, GC.Spread.Sheets.SheetArea.colHeader);
            activeSheet.setStyle(1, i, headerStyle, GC.Spread.Sheets.SheetArea.colHeader);
        }
    }

    ngAfterViewChecked() {
        if (this.dataRetrieved) {
            this.spread = GC.Spread.Sheets.findControl(document.getElementById('ss'));
            let spread = this.spread;
            //var sheet = spread.getActiveSheet();
           // this.getOutstandingBalance();
             this.getvarianceanalysis();  
            //spread.options.calcOnDemand = true;
            //this.spread.bind(GC.Spread.Sheets.Events.SheetTabClick, function (e: any, args: any) {         
            //});
            spread.bind(spreadNS.Events.ActiveSheetChanged, function (e: any, args: any) {
                this.eventLog =
                    'SpreadEvent: ' + GC.Spread.Sheets.Events.ActiveSheetChanged + ' event called' + '\n' +
                    'oldSheetName: ' + args.oldSheet.name() + '\n' +
                    'newSheetName: ' + args.newSheet.name();                     
                    
                    if(this.eventLog !=null){
                        localStorage.setItem("sheetChanged", "true");
                    }
            });


            spread.bind(spreadNS.Events.CellClick, function (e: any, args: any) {
                (<HTMLInputElement> document.getElementById("filter-btn")).disabled = true;
                let sheetArea = args.sheetArea === 0 ? 'sheetCorner' : args.sheetArea === 1 ? 'columnHeader' : args.sheetArea === 2 ? 'rowHeader' : 'viewPort';
                this.eventLog =
                    'SpreadEvent: ' + GC.Spread.Sheets.Events.CellClick + ' event called' + '\n' +
                    'sheetArea: ' + sheetArea + '\n' +
                    'row: ' + args.row + '\n' +
                    'col: ' + args.col;
                console.log("Inside cell click event..." + GC.Spread.Sheets.Events.CellClick, this.eventLog);

                // this.sheet1= localStorage.getItem("currentsheet");
                // console.log(this.sheet1.getCell(args.row,args.col).getValue());
                //console.log(this.sheet1);

                this.currentSheet = args.sheetName;
                // if(this.currentSheet === 'Sch A'){
                //     const buttonModal = document.getElementById("openModalButton")
                //     buttonModal.click();
                // }
                this.mdrmValue = args.sheet.getValue(args.row, args.col - 1);
                this.displayIcon= args.sheet.getValue(args.row, args.col);
                this.a=this.displayIcon.toString();
                // if (args.col === 1 || args.col === 2) {
                //     this.mdrmLable = 'RCFD00' + this.mdrmValue;
                // }
                // else {
                //     this.mdrmLable = 'RCFN00' + this.mdrmValue;
                // }
                localStorage.setItem("mdrm", this.mdrmValue);
                localStorage.setItem("displayIcon", this.displayIcon);
                console.log("r.c ", args.sheet.getValue(args.row, args.col-1));
                console.log("value", args.sheet.getValue(args.row, args.col));

             var pattern = /^[0-9]+(\.[0-9]+){0,3}$/;
             var value = this.a.match(pattern)[1];
             console.log(this.a.match(pattern))
            if(value != null){                
                if(this.displayIcon != 0 && this.displayIcon != null){
                    // if(localStorage.getItem("sheetChanged") === "true"){
                    (<HTMLInputElement> document.getElementById("filter-btn")).disabled = false;                   
                // }
            }
            }
            });
            this.dataRetrieved = true; 
        }    
        
    }


    getLevelOneData() {
        var MDRM = 'RCFD2151'
        console.log(localStorage.getItem("mdrm"));
        this.showLevel1 = !this.showLevel1;
        this.showLevel2 = false;
        this.apiService.getdrilldowndatalevel1(localStorage.getItem("mdrm")).subscribe((data: any) => {
          this.rowOneData = data;
        });
    }

    getLevelTwoData() {
        var MDRM = 'RCFD2151'
        console.log(localStorage.getItem("mdrm"));
        this.showLevel1 = false;
        this.showLevel2 = !this.showLevel2;        
        this.apiService.getdrilldowndatalevel2(localStorage.getItem("mdrm")).subscribe((data: any) => {
            this.rowTwoData = data;
        });
    }

    canceldrill(){
        this.showLevel1 = false;
        this.showLevel2 = false;
        (<HTMLInputElement> document.getElementById("filter-btn")).disabled = true;
    }
}