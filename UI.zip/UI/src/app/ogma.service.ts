import { Injectable } from '@angular/core';
import Ogma, { RawGraph, RendererType, Options, CrossOriginValue, NodeAttributesValue, RawNode, RawEdge } from 'ogma';



interface OgmaParameters {
    dimensions?: {
        width?: number;
        height?: number;
    };
    renderer?: RendererType;
    options?: Options;
    container?: HTMLElement | string;
    graph?: RawGraph;
    imgCrossOrigin?: CrossOriginValue;
    attributes?: NodeAttributesValue;
    
}

const nodeIcons = {
    Function: {
        color: '#1b9e77',
        name: 'far fa-database',
        uni: '\uf1c0',
        label_name: 'Function'
    },
    Schedule: {
       // color: '#4286f4',
       color: '#00a3ae',
        name: 'fas fa-table',
        uni: '\uf0ce',
        label_name: 'Schedule'
    },
    Attribute: {
        color: '#d95f02',
        name: 'far fa-cogs',
        uni: '\uf085',
        label_name: 'attribute'
    },
    REPORTINGLINE: {
        color: 'rgb(166, 118, 29)',
        name: 'fa fa-list',
        uni: '\uf03a',
        label_name: 'REPORTINGLINE'
    },
    Source: {
        color: '#ffe600',
        name: 'fa fa-receipt',
        uni: '\uf111',
        label_name: 'source'
    },
    Report: {
        color: '#e7298a',
        name: 'fab fa-wpforms',
        uni: '\uf15c',
        label_name: 'Report'
    },
    FAQ_Derived: {
        color: '#d95f02',
        name: 'fa fa-user',
        uni: '\uf007',
        label_name: 'FAQ_Derived'
    },
    ProcessGroup: {
        color: '#8b9cb7',
        name: 'fa fa-table',
        uni: '\uf0ce',
        label_name: 'ProcessGroup'
    },
    LOB: {
        color: '#63c2de',
        name: 'fa fa-wrench',
        uni: '\uf111',
        label_name: 'LOB'
    },
    DataConcept: {
        color: '#1b9e77',
        name: 'far fa-database',
        uni: '\uf1c0',
        label_name: 'DataConcept'
    },
    DatabridgePhysicalAttributeName: {
        color: '#8b9cb7',
        name: 'fa fa-table',
        uni: '\uf0ce',
        label_name: 'DatabridgePhysicalAttributeName'
    },
    GoldenSource: {
        color: '#63c2de',
        name: 'fa fa-wrench',
        uni: '\uf111',
        label_name: 'GoldenSource'
    },
    Process: {
        color: '#1b9e77',
        name: 'far fa-database',
        uni: '\uf1c0',
        label_name: 'Process'
    },
    DataDomain: {
        color: '#1b9e77',
        name: 'far fa-database',
        uni: '\uf1c0',
        label_name: 'DataDomain'
    },
    DataElement: {
        color: '#1b9e77',
        name: 'far fa-database',
        uni: '\uf1c0',
        label_name: 'DataElement'
    },
    brid: {
        color: '#1b9e77',
        name: 'far fa-database',
        uni: '\uf1c0',
        label_name: 'DataElement'
    },
    Data_Source: {
        color: '#fff27f',
        name: 'far fa-database',
        uni: '\uf187',
        label_name: 'Data_Source'
    }
    ,
    Data_Attributes: {
        color: '#91278f',
        name: 'fas fa-database',
        uni: '\uf1c0',
        label_name: 'Data_Provider_Name'
    }
    ,
    Business_Attributes: {
        color: '#2c973e',
        name: 'fas fa-cogs',
        uni: '\uf013',
        label_name: 'Business_Attributes'
    }
    ,
    MDRM: {
        // color: '#ff3300',
        color: '#336699',
        name: 'fas fa-passport',
        uni: '\uf5ab',
        label_name: 'MDRM'
    },
    Business_Rule: {
        color: '#ac98db',
        name: 'far fa-list-alt',
        uni: '\uf022',
        label_name: 'Business_Rule'
    },
    Gap_No: {
        color: '#900C3F',
        name: 'far fa-list-alt',
        uni: '\uf022',
        label_name: 'Gap_No'
    },
    StandardModel: {
        color: '#bd470d',
        name: 'far fa-list-alt',
        uni: '\uF0b1',
        label_name: 'StandardModel'
    },
    Axiom: {
        color: '#52e366',
        name: 'far fa-list-alt',
        uni: '\uF19c',
        label_name: 'Axiom'
    },
    Staging: {
        color: '#74ccf4',
        name: 'far fa-list-alt',
        uni: '\uf022',
        label_name: 'Staging'
    }
};

@Injectable()
export class OgmaService {
    // expose an instance of Ogma from the service
    public ogma: Ogma;
    public byCountry;    

    public initConfig(configuration: OgmaParameters = {}) {
        this.ogma = new Ogma(configuration);
        this.ogma.styles.addRule({
            nodeAttributes: {
                text: {
                    content: (n) => {
                        if (n.getData('labels') != null) {
                            const label = n.getData('labels');
                            if (n.getData(label.toLowerCase()) !== 'undefined') {
                                if(label=="Data_Source"){
                                    return n.getData('Source');
                                }else if(label=="Data_Attributes"){
                                    return n.getData('data_attribute');
                                }else if(label=="Business_Attributes"){
                                    return n.getData('BusinessElementName');
                                }else if(label=="Business_Rule"){
                                    return n.getData('id');
                                }else if(label=="MDRM"){
                                   return n.getData('mdrm');
                                }else if(label=="Schedule"){
                                    return n.getData('schedule');
                                }else if(label=="Report"){
                                    return n.getData('report');
                                }else if(label=="Gap_No"){
                                    return n.getData('Gap_No');
                                }else if(label=="StandardModel"){
                                return n.getData('FactField');
                                 }else if(label=="Axiom"){
                                 return n.getData('AxiomField');
                                }else if(label=="Staging"){
                                    return n.getData('StandardStagingField');
                                   }
                                else{
                                    return n.getData(label);
                                }    
                            }
                            return n.getData('name');
                        } else {
                            return n.getData('name');
                        }
                    }
                },
                icon: {
                    font: 'Font Awesome 5 Free',
                    color: (n) => {
                        console.log(n.getData('labels'));
                        if (n.getData('labels') != null && nodeIcons[n.getData('labels')].color != null) {
                            console.log(n.getData('labels')+"  -- "+n.getData('Conf_Analysis'));
                            if(n.getData('labels')=="Business_Attributes" && n.getData('Conf_Analysis')=="Gap"){
                                return '#ff0000';
                            }else{
                                return nodeIcons[n.getData('labels')].color;
                            }
                            
                        }
                        else {
                            return '#8b9cb7';
                        }
                    },
                    style: 'bold',
                    content: (n) => {
                        if (n.getData('labels') != null) {
                            return nodeIcons[n.getData('labels')].uni;
                        }
                    }
                },
                outerStroke: {
                    color: (n) => {
                        if (n.getData('labels') != null) {
                            if(n.getData('labels')=="Business_Attributes" && n.getData('Conf_Analysis')=="Gap"){
                                return '#ff0000';
                            }else{
                                return nodeIcons[n.getData('labels')].color;
                            }
                           
                        } else {
                            return 'black';
                        }
                    },
                    width: 10
                },
                color: 'white',
                opacity: (node) => {
                    return node.getData('open') ? 0.32 : undefined;
                },
            },
            edgeAttributes: {
                text: {
                    content: (e) => {
                        return e.getData('type');
                    }
                },
                shape: {
                    style: 'plain',
                    head: 'arrow',
                    tail: null
                }
            }
            
        });    
         
    }

    public runLayout(layout: string = 'force'): Promise<void> {
        return this.ogma.layouts[layout]({ locate: true });
    }
    public Transform() {
        this.ogma.transformations.addNodeGrouping({
            groupIdFunction: (node) => {
                return node.getData('labels');
            },
            nodeGenerator: (nodes, labels) => {
                return {
                    id: 'special group ' + labels,
                    attributes: { opacity: 0.32, color: 'grey' },
                    data: { open: nodes.size > 2 }
                };
            },
            showContents: (metaNode) => {
                return metaNode.getData('open');
            },
        }).whenApplied().then(() => this.ogma.layouts.force());
    }
}

