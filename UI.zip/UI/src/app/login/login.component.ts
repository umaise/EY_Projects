import { Component, OnInit,EventEmitter,Output } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { ApiService } from '../shared-service/api.service';

@Component({templateUrl: 'login.component.html'})



export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    error = '';
    res:any;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private apiService: ApiService) {}

    ngOnInit() {
        this.loginForm = this.formBuilder.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

    onSubmit() {
        this.submitted = true;
        // stop here if form is invalid
        if (this.loginForm.invalid) {
            alert("Wrong form")
            return;
        }
        this.apiService.login(this.f.username.value, this.f.password.value)
            .subscribe(
                data => {
                   Object.keys(data).map(key =>{
                   this.res =data[key].value
                   })
                   if(this.res === true){ 
                    this.router.navigate(['/home']);
                   }
                   else{
                    alert("wrong username or password")
                   }
                },
                error => {
                    alert("Unable to connect")
                    // this.error = error;
                    // this.loading = false;
                });
    }
}
