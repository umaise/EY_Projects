import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataGapComponent } from './data-gap.component';

describe('DataGapComponent', () => {
  let component: DataGapComponent;
  let fixture: ComponentFixture<DataGapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataGapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataGapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
