import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../shared-service/api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { OgmaService } from '../ogma.service';
import { NodeId, InputTarget, RawGraph } from 'ogma';
import { ButtonRendererComponent } from "../attribute-summary/row-edit.component";

interface HoverEvent {
  target: InputTarget;
  x: number;
  y: number;
}

@Component({
  selector: 'app-data-gap',
  templateUrl: './data-gap.component.html',
  styleUrls: ['./data-gap.component.css']
})
export class DataGapComponent implements OnInit {
  reportData: ReportData[];
  dataView:any;
  displayModal: boolean = false;
  frameworkComponents: any;
  reportName: string;
  scheduleData: ReportData[];
  scheduleName: string;
  lineItemData: ReportData[];
  lineItem: string;
  gapCategoryData: ReportData[];
  gapCategory: string;
  gapData: ReportData[];
  gap: string;
  gapView: DataGap;
  editForm: FormGroup;
  isDisabled;
  gridApi; 
  gridColumnApi;
  gridHistApi;
  gridHistColumnApi;
  rowDataHistory: any;
  TabGroup;
  rowData: any;
  timeStamp: any;
  gapTable = [];
  rowGapData: any;
  selectedIndex: number = 0;
  items =[];
  gapnumber:any;
  gapCat:any;

  colGapDefs = [
    { headerName: 'RemediationStatus', field: 'RemediationStatus', sortable: true, filter: true, resizable: true },
    { headerName: 'TotalGapsOpen', field: 'TotalGapsOpen', sortable: true, filter: true, resizable: true },
    { headerName: 'TotalGapsClosed', field: 'TotalGapsClosed', sortable: true, filter: true, resizable: true },
  ];

  columnDefsHistory = [
    { headerName: 'Conf_Analysis', field: 'Conf_Analysis', sortable: true, filter: true, resizable: true },
    { headerName: 'Conf_Analysis_review', field: 'Conf_Analysis_review', sortable: true, filter: true, resizable: true },
    { headerName: 'GapMatchCategory', field: 'GapMatchCategory', sortable: true, filter: true, resizable: true },
    { headerName: 'Gap_No', field: 'Gap_No', sortable: true, filter: true, resizable: true },
    // { headerName: 'GapSubCategory', field: 'GapSubCategory', sortable: true, filter: true, resizable: true },
    // { headerName: 'GapDescription', field: 'GapDescription', sortable: true, filter: true, resizable: true },
    // { headerName: 'ApplicableAttributes', field: 'ApplicableAttributes', sortable: true, filter: true, resizable: true },
    // { headerName: 'IssueSeverity', field: 'IssueSeverity', sortable: true, filter: true, resizable: true },
    // { headerName: 'ScopeOfRemediation', field: 'ScopeOfRemediation', sortable: true, filter: true, resizable: true },
    // { headerName: 'RemediationStatus', field: 'RemediationStatus', sortable: true, filter: true, resizable: true },
    // { headerName: 'RemediationDate', field: 'RemediationDate', sortable: true, filter: true, resizable: true },
    // { headerName: 'ModifiedBy', field: 'ModifiedBy', sortable: true, filter: true, resizable: true },
    // { headerName: 'ConformanceReviewStatus', field: 'ConformanceReviewStatus', sortable: true, filter: true, resizable: true },
    // { headerName: 'modifiedon', field: 'modifiedon', sortable: true, filter: true, resizable: true }
  ];
  columnDefs = [
    {
      headerName: "Edit",
      cellRenderer: "buttonRenderer",
      cellRendererParams: {
        onClick: this.onEditButtonClick.bind(this),
        label: "Edit"
      }
    },
    { headerName: 'Report', field: '0', sortable: true, filter: true, resizable: true },
    { headerName: 'Schedule', field: '1', sortable: true, filter: true, resizable: true },
    { headerName: 'MDRM', field: '2', sortable: true, filter: true, resizable: true },
    { headerName: 'GapNo', field: '3', sortable: true, filter: true, resizable: true },
    { headerName: 'Conf Analysis', field: '4', sortable: true, filter: true, resizable: true },
    { headerName: 'ConfAnalysisreview', field: '5', sortable: true, filter: true, resizable: true },
    { headerName: 'GapMatchCategory', field: '6', sortable: true, filter: true, resizable: true },
    // { headerName: 'CurrentOwner', field: 'CurrentOwner', sortable: true, filter: true, resizable: true },
    // { headerName: 'ReportLineField', field: 'ReportLineField', sortable: true, filter: true, resizable: true },
    // { headerName: 'GapCategory', field: 'GapCategory', sortable: true, filter: true, resizable: true },
    // { headerName: 'GapSubCategory', field: 'GapSubCategory', sortable: true, filter: true, resizable: true },
    // { headerName: 'GapDescription', field: 'GapDescription', sortable: true, filter: true, resizable: true },
    // { headerName: 'ApplicableAttributes', field: 'ApplicableAttributes', sortable: true, filter: true, resizable: true },
    // { headerName: 'IssueSeverity', field: 'IssueSeverity', sortable: true, filter: true, resizable: true },
    // { headerName: 'ScopeofRemediation', field: 'ScopeofRemediation', sortable: true, filter: true, resizable: true },
    // { headerName: 'RemediationStatus', field: 'RemediationStatus', sortable: true, filter: true, resizable: true },
    // { headerName: 'RemediationDate', field: 'RemediationDate', sortable: true, filter: true, resizable: true },
    // { headerName: 'ConformanceReviewStatus', field: 'ConformanceReviewStatus', sortable: true, filter: true, resizable: true },
    // { headerName: 'ModifiedBy', field: 'ModifiedBy', sortable: true, filter: true, resizable: true },
    // { headerName: 'modifiedon', field: 'modifiedon', sortable: true, filter: true, resizable: true, minWidth: 80, maxWidth: 100 }
  ];
  @ViewChild('ogmaContainer', { static: true })
  private container;

  @Input() currentLayout = 'force';
  layouts: string[] = ['force', 'hierarchical'];
  ogmaContainer;
  graph;
  hoveredContent: { id: NodeId; data };
  hoveredPosition: { x: number; y: number };
  constructor(private apiService: ApiService, private http: HttpClient,
    private _formBuilder: FormBuilder, private snackBar: MatSnackBar, private ogmaService: OgmaService) {
      this.frameworkComponents = {
        buttonRenderer: ButtonRendererComponent,
      }
  }

  ngOnInit() {
    //this.getTables()
    this.getReportNames();
    this.gapView = new DataGap();
    this.isDisabled = true;
    this.editForm = this._formBuilder.group({
      Conf_Analysis: [{ value: '', disabled: true }, Validators.required],
      Conf_Analysis_review: [{ value: '', disabled: true }, Validators.required],
      GapMatchCategory: [{ value: '', disabled: true }, Validators.required],
      Gap_No: [{ value: '', disabled: this.isDisabled }, Validators.required],
    });

    // this.apiService.getRemediationStatusValue().subscribe((value: any) => {
    //   Object.keys(value).map(key => {
    //     value[key].TotalGapsOpen = value[key].TotalGapsOpen.low;
    //     value[key].TotalGapsClosed = value[key].TotalGapsClosed.low;
    //   })
    //   this.rowGapData=value
    // })
    this.ogmaService.initConfig({
      options: {
        backgroundColor: 'rgb(240, 240, 240)',
        minimumHeight: 400,
        minimumWidth: 1300
      },
       dimensions:{
         height:490,
         width:1350,
       }
    }
    );


    this.ogmaService.ogma.events.onHover(({ x, y, target }: HoverEvent) => {
      if (target.isNode) {
        // save the tooltip state (offset by 20px the vertical position)
        this.hoveredContent = {
          id: target.getId(),
          data: target.getData()
        };
        this.hoveredPosition = { x, y: y + 100 };
      }
    });

    this.ogmaService.ogma.events.onUnhover((_: HoverEvent) => {
      // clear the tooltip state
      this.hoveredContent = null;
    });

    this.getUpdateDataGapHistory();
  }
  onEditButtonClick(params) {
    this.dataView = params.data;
    this.gapCat= this.dataView[6];
    this.gapnumber=this.dataView[3];
    this.displayModal = !this.displayModal;
    this.getGapViewForm(this.gapCat,this.gapnumber);
  }
  modalClicked() {
    this.displayModal = !this.displayModal;
  }
  ngAfterContentInit() {
    this.ogmaService.ogma.setContainer(this.container.nativeElement);
    return this.runLayout();
  }

  getTableViewData() {
    // this.apiService.getDataGapValues(this.reportName, this.scheduleName, this.lineItem, this.gapCategory, this.gap).subscribe((data: ReportData[]) => {
    //   this.rowData = data;
    // });
    this.apiService.getReportingLineGapTable(this.reportName, this.scheduleName, this.lineItem).subscribe((data: any) => {
      this.items = [];
      for (let i = 0; i < data.length; i++) {
       this.items.push(data[i]._fields);
     }
     this.rowData = this.items;
    });
  }

  getGapTableValues() {
    this.apiService.getDataGapValues(this.reportName, this.scheduleName, this.lineItem, this.gapCategory, this.gap).subscribe((data: ReportData[]) => {
      this.rowData = data;
    });
  }

  getReportNames() {
    this.apiService.getReportNames().subscribe((data: ReportData[]) => {
      this.reportData = data;
    });
  }
  zoomIn(){
    this.ogmaService.ogma.view.zoomIn({ duration: 200 }).then(function () { console.log('zoom done') });
}
 zoomOut() {
  this.ogmaService.ogma.view.zoomOut({ duration: 200 }).then(function () { console.log('zoom done') });
}
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.sizeColumnsToFit() 
  }

  onGridHistReady(params) {
    this.gridHistApi = params.api;
    this.gridHistColumnApi = params.columnApi;
    params.api.sizeColumnsToFit() 
  }

  isEditForm() {
    this.isDisabled = !this.isDisabled;
    const state = this.isDisabled ? 'disable' : 'enable';
    Object.keys(this.editForm.controls).forEach((controlName) => {
      this.editForm.controls[controlName][state](); // disables/enables each form control based on 'this.formDisabled'
    });
  }

  onBtnHistExport(){
    this.gridHistApi.exportDataAsCsv();
  }

  getSchedule(reportName) {
    this.reportName = reportName;
    this.apiService.getSectionNamesFromReport(reportName).subscribe((data: ReportData[]) => {

      this.scheduleData = data;
      this.scheduleData.sort((a, b) => a.text.localeCompare(b.text));
      // this.apiService.getReportGapTable(reportName).subscribe((data: ReportData[]) => {        
      //   this.rowData = data
      // });
    });

  }

  getLineItem(scheduleName: string) {
    this.scheduleName = scheduleName;
    this.apiService.getLineItemsForSection(this.reportName, scheduleName).subscribe((data: ReportData[]) => {
      this.lineItemData = data;

      this.lineItemData.sort((a, b) => a.text.localeCompare(b.text));
      // this.apiService.getScheduleGapTable(this.reportName, scheduleName).subscribe((data: ReportData[]) => {
      //   this.rowData = data
      // });

    });

  }
  getGapCategory(lineItem: string) {
    this.lineItem = lineItem;
    this.apiService.getGapCategory(this.reportName, this.scheduleName, lineItem).subscribe((data: ReportData[]) => {
      this.gapCategoryData = data;
      // this.apiService.getReportingLineGapTable(this.reportName, this.scheduleName, lineItem).subscribe((data: ReportData[]) => {
      //   this.rowData = data
      // });
      this.DisplayAll();
    });

  }

  getGap(gapCategory: string) {
    this.gapCategory = gapCategory;
    this.apiService.getGap(this.reportName, this.scheduleName, this.lineItem, gapCategory).subscribe((data: ReportData[]) => {
      this.gapData = data;
    });
  }

  getGapViewForm(gapCat:string,gap: string) {
    this.gap = gap;
    this.apiService.getGapView(this.reportName, this.scheduleName, this.lineItem,gapCat ,gap).subscribe((data: DataGap) => {
      this.gapView = data;
    });
  }

  updateGapviewForm() {
    this.displayModal = !this.displayModal;
   const view= [{"Conf_Analysis":this.dataView[4],"Conf_Analysis_review":this.dataView[5],"GapMatchCategory":this.dataView[6],"Gap_No":this.dataView[3]}]
    console.log(view[0])
    this.apiService.updateGapView(view[0]).subscribe(data => {
      this.getTableViewData();
    });     
    this.selectedIndex = this.selectedIndex - 1;
    this.getUpdateDataGapHistory();
  }

  getUpdateDataGapHistory() {
    this.apiService.getUpdateDataGapHistory().subscribe((data: any) => {
      this.rowDataHistory = data;
    });
  }

  onTabClick1(event) {
    if (event.index === 0) {
      
      this.DisplayAll();
    } else {
      this.getTableViewData();
    }
  }
  showSnackBar(msg, action) {
    this.snackBar.open(msg, action, {
      duration: 2000,
      verticalPosition: 'top',
      horizontalPosition: 'right'
    });
  }
  public DisplayAll() {
    this.apiService.GetGraphValuesForDataspage(this.reportName, this.scheduleName, this.lineItem).subscribe((data: RawGraph) => {
      this.ogmaService.ogma.setGraph(data);
      this.getTableViewData();
      return this.runLayout();
    });
  }
  public runLayout(): Promise<void> {
    return this.ogmaService.runLayout(this.currentLayout);
  }
  public ResetGraph() {
    this.ogmaService.ogma.clearGraph();
  }

  onReset() {
    this.rowData = "";
    this.getReportNames();
    this.scheduleData = [];
    this.lineItemData = [];
    this.reportName = "";
    this.scheduleName = "";
    this.lineItem = "";
    this.gapCategoryData = [];
    this.gapCategory = "";
    this.gapData = [];
    this.gap = "";
    //  this.gapView=[];

  }
}

export class ReportData {
  rowID: number;
  id: string;
  text: string;
}

export class DataGap {
  Conf_Analysis: string;
  Conf_Analysis_review: string;
  GapMatchCategory: string;
  Gap_No: string;
}
