import { Component, OnInit } from '@angular/core';
import { ApiService } from '../shared-service/api.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {
  
  attributeData: AttributeData[];
  attributeSummary : AttributeSummary;
  scheduleName:string;

  //table view 
  gridApi;
  gridColumnApi;
  columnDefs = [
   {headerName: 'FAQ ID', field: 'Attribute',  sortable: true, filter: true,  resizable: true },
   {headerName: 'Question', field: 'AttributeGENESISName', sortable: true, filter: true, resizable: true},
   {headerName: 'Answer', field: 'GenesisScriptFlag', sortable: true, filter: true, resizable: true},
   {headerName: 'Date Answered ', field: 'IMRFlag', sortable: true, filter: true, resizable: true},
   {headerName: 'Schedule name ', field: 'GenesisDefaults', sortable: true, filter: true, resizable: true}
 ];
 rowData: any;
  constructor(private apiService: ApiService,private http: HttpClient){  }

  ngOnInit() {
    this.getScheduleName();
  }

  
  getScheduleName(){
    this.apiService.getSchedule().subscribe((data: AttributeData[]) => {
      this.attributeData = data;
     
     })
  }

  getFAQMetrics(scheduleName){
    this.scheduleName = scheduleName;
    this.rowData="";
    this.apiService.getFAQMetrics(scheduleName).subscribe((data: AttributeSummary) => {
      this.attributeSummary = data;
    })
  }

  getTableDetailsForFAQ(){
    this.apiService.getTableDetailForFAQ(this.scheduleName).subscribe((data: any) => {
      this.rowData = data;
      });
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  onBtnExport() {
    this.gridApi.exportDataAsCsv();
  }

  onReset(){
    this.attributeData = [];
    this.getScheduleName();
    this.attributeSummary = new AttributeSummary();
    this.scheduleName = "";
    this.rowData =[];
  }
}

export class AttributeData{
  rowID: number;
  attributeName: string
}

export class AttributeSummary{
  report: number;
  source: number;
  schedule: number;
  reportingLine: number;
  dataConcept: number;
  dataElement: number;
}
