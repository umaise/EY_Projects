import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ReportAnalyticsComponent } from './report-analytics/report-analytics.component';
import { AttributeSummaryComponent } from './attribute-summary/attribute-summary.component';
import { FaqComponent } from './faq/faq.component';
import { DataGapComponent } from './data-gap/data-gap.component';
import { DashboardComponent} from './dashboard/dashboard.component'
import { LoginComponent } from './login/login.component';
import { SheetComponent } from './sheet/sheet.component';
import { AuthGuard } from './_guards';
import { ExcelComponent } from './excel/excel.component';
import { SpreadSheetComponent } from './spread-sheet/spread-sheet.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent},
  { path: 'report-analytics', component: ReportAnalyticsComponent },
  { path: 'attribute-analysis', component: AttributeSummaryComponent },
  { path: 'faq', component: FaqComponent },
  { path: 'gap-analysis', component: DataGapComponent},
  { path: 'audit-log', component: DashboardComponent},
  { path: 'login', component: LoginComponent },
  { path: 'sheet', component: SheetComponent },
  { path: 'excel', component: ExcelComponent },
  { path: 'spread-sheet', component:  SpreadSheetComponent},
   //{ path: '**',redirectTo: '/login' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
