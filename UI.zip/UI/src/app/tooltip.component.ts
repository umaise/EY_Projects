
import { Component, Input } from '@angular/core';

@Component({
  selector: 'tooltip',
  templateUrl: './tooltip.component.html',
  styleUrls: ['./tooltip.component.css'],
})
export class TooltipComponent {
    @Input() content: {id: string,  data};
    @Input() position: {x: number, y: number};
}
