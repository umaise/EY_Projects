import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  constructor(private readonly router: Router) { }

  ngOnInit() {
  }

  datagap() {
    this.router.navigate(['gap-analysis']);
  }
  attsummary() {
    this.router.navigate(['/attribute-analysis']);
  }
  report() {
    this.router.navigate(['/report-analytics']);
  }
  dashboard() {
    this.router.navigate(['/audit-log']);
  }
  home() {
    this.router.navigate(['home']);
  }
  histTbl() {
    this.router.navigate(['/historical-table']);
  }

  sheet(){
    this.router.navigate(['/sheet']);
  }
}
