


import { ApiService } from '../shared-service/api.service';


export var single = [
    {
      "name": "Deposits",
      "value": 1
    },
    {
      "name": "Loans",
      "value": 129
    }
  ];

  export var multi = [
    {
      "name": "H.1 - Corporate Loan Data Schedule",
      "series": [
        {
          "name": "2010",
          "value": 73
        },
        {
          "name": "2011",
          "value": 80
        }
      ]
    },
  
    {
      "name": "H.2 - Commercial Real Estate Schedule",
      "series": [
        {
          "name": "2010",
          "value": 78
        },
        {
          "name": "2011",
          "value": 82
        }
      ]
    },
  ];