import { Component, OnInit } from '@angular/core';
// import { single, multi } from './data';
import { Router } from '@angular/router';
import { ApiService } from '../shared-service/api.service';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { dataBound } from '@syncfusion/ej2-spreadsheet';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  // single: any[];
  multi: any[];
  pieview: any[] = [900, 400];
  barview: any[] = [700, 400];
  flag: any;
  sourceData = [];
  sourceDataPieChange = [];
  sourceDataPieChangeRank = [];
  initMulti = [];
  histCard: any;
  histSchTab: any;
  histLineTab: any;
  // options
  showXAxis: boolean = true;
  showYAxis: boolean = true;
  gradient: boolean = false;
  showLegend: boolean = true;
  showXAxisLabel: boolean = true;
  //  xAxisLabel: string = 'Country';
  showYAxisLabel: boolean = true;
  //  yAxisLabel: string = 'Population';
  animations: boolean = true;
  legendTitle = '';
  tooltipText = 'lenka';
  gridApi;
  gridColumnApi; any
  reportcnt: [];
  recPer: any;
  scheduleCnt: any;
  schedulePer: any;
  mdrmCnt: any;
  mdrmPer: any;
  rowData;
  reportData: any;
  reportName: string;
  scheduleData: any;
  scheduleName: string;
  lineItemData: any;
  lineItem: string;
  piechart = [];
  gapCategoryData: ReportData[];
  chartNames:any;

  colorScheme = {
    domain: ['#e7298a','#000000','#336699']
  };
  pieChangecolorScheme = {
    domain: ['#00a3ae', '#ffe600']
  };
  pieChangeRankcolorScheme = {
    domain: ['#91278f', '#ac98db', '#00a3ae', '#bd478c']
  };

  single = [
  ];
  PieChange = [];
  PieChangeRank = [];


  colDefs = [
    { headerName: 'Report', field: 'Report', sortable: true, filter: true, resizable: true },
    { headerName: 'Schedule Name', field: 'ScheduleName', sortable: true, filter: true, resizable: true },
    { headerName: 'MDRM', field: 'MDRM', sortable: true, filter: true, resizable: true },
    { headerName: 'Reporting Line', field: 'ReportingLine', sortable: true, filter: true, resizable: true },
    { headerName: 'Reporting Instructions', field: 'ReportingInstructions', sortable: true, filter: true, resizable: true },
    { headerName: 'ID', field: 'ID', sortable: true, filter: true, resizable: true },
    { headerName: 'Bussiness Requirements', field: 'BusinessRequirements', sortable: true, filter: true, resizable: true },
    { headerName: 'Faq Reference', field: 'FAQReference', sortable: true, filter: true, resizable: true },
    { headerName: 'Bussiness Element Name', field: 'BusinessElementName', sortable: true, filter: true, resizable: true },
    { headerName: 'Requirement Construction Logic', field: 'RequirementConstructionLogic', sortable: true, filter: true, resizable: true },
    { headerName: 'Schedule Product', field: 'ScheduleProduct', sortable: true, filter: true, resizable: true },
    { headerName: 'Data Attribute', field: 'DataAttribute', sortable: true, filter: true, resizable: true },
    { headerName: 'Provisioning System', field: 'ProvisioningSystem', sortable: true, filter: true, resizable: true },
    { headerName: 'Schedule Owner', field: 'ScheduleOwner', sortable: true, filter: true, resizable: true },
    { headerName: 'Change Type', field: 'ChangeType', sortable: true, filter: true, resizable: true },
    { headerName: 'Last Update DT', field: 'LastUpdateDT', sortable: true, filter: true, resizable: true },
    { headerName: 'Record Start Date', field: 'RecordStartDate', sortable: true, filter: true, resizable: true },
    { headerName: 'Record End Date', field: 'RecordEndDate', sortable: true, filter: true, resizable: true },
    { headerName: 'Change Rank', field: 'Changerank', sortable: true, filter: true, resizable: true },
    { headerName: 'Allowable Values', field: 'AllowableValues', sortable: true, filter: true, resizable: true },
    { headerName: 'Additional Requirement Information', field: 'AdditionalRequirementInformation', sortable: true, filter: true, resizable: true },
    { headerName: 'Bussiness Element Name Def', field: 'BusinessElementDefination', sortable: true, filter: true, resizable: true },
    { headerName: 'Bussiness Transaltion', field: 'BusinessTranslation', sortable: true, filter: true, resizable: true },
    { headerName: 'Status', field: 'Status', sortable: true, filter: true, resizable: true },
    { headerName: 'Standardization Logic', field: 'StandardizationLogic', sortable: true, filter: true, resizable: true },
    { headerName: 'Bussiness Attribute', field: 'BusinessAttribute', sortable: true, filter: true, resizable: true },
    { headerName: 'Table Name', field: 'TableName', sortable: true, filter: true, resizable: true },
    { headerName: 'Axiom Short Trans Logic', field: 'AxiomShorthandTransformationLogic', sortable: true, filter: true, resizable: true },
    { headerName: 'DataSourcingTransformation', field: 'DataSourcingTransformation', sortable: true, filter: true, resizable: true },
    { headerName: 'DataProviderInterpretation', field: 'DataProviderInterpretation', sortable: true, filter: true, resizable: true },
    { headerName: 'StandardStagingTable', field: 'StandardStagingTable', sortable: true, filter: true, resizable: true },
    { headerName: 'StandardStagingField', field: 'StandardStagingField', sortable: true, filter: true, resizable: true },
    { headerName: 'DataAttributeDefination', field: 'DataAttributeDefination', sortable: true, filter: true, resizable: true },
  ]
  //   // options
  //   showXAxis = true;
  //   showYAxis = true;
  //   piegradient = false;
  //   showLegend = true;
  //   showXAxisLabel = true;
  //   xAxisLabel = 'Schedule Name';
  //   showYAxisLabel = true;
  //   yAxisLabel = 'Gap Count';
  //   gradient: boolean = true;
  //   sourceData = [];
  //   initMulti = [];
  //   num:number=0
  //   // showLegend: boolean = true;
  //   showLabels: boolean = true;
  //   isDoughnut: boolean = false;
  //   showChart=true;
  //   public barChartOptions: ChartOptions = {
  //     responsive: true,
  //   };
  //   public barChartLabels: Label[] = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
  //   public barChartType: ChartType = 'bar';
  //   public barChartLegend = true;
  //   public barChartPlugins = [];

  //     public barChartData: ChartDataSets[] = [
  //       { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A', stack: 'a' },
  //       { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B', stack: 'a' }
  //     ];

  constructor(private readonly router: Router, private apiService: ApiService) {
    this.apiService.getHistoryProductAlignment().subscribe(data => {
      Object.keys(data).map(key => {
        this.single = [...this.single, ...[{ "name": data[key].ScheduleProduct, "value": data[key].cnt }]]
      })
    });
    this.apiService.getHistoryChangeType().subscribe(data => {
      Object.keys(data).map(key => {
        this.PieChange = [...this.PieChange, ...[{ "name": data[key].CHANGETYPE, "value": data[key].cnt }]]
      })
    });
    this.apiService.getHistoryChangeRank().subscribe(data => {
      Object.keys(data).map(key => {
        this.PieChangeRank = [...this.PieChangeRank, ...[{ "name": data[key].CHANGERANK, "value": data[key].cnt }]]
      })
    });
    Object.assign(this.single);
    Object.assign(this.PieChange);
    Object.assign(this.PieChangeRank);
    this.sourceData = this.single;
    this.sourceDataPieChange = this.PieChange;
    this.sourceDataPieChangeRank = this.PieChangeRank;
  }

  piecolorScheme = {
    domain: ['#e7298a', '#336699', '#91278f', '#ffe600', '#ac98db', '#2c973e', '#00a3ae']
  };

  //   barcolorScheme = {
  //     domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA']
  //   };


  ngOnInit() {
    this.apiService.getReportNames().subscribe((data: ReportData[]) => {
      this.reportData = data;
    });
    this.chartNames = this.single.map((d: any) => d.name);
    console.log(this.chartNames)
    this.HistCard();
  }

  //   onSelect(event) {
  //     let temp = JSON.parse(JSON.stringify(this.bar));
  //     if (this.isBarDataShown(event))    {
  //         //Hide it

  //         temp.filter(bar => {
  //           // bar.filter(e => {
  //           //   if(e.name === event)
  //           //   e.value =0;
  //           // })
  //             if (bar.name === event) {
  //             //bar.value = 0;

  //             console.log(bar.value) 
  //                 return bar;
  //             }
  //         });
  //     }
  //     else {
  //         //Show it back
  //         const barToAdd = this.barData.filter(bar => {
  //             return bar.name === event;
  //         });
  //         console.log("barToAdd", barToAdd[0]);
  //         temp.some(bar => {
  //             if (bar.name === event) {
  //               bar.value = barToAdd[0].value;
  //                 return true;
  //             }
  //         });
  //     }
  //     this.bar = temp;
  //     console.log(event);
  //   }

  // onSelect(event) {
  //   if (this.isLegend(event)) {
  //     if (this.isDataBarShown(event)) {
  //       const tempData = JSON.parse(JSON.stringify(this.multi));
  //       tempData.forEach(country => {
  //         country.series.forEach(year => {
  //           if (year.name === event) {
  //             year.value = 0;
  //           }
  //         });
  //       });
  //       this.multi = tempData;
  //     } else {
  //       this.initMulti.forEach(country => {
  //         country.series.forEach(year => {
  //           if (year.name === event && year.value !== 0) {
  //             this.setChartDataBackToInitData(country.name, year.name, year.value)
  //           }
  //         });
  //       });
  //     }
  //   } else {
  //     console.log('emit event and do something else')
  //     // this.selection.emit(event);
  //   }
  // }

  // isLegend = (event) => typeof event === 'string';

  // isDataBarShown = (event) => {
  //   const selectedBar = this.multi.find(model => {
  //     return model.series.find(singleModel => {
  //       return singleModel.name === event && singleModel.value !== 0;
  //     });
  //   });

  //   return typeof selectedBar !== 'undefined';
  // }


  HistCard() {
    this.apiService.getHistCard().subscribe(data => {
      Object.keys(data).map(key => {
        if (key === 'ReportCnt') {
          this.reportcnt = data[key];
        }
        if (key === 'ReportPer') {
          this.recPer = data[key];
        }
        if (key === 'ScheduleCnt') {
          this.scheduleCnt = data[key];
        }
        if (key === 'SchedulePer') {
          this.schedulePer = data[key];
        }
        if (key === 'MdrmCnt') {
          this.mdrmCnt = data[key];
        }
        if (key === 'MdrmPer') {
          this.mdrmPer = data[key];
        }

      })

    })


    // this.apiService.getHistTable().subscribe(data => {
    //   console.log(data)
    // });
  }

  // setChartDataBackToInitData = (country, yearName, yearDefValue) => {
  //   const tempData = JSON.parse(JSON.stringify(this.multi));
  //   tempData.find(_country =>
  //     _country.name === country).series.find(_year => _year.name === yearName).value = yearDefValue;
  //   this.multi = tempData;
  // }
  onSelectPie(event) {
    console.log("Legend clicked");
    let temp = JSON.parse(JSON.stringify(this.single));
    if (this.isDataShown(event)) {
      //Hide it
      temp.some(pie => {
        if (pie.name === event) {
          pie.value = 0;
          return true;
        }
      });
    } else {
      console.log("In Else case");
      //Show it back
      const pieToAdd = this.single.filter(pie => {
        return pie.name === event;
      });
      console.log("pieToAdd", pieToAdd[0]);
      temp.some(pie => {
        if (pie.name === event) {
          pie.value = pieToAdd[0].value;
          return true;
        }
      });
    }
    this.single = temp;
  }

  isDataShown = (name) => {
    const selectedPie = this.single.filter(pie => {
      return pie.name === name && pie.value !== 0;
    });
    return selectedPie && selectedPie.length > 0;
  }

  //     isBarDataShown = (name) => {
  //       const selectedBar = this.bar.filter(bar => {
  //           return bar.name === name && bar.value !== 0;
  //       });
  //       return selectedBar && selectedBar.length > 0;
  //   }

  onActivate(data): void {
    console.log('Activate', JSON.parse(JSON.stringify(data)));
  }

  onDeactivate(data): void {
    console.log('Deactivate', JSON.parse(JSON.stringify(data)));
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  getReportNames(reportName) {
    this.apiService.getReportTab(reportName).subscribe(data => {
      Object.keys(data).map(key => {
        if (key === 'recordsets')
          this.histCard = data[key].map(val => {
            return val
          })
      })
      this.rowData = this.histCard[0];
    });
  }
  getSchedule(reportName) {
    this.reportName = reportName;
    this.apiService.getSectionNamesFromReport(reportName).subscribe((data: ReportData[]) => {
      this.scheduleData = data;
      this.scheduleData.sort((a, b) => a.text.localeCompare(b.text));
    });

  }

  getLineItem(scheduleName: string) {
    this.scheduleName = scheduleName;
    this.apiService.getLineItemsForSection(this.reportName, scheduleName).subscribe((data: ReportData[]) => {
      this.lineItemData = data;

      this.lineItemData.sort((a, b) => a.text.localeCompare(b.text));
      this.apiService.getScheduleHistTable(this.reportName, scheduleName).subscribe((data: ReportData[]) => {
        Object.keys(data).map(key => {
          if (key === 'recordsets')
            this.histCard = data[key].map(val => {
              return val
            })
        })
        this.rowData = this.histCard[0];
      });

    });

  }
  getMetricsByLineItem(lineItem: string) {
    this.lineItem = lineItem;
    this.apiService.getLineHistTable(this.reportName, this.scheduleName, lineItem).subscribe((data: ReportData[]) => {

      Object.keys(data).map(key => {

        if (key === 'recordsets')

          this.histLineTab = data[key].map(val => {

            return val

          })

      })

      this.rowData = this.histLineTab[0];

    });
  }

  onBtnExport() {

    this.gridApi.exportDataAsCsv();

  }
  onReset() {
    // this.rowData = "";
    // this.getReportNames();
    this.scheduleData = [];
    this.lineItemData = [];
    this.reportName = "";
    this.scheduleName = "";
    this.lineItem = "";
  }

}

export class ReportData {
  rowID: number;
  id: string;
  text: string;
}