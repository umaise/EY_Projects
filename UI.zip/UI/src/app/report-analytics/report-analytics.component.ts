import { Component, OnInit, ViewChild, AfterContentInit, Input, SelfDecorator } from '@angular/core';
import { ApiService } from '../shared-service/api.service';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, Validators, FormBuilder, NgForm } from '@angular/forms';
import * as CanvasJS from '../canvasjs.min';
import { OgmaService } from '../ogma.service';
import { NodeId, InputTarget, RawGraph } from 'ogma';
import { MatTabChangeEvent } from '@angular/material';


interface HoverEvent {
  target: InputTarget;
  x: number;
  y: number;
}
//interface MouseButtonEvent {
// target: InputTarget;
//}
@Component({
  selector: 'report-analytics',
  templateUrl: './report-analytics.component.html',
  styleUrls: ['./report-analytics.component.css']
})
export class ReportAnalyticsComponent implements OnInit, AfterContentInit {

  reportData: ReportData[];
  scheduleData: ReportData[];
  lineItemData: ReportData[];
  reportName: string;
  scheduleName: string;
  lineItem: string;
  lineItemDesc: string;
  donutDeatils: DonutDetails[];
  donutdata = [];
  //Metrics
  metricDetails: MetricDetails;
  reportCard: ReportCard;
  histLineTab: any;
  items = [];
  itemsToAdd = [{
  }];

  //Ogmaservice
  @ViewChild('ogmaContainer', { static: true })
  private container;

  @Input() currentLayout = 'force';
  layouts: string[] = ['force', 'hierarchical'];
  ogmaContainer;
  graph;
  hoveredContent: { id: NodeId; data };
  hoveredPosition: { x: number; y: number };
  //end

  gridApi;
  gridColumnApi;
  columnDefs = [ 
    { headerName: 'ReportName', field: '0', sortable: true, filter: true, resizable: true },
    { headerName: 'ScheduleName', field: '1', sortable: true, filter: true, resizable: true },
    { headerName: 'ScheduleProduct', field: '2', sortable: true, filter: true, resizable: true },
    { headerName: 'ScheduleOwner', field: '3', sortable: true, filter: true, resizable: true },
    { headerName: 'MDRM', field: '4', sortable: true, filter: true, resizable: true },
    { headerName: 'ReportingLine', field: '5', sortable: true, filter: true, resizable: true },
    { headerName: 'ReportingInstruction', field: '6', sortable: true, filter: true, resizable: true },
    { headerName: 'AllowableValues', field: '7', sortable: true, filter: true, resizable: true },
    { headerName: 'FAQ Reference', field: '8', sortable: true, filter: true, resizable: true },
    { headerName: 'ID', field: '9', sortable: true, filter: true, resizable: true },
    { headerName: 'BussinessRequirements', field: '10', sortable: true, filter: true, resizable: true },
    { headerName: 'AdditionalRequirementInformation', field: '11', sortable: true, filter: true, resizable: true },
    { headerName: 'BusinessElementName', field: '12', sortable: true, filter: true, resizable: true },
    { headerName: 'BusinessElementDefination', field: '13', sortable: true, filter: true, resizable: true },
    { headerName: 'ConstructionLogic', field: '14', sortable: true, filter: true, resizable: true },
    { headerName: 'BusinessTranslation', field: '15', sortable: true, filter: true, resizable: true },
    { headerName: 'Status', field: '16', sortable: true, filter: true, resizable: true },
    { headerName: 'BusinessAttribute', field: '17', sortable: true, filter: true, resizable: true },
    { headerName: 'AxiomShorthandTransformationLogic', field: '18', sortable: true, filter: true, resizable: true },
    { headerName: 'DataAttribute', field: '19', sortable: true, filter: true, resizable: true },
    { headerName: 'Table Name', field: '20', sortable: true, filter: true, resizable: true },
    { headerName: 'DataProviderName', field: '21', sortable: true, filter: true, resizable: true },
    { headerName: 'DataSourcingTransformation', field: '22', sortable: true, filter: true, resizable: true },
    { headerName: 'DataProviderInterpretation', field: '23', sortable: true, filter: true, resizable: true },
    { headerName: 'StandardizationLogic', field: '24', sortable: true, filter: true, resizable: true },
    { headerName: 'StandardStagingTable', field: '25', sortable: true, filter: true, resizable: true },
    { headerName: 'StandardStagingField', field: '26', sortable: true, filter: true, resizable: true },
    { headerName: 'DataAttributeDefination', field: '27', sortable: true, filter: true, resizable: true },
    { headerName: 'Gap No', field: '28', sortable: true, filter: true, resizable: true },
    { headerName: 'Conf Analysis', field: '29', sortable: true, filter: true, resizable: true },
    { headerName: 'Conf Analysis review', field: '30', sortable: true, filter: true, resizable: true },
    { headerName: 'Gap Match Category', field: '31', sortable: true, filter: true, resizable: true },
    { headerName: 'Source', field: '32', sortable: true, filter: true, resizable: true },
  ];

  rowData: any;
  private overlayNoRowsTemplate;
  private overlayLoadingTemplate;
  TabGroup;

  constructor(private apiService: ApiService, private http: HttpClient, private ogmaService: OgmaService) {
    this.overlayLoadingTemplate =
      '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>';
    this.overlayNoRowsTemplate =
      "<span style=\"padding: 10px;\">Loading...</span>";
  }
  selectedIndex;
  ngOnInit() {
    this.getReportNames();
    this.getTableViewData();
    this.ogmaService.initConfig({
      options: {
        backgroundColor: 'rgb(240, 240, 240)',
        minimumHeight: 400,
        minimumWidth: 1300,
      }
    }
    );


    this.ogmaService.ogma.events.onHover(({ x, y, target }: HoverEvent) => {
      if (target.isNode) {
        this.hoveredContent = {
          id: target.getId(),
          data: target.getData()
        };
        this.hoveredPosition = { x, y: y + 100 };
      }
    });

    this.ogmaService.ogma.events.onUnhover((_: HoverEvent) => {
      // clear the tooltip state
      this.hoveredContent = null;
    });

  }


  getReportNames() {
    this.apiService.getReportNames().subscribe((data: ReportData[]) => {
      this.reportData = data;
    });

  }

  getTableViewData() {
    if (this.reportName && this.scheduleName && this.lineItem) {
      this.apiService.getTableViewDataLineItem(this.reportName, this.scheduleName, this.lineItem).subscribe((data: any) => {
        this.items = [];
        for (let i = 0; i < data.length; i++) {
          this.items.push(data[i]._fields);
        }
        this.rowData = this.items;
      });
    } else if (this.reportName && this.scheduleName) {
      this.apiService.getTableViewDataSchedule(this.reportName, this.scheduleName).subscribe((data: any) => {
        this.items = [];
        for (let i = 0; i < data.length; i++) {
          this.items.push(data[i]._fields);
        }
        this.rowData = this.items;
      });
    } else {
      this.apiService.getTableViewDataReport(this.reportName).subscribe((data: any) => {
        this.items = [];
        for (let i = 0; i < data.length; i++) {
          this.items.push(data[i]._fields);
        }
        this.rowData = this.items;
      });
    }
  }
  onTabClick(event) {
    if (event.index === 0) {
      this.DisplayAll();
    } else {
      this.getTableViewData();
    }
  }

   zoomIn(){
    this.ogmaService.ogma.view.zoomIn({ duration: 200 }).then(function () { console.log('zoom done') });
}
 zoomOut() {
  this.ogmaService.ogma.view.zoomOut({ duration: 200 }).then(function () { console.log('zoom done') });
}

  getSchedule(reportName) {
    this.reportName = reportName;
    this.rowData = "";
    this.apiService.getSectionNamesFromReport(reportName).subscribe((data: ReportData[]) => {
      this.scheduleData = data;
      this.scheduleData.sort((a, b) => a.text.localeCompare(b.text));
      //get report card info
      this.apiService.getReportCardInfo(reportName).subscribe((data: ReportCard) => {
        this.reportCard = data;
        this.getMetricsByReportName(reportName);
      });
    });
  }


  getLineItem(scheduleName: string) {
    this.scheduleName = scheduleName;
    this.rowData = "";
    this.apiService.getLineItemsForSection(this.reportName, scheduleName).subscribe((data: ReportData[]) => {
      this.lineItemData = data;
      this.lineItemData.sort((a, b) => a.text.localeCompare(b.text));
      this.getMetricsBySchedule(this.reportName, scheduleName);
    });
  }

  getMetricsByReportName(reportName: string) {
    this.apiService.getMetricDetailByReportName(reportName).subscribe((data: MetricDetails) => {
      this.metricDetails = data;
      this.getTableViewData();
    });
  }

  getMetricsBySchedule(reportName: string, schedule: string) {
    this.lineItem = "";
    this.apiService.getMetricDetailBySchedule(reportName, schedule).subscribe((data: MetricDetails) => {
      this.metricDetails = data;
      this.getTableViewData();
    });
  }

  getMetricsByLineItem(lineItem: string) {
    this.lineItem = lineItem;
    this.rowData = "";
    this.apiService.getMetricDetailByLineItem(this.reportName, this.scheduleName, lineItem).subscribe((data: MetricDetails) => {
      this.metricDetails = data;
      console.log(this.metricDetails)
      this.getLineItemDescription();
    });
  }

  getLineItemDescription() {
    this.apiService.getLineItemDescription(this.reportName, this.scheduleName, this.lineItem).subscribe((data: any) => {
      this.lineItemDesc = data.lineDescription;
      this.DisplayAll();
    });
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  onBtnExport() {
    this.gridApi.exportDataAsCsv();
  }

  onReset() {
    this.rowData = "";
    this.getReportNames();
    this.scheduleData = [];
    this.lineItemData = [];
    this.reportName = "";
    this.scheduleName = "";
    this.lineItem = "";
    this.lineItemDesc = "";
    this.donutDeatils = [];
    this.donutdata = [];

    //Metrics
    this.metricDetails = null;
    this.reportCard = null;
    let chart = new CanvasJS.Chart("chartContainer", {});
    chart.render();
  }

  getDonutByReportName(reportName: string) {
    this.apiService.getDonutCharDetails(reportName).subscribe((data: DonutDetails[]) => {
      for (let i = 0; i < data.length; i++) {
        this.donutdata.push({ label: data[i].scheduleName, y: data[i].count });
      }
      let chart = new CanvasJS.Chart("chartContainer", {
        theme: "light2",
        animationEnabled: true,
        exportEnabled: true,
        title: {
          text: "Distribution of Total Unique Gaps by Schedule"
        },
        data: [{
          type: "doughnut",
          startAngle: 60,
          showInLegend: true,
          legendText: "{label}",
          indexLabelFontSize: 17,
          indexLabel: "{label} - #percent%",
          toolTipContent: "<b>{label}:</b> {y} (#percent%)",
          dataPoints: this.donutdata
        }]
      });
      chart.render();
    });
  }

  /**
   * Ogma container must be set when content is initialized
   */
  ngAfterContentInit() {
    this.ogmaService.ogma.setContainer(this.container.nativeElement);
    return this.runLayout();
  }

  public runLayout(): Promise<void> {
    return this.ogmaService.runLayout(this.currentLayout);
  }

  public DisplayAll() {
    this.apiService.GetGraphValuesForReportAnalyticspage(this.reportName, this.scheduleName, this.lineItem).subscribe((data: RawGraph) => {

      this.ogmaService.ogma.setGraph(data);
      this.getTableViewData();
      return this.runLayout();
    });
  }
  public ResetGraph() {
    this.ogmaService.ogma.clearGraph();
  }
}


export class ReportData {
  rowID: number;
  id: string;
  text: string;
}

export class ReportCard {
  reportSections: number;
  lineItems: number;
}

export class MetricDetails {
  source: number;
  businessElementName: number;
  dataAttribute: number;
  reportingLine: number;
  crrid: number;
}

export class DonutDetails {
  rowID: number;
  reportName: string;
  scheduleName: string;
  count: number;
}
