import { Component, OnInit } from '@angular/core';
import { ApiService } from '../shared-service/api.service';
import { HttpClient } from '@angular/common/http';

@Component({
	selector: 'app-home',
	templateUrl: './home.component.html',
	styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

	summary: Summary;
	product: products;
	reportData: ReportData[];
	keyword = 'Title';
	data: any;
	errorMsg: string;
	isLoadingResult: boolean;
	gridApi;
	gridColumnApi;
	//   columnDefs = [
	//    {headerName: 'Report Name', field: 'ReportName',  sortable: true, filter: true,  resizable: true },
	//    {headerName: 'Report Schedule', field: 'ScheduleName', sortable: true, filter: true, resizable: true,width: 300},
	//    {headerName: 'Unique Conformance Gaps', field: 'GapCount', sortable: true, filter: true, resizable: true},
	//    {headerName: 'Unique Physical Data Attributes', field: 'DataAttributeCount', sortable: true, filter: true, resizable: true},
	//  ];

	columnRulesDefs =[
		// { headerName: 'Cycle', field: 'Cycle', sortable: true, filter: true, resizable: true },
		// { headerName: 'Pillar', field: 'Pillar', sortable: true, filter: true, resizable: true },
		{ headerName: 'Report', field: 'Report'},
		{ headerName: 'Schedule', field: 'Schedule'},
		{ headerName: 'Rule Count', field: 'RuleCount'},
		{ headerName: 'Count Completed', field: 'CountCompleted' }
		// { headerName: 'Owner', field: 'Owner', sortable: true, filter: true, resizable: true },
		// { headerName: 'Comments', field: 'Comments', sortable: true, filter: true, resizable: true },
		// { headerName: '%Complete', field: 'Complete', sortable: true, filter: true, resizable: true },
	]

	defaultColDef = {
		sortable: true,
		resizable: true,
		filter: true,
	  };

	rowData: any;
	rowRulesData: any;
	private overlayNoRowsTemplate;
	private overlayLoadingTemplate;
	TabGroup;
	constructor(private apiService: ApiService) {
		this.overlayLoadingTemplate =
			'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>';
		this.overlayNoRowsTemplate =
			"<span style=\"padding: 10px;\">Loading...</span>";
	}
	ngOnInit() {
		this.apiService.getIndexSummary().subscribe((data: products) => {
			this.product = new products();
			this.product = data;
			// this.apiService.getHomeSummaryGapAnalytics().subscribe((data: Summary)=>{  
			// 	this.rowData = data;
			this.apiService.getReportNames().subscribe((data: ReportData[]) => {
				this.reportData = data;
				this.apiService.getBussinessRulesValue().subscribe((data: RuleReport[]) => {
					Object.keys(data).map(key => {
						data[key].RuleCount = data[key].RuleCount.low;
						data[key].CountCompleted = data[key].CountCompleted.low;
						// data[key].Complete= (data[key].CountCompleted /data[key].RuleCount).toFixed(4);
					})
					console.log("home",data)
					this.rowRulesData = data
				})
				//})
			})
		})
	}

	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;
		params.api.sizeColumnsToFit() 
	}
	getServerResponse(event) {
		this.isLoadingResult = true;
	}

	searchCleared() {
		console.log('searchCleared');
		this.data = [];
	}

	selectEvent(item) {
		// do something with selected item
	}

	onChangeSearch(val: string) {
		// fetch remote data from here
		// And reassign the 'data' which is binded to 'data' property.
	}

	onFocused(e) {
		// do something when input is focused
	}

}

export class products {
	ReportCount: number
	LineCount: number
	DataCount: number
	SourceCount: number
	ScheduleCount: number
	BusinessReqCount: number
	BusinessEleCount: number
}

export class Summary {
	reportName: string;
	scheduleName: string;
	reportLine: number;
	reportLineDes: string;
	// gap:number;
	// businessElementName:string;
}

export class ReportData {
	rowID: number;
	id: string;
	text: string
}

export class RuleReport {
	report: string;
	schedule: string;
	ruleCount: number;
	completed: number;
}