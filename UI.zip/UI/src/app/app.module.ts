import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DataTablesModule } from 'angular-datatables';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { MatToolbarModule, MatIconModule, MatSidenavModule, MatListModule, MatGridListModule, MatButtonModule, MatSnackBarModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './header/header.component';
import { ReportAnalyticsComponent } from './report-analytics/report-analytics.component';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { AttributeSummaryComponent } from './attribute-summary/attribute-summary.component';
import { FaqComponent } from './faq/faq.component';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { OgmaService } from './ogma.service';
import { TooltipComponent } from './tooltip.component';
import {
  MatTabsModule
} from '@angular/material/tabs';
import { DataGapComponent } from './data-gap/data-gap.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ChartsModule } from 'ng2-charts';
import { LoginComponent } from './login/login.component';
import { SheetComponent } from './sheet/sheet.component';
import { SpreadsheetAllModule } from '@syncfusion/ej2-angular-spreadsheet';
import { ButtonRendererComponent } from './attribute-summary/row-edit.component';
import { ExcelComponent } from './excel/excel.component';
import { NgxDocViewerModule } from 'ngx-doc-viewer';
import { SpreadSheetComponent } from './spread-sheet/spread-sheet.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    ReportAnalyticsComponent,
    AttributeSummaryComponent,
    TooltipComponent,
    FaqComponent,
    DataGapComponent,
    SidebarComponent,
    DashboardComponent,
    LoginComponent,
    SheetComponent,
    ButtonRendererComponent,
    ExcelComponent,
    SpreadSheetComponent
  ],
  imports: [
    BrowserModule,
    SpreadsheetAllModule,
    NgxChartsModule,
    ChartsModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    MatIconModule,
    MatGridListModule,
    HttpClientModule,
    DataTablesModule,
    MatSnackBarModule,
    AgGridModule.withComponents([ButtonRendererComponent]),
    FormsModule,
    ReactiveFormsModule,
    MatTabsModule,
    AutocompleteLibModule,
    NgxDocViewerModule
  ],
  exports: [
    MatTabsModule
  ],
  
  providers: [OgmaService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }


