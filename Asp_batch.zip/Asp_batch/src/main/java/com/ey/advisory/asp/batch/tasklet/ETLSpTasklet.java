package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.etl.service.ETLSpService;

public class ETLSpTasklet implements Tasklet {
	@Autowired
	ETLSpService etlSpCallService;
	private String storedProcName;
	private String storedProcSchema;
	private int inputParamsCount;
	private int outputParamsCount;
	//List that maintains the insertion Order
	private List<String> inputParams;
	private String outputParam;
	private String outputParamListFlag;
	protected static final Logger lOGGER = Logger
			.getLogger(ETLSpTasklet.class);
	
	public String getOutputParamListFlag() {
		return outputParamListFlag;
	}


	public void setOutputParamListFlag(String outputParamListFlag) {
		this.outputParamListFlag = outputParamListFlag;
	}


	public String getOutputParam() {
		return outputParam;
	}


	public void setOutputParam(String outputParam) {
		this.outputParam = outputParam;
	}


	public List<String> getInputParams() {
		return inputParams;
	}


	public void setInputParams(List<String> inputParams) {
		this.inputParams = inputParams;
	}


	public String getStoredProcName() {
		return storedProcName;
	}


	public void setStoredProcName(String storedProcName) {
		this.storedProcName = storedProcName;
	}


	public String getStoredProcSchema() {
		return storedProcSchema;
	}


	public void setStoredProcSchema(String storedProcSchema) {
		this.storedProcSchema = storedProcSchema;
	}


	public int getInputParamsCount() {
		return inputParamsCount;
	}


	public void setInputParamsCount(int inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}


	public int getOutputParamsCount() {
		return outputParamsCount;
	}


	public void setOutputParamsCount(int outputParamsCount) {
		this.outputParamsCount = outputParamsCount;
	}


	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		ExecutionContext executionContext=chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();
		//Trigger Stored procedure with No input and when exactly one result object is expected
		lOGGER.info("Executing ETLSpTakslet with Stored proc name "+ storedProcName);
		try{
		if(inputParamsCount==0 && outputParamsCount==1){
			List<String> outputParamList;
			outputParam=etlSpCallService.executeStoredProcedure(storedProcName);
			if(outputParam !=null && !("null").equals(outputParam) && !("").equals(outputParam.trim())){
				outputParamList=new ArrayList<>();
				outputParamList.add(outputParam);
				executionContext.put("outputParamList", outputParamList);
			}
		}
		//Trigger Stored procedure with No input and No output is expected
		else if(inputParamsCount==0 && outputParamsCount==0){
			outputParam=etlSpCallService.executeStoredProcedure(storedProcName);
		}
		//Trigger Stored procedure with one or many inputs and No output is expected
		else if(inputParamsCount>0 && inputParams !=null && !inputParams.isEmpty() && (inputParams.size()==inputParamsCount)){
			lOGGER.info("Executing ETLSpTakslet with inputParams "+inputParams);
			outputParam=etlSpCallService.executeStoredProcedure(storedProcSchema,storedProcName,inputParamsCount,inputParams);
			lOGGER.info("Executed ETLSpTakslet with inputParams "+inputParams);
			lOGGER.info("Executed ETLSpTakslet with outputParams "+outputParam);
		}
		//Trigger Stored procedure with No input and when   List<object[]> is expected 
		else if(inputParamsCount==0 && ("Y".equals(outputParamListFlag))){
			List<Object[]> outputList=etlSpCallService.executeSPReturnList(storedProcName);
			executionContext.put("outputParamList", outputList);
		}
		//Trigger Stored procedure with one or many inputs and when exactly one result object is expected 
		else if(inputParamsCount>0 && inputParams !=null && !inputParams.isEmpty() && (inputParams.size()==inputParamsCount)&& outputParamsCount==1){
			List<String> outputParamList;
			outputParam=etlSpCallService.executeStoredProcedure(storedProcSchema,storedProcName,inputParamsCount,inputParams);
					if(outputParam !=null && !("null").equals(outputParam) && !("").equals(outputParam.trim())){
						outputParamList=new ArrayList<>();
						outputParamList.add(outputParam);
						executionContext.put("outputParamList", outputParamList);
					}
		}}catch(Exception e){
			lOGGER.error("Exeception in ETLSPTasklet, Exception is "+e);
			throw e;
		}
		return RepeatStatus.FINISHED;
	}

}
