package com.ey.advisory.asp.batch.listener;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;

public class UpdateStatusJobListener implements JobExecutionListener {

	protected static final Logger LOGGER = Logger.getLogger(UpdateStatusJobListener.class);

	@Autowired
	TenantDynamicJobDetailsService tenantDynamicJobDetailsService;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		LOGGER.info("in beforeJob of UpdateStatusJobListener ");		
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		String jobNameGroupCode = jobExecution.getJobParameters().getString("JOB_NAME");
		if (jobNameGroupCode != null) {
			String[] param = jobNameGroupCode.split("_");
			if (param.length > 0) {
				tenantDynamicJobDetailsService.updateJobDetail(param[0], param[1], null);
			}
			LOGGER.info("UpdateStatusJobListener : Updated job status completed for "+param[0] );			
		}		
		
	}

}
