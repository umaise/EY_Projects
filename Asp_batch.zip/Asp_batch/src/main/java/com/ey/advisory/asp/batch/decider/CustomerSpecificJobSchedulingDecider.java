package com.ey.advisory.asp.batch.decider;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:batch.properties")
public class CustomerSpecificJobSchedulingDecider implements JobExecutionDecider {

	protected static final Logger lOGGER = Logger.getLogger(CustomerSpecificJobSchedulingDecider.class);

	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {
		
		lOGGER.info("Inside CustomerSpecificJobSchedulingDecider");
		
		ExecutionContext executionContext = jobExecution.getExecutionContext();
		
		@SuppressWarnings("unchecked")
		List<String> jobPriorityList = (List<String>)executionContext.get("groupPriorityList");

		if(jobPriorityList == null || jobPriorityList.size() == 0){
			lOGGER.info("Returning UNSCHEDULE from CustomerSpecificJobSchedulingDecider");
			return new FlowExecutionStatus("UNSCHEDULE");
		}
		else{
			lOGGER.info("Returning SCHEDULE from CustomerSpecificJobSchedulingDecider");
			return new FlowExecutionStatus("SCHEDULE");
		}
		
		

	}

}
