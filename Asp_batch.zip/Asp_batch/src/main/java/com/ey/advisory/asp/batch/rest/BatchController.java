package com.ey.advisory.asp.batch.rest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.batch.util.JobLaunchHelper;
import com.ey.advisory.asp.client.domain.ClientGroupDomain;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.service.ClientGroupService;
import com.ey.advisory.asp.client.service.EntityHeirarchyService;
import com.ey.advisory.asp.master.domain.CustomerJobDetails;
import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.QuartzJobDetails;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.QuartzJobDetailsRepository;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;
import com.ey.advisory.asp.master.service.CustomerJobDetailsService;
import com.ey.advisory.asp.master.service.GroupService;
import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;

@RestController
@PropertySource("classpath:batch.properties")
public class BatchController {

	@Autowired
	JobLaunchHelper jobLaunchHelper;

	@Autowired
	private TenantDynamicJobDetailsRepository tenantDynamicJobDetailsRepository;

	@Autowired
	CustomerJobDetailsService CustomerJobDetailsService;

	@Autowired
	QuartzJobDetailsRepository quartzJobDetailsRepository;
	
	@Autowired
	TenantDynamicJobDetailsService tenantDynamicJobDetailsService;

	@Autowired
	GroupService groupService;
	
	@Autowired
	ClientGroupService clientGroupService;

	@Autowired
	EntityHeirarchyService entityHeirarchyService;

	private static final Logger LOGGER = Logger.getLogger(BatchController.class);
	private static final String CLASS_NAME = BatchController.class.getName();

	@RequestMapping(value = "/triggerJob/{jobName}", method = RequestMethod.GET)
	public String manuallyTriggerJob(@PathVariable String jobName) {

		try {
			LOGGER.info("Inside manuallyTriggerJob for jobName " + jobName);
			jobLaunchHelper.launchJob(jobName, null);
			LOGGER.info("Exit manuallyTriggerJob for jobName " + jobName);
			return Constant.SUCCESS;
		} catch (JobParametersInvalidException jpie) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : manuallyTriggerJob" + jpie.getMessage());
			return Constant.FAILED;
		} catch (JobExecutionAlreadyRunningException jeare) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : manuallyTriggerJob" + jeare.getMessage());
			return Constant.FAILED;
		} catch (JobRestartException jre) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : manuallyTriggerJob" + jre.getMessage());
			return Constant.FAILED;
		} catch (JobInstanceAlreadyCompleteException jiace) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : manuallyTriggerJob" + jiace.getMessage());
			return Constant.FAILED;
		} catch (NoSuchJobException nsje) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : manuallyTriggerJob" + nsje.getMessage());
			return Constant.FAILED;
		}

	}

	@RequestMapping(value = "/triggerJobManually", method = RequestMethod.POST)
	public String triggerJob(@RequestBody String jsonString) {
		JSONParser jsonParser = new JSONParser();

		try {
			JSONObject jsonObject = (JSONObject) jsonParser.parse(jsonString);
			String jobName = (String) jsonObject.get("jobName");
			LOGGER.info("Inside triggerJob for jobName " + jobName);
			Map<String, Object> jobParams = new HashMap<>();
			if (jsonObject.get("parameterName1") != null && jsonObject.get("parameterValue1") != null) {
				jobParams.put((String) jsonObject.get("parameterName1"), (String) jsonObject.get("parameterValue1"));
			}
			if (jsonObject.get("parameterName2") != null && jsonObject.get("parameterValue2") != null) {
				jobParams.put((String) jsonObject.get("parameterName2"), (String) jsonObject.get("parameterValue2"));
			}
			if (jsonObject.get("parameterName3") != null && jsonObject.get("parameterValue3") != null) {
				jobParams.put((String) jsonObject.get("parameterName3"), (String) jsonObject.get("parameterValue3"));
			}
			jobLaunchHelper.launchQuartzJob(jobName, jobParams);
			LOGGER.info("Exit triggerJob for jobName " + jobName);
		} catch (Exception ex) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : triggerJob" + ex.getMessage());
			return "Job Triggered Failed";
		}
		return "Job Triggered";
	}

	@RequestMapping(value = "/deleteCustomerJob", method = RequestMethod.POST)
	public String deleteCustomerJob(@RequestParam String groupId, @RequestParam String jobName) {

		try {
			LOGGER.info("Inside deleteCustomerJob for jobName " + jobName + " and groupId " + groupId);
			boolean deleted = CustomerJobDetailsService.deleteCustomerDetails(jobName, groupId);
			if (!deleted) {
				LOGGER.info(jobName + " doesn't exist");
				return "Job doesn't Exist";
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : deleteCustomerJob" + ex.getMessage());
			return "Deletion failed";
		}
		LOGGER.info("Exit deleteCustomerJob for jobName " + jobName + " and groupId " + groupId);
		return "Job Deleted";

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/insertCustomerJob", method = RequestMethod.POST)
	public String insertCustomerJob(@RequestBody String jsonString) {
		JSONParser jsonParser = new JSONParser();
		CustomerJobDetails customerJobDetails = null;
		try {
			JSONObject jsonObject = (JSONObject) jsonParser.parse(jsonString);
			String groupId = (String) jsonObject.get("groupEntityId");
			String jobName = (String) jsonObject.get("jobName");
			LOGGER.info("Inside insertCustomerJob for jobName " + jobName + " and groupId " + groupId);
			String cronExpression = (String) jsonObject.get("cronExpression");
			Map<String, Object> jobParameter = (Map<String, Object>) jsonObject.get("jobParameter");
			customerJobDetails = CustomerJobDetailsService.findByBeanNameAndGroupCode(jobName, groupId);
			if (customerJobDetails == null) {
				CustomerJobDetailsService.saveCustomerDetails(groupId, jobName, cronExpression, jobParameter);
			} else {
				customerJobDetails.setCronExpression(cronExpression);
				CustomerJobDetailsService.updateCustomerDetails(customerJobDetails);
			}
			LOGGER.info("Exit insertCustomerJob for jobName " + jobName + " and groupId " + groupId);
		} catch (Exception ex) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : insertCustomerJob" + ex.getMessage());
			return "Insertion failed";
		}
		return "Job Inserted";
	}

	/*
	 * @RequestMapping(value = "/generateGstr2ReconReport/{gstin}/{taxPeriod}",
	 * method = RequestMethod.GET, produces = {
	 * MediaType.APPLICATION_OCTET_STREAM_VALUE }) public HttpEntity<byte[]>
	 * generateGstr2ReconReport(@PathVariable String gstin, @PathVariable String
	 * taxPeriod,
	 * 
	 * @RequestHeader HttpHeaders headers) throws IOException { Map<String,
	 * Object> jobParams = new HashMap<>(); String currentDate = new
	 * SimpleDateFormat("yyyyMMddhhmm").format(new Date());
	 * jobParams.put("gstin", gstin); jobParams.put("triggered", "manual");
	 * jobParams.put("taxPeriod", taxPeriod); jobParams.put("currentDate",
	 * currentDate); InputStream inputStream = null; HttpHeaders header = new
	 * HttpHeaders(); byte[] file = null; String jobName =
	 * Constant.RECON_REPORT_JOB_NAME; try { jobLaunchHelper.launchJob(jobName,
	 * jobParams); inputStream = new FileInputStream(Constant.RECON_FILE_PATH +
	 * "recon_report_" + currentDate + ".xlsx"); file =
	 * IOUtils.toByteArray(inputStream); header.set("Content-Disposition",
	 * "attachment; filename=ReconReport.xlsx");
	 * header.setContentLength(file.length); } catch (Exception e) {
	 * LOGGER.error("Exception in " + CLASS_NAME+
	 * " Method : generateGstr2ReconReport"+ e.getMessage()); } return new
	 * HttpEntity<>(file, header); }
	 * 
	 * 
	 * @RequestMapping(value =
	 * "/generateGstnErrorReport/{gstin}/{taxPeriod}/{processType}", method =
	 * RequestMethod.GET, produces = { MediaType.APPLICATION_OCTET_STREAM_VALUE
	 * }) public HttpEntity<byte[]> generateGSTNErrorReport(@PathVariable String
	 * gstin,@PathVariable String taxPeriod,@PathVariable String
	 * processType, @RequestHeader HttpHeaders headers) throws IOException {
	 * 
	 * Map<String, Object> jobParams = new HashMap<>(); String currentDate=new
	 * SimpleDateFormat("yyyyMMddhhmm").format(new Date());
	 * jobParams.put("triggered", "manual"); jobParams.put("currentDate",
	 * currentDate); jobParams.put("taxPeriod", taxPeriod);
	 * jobParams.put("gstin", gstin); InputStream inputStream ; HttpHeaders
	 * header = new HttpHeaders(); String
	 * jobName=processType.equals(Constant.GSTR1)?Constant.
	 * GSTR1_GSTN_REPORT_JOB_NAME:Constant.GSTR2_GSTN_REPORT_JOB_NAME; byte[]
	 * file = null; try { jobLaunchHelper.launchJob(jobName, jobParams);
	 * inputStream = new FileInputStream(Constant.FILE_PATH +
	 * gstin+"_"+taxPeriod+"_"+processType+"_"+currentDate+".xlsx"); file =
	 * IOUtils.toByteArray(inputStream); header.set("Content-Disposition",
	 * "attachment; filename=ErrorReport.xlsx");
	 * header.setContentLength(file.length);
	 * 
	 * } catch (Exception e) { if(LOGGER.isInfoEnabled()) LOGGER.info(
	 * "Exception in " + CLASS_NAME+ " Method : generateGSTNErrorReport"+
	 * e.getMessage()); }
	 * 
	 * return new HttpEntity<>(file, header);
	 * 
	 * }
	 */

	@RequestMapping(value = "/fetchAllGroups")
	public List<Group> fetchAllGroups() {
		LOGGER.info("Inside BatchController:fetchAllGroups");
		return groupService.getAllGroups();
	}

	@RequestMapping(value = "/getJobsForGroup")
	@ResponseBody
	public List<QuartzJobDetails> getJobsForGroup(@RequestBody String groupName) {
		LOGGER.info("Inside BatchController:getJobsForGroup");
		return quartzJobDetailsRepository.findByJobGroup(groupName);
	}

	/**
	 * This method is used to fetch all the jobDetails for List of groups
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getJobsForGroups")
	@ResponseBody
	public Map<String, List<QuartzJobDetails>> getJobsForGroups() {
		LOGGER.info("Inside BatchController:getJobsForGroups");
		List<String> groupIdList = new ArrayList<>();
		groupIdList.add("CLIENT_MANAGED_JOBS");
		groupIdList.add("CLIENT_SPECIFIC_JOBS");
		groupIdList.add("SYSTEM_CLIENT_JOBS");
		groupIdList.add("SYSTEM_CLIENT_DYNAMIC_JOBS");
		List<QuartzJobDetails> jobsList = quartzJobDetailsRepository.findByJobGroupIn(groupIdList);
		Map<String, List<QuartzJobDetails>> quartzDetails = new HashMap<>();
		List<QuartzJobDetails> qtzJobList;
		if (jobsList != null && !jobsList.isEmpty()) {
			for (int i = 0; i < jobsList.size(); i++) {
				QuartzJobDetails quartzJobDetails = jobsList.get(i);
				if (quartzDetails.containsKey(quartzJobDetails.getQuartzJobDetailsPK().getJobGroup())) {
					quartzDetails.get(quartzJobDetails.getQuartzJobDetailsPK().getJobGroup()).add(quartzJobDetails);
				} else {
					qtzJobList = new ArrayList<>();
					qtzJobList.add(quartzJobDetails);
					quartzDetails.put(quartzJobDetails.getQuartzJobDetailsPK().getJobGroup(), qtzJobList);
				}
			}
		}
		LOGGER.info("Exit BatchController:getJobsForGroups");
		return quartzDetails;
	}

	@RequestMapping(value = "/getEntityNames", method = RequestMethod.POST)
	public List<EntityHierarchy> getEntityNames(@RequestBody String groupId) {
		LOGGER.info("Inside BatchController:getEntityNames");
		return entityHeirarchyService.getEntityNames(groupId);
	}

	@RequestMapping(value = "/scheduleTenantSimpleTrigger", method = RequestMethod.POST)
	public Object scheduleTenantSimpleTrigger(@RequestBody JSONObject jsonObj) {
		LOGGER.info("Inside scheduleTenantSimpleTrigger method ");
		String result = "Success";
		if(jsonObj.containsKey(Constant.PARAMS_KEY) && jsonObj.containsKey(Constant.GROUP_CODE_KEY) && jsonObj.containsKey(Constant.JOB_NAME_KEY) &&  jsonObj.containsKey(Constant.TIME_INTERVAL_KEY)){
		String paramString = (String) jsonObj.get(Constant.PARAMS_KEY);
		String[] params=paramString.split(",");
		String groupCode = (String) jsonObj.get(Constant.GROUP_CODE_KEY);
		String jobName = (String) jsonObj.get(Constant.JOB_NAME_KEY);
		int timeInterval =  Integer.parseInt(jsonObj.get(Constant.TIME_INTERVAL_KEY).toString());
		int repeatCount =  Integer.parseInt(jsonObj.get(Constant.REPEAT_COUNT_KEY).toString());
		int priority =  Integer.parseInt(jsonObj.get(Constant.PRIORITY_KEY).toString());
		LOGGER.info("Inside scheduleTenantSimpleTrigger for jobName " + jobName + " and groupId " + groupCode);
		if (groupCode != null && jobName != null) {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			for(String param:params){
				if(!param.equals(Constant.TIME_INTERVAL_KEY) && !param.equals(Constant.PARAMS_KEY) &&  !param.equals(Constant.PRIORITY_KEY)&&  !param.equals(Constant.REPEAT_COUNT_KEY))
			paramMap.put(param, (String) jsonObj.get(param));
			}
			TenantDynamicJobDetail tenantDynamicJobDetail = new TenantDynamicJobDetail();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream out = null;
			byte[] jobParam = null;
			try {
				out = new ObjectOutputStream(bos);
				out.writeObject(paramMap);
				jobParam = bos.toByteArray();
				tenantDynamicJobDetail.setGroupCode(groupCode);
				tenantDynamicJobDetail.setJobName(jobName);
				tenantDynamicJobDetail.setPriority(priority);
				tenantDynamicJobDetail.setRepeatCount(repeatCount);
				tenantDynamicJobDetail.setRepeatInterval(timeInterval);
				tenantDynamicJobDetail.setJobParam(jobParam);
				tenantDynamicJobDetail.setStatus(Constant.NEW);
				tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
			} catch (Exception ex) {
				result = "Failed";
				LOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
			} finally {
				try {
					bos.close();
				} catch (IOException ex) {
					LOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
					throw new IllegalStateException("Not able to write Job Param");
				}
			}
		}
		LOGGER.info("Exit scheduleTenantSimpleTrigger for jobName " + jobName + " and groupId " + groupCode);
		}
		
		return result;
	}
	
	@RequestMapping(value = "/scheduleSimpleTrigger", method = RequestMethod.POST)
	public Object scheduleSimpleTrigger(@RequestBody JSONObject jsonObj) {
		String result = "Job Triggered";
		String groupCode = (String) jsonObj.get("groupEntityId");
		int timeInterval =  Integer.parseInt(jsonObj.get("timeInterval").toString());
		int repeatCount = Integer.parseInt(jsonObj.get("repeatCount").toString());
		String jobName = (String) jsonObj.get("jobName");
		LOGGER.info("Inside scheduleTenantSimpleTrigger for jobName " + jobName + " and groupId " + groupCode);
		if (groupCode != null && jobName != null && timeInterval>0) {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("groupCode", groupCode);
			TenantDynamicJobDetail tenantDynamicJobDetail = new TenantDynamicJobDetail();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream out = null;
			byte[] jobParam = null;
			try {
				out = new ObjectOutputStream(bos);
				out.writeObject(paramMap);
				jobParam = bos.toByteArray();
				tenantDynamicJobDetail.setGroupCode(groupCode);
				tenantDynamicJobDetail.setJobName(jobName);
				tenantDynamicJobDetail.setPriority(5);
				tenantDynamicJobDetail.setRepeatCount(repeatCount);
				tenantDynamicJobDetail.setRepeatInterval(timeInterval);
				tenantDynamicJobDetail.setJobParam(jobParam);
				tenantDynamicJobDetail.setStatus(Constant.NEW);
				tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
			} catch (Exception ex) {
				result = "Failed";
				LOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
			} finally {
				try {
					bos.close();
				} catch (IOException ex) {
					LOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
					throw new IllegalStateException("Not able to write Job Param");
				}
			}
		}
		LOGGER.info("Exit scheduleTenantSimpleTrigger for jobName " + jobName + " and groupId " + groupCode);
		return result;
	}
	
	@RequestMapping(value = "/scheduleTenantSimpleTriggerForSave", method = RequestMethod.POST)
	public String scheduleTenantSimpleTriggerForSave(@RequestBody JSONObject jsonObj) {
		String result = "Save In-progress, you cant initiate save.";
		String groupCode =""; //(String) jsonObj.get("groupCode");
		String jobName ="";// (String) jsonObj.get("jobName");
		String taxPeriod = (String) jsonObj.get("taxPeriod");
		String gstin = (String) jsonObj.get("GSTIN");
		String returnType = (String) jsonObj.get("returnTypes");
		String userEmailId = (String) jsonObj.get("userEmailId");
		List<ClientGroupDomain> response = null;
		
		response = clientGroupService.getClientGroup();
		//response = clientGroupDao.getClientGroup();
		if(null != response && !response.isEmpty()){
			groupCode = response.get(0).getGroupCode();
		}
		
		if(null != returnType && !returnType.isEmpty()){
			if(returnType.equals(Constant.GSTR1)){
				jobName=Constant.GSTR1_Tenant_SAVE_JOB_NAME;
			}else if(returnType.equals(Constant.GSTR2)){
				jobName=Constant.GSTR2_Tenant_SAVE_JOB_NAME;
			}
		}
		
		LOGGER.info("Inside scheduleTenantSimpleTrigger for jobName " + jobName + " and groupId " + groupCode
				+ " and taxPeriod " + taxPeriod);
		if (groupCode != null && taxPeriod != null) {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("taxPeriod", taxPeriod);
			paramMap.put("groupCode", groupCode);
			paramMap.put("gstin", gstin);
			paramMap.put("returnType", returnType);
			paramMap.put("userEmailId", userEmailId);
			TenantDynamicJobDetail tenantDynamicJobDetail = new TenantDynamicJobDetail();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream out = null;
			byte[] jobParam = null;
			try {
				out = new ObjectOutputStream(bos);
				out.writeObject(paramMap);
				jobParam = bos.toByteArray();
				tenantDynamicJobDetail.setGroupCode(groupCode);
				tenantDynamicJobDetail.setJobName(jobName);
				tenantDynamicJobDetail.setPriority(5);
				tenantDynamicJobDetail.setRepeatCount(0);
				tenantDynamicJobDetail.setRepeatInterval(1);
				tenantDynamicJobDetail.setJobParam(jobParam);
				tenantDynamicJobDetail.setStatus(Constant.NEW);
				
                String gstinId = tenantDynamicJobDetailsService.getJobParamDetails(jobName, groupCode, Arrays.asList(Constant.NEW,Constant.INPROGRESS));
                if(null == gstinId){
                       tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
                       result = "Save Initiated Successfully. Please check status after 15 min.";
                }else{
                       if(!gstinId.equalsIgnoreCase(gstin)){
                              tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
                              result = "Save Initiated Successfully. Please check status after 15 min.";
                       }
                }

				/*if(tenantDynamicJobDetailsService.findByJobNameAndGroupCodeAndStatus(jobName, groupCode, Arrays.asList(Constant.NEW,Constant.INPROGRESS))){
					tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
					result = "Success";
				}*/
			} catch (Exception ex) {
				result = "Failed";
				LOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
			} finally {
				try {
					if(out!=null){
						out.close();
					}
					bos.close();
				} catch (IOException ex) {
					LOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
					throw new IllegalStateException("Not able to write Job Param");
				}
			}
		}
		LOGGER.info("Exit scheduleTenantSimpleTrigger for jobName " + jobName + " and groupId " + groupCode
				+ " and taxPeriod " + taxPeriod);
		return result;
	} 
	


}
