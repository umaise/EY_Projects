package com.ey.advisory.asp.batch.listener;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.JobLaunchHelper;

@Component
public class Gstr2RoutingAndReconProcessJobListener implements JobExecutionListener {

	@Autowired
	JobLaunchHelper jobLaunchHelper;

	private static final Logger logger = Logger.getLogger(Gstr2RoutingAndReconProcessJobListener.class);
	private static final String REPORT_JOB = "reconciliationProcessGstr2Job";

	@Override
	public void beforeJob(JobExecution jobExecution) {
		logger.info("********** Started Job execution " + jobExecution.getJobId());
	}

	@SuppressWarnings("static-access")
	@Override
	public void afterJob(JobExecution jobExecution) {
		logger.info("*********** Finished Job execution " + jobExecution.getJobId());
		if(jobExecution.getExitStatus().COMPLETED == ExitStatus.COMPLETED){
			ExecutionContext stepExecution = jobExecution.getExecutionContext();
			if(stepExecution.containsKey("reconStatus") && stepExecution.get("reconStatus")!=null) {				
					try {
						logger.info("Triggered in Listener "+REPORT_JOB);
						jobLaunchHelper.launchQuartzJob(REPORT_JOB, new HashMap<>());
					} catch (JobParametersInvalidException jpie) {
						jpie.printStackTrace();
						throw new IllegalStateException(jpie.getMessage());
					} catch (JobExecutionAlreadyRunningException jeare) {
						jeare.printStackTrace();
						throw new IllegalStateException(jeare.getMessage());
					} catch (JobRestartException jre) {
						jre.printStackTrace();
						throw new IllegalStateException(jre.getMessage());
					} catch (JobInstanceAlreadyCompleteException jiace) {
						jiace.printStackTrace();
						throw new IllegalStateException(jiace.getMessage());
					} catch (NoSuchJobException nsje) {
						nsje.printStackTrace();
						throw new IllegalArgumentException(nsje.getMessage());
					}
				}
				
			}
		}
	}


