package com.ey.advisory.asp.batch.listener;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;

@Component
public class TimeoutAndPersistRedisToDBPart2Listener implements JobExecutionListener {

	private static final String POLLREDISANDSAVEJOB_JOB = "pollRedisAndSaveJob";

	protected static final Logger LOGGER = Logger.getLogger(ProcessClientFileListener.class);

	@Autowired
	TenantDynamicJobDetailsService tenantDynamicJobDetailsService;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		LOGGER.info("in beforeJob of ProcessClientFileListener ");

	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		JobParameters jobParameters = jobExecution.getJobParameters();
		String groupCode = jobParameters.getString("groupCode");
		if (groupCode != null) {
			LOGGER.info("Executing TimeoutAndPersistRedisToDBPart2Listener and updating status to CTD : > ");
			tenantDynamicJobDetailsService.updateJobDetail(POLLREDISANDSAVEJOB_JOB, groupCode, null);
		}
	}
}