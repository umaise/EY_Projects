package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;
import com.ey.advisory.asp.master.repository.FileUploadStatusRepository;

public class GenericTasklet implements Tasklet {

	protected static final Logger LOGGER = Logger.getLogger(GenericTasklet.class);
	@Autowired
	private FileUploadStatusRepository tblSalesFileStatusRepo;
	
	@Autowired
	ClientSpCallService clientSpCallService;
	
	private String jobStatus;
	private String fileData;
	private String isProcessed;
	private String storedProcName;
	private String storedProcSchema;
	private String inputParamsCount;
	private String updateJobStatusTo;
	private String updateIsProcessedTo;
	
	List<FileUploadStatusMaster> processFileList;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		String status;
		if(LOGGER.isInfoEnabled())
		LOGGER.info("Inside Generic Tasklet execute method");
		processFileList = tblSalesFileStatusRepo.findByIsStageProcessedAndJobStatusAndFileData(isProcessed, jobStatus,fileData); 	
		List<String> fileIdList;
		try{
			if(processFileList.isEmpty()){
				chunkContext.getStepContext().getStepExecution().setExitStatus(ExitStatus.NOOP);
			}
			for (FileUploadStatusMaster tblSalesFileInfo : processFileList) {
				fileIdList = new ArrayList<>();
				fileIdList.add(String.valueOf(tblSalesFileInfo.getFileId()));
				tblSalesFileStatusRepo.updateIsProcessedJobStatus(updateIsProcessedTo, updateJobStatusTo, tblSalesFileInfo.getFileId());
				status=clientSpCallService.executeStoredProcedure(storedProcSchema, storedProcName, inputParamsCount, fileIdList);
				if(Constant.SUCCESS.equalsIgnoreCase(status)){
					tblSalesFileStatusRepo.updateIsProcessedJobStatus(updateIsProcessedTo, Constant.UPDATE_ROUTING_JOB_STATUS_TO, tblSalesFileInfo.getFileId());
					if(LOGGER.isInfoEnabled())
					LOGGER.info("Inside Generic Tasklet execute method routing Job is success");
				}
				if(Constant.FAILED.equalsIgnoreCase(status)){
					chunkContext.getStepContext().getStepExecution().setExitStatus(ExitStatus.NOOP);
					if(LOGGER.isInfoEnabled())
					LOGGER.info("Inside Generic Tasklet execute method routing Job is failed");
					return RepeatStatus.FINISHED;
				}
			}
		}catch(Exception ex){
			LOGGER.error("Exception in the Generic tasklet Execute method.");
			chunkContext.getStepContext().getStepExecution().setExitStatus(ExitStatus.NOOP);
		}
		if(LOGGER.isInfoEnabled())
		LOGGER.info("Generic Tasklet execute method finished");
		return RepeatStatus.FINISHED;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public void setStoredProcName(String storedProcName) {
		this.storedProcName = storedProcName;
	}
	public void setStoredProcSchema(String storedProcSchema) {
		this.storedProcSchema = storedProcSchema;
	}
	public void setInputParamsCount(String inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}
	public void setFileData(String fileData) {
		this.fileData = fileData;
	}
	public void setIsProcessed(String isProcessed) {
		this.isProcessed = isProcessed;
	}
	public void setUpdateJobStatusTo(String updateJobStatusTo) {
		this.updateJobStatusTo = updateJobStatusTo;
	}
	public void setUpdateIsProcessedTo(String updateIsProcessedTo) {
		this.updateIsProcessedTo = updateIsProcessedTo;
	}
}
