package com.ey.advisory.asp.batch.reader;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.client.service.gstr2.Gstr2ReconDetailsService;
import com.ey.advisory.asp.master.repository.FileUploadRepository;

public class Gstr2ReadyToReconFileGstnReader implements ItemReader<String> {

	protected static final Logger lOGGER = Logger.getLogger(Gstr2ReadyToReconFileGstnReader.class);
	private List<String> gstinList;
	private int rowCount;
	@Autowired
	private FileUploadRepository fileUploadRepository;
	@Autowired
	private Gstr2ReconDetailsService gstr2ReconDetailsService;

	@BeforeStep
	public void initializeState(StepExecution stepExecution) {
		lOGGER.info("Inside Gstr2ReadyToReconFileReader:initializeState()");
		List<Integer> fileIdList = fileUploadRepository.getBifurcatedFileIdsForGstr2();
		if(fileIdList != null && fileIdList.size() >0){
			gstinList = gstr2ReconDetailsService.getGstnListForFileId(fileIdList);
		}
		rowCount = 0;
		lOGGER.info("Exit Gstr2ReadyToReconFileReader:initializeState()");
	}

	@Override
	public String read() throws Exception {
		lOGGER.info("Inside Gstr2ReadyToReconFileReader:read() count " + rowCount);
		String gstin = null;
		if (gstinList != null && rowCount < gstinList.size()) {
			gstin = gstinList.get(rowCount);
			rowCount++;
		}
		lOGGER.info("Exit Gstr2ReadyToReconFileReader:read() count " + rowCount);
		return gstin;
	}

}
