package com.ey.advisory.asp.batch.tasklet;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.client.domain.TblEmailStatusDetails;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;

public class UpdateMailStatusTasklet implements Tasklet{
	protected static final Logger LOGGER = Logger.getLogger(UpdateMailStatusTasklet.class);
	@Autowired
	Gstr1Service gstr1Service;
	private List<TblEmailStatusDetails> inputParamList;
	public List<TblEmailStatusDetails> getInputParamList() {
		return inputParamList;
	}


	public void setInputParamList(List<TblEmailStatusDetails> inputParamList) {
		this.inputParamList = inputParamList;
	}


	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		if(LOGGER.isInfoEnabled())
		LOGGER.info("Inside execute method of UpdateMailStatusTasklet() ");
		
		if(inputParamList !=null && !inputParamList.isEmpty() ){
				gstr1Service.updateMailStatus(inputParamList);
		}
		
		if(LOGGER.isInfoEnabled())
	LOGGER.info("Exiting from execute method of UpdateMailStatusTasklet() ");
		return RepeatStatus.FINISHED;
	}

}
