package com.ey.advisory.asp.batch;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

//FIXME removed final class and constructor to public from private.. to support aop
public class AutowireSpringBeanHelper implements ApplicationContextAware {

    private static final AutowireSpringBeanHelper INSTANCE = new AutowireSpringBeanHelper();
    private static ApplicationContext applicationContext;

    public static void autowire(Object classToAutowire, Object... beansToAutowireInClass) {
        for (Object bean : beansToAutowireInClass) {
            if (bean == null) {
                applicationContext.getAutowireCapableBeanFactory().autowireBean(classToAutowire);
                return;
            }
        }
    }

    @Override
    public void setApplicationContext(final ApplicationContext applicationContext) {
        AutowireSpringBeanHelper.applicationContext = applicationContext;
    }

    public static AutowireSpringBeanHelper getInstance() {
        return INSTANCE;
    }

}
