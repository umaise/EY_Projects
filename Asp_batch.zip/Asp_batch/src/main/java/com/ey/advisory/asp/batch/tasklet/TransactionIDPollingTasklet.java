package com.ey.advisory.asp.batch.tasklet;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.ey.advisory.asp.client.dto.TransactionIDPolling;
import com.ey.advisory.asp.client.service.GSTINDetailsService;
import com.ey.advisory.asp.gstn.service.second.IAPIService;

public class TransactionIDPollingTasklet implements Tasklet {

	protected static final Logger LOGGER = Logger.getLogger(TransactionIDPollingTasklet.class);

	@Autowired
	@Qualifier("GSTNService")
	IAPIService gstnServiceImpl;

	@Autowired
	GSTINDetailsService gstinService;


	@Autowired
	GSTINDetailsService gstinDetailsService;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
     try{
		LOGGER.info("Inside TransactionIDPollingTasklet execute method");
		boolean isSummary = false;
		ExecutionContext stepExecution = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getExecutionContext();
		if (com.ey.advisory.asp.batch.util.Constant.SUMMARY_TRNX_ID_POLLING_JOB
				.equalsIgnoreCase(chunkContext.getStepContext().getJobName())) {
			isSummary = true;
		}
		List<TransactionIDPolling> transactionIDPollingCheck = gstinDetailsService
				.getTransactionIDPollingList(isSummary);
		if (!(null == transactionIDPollingCheck && transactionIDPollingCheck.isEmpty())) {
			stepExecution.put("TrnxIDCount", transactionIDPollingCheck.size());			
		}else{
				LOGGER.info("transactionIDPollingCheck is null or empty");
		}
		String jobNameGroupCode = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters().getString("JOB_NAME");
		if (jobNameGroupCode != null) {
			int index = jobNameGroupCode.indexOf("_");
			String param=jobNameGroupCode.substring(index+1);	
				chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("groupCode",param);			
		}
     }catch(Exception e){
    	 LOGGER.error("Exception inside TransactionIDPollingTasklet "+e); 
     }
		return RepeatStatus.FINISHED;
	}
	
}
