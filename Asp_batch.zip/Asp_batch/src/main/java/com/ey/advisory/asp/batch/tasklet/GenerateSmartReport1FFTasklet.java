package com.ey.advisory.asp.batch.tasklet;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.service.GroupService;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;
@PropertySource("classpath:batch.properties")
public class GenerateSmartReport1FFTasklet implements Tasklet {

	@Autowired
	private GroupService groupService;
	
	@Autowired
	BatchClientUtility batchClientUtility;
	
	@Autowired
	private Environment env;
	
	private String group;
	
	private String reportId; 
	
	private String resource;
	
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	protected static final Logger lOGGER = Logger.getLogger(GenerateSmartReport1FFTasklet.class);
	private static final String CLASS_NAME = GenerateSmartReport1FFTasklet.class.getName();
	@SuppressWarnings("unchecked")
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		lOGGER.info("Inside execute method of MakeRestCallToAspAppTasklet : jobName "+Constant.GENERATE_SMART_REPORTS_JOB);
	HttpHeaders httpHeaders = null;
	if(resource!=null && group !=null){
	String path = env.getProperty("batch.restapi.host")+resource;
	httpHeaders = new HttpHeaders();
    httpHeaders.add(TenantConstant.REQUEST_TENANT_HEADER, group);
    try{
    	lOGGER.info("Before executing rest call , group :"+group);
    	lOGGER.info("Before executing rest call , path :"+path);
       String result= batchClientUtility.executeRestCall(path,httpHeaders,reportId,HttpMethod.POST);
    }catch(Exception ex){
    	lOGGER.error("Error while calling App server generate smart report "+ex);
    	chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("exitMessage", ex.getMessage());
    }
    lOGGER.info("Exiting from "+CLASS_NAME+"after completion");
	}
	return RepeatStatus.FINISHED;
	}
	public String getResource() {
		return resource;
	}
	public void setResource(String resource) {
		this.resource = resource;
	}


	
}
