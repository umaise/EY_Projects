package com.ey.advisory.asp.batch.tasklet;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.asp.master.service.ReturnPeriodService;

@Component("getCurrentReturnPeriodTasklet")
public class GetCurrentReturnPeriodTasklet implements Tasklet {

	@Autowired
	private ReturnPeriodService returnPeriodService;

	protected static final Logger lOGGER = Logger
			.getLogger(GetCurrentReturnPeriodTasklet.class);

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		
		ExecutionContext executionContext = chunkContext.getStepContext()
				.getStepExecution().getJobExecution().getExecutionContext();
		String status = "";
		try{
			
			lOGGER.info("Inside execute method of GetCurrentReturnPeriodTasklet");
			ReturnPeriod returnPeriodObj = returnPeriodService.getReturnPeriod();
			
			String currentReturnPeriod = "";
			
			if(returnPeriodObj != null){
				currentReturnPeriod=returnPeriodObj.getTaxPeriodMMYYYY();
			}
			
			if(!"".equals(currentReturnPeriod)){
				status = Constant.SUCCESS;
				executionContext.putString("currentTaxPeriod", currentReturnPeriod);
			}else{
				lOGGER.info("Current return period data is not available in master.tblReturnPeriod table");
				status = Constant.FAILED;
			}
		
		} catch (Exception ex) {
			lOGGER.error("Error while deActivating the existing TaxPeriod and creating Current Period "
					+ ex);
			status = Constant.FAILED;
		}
		executionContext.putString("status", status);
		return RepeatStatus.FINISHED;
	}

}
