package com.ey.advisory.asp.batch.tasklet;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.SmartReport;
import com.ey.advisory.asp.client.service.SmartReportService;
import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;
@PropertySource("classpath:batch.properties")
public class MakeRestCallToAspAppTasklet1FF implements Tasklet  {

	@Autowired
	TenantDynamicJobDetailsService tenantDynamicJobDetailsService;
	
	@Autowired
	BatchClientUtility batchClientUtility;
	
	private String hitCount; 
	
	@Autowired
	private Environment env;
	
	private String resource;
	
	private String group;
	
	private String taxPeriod;
	
	private String token;
	
	private String gstin;
	
	private String action;
	
	@Autowired
	SmartReportService smartReportService;
	
	public String getHitCount() {
		return hitCount;
	}


	public void setHitCount(String hitCount) {
		this.hitCount = hitCount;
	}
	protected static final Logger lOGGER = Logger.getLogger(MakeRestCallToAspAppTasklet1FF.class);
	private static final String CLASS_NAME = MakeRestCallToAspAppTasklet1FF.class.getName();
	@SuppressWarnings("unchecked")
	@Override
	public RepeatStatus execute(StepContribution conribution, ChunkContext chunkContext) throws Exception {
		lOGGER.info("Inside execute method of MakeRestCallToAspAppTasklet : jobName "+Constant.GET_GSTR1FF_FILE_DETAILS_TOKEN_JOB);
		HttpHeaders httpHeaders = null;
		if(resource!=null && group !=null){
		String path = env.getProperty("batch.restapi.host")+resource;
		httpHeaders = new HttpHeaders();
        httpHeaders.add(TenantConstant.REQUEST_TENANT_HEADER, group);
        try{
        	lOGGER.info("Before executing rest call , group :"+group);
        	lOGGER.info("Before executing rest call , path :"+path);
        	JSONObject jsonObject = new JSONObject();
        	jsonObject.put("gstin", gstin);
        	jsonObject.put("token", token);
        	jsonObject.put("taxPeriod", taxPeriod);
        	jsonObject.put("action", action);
        	jsonObject.put("hitCount", hitCount); 
            batchClientUtility.executeRestCallWithoutResponse(path,httpHeaders, jsonObject.toString(),HttpMethod.POST);
        }catch(Exception ex){
        	lOGGER.error("Error while calling App server get File Details "+ex);
        	smartReportService.updateGSTR1FFStatus(gstin, taxPeriod, Constant.FAILED);
        	chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("exitMessage", ex.getMessage());
        }
        lOGGER.info("Exiting from "+CLASS_NAME+"after completion");
		}
		return RepeatStatus.FINISHED;
	}
	
	
	public String getResource() {
		return resource;
	}
	public void setResource(String resource) {
		this.resource = resource;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	 

	
	
}
