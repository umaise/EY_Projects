package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.service.ClientSpCallService;

public class ClientSpTasklet implements Tasklet {

	@Autowired
	ClientSpCallService clientSpCallService;
	private String storedProcName;
	private String storedProcSchema;
	private int inputParamsCount;
	private int outputParamsCount;
	// List that maintains the insertion Order
	private List<String> inputParams;
	private String outputParam;
	private String outputParamListFlag;

	private static final Logger LOGGER = Logger.getLogger(ClientSpTasklet.class);

	public String getOutputParamListFlag() {
		return outputParamListFlag;
	}

	public void setOutputParamListFlag(String outputParamListFlag) {
		this.outputParamListFlag = outputParamListFlag;
	}

	public String getOutputParam() {
		return outputParam;
	}

	public void setOutputParam(String outputParam) {
		this.outputParam = outputParam;
	}

	public List<String> getInputParams() {
		return inputParams;
	}

	public void setInputParams(List<String> inputParams) {
		this.inputParams = inputParams;
	}

	public String getStoredProcName() {
		return storedProcName;
	}

	public void setStoredProcName(String storedProcName) {
		this.storedProcName = storedProcName;
	}

	public String getStoredProcSchema() {
		return storedProcSchema;
	}

	public void setStoredProcSchema(String storedProcSchema) {
		this.storedProcSchema = storedProcSchema;
	}

	public int getInputParamsCount() {
		return inputParamsCount;
	}

	public void setInputParamsCount(int inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}

	public int getOutputParamsCount() {
		return outputParamsCount;
	}

	public void setOutputParamsCount(int outputParamsCount) {
		this.outputParamsCount = outputParamsCount;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		LOGGER.info("Inside ClientSpTasklet:execute()");
		ExecutionContext executionContext = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getExecutionContext();
		// Trigger Stored procedure with No input and when exactly one result
		// object is expected
		if (inputParamsCount == 0 && outputParamsCount == 1) {
			// TODO-Implementation of ClientSpCallService using HibernateDao to
			// trigger SP
		}
		// Trigger Stored procedure with No input and No output is expected
		else if (inputParamsCount == 0 && outputParamsCount == 0) {
			// TODO-Implementation of ClientSpCallService using HibernateDao to
			// trigger SP
		}
		// Trigger Stored procedure with one or many inputs and when exactly one
		// result object is expected
		else if (inputParamsCount > 0 && inputParams != null && !inputParams.isEmpty()
				&& (inputParams.size() == inputParamsCount) && outputParamsCount == 1) {
			List<String> outputParamList;
			LOGGER.info("input params are  "+ inputParams);
			outputParam = clientSpCallService.executeStoredProcedure(storedProcSchema, storedProcName,
					String.valueOf(inputParamsCount), inputParams);
			LOGGER.info("Output param "+ outputParam);
			if (outputParam != null && !outputParam.equals(Constant.FAILED) && !("").equals(outputParam.trim())) {
				outputParamList = new ArrayList<>();
				outputParamList.add(outputParam);
				executionContext.put("outputParamList", outputParamList);
			}
		}
		// Trigger Stored procedure with one or many inputs and No output is
		// expected
		else if (inputParamsCount > 0 && inputParams != null && !inputParams.isEmpty()
				&& (inputParams.size() == inputParamsCount)) {
			clientSpCallService.executeStoredProcedure(storedProcSchema, storedProcName,
					String.valueOf(inputParamsCount), inputParams);
		}
		// Trigger Stored procedure with No input and when List<object[]> is
		// expected
		else if (inputParamsCount == 0 && ("Y".equals(outputParamListFlag))) {
			// TODO-Implementation of ClientSpCallService using HibernateDao to
			// trigger SP
		}

		LOGGER.info("Exit ClientSpTasklet:execute()");

		return RepeatStatus.FINISHED;
	}

}
