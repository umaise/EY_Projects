package com.ey.advisory.asp.batch.writer;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.client.domain.PayloadStatus;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.master.repository.FileUploadStatusRepository;

public class TransactionStatusWriter implements ItemWriter<PayloadStatus>{
	@Autowired
	Gstr1Service gstr1Service;
	@Autowired
	FileUploadStatusRepository salesFileStatusRepo;
	Set<Integer> fileIdsSet=new HashSet<>();
	

	@Override
	public void write(List<? extends PayloadStatus> items) throws Exception {
		for(PayloadStatus payloadDetails:items){
			if(payloadDetails.getTransactionStatus()!=null){
				fileIdsSet.add(payloadDetails.getFileId());
				gstr1Service.updateTransactionStatus(payloadDetails);
			}
		}
	}
	
	@AfterStep
    public void afterStep(StepExecution stepExecution) throws IOException {
		for(Integer fileId:fileIdsSet){
		salesFileStatusRepo.updateIsProcessedJobStatus(Constant.IS_PROCESSED_TRANSACTION_ACK,Constant.JOB_STATUS_PIPELINE, fileId);
    }
	}

}
