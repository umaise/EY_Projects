package com.ey.advisory.asp.quartz.dynamicScheduler;

import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.ey.advisory.asp.master.domain.CustomerJobDetails;
import com.ey.advisory.asp.master.service.CustomerJobDetailsService;

public class ClientManagedDynamicScheduler implements InitializingBean {

	@Autowired
	@Qualifier("clientManagedDynaScheduler")
	private DynamicScheduler dynamicScheduler;

	@Autowired
	private CustomerJobDetailsService customerJobDetailsService;

	private Scheduler scheduler;

	protected static final Logger LOGGER = Logger.getLogger(ClientManagedDynamicScheduler.class);
	private static final String CLASS_NAME = ClientManagedDynamicScheduler.class.getName();

	@Autowired
	public ClientManagedDynamicScheduler(@Qualifier("clientManagedJobScheduler") Scheduler newScheduler) {
		this.scheduler = newScheduler;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		dynamicScheduler.setScheduler(scheduler);
		List<CustomerJobDetails> customerJobDetailsList = customerJobDetailsService.getCustomerDetails();
		for (CustomerJobDetails customerJobDetails : customerJobDetailsList) {
			scheduleJob(customerJobDetails);
		}
	}

	public void scheduleJob(CustomerJobDetails customerJobDetails) {
		try {
			String jobName = customerJobDetails.getBeanName();
			String cronExpression = customerJobDetails.getCronExpression();
			//jobName = jobName + "_" + cronExpression.replaceAll("[,\\s]", "");
			dynamicScheduler.scheduleInvocation(jobName, customerJobDetails.getGroupCode(), cronExpression,
					customerJobDetails.getJobData());

		} catch (Exception ex) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : executeInternal" + ex.getMessage());
			throw new IllegalStateException("Not able to schedule job");
		}
	}

	public void deleteJob(CustomerJobDetails customerJobDetails) {
		String jobName = customerJobDetails.getBeanName();
		JobDetail job = dynamicScheduler.createDynamicJobDetail(jobName, customerJobDetails.getGroupCode(),
				customerJobDetails.getJobData());
		CronTrigger trigger = dynamicScheduler.buildCronTrigger(jobName, customerJobDetails.getGroupCode(),
				customerJobDetails.getCronExpression());
		dynamicScheduler.deleteJob(job, trigger);
	}

}
