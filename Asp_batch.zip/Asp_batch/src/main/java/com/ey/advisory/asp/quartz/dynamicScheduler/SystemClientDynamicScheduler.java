package com.ey.advisory.asp.quartz.dynamicScheduler;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;

public class SystemClientDynamicScheduler implements InitializingBean {
    
    @Autowired
    @Qualifier("systemClientDynaScheduler")
    private DynamicScheduler dynamicScheduler;
    
    @Autowired
    TenantDynamicJobDetailsRepository jobDetailsRepository;
    
    private Scheduler scheduler;

    
    protected static final Logger LOGGER = Logger.getLogger(SystemClientDynamicScheduler.class);
   	private static final String CLASS_NAME = SystemClientDynamicScheduler.class.getName();

    @Autowired
    public SystemClientDynamicScheduler(@Qualifier("systemClientDynaJobScheduler") Scheduler newScheduler) {
        this.scheduler = newScheduler;
    }
    
    public int scheduleJob(TenantDynamicJobDetail JobDetails) {

        JobDataMap jobDataMap = new JobDataMap();
        
        JobDetail job ;
        
        String param = readJobParam(JobDetails, jobDataMap);        
        
        String jobName;
        
        if(jobDataMap != null && jobDataMap.containsKey("entityId"))
        {
        	param="_"+(String)jobDataMap.get("entityId")+"_"+jobDataMap.get("entityCode");
        }
        if(jobDataMap != null && jobDataMap.containsKey("invoiceType") && jobDataMap.containsKey("gstin"))
        {
        	param="_"+(String)jobDataMap.get("invoiceType")+"_"+(String)jobDataMap.get("gstin");
        }
        if(jobDataMap != null && jobDataMap.containsKey(Constant.JOB_NAME_KEY) && ((String)jobDataMap.get(Constant.JOB_NAME_KEY)).equals(Constant.RECON_JOB_NAME))
        {
        	param="_"+(String)jobDataMap.get("gstin");
        }
        if(jobDataMap != null && jobDataMap.containsKey("reportId"))
        {
        	param="_"+(String)jobDataMap.get("reportId");
        } 
        jobName=JobDetails.getJobName()+"_"+JobDetails.getGroupCode()+param;
    
        jobDataMap.put("JOB_NAME", jobName);
       
        dynamicScheduler.setScheduler(scheduler);  
        
        
        if(dynamicScheduler.checkIfSameJobExistWithDiffFileId(jobName,JobDetails.getGroupCode(),jobDataMap) /*|| 
        		checkIfSameJobExistInProcessingState(JobDetails.getJobName(), JobDetails.getGroupCode(), param)*/ ){
           return -1;
        }
        
       /* if(JobDetails.getFlag() == -1 && checkIfSameJobExistInProcessingState(JobDetails.getJobName(), JobDetails.getGroupCode(), param)){
        	return -1;
        }*/
        
        //Proper Job description needs to be mentioned
        job = dynamicScheduler.createTenantDynamicJobDetail(jobName, JobDetails.getGroupCode(), "");    
        
        Iterator<String> keys = jobDataMap.keySet().iterator();
        while (keys.hasNext()) {
            String key = (String) keys.next();
            Object value = jobDataMap.get(key);
            job.getJobDataMap().put(key, value);            
        }
        
        Trigger trigger = dynamicScheduler.buildSimpleTrigger(jobName, JobDetails.getGroupCode(), JobDetails.getRepeatInterval(),
            JobDetails.getRepeatCount(), JobDetails.getPriority());
     
        
        return dynamicScheduler.scheduleJobWithSimpleTrigger(job, trigger);
        
    }
    
    public boolean checkIfSameJobExistInProcessingState(String jobName, String groupCode, String param){
    	
    	List<TenantDynamicJobDetail> jobDetails ;
    	
    	jobDetails = jobDetailsRepository.getJobDetailsForInput(jobName, groupCode);
    	
        for(TenantDynamicJobDetail jobDetail : jobDetails){        	
        	 JobDataMap jobDataMap = new JobDataMap();
        	 String existingParam = readJobParam(jobDetail, jobDataMap);        	 
        	 if(jobDataMap != null && jobDataMap.containsKey("entityId"))
             {
        		 existingParam="_"+(String)jobDataMap.get("entityId")+"_"+jobDataMap.get("entityCode");
             }         	
        	 if(param.equals(existingParam)){
        		 return true;
        	 }
        }
    	
    	return false;
    	
    }

    @SuppressWarnings("unchecked")
    public String readJobParam(TenantDynamicJobDetail jobDetails,JobDataMap jobDataMap){
    	
    	String param = "";
    	
    	 if (jobDetails.getJobParam() != null) {
             InputStream is = new ByteArrayInputStream(jobDetails.getJobParam());
             ObjectInputStream ois = null;
             String values[] = null;
             try {
                 ois = new ObjectInputStream(is);
                 Map<String, Object> inputJobMap = (Map<String, Object>) ois.readObject();
                 if (inputJobMap != null) {
                     Iterator<String> keys = inputJobMap.keySet().iterator();
                     while (keys.hasNext()) {
                         String key = (String) keys.next();
                         Object value = inputJobMap.get(key);
                         if(("paramsList").equals(key)){
                             values= ((String)value).split(",");
                             if(values.length>2)
                             param = param+"_"+values[2];
                         }
                         jobDataMap.put(key, value);
                     }
                 }
             }
             catch (Exception e) {
             	if(LOGGER.isInfoEnabled())
                 LOGGER.info("Exception in " + CLASS_NAME+ " Method : readJobParam"+ e.getMessage());
                 throw new IllegalStateException("Not able to parse Job Param");
             }
             finally{
             	try {
     				ois.close();
     				is.close();
     			} catch (IOException ex) {
     				throw new IllegalStateException("Not able to write Job Param");
     			}
             	
             }
         }
    	 
    	 return param;  
    	
    }
    
    @Override
    public void afterPropertiesSet() throws Exception {
        
        List<TenantDynamicJobDetail> multiTenantJobDetailsList = jobDetailsRepository.getJobDetails();
        
        for(TenantDynamicJobDetail jobDetail : multiTenantJobDetailsList){
        	jobDetail.setFlag(-1);
            int isUpdate = scheduleJob(jobDetail);
            if(isUpdate != -1) {
            	jobDetail.setStatus(Constant.INPROGRESS);
            	//jobDetail.setUpdated(new Date());
                jobDetailsRepository.save(jobDetail);
            }

        }
        
    }

}
