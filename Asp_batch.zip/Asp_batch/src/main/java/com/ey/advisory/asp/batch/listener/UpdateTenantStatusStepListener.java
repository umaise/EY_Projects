package com.ey.advisory.asp.batch.listener;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;
@Component
public class UpdateTenantStatusStepListener implements StepExecutionListener  {

	protected static final Logger LOGGER = Logger.getLogger(UpdateTenantStatusStepListener.class);

	@Autowired
	TenantDynamicJobDetailsService tenantDynamicJobDetailsService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		LOGGER.info("Inside UpdateStatusJobListener : Updated job status ");
		String exitMessage=null;
		String jobNameGroupCode = stepExecution.getJobExecution().getJobParameters().getString("JOB_NAME");
		if(stepExecution.getJobExecution().getExecutionContext().containsKey("exitMessage")){
		exitMessage=stepExecution.getJobExecution().getExecutionContext().getString("exitMessage");
		}
		ExitStatus exitStatus=stepExecution.getExitStatus();
		if (jobNameGroupCode != null) {
			String[] param = jobNameGroupCode.split("_");
			if (param.length > 0) {
				tenantDynamicJobDetailsService.updateJobDetail(param[0], param[1], null);
			}
			LOGGER.info("UpdateStatusJobListener : Updated job status completed for "+param[0] );			
		}	
		if(exitMessage!=null){
		exitStatus=new ExitStatus("ERROR",exitMessage);
		}
		return exitStatus;
	}


}
