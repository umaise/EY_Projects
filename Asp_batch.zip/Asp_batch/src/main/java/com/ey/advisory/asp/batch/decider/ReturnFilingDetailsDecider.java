package com.ey.advisory.asp.batch.decider;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.Constant;
@Component
public class ReturnFilingDetailsDecider implements JobExecutionDecider{
	protected static final Logger lOGGER = Logger.getLogger(ReturnFilingDetailsDecider.class);
	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution,
			StepExecution stepExecution) {
		lOGGER.info("Inside ReturnFilingDetailsDecider");
		ExecutionContext executionContext=jobExecution.getExecutionContext();
		String flowstatus="EXIT";
		if(executionContext.containsKey("status")){
			String status=executionContext.getString("status");
				if(Constant.SUCCESS.equals(status)){
					lOGGER.info("ReturnType Decider scheduling outward ");
					flowstatus="SEND_TO_RETURN_FILING_DETAILS";
				}
		}
		lOGGER.info("ReturnFilingDetailsDecider scheduling  with status "+flowstatus);
		return new FlowExecutionStatus(flowstatus);
	}

}
