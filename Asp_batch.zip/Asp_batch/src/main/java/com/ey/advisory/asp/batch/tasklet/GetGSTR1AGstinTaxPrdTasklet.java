package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;
import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.asp.master.repository.IReturnPeriodRepository;

public class GetGSTR1AGstinTaxPrdTasklet implements Tasklet {

	protected static final Logger LOGGER = Logger.getLogger(GetGSTR1AGstinTaxPrdTasklet.class);
	
	@Autowired
	private Gstr1Service gstr1Service;
	
	@Autowired
	private IReturnPeriodRepository iReturnPeriodRepository;
	
	String taxPeriod;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		ExecutionContext executionContext=chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();
		List<String> gstinList=new ArrayList<>();
		Map<String, List<String>> gstinTaxPrdMap=new HashMap<>();
		
		ReturnPeriod returnPeriod= iReturnPeriodRepository.findByIsCurrentPeriod(true);
		Calendar cal = Calendar.getInstance();
		cal.setTime(returnPeriod.getStartDt());
		int month = cal.get(Calendar.MONTH)+1;
		int year = cal.get(Calendar.YEAR);
		String monthTwoDigits=(month)<10 ? "0"+String.valueOf(month): String.valueOf(month);
		taxPeriod= monthTwoDigits + String.valueOf(year);
		
		List<TblGstinRetutnFilingStatus> retFilingStatusList = gstr1Service.getReturnFilingDetailsForGSTR1A(taxPeriod, Constant.GSTR2, Constant.RET_FILING_STATUS_SUBMITTED, Constant.ONE);
		retFilingStatusList.forEach(item -> gstinList.add(item.getId().getGstinId()));
		gstinTaxPrdMap.put(taxPeriod, gstinList);
		 
		executionContext.put("gstinTaxPeriodMap", gstinTaxPrdMap);
		return RepeatStatus.FINISHED;
	}

}
