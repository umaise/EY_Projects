package com.ey.advisory.asp.quartz;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.UnableToInterruptJobException;
import org.quartz.impl.JobDetailImpl;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.configuration.JobLocator;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.ey.advisory.asp.batch.util.Constant;

public class TenantJobLauncher extends QuartzJobBean implements ApplicationContextAware, InterruptableJob {

	@Autowired
	private ApplicationContext appContext;

	private static final String JOB_NAME = "jobName";

	private JobLocator jobLocator;

	private JobLauncher jobLauncher;

	/**
	 * Flag to indicate whether this job has been interrupted. When this flag
	 * becomes true the job should stop what it is doing and finish.
	 */
	private boolean hasBeenInterrupted = false;

	protected static final Logger LOGGER = Logger.getLogger(TenantJobLauncher.class);
	private static final String CLASS_NAME = TenantJobLauncher.class.getName();

	public void setJobLocator(JobLocator jobLocator) {
		this.jobLocator = jobLocator;
	}

	public void setJobLauncher(JobLauncher jobLauncher) {
		this.jobLauncher = jobLauncher;
	}

	@Override
	public void setApplicationContext(ApplicationContext appContext) throws BeansException {
		this.appContext = appContext;
	}

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		if (!hasBeenInterrupted) {
			LOGGER.info("hasNotBeenInterrupted ....executeInternal");
			Map<String, Object> jobParams = context.getMergedJobDataMap();

			String jobInScheduler = context.getJobDetail().getKey().getName();

			if (jobInScheduler != null) {

				String jobNameWithParam[] = jobInScheduler.split("_");

				Map<String, Object> jobDataMap = ((JobDetailImpl) appContext.getBean(jobNameWithParam[0]))
						.getJobDataMap();

				String jobName = (String) jobDataMap.get(JOB_NAME);

				JobParameters jobParameters = getJobParametersFromJobMap(jobDataMap, jobParams);

				if (jobName != null) {
					try {
						List<JobExecutionContext> jobs = context.getScheduler().getCurrentlyExecutingJobs();
						for (JobExecutionContext job : jobs) {
							if (job.getTrigger().equals(context.getTrigger())
									&& !job.getFireInstanceId().equals(context.getFireInstanceId())) {
								LOGGER.info(
										"There's another instance of same job currently running, so leaving" + this);
								return;
							}
						}
						Job job = jobLocator.getJob(jobName);
						jobLauncher.run(job, jobParameters);
					} catch (Exception e) {
						LOGGER.error("Exception in " + CLASS_NAME + " Method : executeInternal" + e.getMessage());
						throw new IllegalStateException("Not able to launch job " + jobName);
					}
				}
			}
		}
		LOGGER.info("hasBeenInterrupted ....executeInternal");
	}

	private JobParameters getJobParametersFromJobMap(Map<String, Object> jobDataMap, Map<String, Object> jobParams) {

		JobParametersBuilder builder = new JobParametersBuilder();

		for (Entry<String, Object> entry : jobDataMap.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			if (value instanceof String && !key.equals(JOB_NAME)) {
				builder.addString(key, (String) value);
			} else if (value instanceof Float || value instanceof Double) {
				builder.addDouble(key, ((Number) value).doubleValue());
			} else if (value instanceof Integer || value instanceof Long) {
				builder.addLong(key, ((Number) value).longValue());
			} else if (value instanceof Date) {
				builder.addDate(key, (Date) value);
			} else {
				// JobDataMap contains values which are not job parameters
				// (ignoring)
			}
		}

		for (Map.Entry<String, Object> entry : jobParams.entrySet()) {
			String key = entry.getKey();
			Object value = jobParams.get(key);
			if (value instanceof String) {
				builder.addString(key, (String) value);
			} else if (value instanceof Float || value instanceof Double) {
				builder.addDouble(key, ((Number) value).doubleValue());
			} else if (value instanceof Integer || value instanceof Long) {
				builder.addLong(key, ((Number) value).longValue());
			} else if (value instanceof Date) {
				builder.addDate(key, (Date) value);
			} else {
				// JobDataMap contains values which are not job parameters
				// (ignoring)
			}

		}

		// need unique job parameter to rerun the same job
		builder.addDate(Constant.JOB_RUN_DATE, new Date());

		return builder.toJobParameters();

	}

	@Override
	public void interrupt() throws UnableToInterruptJobException {
		hasBeenInterrupted = true;
	}

}
