package com.ey.advisory.asp.batch.tasklet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.redis.JedisConnectionUtil2;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;

@Component
public class PollRedisAndTriggerTasklet implements Tasklet {

	private static final Logger lOGGER = Logger.getLogger(PollRedisAndTriggerTasklet.class);
	private static final String CLASS_NAME = PollRedisAndTriggerTasklet.class.getName();

	@Autowired
	private TenantDynamicJobDetailsRepository tenantDynamicJobDetailsRepository;
	@Autowired
	private JedisConnectionUtil2 jedisConnectionUtil;
	private String jobName;
	private int repeatCount;
	private int repeatInterval;
	private String id;
	private int timedOutRetryCnt;

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public int getRepeatCount() {
		return repeatCount;
	}

	public void setRepeatCount(int repeatCount) {
		this.repeatCount = repeatCount;
	}

	public int getRepeatInterval() {
		return repeatInterval;
	}

	public void setRepeatInterval(int repeatInterval) {
		this.repeatInterval = repeatInterval;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public int getTimedOutRetryCnt() {
		return timedOutRetryCnt;
	}

	public void setTimedOutRetryCnt(int timedOutRetryCnt) {
		this.timedOutRetryCnt = timedOutRetryCnt;
	}

	private RedisTemplate<String, Object> redisTemplate = null;
	private RedisTemplate<String, String> redisStringtemplate = null;
	private RedisTemplate<String, Integer> redisIntegertemplate = null;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		lOGGER.info("Starting PollRedisAndTriggerTasklet.execute() : " + jobName);
		RedisConnection connection = null;
		long startTime = System.currentTimeMillis();

		try {
			lOGGER.info("Before  redisIntegertemplate intialization...");
			redisTemplate = jedisConnectionUtil.getRedisTemplateKVStringObject();
			redisStringtemplate = jedisConnectionUtil.getRedisTemplateKVStringString();
			redisIntegertemplate = jedisConnectionUtil.getRedisTemplateKVStringInteger();
			Map<String, StringBuilder> groupVsChunksMap = new HashMap<String, StringBuilder>();

			int countValue = 100;
			String pattern = "gstr*_" + Constant.INVOICE_COUNT;
			boolean done = false;

			ScanOptions options = ScanOptions.scanOptions().match(pattern).count(countValue).build();
			connection = redisTemplate.getConnectionFactory().getConnection();
			while (!done) {
				try {
					Cursor<byte[]> it = connection.scan(options);
					if (it != null) {
						lOGGER.info("Cursor is not null : ");
						while (it.hasNext()) {
							byte[] data = (byte[]) it.next();
							String fileInvCountKey = new String(data, 0, data.length);
							String[] fileIdKey = fileInvCountKey.split("_");
							String fileKey = fileIdKey[0] + "_" + fileIdKey[1] + "_" + fileIdKey[2];
							String invCountKey = fileKey + "_" + Constant.INVOICE_COUNT;
							String groupCodeKey = fileKey + "_" + Constant.GROUP_CODE;
							String invProcessedKey = fileKey + "_" + Constant.INVOICE_PSD_COUNT;
							String previousInvProcessedKey = fileKey + "_" + Constant.PREV_INVOICE_PSD_COUNT;
							String tenantJobCreatedKey = fileKey + "_" + Constant.TENANT_JOB_CREAYED_FLAG;
							String timedOutRetryCntKey = fileKey + "_" + Constant.TIMED_OUT_RETRY_CNT;

							Integer invCount = (Integer) redisTemplate.opsForValue().get(invCountKey);

							if (invCount == null || invCount == 0) {
								invCount = redisIntegertemplate.opsForValue().get(invCountKey);
								// Below line is to get invoice count using
								// default RedisTemplate of jdk key value
								// serialize in other places
								redisTemplate.opsForValue().set(invCountKey, invCount);
							}

							Long processedInvCnt = redisTemplate.opsForHash().size(invProcessedKey);

							Long previousInvProcessed = (Long) redisTemplate.opsForValue().get(previousInvProcessedKey);
							boolean isRetryRequired=false;
							
							String isTenantJobCreated = redisStringtemplate.opsForValue().get(tenantJobCreatedKey);
							Integer retryCntVal=(Integer) redisTemplate.opsForValue().get(timedOutRetryCntKey);
							
							//Below condition to avoid tenant job creation till retry count match in case of timed out scenario.
							if(processedInvCnt != null && processedInvCnt.longValue() != 0 && 
									previousInvProcessed != null && previousInvProcessed.longValue() != 0
									&& processedInvCnt.equals(previousInvProcessed) 
									&& !processedInvCnt.equals(invCount.longValue())){
								
									if(retryCntVal!=null && (retryCntVal.compareTo(timedOutRetryCnt) >= 0)){
										isRetryRequired=false;
										lOGGER.info("Reached retry count for file chunk : " + timedOutRetryCntKey);
									}else{
										isRetryRequired=true;
										retryCntVal=(retryCntVal!=null) ? (retryCntVal+1):0;
										redisTemplate.opsForValue().set(timedOutRetryCntKey, retryCntVal);
										lOGGER.info("Retry count for file chunk : " + timedOutRetryCntKey + " is " +(retryCntVal-1));
									}
							}

							lOGGER.info("previous processed count for " + previousInvProcessedKey + " : "
									+ previousInvProcessed);
							lOGGER.info("current processed count for " + invProcessedKey + " : " + processedInvCnt);
							lOGGER.info("Tenant Job Craeted for " + tenantJobCreatedKey + " : " + isTenantJobCreated);

							if (processedInvCnt != null && processedInvCnt.longValue() != 0
									&& (isTenantJobCreated == null || "".equals(isTenantJobCreated)) 
									&& !isRetryRequired
									&& (processedInvCnt.equals(invCount.longValue())
											|| (previousInvProcessed != null && previousInvProcessed.longValue() != 0
													&& processedInvCnt.equals(previousInvProcessed)))) {

								String groupCode = (String) redisStringtemplate.opsForValue().get(groupCodeKey);
								String fileId = fileIdKey[1];

								if (groupCode != null && fileId != null) {

									if (groupVsChunksMap.containsKey(groupCode)) {
										StringBuilder fileListString = groupVsChunksMap.get(groupCode);
										fileListString.append(Constant.SEPRATOR);
										fileListString.append(fileKey);
										groupVsChunksMap.put(groupCode, fileListString);
									} else {
										StringBuilder fileListString = new StringBuilder();
										fileListString.append(fileKey);
										groupVsChunksMap.put(groupCode, fileListString);
									}

								}
								// }
							} else if (processedInvCnt.longValue() > 0) {
								lOGGER.info("Pushing previousInvProcessedKey as : " + jobName);
								redisTemplate.opsForValue().set(previousInvProcessedKey, processedInvCnt);
							}
						} // inner while ends - for each key found
					} else {
						lOGGER.error("Redis tracker map is null : " + jobName);
					}
					done = true;
				} catch (NoSuchElementException nse) {
					lOGGER.info(
							"Going for " + countValue + " was not hard enough. Trying harder with : " + countValue * 2);
					options = ScanOptions.scanOptions().match(pattern).count(countValue * 2).build();
				}
			} // outer while ends - for trying with higher option

			saveTrigersForPersistDBJob(groupVsChunksMap,redisStringtemplate);

		} catch (Exception e) {
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			lOGGER.error("PollRedisAndTriggerTasklet ERROR : " + errors.toString());
		} finally {
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}
			long endTime = System.currentTimeMillis();
			long totalTime = (endTime - startTime) / 1000;
			lOGGER.info("Time taken PollRedisAndTriggerTasklet.execute() : " + totalTime + " in Seconds");
		}

		return RepeatStatus.FINISHED;
	}

	private void saveTrigersForPersistDBJob(Map<String, StringBuilder> groupVsChunksMap,RedisTemplate<String, String> redisStringtemp) {

		for (String groupCode : groupVsChunksMap.keySet()) {
			StringBuilder fileListString = groupVsChunksMap.get(groupCode);

			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(id, fileListString.toString());
			paramMap.put("groupCode", groupCode);

			TenantDynamicJobDetail tenantDynamicJobDetail = new TenantDynamicJobDetail();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream out = null;
			byte[] jobParam = null;
			try {
				out = new ObjectOutputStream(bos);
				out.writeObject(paramMap);
				jobParam = bos.toByteArray();
				tenantDynamicJobDetail.setGroupCode(groupCode);
				tenantDynamicJobDetail.setJobName(jobName);
				tenantDynamicJobDetail.setPriority(10);
				tenantDynamicJobDetail.setRepeatCount(repeatCount);
				tenantDynamicJobDetail.setRepeatInterval(repeatInterval);
				tenantDynamicJobDetail.setJobParam(jobParam);
				tenantDynamicJobDetail.setStatus(Constant.NEW);

				tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
				
				String[] fileKeys = fileListString.toString().split(Constant.SEPRATOR);
				for(String fileKey :fileKeys){
					String tenantJobCreatedKey = fileKey + "_" + Constant.TENANT_JOB_CREAYED_FLAG;
					redisStringtemp.opsForValue().set(tenantJobCreatedKey, "Yes");
				}
				if (lOGGER.isInfoEnabled())
					lOGGER.info("Job has been scheduled " + jobName);

			} catch (Exception ex) {
				lOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
			} finally {
				try {
					if(bos!=null){
						bos.close();
					}
					if(out!=null){
						out.close();
						}
				} catch (IOException ex) {
					throw new IllegalStateException("Not able to write Job Param");
				}
			}

		}
	}
}