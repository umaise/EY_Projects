package com.ey.advisory.asp.batch.reader;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import com.ey.advisory.asp.client.domain.InvoiceKeyDetail;
import com.ey.advisory.asp.client.dto.TechReconDTO;
import com.ey.advisory.asp.client.service.GSTINDetailsService;
import com.ey.advisory.asp.client.service.TblGstinListService;
import com.ey.advisory.asp.multitenancy.BatchTenantContext;

public class TechReconReader implements ItemReader<TechReconDTO> {

	private static final Logger LOGGER = Logger.getLogger(TechReconReader.class);
	private static final String CLASS_NAME = TechReconReader.class.getName();
	private String group;
	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	@Autowired
	GSTINDetailsService gstinDetailsService;

	List<TechReconDTO> finalTechReconList;

	private int rowCount = 0;

	@BeforeStep
	public void getTechReconData(StepExecution stepExecution) {
		try {
			BatchTenantContext.setTenantId(group);
			String jobName = null;
			JobExecution jobExecution = stepExecution.getJobExecution();
			jobName = jobExecution.getJobInstance().getJobName();
			jobExecution.getExecutionContext().put("groupCode",group);
			LOGGER.info("Inside getTechReconData() of" + CLASS_NAME);
			LOGGER.info("Job Name" + jobName);

			finalTechReconList=gstinDetailsService.getTechReconDTOList();
		} catch (Exception e) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : getTechReconData" + e.getMessage());
		}
	}

	@Override
	public TechReconDTO read()
			throws UnexpectedInputException, ParseException, NonTransientResourceException, Exception {

		TechReconDTO techReconDTO = null;
		try {
			if (finalTechReconList != null && rowCount < finalTechReconList.size()) {
				LOGGER.info("finalTechReconList size = " + finalTechReconList.size());
				techReconDTO = finalTechReconList.get(rowCount);
				++rowCount;
			}
			else{
				LOGGER.info("finalTechReconList is empty");
			}

		}
		catch (Exception e) {
			LOGGER.error("Exception in " + CLASS_NAME + " Method : getTechReconData" + e.getMessage());
		}
		return techReconDTO;
	}
}
