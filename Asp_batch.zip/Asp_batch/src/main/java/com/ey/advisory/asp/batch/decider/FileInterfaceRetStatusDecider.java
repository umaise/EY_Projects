package com.ey.advisory.asp.batch.decider;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.Constant;

/**
 * @author Smruti.Pradhan Decider for InterfacetoGSTN Job
 */
@Component
public class FileInterfaceRetStatusDecider implements JobExecutionDecider {
	protected static final Logger LOGGER = Logger.getLogger(FileInterfaceRetStatusDecider.class);

	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {

		ExecutionContext executionContext = stepExecution.getJobExecution().getExecutionContext();
		LOGGER.info("Executing Decision with FileInterfaceRetStatusDeciderTasklet :  ");
		String isRetStatusReq = null;
		if (executionContext.containsKey("isRetStatusReq") && executionContext.get("isRetStatusReq") != null)
			isRetStatusReq = (String) executionContext.get("isRetStatusReq");

		if (isRetStatusReq.equals(Constant.No))
			return FlowExecutionStatus.STOPPED;
		else {
			LOGGER.info("Executing Decision with FileInterfaceRetStatusDeciderTasklet :");
			return FlowExecutionStatus.COMPLETED;
		}

	}

}
