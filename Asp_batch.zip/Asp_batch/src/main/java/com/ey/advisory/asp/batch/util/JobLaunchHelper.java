package com.ey.advisory.asp.batch.util;

import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component(value = "jobLaunchHelper")
public class JobLaunchHelper implements ApplicationContextAware {

  protected static final Logger LOGGER = Logger.getLogger(JobLaunchHelper.class);
  private static final String CLASS_NAME = JobLaunchHelper.class.getName();

  @Autowired(required = false)
  private JobRegistry jobRegistry;

  @Autowired(required = false)
  private JobLauncher syncJobLauncher;

  private ApplicationContext applicationContext;

  public void launchJob(String jobName, Map<String, Object> jobParams)
      throws JobParametersInvalidException,
      JobExecutionAlreadyRunningException, JobRestartException,
      JobInstanceAlreadyCompleteException, NoSuchJobException {

   
	Job job = (Job) applicationContext.getBean(jobName);

    try { 	

      syncJobLauncher.run(job, getJobParametersFromJobMap(jobParams));

    } catch (Exception exp) {
    	if(LOGGER.isInfoEnabled())
    	LOGGER.info("Exception in " + CLASS_NAME+ " Method : launchJob"+ exp.getMessage());
    }
  }
  
  public void launchQuartzJob(String jobName, Map<String, Object> jobParams)
      throws JobParametersInvalidException,
      JobExecutionAlreadyRunningException, JobRestartException,
      JobInstanceAlreadyCompleteException, NoSuchJobException {

   
      org.quartz.impl.JobDetailImpl job = (org.quartz.impl.JobDetailImpl) applicationContext.getBean(jobName);
      Job batchJob = (Job) applicationContext.getBean((String)job.getJobDataMap().get("jobName"));

    try {   

       syncJobLauncher.run(batchJob, getJobParametersFromJobMap(jobParams));

    } catch (Exception exp) {
    	if(LOGGER.isInfoEnabled())
        LOGGER.info("Exception in " + CLASS_NAME+ " Method : launchQuartzJob"+ exp.getMessage());
    }
  }
  
  private JobParameters getJobParametersFromJobMap(Map<String, Object> jobDataMap) {

		JobParametersBuilder builder = new JobParametersBuilder();

		for (Entry<String, Object> entry : jobDataMap.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			if (value instanceof String) {
				builder.addString(key, (String) value);
			} else if (value instanceof Float || value instanceof Double) {
				builder.addDouble(key, ((Number) value).doubleValue());
			} else if (value instanceof Integer || value instanceof Long) {
				builder.addLong(key, ((Number) value).longValue());
			} else if (value instanceof Date) {
				builder.addDate(key, (Date) value);
			} else {
				// JobDataMap contains values which are not job parameters
				// (ignoring)
			}
		}

		//need unique job parameter to rerun the same job
		builder.addDate(Constant.JOB_RUN_DATE, new Date());
		
		return builder.toJobParameters();

	}
@Override
  public void setApplicationContext(ApplicationContext applicationContext)
      throws BeansException {
    this.applicationContext = applicationContext;
  }
  
 
}
