package com.ey.advisory.asp.batch.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblEmailStatusDetails;
import com.ey.advisory.asp.client.dto.GstrReconMailDetailDto;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;
import com.ey.advisory.asp.master.domain.User;
import com.ey.advisory.asp.master.repository.UserRepository;

@Component
public class EmailGstrAndReconProcessor implements ItemProcessor<TblEmailStatusDetails, GstrReconMailDetailDto> {

	@Autowired
	ClientSpCallService clientSpCallService;
	@Autowired
	Gstr1Service gstr1Service;
	@Autowired
	UserRepository userRepository;

	protected static final Logger lOGGER = Logger.getLogger(EmailGstrAndReconProcessor.class);

	@Value("${job.userDetailsForGSTIN.storedProcName}")
	private String userDetailStoredProcName;
	@Value("${job.GetGstinEntityForGSTIN.storedProcName}")
	private String entityStoredProcName;
	@Value("${job.userDetailsForGSTIN.spSchemaName}")
	private String storedProcSchema;
	@Value("${job.userDetailsForGSTIN.inputParamsCount}")
	private String inputParamsCount;
	public Map<String, String> legalNameMap;
	public Map<String, List<User>> userMailMap;
	public List<String> gstinList;

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		lOGGER.info("Inside EmailGstrAndReconProcessor:beforeStep()");
		userMailMap = new HashMap<String, List<User>>();
		gstinList = new ArrayList<String>();
		lOGGER.info("Exit EmailGstrAndReconProcessor:beforeStep()");
	}

	/*
	 * public String getClientLegalName(String gstin) throws Exception{ String
	 * clientLegalName; if(legalNameMap.containsKey(gstin)){
	 * clientLegalName=legalNameMap.get(gstin); }else{
	 * clientLegalName=clientSpCallService.executeStoredProcedure(
	 * storedProcSchema, entityStoredProcName, inputParamsCount, gstinList);
	 * legalNameMap.put(gstin, clientLegalName); } return clientLegalName; }
	 */

	@SuppressWarnings("unchecked")
	public List<User> getEmailListForGstin(String gstin) throws Exception {
		lOGGER.info("Inside EmailGstrAndReconProcessor:getEmailListForGstin()");
		List<Long> userList = new ArrayList<>();
		List<User> usersList = null;
		if (userMailMap.containsKey(gstin)) {
			usersList = userMailMap.get(gstin);
		} else {
			lOGGER.info("Executing stored proc " + userDetailStoredProcName);
			List<Object> userIdList = (List<Object>) clientSpCallService.executeStoredProcedureReturnList(
					storedProcSchema, userDetailStoredProcName, inputParamsCount, gstinList);
			for (Object id : userIdList) {
				userList.add(Long.parseLong(String.valueOf(id)));
			}
			if (!userList.isEmpty()) {
				usersList = userRepository.findByUserIdInAndEmailIdNotNull(userList);
				userMailMap.put(gstin, usersList);
			}
		}
		lOGGER.info("Exit EmailGstrAndReconProcessor:getEmailListForGstin()");
		return usersList;

	}

	@Override
	public GstrReconMailDetailDto process(TblEmailStatusDetails gstinDetails) throws Exception {
		lOGGER.info("Inside EmailGstrAndReconProcessor:process()");
		lOGGER.info("Processing the mail details");
		GstrReconMailDetailDto mailDetailDto = new GstrReconMailDetailDto();
		List<String> mailList = null;
		List<String> mobileNumbersList = null;
		int invoiceCount = 0;
		String clientLegalName = "";
		String gstin = gstinDetails.getGstin();
		String returnType = gstinDetails.getReturnType();
		gstinList.add(gstin);
		List<User> userListForGstin = getEmailListForGstin(gstin);
		if (!returnType.equals(Constant.GSTR2A) && gstin != null && !gstin.isEmpty()) {
			clientLegalName = gstin.substring(2, 12);
			invoiceCount = gstr1Service.getAffectedInvoiceCountForGstin(gstin, returnType);
		}
		if (userListForGstin != null && userListForGstin.size() > 0) {
			mailList = new ArrayList<String>();
			mobileNumbersList = new ArrayList<String>();
			for (User user : userListForGstin) {
				mailList.add(user.getEmailId());
				mobileNumbersList.add(user.getMobileNo());
			}
		}
		mailDetailDto.setClientLegalName(clientLegalName);
		mailDetailDto.setMailList(mailList);
		mailDetailDto.setMobileNumbersList(mobileNumbersList);
		mailDetailDto.setReturnType(returnType);
		mailDetailDto.setGstin(gstin);
		mailDetailDto.setInvoiceCount(invoiceCount);
		gstinList.clear();
		lOGGER.info("Exit EmailGstrAndReconProcessor:process()");

		return mailDetailDto;

	}

	public String getUserDetailStoredProcName() {
		return userDetailStoredProcName;
	}

	public void setUserDetailStoredProcName(String userDetailStoredProcName) {
		this.userDetailStoredProcName = userDetailStoredProcName;
	}

	public String getEntityStoredProcName() {
		return entityStoredProcName;
	}

	public void setEntityStoredProcName(String entityStoredProcName) {
		this.entityStoredProcName = entityStoredProcName;
	}

	public String getStoredProcSchema() {
		return storedProcSchema;
	}

	public void setStoredProcSchema(String storedProcSchema) {
		this.storedProcSchema = storedProcSchema;
	}

	public String getInputParamsCount() {
		return inputParamsCount;
	}

	public void setInputParamsCount(String inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}

}
