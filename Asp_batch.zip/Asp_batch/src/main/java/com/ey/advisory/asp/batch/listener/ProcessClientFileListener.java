package com.ey.advisory.asp.batch.listener;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;

@Component
public class ProcessClientFileListener implements JobExecutionListener {
	
	private static final String CLIENT_OUTWARD_JOB= "processOutwardClientRawFileJob";
	
	private static final String CLIENT_INWARD_JOB= "processInwardClientRawFileJob";
	
	protected static final Logger LOGGER = Logger.getLogger(ProcessClientFileListener.class);
	
	@Autowired
	TenantDynamicJobDetailsService tenantDynamicJobDetailsService;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		LOGGER.info("in beforeJob of ProcessClientFileListener ");
	}

	@Override
	public void afterJob(JobExecution jobExecution) {		
		JobParameters jobParameters = jobExecution.getJobParameters();
		String inputParams = jobParameters.getString("paramsList");
		if (inputParams != null && !inputParams.isEmpty()) {
				LOGGER.info("Executing ProcessClientFileListener and updating status to CTD :  ");
				String inputParam[] = inputParams.split(",");
				String groupCode = inputParam[0];
				String type = inputParam[2];
				String jobName=Constant.GSTR1OS.equals(type)?CLIENT_OUTWARD_JOB:CLIENT_INWARD_JOB;
				tenantDynamicJobDetailsService.updateJobDetail(jobName, groupCode, type);
				LOGGER.info("ProcessClientFileListener : Updated job status completed for "+jobName );
			}
		}	
	}

