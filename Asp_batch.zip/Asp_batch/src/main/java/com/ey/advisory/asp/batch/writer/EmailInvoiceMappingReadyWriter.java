package com.ey.advisory.asp.batch.writer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblEmailStatusDetails;
import com.ey.advisory.asp.client.dto.InvoiceMappingReadyMailDto;
import com.ey.advisory.asp.notification.constants.NotificationConstants;
import com.ey.advisory.asp.notification.dto.EmailDto;
import com.ey.advisory.asp.notification.service.EmailService;

@Component
@PropertySources({  @PropertySource("classpath:batch.properties"),
@PropertySource("classpath:RestConfig.properties") })
public class EmailInvoiceMappingReadyWriter implements ItemWriter<InvoiceMappingReadyMailDto>{
	
	@Autowired
	EmailService mailService;
	
	@Value("${job.gstr6Inv.templateName}")
	private String invMappingReadyTemplate;

	@Value("${job.gstr6Determination.templateName}")
	private String DetSheetTemplate;
	
	List<TblEmailStatusDetails> notifiedGstnList=new ArrayList<TblEmailStatusDetails>();
	protected static final Logger lOGGER = Logger.getLogger(EmailInvoiceMappingReadyWriter.class);
	
	@Override
    public void write(List<? extends InvoiceMappingReadyMailDto> items) throws Exception {
		for (InvoiceMappingReadyMailDto gstinDetails : items) {
			String mailStatus="";
		TblEmailStatusDetails details=new TblEmailStatusDetails();
		Map<String,Object> templateDetailsMap=new HashMap<String,Object>();
		String returnType=gstinDetails.getReturnType();
		String gstin=gstinDetails.getGstin();
		List<String> mailList=gstinDetails.getMailList();
		templateDetailsMap.put("gstin", gstin);
		String template=returnType.equals(Constant.GSTR6INV_MAPPING_READY)?invMappingReadyTemplate:DetSheetTemplate;
		String subject=returnType.equals(Constant.GSTR6INV_MAPPING_READY)?Constant.INV_MAPPING_READY_EMAIL_SUBJECT:Constant.DET_SHEET_READY_EMAIL_SUBJECT;
		lOGGER.info("Before Condition check gstin and mailList"+gstin+"-->"+mailList);
		if(mailList!=null && mailList.size()>0){
			lOGGER.info("Started sending mail for the Users "+mailList);
			EmailDto mail=new EmailDto();
	        mail.setTemplatePlaceHolders(templateDetailsMap);
	        mail.setSendEmail(true);
	        mail.setHtmlContent(true);
	        mail.setTemplateName(template);
	        mail.setSubject(subject);
	        mail.setTo(new ArrayList<String>());
	        mail.setCc(new ArrayList<String>());
	        mail.setBcc(mailList);
	        try{
	        mailStatus=mailService.sendEmail(mail);
	        lOGGER.info("Sent Mail with Status "+mailStatus);
	        if(NotificationConstants.EMAIL_SUCCESS_MESSAGE.equals(mailStatus)){
	        	details.setGstin(gstin);
	        	details.setReturnType(returnType);
	        	notifiedGstnList.add(details);
	        }
	        }catch(Exception ex){
	        	lOGGER.error("Error while sending Eamil"+ex);
	        }
	        }
		}}
	
	@AfterStep
    public void afterStep(StepExecution stepExecution) throws IOException {
    	ExecutionContext executionContext=stepExecution.getJobExecution().getExecutionContext();
    	lOGGER.info("Executing After Mail Job  with notified List"+notifiedGstnList);
    	executionContext.put("notifiedGstinList", notifiedGstnList);
       
    }
    	
	}
 

