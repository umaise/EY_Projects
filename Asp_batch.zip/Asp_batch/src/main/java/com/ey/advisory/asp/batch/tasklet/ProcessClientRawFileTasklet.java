package com.ey.advisory.asp.batch.tasklet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.etl.service.ETLSpService;

public class ProcessClientRawFileTasklet implements Tasklet{
	
	@Autowired
	ClientSpCallService clientSpCallService;
	
	@Autowired
	ETLSpService etlSpCallService;
	
	private List<String> inputParams;
	private int inputParamsCount;
	
	private String ClientStoredProcName;
	private String ClientstoredProcSchema;
	
	private String ETLStoredProcName;
	private String ETLstoredProcSchema;
	private boolean completionFlag=false;
	
	private static final Logger LOGGER = Logger.getLogger(ProcessClientRawFileTasklet.class);
	
	public List<String> getInputParams() {
		return inputParams;
	}
	public void setInputParams(List<String> inputParams) {
		this.inputParams = inputParams;
	}
	public String getClientStoredProcName() {
		return ClientStoredProcName;
	}
	public void setClientStoredProcName(String clientStoredProcName) {
		ClientStoredProcName = clientStoredProcName;
	}
	public String getClientstoredProcSchema() {
		return ClientstoredProcSchema;
	}
	public void setClientstoredProcSchema(String clientstoredProcSchema) {
		ClientstoredProcSchema = clientstoredProcSchema;
	}
	public String getETLStoredProcName() {
		return ETLStoredProcName;
	}
	public void setETLStoredProcName(String eTLStoredProcName) {
		ETLStoredProcName = eTLStoredProcName;
	}
	public String getETLstoredProcSchema() {
		return ETLstoredProcSchema;
	}
	public void setETLstoredProcSchema(String eTLstoredProcSchema) {
		ETLstoredProcSchema = eTLstoredProcSchema;
	}
	
	public int getInputParamsCount() {
		return inputParamsCount;
	}
	public void setInputParamsCount(int inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}
	
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		try{
			LOGGER.info("Started  Client and ETL File Processing ");
		if (inputParams != null  && !inputParams.isEmpty() && ClientstoredProcSchema!=null && ClientStoredProcName!=null && ETLstoredProcSchema!=null && ETLStoredProcName!=null) {
			LOGGER.info("Started  Client and ETL File Processing , File Id is "+inputParams.get(0));
			String outputParam=clientSpCallService.executeStoredProcedure(ClientstoredProcSchema, ClientStoredProcName,
					String.valueOf(inputParamsCount), inputParams);
			LOGGER.info("Triggered Client Stored Proc and the JobName returned for the File "+inputParams.get(0)+ "is "+outputParam);
					if(outputParam !=null && !outputParam.equals(Constant.FAILED) && !("").equals(outputParam.trim())){
						List<String> jobNameList=new ArrayList<String>();
						jobNameList.add(outputParam);
						LOGGER.info("Triggering ETL Stored Proc with the JobName "+outputParam);
						etlSpCallService.executeStoredProcedure(ETLstoredProcSchema,ETLStoredProcName,inputParamsCount,jobNameList);
						LOGGER.info("Triggered ETL Stored Proc with the JobName "+outputParam);
						completionFlag=true;
					}else{
						LOGGER.info("JobName undefined from client SP");
					}
		}
		LOGGER.info("Finished Processing with status ");
		}catch(Exception e){
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().putString("Exception", e.toString());
			contribution.setExitStatus(ExitStatus.FAILED);
			LOGGER.error("Exception while processing the File , Exception is "+e);
		}
		LOGGER.info("Completed Processing Client and ETL ");
		return RepeatStatus.FINISHED;
	}
	
	@AfterStep
    public ExitStatus afterStep(StepExecution stepExecution) throws IOException {
		if(completionFlag){
			return new ExitStatus("COMPLETED","Completed Successfully for FIle ID"+inputParams.get(0));
			}else{
				return new ExitStatus("FAILED","File is Not Processed , List is "+inputParams);
			}
		
    }
	

}
