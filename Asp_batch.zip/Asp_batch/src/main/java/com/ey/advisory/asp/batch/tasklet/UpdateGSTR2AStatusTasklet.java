package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import com.ey.advisory.asp.client.service.TblGstinRetutnFilingStatusService;

public class UpdateGSTR2AStatusTasklet implements Tasklet{
	protected static final Logger LOGGER = Logger.getLogger(UpdateGSTR2AStatusTasklet.class);
	
	@Autowired
	TblGstinRetutnFilingStatusService tblGstinRetutnFilingStatusService;
	private Map<String, String> inputParamMap;
	public Map<String, String> getInputParamMap() {
		return inputParamMap;
	}
	public void setInputParamMap(Map<String, String> inputParamMap) {
		this.inputParamMap = inputParamMap;
	}
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		LOGGER.info("Inside execute method of UpdateGSTR2AStatusTasklet() ");
		
		ExecutionContext executionContext=chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();

		if(inputParamMap !=null && inputParamMap.size()>0 ){
			for (Map.Entry<String,String> entry : inputParamMap.entrySet()) {
				String key[] = entry.getKey().split("~");

				List<String> inputParams=new ArrayList<>();
				inputParams.add(key[0]);
				inputParams.add(key[1]);
				inputParams.add(entry.getValue());
				String reconStatus=tblGstinRetutnFilingStatusService.insertGstr2AFilingStatus(inputParams);
				executionContext.put("reconStatus", reconStatus); //TODO : Change
			}
		}
		
	LOGGER.info("Exiting from execute method of UpdateGSTR2AStatusTasklet() ");
		return RepeatStatus.FINISHED;
	}

}
