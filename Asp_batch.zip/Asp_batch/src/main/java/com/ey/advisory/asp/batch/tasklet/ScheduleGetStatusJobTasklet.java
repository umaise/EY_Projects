package com.ey.advisory.asp.batch.tasklet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.CustomerJobFrequencyDetailsRepository;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;
import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;

public class ScheduleGetStatusJobTasklet implements Tasklet{
	
	private static final Logger lOGGER = Logger.getLogger(ScheduleGetStatusJobTasklet.class);
	private static final String CLASS_NAME = ScheduleGetStatusJobTasklet.class.getName();
	private String jobName ;
	private int repeatCount ;
	private int repeatInterval ;
	public String code;
	
	@Autowired
	private TenantDynamicJobDetailsRepository tenantDynamicJobDetailsRepository;
	
	@Autowired
	private TenantDynamicJobDetailsService tenantDynamicJobDetailsService;
	
	@Autowired
	private CustomerJobFrequencyDetailsRepository customerJobFrequencyDetails;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
		
		String jobNameGroupCode = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters().getString("JOB_NAME");		
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("day", String.valueOf(LocalDate.now().getDayOfMonth())) ;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream out = null;
		byte[] jobParam = null;
		try {
			out = new ObjectOutputStream(bos);
			out.writeObject(paramMap);
			jobParam = bos.toByteArray();
		} catch (Exception ex) {
			lOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
		} finally {
			try {
				bos.close();
			} catch (IOException ex) {
				throw new IllegalStateException("Not able to write Job Param");
			}
		}
		
		if(code==null || code.isEmpty()){
			code = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters()
					.getString(TenantConstant.BATCH_TENANT_CONTEXT);
			} 
			
			if(null != code){
			TenantDynamicJobDetail tenantDynamicJobDetail = new TenantDynamicJobDetail();
			tenantDynamicJobDetail.setGroupCode(code.toLowerCase());
			tenantDynamicJobDetail.setJobName(jobName);
			tenantDynamicJobDetail.setPriority(10);
			tenantDynamicJobDetail.setRepeatCount(repeatCount);  
			tenantDynamicJobDetail.setRepeatInterval(repeatInterval); 
			tenantDynamicJobDetail.setJobParam(jobParam);
			tenantDynamicJobDetail.setStatus(Constant.NEW);
			if(tenantDynamicJobDetailsService.findByJobNameAndGroupCodeAndStatus(jobName, code.toLowerCase(), Arrays.asList(Constant.NEW))){
			tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
			return RepeatStatus.FINISHED;}
			}else{
				lOGGER.error("group code is empty");
			}
			
			return RepeatStatus.FINISHED;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public int getRepeatCount() {
		return repeatCount;
	}

	public void setRepeatCount(int repeatCount) {
		this.repeatCount = repeatCount;
	}

	public int getRepeatInterval() {
		return repeatInterval;
	}

	public void setRepeatInterval(int repeatInterval) {
		this.repeatInterval = repeatInterval;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	
}
