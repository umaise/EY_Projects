package com.ey.advisory.asp.batch.util;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.util.RestClientUtility;

/**
 * @author Smruti.Pradhan
 *
 *         make Node Js api call
 */
@Component
@PropertySource("classpath:batch.properties")
public class BatchClientUtility {

	private static final Logger LOGGER = Logger.getLogger(BatchClientUtility.class);

	@Autowired
	RestTemplate restTemplatewithoutProxy;

	@Autowired
	private Environment env;

	// POST
	public String executeRestCall(String uri, HttpHeaders httpHeaders, String inputData, HttpMethod httpMethod) throws Exception {
		HttpEntity<String> entity = new HttpEntity<>(inputData, httpHeaders);
		try {
			ResponseEntity<String> response = restTemplatewithoutProxy.exchange(uri, httpMethod, entity, String.class);
			LOGGER.info("response from node js==>"+response);
			return response.getBody();
		} catch (HttpServerErrorException hsee) {
			LOGGER.error("Inside Batch Client Util: HttpServerErrorException");
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, hsee.getMessage());
		} catch (HttpClientErrorException hcee) {
			LOGGER.error("Inside Batch Client Util: HttpClientErrorException");
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, hcee.getMessage());
		} catch (HttpStatusCodeException hsce) {
			LOGGER.error("Inside Batch Client Util: HttpStatusCodeException");					throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, hsce.getMessage());
		} catch (RestClientException rce) {
			LOGGER.error("Inside Batch Client Util: RestClientException");
			throw new RestClientException(rce.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Inside Batch Client Util: Exception");
			throw new Exception(e.getMessage());
		}
	}

	public String executeRestCall(String uri, HttpHeaders httpHeaders, HttpMethod httpMethod) {
		String result = "";
		//HttpEntity<Object> entity = new HttpEntity<>(getCustomHeadersGSP(httpHeaders));
		HttpEntity<Object> entity = new HttpEntity<>(httpHeaders);
		try {
			ResponseEntity<String> response = restTemplatewithoutProxy.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpClientErrorException hcee) {
			LOGGER.error("Inside Batch Client Util: HttpClientErrorException");
				return hcee.getMessage();
		} catch (HttpStatusCodeException hsce) {
			LOGGER.error("Inside Batch Client Util: HttpStatusCodeException");
				return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error("Inside Batch Client Util: RestClientException");
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error("Inside Batch Client Util: Exception");
			return e.getMessage();
		}

		return result;
	}

	private HttpHeaders getCustomHeaders(HttpHeaders httpHeaders) {

		httpHeaders.add(Constant.IP_USR, env.getProperty("ip.usr"));
		httpHeaders.add(Constant.GSP_USER, env.getProperty("gsp-user"));
		httpHeaders.add(Constant.GSP_CLIENT_ID, env.getProperty("gsp-clientid"));
		httpHeaders.add(Constant.GSP_CLIENT_SECRET, env.getProperty("gsp-client-secret"));
		httpHeaders.add(Constant.PARAM_OAUTH, env.getProperty("auth.token"));
		httpHeaders.add(Constant.STATECD, env.getProperty("state.cd"));
		httpHeaders.add(Constant.USERNAME, env.getProperty("rest.username"));
		httpHeaders.add(Constant.TXN, env.getProperty("rest.txn"));
		return httpHeaders;
	}
	
	public HttpHeaders setCustomHeadersGSP(HttpHeaders httpHeaders, String groupCode, String gstinData, String ret_prd) throws UnknownHostException {

		Map<Object, Object> gspHeaderDetails = RestClientUtility.getRedisDataForGSP(groupCode);
		AuthDetailsDto dto = RestClientUtility.getRedisData(gstinData);
		InetAddress IP = InetAddress.getLocalHost();
		
		if(null != gspHeaderDetails && gspHeaderDetails.size() >0){
			httpHeaders.add("digigst_username", gspHeaderDetails.get(Constant.GSP_DIGIGST_USERNAME).toString());
			httpHeaders.add("access_token", gspHeaderDetails.get(Constant.ACCESS_TOKEN).toString());
			httpHeaders.add("api_key", gspHeaderDetails.get(Constant.API_KEY).toString());
			httpHeaders.add("api_secret", gspHeaderDetails.get(Constant.API_SECRET).toString());
		}
		httpHeaders.add(Constant.IP_USR, env.getProperty("ip.usr"));
		httpHeaders.add(Constant.PARAM_OAUTH, dto.getAuthToken());
		httpHeaders.add(Constant.STATECD, dto.getStateCode());
		httpHeaders.add(Constant.USERNAME, dto.getUserName());
		httpHeaders.add(Constant.TXN, env.getProperty("rest.txn"));
		httpHeaders.add(Constant.GSTIN_HDR, gstinData);
		httpHeaders.add(Constant.RET_PRD, ret_prd);
		
		return httpHeaders;
	}
	
	public void executeRestCallWithoutResponse(String uri, HttpHeaders httpHeaders, String inputData, HttpMethod httpMethod) throws Exception {
		HttpEntity<String> entity = new HttpEntity<>(inputData, httpHeaders);
		try {
			restTemplatewithoutProxy.exchange(uri, httpMethod, entity, String.class);
		} catch (HttpServerErrorException hsee) {
			LOGGER.error("Inside Batch Client Util: HttpServerErrorException");
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, hsee.getMessage());
		} catch (HttpClientErrorException hcee) {
			LOGGER.error("Inside Batch Client Util: HttpClientErrorException");
			throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, hcee.getMessage());
		} catch (HttpStatusCodeException hsce) {
			LOGGER.error("Inside Batch Client Util: HttpStatusCodeException");					throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, hsce.getMessage());
		} catch (RestClientException rce) {
			LOGGER.error("Inside Batch Client Util: RestClientException");
			throw new RestClientException(rce.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Inside Batch Client Util: Exception");
			throw new Exception(e.getMessage());
		}
	}

}
