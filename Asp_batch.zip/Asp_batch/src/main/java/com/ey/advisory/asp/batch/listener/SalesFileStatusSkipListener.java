package com.ey.advisory.asp.batch.listener;

import org.apache.log4j.Logger;
import org.springframework.batch.core.SkipListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;
import com.ey.advisory.asp.master.repository.FileUploadStatusRepository;

public class SalesFileStatusSkipListener implements SkipListener<FileUploadStatusMaster, FileUploadStatusMaster> {
	
	protected static final Logger LOGGER = Logger.getLogger(SalesFileStatusSkipListener.class);

	private String isProcessed;
	private String jobStatus;

	@Autowired
	FileUploadStatusRepository tblSalesFileStatusRepo;

	@Override
	public void onSkipInWrite(FileUploadStatusMaster fileInfo, Throwable t) {
		LOGGER.info("in onSkipInWrite of SalesFileStatusSkipListener ");
		tblSalesFileStatusRepo.updateIsProcessedJobStatus(isProcessed, jobStatus, fileInfo.getFileId());
	}

	@Override
	public void onSkipInProcess(FileUploadStatusMaster item, Throwable t) {
		//As of now we are not performing any skip operation/logic in process step
	}

	@Override
	public void onSkipInRead(Throwable t) {
		//As of now we are not performing any skip operation/logic in read step
	}

	public String getIsProcessed() {
		return isProcessed;
	}

	public void setIsProcessed(String isProcessed) {
		this.isProcessed = isProcessed;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
}
