package com.ey.advisory.asp.batch.writer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.CustomerJobFrequencyDetailsRepository;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;

public class ScheduleCustomerSpecificJob implements ItemWriter<String> {

	private String jobName;

	@Autowired
	private TenantDynamicJobDetailsRepository tenantDynamicJobDetailsRepository;
	@Autowired
	private CustomerJobFrequencyDetailsRepository customerJobFrequencyDetails;
	
	private static final Logger lOGGER = Logger.getLogger(ScheduleCustomerSpecificJob.class);
	private static final String CLASS_NAME = ScheduleCustomerSpecificJob.class.getName();

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends String> groupCodes) throws Exception {

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("day", String.valueOf(LocalDate.now().getDayOfMonth())) ;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream out = null;
		byte[] jobParam = null;
		try {
			out = new ObjectOutputStream(bos);
			out.writeObject(paramMap);
			jobParam = bos.toByteArray();
		} catch (Exception ex) {
			lOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
		} finally {
			try {
				out.close();
				bos.close();
			} catch (IOException ex) {
				throw new IllegalStateException("Not able to write Job Param");
			}
		}
		for (String groupCode : groupCodes) {
			TenantDynamicJobDetail tenantDynamicJobDetail = new TenantDynamicJobDetail();
			tenantDynamicJobDetail.setGroupCode(groupCode);
			tenantDynamicJobDetail.setJobName(jobName);
			tenantDynamicJobDetail.setPriority(9);
			tenantDynamicJobDetail.setRepeatCount(0);
			tenantDynamicJobDetail.setRepeatInterval(1);
			tenantDynamicJobDetail.setJobParam(jobParam);
			tenantDynamicJobDetail.setStatus(Constant.NEW);
			tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
		}

		customerJobFrequencyDetails.updateScheduledFlagForCustomerGroupCode((List<String>) groupCodes);

	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

}
