package com.ey.advisory.asp.batch.reader;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import com.ey.advisory.asp.client.dto.TransactionIDPolling;
import com.ey.advisory.asp.client.service.GSTINDetailsService;

public class TransactionIDPollingReader implements ItemReader<TransactionIDPolling> {

	private static final Logger LOGGER = Logger.getLogger(TransactionIDPollingReader.class);

	@Autowired
	GSTINDetailsService gstinDetailsService;

	List<TransactionIDPolling> transactionIDPollingList;
	 
	private int rowCount = 0;
	private String jobName;
	@BeforeStep
	public void getInterstepData(StepExecution stepExecution)
	{
		try{
		LOGGER.info("Started TransactionIDPollingReader");
		String jobName = null;
		JobExecution jobExecution = stepExecution.getJobExecution();	
		LOGGER.info("Job Name" + jobExecution.getJobInstance().getJobName());	
		jobName = jobExecution.getJobInstance().getJobName();	
		if (com.ey.advisory.asp.batch.util.Constant.SUMMARY_TRNX_ID_POLLING_JOB.equalsIgnoreCase(jobName))
		{
			transactionIDPollingList = gstinDetailsService.getTransactionIDPollingList(true);		
		}
		else 
		{		
			transactionIDPollingList = gstinDetailsService.getTransactionIDPollingList(false);	         
	    }
		}catch(Exception e){
			LOGGER.error("Exception in TransactionIDPollingReader getInterstepData"+ e);
		}
		
	}

	@Override
	public TransactionIDPolling read()
			throws UnexpectedInputException, ParseException, NonTransientResourceException,Exception
	{
		TransactionIDPolling transactionIDPolling = null;
		try{
		if(transactionIDPollingList!=null && rowCount < transactionIDPollingList.size())
        {
			LOGGER.info("transactionIDPollingList size = " +transactionIDPollingList.size());
        	transactionIDPolling =  transactionIDPollingList.get(rowCount);      
            ++rowCount;
		}}catch(Exception e){
			LOGGER.error("Exception in TransactionIDPolling read() "+e);	
        }
	
		return transactionIDPolling; 
  } 
	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
}
