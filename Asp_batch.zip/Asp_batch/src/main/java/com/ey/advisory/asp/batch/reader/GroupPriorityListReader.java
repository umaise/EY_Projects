package com.ey.advisory.asp.batch.reader;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;

public class GroupPriorityListReader implements ItemReader<String> {

	protected static final Logger lOGGER = Logger.getLogger(GroupPriorityListReader.class);

	private List<String> jobPriorityList;
	int rowCount;

	@SuppressWarnings("unchecked")
	@BeforeStep
	public void initializeState(StepExecution stepExecution) {
		lOGGER.info("Inside GroupPriorityListReader:initializeState()");
		jobPriorityList = (List<String>) (stepExecution.getJobExecution().getExecutionContext()
				.get("groupPriorityList"));
		rowCount = 0;
		if (lOGGER.isInfoEnabled())
			lOGGER.info("Exit GroupPriorityListReader:initializeState()");
	}

	@Override
	public String read() {
		lOGGER.info("Inside GroupPriorityListReader:read() count " + rowCount);
		String groupCode = null;
		if (jobPriorityList != null && rowCount < jobPriorityList.size()) {
			groupCode = jobPriorityList.get(rowCount);
			lOGGER.info("Group Code "+ groupCode);
			rowCount++;
		}
		lOGGER.info("Exit GroupPriorityListReader:read() count " + rowCount);
		return groupCode;
	}

}
