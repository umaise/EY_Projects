package com.ey.advisory.asp.quartz.listener;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.Trigger;
import org.quartz.Trigger.CompletedExecutionInstruction;
import org.quartz.listeners.TriggerListenerSupport;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.multitenancy.BatchTenantContext;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;

@Component
public class ClientJobTriggerListener extends TriggerListenerSupport {

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "ClientJobTriggerListener";
	}

	@Override
	public void triggerFired(Trigger trigger, JobExecutionContext context) {
		JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
		if (jobDataMap != null && jobDataMap.containsKey(TenantConstant.BATCH_TENANT_CONTEXT))
			BatchTenantContext.setTenantId(jobDataMap.get(TenantConstant.BATCH_TENANT_CONTEXT).toString());
	}

	@Override
	public void triggerComplete(Trigger trigger, JobExecutionContext context,
			CompletedExecutionInstruction triggerInstructionCode) {
		BatchTenantContext.clearTenant();
	}

}
