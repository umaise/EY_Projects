package com.ey.advisory.asp.batch.decider;
import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Component;

@Component
public class SimpleTriggerDecider implements JobExecutionDecider {
	protected static final Logger LOGGER = Logger.getLogger(SimpleTriggerDecider.class);
	
	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution,
			StepExecution stepExecution) {
		ExecutionContext executionContext=stepExecution.getJobExecution().getExecutionContext();
		LOGGER.info("Executing Decision with SimpleTriggerDeciderTasklet :  ");
		if(executionContext.containsKey("TrnxIDCount") && executionContext.get("TrnxIDCount") !=null && !executionContext.get("TrnxIDCount").toString().equalsIgnoreCase("0")){
			LOGGER.info("Returned ADD_SIMPLE_TRIGGER");
			return new FlowExecutionStatus("ADD_SIMPLE_TRIGGER");
		}else{
			return new FlowExecutionStatus("EXIT");
		}
	}
}