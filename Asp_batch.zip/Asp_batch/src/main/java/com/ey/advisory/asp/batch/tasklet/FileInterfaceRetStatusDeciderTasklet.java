package com.ey.advisory.asp.batch.tasklet;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.batch.item.ExecutionContext;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblGSTINList;

/**
 * @author Smruti.Pradhan Decider for InterfacetoGSTN Job
 */
public class FileInterfaceRetStatusDeciderTasklet implements JobExecutionDecider {
	protected static final Logger LOGGER = Logger.getLogger(FileInterfaceRetStatusDeciderTasklet.class);

	@SuppressWarnings("unchecked")
	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {

		ExecutionContext executionContext = stepExecution.getJobExecution().getExecutionContext();
		if (LOGGER.isInfoEnabled())
			LOGGER.info("Executing Decision with FileInterfaceRetStatusDeciderTasklet :  ");
		String isRetStatusReq = null;
		if (executionContext.containsKey("isRetStatusReq") && executionContext.get("isRetStatusReq") != null)
			isRetStatusReq = (String) executionContext.get("isRetStatusReq");

		if (isRetStatusReq.equals(Constant.No))
			return FlowExecutionStatus.STOPPED;
		else {
			if (LOGGER.isInfoEnabled())
				LOGGER.info("Executing Decision with FileInterfaceRetStatusDeciderTasklet :");
			return FlowExecutionStatus.COMPLETED;
		}
	
	}

}
