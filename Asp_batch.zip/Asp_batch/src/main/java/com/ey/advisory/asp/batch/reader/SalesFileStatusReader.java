package com.ey.advisory.asp.batch.reader;

import java.util.Calendar;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;
import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.returnfiling.service.ReturnFilingClientService;
import com.ey.advisory.returnfiling.service.ReturnFilingService;

public class SalesFileStatusReader implements ItemReader<FileUploadStatusMaster> {

	protected static final Logger LOGGER = Logger.getLogger(SalesFileStatusReader.class);

	;
	@Autowired
	private ReturnFilingService returnFilingService;
	
	@Autowired
	private ReturnFilingClientService returnFilingClientService;

	private String rowCount;
	private String jobStatus;
	private String isProcessed;
	private int nextSalesFile;
	private String fileData;
	List<FileUploadStatusMaster> processFileList;
	String taxPeriod;

	@BeforeStep
	public void initializeState(StepExecution stepExecution) {
		initialize();
	}

	private void initialize() {
		LOGGER.info("Inside Initialize method");
		Pageable top = new PageRequest(0, Integer.parseInt(rowCount), Direction.ASC, "isStageProcessed", "jobStatus");
		processFileList = returnFilingService.findByIsStageProcessedAndJobStatusAndFileData(isProcessed, jobStatus,
				fileData, top);
		nextSalesFile = 0;

		ReturnPeriod returnPeriod = returnFilingService.findByIsCurrentPeriod(true);
		Calendar cal = Calendar.getInstance();
		cal.setTime(returnPeriod.getStartDt());
		int month = cal.get(Calendar.MONTH) + 1;
		int year = cal.get(Calendar.YEAR);
		String monthTwoDigits = (month) < 10 ? "0" + String.valueOf(month) : String.valueOf(month);
		taxPeriod = monthTwoDigits + String.valueOf(year);

		if (Constant.INWARD.equalsIgnoreCase(fileData)) {
			processFileList = processFileList.stream().filter(item -> returnFilingClientService
					.getReturnFilingDetails(taxPeriod, item.getGstin(), Constant.GSTR2, Constant.FILED) == null)
					.collect(Collectors.toList());
		}
		LOGGER.info("Exit Initialize method");
	}

	@Override
	public FileUploadStatusMaster read() {
		LOGGER.info("Inside read method count " + nextSalesFile);
		FileUploadStatusMaster fileInfo = null;
		if (nextSalesFile < processFileList.size()) {
			fileInfo = processFileList.get(nextSalesFile);
			fileInfo.setTaxPeriod(taxPeriod);
			LOGGER.info("File Info " + fileInfo);
			nextSalesFile++;
		}
		LOGGER.info("Exit read method count " + nextSalesFile);
		return fileInfo;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public void setIsProcessed(String isProcessed) {
		this.isProcessed = isProcessed;
	}

	public void setRowCount(String rowCount) {
		this.rowCount = rowCount;
	}

	public void setFileData(String fileData) {
		this.fileData = fileData;
	}
}
