package com.ey.advisory.asp.batch.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.client.domain.TblEmailStatusDetails;
import com.ey.advisory.asp.client.dto.InvoiceMappingReadyMailDto;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;
import com.ey.advisory.asp.master.domain.User;
import com.ey.advisory.asp.master.repository.UserRepository;

@Component
public class EmailInvoiceMappingReadyProcessor
		implements ItemProcessor<TblEmailStatusDetails, InvoiceMappingReadyMailDto> {

	@Autowired
	ClientSpCallService clientSpCallService;
	@Autowired
	Gstr1Service gstr1Service;
	@Autowired
	UserRepository userRepository;

	protected static final Logger lOGGER = Logger.getLogger(EmailInvoiceMappingReadyProcessor.class);

	@Value("${job.userDetailsForISDGSTIN.storedProcName}")
	private String userDetailStoredProcName;
	@Value("${job.GetGstinEntityForGSTIN.storedProcName}")
	private String entityStoredProcName;
	@Value("${job.userDetailsForGSTIN.spSchemaName}")
	private String storedProcSchema;
	@Value("${job.userDetailsForGSTIN.inputParamsCount}")
	private String inputParamsCount;
	public Map<String, String> legalNameMap;
	public Map<String, List<User>> userMailMap;
	public List<String> gstinList;

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		lOGGER.info("Inside EmailInvoiceMappingReadyProcessor:beforeStep()");
		userMailMap = new HashMap<String, List<User>>();
		gstinList = new ArrayList<String>();
		lOGGER.info("Exit EmailInvoiceMappingReadyProcessor:beforeStep()");
	}

	@SuppressWarnings("unchecked")
	public List<User> getEmailListForGstin(String gstin) throws Exception {
		lOGGER.info("Inside EmailInvoiceMappingReadyProcessor:getEmailListForGstin()");
		List<Long> userList = new ArrayList<>();
		List<User> usersList = null;
		if (userMailMap.containsKey(gstin)) {
			usersList = userMailMap.get(gstin);
		} else {
			lOGGER.info("Executing stored proc " + userDetailStoredProcName);
			List<Object> userIdList = (List<Object>) clientSpCallService.executeStoredProcedureReturnList(
					storedProcSchema, userDetailStoredProcName, inputParamsCount, gstinList);
			for (Object id : userIdList) {
				userList.add(Long.parseLong(String.valueOf(id)));
			}
			if (!userList.isEmpty()) {
				usersList = userRepository.findByUserIdInEmailIdNotNull(userList);
				userMailMap.put(gstin, usersList);
			}
		}
		lOGGER.info("Exit EmailInvoiceMappingReadyProcessor:getEmailListForGstin()");
		return usersList;
	}

	@Override
	public InvoiceMappingReadyMailDto process(TblEmailStatusDetails gstinDetails) throws Exception {
		lOGGER.info("Inside EmailInvoiceMappingReadyProcessor:process()");
		lOGGER.info("Processing the mail details");
		InvoiceMappingReadyMailDto mailDetailDto = new InvoiceMappingReadyMailDto();
		List<String> mailList = null;
		String gstin = gstinDetails.getGstin();
		String returnType = gstinDetails.getReturnType();
		gstinList.add(gstin);
		List<User> userListForGstin = getEmailListForGstin(gstin);
		if (userListForGstin != null && userListForGstin.size() > 0) {
			mailList = new ArrayList<String>();
			for (User user : userListForGstin) {
				mailList.add(user.getEmailId());
			}
		}
		mailDetailDto.setMailList(mailList);
		mailDetailDto.setReturnType(returnType);
		mailDetailDto.setGstin(gstin);
		gstinList.clear();
		lOGGER.info("Exit EmailInvoiceMappingReadyProcessor:process()");
		return mailDetailDto;
	}

	public String getUserDetailStoredProcName() {
		return userDetailStoredProcName;
	}

	public void setUserDetailStoredProcName(String userDetailStoredProcName) {
		this.userDetailStoredProcName = userDetailStoredProcName;
	}

	public String getEntityStoredProcName() {
		return entityStoredProcName;
	}

	public void setEntityStoredProcName(String entityStoredProcName) {
		this.entityStoredProcName = entityStoredProcName;
	}

	public String getStoredProcSchema() {
		return storedProcSchema;
	}

	public void setStoredProcSchema(String storedProcSchema) {
		this.storedProcSchema = storedProcSchema;
	}

	public String getInputParamsCount() {
		return inputParamsCount;
	}

	public void setInputParamsCount(String inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}

}
