package com.ey.advisory.asp.batch.tasklet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;
import com.ey.advisory.asp.master.service.GroupService;

public class CreateSimpleTriggersPerNodeAvailability implements Tasklet {

	@Autowired
	private GroupService groupService;
	
	@Autowired
	private TenantDynamicJobDetailsRepository tenantDynamicJobDetailsRepository;
	
	private String jobName;
	
	private int timeInterval;
	
	@Value("${job.group.simpleTrigger.maxThreadsPerNode}")
	private int maxThreadsPerNode;
	
	@Value("${job.group.simpleTrigger.numberOfNodes}")
	private int noOfNodes;

	protected static final Logger lOGGER = Logger.getLogger(CreateSimpleTriggersPerNodeAvailability.class);
	private static final String CLASS_NAME = CreateSimpleTriggersPerNodeAvailability.class.getName();
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		ExecutionContext executionContext=chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();
		if(executionContext.containsKey("currentTaxPeriod")){
		String currentTaxPeriod=executionContext.getString("currentTaxPeriod");
		lOGGER.info("Inside execute method of CreateReturnPeriodTasklet");
		List<String> activeGroupList=groupService.getAllActiveGroups();
		int activeGroupsSize=activeGroupList.size();
		float maxTriggers=maxThreadsPerNode*noOfNodes;
		int loops=(int) Math.ceil(activeGroupsSize/maxTriggers);
		int repeatInterval=-(timeInterval-1);
		int listIndex=0;
		Map<String,Object> paramMap=new HashMap<String,Object>();
		paramMap.put("taxPeriod", currentTaxPeriod);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream out = null;
		byte[] jobParam = null;
		try {
			out = new ObjectOutputStream(bos);
			out.writeObject(paramMap);
			jobParam = bos.toByteArray();
			for(int i=0;i<loops;i++){
				repeatInterval=repeatInterval+timeInterval;
				for(int j=0;(j<maxTriggers && listIndex<activeGroupsSize);j++){	
				TenantDynamicJobDetail tenantDynamicJobDetail=new TenantDynamicJobDetail();
				tenantDynamicJobDetail.setGroupCode(activeGroupList.get(listIndex));
		      	tenantDynamicJobDetail.setJobName(jobName);
				tenantDynamicJobDetail.setPriority(10);
				tenantDynamicJobDetail.setRepeatCount(0);
				tenantDynamicJobDetail.setRepeatInterval(repeatInterval);
				tenantDynamicJobDetail.setJobParam(jobParam);
				tenantDynamicJobDetail.setStatus(Constant.NEW);
			    tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
			    lOGGER.info("Created Simple Trigger to create Return Filing Details for group "+activeGroupList.get(listIndex));
			    listIndex++;
			}	
			}
		} catch (Exception ex) {
			lOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
		} finally {
			try {
				bos.close();
			} catch (IOException ex) {
				throw new IllegalStateException("Not able to write Job Param");
			}
		}
		
		}
		return RepeatStatus.FINISHED;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public int getTimeInterval() {
		return timeInterval;
	}

	public void setTimeInterval(int timeInterval) {
		this.timeInterval = timeInterval;
	}

	public int getMaxThreadsPerNode() {
		return maxThreadsPerNode;
	}

	public void setMaxThreadsPerNode(int maxThreadsPerNode) {
		this.maxThreadsPerNode = maxThreadsPerNode;
	}

	public int getNoOfNodes() {
		return noOfNodes;
	}

	public void setNoOfNodes(int noOfNodes) {
		this.noOfNodes = noOfNodes;
	}

	
}
