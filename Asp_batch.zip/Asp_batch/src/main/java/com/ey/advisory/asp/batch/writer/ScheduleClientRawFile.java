package com.ey.advisory.asp.batch.writer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;

public class ScheduleClientRawFile implements ItemWriter<String> {

	protected static final Logger lOGGER = Logger.getLogger(ScheduleClientRawFile.class);

	@Autowired
	private TenantDynamicJobDetailsRepository tenantDynamicJobDetailsRepository;

	private String outwardJob;
	private String inwardJob;
	private int repeatCount;
	private int repeatInterval;
	private String id;
	private String code;
	private static final String CLASS_NAME = ScheduleClientRawFile.class.getName();

	@Override
	public void write(List<? extends String> outputParams) throws Exception {

		for (String outputParam : outputParams) {

			String job = null;
			String[] values = outputParam.split(",");
			
			if (values != null && values.length >= 3) {
				
				String returnType = values[2];
				if (Constant.GSTR1OS.equals(returnType)) {
					lOGGER.info("scheduling outward ");
					job = outwardJob;
				} else if (Constant.GSTR2IS.equals(returnType)) {
					lOGGER.info("scheduling Inward ");
					job = inwardJob;
				}

				String groupCode = values[0];
				String fileId = values[1];

				Map<String, Object> paramMap = new HashMap<>();
				paramMap.put(id, fileId);
				paramMap.put(code, groupCode);
				paramMap.put("paramsList", outputParam);

				TenantDynamicJobDetail tenantDynamicJobDetail = new TenantDynamicJobDetail();

				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				ObjectOutputStream out = null;
				byte[] jobParam = null;
				try {
					out = new ObjectOutputStream(bos);
					out.writeObject(paramMap);
					jobParam = bos.toByteArray();
					tenantDynamicJobDetail.setGroupCode((String) values[0]);
					tenantDynamicJobDetail.setJobName(job);
					tenantDynamicJobDetail.setPriority(10);
					tenantDynamicJobDetail.setRepeatCount(repeatCount);
					tenantDynamicJobDetail.setRepeatInterval(repeatInterval);
					tenantDynamicJobDetail.setJobParam(jobParam);
					tenantDynamicJobDetail.setStatus(Constant.NEW);
					tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
					if (lOGGER.isInfoEnabled())
						lOGGER.info("Job has been scheduled " + job);
				} catch (Exception ex) {
					lOGGER.error("Exception in " + CLASS_NAME + " Exception is " + ex);
				} finally {
					try {
						out.close();
						bos.close();
					} catch (IOException ex) {
						throw new IllegalStateException("Not able to write Job Param");
					}
				}
			}
		}

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getOutwardJob() {
		return outwardJob;
	}

	public void setOutwardJob(String outwardJob) {
		this.outwardJob = outwardJob;
	}

	public String getInwardJob() {
		return inwardJob;
	}

	public void setInwardJob(String inwardJob) {
		this.inwardJob = inwardJob;
	}

	public int getRepeatCount() {
		return repeatCount;
	}

	public void setRepeatCount(int repeatCount) {
		this.repeatCount = repeatCount;
	}

	public int getRepeatInterval() {
		return repeatInterval;
	}

	public void setRepeatInterval(int repeatInterval) {
		this.repeatInterval = repeatInterval;
	}

}
