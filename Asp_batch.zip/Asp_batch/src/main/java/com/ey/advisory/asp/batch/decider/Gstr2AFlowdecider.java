package com.ey.advisory.asp.batch.decider;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Component;

@Component
public class Gstr2AFlowdecider  implements JobExecutionDecider {
	protected static final Logger LOGGER = Logger.getLogger(Gstr2AFlowdecider.class);
	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {
		
		LOGGER.info("Inside Gstr2AFlowdecider");
		ExecutionContext executionContext=jobExecution.getExecutionContext();
		
		// TODO Auto-generated method stub
		if (executionContext.containsKey("gstin") && executionContext.get("gstin")!=null  && !executionContext.getString("gstin").isEmpty() 
				&& executionContext.containsKey("ret_period") && executionContext.get("ret_period")!=null && !executionContext.getString("ret_period").isEmpty() ) {
			LOGGER.info("Returning WITH_JOB_PARAMS from Gstr2AFlowdecider");
			return new FlowExecutionStatus("WITH_JOB_PARAMS");
		} else
			LOGGER.info("Returning WITHOUT_JOB_PARAMS from Gstr2AFlowdecider");
			return new FlowExecutionStatus("WITHOUT_JOB_PARAMS");
    		
	}

}
