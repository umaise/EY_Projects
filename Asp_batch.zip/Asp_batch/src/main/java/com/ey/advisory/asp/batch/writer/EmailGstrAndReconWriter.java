package com.ey.advisory.asp.batch.writer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblEmailStatusDetails;
import com.ey.advisory.asp.client.dto.GstrReconMailDetailDto;
import com.ey.advisory.asp.notification.constants.NotificationConstants;
import com.ey.advisory.asp.notification.dto.EmailDto;
import com.ey.advisory.asp.notification.service.EmailService;
import com.ey.advisory.asp.notification.service.SmsService;
@Component
@PropertySources({  @PropertySource("classpath:batch.properties"),
	@PropertySource("classpath:RestConfig.properties") })
public class EmailGstrAndReconWriter implements ItemWriter<GstrReconMailDetailDto>{
	
	@Autowired
	EmailService mailService;
	@Autowired
	SmsService smsService;
	@Autowired
	private Environment env;
	
	@Autowired
	BatchClientUtility batchClientUtility;
	
	@Value("${job.recon.templateName}")
	private String reconTemplate;
	@Value("${job.gstr.templateName}")
	private String gstrTemplate;
	@Value("${job.gstr6.templateName}")
	private String gstr6Template;
	
	public List<TblEmailStatusDetails> notifiedGstnList=new ArrayList<TblEmailStatusDetails>();
	protected static final Logger lOGGER = Logger.getLogger(EmailGstrAndReconWriter.class);
	
	@SuppressWarnings("unchecked")
	@Override
    public void write(List<? extends GstrReconMailDetailDto> items) throws Exception {
		for (GstrReconMailDetailDto gstinDetails : items) {
			String mailStatus="";
			String smsStatus="";
		TblEmailStatusDetails details=new TblEmailStatusDetails();
		Map<String,Object> templateDetailsMap=new HashMap<String,Object>();
		String clientLegalName="";
		int invoiceCount=0;
		String returnType=gstinDetails.getReturnType();
		String gstin=gstinDetails.getGstin();
		List<String> mailList=gstinDetails.getMailList();
		List<String> mobileNumbersList=gstinDetails.getMobileNumbersList();
		if(!returnType.equals(Constant.GSTR2A)){
		clientLegalName=gstinDetails.getClientLegalName();
		invoiceCount=gstinDetails.getInvoiceCount();
		templateDetailsMap.put("clientLegalName", clientLegalName);
		}else{
			invoiceCount=1;
		}
		lOGGER.info("Before Condition check gstin and mailList"+gstin+"-->"+mailList+" clientLegalName is "+clientLegalName+" invoiceCount is "+invoiceCount);
		if(mailList!=null && mailList.size()>0 && mobileNumbersList!=null && mobileNumbersList.size()>0  && invoiceCount>0){
			lOGGER.info("Started sending mail and Sms for the Users "+mailList+"sms list "+mobileNumbersList);
			EmailDto mail=new EmailDto();
			String template=null;
			String subject=null;
			if(returnType.equals(Constant.GSTR2A)){
				template=reconTemplate;
			}
			else if(returnType.equals(Constant.GSTR6)){
				template=gstr6Template;
			}
			else if(returnType.equals(Constant.GSTR1) || returnType.equals(Constant.GSTR2)){
				template=gstrTemplate;
			}
			if(returnType.equals(Constant.GSTR2A)){
				subject=Constant.RECON_EMAIL_SUBJECT;
			}
			else {
				subject=Constant.EMAIL_SUBJECT.replace("processType", returnType);
			}
	        mail.setTemplatePlaceHolders(templateDetailsMap);
	        mail.setSendEmail(true);
	        mail.setHtmlContent(true);
	        mail.setTemplateName(template);
	        mail.setSubject(subject);
	        mail.setTo(new ArrayList<String>());
	        mail.setCc(new ArrayList<String>());
	        mail.setBcc(mailList);

	        try{
	        mailStatus=mailService.sendEmail(mail);
	        lOGGER.info("Sent Mail with Status "+mailStatus);
	        //Making rest call just to test SMS service ,Once we have a user story will change according to the story
	        if(!returnType.equals(Constant.GSTR6)){
		        String resource = env.getProperty("batch.restapi.host")+env.getProperty("asp-sendSms");
		        HttpHeaders httpHeaders = new HttpHeaders();
		        httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		        JSONObject smsJson=new JSONObject();
		        smsJson.put("mobileNumber", "91999999999");//HardCoded mobile number to test SMS functionality,Needs to be removed
		        smsJson.put("message", "Dear Member, Error report available for "+gstin);
		        lOGGER.info("Json Sms is "+smsJson);
	        //Making rest call just to test SMS service ,Once we have a user story will change according to the story
	        batchClientUtility.executeRestCall(resource,httpHeaders,smsJson.toString(),  HttpMethod.POST);
	        //smsStatus=smsService.generateSms(sms);
	        lOGGER.info("Sms sent with Status "+smsStatus);
	        }
	        if(NotificationConstants.EMAIL_SUCCESS_MESSAGE.equals(mailStatus)){
	        	details.setGstin(gstin);
	        	details.setReturnType(returnType);
	        	notifiedGstnList.add(details);
	        }
	        }catch(Exception ex){
	        	lOGGER.error("Error while sending Eamil and SMS "+ex);
	        }
	        }
		}}
	
	@AfterStep
    public void afterStep(StepExecution stepExecution) throws IOException {
    	ExecutionContext executionContext=stepExecution.getJobExecution().getExecutionContext();
    	lOGGER.info("Executing After Mail Job  with notified List"+notifiedGstnList);
    	executionContext.put("notifiedGstinList", notifiedGstnList);
       
    }
    	
	}
 

