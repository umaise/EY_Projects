package com.ey.advisory.asp.batch.writer;


import java.util.List;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.client.dto.TechReconDTO;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;


public class TechReconWriter implements ItemWriter<TechReconDTO> {

	@Autowired
	private BatchClientUtility batchClientUtility;
	
	@Autowired
	private Environment env;
	
	private String jobName;
	private String jobNameGroupCode,groupCode;
	
	protected static final Logger LOGGER = Logger.getLogger(TechReconWriter.class);
	private static final String CLASS_NAME = TechReconWriter.class.getName();

	
	@BeforeStep
	public void getGroupcode(StepExecution stepExecution) {
		JobExecution jobExecution = stepExecution.getJobExecution();
		jobName = jobExecution.getJobInstance().getJobName();
		jobNameGroupCode = jobExecution.getJobParameters().getString("JOB_NAME");
		if (jobNameGroupCode != null) {
			int index = jobNameGroupCode.indexOf("_");
			groupCode=jobNameGroupCode.substring(index+1);
			LOGGER.info("GroupCode fetched in "+ CLASS_NAME  + groupCode);
		}else{
			LOGGER.info("GroupCode coundnot be fetched as jobNameGroupCode is null" );
		}
	
	}
	
	@Override
	public void write(List<? extends TechReconDTO> item) throws Exception {
		try{
			LOGGER.info("Inside write method of  "+ CLASS_NAME );
			  for(TechReconDTO techReconDTO:item)
			  {
			      JSONObject json=new JSONObject();
			      json = new org.json.simple.JSONObject();
			      json.put(Constant.GSTIN_ID, techReconDTO.getGstin());
			      json.put(Constant.ACTION, techReconDTO.getAction());
			      json.put(Constant.TAX_PERIOD,techReconDTO.getTaxPeriod());
			      json.put(Constant.GROUP_CODE,groupCode);
			      json.put(Constant.LoadId,techReconDTO.getLoadId());
			      
		         HttpHeaders httpHeaders = new HttpHeaders();
		         httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		         httpHeaders.add(TenantConstant.REQUEST_TENANT_HEADER, groupCode);
		         String path = env.getProperty("batch.restapi.host");
		         LOGGER.info("Making asp-app call in " +CLASS_NAME);
		         String resource = path + env.getProperty("asp-getGstr1");
		                   batchClientUtility.executeRestCall(resource,
	                                       httpHeaders, json.toString(), HttpMethod.POST);
		     }
	    }
		catch (Exception e){
			LOGGER.error("Exception in " + CLASS_NAME + " Method : techReconJob" + e.getMessage());
        }

	}
}
