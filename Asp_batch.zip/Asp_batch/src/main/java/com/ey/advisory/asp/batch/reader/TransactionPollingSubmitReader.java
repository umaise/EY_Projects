package com.ey.advisory.asp.batch.reader;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import com.ey.advisory.asp.client.dto.TransactionIDPolling;
import com.ey.advisory.asp.client.service.GSTINDetailsService;

public class TransactionPollingSubmitReader implements ItemReader<TransactionIDPolling> {

	private String jobName;
	private int rowCount = 0;
	private static final Logger LOGGER = Logger.getLogger(TransactionPollingSubmitReader.class);

	@Autowired
	GSTINDetailsService gstinDetailsService;

	List<TransactionIDPolling> transactionIDPollingList;

	@BeforeStep
	public void getInterstepData(StepExecution stepExecution) {
		JobExecution jobExecution = stepExecution.getJobExecution();
		LOGGER.info("Job Name" + jobExecution.getJobInstance().getJobName());
		this.jobName = jobExecution.getJobInstance().getJobName();
		try{
		if (com.ey.advisory.asp.batch.util.Constant.SUMMARY_TRNX_ID_POLLING_JOB.equalsIgnoreCase(this.jobName))
		{
			transactionIDPollingList = gstinDetailsService.getTransactionIDPollingList(true);
		} else 
		{
			transactionIDPollingList = gstinDetailsService.getTransactionPollingSubmitList(false);
		}}
		catch(Exception e){
			LOGGER.error("Exception in getInterstepData() for Get Status submit "+e);
		}
	}

	@Override
	public TransactionIDPolling read()
			throws UnexpectedInputException, ParseException, NonTransientResourceException,Exception
	{
		TransactionIDPolling transactionIDPolling = null;
		try{
		if(transactionIDPollingList!=null && rowCount < transactionIDPollingList.size())
        {
			LOGGER.info("transactionIDPollingList size = " +transactionIDPollingList.size());
        	transactionIDPolling =  transactionIDPollingList.get(rowCount);      
            ++rowCount;
        }
		}catch(Exception e){
			LOGGER.error(" TransactionIDPolling read() for submit "+e);
		}
		return transactionIDPolling; 
  } 
	
	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

}
