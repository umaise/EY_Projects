package com.ey.advisory.asp.batch.writer;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.service.TblGstinRetutnFilingStatusService;
import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;

@Component
@Scope(value = "step") 
public class ReturnFilingDetailsWriter implements ItemWriter<List<TblGstinRetutnFilingStatus>> {
	@Autowired
	TblGstinRetutnFilingStatusService GstinRetutnFilingStatusService;
	
	@Autowired
	TenantDynamicJobDetailsService tenantDynamicJobDetailsService;
	
	@Value("#{jobParameters['BATCH_TENANT_CONTEXT']}")
	private String groupCode;
	
	protected static final Logger lOGGER = Logger.getLogger(ReturnFilingDetailsWriter.class);
	
	@Override
	public void write(List<? extends List<TblGstinRetutnFilingStatus>> items)
			throws Exception {
		for(List<TblGstinRetutnFilingStatus> list:items){
			if(list!=null)
			GstinRetutnFilingStatusService.saveAllGstinReturnFilingStatus(list);
		}
		
	}
	
	@AfterStep
    public void afterStep(StepExecution stepExecution) throws IOException {
    	lOGGER.info("Executing After ReturnFilingDetailsWriter Job  to update the [tblTenantDynamicJobDetail] with group "+groupCode);
    	tenantDynamicJobDetailsService.updateJobDetail(Constant.CREATE_RETURN_FILING_DETAILS_JOB, groupCode, null);
    }
	

}
