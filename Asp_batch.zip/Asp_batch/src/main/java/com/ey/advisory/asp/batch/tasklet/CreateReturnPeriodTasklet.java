package com.ey.advisory.asp.batch.tasklet;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.asp.master.service.ReturnPeriodService;

@Component
public class CreateReturnPeriodTasklet implements Tasklet {

	@Autowired
	private ReturnPeriodService returnPeriodService;

	protected static final Logger lOGGER = Logger
			.getLogger(CreateReturnPeriodTasklet.class);

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		ExecutionContext executionContext = chunkContext.getStepContext()
				.getStepExecution().getJobExecution().getExecutionContext();
		lOGGER.info("Inside execute method of CreateReturnPeriodTasklet");
		String status = "";
		LocalDate todayDate = LocalDate.now();
		String[] dateFields = todayDate.toString().split("-");
		String currentTaxPeriod = dateFields[1] + dateFields[0];
		LocalDate firstDateOfMonth = todayDate.with(TemporalAdjusters
				.firstDayOfMonth());
		LocalDate lastDateOfMonth = todayDate.with(TemporalAdjusters
				.lastDayOfMonth());
		ReturnPeriod currentReturnPeriod = new ReturnPeriod();
		currentReturnPeriod.setCurrentPeriod(true);
		currentReturnPeriod.setEndDt(Date.valueOf(lastDateOfMonth));
		currentReturnPeriod.setStartDt(Date.valueOf(firstDateOfMonth));
		try {
			ReturnPeriod existingReturnPeriod = returnPeriodService
					.getReturnPeriod();
			if (currentTaxPeriod != null) {
				if (existingReturnPeriod != null) {
					if (!existingReturnPeriod.getTaxPeriodMMYYYY().toString()
							.equals(currentTaxPeriod)) {
						
						returnPeriodService
								.deActivateReturnPeriod(existingReturnPeriod
										.getPeriodId());
						returnPeriodService
								.saveReturnPeriod(currentReturnPeriod);
						lOGGER.info("existing return period "+existingReturnPeriod+" deactivated and created current Return Period"+currentReturnPeriod);
					}
				} else {
					returnPeriodService.saveReturnPeriod(currentReturnPeriod);
					lOGGER.info("There is no active existing return period , created current Return Period"+currentReturnPeriod);
				}
				executionContext
						.putString("currentTaxPeriod", currentTaxPeriod);
				status = Constant.SUCCESS;
			}
		} catch (Exception ex) {
			lOGGER.error("Error while deActivating the existing TaxPeriod and creating Current Period "
					+ ex);
			status = Constant.FAILED;
		}
		executionContext.putString("status", status);
		return RepeatStatus.FINISHED;
	}

}
