package com.ey.advisory.asp.batch.tasklet;

import org.quartz.Scheduler;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;
import com.ey.advisory.asp.quartz.dynamicScheduler.DynamicScheduler;

public class UnscheduleCustomerSpecificIterativeJobTasklet implements Tasklet {

	@Autowired
	@Qualifier("systemClientDynaScheduler")
	private DynamicScheduler dynamicScheduler;
	
	@Autowired
	TenantDynamicJobDetailsService tenantDynamicJobDetailsService;

	private Scheduler scheduler;

	@Autowired
	public UnscheduleCustomerSpecificIterativeJobTasklet(
			@Qualifier("systemClientDynaJobScheduler") Scheduler newScheduler) {
		this.scheduler = newScheduler;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		dynamicScheduler.setScheduler(scheduler);
		dynamicScheduler.unscheduleJobWIthSimpleTrigger(Constant.CUSTOMER_SPECIFIC_ITERATIVE_JOB+"_"+Constant.MASTER, Constant.MASTER);
		tenantDynamicJobDetailsService.updateJobDetail(Constant.CUSTOMER_SPECIFIC_ITERATIVE_JOB, Constant.MASTER, null);
		return RepeatStatus.FINISHED;
	}

}
