package com.ey.advisory.asp.batch.tasklet;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.repository.CustomerJobFrequencyDetailsRepository;

@PropertySource("classpath:batch.properties")
public class FetchCustomerJobPriorityListTasklet implements Tasklet{
	
	@Autowired
	private CustomerJobFrequencyDetailsRepository customerJobFrequencyDetails;
	
	@Value("${numberOfJobsToRunInParallel}")
	private String readCount;
	
	protected static final Logger lOGGER = Logger.getLogger(FetchCustomerJobPriorityListTasklet.class);
	

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		int rowCount = 1;
		if(readCount != null){
			rowCount = Integer.parseInt(readCount);
		}
		
		int tempReadCount = rowCount;
		
		lOGGER.info("Inside execute method of FetchCustomerJobPriorityListTasklet");
		ExecutionContext executionContext = chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();

		LocalDate date = LocalDate.now();
		int day = date.getDayOfMonth();

		Pageable topResult = new PageRequest(0, rowCount);

		List<String> groupPriorityList = new ArrayList<>();

		switch (day) {
		case 7:
		case 14:
		case 21:
			groupPriorityList = customerJobFrequencyDetails.getJobPriorityDetails(Constant.WEEKLY, topResult);
			rowCount = rowCount - groupPriorityList.size();
			if (rowCount > 0) {
				topResult = new PageRequest(0, rowCount);
				groupPriorityList.addAll(customerJobFrequencyDetails.getJobPriorityDetails(Constant.DAILY, topResult));
			}
			break;

		case 15:
			groupPriorityList = customerJobFrequencyDetails.getJobPriorityDetails(Constant.FORTNIGHTLY, topResult);
			rowCount = rowCount - groupPriorityList.size();
			if (rowCount > 0) {
				topResult = new PageRequest(0, rowCount);
				groupPriorityList.addAll(customerJobFrequencyDetails.getJobPriorityDetails(Constant.DAILY, topResult));
			}
			break;

		default:
			LocalDate endOfMonth = date.with(TemporalAdjusters.lastDayOfMonth());
			int lastDay = endOfMonth.getDayOfMonth();
			if (day == lastDay) {
				groupPriorityList = customerJobFrequencyDetails.getJobPriorityDetails(Constant.MONTHLY, topResult);
				rowCount = rowCount - groupPriorityList.size();
				if (rowCount > 0) {
					topResult = new PageRequest(0, rowCount);
					groupPriorityList
							.addAll(customerJobFrequencyDetails.getJobPriorityDetails(Constant.FORTNIGHTLY, topResult));

					rowCount = rowCount - groupPriorityList.size();
					if (rowCount > 0) {
						topResult = new PageRequest(0, rowCount);
						groupPriorityList
								.addAll(customerJobFrequencyDetails.getJobPriorityDetails(Constant.WEEKLY, topResult));

						rowCount = rowCount - groupPriorityList.size();
						if (rowCount > 0) {
							topResult = new PageRequest(0, rowCount);
							groupPriorityList.addAll(
									customerJobFrequencyDetails.getJobPriorityDetails(Constant.DAILY, topResult));
						}
					}
				}
			} else {
				groupPriorityList = customerJobFrequencyDetails.getJobPriorityDetails(Constant.DAILY, topResult);
			}
			break;
		}
		
		executionContext.put("groupPriorityList", groupPriorityList);		
		rowCount = tempReadCount;	
		
		return RepeatStatus.FINISHED;
	}

}
