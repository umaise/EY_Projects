package com.ey.advisory.asp.batch.tasklet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblGSTINSummaryList;
import com.ey.advisory.asp.client.dto.FileDto;
import com.ey.advisory.asp.client.dto.FileGroupDto;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.TblGSTINSummaryListService;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.SummaryFileUploadRepository;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;
import com.ey.advisory.asp.master.service.SpCallService;
import com.google.gson.Gson;



/**
 * @author Smruti.Pradhan
 *	This tasklet is to interfaceFile to GSTN
 */
public class FileSummaryInterfaceToGstnTasklet implements Tasklet{
	protected static final Logger LOGGER = Logger.getLogger(FileSummaryInterfaceToGstnTasklet.class);
	@Autowired
	TblGSTINSummaryListService tblGSTINSummaryListService;
	@Autowired
	private TenantDynamicJobDetailsRepository tenantDynamicJobDetailsRepository;
	@Autowired
	ClientSpCallService clientSpCallService;

	@Autowired
	private Environment env;

	@Autowired
	private BatchClientUtility batchClientUtility;

	@Autowired
	Gstr1Service gstr1Service;
	@Autowired
	SpCallService spCallService;
	@Autowired
	SummaryFileUploadRepository summaryFileUploadRepository;
	
	private String storedProcName;
	private String storedProcSchema;
	private int threshold;
	private Long chunkId;
	private String inputParamsCount;
	private String inputParams;
	final int chunkSize=5 *1024 *1024;//5mb
	@AfterStep
	public void afterStep(StepExecution stepExecution) throws IOException {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in afterStep ");
			}
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("Inside FileSummaryInterfaceToGstnTasklet execute method");
		List<TblGSTINSummaryList> gstinListSummary=null;
		try {

	    	String groupCode;
	    	int groupId;
	    	String status=Constant.SUMMARYFILEUPDATESTATUS;
	    	List<String> groupCodeList=spCallService.fetchgroupIdSummaryDetails(Constant.SUMMARYFILESTATUS);
	    	Gson gson = new Gson();
	    	List<Integer> fileIdlists=new ArrayList<>();
	    	for(String groupCodeIt :groupCodeList)
	    	{
  		
	    		FileGroupDto detailList = gson.fromJson(groupCodeIt, FileGroupDto.class);
	    		List<FileDto> fileIdlist=detailList.getFileId();
	    		for(FileDto fileIdInt:fileIdlist)
	    		{
	    			fileIdlists.add(fileIdInt.getSummaryFileID());
	    		}
	    		groupId=detailList.getGroupId();
	    		groupCode=detailList.getGroupCode();
	    		gstinListSummary = tblGSTINSummaryListService.getGstinRtSummaryType(fileIdlists);	
	    		if(gstinListSummary!=null && !gstinListSummary.isEmpty()){
				//insert or update the records in [TblGstinRetutnFilingStatus] table
	    		tblGSTINSummaryListService.insertUpdateGstr12SummaryStatus(gstinListSummary);
	    		sendChunkData(gstinListSummary);
	    		createSummarySimpleTrigger(groupCode,groupId);
	    		summaryFileUploadRepository.updateSummaryStatus(fileIdlists,status);
	    		}	    		
	    		
	    		
	    	}
		
		}catch (Exception ex) {
			gstr1Service.updateGstnTranId("", "", "", "", chunkId);
			LOGGER.error("Exception in FileSummaryInterfaceToGstnTasklet write method");
			
		}
		return RepeatStatus.FINISHED;
	}

	private String executeSp(long threshold,long chunkId,String gstin,String txPeriod,String returnType) throws Exception{
		
		List<String> inputParamList = new ArrayList<>();
		inputParamList.add(Long.toString(threshold));
		inputParamList.add(Long.toString(chunkId));
		inputParamList.add(gstin); 
		inputParamList.add(txPeriod);
		inputParamList.add(returnType);
		
		String jsonString = clientSpCallService.executeStoredProcedure(storedProcSchema, storedProcName,
				inputParamsCount, inputParamList);
		return jsonString;
}
	

private int checkSize(String jsonString){
	try{
		ByteArrayOutputStream obj=new ByteArrayOutputStream();
	    GZIPOutputStream gzip = new GZIPOutputStream(obj);
	    gzip.write(jsonString.getBytes("UTF-8"));
	    gzip.close();
	    String outStr = obj.toString("UTF-8");
	    byte[] b = outStr.getBytes("UTF-8");
		int resSize=b.length;
		return resSize;
	}catch(Exception e){
		return 0;
	}
}
private List<Long> checkJsonOutput(String jsonString)
{
	String payloadDtolist;
	JSONParser jsonParser = new JSONParser();
	JSONObject jsonObject=null;
	List<Long> result=new ArrayList<>();
	if(!("0").equalsIgnoreCase(jsonString))
	{
	payloadDtolist = jsonString.substring(1,
			jsonString.length() - 1);
	//get the chunkid and thresholdNew
	 try {
		jsonObject = (JSONObject) jsonParser.parse(payloadDtolist);
		 long thresholdNew = (long) jsonObject.get("threshold");
		 chunkId=(long) jsonObject.get("chunkId");
		 result.add(thresholdNew);
		 result.add(chunkId);
	} catch (ParseException e) {
		
		e.printStackTrace();
	}
	
	}
	return result;
} 
private void sendChunkData(List<TblGSTINSummaryList>gstinListSummary) 
{
	HttpHeaders httpHeaders = new HttpHeaders();
	httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
	long thresholdNew=0;
	String gstin=null;
	String txPeriod=null;
	String returnType=null;
	String jsonString =null;
	try{
	for(TblGSTINSummaryList gstinData:gstinListSummary){
		Boolean success=true;
		gstin=gstinData.getgSTIN();
		txPeriod=gstinData.getTaxPeriod();
		returnType=gstinData.getReturnType();
		jsonString = executeSp(threshold,0,gstin,txPeriod,returnType);
		List<Long> result=checkJsonOutput(jsonString);
		if(result!=null && !result.isEmpty())
		{//get the chunkid and thresholdNew
		 thresholdNew = (long) result.get(0);
		 chunkId=(long) result.get(1);
		}
		while(success){
				int size = checkSize(jsonString);
				if(size!=0 && size<chunkSize){
					if(returnType.equalsIgnoreCase(Constant.GSTR1))
						{
							batchClientUtility.executeRestCall(env.getProperty("node-gstr1-Datapipeline3-host"),
									httpHeaders, jsonString, HttpMethod.POST);
						}else if(returnType.equalsIgnoreCase(Constant.GSTR2))
						{
							batchClientUtility.executeRestCall(env.getProperty("node-gstr2-Datapipeline3-host"),
									httpHeaders, jsonString, HttpMethod.POST);
						}
						//send previous chunkId
						jsonString=executeSp(thresholdNew,0,gstinData.getgSTIN(),gstinData.getTaxPeriod(),returnType);
						
						if(("0").equalsIgnoreCase(jsonString))
						{	success=false;
						tblGSTINSummaryListService.updateGstinSummaryList(gstinData);
						}else
						{
						result=checkJsonOutput(jsonString);
						if(result!=null)
						{//get the chunkid and thresholdNew
						 thresholdNew = (long) result.get(0);
						 chunkId=(long) result.get(1);
						}
						}
				
				}
				else{
					success=true;
					thresholdNew=thresholdNew/2;
					jsonString=executeSp(thresholdNew,chunkId,gstin,txPeriod,returnType);
					result=checkJsonOutput(jsonString);
					if(result!=null)
					{//get the chunkid and thresholdNew
					 thresholdNew = (long) result.get(0);
					 chunkId=(long) result.get(1);
					}
				}
			}
	}}
	catch(Exception ex){
		gstr1Service.updateGstnTranId("", "", "", "", chunkId);
		LOGGER.error("Exception in FileSummaryInterfaceToGstnTasklet write method");
	}
}
private void createSummarySimpleTrigger(String groupCode,int groupId){
	
		inputParams=groupCode+","+groupId+","+groupId;
		if(groupCode!=null){
		Map<String,Object> paramMap=new HashMap<>();
		paramMap.put("groupId",groupId);
		paramMap.put("groupCode", groupCode);
		paramMap.put("paramsList", inputParams);
		TenantDynamicJobDetail tenantDynamicJobDetail=new TenantDynamicJobDetail();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = null;
        byte[] jobParam = null;
        try {
        	out = new ObjectOutputStream(bos);   
        	out.writeObject(paramMap);
        	jobParam = bos.toByteArray();
        	tenantDynamicJobDetail.setGroupCode(groupCode);
          	tenantDynamicJobDetail.setJobName(Constant.SUMMARY_TRNX_ID_POLLING_JOB);
			tenantDynamicJobDetail.setPriority(10);
			tenantDynamicJobDetail.setRepeatCount(1);
			tenantDynamicJobDetail.setRepeatInterval(2);
			tenantDynamicJobDetail.setJobParam(jobParam);
			tenantDynamicJobDetail.setStatus(Constant.NEW);
		    tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
		    LOGGER.info("Job has been scheduled "+"summaryTransactionIDPollingJob");
        }catch(Exception ex){
        	LOGGER.error("Exception in "+" Exception is "+ ex);
        } finally {
          try {
            bos.close();
          } catch (IOException ex) {
              throw new IllegalStateException("Not able to write Job Param");
          }
        } 
	}
	
}
public void setStoredProcName(String storedProcName) {
	this.storedProcName = storedProcName;
}

public String getStoredProcSchema() {
	return storedProcSchema;
}

public void setStoredProcSchema(String storedProcSchema) {
	this.storedProcSchema = storedProcSchema;
}

public long getChunkId() {
	return chunkId;
}

public void setChunkId(long chunkId) {
	this.chunkId = chunkId;
}

public String getInputParamsCount() {
	return inputParamsCount;
}

public void setInputParamsCount(String inputParamsCount) {
	this.inputParamsCount = inputParamsCount;
}
public int getThreshold() {
	return threshold;
}

public void setThreshold(int threshold) {
	this.threshold = threshold;
}
public String getStoredProcName() {
	return storedProcName;
}
public String getInputParams() {
	return inputParams;
}

public void setInputParams(String inputParams) {
	this.inputParams = inputParams;
}
}
