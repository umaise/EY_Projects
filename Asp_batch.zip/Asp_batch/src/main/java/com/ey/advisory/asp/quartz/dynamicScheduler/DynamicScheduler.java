package com.ey.advisory.asp.quartz.dynamicScheduler;

import static org.quartz.DateBuilder.futureDate;
import static org.quartz.SimpleScheduleBuilder.simpleSchedule;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.quartz.CronTrigger;
import org.quartz.DateBuilder.IntervalUnit;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;
import com.ey.advisory.asp.quartz.TenantJobLauncher;


@PropertySource("classpath:batch.properties")
public class DynamicScheduler{

    @Autowired
	private Environment env;

    private Scheduler scheduler;
        
    protected static final Logger LOGGER = Logger.getLogger(DynamicScheduler.class);
   	private static final String CLASS_NAME = DynamicScheduler.class.getName();

    public void scheduleInvocation(String jobName, String group, String cronExpression,byte[] jobData) throws Exception {
        schedule(createDynamicJobDetail(jobName, group,jobData),
            buildCronTrigger(jobName, group, cronExpression));
    }
    
    /*public void scheduleChainableJobInvocation(String jobName, String group, String cronExpression, String description) throws Exception {
        JobDetail job = JobBuilder.newJob(QuartzChainableJobLauncher.class).withIdentity(jobName, group).withDescription(description).build();
        schedule(job, buildCronTrigger(jobName, group, cronExpression));
    }*/

    
    @SuppressWarnings("deprecation")
    public CronTrigger buildCronTrigger(String jobName, String group, String cronExpression) {
        try {
            CronTriggerImpl trigger ;
            if (cronExpression != null) {
                trigger = new CronTriggerImpl(jobName, group, cronExpression);
            }
            else{
                final Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DATE, -1);
                trigger = new CronTriggerImpl(jobName+"Trigger", "ChainedTrigger", jobName, group, cal.getTime(), null, "0 0 0 * * ?"); 
            }
            trigger.setTimeZone(TimeZone.getTimeZone(env.getProperty("cronTrigger.timeZone")));
            return trigger;
        }
        catch (Exception e) {
        	if(LOGGER.isInfoEnabled())
            LOGGER.info("Exception in " + CLASS_NAME+ " Method : buildCronTrigger"+ e.getMessage());
            throw new IllegalStateException("Failed to get trigger");
        }
    }

    public JobDetail createDynamicJobDetail(String jobName, String group,byte[] jobData) {
        JobDetail job = JobBuilder.newJob(TenantJobLauncher.class).withIdentity(jobName, group).build();
        job.getJobDataMap().put("jobName", jobName);
        job.getJobDataMap().put(TenantConstant.BATCH_TENANT_CONTEXT, group);
        deSerialize(jobData,job);
        return job;
    }
    
    public JobDetail createTenantDynamicJobDetail(String jobName, String group, String description) {
        JobDetail job = JobBuilder.newJob(TenantJobLauncher.class).withIdentity(jobName, group).withDescription(description).build();
        job.getJobDataMap().put(TenantConstant.BATCH_TENANT_CONTEXT, group);
        
        return job;
    }
    
    public boolean checkIfSameJobExistWithDiffFileId(String jobName, String jobGroup, JobDataMap inputJobDataMap) {

        JobKey jobKey = new JobKey(jobName, jobGroup);
        JobDetail job;

        boolean flag = false;
        	 try {
        	            job = scheduler.getJobDetail(jobKey);
        	            if (job != null) {
        	                JobDataMap dataMap = job.getJobDataMap();
        	                if(dataMap.containsKey("fileId")){
        	                if (!(dataMap.get("fileId").equals(inputJobDataMap.get("fileId")))) {
        	                    flag = true;
        	                }
        	            }else if(dataMap.containsKey("invoiceType") && dataMap.containsKey("gstin")) {
        	            	if (dataMap.get("invoiceType").equals(inputJobDataMap.get("invoiceType")) && dataMap.get("gstin").equals(inputJobDataMap.get("gstin"))) {
        	                    flag = true;
        	                }
        	            }else if(dataMap.containsKey("reportId")) {
        	            	if (dataMap.get("reportId").equals(inputJobDataMap.get("reportId"))) {
        	                    flag = true;
        	                }
        	            }else if(dataMap.containsKey(Constant.JOB_NAME_KEY) && ((String)dataMap.get(Constant.JOB_NAME_KEY)).equals(Constant.RECON_JOB_NAME) && dataMap.containsKey("gstin")) {
        	            	if (dataMap.get("gstin").equals(inputJobDataMap.get("gstin"))) {
        	                    flag = true;
							}
        	            }else
        	            	 flag = true;
        	       } 
        }
        catch (SchedulerException e) {
        	if(LOGGER.isInfoEnabled())
            LOGGER.info("Exception in " + CLASS_NAME+ " Method : checkIfSameJobExistWithDiffFileId"+ e.getMessage());
        }
        return flag;
    }
    
    public Trigger buildSimpleTrigger(String name, String group, Integer repeatInterval,Integer repeatCount, Integer priority){
        
        SimpleTrigger trigger ;
        
        if(priority == null){
            priority = 5;
        }
        
        if(repeatCount != null && repeatCount!=0){
            trigger = TriggerBuilder.newTrigger()
            .withIdentity(name, group).startNow()
            .withSchedule(simpleSchedule()
            .withIntervalInMinutes(repeatInterval)
            .withRepeatCount(repeatCount)
            .withMisfireHandlingInstructionNextWithRemainingCount())
            .withPriority(priority)
            .build();
        }
        else{
            trigger = (SimpleTrigger) TriggerBuilder.newTrigger()
            .withIdentity(name, group)
            .startAt(futureDate(repeatInterval, IntervalUnit.MINUTE))
            .withPriority(priority)
            .build();
        }
        
        return trigger;
    }
    
    public void unscheduleJobWIthSimpleTrigger(String triggerName, String triggerGroup){
        
        TriggerKey key = new TriggerKey(triggerName, triggerGroup);
        
        try {
            this.scheduler.unscheduleJob(key);
        }
        catch (SchedulerException e) {
            throw new IllegalStateException("Failed to find Job.", e);
        }
        
    }

   
    public int scheduleJobWithSimpleTrigger(JobDetail job, Trigger trigger){        
        
        if (!isJobExists(job)) {
            doScheduleJob(job, trigger);
            return 0;
        }
        else{
        	return -1;
        }
    }

    public void schedule(JobDetail job, CronTrigger trigger) {
        if (isJobExists(job)) {
            rescheduleJob(job, trigger);
        }
        else {
            doScheduleJob(job, trigger);
        }
    }

    private boolean isJobExists(JobDetail job) {
        try {
            if (this.scheduler.getJobDetail(job.getKey()) != null) {
                return true;
            }
            else
                return false;
        }
        catch (SchedulerException e) {
            throw new IllegalStateException("Failed to find Job.", e);
        }
    }

    private void doScheduleJob(JobDetail job, Trigger trigger) {
        try {
            this.scheduler.scheduleJob(job, trigger);
        }
        catch (SchedulerException e) {
            throw new IllegalStateException("Failed to schedule the Job.", e);
        }
    }

    private void rescheduleJob(JobDetail job, CronTrigger trigger) {
        try {
            CronTrigger existingCronTrigger= (CronTrigger)scheduler.getTrigger(trigger.getKey());
            if(!existingCronTrigger.getCronExpression().equals(trigger.getCronExpression())){
                this.scheduler.rescheduleJob(trigger.getKey(), trigger);
            }
        }
        catch (SchedulerException e) {
            throw new IllegalStateException("Failed to reschedule the Job.", e);
        }

    }

    public void deleteJob(JobDetail job, CronTrigger trigger) {
        try {
            this.scheduler.unscheduleJob(trigger.getKey());
            this.scheduler.deleteJob(job.getKey());
        }
        catch (SchedulerException e) {
            throw new IllegalStateException("Failed to delete the Job.", e);
        }

    }
    
    public Scheduler getScheduler() {
        return scheduler;
    }

    public void setScheduler(Scheduler scheduler) {
        this.scheduler = scheduler;
    }
    private JobDetail deSerialize(byte[] jobData,JobDetail job){
        
             

        if (jobData != null && jobData.length!=0) {
            InputStream is = new ByteArrayInputStream(jobData);
            ObjectInputStream ois = null;
            try {
                ois = new ObjectInputStream(is);
                Map<String, Object> inputJobMap = (Map<String, Object>) ois.readObject();
                if (inputJobMap != null) {
                    Iterator<String> keys = inputJobMap.keySet().iterator();
                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        Object value = inputJobMap.get(key);
                                                 
                            job.getJobDataMap().put(key, value);
                    }
                }
            }
            catch (Exception e) {
            	if(LOGGER.isInfoEnabled())
                LOGGER.info("Exception in " + CLASS_NAME+ " Method : deSerialize"+ e.getMessage());
                throw new IllegalStateException("Not able to parse Job Param");
            }
            finally{
            	try {
    				ois.close();
    				is.close();
    			} catch (IOException ex) {
    				throw new IllegalStateException("Not able to write Job Param");
    			}
            	
            }
        }
        return job;
    }
}