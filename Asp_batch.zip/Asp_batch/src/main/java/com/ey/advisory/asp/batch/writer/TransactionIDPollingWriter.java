package com.ey.advisory.asp.batch.writer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.dto.TransactionIDPolling;
import com.ey.advisory.asp.client.service.GSTINDetailsService;
import com.ey.advisory.asp.client.util.CommonUtillity;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.service.second.IAPIService;
import com.ey.advisory.asp.gstn.util.CryptoUtil;
import com.ey.advisory.asp.gstn.util.RestClientUtility;

public class TransactionIDPollingWriter implements ItemWriter<TransactionIDPolling> {

	@Autowired
	@Qualifier("GSPService")
	IAPIService gstnServiceImpl;

	@Autowired
	GSTINDetailsService gstinService;

	@Autowired
	GSTINDetailsService gstinDetailsService;

	private String jobName;
	private String jobNameGroupCode;
	private String groupCode;
	String errorMessage;
	List<Long> transactionIDPollingList=new ArrayList<Long>() ;


	protected static final Logger LOGGER = Logger.getLogger(TransactionIDPollingWriter.class);
	private static final String CLASS_NAME = TransactionIDPollingWriter.class.getName();

	@BeforeStep
	public void getInterstepData(StepExecution stepExecution) {
		JobExecution jobExecution = stepExecution.getJobExecution();
		jobName = jobExecution.getJobInstance().getJobName();
		jobNameGroupCode = jobExecution.getJobParameters().getString("JOB_NAME");
		if (jobNameGroupCode != null) {
			//groupCode = jobNameGroupCode.split("_")[1];
			int index = jobNameGroupCode.indexOf("_");
			groupCode=jobNameGroupCode.substring(index+1);
		}
		LOGGER.info("GroupCode fetched = " + groupCode);
	}

	@Override
	public void write(List<? extends TransactionIDPolling> items) throws Exception {

		for (TransactionIDPolling transactionIDPolling : items) {

			LOGGER.info("TransactionIDPollingWriter Started ");
			
			AuthDetailsDto dto = new AuthDetailsDto();
			byte[] authEK = null;
			try {				
				String result = "";
				String status = "";
				String errorReport = "";
				if (!(CommonUtillity.isEmpty(transactionIDPolling.getGstinId()))) {
					dto = RestClientUtility.getRedisData(transactionIDPolling.getGstinId());

					if (null != dto) {
						if (!(CommonUtillity.isEmpty(groupCode))) {
							Map<Object, Object> gspDetails = RestClientUtility.getRedisDataForGSP(groupCode);
							if (null != gspDetails && gspDetails.size() > 0) {
								dto.setDigigstUserName((String) gspDetails.get(Constant.GSP_DIGIGST_USERNAME));
								dto.setAccessToken((String) gspDetails.get(Constant.ACCESS_TOKEN));
								dto.setApiKey(((String) gspDetails.get(Constant.API_KEY)).getBytes());
								dto.setApiSecret((String) gspDetails.get(Constant.API_SECRET));

								if (!(CommonUtillity.isEmpty(dto.getSek()))) {
									authEK = CryptoUtil.decodeBase64StringTOByte(dto.getSek());
									dto.setAuthEK(authEK);
								}

								TblGstinDetailsDomain gstinDto = gstinService
										.fetchGstinDetails(transactionIDPolling.getGstinId());
								if (gstinDto != null) {
									if (!(CommonUtillity.isEmpty(gstinDto.getStateCode()))) {
										dto.setStateCode(gstinDto.getStateCode());
									}
								}
								  result =
								 gstnServiceImpl.getTransactionStatus(dto,
								 Constant.VERSION_3, dto.getUserName(),
								 transactionIDPolling.getGstinId(), transactionIDPolling.getTaxPeriod(),
								 Constant.GSPGW_RESTAPI_HOST,
								 Constant.GSPGW_RESTAPI_RETURN,
								 transactionIDPolling.getReturnType().toLowerCase(), "RETSTATUS",
								 transactionIDPolling.getRefId(), true);
							
								if (result != null) {
									
									JSONParser jsonParser = new JSONParser();
									JSONObject jsonObject = (JSONObject) jsonParser.parse(result);
									status = (String) jsonObject.get(Constant.STATUS_CD);
									errorReport = null != jsonObject.get(Constant.GSTNerrorReport)
											? jsonObject.get(Constant.GSTNerrorReport).toString() : "";

											
									transactionIDPolling.setGstnStatus(status);
									transactionIDPolling.setErrorDesc(errorReport);
									transactionIDPollingList.add(transactionIDPolling.getLoadId())	;
											
									if (com.ey.advisory.asp.batch.util.Constant.SUMMARY_TRNX_ID_POLLING_JOB
											.equalsIgnoreCase(this.jobName)) {
										gstinDetailsService.updateGstnStatusToReturnUpload(
												transactionIDPolling.getFilingId(), transactionIDPolling.getTrxId(),
												transactionIDPolling.getRefId(), transactionIDPolling.getLoadId(),
												status, errorReport,transactionIDPolling.getGstinId(),transactionIDPolling.getGstnStatus(),transactionIDPolling.getErrorDesc(), true);
									} else {
										gstinDetailsService.updateGstnStatusToReturnUpload(
												transactionIDPolling.getFilingId(), transactionIDPolling.getTrxId(),
												transactionIDPolling.getRefId(), transactionIDPolling.getLoadId(),
												status, errorReport,transactionIDPolling.getGstinId(),transactionIDPolling.getGstnStatus(),transactionIDPolling.getErrorDesc(), false);
									}
								}
							} else {
								LOGGER.error("Api call Result is null");
							}

						} else {
							LOGGER.error("GSP details not available");
						}
					} else {
						LOGGER.error("GSTN details not available");
					}
				}
			} catch (Exception e) {
				LOGGER.error("Exception in " + CLASS_NAME + " Method : launchJob" + e);
			
			}
		}
    
}
@AfterStep	
public void updateFinalStatus(){
	LOGGER.info("updateFinalStatus() Started "+CLASS_NAME);
    try{
		if (com.ey.advisory.asp.batch.util.Constant.SUMMARY_TRNX_ID_POLLING_JOB.equalsIgnoreCase(this.jobName)) {
			gstinDetailsService.updateReturnFilingStatusForSummary();
		} else {
			//gstinDetailsService.updateReturnFilingStatusForSave();
			if(transactionIDPollingList!=null && transactionIDPollingList.size()>0)
				gstinDetailsService.updateReturnFilingStatusForSave(transactionIDPollingList);
		}
    }
    catch(Exception e){
    	LOGGER.error("Exception @AfterStep while setting final status "+e);
    }
	
}	
	
	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
}
