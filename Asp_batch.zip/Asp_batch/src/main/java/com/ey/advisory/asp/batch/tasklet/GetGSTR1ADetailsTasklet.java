package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepSynchronizationManager;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.client.util.AuthenticationUtility;
import com.ey.advisory.asp.common.Constant;

@PropertySource("classpath:RestConfig.properties")
public class GetGSTR1ADetailsTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	BatchClientUtility batchClientUtility;

	@Autowired
	private Environment env;

	@Autowired
	AuthenticationUtility authenticationUtility;

	private boolean isGstinAvailable;
	
	private String type;
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	private static final Logger LOGGER = Logger.getLogger(GetGSTR1ADetailsTasklet.class);
	private static final String CLASS_NAME = GetGSTR1ADetailsTasklet.class.getName();

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("Entering " + CLASS_NAME + " Method : execute");
		ExecutionContext executionContext = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getExecutionContext();
		StepExecution stepExecution = StepSynchronizationManager.getContext().getStepExecution();
		JSONParser jsonParser = new JSONParser();
		Map<String, String> outputParamMap = new HashMap<>();
		HttpHeaders httpHeaders = new HttpHeaders();
		JSONObject jsonObject;
		String action_required = "Y";
		String result;

		// TODO: Yet to complete the full logic for list/map..assuming just the
		// gstin and ret_prd is passed as params and not the list/map
		Map<String, List<String>> gstinPrdList = new HashMap<>();
		if (isGstinAvailable) {
			String gstin = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters()
					.getString("gstin");
			String ret_period = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters()
					.getString("ret_period");
			if (gstin != null && !gstin.isEmpty() && ret_period != null && !ret_period.isEmpty()) {

				List<String> gstinList = new ArrayList<>();
				gstinList.add(gstin);
				gstinPrdList.put(ret_period, gstinList);

			} else {
				stepExecution.setExitStatus(ExitStatus.NOOP);
				return RepeatStatus.FINISHED;
			}

		} else {
			if (executionContext.containsKey("gstinTaxPeriodMap")) {
				gstinPrdList = (HashMap<String, List<String>>) executionContext.get("gstinTaxPeriodMap");
			}
		}
		try {
			if (gstinPrdList != null && gstinPrdList.size() > 0) {
				for (Map.Entry<String, List<String>> entry : gstinPrdList.entrySet()) {

					List<String> gstinLst = entry.getValue();
					String retPrd = entry.getKey();
					for (String gstinData : gstinLst) {
						String resource;
						
							resource= env.getProperty(Constant.GSP_STUB_API_HOST)
							+ env.getProperty(Constant.GSP_STUB_API_GSTR1A_RESOURCE) + "?action="+type
							+ "&ret_period=" + retPrd + "&gstin=" + gstinData + "&action_required="
							+ action_required;
							
						result = batchClientUtility.executeRestCall(resource, httpHeaders, HttpMethod.GET);
						jsonObject = (JSONObject) jsonParser.parse(result);
						LOGGER.error("Before Starting stubs" + jsonObject);
						if (jsonObject.containsKey(Constant.REK) && jsonObject.containsKey(Constant.DATA)
								&& jsonObject.containsKey(Constant.STATUS_CD)) {
							LOGGER.error("Starting stubs");
							String rek = (String) jsonObject.get(Constant.REK);
							String data = (String) jsonObject.get(Constant.DATA);
							String status_cd = (String) jsonObject.get(Constant.STATUS_CD);
							if ("1".equals(status_cd)) {
								String apiKey = authenticationUtility.getBusinessTypeDetailsFromGSTN(rek,
										Constant.SESSION_KEY.getBytes());
								String finalJsonData = authenticationUtility.getBusinessTypeDetailsFromGSTN(data,
										apiKey.getBytes());
								outputParamMap.put(gstinData + "~" + retPrd, finalJsonData);
								
								
								
								executionContext.put("outputParamMap", outputParamMap);
								LOGGER.info(" Stub " + CLASS_NAME + "Json data is" + finalJsonData + " gstin is "
										+ gstinData + "~" + retPrd);
							} else {
								// TODO: Analyse more on Continue or Stop
								stepExecution.setExitStatus(ExitStatus.NOOP);
								return RepeatStatus.FINISHED;
							}
						}
					}

				}
			} else {
				stepExecution.setExitStatus(ExitStatus.NOOP);
				return RepeatStatus.FINISHED;
			}

		} catch (Exception ex) {
			LOGGER.error("Error " + CLASS_NAME + " Method : execute" + ex.getMessage());
		}
		LOGGER.info("Exiting " + CLASS_NAME + " Method : execute");
		return RepeatStatus.FINISHED;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		if (stepExecution.getExecutionContext().containsKey("gstin")) {
			isGstinAvailable = true;
		} else
			isGstinAvailable = false;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		return null;
	}

}
