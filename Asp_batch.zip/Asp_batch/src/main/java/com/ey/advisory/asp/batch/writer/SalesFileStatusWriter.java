package com.ey.advisory.asp.batch.writer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.ey.advisory.asp.batch.reader.SalesFileStatusReader;
import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblFileUploadStatus;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.TblFileUploadStatusService;
import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;
import com.ey.advisory.asp.master.repository.FileUploadStatusRepository;

public class SalesFileStatusWriter implements ItemWriter<FileUploadStatusMaster> {

	protected static final Logger LOGGER = Logger.getLogger(SalesFileStatusReader.class);

	@Autowired
	ClientSpCallService clientSpCallService;
	@Autowired
	TblFileUploadStatusService tblFileUploadStatusService;

	@Autowired
	private Environment env;

	@Autowired
	private BatchClientUtility batchClientUtility;

	@Autowired
	FileUploadStatusRepository tblSalesFileStatusRepo;

	private String storedProcName;
	private String storedProcSchema;
	private String inputParamsCount;
	private String isProcessed;
	private String jobStatus;
	boolean status = true;

	@Override
	public void write(List<? extends FileUploadStatusMaster> fileInfo) throws Exception {
		if(LOGGER.isInfoEnabled())
		LOGGER.info("Inside SalesFileStatusWriter write method");
		List<String> fileIdList;
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		try {
			for (FileUploadStatusMaster tblSalesFileInfo : fileInfo) {

				List<TblFileUploadStatus> fileUploadStatusList = tblFileUploadStatusService
						.getFileUploadStatusDetails(String.valueOf(tblSalesFileInfo.getFileId()));

				if (fileUploadStatusList != null && !fileUploadStatusList.isEmpty()
						&& !fileUploadStatusList.isEmpty()) {
					for (int i = 0; i < fileUploadStatusList.size(); i++) {
						fileIdList = new ArrayList<>();
						fileIdList.add(String.valueOf(fileUploadStatusList.get(i)));
						fileIdList.add(tblSalesFileInfo.getTaxPeriod());
						tblSalesFileStatusRepo.updateIsProcessedJobStatus(isProcessed, jobStatus,
								tblSalesFileInfo.getFileId());
						String jsonString = clientSpCallService.executeStoredProcedure(storedProcSchema, storedProcName,
								inputParamsCount, fileIdList);
						if (Constant.OUTWARD.equalsIgnoreCase(tblSalesFileInfo.getFileData())) {
							batchClientUtility.executeRestCall(env.getProperty("node-gstr1-Datapipeline3-host"),
									httpHeaders, jsonString, HttpMethod.POST);
						} else {
							batchClientUtility.executeRestCall(env.getProperty("node-gstr2-Datapipeline3-host"),
									httpHeaders, jsonString, HttpMethod.POST);
						}
					}
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in SalesFileStatusWriter write method");
			status = false;
		}
	}

	@AfterStep
	public void afterStep(StepExecution stepExecution) throws IOException {
		if (!status)
			stepExecution.setExitStatus(ExitStatus.NOOP);

	}

	public String getStoredProcSchema() {
		return storedProcSchema;
	}

	public void setStoredProcSchema(String storedProcSchema) {
		this.storedProcSchema = storedProcSchema;
	}

	public String getInputParamsCount() {
		return inputParamsCount;
	}

	public void setInputParamsCount(String inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}

	public final String getStoredProcName() {
		return storedProcName;
	}

	public final void setStoredProcName(String storedProcName) {
		this.storedProcName = storedProcName;
	}

	public String getIsProcessed() {
		return isProcessed;
	}

	public void setIsProcessed(String isProcessed) {
		this.isProcessed = isProcessed;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

}
