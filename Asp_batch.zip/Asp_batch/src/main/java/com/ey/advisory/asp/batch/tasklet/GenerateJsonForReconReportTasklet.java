package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;

import com.ey.advisory.asp.etl.service.ETLSpService;
import com.ey.advisory.asp.master.service.SpCallService;
@PropertySource("classpath:batch.properties")
public class GenerateJsonForReconReportTasklet implements Tasklet  {
	
	@Autowired
	SpCallService spCallService;
	
	@Autowired
	ETLSpService etlSpCallService;
	
	private String masterStoredProc;
	
	private String etlStoredProc;
	
	private String etlStoredProcSchema;
	
	private int inputParamsCount;
	
	protected static final Logger lOGGER = Logger.getLogger(GenerateJsonForReconReportTasklet.class);
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		try{
			lOGGER.info("Inside GenerateJsonForReconReportTasklet execute Method");
		String outputParam=spCallService.executeStoredProcedure(masterStoredProc);
		lOGGER.info("Inside GenerateJsonForReconReportTasklet , executed Master Stored Proc "+masterStoredProc+" SSIS JobName is : "+outputParam);
		if(outputParam!=null && !outputParam.isEmpty() && etlStoredProc!=null && etlStoredProcSchema!=null){
			lOGGER.info("Inside GenerateJsonForReconReportTasklet, Executing ETL Sp "+etlStoredProc);
			List<String> inputParams=new ArrayList<String>();
			inputParams.add(outputParam);
			String	status=etlSpCallService.executeStoredProcedure(etlStoredProcSchema,etlStoredProc,inputParamsCount,inputParams);
			lOGGER.info("Inside GenerateJsonForReconReportTasklet, Executed ETL Sp status is "+status);
		}
		lOGGER.info("Inside GenerateJsonForReconReportTasklet execute Method Ended");
		}catch(Exception e){
			lOGGER.error("Exeception in GenerateJsonForReconReportTasklet, Exception is "+e);
			throw e;
		}
		return RepeatStatus.FINISHED;
		
	}
	public String getMasterStoredProc() {
		return masterStoredProc;
	}
	public void setMasterStoredProc(String masterStoredProc) {
		this.masterStoredProc = masterStoredProc;
	}
	public String getEtlStoredProc() {
		return etlStoredProc;
	}
	public void setEtlStoredProc(String etlStoredProc) {
		this.etlStoredProc = etlStoredProc;
	}
	public String getEtlStoredProcSchema() {
		return etlStoredProcSchema;
	}
	public void setEtlStoredProcSchema(String etlStoredProcSchema) {
		this.etlStoredProcSchema = etlStoredProcSchema;
	}
	public int getInputParamsCount() {
		return inputParamsCount;
	}
	public void setInputParamsCount(int inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}
	
	
	
	
	
}
