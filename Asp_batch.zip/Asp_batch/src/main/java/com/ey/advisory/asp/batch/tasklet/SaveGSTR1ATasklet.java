package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.client.service.ClientSpCallService;

public class SaveGSTR1ATasklet implements Tasklet {
	
	@Autowired
	ClientSpCallService ClientSpCallService;
	
	private String storedProcName;
	private String storedProcSchema;
	private int inputParamsCount;
	private int outputParamsCount;
	//List that maintains the insertion Order
	private Map<String, String> inputParamMap;
	private String outputParam;
	private String outputParamListFlag;
	
	public String getOutputParamListFlag() {
		return outputParamListFlag;
	}


	public void setOutputParamListFlag(String outputParamListFlag) {
		this.outputParamListFlag = outputParamListFlag;
	}


	public String getOutputParam() {
		return outputParam;
	}


	public void setOutputParam(String outputParam) {
		this.outputParam = outputParam;
	}


	public Map<String, String> getInputParamMap() {
		return inputParamMap;
	}


	public void setInputParamMap(Map<String, String> inputParamMap) {
		this.inputParamMap = inputParamMap;
	}


	public String getStoredProcName() {
		return storedProcName;
	}


	public void setStoredProcName(String storedProcName) {
		this.storedProcName = storedProcName;
	}


	public String getStoredProcSchema() {
		return storedProcSchema;
	}


	public void setStoredProcSchema(String storedProcSchema) {
		this.storedProcSchema = storedProcSchema;
	}


	public int getInputParamsCount() {
		return inputParamsCount;
	}


	public void setInputParamsCount(int inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}


	public int getOutputParamsCount() {
		return outputParamsCount;
	}


	public void setOutputParamsCount(int outputParamsCount) {
		this.outputParamsCount = outputParamsCount;
	}


	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {

		//Trigger Stored procedure with one or many inputs and No output is expected
		if(inputParamsCount>0 && inputParamMap !=null && inputParamMap.size()>0 ){
			for (Map.Entry<String,String> entry : inputParamMap.entrySet()) {
				String key[] = entry.getKey().split("~");

				List<String> inputParams=new ArrayList<>();
				inputParams.add(key[0]);
				inputParams.add(key[1]);
				inputParams.add(entry.getValue());
				ClientSpCallService.executeStoredProcedure(storedProcSchema, storedProcName, String.valueOf(inputParamsCount), inputParams);
			}
		}
		return RepeatStatus.FINISHED;
	}

}
