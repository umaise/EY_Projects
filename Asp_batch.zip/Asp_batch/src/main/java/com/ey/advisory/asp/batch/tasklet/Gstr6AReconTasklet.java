package com.ey.advisory.asp.batch.tasklet;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.client.service.gstr2.Gstr2Service;
import com.ey.advisory.asp.client.service.gstr2.ReconStatusService;
import com.ey.advisory.asp.client.service.gstr6.GSTR6AService;
import com.ey.advisory.asp.client.service.gstr6.ReconStatusGstr6Service;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;
@Component
public class Gstr6AReconTasklet implements Tasklet{
	
	private static final Logger log = Logger.getLogger(Gstr6AReconTasklet.class);
	
	private String taxPeriod;
	
	private String gstin;
	
	private String group;
	
    private String masterId;
	
	private String resource;
	
	@Autowired
	BatchClientUtility batchClientUtility;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private Gstr2Service gstr2Service;
	
	@Autowired
	private GSTR6AService gstr6aService;
	
	@Autowired
	ReconStatusGstr6Service reconStatusGstr6Service;


	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	
	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}
	
	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}
	
	
	public String getMasterId() {
		return masterId;
	}

	public void setMasterId(String masterId) {
		this.masterId = masterId;
	}

	@SuppressWarnings("unchecked")
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext context) throws Exception {
		if(log.isInfoEnabled()){
			log.info(Constant.LOGGER_ENTERING + " Gstr6AReconTasklet " + Constant.LOGGER_METHOD + " execute");
		}
		try{
			HttpHeaders httpHeaders = null;
		    String spResponse = gstr6aService.executeRecon(gstin, taxPeriod,masterId);
		    log.info("Recon sp response for MasterId "+masterId+" Group is "+group+" Response is "+ spResponse);
			if(group!=null && gstin!=null && taxPeriod!=null){
				if(Constant.SUCCESS.equalsIgnoreCase(spResponse)){
			reconStatusGstr6Service.updateReconCompletionDate(gstin, taxPeriod, Integer.valueOf(masterId));
			log.info("Executing Recon report app call ");
			String path = env.getProperty("batch.restapi.host")+resource;
			log.info("Executing Recon report app call : path "+path);
			JSONObject jsonObject = new JSONObject();
			httpHeaders = new HttpHeaders();
	        httpHeaders.add(TenantConstant.REQUEST_TENANT_HEADER, group);
	        jsonObject.put("groupCode", group);
        	jsonObject.put("gstin", gstin);
        	jsonObject.put("taxPeriod", taxPeriod);
        	String result=batchClientUtility.executeRestCall(path,httpHeaders, jsonObject.toString(),HttpMethod.POST);
        	log.info("Rest call to generate Recon Report result "+ result);
			}else{
				log.info("Reconcilation has been failed in stored procedure "+spResponse);
				reconStatusGstr6Service.updateReconStatus(gstin, taxPeriod, Integer.valueOf(masterId), "RECON_FAILED");
			}
			}
		
		}catch (Exception e) {
			if (log.isDebugEnabled()){
				log.error("Exception  Gstr6AReconTasklet  Method : execute"+e);
			}
		}
		if (log.isDebugEnabled()){
			log.info("Exiting Gstr6AReconTasklet  Method : execute");
		}
		return RepeatStatus.FINISHED;
	}

}
