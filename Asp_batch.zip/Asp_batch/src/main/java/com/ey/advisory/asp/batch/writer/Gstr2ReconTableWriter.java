package com.ey.advisory.asp.batch.writer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.gstr2.Gstr2Service;
import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.asp.master.repository.IReturnPeriodRepository;

public class Gstr2ReconTableWriter implements ItemWriter<String> {

	protected static final Logger lOGGER = Logger.getLogger(Gstr2ReconTableWriter.class);

	private String storedProcName; 
	private String storedProcSchema;

	@Autowired
	private Gstr2Service gstr2Service;

	@Autowired
	ClientSpCallService clientSpCallService;

	@Autowired
	private IReturnPeriodRepository iReturnPeriodRepository;

	@Override
	public void write(List<? extends String> gstinList) throws Exception {

		lOGGER.info("Inside Gstr2ReconFileWriter:write method");
		try {
			
			ReturnPeriod returnPeriod = iReturnPeriodRepository.findByIsCurrentPeriod(true);
			Calendar cal = Calendar.getInstance();
			cal.setTime(returnPeriod.getStartDt());
			int month = cal.get(Calendar.MONTH) + 1;
			int year = cal.get(Calendar.YEAR);
			String monthTwoDigits = (month) < 10 ? Constant.ZERO + String.valueOf(month) : String.valueOf(month);
			String taxPeriod = monthTwoDigits + String.valueOf(year);
			
			lOGGER.info("taxPeriod "+taxPeriod);

			List<String> inputParamsList = new ArrayList<>();
			String inputParamCount = "";

			for (String gstin : gstinList) {

				TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus = gstr2Service.getGStrReturnFilingDetails(gstin,
						taxPeriod, "GSTR2A");
				if (tblGstinRetutnFilingStatus != null) {
					inputParamsList.add(gstin);
					inputParamsList.add(taxPeriod);
					inputParamCount = inputParamCount + inputParamsList.size();
					clientSpCallService.executeStoredProcedure(storedProcSchema, storedProcName, inputParamCount,
							inputParamsList);
				}

			}
		} catch (Exception ex) {
			lOGGER.error("Exception in Gstr2ReconFileWriter:write " + ex.getMessage());
			throw new Exception(ex);
		}
	}

	public String getStoredProcName() {
		return storedProcName;
	}

	public void setStoredProcName(String storedProcName) {
		this.storedProcName = storedProcName;
	}

	public String getStoredProcSchema() {
		return storedProcSchema;
	}

	public void setStoredProcSchema(String storedProcSchema) {
		this.storedProcSchema = storedProcSchema;
	}

}
