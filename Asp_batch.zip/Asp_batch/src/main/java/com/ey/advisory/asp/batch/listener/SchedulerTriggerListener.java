package com.ey.advisory.asp.batch.listener;

import org.apache.log4j.Logger;
import org.quartz.JobExecutionContext;
import org.quartz.Trigger;
import org.quartz.TriggerListener;

public class SchedulerTriggerListener implements TriggerListener {

	private static final String TRIGGER_LISTENER_NAME = "GlobalTriggerListener";
	private static final Logger LOGGER = Logger.getLogger(SchedulerTriggerListener.class);

	@Override
	public String getName() {
		return TRIGGER_LISTENER_NAME;
	}

	@Override
	public void triggerFired(Trigger trigger, JobExecutionContext context) {
		LOGGER.info("in triggerFired ");
	}

	@Override
	public boolean vetoJobExecution(Trigger trigger, JobExecutionContext context) {
		boolean veto = false;
		return veto;
	}

	@Override
	public void triggerMisfired(Trigger trigger) {
		LOGGER.info("in triggerMisfired ");

	}

	@Override
	public void triggerComplete(Trigger trigger, JobExecutionContext context,
			Trigger.CompletedExecutionInstruction triggerInstructionCode) {
		LOGGER.info("in triggerComplete ");

	}

}
