package com.ey.advisory.asp.batch.tasklet;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;
import java.util.Set;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.batch.redis.JedisConnectionUtil2;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.client.service.ClientFileUploadService;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;
import com.ey.advisory.asp.client.service.gstr2.Gstr2Service;
import com.ey.advisory.asp.client.service.gstr6.Gstr6Service;
import com.ey.advisory.asp.client.service.gstr7.Gstr7Service;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.master.service.SalesFileStatusService;

import org.apache.log4j.Logger;

@Component
public class TimeoutAndPersistRedisToDBTasklet implements Tasklet {

	@Autowired
	Gstr1Service gstr1Service;

	@Autowired
	Gstr2Service gstr2Service;

	@Autowired
	Gstr6Service gstr6Service;

	@Autowired
	Gstr7Service gstr7Service;

	@Autowired
	SalesFileStatusService salesService;

	@Autowired
	ClientFileUploadService clientFileUploadService;

	@Autowired
	private JedisConnectionUtil2 jedisConnectionUtil;

	private static final Logger lOGGER = Logger.getLogger(TimeoutAndPersistRedisToDBTasklet.class);
	private RedisTemplate<String, Object> redisTemplate = null;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		lOGGER.info("Starting TimeoutAndPersistRedisToDBTasklet.execute()...");
		long startTime = System.currentTimeMillis();
		try {

			String result = Constant.FAILED;
			redisTemplate = jedisConnectionUtil.getRedisTemplateKVStringObject();
			JobParameters jobparams = chunkContext.getStepContext().getStepExecution().getJobExecution()
					.getJobParameters();
			String fileListString = jobparams.getString("fileId");
			String[] listOfFiles = fileListString.split(Constant.SEPRATOR);

			for (int fileIndex = 0; fileIndex < listOfFiles.length; fileIndex++) {

				String fileKey = listOfFiles[fileIndex];

				if (fileKey != null) {
					String[] splitKey = fileKey.split("_");
					String GSTR = splitKey[0];

					lOGGER.info("GSTR : " + GSTR + " , fileKey : " + fileKey);
					if (GSTR.equalsIgnoreCase("gstr1")) {
						result = gstr1Service.saveTblTypeErrLstAndRoute(fileKey);
						if (!result.equalsIgnoreCase(Constant.FAILED)) {
							RedisTemplate<String, Integer> integerRedisTemplate = jedisConnectionUtil
									.getRedisTemplateKVStringInteger();
							RedisTemplate<String, String> stringRedisTemplate = jedisConnectionUtil
									.getRedisTemplateKVStringString();
							String invCountKey = fileKey + "_" + Constant.INVOICE_COUNT;
							String groupCodeKey = fileKey + "_" + Constant.GROUP_CODE;
							integerRedisTemplate.delete(invCountKey);
							stringRedisTemplate.delete(groupCodeKey);
						}
					} else if (GSTR.equalsIgnoreCase("gstr2")) {
						result = gstr2Service.saveTblTypeErrLstAndRoute(fileKey);
						if (!result.equalsIgnoreCase(Constant.FAILED)) {
							RedisTemplate<String, Integer> integerRedisTemplate = jedisConnectionUtil
									.getRedisTemplateKVStringInteger();
							RedisTemplate<String, String> stringRedisTemplate = jedisConnectionUtil
									.getRedisTemplateKVStringString();
							String invCountKey = fileKey + "_" + Constant.INVOICE_COUNT;
							String groupCodeKey = fileKey + "_" + Constant.GROUP_CODE;
							integerRedisTemplate.delete(invCountKey);
							stringRedisTemplate.delete(groupCodeKey);
						}
					} else if (GSTR.equalsIgnoreCase("gstr6")) {
						//result = timeoutSaveTblTypeErrLstAndRouteGSTR6(fileKey);
						result = gstr6Service.saveTblTypeErrLstAndRoute(fileKey);
						if(!result.equalsIgnoreCase(Constant.FAILED)){
							RedisTemplate<String,Integer> integerRedisTemplate=jedisConnectionUtil.getRedisTemplateKVStringInteger();
							RedisTemplate<String,String> stringRedisTemplate=jedisConnectionUtil.getRedisTemplateKVStringString();
							String invCountKey = fileKey + "_" + Constant.INVOICE_COUNT;
							String groupCodeKey = fileKey + "_" + Constant.GROUP_CODE;
							integerRedisTemplate.delete(invCountKey);
							stringRedisTemplate.delete(groupCodeKey);
						}	
					} else if (GSTR.equalsIgnoreCase("gstr7")) {
						result = timeoutSaveTblTypeErrLstAndRouteGSTR7(fileKey);
					}
				}
				lOGGER.info("Partial update result for fileKey : " + fileKey + " is : " + result);
			}

		} catch (Exception e) {
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			lOGGER.error("TimeoutAndPersistRedisToDBTasklet ERROR : " + errors.toString());
		} finally {
			long endTime = System.currentTimeMillis();
			long totalTime = (endTime - startTime) / 1000;
			lOGGER.info("Time taken PollRedisAndTriggerTasklet.execute() : " + totalTime + " in Seconds");
		}

		return RepeatStatus.FINISHED;
	}


	private String timeoutSaveTblTypeErrLstAndRouteGSTR7(String fileKey) throws Exception {

		boolean invoiceResult = false;
		boolean errorInfoResult = false;
		String result = Constant.FAILED;

		String[] split = fileKey.split("_");
		Integer fileId = Integer.parseInt(split[1]);

		String invStatusKey = fileKey + "_" + Constant.INVOICE_STATUS;
		String invErrKey = fileKey + "_" + Constant.INVOICE_ERROR_DETAILS;
		Set<InvoiceProcessDto> invoiceList = (Set<InvoiceProcessDto>) redisTemplate.opsForHash().get(fileKey,
				invStatusKey);
		Set<TblTdsErrorInfo> errorInfoList = (Set<TblTdsErrorInfo>) redisTemplate.opsForHash().get(fileKey, invErrKey);

		if (invoiceList != null && !invoiceList.isEmpty()) {
			invoiceResult = gstr7Service.saveGstr7InvoiceStatus(invoiceList, fileId);
		}

		if (errorInfoList != null && !errorInfoList.isEmpty()) {
			errorInfoResult = gstr7Service.saveTdsErrorInfo(errorInfoList);
		}
		salesService.updateFilejobStatus(fileKey);
		gstr7Service.timeoutAndMarkInvoiceStatusTechError(fileId); // @m
		if (invoiceResult && errorInfoResult) {
			result = "Success";
		}
		redisTemplate.delete(fileKey);
		redisTemplate.opsForHash().delete(fileKey, invStatusKey);
		redisTemplate.opsForHash().delete(fileKey, invErrKey);
		return result;
	}

/*	private void deleteLatestUpdatedTimeForFile(String key) {
		String TIMEOUT_ROOT = "ASP_TIMEOUT";
		String TIMEOUT_ROOT_KEY = "ASP_TIMEOUT_KEY";
		String updateLatestDTMKey = key + "_" + Constant.INVOICE_UPDATE_TS;
		String previousInvProcessedKey = key + "_" + Constant.PREV_INVOICE_PSD_COUNT;

		redisTemplate.delete(previousInvProcessedKey);

		// Poll Redis for the timeout and InvCount !=1
		Map<String, Long> trackerMap = (Map<String, Long>) redisTemplate.opsForHash().get(TIMEOUT_ROOT,
				TIMEOUT_ROOT_KEY);
		trackerMap.remove(updateLatestDTMKey);
		redisTemplate.opsForHash().put(TIMEOUT_ROOT, TIMEOUT_ROOT_KEY, trackerMap);
		lOGGER.info("deleteLatestUpdatedTimeForFile : Deleting TIMESTAMP key : " + updateLatestDTMKey);
	}*/

}
