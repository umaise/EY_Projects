package com.ey.advisory.asp.quartz.listener;

import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;

import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.AutowireSpringBeanHelper;
import com.ey.advisory.asp.master.domain.CustomerJobDetails;
import com.ey.advisory.asp.quartz.dynamicScheduler.ClientManagedDynamicScheduler;

public class DynamicSchedulerListener {


    private ClientManagedDynamicScheduler clientManagedDynamicScheduler;

    @Autowired
    public void setDynamicScheduler(ClientManagedDynamicScheduler clientManagedDynamicScheduler) {
        this.clientManagedDynamicScheduler = clientManagedDynamicScheduler;
    }

    @PostPersist
    @PostUpdate
    public void scheduleCustomerJob(CustomerJobDetails customerJobDetails) {
        AutowireSpringBeanHelper.autowire(this, this.clientManagedDynamicScheduler);
        clientManagedDynamicScheduler.scheduleJob(customerJobDetails);
    }

    @PostRemove
    public void removeCustomerJob(CustomerJobDetails customerJobDetails) {
        AutowireSpringBeanHelper.autowire(this, this.clientManagedDynamicScheduler);
        clientManagedDynamicScheduler.deleteJob(customerJobDetails);
    }



}
