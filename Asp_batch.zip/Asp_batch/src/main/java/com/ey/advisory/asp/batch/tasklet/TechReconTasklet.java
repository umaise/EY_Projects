package com.ey.advisory.asp.batch.tasklet;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import com.ey.advisory.asp.client.domain.InvoiceKeyDetail;
import com.ey.advisory.asp.client.dto.TechReconDTO;
import com.ey.advisory.asp.client.service.GSTINDetailsService;

public class TechReconTasklet implements Tasklet {

	protected static final Logger LOGGER = Logger.getLogger(TechReconTasklet.class);

	@Autowired
	GSTINDetailsService gstinDetailsService;

	List<InvoiceKeyDetail> invoiceKeyDetailList;
	List<TechReconDTO> finalTechReconList;
	
	String groupCode,jobNameGroupCode;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
   try{
		LOGGER.info("Inside TechReconTasklet execute method");
		ExecutionContext stepExecution = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getExecutionContext();
	    jobNameGroupCode = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters().getString("JOB_NAME");		
		if (jobNameGroupCode != null) {
			int index = jobNameGroupCode.indexOf("_");
		    groupCode=jobNameGroupCode.substring(index+1);
		    LOGGER.info("GroupCode fetched = " + groupCode);
		}else{
			LOGGER.info("GroupCode coundnot be fetched as jobNameGroupCode is null" );
		}
		
		finalTechReconList=gstinDetailsService.getTechReconDTOList();
		
		if (!(null == finalTechReconList && finalTechReconList.isEmpty())) {
			stepExecution.put("TrnxIDCount", finalTechReconList.size());			
		}else{
				LOGGER.info("finalTechReconList is null or empty");
		}
		String param=groupCode;
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("groupCode",param);			
   }
   catch(Exception e){
	   LOGGER.error("Error has occured inside TechReconTasklet "+e.getStackTrace());
   }
		return RepeatStatus.FINISHED;
	}
	
}
