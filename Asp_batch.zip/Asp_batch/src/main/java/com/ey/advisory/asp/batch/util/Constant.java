package com.ey.advisory.asp.batch.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Constant {
    public static final String APPLICATION_CONTEXT_KEY = "applicationContext";

    public static final String JOB_RUN_DATE = "jobRunDate";
    public static final String FILE_PATH = "/opt/fileshare/Gstn_Error_Report/";
    public static final String GSTR1_GSTN_REPORT_JOB_NAME = "generateGstr1GstnReportExcel";
    public static final String GSTR2_GSTN_REPORT_JOB_NAME = "generateGstr2GstnReportExcel";
    public static final String RECON_REPORT_JOB_NAME = "generateGstr2ReconcilationReportExcel";
    public static final String MISSING = "MISSING";
    public static final String ADDITIONAL = "ADDITIONAL";
    public static final String MIS_MATCH = "MIS-MATCH";
    public static final String RECON_INFO_MASTER = "RECON INFO MASTER";
    public static final String RECON_HEADERS = "Supplier / Issuer GSTIN, Document Type, Document Number, Document Date,"
        + " Original Document Number, Original Document Date,Place of Supply (POS), Reverse Charge?,Line No, HSN/SAC, "
        + "IGST Rate, IGST Amount, CGST Rate, CGST Amount, SGST Rate, SGST Amount, Cess Rate, Cess Amount ";
    public static final String RECON_INFO = "RECON_INFO";
    public static final String RECON_INFO_HEADERS = "Recon Information Code, Recon Information Description";
    public static final String RECON_FILE_PATH = "/opt/fileshare/Gstn_Error_Report/"; 
    public static final String DOCUMENT_TYPE = "INV";
    public static final String B2BA_DOCUMENT_TYPE = "RNV";
    public static final String MIS_MATCH_HEADERS = "Supplier / Issuer GSTIN, Document Type, Document Number, Document Date,"
        + " Place of Supply (POS), Reverse Charge? ";
    public static final String MIS_MATCH_HEADERS_1 = "Original Document Number, Original Document Date,Line No, HSN/SAC, "
        + "IGST Rate, IGST Amount, CGST Rate, CGST Amount, SGST Rate, SGST Amount, Cess Rate, Cess Amount ";    
    public static final String MISSED_IN_2A = "MIS";
    public static final String ADDITIONAL_RECORDS = "ADD";
    public static final String MSMATCH_IN_2A="2AM";
    public static final String PURCHASE_REGISTER_MISMATCH="PRM";
    public static final String MISSED_HEADER_VALUE="MISSING TRANSACTIONS: Transactions that are there in Purchase Register but are not there in auto-drafted GSTR-2";
    public static final String ADDITIONAL_HEADER_VALUE="ADDITIONAL TRANSACTIONS: Transactions that are there in auto-drafted GSTR-2 but are not there in Purchase Register";
    public static final String MISMATCH_HEADER_VALUE_2A="AS PER GSTR-2A";
    public static final String MISMATCH_HEADER_VALUE_PURCHASE_REGISTER="As Per Purchase Register";
    public static final String[] CONSOLIDATED_HEADERS = { "Transaction Details", "Error/Information Details"};
    public static final String[] ERROR_LIST_HEADERS = { "Error Code", "Incident Level", "Return Impacted", "Error Description"};
    public static final String[] INFORMATION_LIST_HEADERS = {"Information Code", "Incident Level", "Return Impacted", "Information Description"};
    public static final String[] ERROR_DETAIL_HEADERS = { "Supplier / Issuer GSTIN","Customer GSTIN / Unit GSTIN / UIN","Customer Name","Document Type","Document Number","Document Date","Line No","HSN/SAC","Original Document Number","Original Document Date","Error Incidence Level","Applicable Error Codes","Applicable Information Codes"};
    public static final String OUTWARD="Outward";
    public static final String INWARD="Inward";
    public static final String GSTR1="GSTR1";
    public static final String GSTR2="GSTR2";
    public static final String GSTR6="GSTR6";
    public static final String GSTR2A="GSTR2RECON";
    public static final String RESPONSE="RESPONSE";
    public static final String RESPONSE_HEADER="Recon Information Code, Auto-generated Response, Your Response";
    public static final String RECON_INFORMATION_CODE="Recon Information Code";
    public static final String RECON_INFORMATION_DESCRIPTION="Recon Information Description";
  
    public static final String EMAIL_SUBJECT = "Error Report related to processType return : Generated on : "+new SimpleDateFormat("dd/MM/yyyy").format(new Date());
    
    public static final String RECON_EMAIL_SUBJECT="Reconciliation Report related to GSTR2A and Purchase register: Generated on :"+new SimpleDateFormat("dd/MM/yyyy").format(new Date());
    
    public static final String INV_MAPPING_READY_EMAIL_TEMPLATE = "InvoiceMappingReadyEmailTemplate.vm";

	public static final String DET_SHEET_READY_EMAIL_SUBJECT = "Download Determination sheet related to GSTR6 return : Generated on : "+ new SimpleDateFormat("dd/MM/yyyy").format(new Date());
	
	public static final String INV_MAPPING_READY_EMAIL_SUBJECT = "Return GSTR 6:  Invoice Mapping sheet is available for download - Generated on : "+ new SimpleDateFormat("dd/MM/yyyy").format(new Date());
	
	public static final String INV_MAPPING_READY_EMAIL_CC = "namratha2.n@in.ey.com";
	
	public static final String GSTR6INV_MAPPING_READY = "GSTR6INV";
    public static final String EMAIL_FROM = "Manoj.Tripathy@in.ey.com";
	
	public static final String EMAIL_CC = "Sai.Pakanati@in.ey.com";
	
	public static final String EMAIL_BCC = "Sai.Pakanati@in.ey.com";
	
	public static final String TRY_AGAIN_STATUS ="Jobs are still running at saturated level.Please try after some time";
	
	public static final String SUCCESS ="Success";
	
	public static final String FAILED ="Failed";
	
	public static final String UPDATE_ROUTING_JOB_STATUS_TO = "P";
	
	public static final String FILED = "FILED";
	
	public static final String ZERO ="0";
	
	public static final int LEFT_ALIGN = -1;
	
	public static final int RIGHT_ALIGN = 1;
	
	public static final int CENTER_ALIGN = 0;
	
	public static final String B2B_INVOICE="Table 4: B2B";

	public static final String B2BA_INVOICE="Table 4A: B2BA";
	
	public static final String CDN_DETAIL="Table 7: CDN";
    
    public static final String CDNA_DETAIL="Table 7A: CDNA";
	
	public static final String INVOICE_INCIDENCE_LEVEL ="Invoice";
	
	public static final String LINE_ITEM_INCIDENCE_LEVEL ="Line-Item";
	
	public static final String CDN_DOCUMENT_TYPE = "CDN";
	
	public static final String CDNA_DOCUMENT_TYPE = "CDNA";
	
	public static final String PENDING = "PENDING";
	
	public static final String ACCEPT = "ACCEPT";
	
	public static final String REJECT = "REJECT";
	
	public static final String MODIFY = "MODIFY";
	
	public static final String CLAIM = "CLAIM";
	
	public static final String DO_NOT_CLAIM = "DON\'T CLAIM";
    
	
    public static final String MISSING_COMMENT = "For tables 4, 4A, 7, 7A \n DON'T CLAIM: Don't insert the document as part of \n final GSTR-2."
        + "This document then should be \n part of matching in next tax period.\n"
        + "CLAIM: Insert the document as part of final GSTR-2; \n Flag to be used is N.\n";
    
    public static final String ADDITIONAL_COMMENT = "For tables 4, 4A, 7, 7A \n ACCEPT: Accept the auto-drafted document; flag to be used against"
        +" the document in GSTR-2 is A \n REJECT: Reject the auto-drafted document; flag to be used aginst the document in GSTR-2 is R \n" 
        +" PENDING: Keep the document pending; flag to be used against the document in GSTR-2 is P";
   
    public static final String MISMATCH_COMMENT = "For tables 4, 7 \n ACCEPT:Accept the auto-drafted document; flag to be used against the document in "
        + "GSTR-2 is A \n MODIFY: Modify the auto-drafted document by updating Taxable Value, Tax Rate and Tax Amount from Purchase Register; flag to "
        + "be used aginst the document in GSTR-2 is M \n PENDING: Keep the auto-drafted document pending; flag to be used against the document in "
        + "GSTR-2 is P \n For tables 4A, 7A \n ACCEPT: Accept the auto-drafted document; flag to be used against the document in GSTR-2 is A \n "
        + "REJECT: Reject the auto-drafted document; flag to be used against the document in GSTR-2 is R \n PENDING: Keep the auto-drafted document pending; flag to be used against the document in GSTR-2 is P";
       
    public static final String RET_FILING_STATUS_SUBMITTED = "SUBMITTED";
    
    public static final boolean ONE = true;
    public static final String GSTR1_TRANSACTIONAL_SAVE_JOB_NAME ="savetransactionalGSTR1Gstn";
    public static final String GSTR1_Tenant_SAVE_JOB_NAME = "savetransactionalGSTR1GstnJob";
    public static final String GSTR1_SUMMARY_SAVE_JOB_NAME ="saveSummaryGSTR1GstnJob";
    public static final String SUMMARY_TRNX_ID_POLLING_JOB="summaryTransactionIDPollingJob";
    public static final String SAVE_TRNX_ID_POLLING_JOB="transactionIDPollingJob";
    public static final String SUBMIT_TRNX_ID_POLLING_JOB="transactionIDPollingSubmitJob";
    public static final String SAVE_GSTR1_DATA_JOB="saveGSTR1DataJob";
    
    public static final String GSTR2_TRANSACTIONAL_SAVE_JOB_NAME ="savetransactionalGSTR2Gstn";
    public static final String GSTR2_Tenant_SAVE_JOB_NAME = "savetransactionalGSTR2GstnJob";
    
    public static final String SUMMARYFILESTATUS = "PSD";
    public static final String SUMMARYFILEUPDATESTATUS="SIP";
    
    public static final String INPROGRESS = "INP";
    public static final String NEW = "NEW";
    public static final String COMPLETED = "CTD";
    public static final String GSTR1OS="GSTR1OS";
    public static final String GSTR2IS="GSTR2IS";
    public static final String EXIT_STATUS="EXIT";
    
    public static final String DAILY="D";
    public static final String WEEKLY="W";
    public static final String FORTNIGHTLY="F";
    public static final String MONTHLY="M";
    
    public static final String CUSTOMER_SPECIFIC_ITERATIVE_JOB="runCustomerSpecificIterativeJob";
    public static final String MASTER= "master";
    
    public static final String CREATE_RETURN_FILING_DETAILS_JOB="createClientReturnFilingDetailsJob";
    
    public static final String REDIS_HOST = "redis.host";
    public static final String REDIS_PORT = "redis.port";
    public static final String REDIS_POOL_MAX_ACTIVE="redis.pool.maxActive";
    public static final String REDIS_POOL_MAX_IDLE="redis.pool.maxIdle";
    public static final String REDIS_POOL_MAX_WAIT="redis.pool.maxWait";
    public static final String REDIS_POOL_TEST_ON_BORROW="redis.pool.testOnBorrow";
    public static final String REDIS_TIME_OUT="redis.pool.timeout";
    public static final String REDIS_PASSWORD="redis.pool.timeout";
    public static final String INVOICE_COUNT = "InvCount";
    public static final String GROUP_CODE = "GroupCode";
    public static final String INVOICE_UPDATE_TS = "LatestDTM"; 
    public static final String INVOICE_PSD_COUNT = "InvPsdCount";
    public static final String PREV_INVOICE_PSD_COUNT = "PreviousInvPsdCount";
    public static final String TENANT_JOB_CREAYED_FLAG = "TenantJobCreated";
	public static final String TIMED_OUT_RETRY_CNT = "TimedOutRetryCnt";
    
	public static final String INVOICE_STATUS="InvStatus";
	public static final String INVOICE_ERROR_DETAILS="InvError";
	public static final String Yes="Yes";
	public static final String No="No";
	public static final String  REQUEST_TENANT_HEADER ="X-TENANT-ID";
	public static final String GROUP_CODE_KEY="groupCode";
	public static final String JOB_NAME_KEY="jobName";
	public static final String TIME_INTERVAL_KEY="timeInterval";
	public static final String REPEAT_COUNT_KEY="repeatCount";
	public static final String PRIORITY_KEY="priority";
	public static final String PARAMS_KEY="params";
	public static final String GET_GSTR2A_FILE_DETAILS_TOKEN_JOB="getGstr2aFileDetailsFromGstnJob";
	public static final String GET_GSTR1FF_FILE_DETAILS_TOKEN_JOB="getGstr1ffFileDetailsFromGstnJob";
	public static final String GET_GSTR6A_FILE_DETAILS_TOKEN_JOB="getGstr6aFileDetailsFromGstnJob";
	
	public static final String SEPRATOR=";";
	public static final String RECON_INPROGRESS="Other recon is still in progress at saturated level.Please try after some time";
	public static final String NO_RECON_PENDING="No recon process is pending";
	public static final String GSTR2_RECON="GSTR2RECON";
	public static final String RECON_JOB_NAME="reconciliationProcessGstr2Job";
	public static final String GENERATE_SMART_REPORTS_JOB="createSmartReportForEachGroupJob";

}
