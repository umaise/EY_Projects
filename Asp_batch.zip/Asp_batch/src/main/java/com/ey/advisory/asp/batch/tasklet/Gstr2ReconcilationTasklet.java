package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblFileUploadStatus;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.TblFileUploadStatusService;
import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;
import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.asp.master.repository.FileUploadStatusRepository;
import com.ey.advisory.asp.master.repository.IReturnPeriodRepository;

public class Gstr2ReconcilationTasklet implements Tasklet {

	protected static final Logger LOGGER = Logger.getLogger(Gstr2ReconcilationTasklet.class);
	List<FileUploadStatusMaster> processFileList;
	
	private String jobStatus;
	private String fileData;
	private String isProcessed;
	private String storedProcName;
	private String storedProcSchema;
	private String inputParamsCount;
	private String updateJobStatusTo;
	private String updateIsProcessedTo;
	
	String taxPeriod;
	
	@Autowired
	private FileUploadStatusRepository tblSalesFileStatusRepo;
	
	@Autowired
	ClientSpCallService clientSpCallService;
	@Autowired
	TblFileUploadStatusService tblFileUploadStatusService;
	@Autowired 
	private IReturnPeriodRepository iReturnPeriodRepository;
	
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("Inside execute mehtod of Gstr2ReconcilationTasklet");
		ExecutionContext executionContext=chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();
		processFileList = tblSalesFileStatusRepo.findByIsStageProcessedAndJobStatusAndFileData(isProcessed, jobStatus,fileData);
		List<String> paramList;
		String status=null;
		List<String> gstinList=new ArrayList<>();
		try{
		for(FileUploadStatusMaster processFile: processFileList){
			paramList = new ArrayList<>();
			List<TblFileUploadStatus> fileUploadStatusList= tblFileUploadStatusService.getFileUploadStatusDetails(String.valueOf(processFile.getFileId()));
			
			ReturnPeriod returnPeriod= iReturnPeriodRepository.findByIsCurrentPeriod(true);
			Calendar cal = Calendar.getInstance();
			cal.setTime(returnPeriod.getStartDt());
			int month = cal.get(Calendar.MONTH)+1;
			int year = cal.get(Calendar.YEAR);
			String monthTwoDigits=(month)<10 ? Constant.ZERO+String.valueOf(month): String.valueOf(month);
			taxPeriod= monthTwoDigits + String.valueOf(year);
			
			if(null != fileUploadStatusList  && !fileUploadStatusList.isEmpty()){
				gstinList.add(String.valueOf(fileUploadStatusList.get(0)));
				paramList.add(String.valueOf(fileUploadStatusList.get(0)));
				paramList.add(taxPeriod);
				status=clientSpCallService.executeStoredProcedure(storedProcSchema, storedProcName, inputParamsCount, paramList);
			}
		}}catch(Exception e){
			LOGGER.error("Error in GSTR2GeconcilationTasklet execute method.");
			status="Failed";
		}
		executionContext.put("reconProcessStatus", status);
		executionContext.put("gstinList", gstinList);
		executionContext.put("taxPeriod", taxPeriod);
		LOGGER.info("Inside execute mehtod of Gstr2ReconcilationTasklet finished");
		return RepeatStatus.FINISHED;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getFileData() {
		return fileData;
	}

	public void setFileData(String fileData) {
		this.fileData = fileData;
	}

	public String getIsProcessed() {
		return isProcessed;
	}

	public void setIsProcessed(String isProcessed) {
		this.isProcessed = isProcessed;
	}

	public String getStoredProcName() {
		return storedProcName;
	}

	public void setStoredProcName(String storedProcName) {
		this.storedProcName = storedProcName;
	}

	public String getStoredProcSchema() {
		return storedProcSchema;
	}

	public void setStoredProcSchema(String storedProcSchema) {
		this.storedProcSchema = storedProcSchema;
	}

	public String getInputParamsCount() {
		return inputParamsCount;
	}

	public void setInputParamsCount(String inputParamsCount) {
		this.inputParamsCount = inputParamsCount;
	}

	public String getUpdateJobStatusTo() {
		return updateJobStatusTo;
	}

	public void setUpdateJobStatusTo(String updateJobStatusTo) {
		this.updateJobStatusTo = updateJobStatusTo;
	}

	public String getUpdateIsProcessedTo() {
		return updateIsProcessedTo;
	}

	public void setUpdateIsProcessedTo(String updateIsProcessedTo) {
		this.updateIsProcessedTo = updateIsProcessedTo;
	}

}
