package com.ey.advisory.asp.batch.tasklet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPOutputStream;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblGSTINList;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.TblGstinListService;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;



/**
 * @author Smruti.Pradhan
 *	This tasklet is to interfaceFile to GSTN
 */
public class FileInterfaceToGstnTasklet implements Tasklet{
	protected static final Logger LOGGER = Logger.getLogger(FileInterfaceToGstnTasklet.class);
	private static final String CLASS_NAME = FileInterfaceToGstnTasklet.class.getName();

	@Autowired
	TblGstinListService tblGstinListService;
	
	@Autowired
	ClientSpCallService clientSpCallService;
	@Autowired
	Gstr1Service gstr1Service;
	@Autowired
	private Environment env;

	@Autowired
	private BatchClientUtility batchClientUtility;
	

	
	boolean status = true;
	@AfterStep
	public void afterStep(StepExecution stepExecution) throws IOException {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in afterStep ");
			}
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("Inside FileInterfaceToGstnTasklet execute method");

		HttpHeaders httpHeaders = new HttpHeaders();
		org.json.simple.JSONObject json;
        json = new org.json.simple.JSONObject();
		String gstin=null;
		String taxPeriod=null;
		String UserEmailId = "";
		
		try {
		httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		String path = env.getProperty("batch.restapi.host"); 
		ExecutionContext executionContext = chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();
		
		if(null!=executionContext.get("gstin") && null!=executionContext.get("taxPeriod")){
		 gstin = (String) executionContext.get("gstin");
		 taxPeriod = (String) executionContext.get("taxPeriod");
		 UserEmailId = (String) executionContext.get("userEmailId");
		}
		
		String jobNameGroupCode = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters()
				.getString("JOB_NAME");
		String groupCode=null;
		if (jobNameGroupCode != null) {
			String[] param = jobNameGroupCode.split("_");
			if (param.length == 2) {
				executionContext.put("groupCode", param[1]);
				groupCode=param[1];
				httpHeaders.add(Constant.REQUEST_TENANT_HEADER, groupCode);
			}
		}
		String jobName = (String) executionContext.get("jobName");
		
		json.put("gstin", gstin);
		json.put("taxPeriod", taxPeriod);
		json.put("jobName", jobName);
		json.put("userEmailId", UserEmailId);
		
		String resource = path + "gstr1/saveGstr";
		String status = batchClientUtility.executeRestCall(resource,
				httpHeaders, json.toJSONString(), HttpMethod.POST);
		if(!"Success".equalsIgnoreCase(status)){
			throw new Exception("Received failure from app_server");
		}
		
		}catch (Exception ex) {
			LOGGER.error("Exception in FileInterfaceToGstnTasklet execute method");
			throw new Exception("Exception in FileInterfaceToGstnTasklet execute method: "+ex.getMessage());
		}
		return RepeatStatus.FINISHED;
	}

}
