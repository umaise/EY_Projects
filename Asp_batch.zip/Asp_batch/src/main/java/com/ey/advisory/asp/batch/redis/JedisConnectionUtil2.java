package com.ey.advisory.asp.batch.redis;


import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.ey.advisory.asp.batch.tasklet.PollRedisAndTriggerTasklet;

import redis.clients.jedis.JedisPoolConfig;


public class JedisConnectionUtil2 {
	
	private static final Logger lOGGER = Logger.getLogger(JedisConnectionUtil2.class);
	
	 private String password;
	 private String hostname;
	 private int poolMaxActive;
	 private int poolMaxIdle;
	 private int poolMaxWait;
	 private boolean testOnBorrow;
	 private int timeOut;	
	 private int port;
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public int getPoolMaxActive() {
		return poolMaxActive;
	}

	public void setPoolMaxActive(int poolMaxActive) {
		this.poolMaxActive = poolMaxActive;
	}

	public int getPoolMaxIdle() {
		return poolMaxIdle;
	}

	public void setPoolMaxIdle(int poolMaxIdle) {
		this.poolMaxIdle = poolMaxIdle;
	}

	public int getPoolMaxWait() {
		return poolMaxWait;
	}

	public void setPoolMaxWait(int poolMaxWait) {
		this.poolMaxWait = poolMaxWait;
	}

	public boolean isTestOnBorrow() {
		return testOnBorrow;
	}

	public void setTestOnBorrow(boolean testOnBorrow) {
		this.testOnBorrow = testOnBorrow;
	}

	public int getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(int timeOut) {
		this.timeOut = timeOut;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
	private JedisConnectionFactory jedisConnectionFactory;
	
	public JedisConnectionUtil2(){
		lOGGER.info("Initializing JedisConnectionUtil2 ...");
	}
	
	public void initIt(){	

		lOGGER.info("Initializing JEDIS CONNECTION FACTORY initIt() called...");
		JedisPoolConfig jedisPoolConfig;		
		try {	
		/*	String hostname = "localhost";
			int port = 6379;
			int poolMaxActive= 100;
			int poolMaxIdle= 10;
			long poolMaxWait=10000;
			boolean testOnBorrow=true;
			int timeOut=5000;
			String password="";		*/
			
			jedisPoolConfig=new JedisPoolConfig();
			jedisPoolConfig.setMaxTotal(poolMaxActive);
			jedisPoolConfig.setMaxIdle(poolMaxIdle);
			jedisPoolConfig.setMaxWaitMillis(poolMaxWait);
			jedisPoolConfig.setTestOnBorrow(testOnBorrow);
			
			jedisConnectionFactory=new JedisConnectionFactory();
			jedisConnectionFactory.setHostName(hostname);
			jedisConnectionFactory.setPort(port);
			jedisConnectionFactory.setPoolConfig(jedisPoolConfig);
			jedisConnectionFactory.setTimeout(timeOut);
			jedisConnectionFactory.setPassword(password);			
			jedisConnectionFactory.afterPropertiesSet();
				
			if(lOGGER.isInfoEnabled()){
				lOGGER.info("Connecting Redis HOST : "+hostname);
				lOGGER.info("Redis PORT : "+port);
			}
		} catch (Exception ex) {
			StringWriter errors = new StringWriter();
			ex.printStackTrace(new PrintWriter(errors));
			lOGGER.error("JedisConnectionUtil2 ERROR : " + errors.toString());
		}		
	}


		
	public RedisTemplate<String,String> getRedisTemplateKVStringString(){
		  RedisTemplate<String,String> redisTemplateWithStringSer = null;
		  redisTemplateWithStringSer = new RedisTemplate<String,String>();
		  redisTemplateWithStringSer.setKeySerializer(new StringRedisSerializer());
		  redisTemplateWithStringSer.setValueSerializer(new StringRedisSerializer());
		  redisTemplateWithStringSer.setConnectionFactory(jedisConnectionFactory);		
		  redisTemplateWithStringSer.afterPropertiesSet();
		return redisTemplateWithStringSer;
	}
	public RedisTemplate<String,Integer> getRedisTemplateKVStringInteger(){
		  RedisTemplate<String,Integer> redisTemplateWithIntegergSer = null;
		  redisTemplateWithIntegergSer = new RedisTemplate<String,Integer>();
		  redisTemplateWithIntegergSer.setKeySerializer(new StringRedisSerializer());
		  redisTemplateWithIntegergSer.setValueSerializer(new GenericToStringSerializer<Integer>(Integer.class));
		  redisTemplateWithIntegergSer.setConnectionFactory(jedisConnectionFactory);
		  redisTemplateWithIntegergSer.afterPropertiesSet();
		return redisTemplateWithIntegergSer;
	}
	public RedisTemplate<String, Object> getRedisTemplateKVStringObject(){
		  RedisTemplate<String, Object> redisTemplateWithDefaultSer = null;
		  redisTemplateWithDefaultSer = new RedisTemplate<String,Object>();
		  //redisTemplateWithDefaultSer.setKeySerializer(new JdkSerializationRedisSerializer());
		  redisTemplateWithDefaultSer.setKeySerializer(new JdkSerializationRedisSerializer());
		  redisTemplateWithDefaultSer.setValueSerializer(new JdkSerializationRedisSerializer());
		  redisTemplateWithDefaultSer.setConnectionFactory(jedisConnectionFactory);
		  redisTemplateWithDefaultSer.afterPropertiesSet();
		return redisTemplateWithDefaultSer;
	}
	

	
	
}