package com.ey.advisory.asp.batch.tasklet;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepSynchronizationManager;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.dto.Gstr3Dto;
import com.ey.advisory.asp.client.service.TblGstinRetutnFilingStatusService;
import com.ey.advisory.asp.client.service.gstr3.Gstr3Service;
import com.ey.advisory.asp.client.util.AuthenticationUtility;
import com.ey.advisory.asp.common.Constant;

@Component
public class GetLiabCashITCDetailsSummaryTasklet implements Tasklet {

	protected static final Logger LOGGER = Logger.getLogger(GetLiabCashITCDetailsSummaryTasklet.class);
	@Autowired
	Gstr3Service  gstr3Service;
	@Autowired
	TblGstinRetutnFilingStatusService tblGstinRetutnFilingStatusService;
	@Autowired
	BatchClientUtility batchClientUtility;
	@Autowired
	private Environment env;
	@Autowired
	AuthenticationUtility authenticationUtility;
	List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatusList;
	private String result="";
	private JSONObject jsonObject;
	JSONParser jsonParser = new JSONParser();
	HttpHeaders httpHeaders = new HttpHeaders();
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		if(LOGGER.isInfoEnabled())
		LOGGER.info("Inside execute mehtod of GetLiabCashITCDetailsSummaryTasklet");
		try
		{
			StepExecution stepExecution = StepSynchronizationManager.getContext().getStepExecution();
			gstinRetutnFilingStatusList = tblGstinRetutnFilingStatusService.loadDataFromTblGSTinReturnFillingStatus();
			if(gstinRetutnFilingStatusList.isEmpty())
			{
				stepExecution.setExitStatus(ExitStatus.NOOP);
				if(LOGGER.isInfoEnabled())
				LOGGER.info("Data is not there");
			}
			else
			{
		 for (TblGstinRetutnFilingStatus gstnRnStatus : gstinRetutnFilingStatusList) {
			    getLiabilityFromStubandSaveintoLiabilityDb(gstnRnStatus,stepExecution);
				
		 }
			}
		}catch(Exception Ex)
		{
			LOGGER.error("Failed due to Reason"+Ex.getMessage());
		}
		
		return RepeatStatus.FINISHED;
	}
	
	private void getLiabilityFromStubandSaveintoLiabilityDb(TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus,StepExecution stepExecution)
	{
		try {
			StringBuilder uri = new StringBuilder(
					"?action=" + Constant.TAX + "&gstin=" + tblGstinRetutnFilingStatus.getId().getGstinId() + "&rt_period=" + tblGstinRetutnFilingStatus.getId().getReturnType() + "&liab_typ=" + "O");
			String resource = env.getProperty("restapi.host-stub") + env.getProperty("restapi.ledger")
					+ uri.toString();
			result = batchClientUtility.executeRestCall(resource, httpHeaders, HttpMethod.GET);
			jsonObject = (JSONObject) jsonParser.parse(result);
			if(LOGGER.isInfoEnabled())
			LOGGER.info("Before Starting stubs" + jsonObject);
			if (jsonObject.containsKey(Constant.REK) && jsonObject.containsKey(Constant.DATA)
					&& jsonObject.containsKey(Constant.STATUS_CD)) {
				LOGGER.error("Starting stubs");
				String rek = (String) jsonObject.get(Constant.REK);
				String data = (String) jsonObject.get(Constant.DATA);
				String status_cd = (String) jsonObject.get(Constant.STATUS_CD);
				if ("1".equals(status_cd)) {
					String apiKey = authenticationUtility.getBusinessTypeDetailsFromGSTN(rek,
							Constant.SESSION_KEY.getBytes());
					String finalJsonData = authenticationUtility.getBusinessTypeDetailsFromGSTN(data,
							apiKey.getBytes());
					gstr3Service.saveGstr3LiabilityLedgerDetail(tblGstinRetutnFilingStatus.getId().getGstinId(),tblGstinRetutnFilingStatus.getId().getTaxPeriod(), finalJsonData);
				} else {
					stepExecution.setExitStatus(ExitStatus.NOOP);
				}
			} 
		}catch (Exception e) {
			LOGGER.error("Failed due to Reason"+e.getMessage());
		} 
		
		
	}
}
