package com.ey.advisory.asp.batch.decider;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.client.domain.TblGSTINList;

/**
 * @author Smruti.Pradhan Decider for InterfacetoGSTN Job
 */
@Component
public class FileInterfaceDecider implements JobExecutionDecider {
	protected static final Logger LOGGER = Logger.getLogger(FileInterfaceDecider.class);

	@SuppressWarnings("unchecked")
	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {
		ExecutionContext executionContext = stepExecution.getJobExecution().getExecutionContext();
		LOGGER.info("Executing Decision with FileInterfaceDecider :  ");
		List<TblGSTINList> gstinList = null;
		if (executionContext.containsKey("gstinList") && executionContext.get("gstinList") != null)
			gstinList = (List<TblGSTINList>) executionContext.get("gstinList");

		if (null == gstinList   || gstinList.isEmpty())
			return FlowExecutionStatus.STOPPED;
		else {
			LOGGER.info("Executing Decision with FileInterfaceDecider :" + gstinList.size());
			return FlowExecutionStatus.COMPLETED;
		}
	}

}
