package com.ey.advisory.asp.quartz.listener;

import java.util.Date;

import javax.persistence.PostPersist;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.AutowireSpringBeanHelper;
import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.quartz.dynamicScheduler.SystemClientDynamicScheduler;

public class SystemClientDynamicSchedulerListener {
    
    private SystemClientDynamicScheduler systemClientDynamicScheduler;
    
    private static final Logger LOGGER = Logger.getLogger(SystemClientDynamicSchedulerListener.class);

    @Autowired
    public void setDynamicScheduler(SystemClientDynamicScheduler systemClientDynamicScheduler) {
        this.systemClientDynamicScheduler = systemClientDynamicScheduler;
    }
           
    /*@PrePersist
    public void checkIfSameJobExistWithDifferentParameter(TenantDynamicJobDetail JobDetails){
    	 JobDataMap jobDataMap = new JobDataMap();      
         AutowireSpringBeanHelper.autowire(this, this.systemClientDynamicScheduler);
         String param = systemClientDynamicScheduler.readJobParam(JobDetails, jobDataMap);         
         boolean flag = systemClientDynamicScheduler.checkIfSameJobExistInProcessingState(JobDetails.getJobName(), JobDetails.getGroupCode(), param);
         if(flag){
        	 JobDetails.setFlag(1);
         }        
    }*/
    
    @PrePersist
    public void onCreate(TenantDynamicJobDetail JobDetails) {
    	Date date = new java.util.Date();
    	JobDetails.setUpdated(date);
    	JobDetails.setCreated(date);
    }

    @PreUpdate
    public void onUpdate(TenantDynamicJobDetail JobDetails) {
    	JobDetails.setUpdated(new java.util.Date());
    }
        
    @PostPersist
    public void scheduleTenantJob(TenantDynamicJobDetail JobDetails) {
        AutowireSpringBeanHelper.autowire(this, this.systemClientDynamicScheduler);
        if(JobDetails.getFlag()!=1){
        	if(LOGGER.isDebugEnabled()) 
        	LOGGER.debug("Scheduling job : " + JobDetails.getJobName() +" with id : "+ JobDetails.getId());        	
        	int isUpdate = systemClientDynamicScheduler.scheduleJob(JobDetails);
        	if(isUpdate != -1){
        		if(LOGGER.isDebugEnabled())
        		LOGGER.debug("Job : " + JobDetails.getJobName() +" id : "+ JobDetails.getId() + " scheduled.");
        		JobDetails.setStatus(Constant.INPROGRESS);
        	}       
        }
    }
    
    
    
}
