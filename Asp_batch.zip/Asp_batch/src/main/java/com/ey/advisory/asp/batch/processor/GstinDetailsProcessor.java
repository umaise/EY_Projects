package com.ey.advisory.asp.batch.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatusPK;
import com.ey.advisory.asp.common.RegistrationTypes;

@Component
@Scope(value = "step")
public class GstinDetailsProcessor implements ItemProcessor<TblGstinDetailsDomain, List<TblGstinRetutnFilingStatus>> {

	protected static final Logger lOGGER = Logger.getLogger(GstinDetailsProcessor.class);

	@Value("#{jobParameters['taxPeriod']}")
	private String taxPeriod;

	@Override
	public List<TblGstinRetutnFilingStatus> process(TblGstinDetailsDomain item) throws Exception {
		
			lOGGER.info("Inside GstinDetailsProcessor:process()");
		String registrationType = item.getTypeOfReg();
		String returnTypes[] = null;
		List<TblGstinRetutnFilingStatus> returnFilingList = null;

		if (registrationType.equalsIgnoreCase(Constant.REGULAR))
			returnTypes = RegistrationTypes.REGULAR.getType().split(",");
		else if (registrationType.equalsIgnoreCase(Constant.TCS))
			returnTypes = RegistrationTypes.TCS.getType().split(",");
		else if (registrationType.equalsIgnoreCase(Constant.TDS))
			returnTypes = RegistrationTypes.TDS.getType().split(",");
		else if (registrationType.equalsIgnoreCase(Constant.ISD))
			returnTypes = RegistrationTypes.ISD.getType().split(",");

		if (returnTypes != null) {
			returnFilingList = new ArrayList<TblGstinRetutnFilingStatus>();
			for (String type : returnTypes) {
				TblGstinRetutnFilingStatus returnFilingDetail = new TblGstinRetutnFilingStatus();
				TblGstinRetutnFilingStatusPK returnFilingDetailPK = new TblGstinRetutnFilingStatusPK();
				returnFilingDetailPK.setGstinId(item.getGstinId());
				returnFilingDetailPK.setTaxPeriod(taxPeriod);
				returnFilingDetailPK.setReturnType(type);
				returnFilingDetail.setId(returnFilingDetailPK);
				returnFilingDetail.setStatus(Constant.NEW);
				returnFilingDetail.setIsSuccess(false);
				returnFilingList.add(returnFilingDetail);
			}
		}
			lOGGER.info("Exit GstinDetailsProcessor:process()");
		return returnFilingList;
	}

}
