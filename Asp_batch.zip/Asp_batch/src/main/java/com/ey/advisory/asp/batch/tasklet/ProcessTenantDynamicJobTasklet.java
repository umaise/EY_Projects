package com.ey.advisory.asp.batch.tasklet;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;
import com.ey.advisory.asp.quartz.dynamicScheduler.SystemClientDynamicScheduler;

@PropertySource("classpath:batch.properties")
public class ProcessTenantDynamicJobTasklet implements Tasklet {

	protected static final Logger LOGGER = Logger.getLogger(ProcessTenantDynamicJobTasklet.class);

	@Autowired
	TenantDynamicJobDetailsRepository jobDetailsRepository;

	@Value("${job.tenantJob.recordCount}")
	private int recordCount;

	@Autowired
	private SystemClientDynamicScheduler sysClientDynaScheduler;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		int count;
		int pageNo = 0;

		List<TenantDynamicJobDetail> multiTenantJobDetailsList = null;

		do {

			count = 0;

			Pageable top = new PageRequest(pageNo, recordCount, Direction.ASC, "id");

			multiTenantJobDetailsList = jobDetailsRepository.getPageableJobDetails(top);

			for (TenantDynamicJobDetail jobDetail : multiTenantJobDetailsList) {
				LOGGER.info("Processing tenant dynamic job detail record with id " + jobDetail.getId());
				jobDetail.setFlag(-1);
				int isUpdate = sysClientDynaScheduler.scheduleJob(jobDetail);
				if (isUpdate != -1) {
					jobDetail.setStatus(Constant.INPROGRESS);
					count++;
					jobDetailsRepository.saveAndFlush(jobDetail);
				}
			}

			if (multiTenantJobDetailsList == null || multiTenantJobDetailsList.size() == 0
					|| multiTenantJobDetailsList.size() < recordCount) {
				break;
			}

			recordCount = recordCount - count;
			pageNo++;

		} while (recordCount > 0);

		return RepeatStatus.FINISHED;
	}

}
