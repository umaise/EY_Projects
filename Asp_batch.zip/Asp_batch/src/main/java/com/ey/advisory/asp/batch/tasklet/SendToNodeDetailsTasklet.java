package com.ey.advisory.asp.batch.tasklet;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;

/**
 * @author Smruti.Pradhan
 * Tasklet used to send invoice count and invoice list for gstr1 to node Js
 */
@PropertySource("classpath:batch.properties")
public class SendToNodeDetailsTasklet implements Tasklet{
	protected static final Logger LOGGER = Logger.getLogger(SendToNodeDetailsTasklet.class);
	@Autowired
	private Environment env;
	
	
	@Autowired
	Gstr1Service gstr1Service;
	
	@Autowired
	private BatchClientUtility batchClientUtility;
	@Autowired 
	ClientSpCallService clientSpCallService;
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
			throws Exception {
		if(LOGGER.isInfoEnabled())
		LOGGER.info("Inside execute method of SendToNodeDetailsTasklet() ");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		ExecutionContext executionContext=chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();
		List<String> invCountlist = (List<String>) executionContext.get("invCount");
    	List<String> lineItmlist=(List<String>) executionContext.get("lineItem");
    	String updateIsProcessedTo=(String) executionContext.get("updateIsProcessedTo");
    	String updateJobStatusTo=(String) executionContext.get("updateJobStatusTo");
    	String fileId=(String) executionContext.get("fileId");

    	/*send invoiceCount to Redis server*/
      	for(String invCount:invCountlist)
    	{
    		invCount=invCount.substring(1,invCount.length()-1);
    		batchClientUtility.executeRestCall(env.getProperty("node-gstr1-InvCountUrl-host"),httpHeaders,
    		invCount,
				HttpMethod.POST);
    	}
      	if(lineItmlist !=null && !lineItmlist.isEmpty()){
      	/*send data to storm at invoice level*/
		for(String lineItem:lineItmlist)
			{
				batchClientUtility.executeRestCall(env.getProperty("node-gstr1-LineCountUrl-host"),httpHeaders,
						lineItem,
				HttpMethod.POST);
			}
      	}
      	else{
      		gstr1Service.updateStageAndJobStatus(updateIsProcessedTo, updateJobStatusTo, Integer.parseInt(fileId));
      	}
		
		LOGGER.info("Finished execute method of SendToNodeDetailsTasklet() ");
		return RepeatStatus.FINISHED;

	
	}
}
