package com.ey.advisory.asp.batch.reader;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.master.service.SpCallService;

public class ClientRawFileReader implements ItemReader<String> {
	
	protected static final Logger lOGGER = Logger.getLogger(ClientRawFileReader.class);


	@Autowired
	private SpCallService spCallService;
	private String storedProcName;
	private List<String> ouputParams;
	private int rowCount = 0;

	@BeforeStep
	public void initializeState(StepExecution stepExecution) {
		
		ouputParams=spCallService.executeStoredProcedureReturnList(null,storedProcName,0,null);
	}

	@Override
	public String read() throws Exception {

		String outputParam = null;

		if (ouputParams != null && rowCount < ouputParams.size()) {
			lOGGER.info("List size "+ouputParams.size() );
			outputParam = ouputParams.get(rowCount);
			++rowCount;
		}
		
		return outputParam;
	}

	public String getStoredProcName() {
		return storedProcName;
	}

	public void setStoredProcName(String storedProcName) {
		this.storedProcName = storedProcName;
	}
	
	

}
