package com.ey.advisory.asp.batch.tasklet;


import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.batch.util.Constant;
import com.ey.advisory.asp.client.domain.TblGSTINList;
import com.ey.advisory.asp.client.service.TblGSTINSummaryListService;
import com.ey.advisory.asp.client.service.TblGstinListService;
import com.ey.advisory.asp.master.service.TenantDynamicJobDetailsService;



/**
 * @author Smruti.Pradhan
 * This Tasklet is to fetch GSTNlist based on current and next taxperiod
 */
public class FetchGSTINListTasklet implements Tasklet{
	protected static final Logger LOGGER = Logger.getLogger(FetchGSTINListTasklet.class);
	@Autowired
	TblGstinListService tblGstinListService;
	
	@Autowired
	TblGSTINSummaryListService tblGSTINSummaryListService;
	
	@Autowired
	TenantDynamicJobDetailsService tenantDynamicJobDetailsService;
		
	
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		LOGGER.info("Inside execute method of FetchGSTINListTasklet ");
		ExecutionContext stepExecution = chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();	
		List<TblGSTINList> gstinList=null;
		String gstin=null;
		String taxPeriod = null;
		String UserId="";
		try {
			
			Map<String, JobParameter> jobPar = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters().getParameters();
			//String gstin = tenantDynamicJobDetailsService.getJobParamDetails(String.valueOf(jobPar.get("jobName")),String.valueOf(jobPar.get("BATCH_TENANT_CONTEXT")), Constant.INPROGRESS);
			if(null != jobPar && null != jobPar.get("gstin") && null != jobPar.get("taxPeriod")  ){
				gstin= String.valueOf(jobPar.get("gstin"));
				taxPeriod = String.valueOf(jobPar.get("taxPeriod"));
				UserId= String.valueOf(jobPar.get("userEmailId"));
			}
			
			stepExecution.put("gstin",gstin );
    		stepExecution.put("taxPeriod",taxPeriod );
    		stepExecution.put("userEmailId", UserId);
			
			
			if (Constant.GSTR1_TRANSACTIONAL_SAVE_JOB_NAME.equalsIgnoreCase(chunkContext.getStepContext().getJobName())) {
		    		stepExecution.put("jobName", Constant.GSTR1_TRANSACTIONAL_SAVE_JOB_NAME);
		    	
			}else if(Constant.GSTR2_TRANSACTIONAL_SAVE_JOB_NAME.equalsIgnoreCase(chunkContext.getStepContext().getJobName())){
		    		stepExecution.put("jobName", Constant.GSTR2_TRANSACTIONAL_SAVE_JOB_NAME);
		    	
			}
			
		}catch (Exception ex) {
			LOGGER.error("Exception in FetchGSTINListTasklet execute method");
			throw new Exception("Exception in FetchGSTINListTasklet execute method: "+ex.getMessage());
		}
		
		return RepeatStatus.FINISHED;
		
	}
	
}
