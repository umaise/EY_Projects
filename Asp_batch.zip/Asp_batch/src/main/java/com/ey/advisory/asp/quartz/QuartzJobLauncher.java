package com.ey.advisory.asp.quartz;

import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;
import org.quartz.UnableToInterruptJobException;
import org.quartz.impl.JobDetailImpl;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.quartz.impl.triggers.SimpleTriggerImpl;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.configuration.JobLocator;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.ey.advisory.asp.batch.util.Constant;

public class QuartzJobLauncher extends QuartzJobBean implements ApplicationContextAware, InterruptableJob {

	@Autowired
	ApplicationContext appContext;

	static final String JOB_NAME = "jobName";

	private JobLocator jobLocator;

	private JobLauncher jobLauncher;

	/**
	 * Flag to indicate whether this job has been interrupted. When this flag
	 * becomes true the job should stop what it is doing and finish.
	 */
	private boolean hasBeenInterrupted = false;

	protected static final Logger LOGGER = Logger.getLogger(QuartzJobLauncher.class);
	private static final String CLASS_NAME = QuartzJobLauncher.class.getName();

	public void setJobLocator(JobLocator jobLocator) {
		this.jobLocator = jobLocator;
	}

	public void setJobLauncher(JobLauncher jobLauncher) {
		this.jobLauncher = jobLauncher;
	}

	@Override
	protected void executeInternal(JobExecutionContext context) {
		if (!hasBeenInterrupted) {
			LOGGER.info("hasNotBeenInterrupted ....executeInternal");
			Map<String, Object> jobDataMap = context.getMergedJobDataMap();

			String jobName;
			JobParameters jobParameters;
			if (jobDataMap == null || jobDataMap.isEmpty()) {
				if (context.getTrigger() instanceof CronTriggerImpl) {
					CronTriggerImpl cronTrigger = (CronTriggerImpl) context.getTrigger();
					if (cronTrigger.getJobName() != null)
						jobDataMap = ((JobDetailImpl) appContext.getBean(cronTrigger.getJobName())).getJobDataMap();
				} else if (context.getTrigger() instanceof SimpleTriggerImpl) {
					SimpleTriggerImpl simpleTrigger = (SimpleTriggerImpl) context.getTrigger();
					if (simpleTrigger.getJobName() != null)
						jobDataMap = ((JobDetailImpl) appContext.getBean(simpleTrigger.getJobName())).getJobDataMap();
				}
			}

			jobName = jobDataMap == null ? null : (String) jobDataMap.get(JOB_NAME);
			jobParameters = getJobParametersFromJobMap(jobDataMap);

			if (jobName != null) {
				try {
					Job job = jobLocator.getJob(jobName);
					jobLauncher.run(job, jobParameters);
				} catch (JobExecutionException e) {
					LOGGER.error("Exception in " + CLASS_NAME + " Method : executeInternal" + e.getMessage());
					throw new IllegalStateException("Unable to launch job " + jobName);
				}catch (Exception e) {
    				if(LOGGER.isInfoEnabled())
    				LOGGER.info("Exception in  Method : executeInternal"+ e.getMessage());
    				throw e;
    			}
			}
		}

		LOGGER.info("hasBeenInterrupted ....executeInternal");
	}

	// get params from jobDataMap property, quartz-context.xml
	private JobParameters getJobParametersFromJobMap(Map<String, Object> jobDataMap) {

		JobParametersBuilder builder = new JobParametersBuilder();

		for (Entry<String, Object> entry : jobDataMap.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			if (value instanceof String && !key.equals(JOB_NAME)) {
				builder.addString(key, (String) value);
			} else if (value instanceof Float || value instanceof Double) {
				builder.addDouble(key, ((Number) value).doubleValue());
			} else if (value instanceof Integer || value instanceof Long) {
				builder.addLong(key, ((Number) value).longValue());
			} else if (value instanceof Date) {
				builder.addDate(key, (Date) value);
			} else {
				// JobDataMap contains values which are not job parameters
				// (ignoring)
			}
		}

		// need unique job parameter to rerun the same job
		builder.addDate(Constant.JOB_RUN_DATE, new Date());

		return builder.toJobParameters();

	}

	 public void interrupt() throws UnableToInterruptJobException {
	        hasBeenInterrupted = true;
	   }

	 
	@Override
	public void setApplicationContext(ApplicationContext appContext) throws BeansException {
		this.appContext = appContext;
	}

}
