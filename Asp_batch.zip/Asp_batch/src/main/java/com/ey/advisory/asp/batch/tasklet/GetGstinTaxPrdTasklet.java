package com.ey.advisory.asp.batch.tasklet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepSynchronizationManager;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.client.service.TblGstinListService;
import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;

public class GetGstinTaxPrdTasklet implements Tasklet {

	protected static final Logger LOGGER = Logger.getLogger(GetGstinTaxPrdTasklet.class);
	List<FileUploadStatusMaster> processFileList;

	private String jobStatus;
	private String fileData;
	private String isProcessed;

	@Autowired
	TblGstinListService tblGstinListService;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		if (LOGGER.isInfoEnabled())
			LOGGER.info("Inside execute mehtod of GetGstinTaxPrdTasklet");
		ExecutionContext executionContext = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getExecutionContext();
		StepExecution stepExecution = StepSynchronizationManager.getContext().getStepExecution();

		List<Object[]> gstinListInfo = tblGstinListService.getGSTINListEligibleForGstr2A();
		
		if(gstinListInfo == null || gstinListInfo.size()==0){
			stepExecution.setExitStatus(ExitStatus.NOOP);
			return RepeatStatus.FINISHED;
		}

		List<String> gstinList = null;
		try {

			Map<String, List<String>> gstinTaxPrdMap = new HashMap<String, List<String>>();
			String gstin = null;
			String taxPeriod = null;

			for (Object[] record : gstinListInfo) {
				taxPeriod = (String) record[1];
				gstin = (String) record[0];
				gstinList = gstinTaxPrdMap.get(taxPeriod);
				if (gstinList == null) {
					gstinList = new ArrayList<>();
				}
				gstinList.add(gstin);
				gstinTaxPrdMap.put(taxPeriod, gstinList);
			}
			executionContext.put("gstinTaxPrdMap", gstinTaxPrdMap);
		} catch (Exception e) {
			LOGGER.error("Exception inside execute method of GetGstinTaxPrdTasklet" + e);
/*			stepExecution.setExitStatus(ExitStatus.NOOP);
			return RepeatStatus.FINISHED;
*/		}

		if (LOGGER.isInfoEnabled())
			LOGGER.info("Inside execute mehtod of Gstr2ReconcilationTasklet finished");
		return RepeatStatus.FINISHED;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getFileData() {
		return fileData;
	}

	public void setFileData(String fileData) {
		this.fileData = fileData;
	}

	public String getIsProcessed() {
		return isProcessed;
	}

	public void setIsProcessed(String isProcessed) {
		this.isProcessed = isProcessed;
	}
}
