package com.ey.advisory.asp.batch.processor;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import com.ey.advisory.asp.batch.util.BatchClientUtility;
import com.ey.advisory.asp.client.domain.PayloadStatus;
import com.ey.advisory.asp.common.Constant;

@PropertySource("classpath:RestConfig.properties")
public class TransactionStatusProcessor implements ItemProcessor<PayloadStatus, PayloadStatus> {
	@Autowired
	BatchClientUtility batchClientUtility;

	@Autowired
	private Environment env;

	private static final Logger LOGGER = Logger.getLogger(TransactionStatusProcessor.class);
	private static final String CLASS_NAME = TransactionStatusProcessor.class.getName();

	@Override
	public PayloadStatus process(PayloadStatus payLoadDetails) throws Exception {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : process()");
		// ToDo- fetch SLA from DB
		long sla = 2;
		String result = "";
		String status = "";
		String gstin = payLoadDetails.getTaxPayerGstin();
		String ackNo = payLoadDetails.getGstntransId();
		long timeDiff = Math.abs(payLoadDetails.getUpdateDate().getTime() - new Date().getTime());
		HttpHeaders httpHeaders = new HttpHeaders();
		String resource = env.getProperty("gsp-restapi.host") + env.getProperty("gsp-arnTrack") + "?action="
				+ Constant.ARNTRACK + "&ackNo=" + ackNo + "&gstin=" + gstin;
		try {
			if (TimeUnit.MILLISECONDS.toHours(timeDiff) > sla) {
				result = batchClientUtility.executeRestCall(resource, httpHeaders, HttpMethod.GET);
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonObject = (JSONObject) jsonParser.parse(result);
				status = (String) jsonObject.get("status_cd");
				payLoadDetails.setTransactionStatus(status);
			}
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : process()");
			throw e;
		}

		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : process()");
		return payLoadDetails;
	}

}
