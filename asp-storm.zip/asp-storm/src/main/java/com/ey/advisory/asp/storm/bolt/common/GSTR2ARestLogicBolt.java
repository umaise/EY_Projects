package com.ey.advisory.asp.storm.bolt.common;

import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;

public class GSTR2ARestLogicBolt extends BoltBuilder{

	private CustomOutputCollector collector;

	private final Logger log = LoggerFactory.getLogger(getClass());
	
	@Override
    public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
        this.collector = collector;
    }

	@Override
	public void execute(Tuple input) {
		ReconciliationDTO reconDTO = null;
        //LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();	
        
        long startTime=System.currentTimeMillis();
        
        try{
        	reconDTO = (ReconciliationDTO) input.getValue(0);
        	
        	RedisTemplate<String,Object> redisTemplate= JedisConnectionUtil.getRedisTemplateKVStringObject();
        	
            String redisKey=reconDTO.getRedisKey();
            
            String invProcessedKey=redisKey+"_"+Constant.INVOICE_PSD_COUNT;
            String invCntKey=redisKey+"_"+Constant.INVOICE_COUNT;
            
            Integer count=(Integer) redisTemplate.opsForValue().get(invCntKey);
            
            if(count==null || count==0 ){
            	 RedisTemplate<String, Integer> redisIntegertemplate=JedisConnectionUtil.getRedisTemplateKVStringInteger();
            	 count=redisIntegertemplate.opsForValue().get(invCntKey);
            	 redisTemplate.opsForValue().set(invCntKey,count);
            }
            
            
            	log.info("In GSTR2ARestLogicBolt  redis key : "+ reconDTO.getRedisKey() + " Recon Status Id : "+ reconDTO.getReconStatusId());
            	redisTemplate.opsForHash().put(invProcessedKey,reconDTO.getReconStatusId(),reconDTO.getFilingStatus());
            
            //Set<Object> psdInvSet= redisTemplate.opsForHash().keys(invProcessedKey);
            //Integer invPsdCnt=psdInvSet.size();
            Long invPsdCnt=redisTemplate.opsForHash().size(invProcessedKey);
            
            log.info("Invoice Count for "+redisKey+" : "+ count);
            log.info("Invoice processed for "+redisKey+" : "+ invPsdCnt);
            
            collector.emit(input,new Values(reconDTO,count,invPsdCnt));
        }
        catch(Exception ex){			
            log.error("Error GSTR1RestLogicBolt", ex);
            //logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
        }
        finally {
            collector.ack(input);
            if(log.isInfoEnabled())
            	log.info("In GSTR1RestLogicBolt Time taken for file : "+reconDTO.getRedisKey()+" Recon Status Id : "+ reconDTO.getReconStatusId() +" is "+(System.currentTimeMillis()-startTime));
        }
        
		
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv","invCount","invPsdCnt"));
		
	}

}
