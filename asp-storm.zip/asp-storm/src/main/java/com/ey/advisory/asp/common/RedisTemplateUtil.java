package com.ey.advisory.asp.common;

import java.util.Properties;

import redis.clients.jedis.JedisPoolConfig;

import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.common.configs.ASPStormProperties;
import com.ey.advisory.asp.common.configs.PasswordProtection;

public class RedisTemplateUtil<K,V>{	
	
	RedisTemplate<K,V> redisTemplate;	
	
	private RedisTemplate createRedisTemplate(){
		JedisConnectionFactory jedisConnectionFactory;
		JedisPoolConfig jedisPoolConfig;		
		try {
			Properties props=new Properties();
			//props.load(RedisTemplateUtil.class.getResourceAsStream("/redis.properties"));
			props = ASPStormProperties.getAllProperties();
			
			String hostname = props.getProperty(Constant.REDIS_HOST);
			int port = Integer.parseInt(props.getProperty("redis.port"));			
			int poolMaxActive=Integer.parseInt(props.getProperty(Constant.REDIS_POOL_MAX_ACTIVE));
			int poolMaxIdle=Integer.parseInt(props.getProperty(Constant.REDIS_POOL_MAX_IDLE));
			long poolMaxWait=Long.parseLong(props.getProperty(Constant.REDIS_POOL_MAX_WAIT));
			boolean testOnBorrow=Boolean.parseBoolean(props.getProperty(Constant.REDIS_POOL_TEST_ON_BORROW));
			int timeOut=Integer.parseInt(props.getProperty(Constant.REDIS_TIME_OUT));
			boolean isPasswordEncrypted=Boolean.parseBoolean(props.getProperty(Constant.REDIS_PASSWORD_ENC));
			String password=props.getProperty(Constant.REDIS_PASSWORD);
			
			if(isPasswordEncrypted){
			password = PasswordProtection.getDecriptedPassword(password);
			}
			
			jedisPoolConfig=new JedisPoolConfig();
			jedisPoolConfig.setMaxTotal(poolMaxActive);
			jedisPoolConfig.setMaxIdle(poolMaxIdle);
			jedisPoolConfig.setMaxWaitMillis(poolMaxWait);
			jedisPoolConfig.setTestOnBorrow(testOnBorrow);
			
			jedisConnectionFactory=new JedisConnectionFactory();
			jedisConnectionFactory.setHostName(hostname);
			jedisConnectionFactory.setPort(port);
			jedisConnectionFactory.setPoolConfig(jedisPoolConfig);
			jedisConnectionFactory.setTimeout(timeOut);
			jedisConnectionFactory.setPassword(password);
			
			jedisConnectionFactory.afterPropertiesSet();
			
			redisTemplate=new RedisTemplate<K, V>();
			redisTemplate.setConnectionFactory(jedisConnectionFactory);
			redisTemplate.afterPropertiesSet();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return redisTemplate;
	}	
	
	public RedisTemplate getRedisTemplate(){
		if(redisTemplate==null){
			redisTemplate=createRedisTemplate();
		}
		return redisTemplate;
	}	
	
}
