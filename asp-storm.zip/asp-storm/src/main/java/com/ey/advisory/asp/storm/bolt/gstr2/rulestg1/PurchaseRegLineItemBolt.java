package com.ey.advisory.asp.storm.bolt.gstr2.rulestg1;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.runtime.Globals;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.KnowledgeBaseFactory;
import org.kie.internal.definition.KnowledgePackage;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.common.error.LogGSTR2RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.master.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.service.gstr2.Gstr2ValidationRuleService;
import com.ey.advisory.asp.service.gstr2.Gstr2ValidationRuleServiceImpl;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;

/**

 * @author  Raghavan. S venket
 * @version 1.0
 * @since   21-04-2017
 */

public class PurchaseRegLineItemBolt extends CustomBaseRichBolt{

	private static final long serialVersionUID = 1L;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;
	Set<TblPurchaseErrorInfo> errorList = new HashSet<TblPurchaseErrorInfo>();

	Set<String> hsnSacGlobalSet = null;
	Map<String, ItemMaster> itemHsnSacMap = new HashMap<String, ItemMaster>();
	private Gstr2ValidationRuleService validationRuleService;

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		validationRuleService = new Gstr2ValidationRuleServiceImpl();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(Tuple input) {
		InwardInvoiceDTO inwardInvoiceDTO = null;
		LogRunTimeErros logRunTimeErros = new LogGSTR2RunTimeErros();
		InputStream fout = null;
		ObjectInputStream oos = null;
		try{
			log.info("In PurchaseRegLineItemBolt.execute() start");
			inwardInvoiceDTO = (InwardInvoiceDTO) input.getValue(0);
			log.info("rediskey : " + inwardInvoiceDTO.getRedisKey() + " InvOrder : "+ inwardInvoiceDTO.getLineItemList().get(0).getInvOrder());

			if(inwardInvoiceDTO.getErrorList()!=null){
				errorList =inwardInvoiceDTO.getErrorList();
			}
			RedisTemplate<String, Object> redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();

			getMasterDetailsfromRedis(redisTemplate,inwardInvoiceDTO.getGroupCode());

			if (itemHsnSacMap == null||itemHsnSacMap.size()==0 ) {

				if( validationRuleService.validateHsnSacAgainstNonGST(inwardInvoiceDTO.getGroupCode()).equalsIgnoreCase("Success")){
					getMasterDetailsfromRedis(redisTemplate,inwardInvoiceDTO.getGroupCode());
				}
			}

			fout = PurchaseRegLineItemBolt.class.getResourceAsStream("/GSTR2_LineItemValidation.ser");
			oos = new ObjectInputStream(fout);

			Collection<KnowledgePackage> knowledgePackages = (Collection<KnowledgePackage>) oos.readObject();
			KieBaseConfiguration kBaseConfig = KnowledgeBaseFactory.newKnowledgeBaseConfiguration();
			KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase(kBaseConfig);
			kbase.addKnowledgePackages(knowledgePackages);
			StatefulKnowledgeSession kSession = kbase.newStatefulKnowledgeSession();

			Map<String,Set<BigDecimal>> globalRatesMap = (Map<String,Set<BigDecimal>>)redisTemplate.opsForHash().get(Constant.REDIS_CACHE, Constant.GLOBAL_RATES_MAP);

			Set<BigDecimal> igstList = new HashSet<>();
			Set<BigDecimal> cgstList = new HashSet<>();
			Set<BigDecimal> sgstList = new HashSet<>();

			if(globalRatesMap!=null && !globalRatesMap.isEmpty()) {
				igstList = globalRatesMap.get(Constant.IGST_RATE_LIST);
				cgstList = globalRatesMap.get(Constant.CGST_RATE_LIST);
				sgstList = globalRatesMap.get(Constant.SGST_RATE_LIST);
			}

			BigDecimal grossTurnover = Utility.getGrossTurnover(inwardInvoiceDTO.getLineItemList().get(0).getCGSTIN(), redisTemplate, inwardInvoiceDTO.getGroupCode());
			Globals globals = kSession.getGlobals();
			globals.set("itemhsnSacSet", itemHsnSacMap.keySet());
			globals.set("errorList", errorList);
			globals.set("globalhsnSacSet", hsnSacGlobalSet);
			globals.set("grossTurnover", grossTurnover);
			globals.set("groupCode", inwardInvoiceDTO.getGroupCode());
			globals.set("igstList", igstList);
			globals.set("cgstList", cgstList);
			globals.set("sgstList", sgstList);

			BigDecimal totalTaxAmount;
			BigDecimal totalTaxRate;

			for(InwardInvoiceModel inaWardstgTbl : inwardInvoiceDTO.getLineItemList()){

				totalTaxAmount = Constant.ZERO_BIG_DECIMAL;
				totalTaxRate = Constant.ZERO_BIG_DECIMAL;

				inaWardstgTbl = prepareModel(inaWardstgTbl);

				totalTaxAmount = totalTaxAmount.add(inaWardstgTbl.getIGSTAmount()).add(inaWardstgTbl.getSGSTAmount()).add(inaWardstgTbl.getCGSTAmount()).add(inaWardstgTbl.getCessAmountSpecific()).add(inaWardstgTbl.getCessAmountAdvalorem());
				totalTaxRate = inaWardstgTbl.getIGSTRate().add(inaWardstgTbl.getCGSTRate()).add(inaWardstgTbl.getSGSTRate()).add(inaWardstgTbl.getCessRateSpecific()).add(inaWardstgTbl.getCessRateAdvalorem());

				kSession.setGlobal("totalTaxAmount", totalTaxAmount);
				kSession.setGlobal("totalTaxRate", totalTaxRate);

				kSession.insert(inaWardstgTbl);
				kSession.fireAllRules();
				if ((inwardInvoiceDTO.getInvStatus() == null
						|| inwardInvoiceDTO.getInvStatus().equals(
								Constant.GSTR2_BR_STG1)) && inaWardstgTbl.getItemStatus() != null) {
					inwardInvoiceDTO.setInvStatus(inaWardstgTbl.getItemStatus());
				}
			}
			inwardInvoiceDTO.setErrorList(errorList);
			kSession.destroy();
			collector.emit(input,new Values(inwardInvoiceDTO));
		}catch(Exception e){
			log.error("Error in PurchaseRegLineItemBolt ", e);
			//collector.customReportError(input, e, "Exception in Bolt PurchaseRegLineItemBolt");
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}finally {
			try {
				if(oos!=null)
					oos.close();
				if(fout!=null)
					fout.close();
			} catch (IOException e) {
				log.error("Error closing stream ", e);
			}

			collector.ack(input);
			//collector.emit(new Values(inwardInvoiceDTO));
			// collector.emit(Constant.GSTR2_Stream1,new Values(inwardInvoiceDTO));
			log.info("In PurchaseRegLineItemBolt.execute() end");
		}
	}

	private InwardInvoiceModel prepareModel(InwardInvoiceModel inaWardstgTbl) {

		if(inaWardstgTbl!=null) {
			inaWardstgTbl.setCGSTRate(inaWardstgTbl.getCGSTRate()==null? Constant.ZERO_BIG_DECIMAL.setScale(2): inaWardstgTbl.getCGSTRate().setScale(2));
			inaWardstgTbl.setIGSTRate(inaWardstgTbl.getIGSTRate()==null? Constant.ZERO_BIG_DECIMAL.setScale(2): inaWardstgTbl.getIGSTRate().setScale(2));
			inaWardstgTbl.setSGSTRate(inaWardstgTbl.getSGSTRate()==null? Constant.ZERO_BIG_DECIMAL.setScale(2): inaWardstgTbl.getSGSTRate().setScale(2));
			inaWardstgTbl.setCessRateSpecific(inaWardstgTbl.getCessRateSpecific()==null? Constant.ZERO_BIG_DECIMAL: inaWardstgTbl.getCessRateSpecific());
			inaWardstgTbl.setCessRateAdvalorem(inaWardstgTbl.getCessRateAdvalorem()==null? Constant.ZERO_BIG_DECIMAL: inaWardstgTbl.getCessRateAdvalorem());

			inaWardstgTbl.setCGSTAmount(inaWardstgTbl.getCGSTAmount()==null? Constant.ZERO_BIG_DECIMAL: inaWardstgTbl.getCGSTAmount());
			inaWardstgTbl.setIGSTAmount(inaWardstgTbl.getIGSTAmount()==null? Constant.ZERO_BIG_DECIMAL: inaWardstgTbl.getIGSTAmount());
			inaWardstgTbl.setSGSTAmount(inaWardstgTbl.getSGSTAmount()==null? Constant.ZERO_BIG_DECIMAL: inaWardstgTbl.getSGSTAmount());
			inaWardstgTbl.setCessAmountSpecific(inaWardstgTbl.getCessAmountSpecific()==null? Constant.ZERO_BIG_DECIMAL: inaWardstgTbl.getCessAmountSpecific());
			inaWardstgTbl.setCessAmountAdvalorem(inaWardstgTbl.getCessAmountAdvalorem()==null? Constant.ZERO_BIG_DECIMAL: inaWardstgTbl.getCessAmountAdvalorem());	

			inaWardstgTbl.setTaxableValue(inaWardstgTbl.getTaxableValue()==null? Constant.ZERO_BIG_DECIMAL: inaWardstgTbl.getTaxableValue());
			inaWardstgTbl.setInvoiceValue(inaWardstgTbl.getInvoiceValue()==null? Constant.ZERO_BIG_DECIMAL: inaWardstgTbl.getInvoiceValue());

			if(inaWardstgTbl.getHSNorSAC()!=null)
				inaWardstgTbl.setHSNorSAC(inaWardstgTbl.getHSNorSAC().trim().isEmpty()? null: inaWardstgTbl.getHSNorSAC());
			if(inaWardstgTbl.getCGSTIN()!=null)
				inaWardstgTbl.setCGSTIN(inaWardstgTbl.getCGSTIN().trim().isEmpty()? null: inaWardstgTbl.getCGSTIN());
			if(inaWardstgTbl.getSGSTIN()!=null)
				inaWardstgTbl.setSGSTIN(inaWardstgTbl.getSGSTIN().trim().isEmpty()? null: inaWardstgTbl.getSGSTIN());
			if(inaWardstgTbl.getPos()!=null)
				inaWardstgTbl.setPos(inaWardstgTbl.getPos().trim().isEmpty()? null: inaWardstgTbl.getPos());
		}
		return inaWardstgTbl;
	}

	private void getMasterDetailsfromRedis(RedisTemplate<String, Object> redisTemplate, String groupCode) {
		if (hsnSacGlobalSet==null) {
			hsnSacGlobalSet = (Set<String>)(Set<?>)redisTemplate.opsForHash().keys(Constant.GLOBAL_MASTER_DETAILS);
		}

		itemHsnSacMap = (Map<String, ItemMaster>)redisTemplate.opsForHash().get(groupCode+"_"+Constant.REDIS_CACHE, Constant.ITEM_MASTER_DETAILS);

		if(itemHsnSacMap==null){
			itemHsnSacMap= new HashMap<String, ItemMaster>();
		}

		if(hsnSacGlobalSet == null){
			hsnSacGlobalSet = new HashSet<>();
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR2_Stream1,new Fields("inv"));
	}

}