package com.ey.advisory.asp.storm.bolt.gstr1.gstn;

import java.util.Map;
import java.util.Properties;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.storm.bolt.common.BoltBuilder;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;

/**
 * @author Smruti.Pradhan
 *This class is used to call tuple for interface to GSTN
 */
public class PublishGstr1RestBolt extends BoltBuilder{
	
	private static final long serialVersionUID = -9050139016787894436L;
	private CustomOutputCollector collector;
	private final Logger log = LoggerFactory.getLogger(getClass());
	/*public PublishGstr1RestBolt(Properties configs) {
		super(configs);
	}*/
	@Override
	public void prepare(Map stormConf, TopologyContext context,
			CustomOutputCollector collector) {

		
		this.collector = collector;
	}
	@Override
	public void execute(Tuple input) {
		  LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();
		try{
			log.info("input json payload"+input.getString(0));
	String str=input.getString(0);
	RestClientUtility restClientUtil = new RestClientUtility();
	restClientUtil.callGSTR1RestService(str);
	
	
		}
		
		catch(Exception ex){
			 log.error(ex.getMessage(), ex);
	         logRunTimeErros.logErrorsInredis(input.getString(0), Constant.DATA_ERROR);
			//collector.customReportError(input, ex, "Exception in Bolt PublishGstr1RestBolt");
		}
		
		finally {
			collector.ack(input);
		}
		
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
			
	}

}
