package com.ey.advisory.asp.common.error;

import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Set;

import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.exceptions.RESTCallFailureException;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

public class LogGSTR1RunTimeErros extends LogRunTimeErros {
	
	private static final Logger log = LoggerFactory.getLogger(LogGSTR1RunTimeErros.class);
	
	@Override
	public void logErrorsInredis(Tuple input,String errorCode) {
		try{
			 OutwardInvoiceDTO outwardInvoiceDTO = (OutwardInvoiceDTO) input.getValue(0);
			 
			 pushInvoiceDetailsToredis(outwardInvoiceDTO,errorCode);
			 
		}catch(Exception ex){
			log.error("Exception in LogGSTR1RunTimeErros.logErrorsInredis() : "+ex.getMessage());
		}
	}

	
	@Override
	public void logErrorsInredis(String jsonString, String errorCode) {
		String redisKey="";
		OutwardInvoiceDTO outwardInvoiceDTO = null;
		try{
			Gson gson = new Gson();
			
            Type listType = new TypeToken<OutwardInvoiceDTO>(){}.getType();
            outwardInvoiceDTO=gson.fromJson(jsonString, listType);
            if(outwardInvoiceDTO !=null){
            	pushInvoiceDetailsToredis(outwardInvoiceDTO,errorCode);
            }
			//TODO Need to insert into new Data model for tracking
		}catch(JsonSyntaxException jsonSyntExce){
			log.error("Recevied message is not in Json format LogGSTR1RunTimeErros.logErrorsInredis() : "+jsonString);
		}catch(Exception ex){
			log.error("Exception in LogGSTR1RunTimeErros.logErrorsInredis() : "+ex.getMessage());
		}
	}

	@Override
	public void decrementInvoiceCount(String redisKey) {
		try{
            RedisTemplate<String, Integer> redisIntegertemplate=JedisConnectionUtil.getRedisTemplateKVStringInteger();
            
            String invCntKey=redisKey+"_"+Constant.INVOICE_COUNT;
            
            RedisAtomicInteger count=new RedisAtomicInteger(invCntKey,redisIntegertemplate);
            if(log.isInfoEnabled()){
            	 log.info("redisKey from LogGSTR1RunTimeErros.decrementInvoiceCount : "+redisKey+"   Count****"+ count);
            }
               
            if(count.intValue()==0){
                if(log.isInfoEnabled()){
                	log.info("Invoice count is coming as ZERO LogGSTR1RunTimeErros.decrementInvoiceCount  : "+redisKey);
                }
            }
            
            if(count.intValue()==1){
                //Trigger web service to update invoice status and error details to DB
                RestClientUtility restClientUtil = new RestClientUtility();
                synchronized (count) {
                	saveInvoceDetails(redisKey);  					 
                }
            }else{
                count.getAndSet(count.intValue()-1);
                if(log.isInfoEnabled())
                    log.info("After decrement count from redis : "+ count);
            }
            
		}catch(Exception ex){
			log.error("Exception in LogGSTR1RunTimeErros.decrementInvoiceCount() : "+ex.getMessage());
		}
		
	}

	@Override
	public void saveInvoceDetails(String redisKey) {
		try{
			RestClientUtility restClientUtil = new RestClientUtility();
        	String groupCode = Utility.getGroupCode(redisKey);
            restClientUtil.callRestServiceJersey(redisKey, groupCode,Constant.REST_HOST);
        }catch(RESTCallFailureException e){
            log.error("Error LogGSTR1RunTimeErros.saveInvoceDetails ", e);
        }catch(Exception ex){
			log.error("Exception in LogGSTR1RunTimeErros.saveInvoceDetails() : "+ex.getMessage());
		}	
	}
	
	public void checkRestLogicForSaveRestCall(String redisKey) {
		try{
            String invProcessedKey=redisKey+"_"+Constant.INVOICE_PSD_COUNT;
            String invCntKey=redisKey+"_"+Constant.INVOICE_COUNT;
            
            RedisTemplate<String,Object> redisTemplate= JedisConnectionUtil.getRedisTemplateKVStringObject();
            
            Integer invCnt=(Integer) redisTemplate.opsForValue().get(invCntKey);
            
            if(invCnt==null || invCnt==0 ){
            	 RedisTemplate<String, Integer> redisIntegertemplate=JedisConnectionUtil.getRedisTemplateKVStringInteger();
            	 invCnt=redisIntegertemplate.opsForValue().get(invCntKey);
            	 redisTemplate.opsForValue().set(invCntKey,invCnt);
            }
            
            Set<Object> psdInvSet= redisTemplate.opsForHash().keys(invProcessedKey);
            
            log.info("Invoice processed in LogGSTR1RunTimeErros.checkRestLogicForSaveRestCall for "+redisKey+" : "+ psdInvSet.size());
            
            if(psdInvSet !=null && psdInvSet.size()==invCnt){
            	log.info("Going to call GSTR1 save rest call from LogGSTR1RunTimeErros.checkRestLogicForSaveRestCall for : "+redisKey);
            	saveInvoceDetails(redisKey); 
            }
            
		}catch(Exception ex){
			log.error("Exception in LogGSTR1RunTimeErros.checkRestLogicForSaveRestCall() : "+ex.getMessage());
		}
		
	}
	
	public void pushInvoiceDetailsToredis(OutwardInvoiceDTO outwardInvoiceDTO,String errorCode) {
		try{
			 
			 String redisKey=outwardInvoiceDTO.getRedisKey();
			 
			 RedisTemplate<String,Object> redisTemplate=JedisConnectionUtil.getRedisTemplateKVStringObject();
			 
			 Set<TblSalesErrorInfo> errorList=null;
			 Set<InvoiceProcessDto> invProcessSet;
             Set<TblSalesErrorInfo> errorSet;
             
			 if(outwardInvoiceDTO.getLineItemList()!=null){
				 OutwardInvoiceModel outwardStagingDetail=outwardInvoiceDTO.getLineItemList().get(0);
				 String invStatusKey=redisKey+"_"+Constant.INVOICE_STATUS;
	             String invErrKey=redisKey+"_"+Constant.INVOICE_ERROR_DETAILS;
	             String invProcessedKey=redisKey+"_"+Constant.INVOICE_PSD_COUNT;
	             
	             log.info("Technical exception occured for invoice : "+outwardStagingDetail.getInvoiceKey());
	             
	             InvoiceProcessDto invProcessDto=new InvoiceProcessDto();
	             invProcessDto.setStatus(errorCode);
	             invProcessDto.setInvOrder(outwardStagingDetail.getInvOrder());
	             
	             redisTemplate.opsForHash().put(invStatusKey,invProcessDto.getInvOrder(),invProcessDto);
	             redisTemplate.opsForHash().put(invProcessedKey, invProcessDto.getInvOrder(),outwardStagingDetail.getInvoiceKey());
	             
				 errorList = outwardInvoiceDTO.getErrorList();

				TblSalesErrorInfo salesErrorInfo=ErrorActionUtility.getSalesTblErrorInfo(outwardStagingDetail,errorCode, null,"Technical Error", false,Constant.INVOICE);
				if(errorList==null){
					errorList=new HashSet();
				}
				errorList.add(salesErrorInfo);
				/*errorSet.addAll(errorList);
				redisTemplate.opsForHash().put(redisKey, invErrKey, errorSet);*/
				redisTemplate.opsForHash().put(invErrKey,invProcessDto.getInvOrder(),errorList);
				
				//decrementInvoiceCount(redisKey);
				checkRestLogicForSaveRestCall(redisKey);
			 }
			 
		}catch(Exception ex){
			log.error("Exception in LogGSTR1RunTimeErros.logErrorsInredis() : "+ex.getMessage());
		}
	}

}
