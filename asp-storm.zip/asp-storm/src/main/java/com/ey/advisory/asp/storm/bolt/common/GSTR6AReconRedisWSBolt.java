package com.ey.advisory.asp.storm.bolt.common;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.client.domain.ReconciliationStatusDTO;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.sun.jersey.api.client.ClientResponse;

public class GSTR6AReconRedisWSBolt extends CustomBaseRichBolt {

	private final Logger log = LoggerFactory.getLogger(getClass());
	
	private CustomOutputCollector collector;
	
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;	   		
	}

	@Override
	public void execute(Tuple input) {
		ReconciliationDTO reconciliationDTO = (ReconciliationDTO) input.getValue(0);
		log.info("In GSTR6AReconRedisWSBolt.execute() start");
		try{
	
		
        RedisTemplate<String,Object> redisTemplate=JedisConnectionUtil.getRedisTemplateKVStringObject();
        
        RedisTemplate<String, Integer> redisIntegertemplate=JedisConnectionUtil.getRedisTemplateKVStringInteger();
        
        String redisKey=reconciliationDTO.getRedisKey();
        System.out.println("redisKey****"+ redisKey);
        String invCntKey=redisKey+"_"+Constant.INVOICE_COUNT;
        String reconStatusKey=redisKey+"_"+Constant.RECON_FILING_STATUS;
        String invErrKey=redisKey+"_"+Constant.INVOICE_ERROR_DETAILS;
        
        ReconciliationStatusDTO reconStatusDTO = new ReconciliationStatusDTO(reconciliationDTO);
        
        
        if(reconStatusDTO !=null){
			  Set<ReconciliationStatusDTO> reconStatusSet;
			  //Set<TblPurchaseErrorInfo> errorSet;
              
              
          
              //RedisAtomicInteger count=new RedisAtomicInteger(invCntKey,redisTemplate.getConnectionFactory());
              RedisAtomicInteger count=new RedisAtomicInteger(invCntKey,redisIntegertemplate);
              System.out.println("Count****"+ count);
              redisTemplate.opsForHash().get(redisKey, reconStatusKey); 
              if(redisTemplate.opsForHash().get(redisKey, reconStatusKey) == null){
            	  reconStatusSet=new HashSet<ReconciliationStatusDTO>();
              }else{
            	  reconStatusSet=(Set<ReconciliationStatusDTO>) redisTemplate.opsForHash().get(redisKey, reconStatusKey);
              }
              reconStatusSet.add(reconStatusDTO);
              redisTemplate.opsForHash().put(redisKey, reconStatusKey,reconStatusSet);   
              
              Set<TblPurchaseErrorInfo> errorList = reconciliationDTO.getErrorList();
              
/*              if(redisTemplate.opsForHash().get(redisKey, invErrKey)==null){
            	  errorSet=new HashSet<TblPurchaseErrorInfo>();
              }else{
            	  errorSet=(Set<TblPurchaseErrorInfo>) redisTemplate.opsForHash().get(redisKey, invErrKey);
              }
              if(errorList!=null &&!errorList.isEmpty()){
            	  errorSet.addAll(errorList);
            	  redisTemplate.opsForHash().put(redisKey, invErrKey,errorSet);
              }*/
            
            	  if(count.intValue()==1){
                	  
            		  synchronized (count) {
					
                	  log.info("In GSTR6AReconRedisWSBolt.execute() inside Rest"+ count);
                	//Trigger web service to update invoice status and error details 
                	  //RestClientUtility restClientUtil = new RestClientUtility();
  					  //restClientUtil.callRestService(Constant.REDIS_INVOICE_CHANNEL);
  					  //restClientUtil.callRestServiceGstr2aRecon(redisKey);
                	  ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.RECONCILIATION_HOST, Constant.UPDATE_RECON_6_FILING_REST,reconciliationDTO.getGroupCode(), redisKey, Constant.VERB_TYPE_POST);
                	  if(response != null && response.getStatusInfo().getStatusCode() == 200){
                		  String responseStatus = response.getEntity(String.class);
                		  if(responseStatus.equalsIgnoreCase("Success")){
                		  log.info("In GSTR6AReconRedisWSBolt.execute() end success");
                		  }else{
                			  log.info("In GSTR6AReconRedisWSBolt.execute() end Failure");
                		  }
                	  }
            		 }
          			
                	  
            		         }
                  else{
                
                	  count.getAndSet(count.intValue()-1);
                	  log.info("After Detecting"+ count);
                    
                      
                  }
        }
        			  
        		}
		catch(Exception ex){			
			log.error("Error GSTR6AReconRedisWSBolt", ex);
			collector.customReportError(input, ex, "Exception in Bolt GSTR6AReconRedisWSBolt");
        }
		
		finally {
			collector.ack(input);
			collector.emit(new Values(reconciliationDTO));
			log.info("In GSTR6AReconRedisWSBolt.execute() end");
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		
	}

	
}
