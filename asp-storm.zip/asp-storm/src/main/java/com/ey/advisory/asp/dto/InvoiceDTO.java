package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.List;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.google.gson.annotations.SerializedName;

/**
 * This abstraction is added to support various DTOs in future
 * 
 * @author Mayank3.Kumar
 *
 */
public class InvoiceDTO implements Serializable{

	static final long serialVersionUID = 1L;
	
	@SerializedName("uk")
	private String redisKey;
	
	public String getRedisKey() {
		return redisKey;
	}
	public void setRedisKey(String redisKey) {
		this.redisKey = redisKey;
	}
}
