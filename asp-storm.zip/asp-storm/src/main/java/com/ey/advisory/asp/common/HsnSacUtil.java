package com.ey.advisory.asp.common;

import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.ProductMaster;
import com.ey.advisory.asp.dto.AnswerModuleDTO;
import com.ey.advisory.asp.master.domain.GlobalGSTRatesMasterI;
import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

/**
 * Class to store HsnSac related code.
 * @author Ashutosh.Srivastava
 *
 */
public class HsnSacUtil {

	private RedisTemplate<String, Object> redisTemplate;
	private static final Logger logger = LoggerFactory.getLogger(HsnSacUtil.class);
	private static Map<String, ProductMaster> productHsnSacMap = null;
	private static Set<String> hsnSacGlobalSet = null;

	public boolean checkGlobalHsnSac(final String hsnsacValue, final String groupCode) {

		getHSNSACDetailsfromRedis(groupCode);
		
		if(hsnSacGlobalSet==null) {
			logger.error("hsnSacGlobalSet is null, value not found in Redis/DB!! : "+hsnsacValue);
			return false;
		} else {
			return checkHSNSACInMasterTable(hsnSacGlobalSet, hsnsacValue);
		} 
	}

	public boolean checkProductHsnSac(final String hsnsacValue, final String groupCode, final String pan) {
		getHSNSACDetailsfromRedis(groupCode);

		if(productHsnSacMap==null) {
			logger.error("productHsnSacMap is null, value not found in Redis/DB!! : " +hsnsacValue);
			return false;
		} else if(isClientProvidedProductMasterTable(pan, groupCode) && !checkHSNSACInMasterTable(productHsnSacMap.keySet(), hsnsacValue)) {
			return loadAndCheckSpecificHSNSAC(hsnsacValue, groupCode, Constant.PRODUCT_MASTER_DETAILS);
		} 
		return true;
	}

	@SuppressWarnings("unchecked")
	private void getHSNSACDetailsfromRedis(final String groupCode) {
		if(redisTemplate==null) {
			redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();
		}
		if (hsnSacGlobalSet==null) {
			hsnSacGlobalSet = (Set<String>)(Set<?>)redisTemplate.opsForHash().keys(Constant.GLOBAL_MASTER_DETAILS);
			if(hsnSacGlobalSet != null)
			logger.debug("HSN Set size:"+hsnSacGlobalSet.size());
		}

		if (productHsnSacMap == null) {
			productHsnSacMap = (Map<String, ProductMaster>)redisTemplate.opsForHash().get(groupCode+"_"+Constant.REDIS_CACHE, Constant.PRODUCT_MASTER_DETAILS);
			if (productHsnSacMap == null) {
				if(Constant.SUCCESS.equalsIgnoreCase(getHsnSacDataFromTable(groupCode))){
					getHSNSACDetailsfromRedis(groupCode);
				}
			}
		}
	}



	private boolean checkHSNSACInMasterTable(Set<String> hsnSacSet, final String lineItemHsnSac){
		for (String hsnsac : hsnSacSet) {
		logger.debug("1.HSNSAC from REdis: "+hsnsac);
		logger.debug("1.HSNSAC from lineitem: "+lineItemHsnSac);
			if(hsnsac.startsWith(lineItemHsnSac)) {
				logger.debug("HSNSAC from REdis: "+hsnsac);
				logger.debug("HSNSAC from lineitem: "+lineItemHsnSac);
				return true;
			}
		}
		return false;
	}

	private boolean loadAndCheckSpecificHSNSAC(String hsnsac, final String groupCode, String tableName) {
		String hsnFound = "";
		ClientResponse response = null;
		try {
			response = new RestClientUtility()
					.getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
							Constant.LOAD_SPECIFIC_HSNSAC_REDIS, groupCode,hsnsac +"/"+tableName,
							Constant.VERB_TYPE_POST);
			if (response!=null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
				hsnFound = response.getEntity(String.class);
			}
		}
		catch (Exception e) {
			logger.error("Error in loadAndCheckSpecificHSNSAC, response : " + response, e);
		}
		return Constant.TRUE.equals(hsnFound);
	}

	private boolean isClientProvidedProductMasterTable(final String pan, final String groupCode){
		Map<String, AnswerModuleDTO> clientData = Utility.getClientOnBoardingDetailFromRedis(pan, groupCode);
		String answerId = null;

		if(clientData != null) {
			AnswerModuleDTO ansDTO = clientData.get(Constant.PRODUCT_MASTER_PROVIDED_QUE_ID);
			if(ansDTO!=null) {
				answerId = ansDTO.getAnswerId();
				logger.info("Client (PAN="+pan+") choice for ProductMaster Details (1=Optional, 2=Mandatory) : " + answerId);
			}
		}
		return Constant.PRODUCT_MASTER_PROVIDED_YES.equals(answerId);
	}

	private String getHsnSacDataFromTable(String groupCode) {
		String status = null;

		try {
			ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
					Constant.LOAD_HSNSAC_REDIS, groupCode, null, Constant.VERB_TYPE_POST);

			if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
				Gson gson = new Gson();
				status = gson.fromJson(response.getEntity(String.class), String.class);
			}
		} catch (Exception e) {
			logger.error("Error in getHsnSacDataFromTable : ", e);
		}
		return status;
	}
}
