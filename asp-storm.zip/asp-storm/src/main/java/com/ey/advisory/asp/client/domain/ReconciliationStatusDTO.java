package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;

public class ReconciliationStatusDTO implements Serializable {
	
	private static final long serialVersionUID = -5474991123453046027L;
	private static final Logger LOGGER = Logger.getLogger(ReconciliationStatusDTO.class);
	
	private int reconStatusId;
	
	private String tableKey;
	
	private String filingStatus;
	
	private boolean updateTaxLiability;
	
	private Set<ReconProcessDTO> reconProcessSet;

	public int getReconStatusId() {
		return reconStatusId;
	}

	public void setReconStatusId(int reconStatusId) {
		this.reconStatusId = reconStatusId;
	}

	public boolean isUpdateTaxLiability() {
		return updateTaxLiability;
	}

	public void setUpdateTaxLiability(boolean updateTaxLiability) {
		this.updateTaxLiability = updateTaxLiability;
	}

	public Set<ReconProcessDTO> getReconProcessSet() {
		return reconProcessSet;
	}

	public void setReconProcessSet(Set<ReconProcessDTO> reconProcessSet) {
		this.reconProcessSet = reconProcessSet;
	}
	
	public String getTableKey() {
		return tableKey;
	}

	public void setTableKey(String tableKey) {
		this.tableKey = tableKey;
	}

	
	public String getFilingStatus() {
		return filingStatus;
	}

	public void setFilingStatus(String filingStatus) {
		this.filingStatus = filingStatus;
	}

	public ReconciliationStatusDTO(){
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in ReconciliationStatusDTO ");
			}
	}
	
	public ReconciliationStatusDTO(ReconciliationDTO dto){
		if(dto != null){
			this.reconStatusId = dto.getReconStatusId();
			this.updateTaxLiability = dto.isUpdateTaxLiability();
			this.tableKey = dto.getTableKey();
			if(this.updateTaxLiability){
				for(ReconciliationDetailsDTO reconDet: dto.getGstr2A())
					reconProcessSet.add(new ReconProcessDTO(reconDet));
			}
		}
	}

}
