package com.ey.advisory.asp.storm.bolt.common;

import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Tuple;

import com.ey.advisory.asp.common.configs.ASPStormProperties;

/**
 * This abstraction enables implementing classes use CustomOutputCollector
 * @author Mayank3.Kumar
 *
 */
public abstract class CustomBaseRichBolt extends BaseRichBolt {
	
	@Override
	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		ASPStormProperties.setAllProperties(stormConf);
		CustomOutputCollector customOutputCollector = new CustomOutputCollector(collector);		
		this.prepare(stormConf,context,customOutputCollector);	
	}
	
	/**
	 * This method is equivalent to prepare() method of storm's BaseRichBolt.prepare() but uses CustomOutputCollector as param.
	 * @param stormConf
	 * @param context
	 * @param customOutputCollector
	 */
	public abstract void prepare(Map stormConf, TopologyContext context, CustomOutputCollector customOutputCollector);
	
}
