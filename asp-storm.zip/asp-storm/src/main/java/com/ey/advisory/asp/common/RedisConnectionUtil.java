package com.ey.advisory.asp.common;

import java.util.Properties;

import org.apache.storm.redis.common.config.JedisPoolConfig;

public class RedisConnectionUtil {
	
	JedisPoolConfig jedisPoolConfig;
	
	private JedisPoolConfig createJedisPoolConfig(){
		JedisPoolConfig jedisPoolConfig=null;
		try {
			Properties props=new Properties();
			props.load(RedisConnectionUtil.class.getResourceAsStream("/redis.properties"));
			
			String hostname = props.getProperty(Constant.REDIS_HOST);
			int port = Integer.parseInt(props.getProperty(Constant.REDIS_PORT));
			String password=props.getProperty(Constant.REDIS_PASSWORD);
			
			return new JedisPoolConfig.Builder()
	                .setHost(hostname).setPort(port).setPassword(password).build();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit(0);
		}
		return jedisPoolConfig;
	}
	public JedisPoolConfig getJedisPoolConfig(){
		if(jedisPoolConfig==null){
			jedisPoolConfig=createJedisPoolConfig();
		}
		return jedisPoolConfig;
	}
}
