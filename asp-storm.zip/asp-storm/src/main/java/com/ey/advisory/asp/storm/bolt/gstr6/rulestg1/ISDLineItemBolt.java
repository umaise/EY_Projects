package com.ey.advisory.asp.storm.bolt.gstr6.rulestg1;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.runtime.Globals;
import org.kie.api.runtime.KieSession;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.KnowledgeBaseFactory;
import org.kie.internal.definition.KnowledgePackage;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ProductMaster;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.dto.EntityModelDTO;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.KSessionUtility;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.AnswerModuleDTO;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.master.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleServiceImpl;
import com.ey.advisory.asp.storm.bolt.common.BoltBuilder;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.sun.jersey.api.client.ClientResponse;

/**
 * Author -Guru
 * @version 1.0
 * @since   31-05-2017
 */

public class ISDLineItemBolt extends BoltBuilder {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private CustomOutputCollector collector;
	EntityModel entityModel;
	private RedisTemplate<String, Object> redisTemplate;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private Gstr6ValidationRuleServiceImpl gstr6ValidationRuleService;
	//private Map<String, ProductMaster> productHsnSacMap = new HashMap<String, ProductMaster>();
	//private Map<String, GlobalGSTRatesMasterI> hsnSacGlobalMap = new HashMap<String, GlobalGSTRatesMasterI>();
	Set<String> hsnSacGlobalSet = null;
	private String groupCode = null;
	private String pan = null;

	/* public SaleRegTurnOverRuleBolt(Properties configs) {
        super(configs);
    }*/

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void prepare(Map stormConf, TopologyContext context,
			CustomOutputCollector collector) {
		this.collector = collector;
		gstr6ValidationRuleService = new Gstr6ValidationRuleServiceImpl();
		try {
			log.info("In ISDLineItemBolt.prepare() start");
			redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();
			if(log.isInfoEnabled())
				log.info("In ISDLineItemBolt.prepare() ends");

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}

	}
	@SuppressWarnings("unchecked")
	@Override
	public void execute(Tuple input) {
		Map<String, EntityModelDTO> entityMap = new HashMap<String, EntityModelDTO>();

		InwardInvoiceGstr6DTO inwardInvoiceDTO=null;
		LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();	
		try {

			inwardInvoiceDTO = (InwardInvoiceGstr6DTO) input.getValue(0);
			groupCode = inwardInvoiceDTO.getGroupCode();
			InwardInvoiceModel stgTbl = inwardInvoiceDTO.getLineItemList().get(0);
			Set<TblIsdErrorInfo> errorList = inwardInvoiceDTO.getErrorList();
			BigDecimal totalTaxAmount = new BigDecimal(30);

			log.info("In ISDLineItemBolt.execute() start");
			EntityModelDTO entityModelTable = null;
			pan = stgTbl.getSGSTIN().substring(2, 12);
			entityMap = (Map<String, EntityModelDTO>) redisTemplate.opsForHash()
					.get(inwardInvoiceDTO.getGroupCode()+"_"+Constant.REDIS_CACHE, Constant.ENTITY_KEY);
			
			if(entityMap == null){
				ClientResponse response = new RestClientUtility()
						.getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
								"asp-restapi.loadEntityDet", inwardInvoiceDTO.getGroupCode(), null,
								Constant.VERB_TYPE_POST);
			}

			if (entityMap != null) {
				entityModelTable = entityMap.get(pan);
			}
			if (entityModelTable == null) {
				ClientResponse response = new RestClientUtility()
						.getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
								"asp-restapi.getEntity", inwardInvoiceDTO.getGroupCode(),pan,
								Constant.VERB_TYPE_POST);
//				Gson gson = new Gson();
				Gson gson = new GsonBuilder().setDateFormat(Constant.DATE_FORMAT).create(); 
				if (response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
					entityModelTable = gson
							.fromJson(response.getEntity(String.class),
									EntityModelDTO.class);
				}
			}
			if (entityModelTable != null) {

				if (errorList == null) {
					errorList = new HashSet<TblIsdErrorInfo>();
				}else{
					errorList = inwardInvoiceDTO.getErrorList();
				}
				BigDecimal grossTurnover = entityModelTable.getGrossTurnOver();

				// BR_OUTWARD_5
				getMasterDetailsfromRedis(redisTemplate, inwardInvoiceDTO.getGroupCode());

				/*if (productHsnSacMap == null) {
					if(gstr6ValidationRuleService.getDataForHsnSac(inwardInvoiceDTO.getGroupCode()).equalsIgnoreCase(Constant.SUCCESS)){
						getMasterDetailsfromRedis(redisTemplate, inwardInvoiceDTO.getGroupCode());
					}
				}*/
				Set<String> globalHSNSACSet = new HashSet<>();
				Set<String> productHSNSACSet = new HashSet<>();
				//globalHSNSACSet.addAll(hsnSacGlobalMap.keySet());
				globalHSNSACSet.addAll(hsnSacGlobalSet);
				
				//productHSNSACSet.addAll(productHsnSacMap.keySet());

				
                InputStream fout = ISDLineItemBolt.class.getResourceAsStream("/GSTR6_LineItemValidation.ser");
                log.info("GSTR6_LineItemValidation.ser : "+fout);
    			ObjectInputStream oos = new ObjectInputStream(fout);

    			Collection<KnowledgePackage> knowledgePackages = (Collection<KnowledgePackage>) oos.readObject();
    			KieBaseConfiguration kBaseConfig = KnowledgeBaseFactory.newKnowledgeBaseConfiguration();
    			KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase(kBaseConfig);
    			kbase.addKnowledgePackages(knowledgePackages);
    			StatefulKnowledgeSession kSession = kbase.newStatefulKnowledgeSession();
    			    			
    			Globals globals = kSession.getGlobals();
    			globals.set("errorList", errorList);
				//kSession.setGlobal("errorList", errorList);
				//kSession.setGlobal("globalhsnSacSet", globalHSNSACSet);
				//kSession.setGlobal("producthsnSacSet", productHSNSACSet);
    			globals.set("grossTurnover", grossTurnover);
				//kSession.setGlobal("grossTurnover", grossTurnover);
				//kSession.setGlobal("saleRegTurnOverRuleBolt", this);

				for(InwardInvoiceModel stgTable : inwardInvoiceDTO.getLineItemList()) {

					/*Double cgStAmount=  stgTable.getCGSTAmount()==null? Constant.ZERO_DOUBLE: stgTable.getCGSTAmount();
					Double igStAmount=  stgTable.getIGSTAmount()==null? Constant.ZERO_DOUBLE: stgTable.getIGSTAmount();
					Double sgStAmount=  stgTable.getSGSTAmount()==null? Constant.ZERO_DOUBLE: stgTable.getSGSTAmount();

					stgTable.setCgstAmount(cgStAmount);
					stgTable.setIgstAmount(igStAmount);
					stgTable.setSgstAmount(sgStAmount);*/

					
					//totalTaxAmount = totalTaxAmount.add(stgTable.getIGSTAmount().add(stgTable.getSGSTAmount()).add(stgTable.getCGSTAmount()).add(stgTable.getCessAmountSpecific()));
							
					//kSession.setGlobal("totalTaxAmount", totalTaxAmount);
					kSession.insert(stgTable);
					kSession.fireAllRules();
					if ((inwardInvoiceDTO.getInvStatus() == null
							|| inwardInvoiceDTO.getInvStatus().equals(
									Constant.GSTR6_BR_STG1)) && stgTable.getItemStatus() != null) {
						inwardInvoiceDTO.setInvStatus(stgTable.getItemStatus());
					}
				}

				kSession.destroy();
			}
			// write an else with no details available
			if(errorList.size()>0){
				inwardInvoiceDTO.setErrorList(errorList);
			}

			collector.emit(input,new Values(inwardInvoiceDTO));

			log.info("Turn Over check complete");

		} catch (JsonSyntaxException ex) {
			log.error("Error ISDLineItemBolt", ex);
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);

		} catch (Exception ex1) {
			log.error("Error ISDLineItemBolt", ex1);
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}finally {
			collector.ack(input);
			log.info("In ISDLineItemBolt.execute() end");
		}

	}

	@SuppressWarnings("unchecked")
	private void getMasterDetailsfromRedis(RedisTemplate<String, Object> redisTemplate, String groupCode) {
		/*hsnSacGlobalMap = (Map<String, GlobalGSTRatesMasterI>) redisTemplate.opsForHash()
				.get(Constant.REDIS_CACHE, Constant.GLOBAL_MASTER_DETAILS);*/
		if (hsnSacGlobalSet==null) {
			hsnSacGlobalSet = (Set<String>)(Set<?>)redisTemplate.opsForHash().keys(Constant.GLOBAL_MASTER_DETAILS);
		}
		//productHsnSacMap = (Map<String, ProductMaster>)redisTemplate.opsForHash().get(groupCode+"_"+Constant.REDIS_CACHE, Constant.PRODUCT_MASTER_DETAILS);
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR1_Stream1, new Fields("inv"));
	}

	public boolean checkGlobalHsnSac(Set<String> globalhsnSacSet, String hsnsacValue) {
		if(!checkHSNSACInMasterTable(globalhsnSacSet, hsnsacValue)) {
			return loadAndCheckSpecificHSNSAC(hsnsacValue, Constant.GLOBAL_MASTER_DETAILS);
		} 
		return true;
	}

	public boolean checkProductHsnSac(Set<String> producthsnSacSet, String hsnsacValue) {
		if(!checkHSNSACInMasterTable(producthsnSacSet, hsnsacValue)) {
			return loadAndCheckSpecificHSNSAC(hsnsacValue, Constant.PRODUCT_MASTER_DETAILS);
		} 
		return true;
	}

	private boolean checkHSNSACInMasterTable(Set<String> hsnSacSet, final String lineItemHsnSac){
		for (String hsnsac : hsnSacSet) {
			if(hsnsac.startsWith(lineItemHsnSac)) {
				return true;
			}
		}
		return false;
	}
	
	private boolean loadAndCheckSpecificHSNSAC(String hsnsac, String tableName) {
		String hsnFound = "";
		ClientResponse response = null;
		try {
            response = new RestClientUtility()
				.getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
						Constant.LOAD_SPECIFIC_HSNSAC_REDIS, groupCode,hsnsac +"/"+tableName,
						Constant.VERB_TYPE_POST);
            if (response!=null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
			hsnFound = response.getEntity(String.class);
		}
        }
        catch (Exception e) {
            log.error("Error in loadAndCheckSpecificHSNSAC, response : " + response, e);
        }
		return hsnFound.equals(Constant.TRUE);
	}
	
	public boolean isClientProvidedProductMasterTable(){
		Map<String, AnswerModuleDTO> clientData = Utility.getClientOnBoardingDetailFromRedis(pan, groupCode);
		
		String answerId = clientData.get(Constant.PRODUCT_MASTER_PROVIDED_QUE_ID).getAnswerId();
		
		return answerId.equals(Constant.PRODUCT_MASTER_PROVIDED_YES);
	}
}


   