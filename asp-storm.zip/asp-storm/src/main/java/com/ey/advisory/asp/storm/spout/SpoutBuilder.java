package com.ey.advisory.asp.storm.spout;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;


public abstract class SpoutBuilder {
	
	public Properties configs = null;
	
	public SpoutBuilder(Properties configs){
		this.configs=configs;
	}
	
	/*public static Properties gststormConfig(){
		try{
			if(configs==null){
				configs.load(SpoutBuilder.class.getResourceAsStream("/asp-storm-config.properties"));
			}
		}catch(Exception ex){
			ex.printStackTrace();
			System.exit(0);
		}
		return configs;
	}*/
	
	public abstract KafkaSpout buildKafkaSpout(); 
}
