package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;

public class TblTdsErrorInfo implements Serializable{

	/**
	 * 
	 * @author BadariKrishna.SG
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer errorInfoID; 
	private String processStatus;
	private Integer tdsStagingID;
	private String invoiceNum;
	private String gstin;
	private String errorInfoCode;
	private String incidenceLevel;
	private String errorColumnName;
	private String errorDesc;
	private char isError;
	private boolean isProcessed;
	private Timestamp createDate;
	private String createdBy;
	private Timestamp updatedDate;
	public Integer getErrorInfoID() {
		return errorInfoID;
	}
	public void setErrorInfoID(Integer errorInfoID) {
		this.errorInfoID = errorInfoID;
	}
	public String getProcessStatus() {
		return processStatus;
	}
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	
	public Integer getTdsStagingID() {
		return tdsStagingID;
	}
	public void setTdsStagingID(Integer tdsStagingID) {
		this.tdsStagingID = tdsStagingID;
	}
	public String getInvoiceNum() {
		return invoiceNum;
	}
	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getErrorInfoCode() {
		return errorInfoCode;
	}
	public void setErrorInfoCode(String errorInfoCode) {
		this.errorInfoCode = errorInfoCode;
	}
	public String getIncidenceLevel() {
		return incidenceLevel;
	}
	public void setIncidenceLevel(String incidenceLevel) {
		this.incidenceLevel = incidenceLevel;
	}
	public String getErrorColumnName() {
		return errorColumnName;
	}
	public void setErrorColumnName(String errorColumnName) {
		this.errorColumnName = errorColumnName;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	
	public char getIsError() {
		return isError;
	}
	public void setIsError(char isError) {
		this.isError = isError;
	}
	public boolean isProcessed() {
		return isProcessed;
	}
	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}
	public Timestamp getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}
	public TblTdsErrorInfo(Integer tdsStagingID, String errorInfoCode, String errorDesc, String errorColumnName,
			String processStatus, boolean isProcessed, String invoiceNum, String gstin,String incidenceLevel, char isError) {
		this.tdsStagingID=tdsStagingID;
		this.errorInfoCode=errorInfoCode;
		this.errorDesc=errorDesc;
		this.errorColumnName=errorColumnName;
		this.processStatus=processStatus;
		this.isProcessed=isProcessed;
		this.invoiceNum = invoiceNum;
		this.gstin = gstin;
		this.incidenceLevel=incidenceLevel;
		this.isError = isError;
	}
	
	

}
