package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.SerializedName;

public class ReconciliationDetailsDrDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SerializedName("ID")
	private Long id;

	@SerializedName("SrNo")
	private Long srNo;

	@SerializedName("ISDRegisteredGSTIN")
	private String isdRegisteredGSTIN;

	@SerializedName("GSTINofSupplier")
	private String gstsinNofSupplier;

	@SerializedName("DocumentType")
	private String docType;

	@SerializedName("DocumentNo")
	private String docNo;

	@SerializedName("DocumentDate")
	private String docDate;

	@SerializedName("SAC")
	private String sac;

	@SerializedName("GSTINofReceiver")
	private String gstinOfReceiver;

	@SerializedName("ISDInvoicesDocumentNo")
	private String isdInvoices_DocNo;

	@SerializedName("ISDInvoiceDate")
	private String isdInvoiceDate;

	@SerializedName("IGST")
    private Double igst;

	@SerializedName("CGST")
	private Double cgst;

	@SerializedName("SGSTUTGST")
	private Double sgst_UTGST;

	@SerializedName("CESS")
	private Double cess;

	@SerializedName("ItcIGST")
	private Double itcIGST;

	@SerializedName("ItcCGST")
	private Double itcCGST;

	@SerializedName("ItcSGSTUTGST")
	private Double itcSGST_UTGST;

	@SerializedName("ItcCESS")
	private Double itcCESS;

	@SerializedName("fileID")
	private Long fileID;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSrNo() {
		return srNo;
	}

	public void setSrNo(Long srNo) {
		this.srNo = srNo;
	}

	public String getIsdRegisteredGSTIN() {
		return isdRegisteredGSTIN;
	}

	public void setIsdRegisteredGSTIN(String isdRegisteredGSTIN) {
		this.isdRegisteredGSTIN = isdRegisteredGSTIN;
	}

	public String getGstsinNofSupplier() {
		return gstsinNofSupplier;
	}

	public void setGstsinNofSupplier(String gstsinNofSupplier) {
		this.gstsinNofSupplier = gstsinNofSupplier;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocNo() {
		return docNo;
	}

	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}

	public String getDocDate() {
		return docDate;
	}

	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}

	public String getSac() {
		return sac;
	}

	public void setSac(String sac) {
		this.sac = sac;
	}

	public String getGstinOfReceiver() {
		return gstinOfReceiver;
	}

	public void setGstinOfReceiver(String gstinOfReceiver) {
		this.gstinOfReceiver = gstinOfReceiver;
	}

	public String getIsdInvoices_DocNo() {
		return isdInvoices_DocNo;
	}

	public void setIsdInvoices_DocNo(String isdInvoices_DocNo) {
		this.isdInvoices_DocNo = isdInvoices_DocNo;
	}

	public String getIsdInvoiceDate() {
		return isdInvoiceDate;
	}

	public void setIsdInvoiceDate(String isdInvoiceDate) {
		this.isdInvoiceDate = isdInvoiceDate;
	}

	public Double getIgst() {
		return igst;
	}

	public void setIgst(Double igst) {
		this.igst = igst;
	}

	public Double getCgst() {
		return cgst;
	}

	public void setCgst(Double cgst) {
		this.cgst = cgst;
	}

	public Double getSgst_UTGST() {
		return sgst_UTGST;
	}

	public void setSgst_UTGST(Double sgst_UTGST) {
		this.sgst_UTGST = sgst_UTGST;
	}

	public Double getCess() {
		return cess;
	}

	public void setCess(Double cess) {
		this.cess = cess;
	}

	public Double getItcIGST() {
		return itcIGST;
	}

	public void setItcIGST(Double itcIGST) {
		this.itcIGST = itcIGST;
	}

	public Double getItcCGST() {
		return itcCGST;
	}

	public void setItcCGST(Double itcCGST) {
		this.itcCGST = itcCGST;
	}

	public Double getItcSGST_UTGST() {
		return itcSGST_UTGST;
	}

	public void setItcSGST_UTGST(Double itcSGST_UTGST) {
		this.itcSGST_UTGST = itcSGST_UTGST;
	}

	public Double getItcCESS() {
		return itcCESS;
	}

	public void setItcCESS(Double itcCESS) {
		this.itcCESS = itcCESS;
	}

	public Long getFileID() {
		return fileID;
	}

	public void setFileID(Long fileID) {
		this.fileID = fileID;
	}
	

	
}
