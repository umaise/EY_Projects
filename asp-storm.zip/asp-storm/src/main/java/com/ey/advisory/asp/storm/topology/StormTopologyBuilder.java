package com.ey.advisory.asp.storm.topology;

import java.util.Properties;

import org.apache.storm.redis.common.config.JedisPoolConfig;
import org.apache.storm.topology.TopologyBuilder;

/**
* StormTopologyBuilder is the abstract base class for all data pipelines
* which allows the segregation of data pipelines based on rule stages
* into the implementing subclasses containing Spouts and Bolts related
* to the pipeline. 
*
* @author  Siddharth Pahuja
* @version 1.0
* @since   06-03-2017
*/

public abstract class StormTopologyBuilder {
	
	protected Properties configs;
	//protected JedisPoolConfig jedisPoolConfig;
	
	public StormTopologyBuilder(Properties configs){
		this.configs = configs;
	}
	
//	public StormTopologyBuilder(Properties configs, JedisPoolConfig jedisPoolConfig){
//		this.configs = configs;
//		this.jedisPoolConfig = jedisPoolConfig;
//	}
	
	/*
	 * set Spouts and Bolts for the specific Data pipeline
	 */
	public abstract void buildDataPipeline(TopologyBuilder builder);

}
