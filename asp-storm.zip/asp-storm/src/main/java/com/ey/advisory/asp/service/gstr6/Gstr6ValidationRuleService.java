package com.ey.advisory.asp.service.gstr6;

import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;

public interface Gstr6ValidationRuleService {
	
	public InwardInvoiceGstr6DTO executeGSTR6ITCValidationRules(InwardInvoiceGstr6DTO inwardInvoiceDTO);

	String getDataForHsnSac(String groupCode);
}
