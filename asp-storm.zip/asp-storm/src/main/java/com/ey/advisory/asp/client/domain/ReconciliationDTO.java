package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.google.gson.annotations.SerializedName;

public class ReconciliationDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@SerializedName("uk")
	private String redisKey;

	@SerializedName("tbl")
	private String tableKey;
	
	@SerializedName("reconStatusId")
	private int reconStatusId;
	
	@SerializedName("PR")
	private List<ReconciliationDetailsDTO> purchaseRegister;
	
	@SerializedName("GSTR2A")
	private List<ReconciliationDetailsDTO> gstr2A;
	
	@SerializedName("DR")
	private List<ReconciliationDetailsDrDTO> distributionRegister;
	
	private Double purchaseRegisterTaxAmount;
	
	private Double gstr2aTaxAmount;
	
	private Double purchaseRegisterITCAmount;
	
	private Double gstr2aITCAmount;
	
	private Double dRITCAmount;
	
	private Double totalITCAmount;
	
	private String filingStatus;
	
	private boolean updateTaxLiability;
	
	@SerializedName("clientRes")
	private String clientResponse;
	
	@SerializedName("drAvailable")
	private String drAvailable;
	
	private String filingRecordType;
	
	private List<String> purchaseGSTINList;
	
	private boolean purchasePresentForPAN;
	
	private Set<TblPurchaseErrorInfo> errorList;
	
	private String groupCode;
	
	@SerializedName("taxPeriod")
	private String taxPeriod; 

	
	
	public String getTableKey() {
		return tableKey;
	}

	public void setTableKey(String tableKey) {
		this.tableKey = tableKey;
	}

	public List<ReconciliationDetailsDTO> getPurchaseRegister() {
		return purchaseRegister;
	}

	public void setPurchaseRegister(List<ReconciliationDetailsDTO> purchaseRegister) {
		this.purchaseRegister = purchaseRegister;
	}

	public List<ReconciliationDetailsDTO> getGstr2A() {
		return gstr2A;
	}

	public void setGstr2A(List<ReconciliationDetailsDTO> gstr2a) {
		gstr2A = gstr2a;
	}

	public Double getPurchaseRegisterTaxAmount() {
		return purchaseRegisterTaxAmount;
	}

	public void setPurchaseRegisterTaxAmount(Double purchaseRegisterTaxAmount) {
		this.purchaseRegisterTaxAmount = purchaseRegisterTaxAmount;
	}

	public Double getGstr2aTaxAmount() {
		return gstr2aTaxAmount;
	}

	public void setGstr2aTaxAmount(Double gstr2aTaxAmount) {
		this.gstr2aTaxAmount = gstr2aTaxAmount;
	}

	public Set<TblPurchaseErrorInfo> getErrorList() {
		return errorList;
	}

	public void setErrorList(Set<TblPurchaseErrorInfo> errorList) {
		this.errorList = errorList;
	}

	public String getFilingStatus() {
		return filingStatus;
	}

	public void setFilingStatus(String filingStatus) {
		this.filingStatus = filingStatus;
	}


	public String getFilingRecordType() {
		return filingRecordType;
	}

	public void setFilingRecordType(String filingRecordType) {
		this.filingRecordType = filingRecordType;
	}

	public List<String> getPurchaseGSTINList() {
		return purchaseGSTINList;
	}

	public void setPurchaseGSTINList(List<String> purchaseStagingLineItems) {
		this.purchaseGSTINList = purchaseStagingLineItems;
	}

	public Double getTotalITCAmount() {
		return totalITCAmount;
	}

	public void setTotalITCAmount(Double totalITCAmount) {
		this.totalITCAmount = totalITCAmount;
	}

	public boolean isPurchasePresentForPAN() {
		return purchasePresentForPAN;
	}

	public void setPurchasePresentForPAN(boolean purchasePresentForPAN) {
		this.purchasePresentForPAN = purchasePresentForPAN;
	}

	public String getRedisKey() {
		return redisKey;
	}

	public void setRedisKey(String redisKey) {
		this.redisKey = redisKey;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}



	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getClientResponse() {
		return clientResponse;
	}

	public void setClientResponse(String clientResponse) {
		this.clientResponse = clientResponse;
	}

	public String getDrAvailable() {
		return drAvailable;
	}

	public void setDrAvailable(String drAvailable) {
		this.drAvailable = drAvailable;
	}

	public List<ReconciliationDetailsDrDTO> getDistributionRegister() {
		return distributionRegister;
	}

	public void setDistributionRegister(List<ReconciliationDetailsDrDTO> distributionRegister) {
		this.distributionRegister = distributionRegister;
	}

	public Double getPurchaseRegisterITCAmount() {
		return purchaseRegisterITCAmount;
	}

	public void setPurchaseRegisterITCAmount(Double purchaseRegisterITCAmount) {
		this.purchaseRegisterITCAmount = purchaseRegisterITCAmount;
	}

	public Double getGstr2aITCAmount() {
		return gstr2aITCAmount;
	}

	public void setGstr2aITCAmount(Double gstr2aITCAmount) {
		this.gstr2aITCAmount = gstr2aITCAmount;
	}

	public Double getdRITCAmount() {
		return dRITCAmount;
	}

	public void setdRITCAmount(Double dRITCAmount) {
		this.dRITCAmount = dRITCAmount;
	}

	public int getReconStatusId() {
		return reconStatusId;
	}

	public void setReconStatusId(int reconStatusId) {
		this.reconStatusId = reconStatusId;
	}

	public boolean isUpdateTaxLiability() {
		return updateTaxLiability;
	}

	public void setUpdateTaxLiability(boolean updateTaxLiability) {
		this.updateTaxLiability = updateTaxLiability;
	}
	
	
}
