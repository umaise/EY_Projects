package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

public class ItemMaster implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer itemID;
	private String rGSTIN;
	private String itemCode;
	private String description;
	private String category;
	private String hSNSAC;
	private Character nonCreditable;
	private Character reverseCharge;
	private Character isTDS;
	private Character isExempt;
	private String iTCEligibility;
	private String notificationNumber;
	private Date notificationDate;
	private Date effectiveDate;
	private String serialNumber;
	private Double iGSTRt;
	private Double cGSTRt;
	private Double sGSTRt;
	private Double utGSTRt;
	private Double cessRt;
	private Double cESSRtAdValerom;
	private Double CESSRtAdValerom1;
	private String aDD1;
	private String aDD2;
	private String aDD3;
	private String aDD4;
	private String aDD5;
	public Integer getItemID() {
		return itemID;
	}
	public void setItemID(Integer itemID) {
		this.itemID = itemID;
	}
	public String getrGSTIN() {
		return rGSTIN;
	}
	public void setrGSTIN(String rGSTIN) {
		this.rGSTIN = rGSTIN;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String gethSNSAC() {
		return hSNSAC;
	}
	public void sethSNSAC(String hSNSAC) {
		this.hSNSAC = hSNSAC;
	}
	public Character getNonCreditable() {
		return nonCreditable;
	}
	public void setNonCreditable(Character nonCreditable) {
		this.nonCreditable = nonCreditable;
	}
	public Character getReverseCharge() {
		return reverseCharge;
	}
	public void setReverseCharge(Character reverseCharge) {
		this.reverseCharge = reverseCharge;
	}
	public Character getIsTDS() {
		return isTDS;
	}
	public void setIsTDS(Character isTDS) {
		this.isTDS = isTDS;
	}
	public Character getIsExempt() {
		return isExempt;
	}
	public void setIsExempt(Character isExempt) {
		this.isExempt = isExempt;
	}
	public String getiTCEligibility() {
		return iTCEligibility;
	}
	public void setiTCEligibility(String iTCEligibility) {
		this.iTCEligibility = iTCEligibility;
	}
	public String getNotificationNumber() {
		return notificationNumber;
	}
	public void setNotificationNumber(String notificationNumber) {
		this.notificationNumber = notificationNumber;
	}
	public Date getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public Double getiGSTRt() {
		return iGSTRt;
	}
	public void setiGSTRt(Double iGSTRt) {
		this.iGSTRt = iGSTRt;
	}
	public Double getcGSTRt() {
		return cGSTRt;
	}
	public void setcGSTRt(Double cGSTRt) {
		this.cGSTRt = cGSTRt;
	}
	public Double getsGSTRt() {
		return sGSTRt;
	}
	public void setsGSTRt(Double sGSTRt) {
		this.sGSTRt = sGSTRt;
	}
	public Double getUtGSTRt() {
		return utGSTRt;
	}
	public void setUtGSTRt(Double utGSTRt) {
		this.utGSTRt = utGSTRt;
	}
	public Double getCessRt() {
		return cessRt;
	}
	public void setCessRt(Double cessRt) {
		this.cessRt = cessRt;
	}
	public Double getcESSRtAdValerom() {
		return cESSRtAdValerom;
	}
	public void setcESSRtAdValerom(Double cESSRtAdValerom) {
		this.cESSRtAdValerom = cESSRtAdValerom;
	}
	public Double getCESSRtAdValerom1() {
		return CESSRtAdValerom1;
	}
	public void setCESSRtAdValerom1(Double cESSRtAdValerom1) {
		CESSRtAdValerom1 = cESSRtAdValerom1;
	}
	public String getaDD1() {
		return aDD1;
	}
	public void setaDD1(String aDD1) {
		this.aDD1 = aDD1;
	}
	public String getaDD2() {
		return aDD2;
	}
	public void setaDD2(String aDD2) {
		this.aDD2 = aDD2;
	}
	public String getaDD3() {
		return aDD3;
	}
	public void setaDD3(String aDD3) {
		this.aDD3 = aDD3;
	}
	public String getaDD4() {
		return aDD4;
	}
	public void setaDD4(String aDD4) {
		this.aDD4 = aDD4;
	}
	public String getaDD5() {
		return aDD5;
	}
	public void setaDD5(String aDD5) {
		this.aDD5 = aDD5;
	}

	

}
