package com.ey.advisory.asp.storm.bolt.common;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RedisTemplateUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.exceptions.RESTCallFailureException;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleService;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleServiceImpl;

/**
 * Author -Guru
 * @version 1.0
 * @since   31-05-2017
 */
public class GSTR6RedisWSBolt extends CustomBaseRichBolt {
	
	
	private static final long serialVersionUID = -463916378613289230L;

	private CustomOutputCollector collector;
	
	private Gstr6ValidationRuleService ValidationRuleService;
	
	private RedisTemplate<String, Object> redisTemplate;

	 //private Integer count=0;
	 private final Logger log = LoggerFactory.getLogger(getClass());
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		ValidationRuleService = new Gstr6ValidationRuleServiceImpl();	
		RedisTemplateUtil<String, Object> redisTemplateUtil= new RedisTemplateUtil<String, Object>();
        redisTemplate=JedisConnectionUtil.getRedisTemplateKVStringObject();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(Tuple input) {
		
		log.info("In GSTR6RedisWSBolt.execute() start");
		
		InwardInvoiceGstr6DTO inwardInvoiceDTO = (InwardInvoiceGstr6DTO) input.getValue(0);
		LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();	
        String redisKey=inwardInvoiceDTO.getRedisKey();
        //String invCntKey=redisKey+"_"+Constant.INVOICE_COUNT;
        String invStatusKey=redisKey+"_"+Constant.INVOICE_STATUS;
        String invErrKey=redisKey+"_"+Constant.INVOICE_ERROR_DETAILS;
        String invProcessedKey=redisKey+"_"+Constant.INVOICE_PSD_COUNT;
        
        

        InwardInvoiceModel inwardStagingDetail=inwardInvoiceDTO.getLineItemList().get(0);
        log.info("rediskey : " + redisKey + " InvOrder : "+ inwardStagingDetail.getInvOrder());
        
        //Integer count=Integer.parseInt(jedis.hmget(redisKey, invCntKey).get(0));
        
		try{
			  Set<InvoiceProcessDto> invProcessSet = new HashSet<>();
              
              if(inwardInvoiceDTO != null && inwardInvoiceDTO.getLineItemList() != null && !inwardInvoiceDTO.getLineItemList().isEmpty()){
            	  log.info("inwardInvoiceDTO.getLineItemList() list size - " +inwardInvoiceDTO.getLineItemList().size());	
	        	for(InwardInvoiceModel lineItem : inwardInvoiceDTO.getLineItemList()){
	        		
	        		InvoiceProcessDto invProcessDto = new InvoiceProcessDto(lineItem.getDocumentNo(), lineItem.getDocumentDate(), lineItem.getTaxPeriod(), inwardStagingDetail.getTableType(), inwardInvoiceDTO.getInvStatus(),
	        				lineItem.getInvOrder(), lineItem.getSGSTIN(), lineItem.getCGSTIN(),	inwardStagingDetail.getSubCategory(), lineItem.getEligibilityIndicator(),lineItem.getAvailableCESS(), 
	        				lineItem.getAvailableCGST(), lineItem.getAvailableIGST(), lineItem.getAvailableSGST(), lineItem.getLineNumber());
	        		
	        		invProcessSet.add(invProcessDto);
	        		
	        		
	        	}
	        	
	        	redisTemplate.opsForHash().put(invStatusKey,inwardStagingDetail.getInvOrder(),invProcessSet);
	        	redisTemplate.opsForHash().put(invProcessedKey,inwardStagingDetail.getInvOrder(),inwardStagingDetail.getInvOrder());
	        }
              
              Set<TblIsdErrorInfo> errorList=inwardInvoiceDTO.getErrorList();
              
              if(errorList!=null && !errorList.isEmpty()){
            	 // for(TblIsdErrorInfo errInfo:errorList){
            		  redisTemplate.opsForHash().put(invErrKey,inwardStagingDetail.getInvOrder(),errorList);
              	//}
            	  
              }
            	  
              
               
              
        }catch(Exception ex){
        	  log.info(ex.getMessage());
        	  logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
              collector.customReportError(input, ex, "Exception in Bolt GSTR6RedisWSBolt");
        }
		finally {
		collector.ack(input);
		//collector.emit(input, new Values(inwardInvoiceDTO));
		log.info("In GSTR6RedisWSBolt.execute() end");
		}
	}
	
	@Override
	public void cleanup() {
		// TODO Auto-generated method stub
		super.cleanup();
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("gstr6"));
	}
//rule 1 bolt
	
}


