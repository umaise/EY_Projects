package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.google.gson.annotations.SerializedName;

public class InvoiceProcessDto implements Serializable {
	private static final long serialVersionUID = -5474991306453046027L;
	private String docNum;
	private Object documentDate;
	private String taxperiod;
	private String tableType;
	private String status;
	private Integer invOrder;
	private String sGstin;
	private String cGstin;
	private String subCategory;
	private String eligibilityIndicator;
	private BigDecimal availableCESS;
    private BigDecimal availableCGST;
    private BigDecimal availableIGST;
    private BigDecimal availableSGST;
	private String originalDocNo;
	private String eligibleIndic;
	private String docType;
	private String invKey;
	private int lineNumber;
	private String orgCRDocNo;
	private String orgCRDocDate;


	
	public String getInvKey() {
		return invKey;
	}
	public void setInvKey(String invKey) {
		this.invKey = invKey;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getOriginalDocNo() {
		return originalDocNo;
	}
	public void setOriginalDocNo(String originalDocNo) {
		this.originalDocNo = originalDocNo;
	}
	public String getEligibleIndic() {
		return eligibleIndic;
	}
	public void setEligibleIndic(String eligibleIndic) {
		this.eligibleIndic = eligibleIndic;
	}
    
    public InvoiceProcessDto(){}
    
    public InvoiceProcessDto(String docNum, Object documentDate, String taxperiod,String tableType,String status,Integer invOrder,String sGstin,String cGstin,
    		String subCategory,String eligibilityIndicator,BigDecimal availableCESS,BigDecimal availableCGST,BigDecimal availableIGST,BigDecimal availableSGST, int lineNumber){
    	this.docNum = docNum;
    	this.documentDate = documentDate;
    	this.taxperiod = taxperiod;
    	this.tableType = tableType;
    	this.status = status;
    	this.invOrder = invOrder;
    	this.sGstin = sGstin;
    	this.cGstin = cGstin;
    	this.subCategory = subCategory;
    	this.eligibilityIndicator = eligibilityIndicator;
    	this.availableCESS = availableCESS;
    	this.availableIGST = availableIGST;
    	this.availableCGST = availableCGST;
    	this.availableSGST = availableSGST;
    	this.lineNumber = lineNumber;
    	}
    
    
	public Integer getInvOrder() {
		return invOrder;
	}
	public void setInvOrder(Integer invOrder) {
		this.invOrder = invOrder;
	}
	public String getDocNum() {
		return docNum;
	}
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}
	public Object getDocumentDate() {
		return documentDate;
	}
	public void setDocumentDate(Object documentDate) {
		this.documentDate = documentDate;
	}
	public String getTaxperiod() {
		return taxperiod;
	}
	public void setTaxperiod(String taxperiod) {
		this.taxperiod = taxperiod;
	}
	public String getTableType() {
		return tableType;
	}
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    public String getsGstin() {
        return sGstin;
    }
    public void setsGstin(String sGstin) {
        this.sGstin = sGstin;
    }
    public String getcGstin() {
        return cGstin;
    }
    public void setcGstin(String cGstin) {
        this.cGstin = cGstin;
    }
    public String getSubCategory() {
        return subCategory;
    }
    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }
	public String getEligibilityIndicator() {
		return eligibilityIndicator;
	}
	public void setEligibilityIndicator(String eligibilityIndicator) {
		this.eligibilityIndicator = eligibilityIndicator;
	}
	public BigDecimal getAvailableCESS() {
		return availableCESS;
	}
	public void setAvailableCESS(BigDecimal availableCESS) {
		this.availableCESS = availableCESS;
	}
	public BigDecimal getAvailableCGST() {
		return availableCGST;
	}
	public void setAvailableCGST(BigDecimal availableCGST) {
		this.availableCGST = availableCGST;
	}
	public BigDecimal getAvailableIGST() {
		return availableIGST;
	}
	public void setAvailableIGST(BigDecimal availableIGST) {
		this.availableIGST = availableIGST;
	}
	public BigDecimal getAvailableSGST() {
		return availableSGST;
	}
	public void setAvailableSGST(BigDecimal availableSGST) {
		this.availableSGST = availableSGST;
	}
	public int getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public String getOrgCRDocNo() {
		return orgCRDocNo;
	}
	public void setOrgCRDocNo(String orgCRDocNo) {
		this.orgCRDocNo = orgCRDocNo;
	}
	public String getOrgCRDocDate() {
		return orgCRDocDate;
	}
	public void setOrgCRDocDate(String orgCRDocDate) {
		this.orgCRDocDate = orgCRDocDate;
	}
	
	
}
