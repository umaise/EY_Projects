package com.ey.advisory.asp.master.domain;

import java.io.Serializable;




public class ErrorMasterDto implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    //private String ruleID;

    private String errorInfoCode;
    private String errorInfoDesc;
    private char isError;


    /*	public String getRuleID() {
		return ruleID;
	}
	public void setRuleID(String ruleID) {
		this.ruleID = ruleID;
	}*/

    public String getErrorInfoCode() {
        return errorInfoCode;
    }
    public void setErrorInfoCode(String errorInfoCode) {
        this.errorInfoCode = errorInfoCode;
    }

    public String getErrorInfoDesc() {
        return errorInfoDesc;
    }
    public void setErrorInfoDesc(String errorInfoDesc) {
        this.errorInfoDesc = errorInfoDesc;
    }

    public char getIsError() {
        return isError;
    }
    public void setIsError(char isError) {
        this.isError = isError;
    }

}