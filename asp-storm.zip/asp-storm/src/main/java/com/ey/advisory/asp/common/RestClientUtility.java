package com.ey.advisory.asp.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.common.configs.ASPStormProperties;
import com.ey.advisory.asp.exceptions.RESTCallFailureException;
import com.github.rholder.retry.RetryException;
import com.github.rholder.retry.Retryer;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.github.rholder.retry.WaitStrategies;
import com.google.common.base.Predicates;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lmax.disruptor.WaitStrategy;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import clojure.main;


/**
 * @author Smruti.Pradhan
 *This utilty class is to communicate to rest Api from storm
 */
public class RestClientUtility {

	public Properties restConfig;
	private final Logger log = LoggerFactory.getLogger(getClass());	 	
	private int initalTIME=1000;
	private int maxTIME=10000;
	private int numberRETRY=5;
	Set<TblSalesErrorInfo> errorList = new HashSet<TblSalesErrorInfo>();
	OutwardInvoiceModel outwardInvoiceModel;

	public RestClientUtility() {
		restConfig = new Properties();
		try {
//			restConfig.load(RestClientUtility.class
//					.getResourceAsStream("/rest-config.properties"));
			restConfig = ASPStormProperties.getAllProperties();
			this.initalTIME = Integer.parseInt(restConfig.getProperty(Constant.ASP_InitalTIME_MS));
			this.maxTIME = Integer.parseInt(restConfig.getProperty(Constant.ASP_MaxTIME_MS));
			this.numberRETRY = Integer.parseInt(restConfig.getProperty(Constant.ASP_MAX_RETRY));		
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	
	public void callRestServiceJersey(String redisInvoiceKey, String groupCode,String hostName) throws RESTCallFailureException {
	
	ClientResponse response = null;
	String host = restConfig.getProperty(hostName);
	if(host != null ){
		
			Client client = Client.create();
			WebResource webResource = client.resource(host);
			WebResource.Builder builder = webResource.accept(MediaType.APPLICATION_JSON);
			builder.type(MediaType.APPLICATION_JSON);
			builder.header(Constant.TENANT_CODE, groupCode);		
			try{
				response = builder.post(ClientResponse.class, redisInvoiceKey);
				
			}catch(ClientHandlerException e){
				log.error("RestClientUtility: saveInvoice ERROR",e);				
			}
			if(response == null || response.getStatus() != 200){
				
				RESTRetryerJersey retryTask = new RESTRetryerJersey(builder, "POST", redisInvoiceKey, ClientResponse.class,groupCode);
				Retryer<Boolean> retrier = RetryerBuilder.<Boolean>newBuilder()
			            .retryIfExceptionOfType(RESTCallFailureException.class)
			            .retryIfRuntimeException()
			            .withWaitStrategy(WaitStrategies.exponentialWait(initalTIME,maxTIME, TimeUnit.MILLISECONDS))
			            .withStopStrategy(StopStrategies.stopAfterAttempt(numberRETRY))
			            .build();

				try {
					retrier.call(retryTask);
				} catch (RetryException e) {
					log.error("RetryException while retrying : ",e);
					throw new RESTCallFailureException();
				    //e.printStackTrace();
				} catch (ExecutionException e) {
					log.error("ExecutionException while retrying : ",e.getCause());
					throw new RESTCallFailureException();
				    //e.printStackTrace();
				}
			}
		
	  }	
			log.info("End Rest Service");
	}

	/*public void callRestService(String redisInvoiceKey, String groupCode) throws RESTCallFailureException {
		try {
			if(log.isInfoEnabled())
			log.info("Start Rest Service");
			URL url = new URL(restConfig.getProperty(Constant.REST_HOST));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty(Constant.TENANT_CODE, groupCode);

			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(redisInvoiceKey);
			out.flush();			
			
			if(returnOnSuccess(conn,redisInvoiceKey).equals("FAILURE")){
				throw new RESTCallFailureException();
			}
			
			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED && conn.getResponseCode() != HttpURLConnection.HTTP_OK  ) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}
			
			RESTRetryer retryTask = new RESTRetryer(conn, redisInvoiceKey);
			Retryer<Boolean> retrier = RetryerBuilder.<Boolean>newBuilder()
		            .retryIfExceptionOfType(RESTCallFailureException.class)
		            .retryIfRuntimeException()
		            .withWaitStrategy(WaitStrategies.exponentialWait(initalTIME,maxTIME, TimeUnit.MILLISECONDS))
		            .withStopStrategy(StopStrategies.stopAfterAttempt(numberRETRY))
		            .build();

			try {
				retrier.call(retryTask);
			} catch (RetryException e) {
				log.error("RetryException while retrying : ",e);
				throw new RESTCallFailureException();
			    //e.printStackTrace();
			} catch (ExecutionException e) {
				log.error("ExecutionException while retrying : ",e.getCause());
				throw new RESTCallFailureException();
			    //e.printStackTrace();
			}


			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");

			while ((output = br.readLine()) != null) {
				//System.out.println(output);
				if(log.isInfoEnabled())
				log.info("Rest Service Response: "+output);
			}

			conn.disconnect();

		} catch (MalformedURLException e) {
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} catch (IOException e) {
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} 
		log.info("End Rest Service");

	}
*/
	
	
	
	/*public void callRestServiceGstr2(String redisInvoiceKey, String groupCode) {
		try {
			if(log.isInfoEnabled())
			log.info("Start Rest Service");
			URL url = new URL(restConfig.getProperty(Constant.REST_HOST_GSTR2));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
			conn.setRequestProperty(Constant.TENANT_CODE, groupCode);

			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(redisInvoiceKey);
			out.flush();

			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED && conn.getResponseCode() != HttpURLConnection.HTTP_OK  ) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");

			while ((output = br.readLine()) != null) {
				//System.out.println(output);
				if(log.isInfoEnabled())
				log.info("Rest Service Response: "+output);
			}

			conn.disconnect();

		} catch (MalformedURLException e) {
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} catch (IOException e) {
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} catch(Exception e){
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();
		}
		if(log.isInfoEnabled())
		log.info("End Rest Service");

	}
	
*/	
	/**
	 * This utility method is used to call App rest layer
	 * @param gstr1Data
	 */
	public void callGSTR1RestService(String gstr1Data) {

		/*try {

			Client client = Client.create();

			WebResource webResource = client
					.resource(restConfig.getProperty(Constant.ASP_REST_HOST));

			ClientResponse response = webResource.type("application/json;charset=UTF-8")
					.post(ClientResponse.class, gstr1Data);
			client.

			if (response.getStatus() != 201) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			System.out.println("Output from Server .... \n");
			String output = response.getEntity(String.class);
			System.out.println(output);

		} catch (Exception e) {

			e.printStackTrace();

		}*/
		log.info("entering to execute");
		try {
			
			 JsonParser parser = new JsonParser();
	            JsonArray jsonArray = parser.parse(gstr1Data).getAsJsonArray();
	      
	            JsonObject jsonObj=jsonArray.get(0).getAsJsonObject();
	            String groupCode=jsonObj.get("groupCode").getAsString();
	            //jsonObj.remove("groupCode");
	        if(log.isInfoEnabled())
			log.info("Start Rest Service");
			URL url = new URL(restConfig.getProperty(Constant.ASP_REST_HOST));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
			conn.setRequestProperty(Constant.TENANT_CODE, groupCode);
			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(jsonArray.toString());
			out.flush();
			if(out!=null) {
				out.close();
			}

			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED && conn.getResponseCode() != HttpURLConnection.HTTP_OK  ) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;

			while ((output = br.readLine()) != null) {
				if(log.isInfoEnabled())
				log.info("Rest Service Response: "+output);
			}
			
			if(br!=null) {
				br.close();
			}
			
			conn.disconnect();

		} catch (MalformedURLException e) {
			if(log.isDebugEnabled())
			log.debug("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} catch (IOException e) {
			if(log.isDebugEnabled())
			log.debug("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} catch(Exception e){
			if(log.isDebugEnabled())
			log.debug("Error in Rest service", e.getMessage());
			e.printStackTrace();
		} 
		if(log.isDebugEnabled())
		log.info("End Rest Service");
		 
	}


	/*
	 * Utility Method to call Rest Service with hostName, restEndpoint, payload, verbType
	 * 
	 * hostname: From rest-config.properties - includes host and port
	 * restEndpoint: From rest-config.properties - includes rest Endpoint Url
	 * payload: JSON String
	 * verbType: GET, POST	
	 */

	public ClientResponse getRestServiceResponse(String hostName, String restEndpoint, String groupCode, String payLoad, String verbType){

		ClientResponse response = null;
		String host = restConfig.getProperty(hostName);
		String restUrl = restConfig.getProperty(restEndpoint);
		if(host != null && StringUtils.isNotEmpty(restUrl)){
			try{

				Client client = Client.create();

				WebResource webResource = client.resource(host + restUrl);
				WebResource.Builder builder = webResource.accept(MediaType.APPLICATION_JSON);
				builder.type(MediaType.APPLICATION_JSON);
				builder.header(Constant.TENANT_CODE, groupCode);

				if("POST".equalsIgnoreCase(verbType)){
					response = builder.post(ClientResponse.class, payLoad);
				}else if("GET".equalsIgnoreCase(verbType)){
					response = builder.get(ClientResponse.class);
				}
			}catch(Exception e){
			    log.error("Error in getRestServiceResponse, url : " + hostName+restEndpoint, e);
			}
		}

		return response;
	}
	
	
	public String getRestServiceResponseB2CLEA(String hostName, String restEndpoint, String groupCode, String payLoad, String verbType){

		String response = null;
		String host = restConfig.getProperty(hostName);
		String restUrl = restConfig.getProperty(restEndpoint);
		if(host != null && StringUtils.isNotEmpty(restUrl)){
			try{

				Client client = Client.create();

				WebResource webResource = client.resource(host + restUrl);
				WebResource.Builder builder = webResource.accept(MediaType.APPLICATION_JSON);
				builder.type(MediaType.APPLICATION_JSON);
				builder.header(Constant.TENANT_CODE, groupCode);
				response = builder.post(String.class, payLoad);
				
			}catch(Exception e){
			    log.error("Error in getRestServiceResponse, url : " + hostName+restEndpoint, e);
			}
		}
		return response;
	}
	
	
	/**
	 * This utility method is used to call App rest layer
	 * @param gstr1Data
	 */
	public void callGSTR2RestService(String gstr2Data) {
		try{
			if(log.isInfoEnabled())
			log.info("Start Rest Service");
			URL url = new URL(restConfig.getProperty(Constant.ASP_GSTR2_REST_HOST));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");

			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(gstr2Data);
			out.flush();

			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED && conn.getResponseCode() != HttpURLConnection.HTTP_OK  ) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");

			while ((output = br.readLine()) != null) {
				//System.out.println(output);
				if(log.isInfoEnabled())
				log.info("Rest Service Response: "+output);
			}

			conn.disconnect();

		} catch (MalformedURLException e) {
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} catch (IOException e) {
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} catch(Exception e){
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();
		}
		if(log.isInfoEnabled())
		log.info("End Rest Service");

	}
	
/*	public void callRestServiceGstr6(String redisInvoiceKey,String groupCode) {
		try {
			if(log.isInfoEnabled())
			log.info("Start Rest Service");
			URL url = new URL(restConfig.getProperty(Constant.REST_HOST_GSTR6));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
			conn.setRequestProperty(Constant.TENANT_CODE, groupCode);

			Gson gson = new Gson();
			String jsonStr=gson.toJson(redisInvoiceChannel);
			System.out.println(jsonStr);
			JsonObject covertedObject =new Gson().fromJson(jsonStr, JsonObject.class);
			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(redisInvoiceKey);
			out.flush();

			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED && conn.getResponseCode() != HttpURLConnection.HTTP_OK  ) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");

			while ((output = br.readLine()) != null) {
				//System.out.println(output);
				if(log.isInfoEnabled())
				log.info("Rest Service Response: "+output);
			}

			conn.disconnect();

		} catch (MalformedURLException e) {
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} catch (IOException e) {
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();

		} catch(Exception e){
			log.error("Error in Rest service", e.getMessage());
			e.printStackTrace();
		}
		if(log.isInfoEnabled())
		log.info("End Rest Service");

	}
*/	
}
