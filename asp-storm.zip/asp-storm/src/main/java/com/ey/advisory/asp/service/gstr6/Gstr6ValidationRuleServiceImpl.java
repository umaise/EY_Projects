package com.ey.advisory.asp.service.gstr6;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.common.GSTR6ValidationUtility;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RedisTemplateUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.jersey.api.client.ClientResponse;

import org.apache.commons.lang3.StringUtils;


public class Gstr6ValidationRuleServiceImpl implements Gstr6ValidationRuleService{
	
	Set<TblIsdErrorInfo> errorList = new HashSet<TblIsdErrorInfo>();
	private RedisTemplate<String, Object> redisTemplate;
	private final Logger log = LoggerFactory.getLogger(getClass());
	Map<String, TblGstinDetailsDomain> gstinMap = new HashMap<String, TblGstinDetailsDomain>();
	BigDecimal totalTaxAmount = Constant.ZERO_BIG_DECIMAL;
	BigDecimal totalTaxRate = Constant.ZERO_BIG_DECIMAL;
	
	public Gstr6ValidationRuleServiceImpl(){
		redisTemplate=JedisConnectionUtil.getRedisTemplateKVStringObject();
	}

	public InwardInvoiceGstr6DTO executeGSTR6ITCValidationRules(InwardInvoiceGstr6DTO inwardInvoiceDTO) {
		
		if(inwardInvoiceDTO.getErrorList()!=null){
		errorList = inwardInvoiceDTO.getErrorList();
		}
		
		List<InwardInvoiceModel> lineItems = inwardInvoiceDTO.getLineItemList();
		
		
		
		 boolean   validateDocTypeForTaxPeriodFlag = validateDocTypeForTaxPeriod(lineItems.get(0));
		 boolean   validateOriginalDocDateForRNVFlag = validateOriginalDocDateForRNV(lineItems.get(0));
		 boolean   validateDocumentDateForTaxPeriodFlag = validateDocumentDateForTaxPeriod(lineItems.get(0));
		 //boolean   validateDocumentDateForRegDateFlag = validateDocumentDateForRegDate(lineItems.get(0),inwardInvoiceDTO.getGroupCode());
		 
		 if(!validateDocTypeForTaxPeriodFlag|| !validateOriginalDocDateForRNVFlag||!validateDocumentDateForTaxPeriodFlag/*||!validateDocumentDateForRegDateFlag*/){
				inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
			}else if(inwardInvoiceDTO.getInvStatus() == null){
				inwardInvoiceDTO.setInvStatus(Constant.GSTR6_BR_STG1);
			}
		 
		 
		
		int counter = 0;
			
		if(inwardInvoiceDTO.getLineItemList()!=null){

				for(InwardInvoiceModel inwardInvoiceModel : inwardInvoiceDTO.getLineItemList())	{	
					validateGstr6BusinessTable(inwardInvoiceModel, inwardInvoiceDTO);
					//validateItcEligiblityForInputType(inwardInvoiceModel);
					//validateAmendmentItcEligiblity(inwardInvoiceModel);
					//validateDocSeries(inwardInvoiceModel,inwardInvoiceDTO);
					
					//validateCrDrEligibleOriginalDocument(inwardInvoiceModel,inwardInvoiceDTO);
					
					//validateCRagainstOriginalDocNo(inwardInvoiceModel,inwardInvoiceDTO);
				
					validateReportDate(inwardInvoiceModel,inwardInvoiceDTO);
					
					//validateInvoiceNo(inwardInvoiceModel,inwardInvoiceDTO);
					validateEligibleInput(inwardInvoiceModel);
					//validateGoodsServicesFlag(inwardInvoiceModel);*/
					validateEligibleComputation(inwardInvoiceModel);
					validateTaxForSez(inwardInvoiceModel);
					validateDocumentNumber(inwardInvoiceModel);
					prepareModel(inwardInvoiceModel);
					if(inwardInvoiceModel.getItemStatus() != null && inwardInvoiceModel.getItemStatus() == Constant.BUS_RULE_ERROR){
						counter = counter + 1;
					}
				}
			}
		
		if (counter > 0  ) {
				inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
		}else if (inwardInvoiceDTO.getInvStatus() == null) {
				inwardInvoiceDTO.setInvStatus(Constant.GSTR6_BR_STG1);
		}
		
		if(!validateNilNonExtOnTaxAmount(lineItems.get(0)))
		{
			inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
		}
	
		inwardInvoiceDTO.setErrorList(errorList);

		return inwardInvoiceDTO;
	
}
	
	private void validateInvoiceNo(InwardInvoiceModel inwardInvoiceModel,InwardInvoiceGstr6DTO inwardInvoiceDTO){
		/*   String invStatusKey=inwardInvoiceDTO.getRedisKey()+"_"+Constant.INVOICE_STATUS_VAL;
		   Set<InvoiceProcessDto> invoiceProcessSet = new HashSet<InvoiceProcessDto>() ;
		   InvoiceProcessDto invProcessDto=new InvoiceProcessDto();
	        InwardInvoiceModel inwardStagingDetail=inwardInvoiceDTO.getLineItemList().get(0);
	        invProcessDto.setInvKey(inwardStagingDetail.getInvoiceKey());
	        invProcessDto.setInvOrder(inwardStagingDetail.getInvOrder());
	        invoiceProcessSet.add(invProcessDto);
	        redisTemplate.opsForHash().put(invStatusKey, invProcessDto.getInvOrder(),invProcessDto);*/
	        
		String result = GSTR6ValidationUtility.fetchInvoiceNo(inwardInvoiceModel,inwardInvoiceDTO,inwardInvoiceDTO.getGroupCode());
		
		if (result != null && result.length() > 0 && result != "") {
		int val = Integer.parseInt(result);
		if(val == 1){
			if(inwardInvoiceModel.getDocumentType().equalsIgnoreCase("INV")){
			inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER207", "Invoice Line Item ", Constant.BUSINESS_RULE, Boolean.FALSE
					,Constant.INVOICE));
			}
			if(inwardInvoiceModel.getDocumentType().equalsIgnoreCase("CR")){
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER246", "Invoice Line Item ", Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.INVOICE));
				}
			if(inwardInvoiceModel.getDocumentType().equalsIgnoreCase("DR")){
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER247", "Invoice Line Item ", Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.INVOICE));
				}
		}
		}
	}
	
	private void validateReportDate(InwardInvoiceModel inwardInvoiceModel, InwardInvoiceGstr6DTO inwardInvoiceDTO) {
		if(inwardInvoiceModel.getDocumentType() != null && inwardInvoiceModel.getDocumentType().length()>0 && inwardInvoiceModel.getTaxPeriod() != null && inwardInvoiceModel.getTaxPeriod().length()>0
				&& inwardInvoiceModel.getEligibilityIndicator() != null && inwardInvoiceModel.getEligibilityIndicator().length()>0 ){
		String docType = inwardInvoiceModel.getDocumentType();
		String eligibleIndicator = inwardInvoiceModel.getEligibilityIndicator();
		// Date date = inwardInvoiceModel.getDocumentDate();
		String fy = null;
		int currentFY = Integer.parseInt(inwardInvoiceModel.getTaxPeriod().substring(2, 6));
		int currentMonth = Integer.parseInt(inwardInvoiceModel.getTaxPeriod().substring(0, 2));
		Date modDate;
		try {
			modDate = Utility.convertStringToDate(Constant.DATE_FORMAT, new String(currentFY + 1 + "-09-30"));
			Date originalDate = Utility.convertStringToDate(Constant.DATE_FORMAT,
					inwardInvoiceModel.getDocumentDate().toString());
	
			boolean notNull = false;
			boolean docTypeFlag = false;
			boolean originalDateFlag = false;
			boolean eligibilityIndicatorFlag = false;
			boolean FYFlag = false;
	
			notNull = docType != null && docType != "" && docType.length() > 0 && eligibleIndicator != null
					&& eligibleIndicator != "" && eligibleIndicator.length() > 0 && originalDate != null
					&& modDate != null;
					
			if(notNull){		
				
				docTypeFlag = docType.equals(Constant.INV) || docType.equals(Constant.CR) || docType.equals(Constant.DR);
				originalDateFlag = originalDate.after(modDate) && originalDate.compareTo(modDate) > 0;
				eligibilityIndicatorFlag = eligibleIndicator.equals(Constant.INPUT_SERVICES);
				
				 if(currentMonth-1 < Calendar.APRIL){
		             fy = String.valueOf(currentFY - 1)+String.valueOf(currentFY);
		         }
				 else{
		             fy = String.valueOf(currentFY)+String.valueOf(currentFY+1);
		         }
		
				 FYFlag = Utility.getFY(inwardInvoiceModel.getDocumentDate()).equalsIgnoreCase(fy);
				 
				 if (docTypeFlag ) {
						if(originalDateFlag ){
							if(eligibilityIndicatorFlag){
								 if(FYFlag) {
		
									log.info("ITC for Invoice(s) <> cannot be availed after September 30 of the next Financial Year or Annual Return Filing whichever is earlier.");
									inwardInvoiceModel.setEligibilityIndicator(Constant.NO);
									inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);

									errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER406", "Taxable Value ", Constant.BUSINESS_RULE, Boolean.FALSE
											,Constant.INVOICE));
									
								 }
							}
						}	
		
				}
			}
	
		} catch (ParseException e) {
			log.error("exception in  date parsing ", e);
		}
		}
	}
	
	
	

	/**
	 * BR 1370, 1371
	 */
	private void validateEligibleInput(InwardInvoiceModel inwardInvoiceModel) {

		//String transactionNo = inwardInvoiceModel.getTransactionIDforAdvances();
		String eligibleInput = inwardInvoiceModel.getEligibilityIndicator();

		if ( eligibleInput == null || eligibleInput=="" || eligibleInput.length()==0 ) {

			log.error("Eligibility of ITC Flag is Missing for the Transaction No.<> ");
			inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER462", "Eligibility of ITC Flag", Constant.BUSINESS_RULE, Boolean.FALSE
					,Constant.INCIDENCE_LEVEL_LINE_ITEM));
		}

		if (eligibleInput != null && eligibleInput.length()>0){
				if(!eligibleInput.equalsIgnoreCase(Constant.INPUT_SERVICES)){ 
					if(!eligibleInput.equalsIgnoreCase(Constant.NO)) {

			log.info("Flag other than IS/ NO cannot be selected for the Transaction No.<> ");
			inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);

			errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER463", "Eligibility of ITC Flag", Constant.BUSINESS_RULE, Boolean.FALSE
					,Constant.INVOICE));
		}
	}
		}
	}

	
	
	/**
	 * user story-2142,2143,2144,2145
	 * */
	private void validateCrDrEligibleOriginalDocument(InwardInvoiceModel inwardInvoiceModel,InwardInvoiceGstr6DTO inwardInvoiceDTO) {
		String elegInd="";
		String eligibleIndicator = inwardInvoiceModel.getEligibilityIndicator();
		
		String resultVal = GSTR6ValidationUtility.fetchEligibleIndicator(inwardInvoiceModel,inwardInvoiceDTO,inwardInvoiceDTO.getGroupCode());
	
		resultVal=resultVal.replace("[", "");
		resultVal=resultVal.replace("]", "");
		resultVal=resultVal.replace("\"", "");
		List result = Arrays.asList(resultVal.split("\\,"));
		Iterator eligIndIterator = result.iterator();
		while(eligIndIterator.hasNext()){
             elegInd = (String) eligIndIterator.next();
             log.info("eligibility Indicator value "+elegInd );
		if(inwardInvoiceModel.getDocumentType().equalsIgnoreCase("DR")){
		if (eligibleIndicator != null && eligibleIndicator.length()>0
				&& (!eligibleIndicator.equalsIgnoreCase(elegInd))) {

			inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "IN601", "Eligibility of ITC Flag", Constant.BUSINESS_RULE, Boolean.FALSE
					,Constant.INVOICE));
		}
		}
		if(inwardInvoiceModel.getDocumentType().equalsIgnoreCase("CR")){
			if (eligibleIndicator != null && eligibleIndicator.length()>0
					&& (!eligibleIndicator.equalsIgnoreCase(elegInd))) {

				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "IN602", "Eligibility of ITC Flag", Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.INVOICE));
			}
			}
		}
				}

	
/*	private void validateCRagainstOriginalDocNo(InwardInvoiceModel inwardInvoiceModel,InwardInvoiceGstr6DTO inwardInvoiceDTO){
			
			String result = GSTR6ValidationUtility.fetchCRTaxableValue(inwardInvoiceModel,inwardInvoiceDTO,inwardInvoiceDTO.getGroupCode());
			if (result != null && result.length() > 0 && result != "") {
				if (!result.equalsIgnoreCase("[null]")) {
					if (!result.equalsIgnoreCase("[]")) {
			String modifiedVal = result.substring(result.indexOf("[") + 1, result.indexOf("]"));  
			
			if(((inwardInvoiceModel.getTaxableValue().compareTo(BigDecimal.valueOf(Double.parseDouble(modifiedVal)))== -1) && (inwardInvoiceModel.getTaxableValue().compareTo(BigDecimal.valueOf(Double.parseDouble(modifiedVal)))== 0))){
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER605", "Taxable Value ", Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.INVOICE));
					}
				}
			}
			}
		}*/
	
	    //BR 1391
		private Boolean validateDocTypeForTaxPeriod(InwardInvoiceModel inwardInvoiceModel) {
				
			try {
				String docType = inwardInvoiceModel.getDocumentType();
				Calendar taxPeriod = Calendar.getInstance();
				taxPeriod.setTime(Utility.convertStringToDate(Constant.DATEFORMAT, inwardInvoiceModel.getTaxPeriod().toString()));
				
				int month =  taxPeriod.get(Calendar.MONTH);
				int year = taxPeriod.get(Calendar.YEAR);
				if(month== 6 && year == 2017){
					if(docType!=null && (docType.equals(Constant.RNV)||docType.equals(Constant.RDR)||docType.equals(Constant.RCR))){
						log.info("RNV/RDR/RCR cannot exists for the first tax period for GST regime");
						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						//errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel.getId(), "ER228","Document Type", Constant.BUSINESS_RULE, false, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),Constant.INVOICE));
						errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER230", "Document Type", Constant.BUSINESS_RULE, Boolean.FALSE
								,Constant.INVOICE));
						return false;
					}
				}
			} catch (ParseException pe) {
				log.error("Error Parsing Tax period for invoice ", inwardInvoiceModel.getId(), pe);
			}
			return true;
			}

	    //BR 2125
        private void validateGstr6BusinessTable(InwardInvoiceModel inwardInvoiceModel, InwardInvoiceGstr6DTO inwardInvoiceDTO) {
            String supplierGSTIN = inwardInvoiceModel.getSGSTIN();
            String docType = inwardInvoiceModel.getDocumentType();
            String supplyType = inwardInvoiceModel.getSupplyType();
            String eligibilityIndicator = inwardInvoiceModel.getEligibilityIndicator();
            boolean isEmpty = false;
            boolean docTypeFlag = false;
            boolean supplyTypeFlag = false;
            boolean eligibilityIndicatorFlag = false;
            String typeOfReg = "";
            String groupCode = inwardInvoiceDTO.getGroupCode();
                           
            isEmpty = StringUtils.isEmpty(supplierGSTIN);
            docTypeFlag = !StringUtils.isEmpty(docType) &&  (docType.equals(Constant.SLF) || docType.equals(Constant.RSLF) ||docType.equals(Constant.DLC)||docType.equals(Constant.RLDC));
            supplyTypeFlag = !StringUtils.isEmpty(supplyType) &&  (supplyType.equals(Constant.IMP)||supplyType.equals(Constant.NON)||supplyType.equals(Constant.COM)||supplyType.equals(Constant.DXP)||supplyType.equals(Constant.NSY));
            eligibilityIndicatorFlag = !StringUtils.isEmpty(eligibilityIndicator) && (eligibilityIndicator.equals(Constant.INPUTS)||eligibilityIndicator.equals(Constant.CAPITAL_GOODS));
            
            RedisTemplateUtil<String, Object> redisTemplateUtil = new RedisTemplateUtil<String, Object>();
            RedisTemplate<String, Object> redisTemplate = redisTemplateUtil.getRedisTemplate();

            gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(groupCode+"_"+
                                          Constant.REDIS_CACHE, Constant.GSTIN_DEATILS);

            if(gstinMap == null){
                           gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(groupCode+"_"+Constant.REDIS_CACHE, Constant.GSTIN_DEATILS);
            }
            
            TblGstinDetailsDomain gstin = null;
            if(gstinMap!=null)
                           gstin = gstinMap.get(supplierGSTIN);
            
            if (gstin == null) {
                           ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, "asp-restapi.getGSTIN", inwardInvoiceDTO.getGroupCode(), supplierGSTIN, Constant.VERB_TYPE_POST);
                           //Gson gson = new Gson();
                           Gson gson = new GsonBuilder().setDateFormat(Constant.DATE_FORMAT).create(); 
                           
                           if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
                                          gstin = gson.fromJson(response.getEntity(String.class), TblGstinDetailsDomain.class);
                           }
            }
            
            if(gstin != null && gstin.getTypeOfReg() != null){
                           typeOfReg= gstin.getTypeOfReg();
            }
            
            if(isEmpty||docTypeFlag||supplyTypeFlag||eligibilityIndicatorFlag||typeOfReg.equals(Constant.ISD)){
                           log.info("Invoice does not fall into any of GSTR6 business tables");
                           inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
                                          //errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel.getId(), "ER220","Table Type", Constant.BUSINESS_RULE, false, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),Constant.LINE_ITEM));
                           errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER602", "Table Type", Constant.BUSINESS_RULE, Boolean.FALSE,Constant.LINE_ITEM));
            }              
}

			
			
			
			//BR 2157
			private void validateDocumentNumber(InwardInvoiceModel inwardInvoiceModel) {
				
				String documentNo = inwardInvoiceModel.getDocumentNo();
				String originalDocumentNo = inwardInvoiceModel.getOriginalDocumentNo();
				boolean docFlag=false, orgDocFlag=false;
							
				if((documentNo!= null && documentNo.length()!=0 && originalDocumentNo!=null && originalDocumentNo.length()!=0)	){
				
					if(documentNo.contains("/") )
						documentNo=documentNo.replaceAll("/", "");
					if( documentNo.contains("-"))
						documentNo=documentNo.replaceAll("-", "");
					docFlag=documentNo.matches("[A-Za-z0-9]+");
					
					if(originalDocumentNo.contains("/") )
						originalDocumentNo=originalDocumentNo.replaceAll("/", "");
					if( originalDocumentNo.contains("-"))
						originalDocumentNo=originalDocumentNo.replaceAll("-", "");
					orgDocFlag=originalDocumentNo.matches("[A-Za-z0-9]+");
					
					if(!docFlag || !orgDocFlag){
						log.info("Document Number cannot have special characters other '-' or '/'.");
						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						//errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel.getId(), "ER230","Document No", Constant.BUSINESS_RULE, false, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),Constant.LINE_ITEM));
						errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER055", "Document No", Constant.BUSINESS_RULE, Boolean.FALSE
								,Constant.LINE_ITEM));
					}	
				}	
			}
			
			//BR 1390
			private Boolean validateOriginalDocDateForRNV(InwardInvoiceModel inwardInvoiceModel) {
				
			String docType = inwardInvoiceModel.getDocumentType();
				
				if(docType.equals(Constant.RNV)){
					Date docDt;
					Date originalDocDate;
					try {
						docDt = Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getDocumentDate().toString());
						originalDocDate= Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getOriginalDocumentDate().toString());
					
					if (docDt.getMonth() == originalDocDate.getMonth() && docDt.getYear() == originalDocDate.getYear())
					{
						log.info("INV and RNV document types cannot exists for a same Invoice number within the given tax period");
						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						//errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel.getId(), "ER217","Document Date", Constant.BUSINESS_RULE, false, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),Constant.INVOICE));
						errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER609", "Document Date", Constant.BUSINESS_RULE, Boolean.FALSE
								,Constant.INVOICE));
						return false;
					}
					} catch (ParseException pe) {
						log.error("Error Parsing Date for invoice ", inwardInvoiceModel.getId(), pe);
				 }
				}
				/*if(docType.equals(Constant.RCR) || docType.equals(Constant.RDR) ){
					Date docDt;
					Date originalDocDate;
					try {
						docDt = Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getDocumentDate().toString());
						originalDocDate= Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getOriginalDocumentDate().toString());
					
					if (docDt.getMonth() == originalDocDate.getMonth() && docDt.getYear() == originalDocDate.getYear())
					{
						log.info("Original Document & Revised Document cannot be reported in same tax period for the same Document Number");
						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						//errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel.getId(), "ER217","Document Date", Constant.BUSINESS_RULE, false, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),Constant.INVOICE));
						errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER229", "Document Date", Constant.BUSINESS_RULE, Boolean.FALSE
								,Constant.INVOICE));
						return false;
					}
					} catch (ParseException pe) {
						log.error("Error Parsing Date for invoice ", inwardInvoiceModel.getId(), pe);
				 }
				}*/
				return true;
			}
			
			// #BR 1379
			private Boolean validateDocumentDateForTaxPeriod(InwardInvoiceModel inwardInvoiceModel) {
				
				Calendar cal = Calendar.getInstance();
				Date documentDate = null;
				Date gstRegimeDate = null;	
				
				String docType = inwardInvoiceModel.getDocumentType();
					try {
						documentDate = Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getDocumentDate().toString());
						gstRegimeDate = Utility.convertStringToDate(Constant.DATEFORMAT, "072017".toString());
					} catch (ParseException e) {
						e.printStackTrace();
						log.error("Error in parsing date" + e);
					}
							
					if (documentDate!=null && documentDate.compareTo(gstRegimeDate) < 0) {
						
						if(!(("Y".equals(inwardInvoiceModel.getCRDRPreGST())) &&(docType.equals(Constant.CR)|| docType.equals(Constant.DR)))){
							log.info(" Records pertain to pre-GST regime. ");
							inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
							//errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel.getId(), "ER221","Tax Period", Constant.BUSINESS_RULE, false, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),Constant.INVOICE));
							errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER603", "Tax Period", Constant.BUSINESS_RULE, Boolean.FALSE
									,Constant.INVOICE));
							return false;
						}
					
					}
					return true;
			}
			
			
			/**1384
			 * Validating Document Date for greater than Registration Date
			 */
			@SuppressWarnings({ "unchecked"}) 
			private boolean validateDocumentDateForRegDate(InwardInvoiceModel inwardInvoiceModel, String groupCode) {

				Date registrationDate=null;
				Date docDt = null;
				String gstinId = inwardInvoiceModel.getSGSTIN();
				RedisTemplateUtil<String, Object> redisTemplateUtil = new RedisTemplateUtil<String, Object>();

				String columnNames = "";

				RedisTemplate<String, Object> redisTemplate = redisTemplateUtil
						.getRedisTemplate();

				gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(
						Constant.REDIS_CACHE, groupCode+"_"+Constant.GSTIN_DEATILS);

				if(gstinMap == null){
					loadGSTINDetailsToRedis(groupCode);
					gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(
							Constant.REDIS_CACHE, groupCode+"_"+Constant.GSTIN_DEATILS);
				}

				TblGstinDetailsDomain gstin = null;
				if(gstinMap!=null)
					gstin = gstinMap.get(gstinId);

				if (gstin == null) {

					ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, "asp-restapi.getGSTIN", groupCode, gstinId, Constant.VERB_TYPE_POST);
					//Gson gson = new Gson();
					Gson gson = new GsonBuilder().setDateFormat(Constant.DATE_FORMAT).create(); 
					
					if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
						gstin = gson.fromJson(response.getEntity(String.class), TblGstinDetailsDomain.class);
					}
				} 

				try {
					if(gstin != null && gstin.getRegdt() != null){
						//registrationDate=Utility.convertStringToDate(Constant.DATE_FORMAT, gstin.getRegdt().toString());
						registrationDate= gstin.getRegdt();
					}
					if (registrationDate == null) {/*

						log.error("GST Registration Date is not available");
						columnNames = Constant.DOC_DATE;

						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);

						errorList.add(ErrorActionUtility.getSalesTblErrorInfo(
								inwardInvoiceModel.getInvoiceKey(), "ER053", columnNames,
								Constant.BUSINESS_RULE, false,inwardInvoiceModel.getSGSTIN(),Constant.INVOICE, null));
						return false;
					*/} else {

						docDt= Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getDocumentDate().toString());
						//docDt= outwardInvoiceModel.getDocDate();


						if (docDt.compareTo(registrationDate) < 0) {

							log.error("Document Date is earlier than the Effective Date of GST Registration");

							inwardInvoiceModel
							.setItemStatus(Constant.BUS_RULE_ERROR);
							columnNames = Constant.DOC_DATE;
							
							//errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel.getId(), "ER229",Constant.DOC_DATE, Constant.BUSINESS_RULE, false, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),Constant.INVOICE));
							errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER220", Constant.DOC_DATE, Constant.BUSINESS_RULE, Boolean.FALSE
									,Constant.INVOICE));
							
							return false;
						}
					}

				} catch (Exception e) {
					log.error("Error Validating DocumentDate for Registration Date in GSTR6 : validateDocumentDateForRegDate ", e);
				}
				return true;



			}
	@Override
	public String getDataForHsnSac(String groupCode) {
		String status = null;

		ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
				Constant.LOAD_HSNSAC_REDIS, groupCode, null, Constant.VERB_TYPE_POST);

		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			Gson gson = new Gson();
			status = gson.fromJson(response.getEntity(String.class), String.class);
		}
		return status;
	}
	
	
	// BR 1378
	private void validateEligibleComputation(InwardInvoiceModel inwardInvoiceModel) {

			//for (InwardInvoiceDTO lineItem : inwardInvoiceModel){
			
			BigDecimal itcAvailCgst=inwardInvoiceModel.getAvailableCGST() == null ? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getAvailableCGST().abs();
			BigDecimal itcAvailIgst=inwardInvoiceModel.getAvailableIGST()== null ? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getAvailableIGST().abs();
			BigDecimal itcAvailSgst=inwardInvoiceModel.getAvailableSGST()== null ? Constant.ZERO_BIG_DECIMAL : inwardInvoiceModel.getSGSTAmount().abs();
			BigDecimal itcAvailCess=inwardInvoiceModel.getAvailableCESS()== null ? Constant.ZERO_BIG_DECIMAL : inwardInvoiceModel.getAvailableCESS().abs();
					
			BigDecimal itcCgstAmount=inwardInvoiceModel.getCGSTAmount() == null ? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getCGSTAmount().abs();
			BigDecimal itcIgstAmount=inwardInvoiceModel.getIGSTAmount()== null ? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getIGSTAmount().abs();
			BigDecimal itcSgstAmount=inwardInvoiceModel.getSGSTAmount()== null ? Constant.ZERO_BIG_DECIMAL : inwardInvoiceModel.getSGSTAmount().abs();
			BigDecimal itcCessAmountAdvalorem=inwardInvoiceModel.getCessAmountAdvalorem()== null ? Constant.ZERO_BIG_DECIMAL : inwardInvoiceModel.getCessAmountAdvalorem().abs();
			BigDecimal itcCessAmountSpecific=inwardInvoiceModel.getCessAmountSpecific()== null ? Constant.ZERO_BIG_DECIMAL : inwardInvoiceModel.getCessAmountSpecific().abs();
				
			BigDecimal totalTaxAvailable = itcAvailCgst.add(itcAvailIgst).add(itcAvailSgst).add(itcAvailCess);

			BigDecimal totalTaxAmount = itcCgstAmount.add(itcIgstAmount).add(itcSgstAmount).add(itcCessAmountAdvalorem).add(itcCessAmountSpecific);
			
			BigDecimal itcCessAmt = itcCessAmountAdvalorem.add(itcCessAmountSpecific).abs();

			BigDecimal totalTax = totalTaxAmount.abs();

			BigDecimal taxAvailable =totalTaxAvailable.abs();

				//if (taxAvailable.compareTo(totalTax) >0) {
			/*if(itcAvailCgst.compareTo(itcCgstAmount)>0){
				if(itcAvailIgst.compareTo(itcIgstAmount)>0){
					if(itcAvailSgst.compareTo(itcSgstAmount)>0){
						if(itcAvailCess.compareTo(itcCessAmt)>0){
					log.info("Total tax available as ITC is more than the  Tax amount of invoice");
					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);

					errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER404", "TotalTaxeligibleITC", Constant.BUSINESS_RULE, Boolean.FALSE
							,Constant.INVOICE));
				//}
					}
						
					}
				}
			}*/
			
			if ((itcAvailCgst.compareTo(itcCgstAmount) > 0) || (itcAvailSgst.compareTo(itcSgstAmount) > 0)) {
				log.info("Total tax available as ITC is more than the  Tax amount of invoice");
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER404", "TotalTaxeligibleITC", Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.INVOICE));
			}
			
			if (itcAvailIgst.compareTo(itcIgstAmount) > 0) {
				log.info("Total tax available as ITC is more than the  Tax amount of invoice");
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER404", "TotalTaxeligibleITC", Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.INVOICE));
			}
			
			if (itcAvailCess.compareTo(itcCessAmt) > 0) {
				log.info("Total tax available as ITC is more than the  Tax amount of invoice");
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER404", "TotalTaxeligibleITC", Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.INVOICE));
			}
	}
	
	/*
	 * validating document date to be within tax period boundaries
	 */

	private String loadGSTINDetailsToRedis(String groupCode ) {
		String status = null;


		ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.LOAD_GSTIN_REDIS,  groupCode, null, Constant.VERB_TYPE_POST);
		Gson gson = new Gson();

		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			status = gson.fromJson(response.getEntity(String.class), String.class);
		}
		return status;

	}	

	private boolean validateNilNonExtOnTaxAmount(InwardInvoiceModel inwardInvoiceModel) {
		String supplyType = inwardInvoiceModel.getSupplyType();

		if((supplyType.equalsIgnoreCase(Constant.EXT) || supplyType.equalsIgnoreCase(Constant.NON) || supplyType.equalsIgnoreCase(Constant.NIL)) 
				&& (totalTaxRate.compareTo(Constant.ZERO_BIG_DECIMAL)==1 || totalTaxAmount.compareTo(Constant.ZERO_BIG_DECIMAL)==1)){

			String columnNames = "";
			String rates = Constant.CGSTRATE + "," + Constant.SGSTRATE + "," + Constant.IGSTRATE + "," + Constant.CESS_RATE_ADV + "," + Constant.CESS_RATE_SPECIFIC;
			String amount = Constant.CGST_AMOUNT + "," + Constant.SGST_AMOUNT + "," + Constant.IGST_AMOUNT + "," + Constant.CESS_AMT_ADV + "," + Constant.CESS_AMT_SPECIFIC;
			if(totalTaxRate.compareTo(Constant.ZERO_BIG_DECIMAL)==1) {
				columnNames = rates;
			} 
			if(totalTaxAmount.compareTo(Constant.ZERO_BIG_DECIMAL)==1) {
				columnNames = columnNames.isEmpty()?amount:columnNames+ ","+amount;
			}
			inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER233", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE
					,Constant.LINE_ITEM));
			return false;
		}
		return true;
	}

	private void prepareModel(InwardInvoiceModel inwardInvoiceModel) {

		inwardInvoiceModel.setCGSTRate(inwardInvoiceModel.getCGSTRate()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getCGSTRate());
		inwardInvoiceModel.setIGSTRate(inwardInvoiceModel.getIGSTRate()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getIGSTRate());
		inwardInvoiceModel.setSGSTRate(inwardInvoiceModel.getSGSTRate()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getSGSTRate());
		inwardInvoiceModel.setCessRateSpecific(inwardInvoiceModel.getCessRateSpecific()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getCessRateSpecific());
		inwardInvoiceModel.setCessRateAdvalorem(inwardInvoiceModel.getCessRateAdvalorem()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getCessRateAdvalorem());

		inwardInvoiceModel.setCGSTAmount(inwardInvoiceModel.getCGSTAmount()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getCGSTAmount());
		inwardInvoiceModel.setIGSTAmount(inwardInvoiceModel.getIGSTAmount()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getIGSTAmount());
		inwardInvoiceModel.setSGSTAmount(inwardInvoiceModel.getSGSTAmount()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getSGSTAmount());
		inwardInvoiceModel.setCessAmountSpecific(inwardInvoiceModel.getCessAmountSpecific()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getCessAmountSpecific());
		inwardInvoiceModel.setCessAmountAdvalorem(inwardInvoiceModel.getCessAmountAdvalorem()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getCessAmountAdvalorem());

		totalTaxAmount = inwardInvoiceModel.getIGSTAmount().add(inwardInvoiceModel.getSGSTAmount()).add(inwardInvoiceModel.getCGSTAmount()).add(inwardInvoiceModel.getCessAmountSpecific()).add(inwardInvoiceModel.getCessAmountAdvalorem());
		totalTaxRate = inwardInvoiceModel.getIGSTRate().add(inwardInvoiceModel.getCGSTRate()).add(inwardInvoiceModel.getSGSTRate()).add(inwardInvoiceModel.getCessRateSpecific()).add(inwardInvoiceModel.getCessRateAdvalorem());


		/*	inwardInvoiceModel.setTaxableValue(inwardInvoiceModel.getTaxableValue()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getTaxableValue());
		inwardInvoiceModel.setInvoiceValue(inwardInvoiceModel.getInvoiceValue()==null? Constant.ZERO_BIG_DECIMAL: inwardInvoiceModel.getInvoiceValue());*/

	}
	
	private void validateTaxForSez(InwardInvoiceModel inwardInvoiceModel) {
		if(inwardInvoiceModel.getSupplyType()!=null && inwardInvoiceModel.getSGSTRate()!=null && inwardInvoiceModel.getCGSTRate()!=null && inwardInvoiceModel.getSGSTAmount()!=null && inwardInvoiceModel.getCGSTAmount()!=null){
			if((inwardInvoiceModel.getSupplyType().equalsIgnoreCase(Constant.SEZ))&&((inwardInvoiceModel.getSGSTRate().compareTo(Constant.ZERO_BIG_DECIMAL)==1)||(inwardInvoiceModel.getCGSTRate().compareTo(Constant.ZERO_BIG_DECIMAL)==1)
					||(inwardInvoiceModel.getSGSTAmount().compareTo(Constant.ZERO_BIG_DECIMAL)==1)||(inwardInvoiceModel.getCGSTAmount().compareTo(Constant.ZERO_BIG_DECIMAL)==1))){
				String rates = Constant.CGSTRATE + "," + Constant.SGSTRATE ;
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER228", rates, Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.LINE_ITEM));
			}
		}
	}

}
