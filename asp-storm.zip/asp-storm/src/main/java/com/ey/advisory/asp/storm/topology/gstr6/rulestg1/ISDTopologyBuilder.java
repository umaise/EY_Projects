package com.ey.advisory.asp.storm.topology.gstr6.rulestg1;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseRichBolt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.redis.mapper.ISDRedisCompute;
import com.ey.advisory.asp.storm.bolt.common.GSTR6RedisWSBolt;
import com.ey.advisory.asp.storm.bolt.common.GSTR6RestCallBolt;
import com.ey.advisory.asp.storm.bolt.common.GSTR6RestLogicBolt;
import com.ey.advisory.asp.storm.bolt.common.PublishRedisBolt;
import com.ey.advisory.asp.storm.bolt.gstr6.rulestg1.ISDCatRuleBolt;
import com.ey.advisory.asp.storm.bolt.gstr6.rulestg1.ISDLineItemBolt;
import com.ey.advisory.asp.storm.bolt.gstr6.rulestg1.ISDRuleBolt;
import com.ey.advisory.asp.storm.bolt.gstr6.rulestg1.ISDRuleValidationBolt;
import com.ey.advisory.asp.storm.spout.gstr6.rulestg1.ISDSpoutBuilder;
import com.ey.advisory.asp.storm.topology.StormTopologyBuilder;




public class ISDTopologyBuilder extends StormTopologyBuilder{

	private ISDSpoutBuilder isdSpoutBuilder;
	private BaseRichBolt isdCatRuleBolt;
	private BaseRichBolt isdRuleValidationBolt;
	private BaseRichBolt isdRuleBolt;
	private GSTR6RedisWSBolt gstr6RedisWSBolt;
	private BaseRichBolt isdRedisCompute;
	private PublishRedisBolt publishRedisBolt;
	private ISDLineItemBolt isdLineItemBolt;
	private GSTR6RestCallBolt gstr6RestCallBolt;
	private GSTR6RestLogicBolt gstr6RestLogicBolt;
	
	private final Logger log = LoggerFactory.getLogger(getClass());


	public ISDTopologyBuilder(Properties configs) {
		super(configs);
		initialize();
	}
	
	private void initialize() {
		isdSpoutBuilder=new ISDSpoutBuilder(configs);
		isdCatRuleBolt = new ISDCatRuleBolt();
		isdRuleValidationBolt = new ISDRuleValidationBolt();
		isdLineItemBolt = new ISDLineItemBolt();
		isdRuleBolt = new ISDRuleBolt();
		gstr6RedisWSBolt=new GSTR6RedisWSBolt();
		gstr6RestCallBolt = new GSTR6RestCallBolt();
		gstr6RestLogicBolt = new GSTR6RestLogicBolt();
		//isdRedisCompute = new ISDRedisCompute();
		//publishRedisBolt=new PublishRedisBolt();
	}

	@Override
	public void buildDataPipeline(TopologyBuilder builder) {
		log.info("ISDTopologyBuilder.setBuilderDataPipeline() starts");
		
		if(builder != null){
			try{
				KafkaSpout purchaseRegSpout=isdSpoutBuilder.buildKafkaSpout();

				builder.setSpout(configs.getProperty(Constant.STORM_SPOUT_ISDREG), purchaseRegSpout);
				
				//int sinkPurchaseBoltCount = Integer.parseInt(configs.getProperty(Constant.PURCHASEREG_READ_BOLT_COUNT));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_ISDREG_RULE1),isdCatRuleBolt).shuffleGrouping(configs.getProperty(Constant.STORM_SPOUT_ISDREG));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_ISDREG_RULE2),isdRuleValidationBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_ISDREG_RULE1));
				
				//builder.setBolt(configs.getProperty(Constant.BOLT_ISDREG_RULE3),isdRuleBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_ISDREG_RULE2));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_ISDREG_RULE4),isdLineItemBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_ISDREG_RULE2));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_GSTR6_REDIS_WS),gstr6RedisWSBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_ISDREG_RULE4));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_ISDREG_RULE5),gstr6RestLogicBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_GSTR6_REDIS_WS));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_ISDREG_RULE6),gstr6RestCallBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_ISDREG_RULE5));
				
				//builder.setBolt(configs.getProperty(Constant.BOLT_ISDCOMPUTE_REDIS),isdRedisCompute).shuffleGrouping(configs.getProperty(Constant.BOLT_ISDREG_RULE6));
				
				//builder.setBolt(configs.getProperty(Constant.BOLT_PUBLISH_REDIS),publishRedisBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_ISDCOMPUTE_REDIS));
				
				log.info("ISDTopologyBuilder.setBuilderDataPipeline() ends");
			}catch(Exception e){
				log.error("Error Building ISD Topology " + e);
			}
	
}
		
}
}
