package com.ey.advisory.asp.service.gstr7;

import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.InwardInvoiceModelGstr7;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.dto.InwardInvoiceGstr7DTO;


/**
 * 
 * @author Nisha Kumari
 * @version 1.0
 * @since 30-05-2017
 */
public class Gstr7ValidationRuleServiceImpl implements
		Gstr7ValidationRuleService {

	Set<TblTdsErrorInfo> errorList = new HashSet<TblTdsErrorInfo>();
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Override
	public InwardInvoiceGstr7DTO executeGSTR7ValidationRules(InwardInvoiceGstr7DTO inwardInvoiceDTO) {
		if (inwardInvoiceDTO.getErrorList() != null) {
			errorList = inwardInvoiceDTO.getErrorList();
		}
		List<InwardInvoiceModelGstr7> lineItem = inwardInvoiceDTO.getLineItemList();

		InwardInvoiceModelGstr7 inwardInvoiceModel = inwardInvoiceDTO
				.getLineItemList().get(0);
		if (inwardInvoiceModel != null) {
			
			boolean isValidateTdsComputation = validateTdsComputation(inwardInvoiceModel);

			/*boolean isValidateTdsRateWithMaster = validateTdsRateWithMaster(inwardInvoiceModel, inwardInvoiceDTO.getGroupCode());

			boolean isValidateStateCode = validateStateCode(inwardInvoiceModel);

			boolean isValidateDupInv = validateDupInv(inwardInvoiceModel,
					inwardInvoiceDTO.getGroupCode());

			// boolean isValidateAdvTds = validateAdvTds(inwardInvoiceModel);

			boolean isValidateInv = validateInv(inwardInvoiceModel);

			boolean isValidateContractVal = validateContractVal(
					inwardInvoiceModel, inwardInvoiceDTO.getGroupCode());*/

			//boolean isValidateTDSFlagAndDocType = validateTDSFlagAndDocType(inwardInvoiceModel);

			boolean isVerifySupplierGSTIN = verifySupplierGSTIN(inwardInvoiceModel);

			//boolean isValidateContractValue = validateContractValue(inwardInvoiceModel);

			if(isValidateTdsComputation ||  !isVerifySupplierGSTIN
					)
				inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
			inwardInvoiceDTO.setErrorList(errorList);
		} else if (inwardInvoiceDTO.getInvStatus() == null) {
			inwardInvoiceDTO.setInvStatus(Constant.GSTR7_BR_STG1);
		}
		return inwardInvoiceDTO;
	}

	/*// Rule 15 removed
	@SuppressWarnings("unchecked")
	private boolean validateTdsRateWithMaster(
			InwardInvoiceModelGstr7 inwardInvoiceModel, String groupCode) {
		Map<String, GlobalGSTRatesMasterI> globalMasterMap = null;
		RedisTemplateUtil<String, Object> redisTemplateUtil = new RedisTemplateUtil<String, Object>();
		RedisTemplate<String, Object> redisTemplate = redisTemplateUtil
				.getRedisTemplate();
		globalMasterMap = (Map<String, GlobalGSTRatesMasterI>) redisTemplate
				.opsForHash().get(groupCode+"_"+ Constant.REDIS_CACHE,
						Constant.GLOBAL_MASTER_DETAILS);

		String hsnsac = inwardInvoiceModel.gethSNSAC();
		String dateofPayment = (String) inwardInvoiceModel.getDateofPayment();
		Double igstRate = inwardInvoiceModel.gettDSIGSTrate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDSIGSTrate();
		Double cgstRate = inwardInvoiceModel.gettDSCGSTrate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDSCGSTrate();
		Double sgstRate = inwardInvoiceModel.gettDSGSTrate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDSGSTrate();
		Double utgstRate = inwardInvoiceModel.gettDSUTGSTrate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDSUTGSTrate();
		Double cessRate = inwardInvoiceModel.getCessRate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.getCessRate();

		GlobalGSTRatesMasterI globalMaster = globalMasterMap.get(hsnsac);
		String dateofeffective;
		if(globalMaster.getExempted_tds_effectiveDate()!=null)
		dateofeffective = globalMaster.getExempted_tds_effectiveDate();
		Double igstMasterRate = globalMaster.getGst_tds_igst() == null ? Constant.ZERO_DOUBLE
				: globalMaster.getGst_tds_igst().doubleValue();
		Double cgstMasterRate = globalMaster.getGst_tds_cgst() == null ? Constant.ZERO_DOUBLE
				: globalMaster.getGst_tds_cgst().doubleValue();
		Double sgstMasterRate = globalMaster.getGst_tds_sgst() == null ? Constant.ZERO_DOUBLE
				: globalMaster.getGst_tds_sgst().doubleValue();
		Double utgstMasterRate = globalMaster.getGst_tds_utgst() == null ? Constant.ZERO_DOUBLE
				: globalMaster.getGst_tds_utgst().doubleValue();
		Double cessMasterRate = globalMaster.getGst_tds_cess() == null ? Constant.ZERO_DOUBLE
				: globalMaster.getGst_tds_cess().doubleValue();

		SimpleDateFormat formatter=new SimpleDateFormat("MMddyyyy");
		Date dtofPayment = null;
		Date dtofeffective = null;
		try {
			dtofPayment = formatter.parse(dateofPayment);
			dtofeffective = formatter.parse(dateofeffective);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
		if (dtofPayment.compareTo(dtofeffective) >= 0) {
			//System.out.println("Date of payment is after the date of tds effective");
			//if(igstRate != igstMasterRate && cgstRate != cgstMasterRate && sgstRate != sgstMasterRate && utgstRate != utgstMasterRate && cessRate != cessMasterRate )
			if (igstRate != Constant.ZERO_DOUBLE && igstRate != igstMasterRate) {
				globalMaster.setGst_tds_igst(BigDecimal.valueOf(igstRate));
				log.info("IGST Rate of TDS is not same as stored in GST rates master table");
				return false;
			}
			if (cgstRate != Constant.ZERO_DOUBLE && cgstRate != cgstMasterRate) {
				globalMaster.setGst_tds_cgst(BigDecimal.valueOf(cgstRate));
				log.info("CGST Rate of TDS is not same as stored in GST rates master table");
				return false;
			}
			if (sgstRate != Constant.ZERO_DOUBLE && sgstRate != sgstMasterRate) {
				globalMaster.setGst_tds_sgst(BigDecimal.valueOf(sgstRate));
				log.info("SGST Rate of TDS is not same as stored in GST rates master table");
				return false;
			}
			if (utgstRate != Constant.ZERO_DOUBLE && utgstRate != utgstMasterRate) {
				globalMaster.setGst_tds_utgst(BigDecimal.valueOf(utgstRate));
				log.info("UTGST Rate of TDS is not same as stored in GST rates master table");
				return false;
			}
			if (cessRate != Constant.ZERO_DOUBLE && cessRate != cessMasterRate) {
				globalMaster.setGst_tds_cess(BigDecimal.valueOf(cessRate));
				log.info("CESS Rate of TDS is not same as stored in GST rates master table");
				return false;
			}
		//}

		return true;
	}
*/
	// Rule 16
	private boolean validateTdsComputation(InwardInvoiceModelGstr7 inwardInvoiceModel) {
		DecimalFormat df = new DecimalFormat("0.00");

		Double valueOnTDS = inwardInvoiceModel.getValueOnTDS() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.getValueOnTDS();
		Double igstRate = inwardInvoiceModel.gettDSIGSTrate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDSIGSTrate();
		Double cgstRate = inwardInvoiceModel.gettDSCGSTrate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDSCGSTrate();
		Double sgstRate = inwardInvoiceModel.gettDSGSTrate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDSGSTrate();
		Double utgstRate = inwardInvoiceModel.gettDSUTGSTrate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDSUTGSTrate();
		Double cessRate = inwardInvoiceModel.getCessRate() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.getCessRate();

		double tds_CGST = Double.valueOf(df.format(cgstRate * valueOnTDS));
		double tds_IGST = Double.valueOf(df.format(igstRate * valueOnTDS));
		double tds_SGST = Double.valueOf(df.format(sgstRate * valueOnTDS));
		double tds_UTGST = Double.valueOf(df.format(utgstRate * valueOnTDS));
		double tds_Cess = Double.valueOf(df.format(cessRate * valueOnTDS));

		double cgst = inwardInvoiceModel.gettDS_CGST() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDS_CGST();
		double igst = inwardInvoiceModel.gettDS_IGST() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDS_IGST();
		double sgst = inwardInvoiceModel.gettDS_SGST() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDS_SGST();
		double utgst = inwardInvoiceModel.gettDSUTGST() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDSUTGST();
		double cess = inwardInvoiceModel.gettDS_Cess() == null ? Constant.ZERO_DOUBLE
				: inwardInvoiceModel.gettDS_Cess();

		if ((tds_CGST != cgst) && (tds_IGST != igst) && (tds_SGST != sgst)
				&& (tds_UTGST != utgst) && (tds_Cess != cess)) {
			errorList.add(ErrorActionUtility.getTdsTblErrorInfo(
					inwardInvoiceModel.getId(), "INXXX", Constant.TAX,
					Constant.BUSINESS_RULE, false,
					inwardInvoiceModel.getDocumentNo(),
					inwardInvoiceModel.getCompanyGSTIN(), Constant.INVOICE));
			log.info("Amount of TDS has not been computed correctly");
			return false;
		}
		return true;
	}

	/*// Rule 13 removed
	private boolean validateStateCode(InwardInvoiceModelGstr7 inwardInvoiceModel) {
		String supplierStateCode = StringUtils.substring(
				inwardInvoiceModel.getSupplierGSTIN(), 0, 2);
		String recepientStateCode = StringUtils.substring(
				inwardInvoiceModel.getCompanyGSTIN(), 0, 2);
		if (!inwardInvoiceModel.getpOS().equals(supplierStateCode)
				&& !supplierStateCode.equals(recepientStateCode)
				&& !inwardInvoiceModel.getpOS().equals(recepientStateCode)) {
			errorList.add(ErrorActionUtility.getTdsTblErrorInfo(
					inwardInvoiceModel.getId(), "INXXX", Constant.POS,
					Constant.BUSINESS_RULE, false,
					inwardInvoiceModel.getDocumentNo(),
					inwardInvoiceModel.getCompanyGSTIN(), Constant.INVOICE));
			log.info("TDS flag is set to yes; but POS and recipient state code and supplier state code are not same");
			return false;
		}
		return true;
	}*/

	/*// Rule 11 removed
	private boolean validateDupInv(InwardInvoiceModelGstr7 inwardInvoiceModel,
			String groupCode) {
		Gson gson = new Gson();
		String jsonString = gson.toJson(inwardInvoiceModel);
		List<InwardInvoiceModel> invList = null;
		ClientResponse response = new RestClientUtility()
				.getRestServiceResponse("GSTR2_Host",
						"asp-restapi.validateDupInv", groupCode, jsonString,
						Constant.VERB_TYPE_POST);

		if (response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
			 invList = (List<InwardInvoiceModel>) redisTemplate.opsForHash()
                    .get(groupCode+"_"+Constant.REDIS_CACHE, Constant.INVOICE_LIST);
                
                clientData = questionAnswerMappingMap.get(PAN);
            }
			errorList.add(ErrorActionUtility.getTdsTblErrorInfo(
					inwardInvoiceModel.getId(), "INXXX", Constant.INVOICE,
					Constant.BUSINESS_RULE, false,
					inwardInvoiceModel.getDocumentNo(),
					inwardInvoiceModel.getCompanyGSTIN(), Constant.INVOICE));
			log.info("The invoice no. "
					+ inwardInvoiceModel.getDocumentNo()
					+ " for GSTIN "
					+ inwardInvoiceModel.getCompanyGSTIN()
					+ " has already been reflected in this or earlier return. Please consider the earlier deductions as well");
			return false;
		}
		return true;
	}*/

	/*
	 * //Rule 10 removed
	 * private boolean validateAdvTds(InwardInvoiceModel
	 * inwardInvoiceModel) {
	 * if(inwardInvoiceModel.getInwardSuppliesSubjectTTDS()
	 * .startsWith(Constant.Y) ||
	 * inwardInvoiceModel.getInwardSuppliesSubjectTTDS().equals(Constant.NA)){
	 * errorList
	 * .add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel
	 * .getId(), "INXXX", Constant.TDS, Constant.BUSINESS_RULE, false,
	 * inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCompanyGSTIN(),
	 * Constant.INVOICE));
	 * log.info("Whether TDS has been deducted earlier shall be Yes or NA");
	 * return false; } return true; }
	 */

	/*// Rule 7 removed 
	private boolean validateInv(InwardInvoiceModelGstr7 inwardInvoiceModel) {
		if (inwardInvoiceModel.getDocumentType().endsWith(Constant.INV)
				|| inwardInvoiceModel.getDocumentType().endsWith(Constant.DR)
				|| inwardInvoiceModel.getDocumentType().endsWith(Constant.CR)
				|| inwardInvoiceModel.getDocumentType().endsWith(Constant.ADV)) {
			if (inwardInvoiceModel.getDocumentDate().equals(null)) {
				errorList
						.add(ErrorActionUtility.getTdsTblErrorInfo(
								inwardInvoiceModel.getId(), "INXXX",
								Constant.INVOICE, Constant.BUSINESS_RULE,
								false, inwardInvoiceModel.getDocumentNo(),
								inwardInvoiceModel.getCompanyGSTIN(),
								Constant.INVOICE));
				log.info("Please mention the document date for document number "
						+ inwardInvoiceModel.getDocumentNo());
				return false;
			}
		}
		return true;
	}*/

	/*// Rule 14 removed
	private boolean validateContractVal(InwardInvoiceModelGstr7 inwardInvoiceModel,
			String groupCode) {
		Gson gson = new Gson();
		String jsonString = gson.toJson(inwardInvoiceModel);
		ClientResponse response = new RestClientUtility()
				.getRestServiceResponse("GSTR2_Host",
						"asp-restapi.validateContractVal", groupCode,
						jsonString, Constant.VERB_TYPE_POST);

		if (response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
			errorList.add(ErrorActionUtility.getTdsTblErrorInfo(
					inwardInvoiceModel.getId(), "INXXX", Constant.CONTRACT,
					Constant.BUSINESS_RULE, false,
					inwardInvoiceModel.getDocumentNo(),
					inwardInvoiceModel.getCompanyGSTIN(), Constant.INVOICE));
			log.info("Total value of invoices under contract No. "
					+ inwardInvoiceModel.getContractNumber() + " for GSTIN "
					+ inwardInvoiceModel.getSupplierGSTIN()
					+ " exceeds contract value");
			return false;
		}
		return true;
	}*/

	/* Removed (Business Rule ID 1, Business Rule ID 6 )
	 * Business Rule ID 1, Business Rule ID 6 Rule 1 :Validating TDS
	 * Applicability based on TDS Flag(Yes,No) Rule 6 :TDS Flag = Yes && doc
	 * type = INV or ADV or DR or CR or RINV OR RADV or RDR or RCR;
	 
	private Boolean validateTDSFlagAndDocType(InwardInvoiceModelGstr7 invoice) {
		String tdsFlag = invoice.getInwardSuppliesSubjectTTDS();
		String docType = invoice.getDocumentType();

		if (tdsFlag != null) {
			if (tdsFlag.equals(Constant.N)) {
				log.info("TDS flag is set to No");
				invoice.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getTdsTblErrorInfo(
						invoice.getId(), "ER057", "InwardSuppliesSubjectTTDS",
						Constant.BUSINESS_RULE, false, invoice.getDocumentNo(),
						invoice.getCompanyGSTIN(),
						Constant.INCIDENCE_LEVEL_INVOICE));
				return false;
			} else if (tdsFlag.equals(Constant.Y)) {
				if (!(docType.equals(Constant.INV)
						|| docType.equals(Constant.ADV)
						|| docType.equals(Constant.DR)
						|| docType.equals(Constant.CR)
						|| docType.equals(Constant.RINV)
						|| docType.equals(Constant.RADV)
						|| docType.equals(Constant.RDR) || docType
							.equals(Constant.RCR))) {
					log.info("TDS flag is yes, but document type is other than CR,DR,ADV,INV,RCR,RDR,RINV,RADV");//CHCK
					invoice.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getTdsTblErrorInfo(
							invoice.getId(), "ER059", "DocumentType",
							Constant.BUSINESS_RULE, false,
							invoice.getDocumentNo(), invoice.getCompanyGSTIN(),
							Constant.INCIDENCE_LEVEL_INVOICE));
					return false;
				}
			}
		} else {
			// confirm the rule for TDS flag = null (GSTR7COMMENT)
		}
		return true;
	}
*/
	/**
	 * Removed - Business Rule Id - 4
	 * 
	 * @param invoice
	 * @return
	 *//*
	private Boolean validateContractValue(InwardInvoiceModelGstr7 invoice) {
		String tdsFlag = invoice.getInwardSuppliesSubjectTTDS();
		if (tdsFlag.equals(Constant.Y)) {
			if (invoice.getContractValue() != null
					&& invoice.getContractValue() < 250000) {
				log.info("Contract value of Contract no. "
						+ invoice.getContractNumber()
						+ " is below the threshold limit and hence TDS should not be deducted on Invoice/document no.");
				invoice.setItemStatus(Constant.BUS_RULE_ERROR);// Create Error
																// Codes
				errorList.add(ErrorActionUtility.getTdsTblErrorInfo(
						invoice.getId(), "ER060", "ContractValue",
						Constant.BUSINESS_RULE, false, invoice.getDocumentNo(),
						invoice.getCompanyGSTIN(),
						Constant.INCIDENCE_LEVEL_INVOICE));
				return false;
			}
		}
		return true;
	}*/

	/*
	 * Business Rule ID 3 Verify if the Supplier GSTIN is not NULL.
	 */
	private Boolean verifySupplierGSTIN(InwardInvoiceModelGstr7 invoice) {
		String supplierGSTIN = invoice.getSupplierGSTIN();
		if (supplierGSTIN == null) {// Check if we need to check empty also
			log.info("GSTIN of the supplier with contract no. "
					+ invoice.getContractNumber() + " is not available");
			invoice.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList
					.add(ErrorActionUtility.getTdsTblErrorInfo(
							invoice.getId(), "ER058", "SupplierGSTIN",
							Constant.BUSINESS_RULE, false,
							invoice.getDocumentNo(), invoice.getCompanyGSTIN(),
							Constant.INCIDENCE_LEVEL_INVOICE));
			return false;
		}
		return true;
	}
	
	/*private Date getCutOffStartDate(Date documentDate) {
        if(documentDate != null){
            Calendar cal = Calendar.getInstance();
            cal.setTime(documentDate);
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);

            if(month < Calendar.OCTOBER){
                cal.set(year-1, Constant.CUTOFF_START_MONTH, Constant.CUTOFF_START_DATE);
            }else{
                cal.set(year, Constant.CUTOFF_START_MONTH, Constant.CUTOFF_START_DATE);
            }
            return cal.getTime();
        }
        return null;
    }

    private Date getCutOffEndDate(Date documentDate){
        if(documentDate != null){
            Calendar cal = Calendar.getInstance();
            cal.setTime(documentDate);
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);

            if(month < Calendar.OCTOBER){
				cal.set(year, month-1, 1);
				cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			}else{
				cal.set(year, Constant.CUTOFF_END_MONTH, Constant.CUTOFF_END_DATE);
			}
            cal.set(year, month-1, 1);
            cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
            return cal.getTime();
        }
        return null;
    }*/

	@Override
	public InwardInvoiceGstr7DTO executeLineItemValidationRules(
			InwardInvoiceGstr7DTO inwardInvoiceDTO) {
		return inwardInvoiceDTO;
	}
	
}
