package com.ey.advisory.asp.redis.mapper;

import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.InwardInvoiceModelGstr7;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RedisTemplateUtil;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.dto.InwardInvoiceGstr7DTO;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;

/**

* @author  Nisha Kumari
* @version 1.0
* @since   30-05-2017
*/
public class TdsRegRedisCompute extends CustomBaseRichBolt {
	
/**
	 * 
	 */
private static final long serialVersionUID = 1L;
private final Logger log = LoggerFactory.getLogger(getClass());
private CustomOutputCollector collector;
	
	
	
	@Override
    public void execute(Tuple input) {
		  int count=0;
	      String key="";
        StringBuffer keyGen=new StringBuffer();
        InwardInvoiceModelGstr7 stgTable=null;
      
        try {
        	InwardInvoiceGstr7DTO inwardInvoiceDTO = (InwardInvoiceGstr7DTO) input.getValue(0);
            
            if(inwardInvoiceDTO!=null && inwardInvoiceDTO.getLineItemList()!=null &&  !inwardInvoiceDTO.getLineItemList().isEmpty()){
            	stgTable = inwardInvoiceDTO.getLineItemList().get(0);
	          
            	if(inwardInvoiceDTO.getInvStatus() !=null && inwardInvoiceDTO.getInvStatus().equalsIgnoreCase(Constant.GSTR7_BR_STG1) ){
					keyGen.append(stgTable.getfILEID()).append("~").append(stgTable.getTableType()).append(Constant.PROCESSED_SUCCESS);
				}else{
					keyGen.append(stgTable.getfILEID()).append("~").append(stgTable.getTableType()).append(Constant.PROCESSED_ERROR);
				}
	         }
              
            key = keyGen.toString().toLowerCase();
            RedisTemplateUtil<String, Object> redisTemplateUtil= new RedisTemplateUtil<String, Object>();
            RedisTemplate<String,Object> redisTemplate=redisTemplateUtil.getRedisTemplate();
            
            if(redisTemplate.opsForHash().get(Constant.REDIS_INVOICE_CHANNEL, key)==null){
            	//map.put(key, Constant.ZERO);
            	redisTemplate.opsForHash().put(Constant.REDIS_INVOICE_CHANNEL,key,Constant.INTIEGER_ZERO);
            	
            }
           else{
            		count=(Integer) redisTemplate.opsForHash().get(Constant.REDIS_INVOICE_CHANNEL,key);
            		//count=Integer.parseInt(countStr)+1;
            		count=count+1;
            		//map.put(key, Integer.toString(count));
            		redisTemplate.opsForHash().put(Constant.REDIS_INVOICE_CHANNEL,key,count);
            	}
        }catch(Exception ex){
        	log.info(ex.getMessage());
        	collector.customReportError(input, ex, "Exception in Bolt TDSRegRedisCompute");
        }
        finally {
        	collector.ack(input);
        	this.collector.emit(new Values(key,count));
		}
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("tabletype", "count"));
    }

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		
		 this.collector=collector;
	}
}

