package com.ey.advisory.asp.common;

import org.apache.storm.kafka.ZkHosts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DynamicZkHosts extends ZkHosts{
	
	private static final long serialVersionUID = -5932452709116801605L;
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	public DynamicZkHosts(StormClusterUtil azureZKHostUtil) {
		super(azureZKHostUtil.getKafkaZKhosts());	
		if(log.isInfoEnabled())
		log.info("CustomZkHosts: Setting Kafka ZK hosts to : "+azureZKHostUtil.getKafkaZKhosts());
		
	}

}
