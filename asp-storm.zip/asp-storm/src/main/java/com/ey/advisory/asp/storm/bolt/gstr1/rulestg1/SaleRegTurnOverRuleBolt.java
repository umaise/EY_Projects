package com.ey.advisory.asp.storm.bolt.gstr1.rulestg1;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.HsnSacUtil;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.KnowledgeBaseSingleton;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.storm.bolt.common.BoltBuilder;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.sun.jersey.api.client.ClientResponse;

public class SaleRegTurnOverRuleBolt extends BoltBuilder {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private CustomOutputCollector collector;
	EntityModel entityModel;
	private RedisTemplate<String, Object> redisTemplate;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private String pan = null;
	private KnowledgeBase kbase = null;
	RestClientUtility restClientUtil = null;

	/* public SaleRegTurnOverRuleBolt(Properties configs) {
        super(configs);
    }*/

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void prepare(Map stormConf, TopologyContext context,
			CustomOutputCollector collector) {
		this.collector = collector;
		restClientUtil = new RestClientUtility();
		try {
			log.info("In SaleRegTurnOverRuleBolt.prepare() start");
			
			this.kbase =  KnowledgeBaseSingleton.getKnowledgeBaseFromSERFile("/GSTR1_LineItemValidation.ser");

			redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();
			if(log.isInfoEnabled())
				log.info("In SaleRegTurnOverRuleBolt.prepare() ends");

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(Tuple input) {

		OutwardInvoiceDTO outwardInvoiceDTO=null;
		LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();	
		long startTime=System.currentTimeMillis();
		int invOrder=0;
		try {

			outwardInvoiceDTO = (OutwardInvoiceDTO) input.getValue(0);
            OutwardInvoiceModel stgTbl = outwardInvoiceDTO.getLineItemList().get(0);
			Set<TblSalesErrorInfo> errorList = outwardInvoiceDTO.getErrorList();
            Double totalTaxAmount;
            Double totalTaxRate;

            invOrder=stgTbl.getInvOrder();

            log.info("In SaleRegTurnOverRuleBolt.execute() start");
            log.info("In SaleRegTurnOverRuleBolt  redis key : "+outwardInvoiceDTO.getRedisKey() + " Invoice order : "+stgTbl.getInvOrder());

			if (errorList == null) {
				errorList = new HashSet<TblSalesErrorInfo>();
            }else{
                errorList = outwardInvoiceDTO.getErrorList();
			}

            BigDecimal grossTurnover = Utility.getGrossTurnover(stgTbl.getsGSTIN(), redisTemplate, outwardInvoiceDTO.getGroupCode());

			//FileInputStream fout = new FileInputStream("GSTR1_LineItemValidation.ser");
			/*InputStream fout = SaleRegTurnOverRuleBolt.class.getResourceAsStream("/GSTR1_LineItemValidation.ser");
                log.info("GSTR1_LineItemValidation.ser : "+fout);
    			ObjectInputStream oos = new ObjectInputStream(fout);

    			Collection<KnowledgePackage> knowledgePackages = (Collection<KnowledgePackage>) oos.readObject();
    			KieBaseConfiguration kBaseConfig = KnowledgeBaseFactory.newKnowledgeBaseConfiguration();
    			KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase(kBaseConfig);
    			kbase.addKnowledgePackages(knowledgePackages);*/

			StatefulKnowledgeSession kSession = kbase.newStatefulKnowledgeSession();	

			Map<String,Set<BigDecimal>> globalRatesMap = (Map<String,Set<BigDecimal>>)redisTemplate.opsForHash().get(Constant.REDIS_CACHE, Constant.GLOBAL_RATES_MAP);
			Set<Double> igstList = new HashSet<>();
			Set<Double> cgstList = new HashSet<>();
			Set<Double> sgstList = new HashSet<>();

			if(globalRatesMap!=null && !globalRatesMap.isEmpty()) {
				igstList = Utility.converBigDecimalToDouble(globalRatesMap.get(Constant.IGST_RATE_LIST));
				cgstList = Utility.converBigDecimalToDouble(globalRatesMap.get(Constant.CGST_RATE_LIST));
				sgstList = Utility.converBigDecimalToDouble(globalRatesMap.get(Constant.SGST_RATE_LIST));
			}

			kSession.setGlobal("errorList", errorList);
			kSession.setGlobal("grossTurnover", grossTurnover);
			kSession.setGlobal("hsnSacUtil", new HsnSacUtil());
			kSession.setGlobal("groupCode", outwardInvoiceDTO.getGroupCode());
			kSession.setGlobal("PAN", pan);
			kSession.setGlobal("igstList", igstList);
			kSession.setGlobal("cgstList", cgstList);
			kSession.setGlobal("sgstList", sgstList);
			kSession.setGlobal("log", log);

			for(OutwardInvoiceModel stgTable : outwardInvoiceDTO.getLineItemList()) {

				totalTaxAmount = Constant.ZERO_DOUBLE;
	            totalTaxRate = Constant.ZERO_DOUBLE;
	            
	            prepareModel(stgTable);
	            
				totalTaxAmount = stgTable.getIgstAmount() + stgTable.getSgstAmount() + stgTable.getCgstAmount() + stgTable.getCessAmountSpecific() + stgTable.getCessAmountAdvalorem();
				totalTaxRate = stgTable.getIgstRate() + stgTable.getCgstRate() + stgTable.getSgstRate() + stgTable.getCessRateSpecific() +stgTable.getCessRateAdvalorem();

				kSession.setGlobal("totalTaxAmount", totalTaxAmount);
				kSession.setGlobal("totalTaxRate", totalTaxRate);
				kSession.insert(stgTable);

				kSession.fireAllRules();
				if ((outwardInvoiceDTO.getInvStatus() == null
						|| outwardInvoiceDTO.getInvStatus().equals(
								Constant.GSTR1_BR_STG1)) && stgTable.getItemStatus() != null) {
					outwardInvoiceDTO.setInvStatus(stgTable.getItemStatus());
				}
			}

			kSession.destroy();
			// write an else with no details available
			if(errorList.size()>0){
				outwardInvoiceDTO.setErrorList(errorList);
			}

			collector.emit(input,new Values(outwardInvoiceDTO));

			log.info("Turn Over check complete");

		} catch (JsonSyntaxException ex) {
			log.error("Error SaleRegTurnOverRuleBolt", ex);
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);

		} catch (Exception ex1) {
			log.error("Error SaleRegTurnOverRuleBolt", ex1);
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}finally {
			collector.ack(input);
			log.info("In SaleRegTurnOverRuleBolt Time taken for file : "+outwardInvoiceDTO.getRedisKey()+" Inv Order : "+ invOrder+" is "+(System.currentTimeMillis()-startTime));
		}

	}

	private void prepareModel(OutwardInvoiceModel stgTable) {
		
		stgTable.setCgstRate(stgTable.getCgstRate()==null? Constant.ZERO_DOUBLE: stgTable.getCgstRate());
		stgTable.setIgstRate(stgTable.getIgstRate()==null? Constant.ZERO_DOUBLE: stgTable.getIgstRate());
		stgTable.setSgstRate(stgTable.getSgstRate()==null? Constant.ZERO_DOUBLE: stgTable.getSgstRate());
		stgTable.setCessRateSpecific(stgTable.getCessRateSpecific()==null? Constant.ZERO_DOUBLE: stgTable.getCessRateSpecific());
		stgTable.setCessRateAdvalorem(stgTable.getCessRateAdvalorem()==null? Constant.ZERO_DOUBLE: stgTable.getCessRateAdvalorem());

		stgTable.setCgstAmount(stgTable.getCgstAmount()==null? Constant.ZERO_DOUBLE: stgTable.getCgstAmount());
		stgTable.setIgstAmount(stgTable.getIgstAmount()==null? Constant.ZERO_DOUBLE: stgTable.getIgstAmount());
		stgTable.setSgstAmount(stgTable.getSgstAmount()==null? Constant.ZERO_DOUBLE: stgTable.getSgstAmount());
		stgTable.setCessAmountSpecific(stgTable.getCessAmountSpecific()==null? Constant.ZERO_DOUBLE: stgTable.getCessAmountSpecific());
		stgTable.setCessAmountAdvalorem(stgTable.getCessAmountAdvalorem()==null? Constant.ZERO_DOUBLE: stgTable.getCessAmountAdvalorem());	

		stgTable.setTaxableValue(stgTable.getTaxableValue()==null? Constant.ZERO_DOUBLE: stgTable.getTaxableValue());
		stgTable.setInvoiceValue(stgTable.getInvoiceValue()==null? Constant.ZERO_DOUBLE: stgTable.getInvoiceValue());

		if(stgTable.getHsnsac()!=null)
			stgTable.setHsnsac(stgTable.getHsnsac().trim().isEmpty()? null: stgTable.getHsnsac());
		if(stgTable.getShippingBillNo()!=null)
			stgTable.setShippingBillNo(stgTable.getShippingBillNo().trim().isEmpty()? null: stgTable.getShippingBillNo());
		
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR1_Stream1, new Fields("inv"));
	}
}
