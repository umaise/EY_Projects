package com.ey.advisory.asp.storm.bolt.common;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import com.ey.advisory.asp.client.domain.InwardInvoiceModelGstr6;
import com.ey.advisory.asp.client.domain.InwardInvoiceModelGstr7;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RedisTemplateUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.dto.InwardInvoiceGstr7DTO;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleService;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleServiceImpl;
import com.ey.advisory.asp.service.gstr7.Gstr7ValidationRuleService;
import com.ey.advisory.asp.service.gstr7.Gstr7ValidationRuleServiceImpl;

public class GSTR7RedisWSBolt extends CustomBaseRichBolt {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -463916378613289230L;

	private CustomOutputCollector collector;
	
	private Gstr7ValidationRuleService ValidationRuleService;

	 //private Integer count=0;
	 private final Logger log = LoggerFactory.getLogger(getClass());
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		ValidationRuleService = new Gstr7ValidationRuleServiceImpl();	   		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(Tuple input) {
		
		log.info("In GSTR7RedisWSBolt.execute() start");
		
		InwardInvoiceGstr7DTO inwardInvoiceDTO = (InwardInvoiceGstr7DTO) input.getValue(0);
		
		RedisTemplateUtil<String, Object> redisTemplateUtil= new RedisTemplateUtil<String, Object>();
        RedisTemplate<String,Object> redisTemplate=redisTemplateUtil.getRedisTemplate();
        
        RedisTemplateUtil<String, Integer> redisIntegertemplateUtil= new RedisTemplateUtil<String, Integer>();
        RedisTemplate<String, Integer> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
        redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.setValueSerializer(new GenericToStringSerializer<Integer>(Integer.class));
        redisIntegertemplate.afterPropertiesSet();
        
        
        String redisKey=inwardInvoiceDTO.getRedisKey();
        String invCntKey=redisKey+"_"+Constant.INVOICE_COUNT;
        String invStatusKey=redisKey+"_"+Constant.INVOICE_STATUS;
        String invErrKey=redisKey+"_"+Constant.INVOICE_ERROR_DETAILS;
        
        InvoiceProcessDto invProcessDto=new InvoiceProcessDto();
        InwardInvoiceModelGstr7 inwardStagingDetail=inwardInvoiceDTO.getLineItemList().get(0);
        
        //Integer count=Integer.parseInt(jedis.hmget(redisKey, invCntKey).get(0));
        
		try{
			  Set<InvoiceProcessDto> invProcessSet;
              Set<TblTdsErrorInfo> errorSet;
              
              //RedisAtomicInteger count=new RedisAtomicInteger(invCntKey,redisTemplate.getConnectionFactory());
              RedisAtomicInteger count=new RedisAtomicInteger(invCntKey,redisIntegertemplate);
              
              System.out.println("Count****"+ count);
                     
              invProcessDto.setDocNum(inwardStagingDetail.getDocumentNo());
              invProcessDto.setDocumentDate(inwardStagingDetail.getDocumentDate());
              invProcessDto.setTaxperiod(inwardStagingDetail.getTaxPeriod());
              invProcessDto.setStatus(inwardInvoiceDTO.getInvStatus());
              invProcessDto.setTableType(inwardStagingDetail.getTableType());
              invProcessDto.setInvOrder(inwardStagingDetail.getInvOrder());
              invProcessDto.setcGstin(inwardStagingDetail.getCompanyGSTIN());
              
              redisTemplate.opsForHash().get(redisKey, invStatusKey); 
              if(redisTemplate.opsForHash().get(redisKey, invStatusKey) == null){
            	  invProcessSet=new HashSet<InvoiceProcessDto>();
              }else{
            	  invProcessSet=(Set<InvoiceProcessDto>) redisTemplate.opsForHash().get(redisKey, invStatusKey);
              }
              invProcessSet.add(invProcessDto);
              redisTemplate.opsForHash().put(redisKey, invStatusKey,invProcessSet);
              
              Set<TblTdsErrorInfo> errorList=inwardInvoiceDTO.getErrorList();
              
              if(redisTemplate.opsForHash().get(redisKey, invErrKey)==null){
            	  errorSet=new HashSet<TblTdsErrorInfo>();
              }else{
            	  errorSet=(Set<TblTdsErrorInfo>) redisTemplate.opsForHash().get(redisKey, invErrKey);
              }
              if(errorList!=null && !errorList.isEmpty()){
            	  errorSet.addAll(errorList);
            	  redisTemplate.opsForHash().put(redisKey, invErrKey,errorSet);
              }
              
  
            
            	  if(count.intValue()==1){
                	  
            		  synchronized (count) {
					
                	  log.info("In GSTR7RedisWSBolt.execute() inside Rest"+ count);
                	//Trigger web service to update invoice status and error details 
                	  RestClientUtility restClientUtil = new RestClientUtility();
  					//  restClientUtil.callRestService(Constant.REDIS_INVOICE_CHANNEL);
                	  restClientUtil.getRestServiceResponse("GSTR6_Host", "asp-restapi.saveGstr7Invoice", inwardInvoiceDTO.getGroupCode(), redisKey,  Constant.VERB_TYPE_POST);
            		  }
          			
                	  
                  }
                 /* else{
                
                	  count.getAndSet(count.intValue()-1);
                	  log.info("After Detecting"+ count);
                    
                      
                  }
              */
              
              
        }catch(Exception ex){
        	  log.info(ex.getMessage());
              collector.customReportError(input, ex, "Exception in Bolt GSTR6RedisWSBolt");
        }

		collector.ack(input);
		collector.emit(new Values(inwardInvoiceDTO));
		log.info("In GSTR6RedisWSBolt.execute() end");
	}
	
	@Override
	public void cleanup() {
		// TODO Auto-generated method stub
		super.cleanup();
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("gstr6"));
	}
//rule 1 bolt
	
}

