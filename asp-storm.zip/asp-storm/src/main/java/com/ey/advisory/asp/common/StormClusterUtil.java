package com.ey.advisory.asp.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.MessageFormat;
import java.util.Base64;
import java.util.Properties;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.ey.advisory.asp.common.configs.PasswordProtection;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class StormClusterUtil {
	
	private String kafkaZKHosts="";		
	private String clusterUsername=null;
	private String clusterPasswd= null;
	private String clusterURI = null;
	
	
	public StormClusterUtil(String defaultkafkaZKHosts,String clusterName,String clusterUsername,String clusterPasswd,String clusterURI,String isEncryptedPassword){
		this.kafkaZKHosts = defaultkafkaZKHosts;
		this.clusterUsername = clusterUsername;
		this.clusterPasswd = clusterPasswd;
		this.clusterURI = MessageFormat.format(clusterURI, clusterName,clusterName);	
		boolean passEncrypted = Boolean.parseBoolean(isEncryptedPassword);
		
		if(passEncrypted){
			try {
				this.clusterPasswd = PasswordProtection.getDecriptedPassword(this.clusterPasswd);
			} catch (InvalidKeyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidKeySpecException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchPaddingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidAlgorithmParameterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalBlockSizeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (BadPaddingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public String getKafkaZKhosts(){
		//String kafkaZKHosts="";
		try{
			
			/*Properties props=new Properties();
			
			props.load(StormClusterUtil.class.getResourceAsStream("/rest-config.properties"));*/
			
			//Initialized with default kafka ZK hosts configured in property file
	/*		kafkaZKHosts=props.getProperty("kafka.default.zookeepers");				
			String clusterName= props.getProperty("kafka.cluster.name");
			String clusterUsername=props.getProperty("kafka.cluster.username");
			String clusterPasswd= props.getProperty("kafka.cluster.password");
			String clusterURI= MessageFormat.format(props.getProperty("kafka.cluster.uri"), clusterName,clusterName);
	*/		
			
			URL url = new URL(clusterURI);
			URLConnection uc = url.openConnection();
			
			String userpass = clusterUsername + ":" + clusterPasswd;
			
			String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userpass.getBytes());
	
			uc.setRequestProperty ("Authorization", basicAuth);
		
			InputStream in = uc.getInputStream();
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
	        StringBuilder out = new StringBuilder();
	        
	        String line;	        
	        while ((line = reader.readLine()) != null) {
	            out.append(line);
	        }
	        
	        String responseString=out.toString();
	        JsonElement jelement = new JsonParser().parse(responseString);
	        JsonObject  jobject = jelement.getAsJsonObject();
	        JsonArray jsonArray = jobject.getAsJsonArray("host_components");
	        
	        StringBuilder hosts=new StringBuilder();
	        
	        for (JsonElement jE : jsonArray) {
	        	JsonObject hostObj = jE.getAsJsonObject();
	        	if(hosts.length()==0){
	        		hosts.append(hostObj.getAsJsonObject("HostRoles").get("host_name").getAsString()).append(":2181");
	        	}else{
	        		hosts.append(",").append(hostObj.getAsJsonObject("HostRoles").get("host_name").getAsString()).append(":2181");
	        	}
	        }
			
	        kafkaZKHosts=hosts.toString();
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
		}
		return kafkaZKHosts;
	}
	
}
