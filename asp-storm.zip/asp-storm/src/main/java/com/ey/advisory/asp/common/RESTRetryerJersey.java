package com.ey.advisory.asp.common;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.util.concurrent.Callable;

import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.exceptions.RESTCallFailureException;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

class RESTRetryerJersey implements Callable<Boolean> {

	private final Logger log = LoggerFactory.getLogger(getClass());
	private WebResource.Builder builder;
	private String httpMethod;
	private String payload;
	private String groupCode;
	private Class<ClientResponse> clazz;

	public RESTRetryerJersey(WebResource.Builder builder, String httpMethod,String payload,Class<ClientResponse> clazz,String groupCode) {
		this.builder=builder;
		this.httpMethod=httpMethod;
		this.payload=payload;
		this.clazz=clazz;
		this.groupCode=groupCode;
	}

	  @Override
	  public Boolean call() throws Exception {
		  ClientResponse response = null;
		  builder.type(MediaType.APPLICATION_JSON);
		  builder.header(Constant.TENANT_CODE, this.groupCode);
		    try{
		    	 if("POST".equalsIgnoreCase(httpMethod)){
						response = builder.post(clazz, payload);
					}else if("GET".equalsIgnoreCase(httpMethod)){
						response = builder.get(clazz);
					}
			}catch(ClientHandlerException e){
				log.error("RESTRetryerJersey: Error in saveInvoice");				
			}
		    		    
			if(response==null || response.getStatus() != 200){
				log.error("FAILED : HTTP error code : "+ response);
				// Send e-Mail notification for FAILED server status
				throw new RESTCallFailureException();
			}else{
				// Send e-Mail notification for SUCCESS server status
				log.error("SUCCESS : HTTP code : " + response.getStatus());
			}
	return true;
}}
