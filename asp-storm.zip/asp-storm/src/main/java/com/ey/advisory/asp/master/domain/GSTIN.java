package com.ey.advisory.asp.master.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class GSTIN implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private String gstinId;
	
	
	private String gstin;
	
	
	private String otp;
	
	
	private Date otpExpiryDate;
	
	
	private Boolean isActive;
	
	
	private String createdBy;
	

	private Date createdDate;
	
	
	private String updatedBy;
	
	
	private Date updatedDate;
	
	
	private BigDecimal grossTurnOver;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd",  timezone="IST") 
	private Date regdDt;
	
	
	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Date getOtpExpiryDate() {
		return otpExpiryDate;
	}

	public void setOtpExpiryDate(Date otpExpiryDate) {
		this.otpExpiryDate = otpExpiryDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	
	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getGstinId() {
		return gstinId;
	}

	public void setGstinId(String gstinId) {
		this.gstinId = gstinId;
	}
	
	public BigDecimal getGrossTurnOver() {
		return grossTurnOver;
	}

	public void setGrossTurnOver(BigDecimal grossTurnOver) {
		this.grossTurnOver = grossTurnOver;
	}
	
	public Date getRegdDt() {
		return regdDt;
	}

	public void setRegdDt(Date regdDt) {
		this.regdDt = regdDt;
	}

	

	
	
	

}
