package com.ey.advisory.asp.service.gstr2;

import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;

public abstract class CommonValidationRuleService {

	public abstract InwardInvoiceGstr6DTO executeCommonBusinessRules(
			InwardInvoiceGstr6DTO inwardInvoiceDTO);
	
	public abstract String validateHsnSacAgainstNonGST(String groupCode) ;

}
