package com.ey.advisory.asp.common;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ReconciliationDetailsDTO;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.master.domain.ErrorMasterDto;
import com.ey.advisory.asp.master.domain.PurchaseMetaData;
import com.ey.advisory.asp.master.domain.SupplyMetaData;
import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

public class ErrorActionUtility {

	private final static Logger LOG = LoggerFactory
			.getLogger(ErrorActionUtility.class);

	private static RedisTemplate<String, Object> redisTemplate;

	@SuppressWarnings("unchecked")
	public static TblSalesErrorInfo getSalesTblErrorInfo(OutwardInvoiceModel outwardInvoiceModel, String errorInfoCode, String columnNames, String processStatus,
			boolean isProcessed,String incidenceLevel) {

		String errorColumnId = null;
		try {
			if (errorInfoCode == null) {
				errorInfoCode = "";
			}
			if (processStatus == null) {
				processStatus = "";
			}

			errorColumnId = getSupplyColumnId(columnNames);

			ErrorMasterDto dto = (ErrorMasterDto)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);

			if(dto==null) {
				dto = refreshErrorMasterMap(errorInfoCode);
			}

			if (dto != null) {
				if (dto.getErrorInfoDesc() == null) {
					dto.setErrorInfoDesc("");
				}
				return new TblSalesErrorInfo(outwardInvoiceModel.getId(),outwardInvoiceModel.getFileID(),outwardInvoiceModel.getInvoiceKey(), errorInfoCode,
						dto.getErrorInfoDesc(), errorColumnId,
						processStatus, isProcessed, outwardInvoiceModel.getsGSTIN(),incidenceLevel,dto.getIsError(), Integer.parseInt(outwardInvoiceModel.getLineNumber()), outwardInvoiceModel.getTaxperiod());
			}
		} catch (NullPointerException ne) {
			LOG.error("Error fetching ErrorDescription from Redis: ", ne);
		} catch (Exception e) {
			LOG.error("Error Building TblSalesErrorInfo for invoiceKey: "
					+ outwardInvoiceModel.getInvoiceKey(), e);
		}

		return new TblSalesErrorInfo(outwardInvoiceModel.getId(),outwardInvoiceModel.getFileID(),outwardInvoiceModel.getInvoiceKey(), errorInfoCode,
				Constant.UNKNOWN_ERROR, errorColumnId, processStatus, isProcessed, outwardInvoiceModel.getsGSTIN(),incidenceLevel, Constant.IS_ERROR_E, Integer.parseInt(outwardInvoiceModel.getLineNumber()), outwardInvoiceModel.getTaxperiod());
	}

	private static String getSupplyColumnId(String columnNames) {
		String columnId = "";
		String[] parts = null;
		if (columnNames != null && columnNames.contains(",")) {
			parts = columnNames.split(",");
		} else {
			parts = new String[1];
			parts[0] = columnNames;
		}

		if (parts != null) {
				for (int i = 0; i < parts.length; i++) {
					
					SupplyMetaData supplyMasterObject = (SupplyMetaData)getRedisTemplate().opsForHash().get(Constant.SUPPLY_METADATA, parts[i]);
					if (supplyMasterObject != null) {
						if (i == 0)
							columnId = columnId
							+ supplyMasterObject.getColumnOrderNo()
							.toString();
						else
							columnId = columnId
							+ ", "
							+ supplyMasterObject.getColumnOrderNo()
							.toString();
					}
				}
		}
		return columnId;
	}

	@SuppressWarnings("unchecked")
	public static TblPurchaseErrorInfo getPurchaseTblErrorInfo(InwardInvoiceModel inwardInvoiceModel,
			String errorInfoCode, String columnNames, String processStatus,
			boolean isProcessed,String incidenceLevel) {

		String errorColumnId = null;
		try {
			if (errorInfoCode == null) {
				errorInfoCode = "";
			}
			if (columnNames == null) {
				columnNames = "";
			}
			if (processStatus == null) {
				processStatus = "";
			}
			errorColumnId = getPurchaseColumnId(columnNames);

			ErrorMasterDto dto = (ErrorMasterDto)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);

			if(dto==null) {
				dto = refreshErrorMasterMap(errorInfoCode);
			}

			if (dto != null) {
				if (dto.getErrorInfoDesc() == null) {
					dto.setErrorInfoDesc("");
				}
				return new TblPurchaseErrorInfo(inwardInvoiceModel.getId(), inwardInvoiceModel.getFileID(), inwardInvoiceModel.getInvoiceKey(), errorInfoCode,
						dto.getErrorInfoDesc(),errorColumnId, null,
						processStatus, isProcessed, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, dto.getIsError(), inwardInvoiceModel.getLineNumber(), inwardInvoiceModel.getTaxPeriod());
			}

		} catch (NullPointerException ne) {
			LOG.error("Error fetching ErrorDescription from Redis: ", ne);
		} catch (Exception e) {
			LOG.error("Error Building tblErrorAction for sale staging Id: "
					+ inwardInvoiceModel.getId(), e);
		}

		return new TblPurchaseErrorInfo(inwardInvoiceModel.getId(),(int)inwardInvoiceModel.getFileID(), inwardInvoiceModel.getInvoiceKey(),errorInfoCode,
				Constant.UNKNOWN_ERROR,errorColumnId ,null, processStatus, isProcessed, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, Constant.IS_ERROR_E, inwardInvoiceModel.getLineNumber(), inwardInvoiceModel.getTaxPeriod());
	}

	private static String getPurchaseColumnId(String columnNames) {
		String columnId = "";
		String[] parts = null;
		if (columnNames != null && columnNames.contains(",")) {
			parts = columnNames.split(",");
		} else {
			parts = new String[1];
			parts[0] = columnNames;
		}

		if (parts != null) {
				for (int i = 0; i < parts.length; i++) {
					PurchaseMetaData purchaseMasterObject = (PurchaseMetaData)getRedisTemplate().opsForHash().get(Constant.PURCHASE_METADATA, parts[i]);
					
					if (purchaseMasterObject != null) {
						if (i == 0)
							columnId = columnId
							+ purchaseMasterObject.getColumnOrderNo()
							.toString();
						else
							columnId = columnId
							+ ", "
							+ purchaseMasterObject.getColumnOrderNo()
							.toString();
					}
				}
		}

		return columnId;
	}


	@SuppressWarnings("unchecked")
	public static TblPurchaseErrorInfo getReconErrorInfo(ReconciliationDetailsDTO reconDTO, String errorInfoCode, String columnNames, String processStatus,
			boolean isProcessed,String incidenceLevel) {

		String errorColumnId = null;
		try {
			if (errorInfoCode == null) {
				errorInfoCode = "";
			}
			if (columnNames == null) {
				columnNames = "";
			}
			if (processStatus == null) {
				processStatus = "";
			}
			errorColumnId = getPurchaseColumnId(columnNames);

			ErrorMasterDto dto = (ErrorMasterDto)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);

			if(dto==null) {
				dto = refreshErrorMasterMap(errorInfoCode);
			}

			if (dto != null) {
				if (dto.getErrorInfoDesc() == null) {
					dto.setErrorInfoDesc("");
				}
				return new TblPurchaseErrorInfo(reconDTO.getId(), null, reconDTO.getInvKey(), errorInfoCode,
						dto.getErrorInfoDesc(),errorColumnId, null,
						processStatus, isProcessed, reconDTO.getInvNum(), reconDTO.getCustGSTIN(),incidenceLevel, dto.getIsError(), null, reconDTO.getTaxPeriod());
			}
		} catch (NullPointerException ne) {
			LOG.error("Error fetching ErrorDescription from Redis: ", ne);
		} catch (Exception e) {
			LOG.error("Error Building tblErrorAction for sale staging Id: "
					+ reconDTO.getId(), e);
		}

		return new TblPurchaseErrorInfo(reconDTO.getId(), null, reconDTO.getInvKey(), errorInfoCode, Constant.UNKNOWN_ERROR,errorColumnId ,columnNames, processStatus, isProcessed, 
				reconDTO.getInvKey(), reconDTO.getCustGSTIN(),incidenceLevel, Constant.IS_ERROR_E, null, reconDTO.getTaxPeriod());
	}

	@SuppressWarnings("unchecked")
	public static TblIsdErrorInfo getIsdTblErrorInfo(InwardInvoiceModel inwardInvoiceModel,
			String errorInfoCode, String errorColumnName, String processStatus,
			boolean isProcessed,String incidenceLevel) {

		String errorColumnId = null;

		try {
			if (errorInfoCode == null) {
				errorInfoCode = "";
			}
			if (errorColumnName == null) {
				errorColumnName = "";
			}
			if (processStatus == null) {
				processStatus = "";
			}
			errorColumnId = getPurchaseColumnId(errorColumnName);

			ErrorMasterDto dto = (ErrorMasterDto)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);

			if(dto==null) {
				dto = refreshErrorMasterMap(errorInfoCode);
			}

			if (dto != null) {
				if (dto.getErrorInfoDesc() == null) {
					dto.setErrorInfoDesc("");
				}
				return new TblIsdErrorInfo(inwardInvoiceModel.getId(), inwardInvoiceModel.getFileID(), inwardInvoiceModel.getInvoiceKey(), errorInfoCode,
						dto.getErrorInfoDesc(),errorColumnId,null,
						processStatus, isProcessed, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, dto.getIsError(), inwardInvoiceModel.getLineNumber());
				
			

			}

		} catch (NullPointerException ne) {
			LOG.error("Error fetching ErrorDescription from Redis: ", ne);
		} catch (Exception e) {
			LOG.error("Error Building tblErrorAction for sale staging Id: "
					+ inwardInvoiceModel.getId(), e);
		}

		return new TblIsdErrorInfo(inwardInvoiceModel.getId(),(int)inwardInvoiceModel.getFileID(), inwardInvoiceModel.getInvoiceKey(),errorInfoCode,
				Constant.UNKNOWN_ERROR,errorColumnId,null, processStatus, isProcessed, inwardInvoiceModel.getInvoiceKey(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, Constant.IS_ERROR_E, inwardInvoiceModel.getLineNumber());

	}

	@SuppressWarnings("unchecked")
	public static TblTdsErrorInfo getTdsTblErrorInfo(Integer tdsStagingId,
			String errorInfoCode, String errorColumnName, String processStatus,
			boolean isProcessed, String invoiceNum, String gstin,String incidenceLevel) {

		try {
			if (errorInfoCode == null) {
				errorInfoCode = "";
			}
			if (errorColumnName == null) {
				errorColumnName = "";
			}
			if (processStatus == null) {
				processStatus = "";
			}

			ErrorMasterDto dto = (ErrorMasterDto)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);

			if(dto==null) {
				dto = refreshErrorMasterMap(errorInfoCode);
			}

			if (dto != null) {
				if (dto.getErrorInfoDesc() == null) {
					dto.setErrorInfoDesc("");
				}
				return new TblTdsErrorInfo(tdsStagingId, errorInfoCode,
						dto.getErrorInfoDesc(), errorColumnName,
						processStatus, isProcessed, invoiceNum, gstin,incidenceLevel, dto.getIsError());
			}

		} catch (NullPointerException ne) {
			LOG.error("Error fetching ErrorDescription from Redis: ", ne);
		} catch (Exception e) {
			LOG.error("Error Building tblErrorAction for sale staging Id: "
					+ tdsStagingId, e);
		}

		return new TblTdsErrorInfo(tdsStagingId, errorInfoCode,
				Constant.UNKNOWN_ERROR, errorColumnName, processStatus, isProcessed, invoiceNum, gstin,incidenceLevel, Constant.IS_ERROR_E);
	}

	/**
	 * This method will return M+2 where M=taxPeriod, 
	 * @param taxPeriod
	 * @param errorMsg
	 * @param invoiceId
	 */
	public static String getReconErrorForMisMatch(String errorMsg, String taxPeriod, Integer invoiceId) {
		Calendar cal = Calendar.getInstance();

		String dateStr = taxPeriod;

		if(dateStr != null && !dateStr.isEmpty() && errorMsg != null && !errorMsg.isEmpty()){
			try {
				cal.setTime(Utility.convertStringToDate("MMyyyy", dateStr));
				cal.add(Calendar.MONTH, 2);
				Date timestampNew = new  Date(cal.getTimeInMillis());

				errorMsg = errorMsg.replace("M+2", Utility.convertDateToString("MMM yyyy", timestampNew));
			}
			catch (ParseException e) {
				errorMsg = errorMsg.replace("M+2",taxPeriod+" + 2 months");
				LOG.error("Error parsing date " + taxPeriod + " for ReconErrorForMisMatch for invoice" + (invoiceId != null ? invoiceId : "unknown"), e);
			}
		}
		return errorMsg;
	}

	@SuppressWarnings("unchecked")
	public static String getReconErrorForPending(String errorMsg, Integer invoiceId, String errorInfoCode){

		try {
			if (errorInfoCode == null) {
				errorInfoCode = "";

				ErrorMasterDto dto = (ErrorMasterDto)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);

				if (dto != null) {
					if (dto.getErrorInfoDesc() != null) {

						errorMsg = errorMsg.concat(dto.getErrorInfoDesc().replace("<>", "<" + invoiceId + ">"));
					}
				}
			}
		}catch(Exception e){
			LOG.error("Error Setting Recon Error For Pending transaction "+ invoiceId, e);
		}
		return errorMsg;
	}

	@SuppressWarnings("unchecked")
	public static void validatePurchasePOS(InwardInvoiceModel lineItem, Set<TblPurchaseErrorInfo> errorList, String groupCode){
		if(lineItem != null){
			TblPurchaseErrorInfo errorInfo = null;
			if(errorList == null){
				errorList = new HashSet<TblPurchaseErrorInfo>();
			}
			try{
				String hsnsac = lineItem.getHSNorSAC();
				ItemMaster master = null;
				Map<String, ItemMaster> itemMasterMap = (Map<String, ItemMaster>) getRedisTemplate().opsForHash().get(groupCode+"_"+Constant.REDIS_CACHE, Constant.ITEM_MASTER_DETAILS);

				if(itemMasterMap != null && !itemMasterMap.isEmpty()){
					master = itemMasterMap.get(hsnsac);
					if(master != null){
						if(Constant.Y.equals(master.getNonCreditable())){
							lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
							errorInfo = getPurchaseTblErrorInfo(lineItem, "IN306", "POS", Constant.BUSINESS_RULE, false, Constant.LINE_ITEM);
							if(errorInfo != null && errorInfo.getErrorDesc() != null && !errorInfo.getErrorDesc().isEmpty()){
								errorInfo.setErrorDesc(errorInfo.getErrorDesc().replace("<>", "<" + lineItem.getPos() + ">"));
								errorList.add(errorInfo);
							}
						}
					}else{
						LOG.error("Record not found for " + hsnsac + " in itemMaster");
					}
				}

			}catch(Exception e){
				LOG.error("Error Validating Purchase POS. ", e);
			}
		}
	}

	private static RedisTemplate<String, Object> getRedisTemplate() {
		if(redisTemplate==null) {
			redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();
		}
		return redisTemplate;
	}

	@SuppressWarnings("unchecked")
	private static ErrorMasterDto refreshErrorMasterMap(String errorInfoCode) {
		ErrorMasterDto errorMasterDto = null;
		LOG.info("ErrorCode : "+ errorInfoCode +" not found in Redis, Refreshing errormaster map...");
		try {
			ClientResponse response = new RestClientUtility()
					.getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
							Constant.REFRESH_ERRORMASTER_MAP_REDIS, null, errorInfoCode,
							Constant.VERB_TYPE_POST);
			if (response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
				Gson gson = new Gson();
				errorMasterDto = gson.fromJson(response.getEntity(String.class),
						ErrorMasterDto.class);
			}
		} catch (Exception e) {
			LOG.error("Error refreshing ErrorMasterMap in Redis", e);
		} 

		return errorMasterDto;
	}
}