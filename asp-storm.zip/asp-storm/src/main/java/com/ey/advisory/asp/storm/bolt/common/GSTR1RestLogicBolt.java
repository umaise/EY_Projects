package com.ey.advisory.asp.storm.bolt.common;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;

public class GSTR1RestLogicBolt extends BoltBuilder {

    private CustomOutputCollector collector;

    private final Logger log = LoggerFactory.getLogger(getClass());
    @Override
    public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
        this.collector = collector;
    }

    @Override
    public void execute(Tuple input) {
        OutwardInvoiceDTO outwardInvoiceDTO = null;
        LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();	
        
        long startTime=System.currentTimeMillis();
        int invOrder=0;
        
        try{
        	outwardInvoiceDTO = (OutwardInvoiceDTO) input.getValue(0);
        	
        	RedisTemplate<String,Object> redisTemplate= JedisConnectionUtil.getRedisTemplateKVStringObject();
        	
            String redisKey=outwardInvoiceDTO.getRedisKey();
            
            String invProcessedKey=redisKey+"_"+Constant.INVOICE_PSD_COUNT;
            String invCntKey=redisKey+"_"+Constant.INVOICE_COUNT;
            
            Integer count=(Integer) redisTemplate.opsForValue().get(invCntKey);
            
            if(count==null || count==0 ){
            	 RedisTemplate<String, Integer> redisIntegertemplate=JedisConnectionUtil.getRedisTemplateKVStringInteger();
            	 count=redisIntegertemplate.opsForValue().get(invCntKey);
            	 redisTemplate.opsForValue().set(invCntKey,count);
            }
            
            if(outwardInvoiceDTO.getLineItemList()!=null){
            	OutwardInvoiceModel stgTable = outwardInvoiceDTO.getLineItemList().get(0);
            	invOrder=stgTable.getInvOrder();
            	log.info("In GSTR1RestLogicBolt  redis key : "+outwardInvoiceDTO.getRedisKey() + " Invoice order : "+stgTable.getInvOrder());
            	redisTemplate.opsForHash().put(invProcessedKey,stgTable.getInvOrder(),stgTable.getInvoiceKey());
            }
            
            //Set<Object> psdInvSet= redisTemplate.opsForHash().keys(invProcessedKey);
            //Integer invPsdCnt=psdInvSet.size();
            Long invPsdCnt=redisTemplate.opsForHash().size(invProcessedKey);
            
            log.info("Invoice Count for "+redisKey+" : "+ count);
            log.info("Invoice processed for "+redisKey+" : "+ invPsdCnt);
            
            collector.emit(input,new Values(outwardInvoiceDTO,count,invPsdCnt));
        }
        catch(Exception ex){			
            log.error("Error GSTR1RestLogicBolt", ex);
            logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
        }
        finally {
            collector.ack(input);
            if(log.isInfoEnabled())
            	log.info("In GSTR1RestLogicBolt Time taken for file : "+outwardInvoiceDTO.getRedisKey()+" Inv Order : "+ invOrder+" is "+(System.currentTimeMillis()-startTime));
        }
        
       
    }

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv","invCount","invPsdCnt"));
		
	}

}
