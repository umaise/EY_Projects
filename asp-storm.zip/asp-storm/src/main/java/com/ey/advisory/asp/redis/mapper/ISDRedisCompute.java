package com.ey.advisory.asp.redis.mapper;

import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RedisTemplateUtil;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;

public class ISDRedisCompute extends CustomBaseRichBolt {
	
/**
	 * 
	 */
	private static final long serialVersionUID = 7999696590818254083L;
/**
	 * 
	 */

private final Logger log = LoggerFactory.getLogger(getClass());
private CustomOutputCollector collector;

private RedisTemplate<String, Object> redisTemplate;
	
	
	
	@Override
    public void execute(Tuple input) {
		  int count=0;
	        String key="";
        StringBuffer keyGen=new StringBuffer();
        InwardInvoiceModel stgTable=null;
      
        try {
            InwardInvoiceGstr6DTO InwardInvoiceGstr6DTO = (InwardInvoiceGstr6DTO) input.getValue(0);
            
            if(InwardInvoiceGstr6DTO!=null && InwardInvoiceGstr6DTO.getLineItemList()!=null && !InwardInvoiceGstr6DTO.getLineItemList().isEmpty()){
            	stgTable = InwardInvoiceGstr6DTO.getLineItemList().get(0);
            
            	if(InwardInvoiceGstr6DTO.getInvStatus() !=null && InwardInvoiceGstr6DTO.getInvStatus().equalsIgnoreCase(Constant.GSTR6_BR_STG1) ){
            		keyGen.append(stgTable.getFileID()).append("~").append(stgTable.getTableType()).append(Constant.PROCESSED_SUCCESS);
				}else{
					keyGen.append(stgTable.getFileID()).append("~").append(stgTable.getTableType()).append(Constant.PROCESSED_ERROR);
				}
            }
            
            key = keyGen.toString().toLowerCase();
            /*RedisTemplateUtil<String, Object> redisTemplateUtil= new RedisTemplateUtil<String, Object>();
            RedisTemplate<String,Object> redisTemplate=redisTemplateUtil.getRedisTemplate();*/
            
            if(redisTemplate.opsForHash().get(Constant.REDIS_INVOICE_CHANNEL, key)==null){
            	//map.put(key, Constant.ZERO);
            	redisTemplate.opsForHash().put(Constant.REDIS_INVOICE_CHANNEL,key,Constant.INTIEGER_ZERO);
            	
            }
           else{
            		count=(Integer) redisTemplate.opsForHash().get(Constant.REDIS_INVOICE_CHANNEL,key);
            		//count=Integer.parseInt(countStr)+1;
            		count=count+1;
            		//map.put(key, Integer.toString(count));
            		redisTemplate.opsForHash().put(Constant.REDIS_INVOICE_CHANNEL,key,count);
            	}
        }catch(Exception ex){
        	log.info(ex.getMessage());
        	collector.customReportError(input, ex, "Exception in Bolt ISDRedisCompute");
        }
        finally {
        	collector.ack(input);
        	this.collector.emit(input, new Values(key,count));
		}
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("tabletype", "count"));
    }

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		
		 this.collector=collector;
		 RedisTemplateUtil<String, Object> redisTemplateUtil= new RedisTemplateUtil<String, Object>();
         redisTemplate=redisTemplateUtil.getRedisTemplate();
	}
}
