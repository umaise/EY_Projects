package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;

public class EntityHierarchy implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private final Logger log = LoggerFactory.getLogger(getClass());

	private Integer hierarchyId;
	private Long groupID;
	private String groupCode;
	private String groupName;
	private String circleCode;
	private String circleName;
	private Integer entityID;
	private String entityCode;
	private String entityName;
	private String gSTIN;
	private String subDivCode;
	private String subDivName;
	private String profitCenterCode;
    private String profitCenterName;
    private String businessUnitCode;
    private String businessUnitName;
    private String plantCode;
    private String isActive;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
	public Integer getHierarchyId() {
		return hierarchyId;
	}
	public void setHierarchyId(Integer hierarchyId) {
		this.hierarchyId = hierarchyId;
	}
	public Long getGroupID() {
		return groupID;
	}
	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public String getCircleName() {
		return circleName;
	}
	public void setCircleName(String circleName) {
		this.circleName = circleName;
	}
	public Integer getEntityID() {
		return entityID;
	}
	public void setEntityID(Integer entityID) {
		this.entityID = entityID;
	}
	public String getEntityCode() {
		return entityCode;
	}
	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public String getgSTIN() {
		return gSTIN;
	}
	public void setgSTIN(String gSTIN) {
		this.gSTIN = gSTIN;
	}
	public String getSubDivCode() {
		return subDivCode;
	}
	public void setSubDivCode(String subDivCode) {
		this.subDivCode = subDivCode;
	}
	public String getSubDivName() {
		return subDivName;
	}
	public void setSubDivName(String subDivName) {
		this.subDivName = subDivName;
	}
	public String getProfitCenterCode() {
		return profitCenterCode;
	}
	public void setProfitCenterCode(String profitCenterCode) {
		this.profitCenterCode = profitCenterCode;
	}
	public String getProfitCenterName() {
		return profitCenterName;
	}
	public void setProfitCenterName(String profitCenterName) {
		this.profitCenterName = profitCenterName;
	}
	public String getBusinessUnitCode() {
		return businessUnitCode;
	}
	public void setBusinessUnitCode(String businessUnitCode) {
		this.businessUnitCode = businessUnitCode;
	}
	public String getBusinessUnitName() {
		return businessUnitName;
	}
	public void setBusinessUnitName(String businessUnitName) {
		this.businessUnitName = businessUnitName;
	}
	public String getPlantCode() {
		return plantCode;
	}
	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	/*public boolean isEqualHierarchy(Object lineItem, String identifier) {
		try{
			if(((this.circleName == null && (lineItem.getDivision() == null || lineItem.getDivision().trim().isEmpty())) || (this.circleName != null && lineItem.getDivision() != null && this.circleName.trim().equalsIgnoreCase(lineItem.getDivision().trim())))
					&& ((this.subDivName == null && (lineItem.getSubDivision() == null || lineItem.getSubDivision().trim().isEmpty())) || (this.subDivName != null && lineItem.getSubDivision() != null && this.subDivName.trim().equalsIgnoreCase(lineItem.getSubDivision().trim())))
					&& ((this.profitCenterName == null && (lineItem.getProfitCentre1() == null || lineItem.getProfitCentre1().trim().isEmpty())) || (this.profitCenterName != null && lineItem.getProfitCentre1() != null && this.profitCenterName.trim().equalsIgnoreCase(lineItem.getProfitCentre1().trim())))
					&& ((this.businessUnitName == null && (lineItem.getProfitCentre2() == null ||lineItem.getProfitCentre2().trim().isEmpty())) || (this.businessUnitName != null && lineItem.getProfitCentre2() != null && this.businessUnitName.trim().equalsIgnoreCase(lineItem.getProfitCentre2().trim())))
					&& ((this.plantCode == null && (lineItem.getPlantCode() == null || lineItem.getPlantCode().trim().isEmpty())) || (this.plantCode != null && lineItem.getPlantCode() != null && this.plantCode.trim().equalsIgnoreCase(lineItem.getPlantCode().trim())))){
				return true;
			}
		}catch(Exception e){
			log.error("Error checking entity hierarchy equality for transaction" + lineItem.getId(), e);
		}
		return false;
}*/

	public boolean isEqualHierarchy(int id, String division, String subDivision, String profitCentre1, String profitCentre2, String plantCode){
		try{
			if(((this.circleName == null && (division == null || division.trim().isEmpty())) || (this.circleName != null && division != null && this.circleName.trim().equalsIgnoreCase(division.trim())))
					&& ((this.subDivName == null && (subDivision == null || subDivision.trim().isEmpty())) || (this.subDivName != null && subDivision != null && this.subDivName.trim().equalsIgnoreCase(subDivision.trim())))
					&& ((this.profitCenterName == null && (profitCentre1 == null || profitCentre1.trim().isEmpty())) || (this.profitCenterName != null && profitCentre1 != null && this.profitCenterName.trim().equalsIgnoreCase(profitCentre1.trim())))
					&& ((this.businessUnitName == null && (profitCentre2 == null || profitCentre2.trim().isEmpty())) || (this.businessUnitName != null && profitCentre2 != null && this.businessUnitName.trim().equalsIgnoreCase(profitCentre2.trim())))
					&& ((this.plantCode == null && (plantCode == null || plantCode.trim().isEmpty())) || (this.plantCode != null && plantCode != null && this.plantCode.trim().equalsIgnoreCase(plantCode.trim())))){
				return Boolean.TRUE;
	}
		}catch(Exception e){
			log.error("Error checking entity hierarchy equality for transaction:" + id, e);
		}
		return Boolean.FALSE;
	}
	public void validateEntityHierarchyData(int id, String division, String subDivision, String profitCentre1, String profitCentre2, String plantCode, Set<String> columnSet) {
		try{
		if(columnSet == null){
			columnSet = new HashSet<>();
		}
		if(division != null && this.circleName != null && !this.circleName.trim().equalsIgnoreCase(division.trim())){
			columnSet.add(Constant.DIVISION);
		}
		if(subDivision != null && this.subDivName != null && !this.subDivName.trim().equalsIgnoreCase(subDivision.trim())){
			columnSet.add(Constant.SUB_DIVISION);
		}
		if(profitCentre1 != null && this.profitCenterName != null && !this.profitCenterName.trim().equalsIgnoreCase(profitCentre1.trim())){
			columnSet.add(Constant.PROFIT_CENTER_1);
		}
		if(profitCentre2 != null && this.businessUnitName != null && !this.businessUnitName.trim().equalsIgnoreCase(profitCentre2.trim())){
			columnSet.add(Constant.PROFIT_CENTER_2);
		}
		if(plantCode != null && this.plantCode != null && !this.plantCode.trim().equalsIgnoreCase(plantCode.trim())){
			columnSet.add(Constant.PLANT_CODE);
		}
		}catch(Exception e){
			log.error("Error validating entity hierarchy data for transaction:" + id, e);
		}
	}
}
