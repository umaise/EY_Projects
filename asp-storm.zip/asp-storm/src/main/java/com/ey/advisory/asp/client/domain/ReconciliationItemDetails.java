package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class ReconciliationItemDetails implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@SerializedName("InvoiceDetailsId")
	private Long invoiceDetailsId;
	
	@SerializedName("LineNo")
	private Long lineNo;
	
	@SerializedName("ItemType")
	private String itemType;
    
	@SerializedName("CGSTAmt")
    private Double cgstAmt;

	@SerializedName("CGSTRt")
    private Double cgstRt;

	@SerializedName("HSNSC")
    private String hsnsc;

	@SerializedName("GSTR2A")
    private Double igstAmt;

	@SerializedName("GSTR2A")
    private Double igstRate;

	@SerializedName("SGSTAmt")
    private Double sgstAmt;

	@SerializedName("SGSTRt")
    private Double sgstRate;
    
	@SerializedName("CessAmt")
    private Double cessAmt;
    
	@SerializedName("CessRt")
    private Double cessRate;
	
	@SerializedName("ItemTxval")
	private Double itemTaxVal;

	public Long getInvoiceDetailsId() {
		return invoiceDetailsId;
	}

	public void setInvoiceDetailsId(Long invoiceDetailsId) {
		this.invoiceDetailsId = invoiceDetailsId;
	}

	public Long getLineNo() {
		return lineNo;
	}

	public void setLineNo(Long lineNo) {
		this.lineNo = lineNo;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public Double getCgstAmt() {
		return cgstAmt;
	}

	public void setCgstAmt(Double cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	public Double getCgstRt() {
		return cgstRt;
	}

	public void setCgstRt(Double cgstRt) {
		this.cgstRt = cgstRt;
	}

	public String getHsnsc() {
		return hsnsc;
	}

	public void setHsnsc(String hsnsc) {
		this.hsnsc = hsnsc;
	}

	public Double getIgstAmt() {
		return igstAmt;
	}

	public void setIgstAmt(Double igstAmt) {
		this.igstAmt = igstAmt;
	}

	public Double getIgstRate() {
		return igstRate;
	}

	public void setIgstRate(Double igstRate) {
		this.igstRate = igstRate;
	}

	public Double getSgstAmt() {
		return sgstAmt;
	}

	public void setSgstAmt(Double sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	public Double getSgstRate() {
		return sgstRate;
	}

	public void setSgstRate(Double sgstRate) {
		this.sgstRate = sgstRate;
	}

	public Double getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}

	public Double getCessRate() {
		return cessRate;
	}

	public void setCessRate(Double cessRate) {
		this.cessRate = cessRate;
	}

	public Double getItemTaxVal() {
		return itemTaxVal;
	}

	public void setItemTaxVal(Double itemTaxVal) {
		this.itemTaxVal = itemTaxVal;
	}

    
}
