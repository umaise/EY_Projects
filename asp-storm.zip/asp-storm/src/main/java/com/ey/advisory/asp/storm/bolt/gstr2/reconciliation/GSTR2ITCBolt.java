package com.ey.advisory.asp.storm.bolt.gstr2.reconciliation;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.client.domain.ReconciliationDetailsDTO;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.common.RedisTemplateUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.dto.LineItemDTO;
import com.ey.advisory.asp.service.gstr2.Gstr2ValidationRuleService;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;


public class GSTR2ITCBolt extends CustomBaseRichBolt {

	private static final long serialVersionUID = 1L;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;
	
	private Map<String, ItemMaster> itemHsnSacMap = new HashMap<>();
	private Gstr2ValidationRuleService validationRuleService;
	
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		
	}

	@Override
	public void execute(Tuple input) {
		log.info("In GSTR2ITCBolt.execute() start");
		ReconciliationDTO reconDTO = null;
		try {
			reconDTO = (ReconciliationDTO) input.getValues().get(0);
			/*Set<LineItemDTO> lineItemSet = null;
			Set<LineItemDTO> redisLineItemSet = null;*/
			List<ReconciliationDetailsDTO> gstr2FRecords = null;

			RedisTemplateUtil<String, Object> redisTemplateUtil = new RedisTemplateUtil<String, Object>();
			RedisTemplate<String, Object> redisTemplate = redisTemplateUtil
					.getRedisTemplate();
			
			if (reconDTO.getFilingRecordType() != null && reconDTO.getFilingRecordType().equalsIgnoreCase(Constant.FILING_RECORD_TYPE_PURCHASE_REGISTER)) {
				gstr2FRecords = reconDTO.getPurchaseRegister();
			} else if (reconDTO.getFilingRecordType() != null && reconDTO.getFilingRecordType().equalsIgnoreCase(Constant.FILING_RECORD_TYPE_GSTR2A)) {
				gstr2FRecords = reconDTO.getGstr2A();
				
				/*
				 * Comparing on line No as HSN not present
				 */
				if(Constant.Y.equalsIgnoreCase(gstr2FRecords.get(0).getRevChrg())){
					if(reconDTO.getPurchaseRegister() != null && !reconDTO.getPurchaseRegister().isEmpty()){
						reconDTO.setUpdateTaxLiability(Boolean.TRUE);
						
						for(ReconciliationDetailsDTO reconDetails : gstr2FRecords){
							for(ReconciliationDetailsDTO purchaseRegister : reconDTO.getPurchaseRegister()){
								if(reconDetails.getCustGSTIN().equals(purchaseRegister.getCustGSTIN()) && reconDetails.getGstin().equals(purchaseRegister.getGstin()) 
										&& reconDetails.getInvNum().equals(purchaseRegister.getInvNum()) && reconDetails.getInvDate().equals(purchaseRegister.getInvDate()) 
										&& reconDetails.getLineNo() == purchaseRegister.getLineNo()){
									reconDetails.setSgstAmt(purchaseRegister.getSgstAmt());
									reconDetails.setIgstAmt(purchaseRegister.getIgstAmt());
									reconDetails.setCgstAmt(purchaseRegister.getCgstAmt());
									reconDetails.setCessAmt(purchaseRegister.getCessAmt());
									reconDetails.setItemTxVal(purchaseRegister.getItemTxVal());
								}
							}
						}
					}
				}
				
				
				
				/*if(reconDTO.getTableKey().substring(0, reconDTO.getTableKey().indexOf("_")).equalsIgnoreCase(Constant.B2B)){
				getMasterDetailsfromRedis(redisTemplate,reconDTO.getGroupCode());
				
				if (itemHsnSacMap == null || itemHsnSacMap.isEmpty() ){
	            	if( validationRuleService.validateHsnSacAgainstNonGST(reconDTO.getGroupCode()).equalsIgnoreCase("Success")){
	                    getMasterDetailsfromRedis(redisTemplate,reconDTO.getGroupCode()); 
	                }
	            }
				
				for (ReconciliationDetailsDTO reconDetails : gstr2FRecords){
					if(reconDetails.getRevChrg().equalsIgnoreCase(Constant.Y)){
						ItemMaster master = null;
						if(!itemHsnSacMap.isEmpty() && itemHsnSacMap.containsKey(reconDetails.getHsnsac())){
							master = itemHsnSacMap.get(reconDetails.getHsnsac());
							}else{
								ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.FETCH_ITEM_BY_HSNSAC, reconDTO.getGroupCode(),reconDetails.getHsnsac(), Constant.VERB_TYPE_POST);
								if(response != null && response.getStatusInfo().getStatusCode() == 200 && response.getEntity(String.class).equalsIgnoreCase(Constant.SUCCESS)){
									getMasterDetailsfromRedis(redisTemplate, reconDTO.getGroupCode());
									if(!itemHsnSacMap.isEmpty() && itemHsnSacMap.containsKey(reconDetails.getHsnsac())){
										master = itemHsnSacMap.get(reconDetails.getHsnsac());
									}
								}
							}
						if(master != null && master.getReverseCharge().equals(Constant.Y)){
							if(reconDTO.getPurchaseRegister() != null){
								for(ReconciliationDetailsDTO purchaseRegister : reconDTO.getPurchaseRegister()){
									if(reconDetails.getCustGSTIN().equals(purchaseRegister.getCustGSTIN()) && reconDetails.getGstin().equals(purchaseRegister.getGstin()) 
											&& reconDetails.getInvNum().equals(purchaseRegister.getInvNum()) && reconDetails.getInvDate().equals(purchaseRegister.getInvDate()) 
											&& reconDetails.getHsnsac().equals(purchaseRegister.getHsnsac())){
										reconDetails.setSgstAmt(purchaseRegister.getSgstAmt());
										reconDetails.setIgstAmt(purchaseRegister.getIgstAmt());
										reconDetails.setCgstAmt(purchaseRegister.getCgstAmt());
										
										String columnNames= Constant.REVERSE_CHARGE;
										TblPurchaseErrorInfo errorInfo = ErrorActionUtility.getPurchaseTblErrorInfo(reconDetails, "IN008", columnNames, 
												Constant.PROCESS_STATUS_RECONCILIATION, Boolean.TRUE, Constant.INCIDENCE_LEVEL_LINE_ITEM);
										errorInfo.getErrorDesc().replace("<>", "<"+reconDetails.getInvNum()+">");
										reconDetails.setItemStatus(Constant.INFORMATION);
									}
								}
							}
						}
					}
				}
			}*/
		}

			/*String tblKey = reconDTO.getTableKey();
			if (gstr2FRecords != null && gstr2FRecords.size() > 0) {
				for (ReconciliationDetailsDTO reconDetDTO : gstr2FRecords) {
					LineItemDTO lineItemDTO = new LineItemDTO();
					lineItemDTO.setId(reconDetDTO.getId());
					lineItemDTO.setLineNo(reconDetDTO.getLineNo());
					if (reconDetDTO.getItcCessAmt() == null)// or 0 condition
						lineItemDTO.setItcCessAmt(reconDetDTO.getCessAmt());
					if (reconDetDTO.getItcCgstAmt() == null)
						lineItemDTO.setItcCgstAmt(reconDetDTO.getCgstAmt());
					if (reconDetDTO.getItcSgstAmt() == null)
						lineItemDTO.setItcSgstAmt(reconDetDTO.getSgstAmt());
					if (reconDetDTO.getItcIgstAmt() == null)
						lineItemDTO.setItcIgstAmt(reconDetDTO.getIgstAmt());
					if(reconDTO.getFilingRecordType() != null && reconDTO.getFilingRecordType().equalsIgnoreCase(Constant.FILING_RECORD_TYPE_GSTR2A) && 
							reconDetDTO.getRevChrg().equals(Constant.Y) && reconDTO.getTableKey().substring(0, reconDTO.getTableKey().indexOf("_")).equalsIgnoreCase(Constant.B2B)){
						
					if(reconDetDTO.getSgstAmt() != null)
						lineItemDTO.setCgstAmount(reconDetDTO.getSgstAmt());
					if(reconDetDTO.getIgstAmt() != null)
						lineItemDTO.setIgstAmount(reconDetDTO.getIgstAmt());
					if(reconDetDTO.getCgstAmt() != null)
						lineItemDTO.setCgstAmount(reconDetDTO.getCgstAmt());
					}
					lineItemDTO.setTableType(tblKey.substring(0,
							tblKey.indexOf("_")));
					if (lineItemSet == null) {
						lineItemSet = new HashSet<LineItemDTO>();
					}
					lineItemSet.add(lineItemDTO);
				}
			}
			
			if(!reconDTO.getTableKey().substring(reconDTO.getTableKey().indexOf("_")+1).equalsIgnoreCase(Constant.RECON_TYPE_MATCHED)){
				
			}

			String redisKey = reconDTO.getRedisKey();
			String itcKey = redisKey + "_" + "itcvalues";
			if (redisTemplate.opsForHash().get(redisKey, itcKey) == null) {
				redisLineItemSet = new HashSet<LineItemDTO>();
			} else {
				redisLineItemSet = (Set<LineItemDTO>) redisTemplate
						.opsForHash().get(redisKey, itcKey);
			}
			redisLineItemSet.addAll(lineItemSet);
			redisTemplate.opsForHash().put(redisKey, itcKey, redisLineItemSet);*/
			log.info("In GSTR2ITCBolt.execute() complete");
		} catch (Exception ex) {
			log.error("Error Vin GSTR2ITCBoltt", ex);
			collector.customReportError(input, ex, "Exception in Bolt GSTR2ITCBolt");
			
		} finally {
			collector.ack(input);
			if (reconDTO != null) {
				collector.emit(new Values(reconDTO));
				//collector.emit(Constant.GSTR2_Stream3,new Values(reconDTO));
			} else {
				collector.emit(new Values(input));
				//collector.emit(Constant.GSTR2_Stream3,new Values(input));
			}
			log.info("In GSTR2ITCBolt.execute() end");
		}

	}
	
	private void getMasterDetailsfromRedis(RedisTemplate<String, Object> redisTemplate, String groupCode) {

        itemHsnSacMap = (Map<String, ItemMaster>)redisTemplate.opsForHash().get(groupCode+"_"+Constant.REDIS_CACHE, Constant.ITEM_MASTER_DETAILS);

        if(itemHsnSacMap==null){

            itemHsnSacMap= new HashMap<String, ItemMaster>();
        }

    }

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR2_Stream3,new Fields("inv"));
	}

}
