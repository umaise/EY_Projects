package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ProductMaster implements Serializable {
	
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    private Long productId;
    private String sgstin;
    private String itemCode;
    private String description;
    private String hsnsac;
    private String unitOfMeasurement;
    private Character reverseCharge;
    private Character isTDS;
    private Character isExempt;
    private Date dateOfCircular;
    private String notificationNum;
    private java.util.Date notificationDate;
    private String serialNumber;
    private BigDecimal igstrt;
    private BigDecimal cgstrt;
    private BigDecimal sgstrt;
    private BigDecimal utgst;
    private BigDecimal cessrt;
    private BigDecimal cessrtvalerom;
	private String add1;
	private String add2;
	private String add3;
	private BigDecimal add4;
	private BigDecimal add5;

	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getSgstin() {
		return sgstin;
	}
	public void setSgstin(String sgstin) {
		this.sgstin = sgstin;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHsnsac() {
		return hsnsac;
	}
	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}
	public String getUnitOfMeasurement() {
		return unitOfMeasurement;
	}
	public void setUnitOfMeasurement(String unitOfMeasurement) {
		this.unitOfMeasurement = unitOfMeasurement;
	}
	public Character getReverseCharge() {
		return reverseCharge;
	}
	public void setReverseCharge(Character reverseCharge) {
		this.reverseCharge = reverseCharge;
	}
	public Character getIsTDS() {
		return isTDS;
	}
	public void setIsTDS(Character isTDS) {
		this.isTDS = isTDS;
	}
	public Character getIsExempt() {
		return isExempt;
	}
	public void setIsExempt(Character isExempt) {
		this.isExempt = isExempt;
	}
	public String getNotificationNum() {
		return notificationNum;
	}
	public void setNotificationNum(String notificationNum) {
		this.notificationNum = notificationNum;
	}
	public java.util.Date getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(java.util.Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public BigDecimal getIgstrt() {
		return igstrt;
	}
	public void setIgstrt(BigDecimal igstrt) {
		this.igstrt = igstrt;
	}
	public BigDecimal getCgstrt() {
		return cgstrt;
	}
	public void setCgstrt(BigDecimal cgstrt) {
		this.cgstrt = cgstrt;
	}
	public BigDecimal getSgstrt() {
		return sgstrt;
	}
	public void setSgstrt(BigDecimal sgstrt) {
		this.sgstrt = sgstrt;
	}
	public BigDecimal getUtgst() {
		return utgst;
	}
	public void setUtgst(BigDecimal utgst) {
		this.utgst = utgst;
	}
	public BigDecimal getCessrt() {
		return cessrt;
	}
	public void setCessrt(BigDecimal cessrt) {
		this.cessrt = cessrt;
	}
	public BigDecimal getCessrtvalerom() {
		return cessrtvalerom;
	}
	public void setCessrtvalerom(BigDecimal cessrtvalerom) {
		this.cessrtvalerom = cessrtvalerom;
	}
	public String getAdd1() {
		return add1;
	}
	public void setAdd1(String add1) {
		this.add1 = add1;
	}
	public String getAdd2() {
		return add2;
	}
	public void setAdd2(String add2) {
		this.add2 = add2;
	}
	public String getAdd3() {
		return add3;
	}
	public void setAdd3(String add3) {
		this.add3 = add3;
	}
	public BigDecimal getAdd4() {
		return add4;
	}
	public void setAdd4(BigDecimal add4) {
		this.add4 = add4;
	}
	public BigDecimal getAdd5() {
		return add5;
	}
	public void setAdd5(BigDecimal add5) {
		this.add5 = add5;
	}
    public Date getDateOfCircular() {
        return dateOfCircular;
    }
    public void setDateOfCircular(Date dateOfCircular) {
        this.dateOfCircular = dateOfCircular;
    }
    
}
