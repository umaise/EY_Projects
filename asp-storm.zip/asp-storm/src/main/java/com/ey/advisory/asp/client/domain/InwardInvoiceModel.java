package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import com.google.gson.annotations.SerializedName;

public class InwardInvoiceModel implements Serializable{

	private static final long serialVersionUID = 1L;
	    @SerializedName("ID")
	    private int id;

	    @SerializedName("FileID")
	    private int fileID;

		@SerializedName("SourceIdentifier")
	    private String sourceIdentifier;
	    
	    @SerializedName("SourceFileName")
	    private String sourceFileName;
	    
	    @SerializedName("GLAccountCode")
	    private String gLAccountCode;
	    
	    @SerializedName("Division")
	    private String division;

	    @SerializedName("SubDivision")
	    private String subDivision;

	    @SerializedName("ProfitCentre1")
	    private String profitCentre1;

	    @SerializedName("ProfitCentre2")
	    private String profitCentre2;

	    @SerializedName("PlantCode")
	    private String plantCode;

	    @SerializedName("TaxPeriod")
	    private String taxPeriod;

	    @SerializedName("CGSTIN")
	    private String CGSTIN;

	    @SerializedName("DocumentType")
	    private String documentType;

	    @SerializedName("SupplyType")
	    private String supplyType;

	    @SerializedName("DocumentNo")
	    private String documentNo;

	    @SerializedName("DocumentDate")
	    private Object documentDate;

	    @SerializedName("OriginalDocumentNo")
	    private String originalDocumentNo;

	    @SerializedName("OriginalDocumentDate")
	    private Object originalDocumentDate;

	    @SerializedName("CRDRPreGST")
	    private String CRDRPreGST;
	    
	    @SerializedName("LineNumber")
	    private int lineNumber;

	    @SerializedName("SGSTIN")
	    private String SGSTIN;

	    @SerializedName("OriginalSGSTIN")
	    private String originalSGSTIN;

	    @SerializedName("SupplierName")
	    private String supplierName;

	    @SerializedName("SupplierCode")
	    private String supplierCode;

	    @SerializedName("POS")
	    private String pos;

	    @SerializedName("BillOfEntry")
	    private String billOfEntry;

	    @SerializedName("BillOfEntryDate")
	    private Object billOfEntryDate;

	    @SerializedName("CIFValue")
	    private BigDecimal CIFValue;

	    @SerializedName("CustomDuty")
	    private BigDecimal customDuty;

	    @SerializedName("HSNorSAC")
	    private String HSNorSAC;

	    @SerializedName("ItemCode")
	    private String itemCode;

	    @SerializedName("ItemDescription")
	    private String itemDescription;

	    @SerializedName("ItemCategory")
	    private String itemCategory;

	    @SerializedName("UnitofMeasurement")
	    private String unitofMeasurement;

	    @SerializedName("Quantity")
	    private BigDecimal quantity;

	    @SerializedName("TaxableValue")
	    private BigDecimal taxableValue;
	    
	    @SerializedName("IGSTAmount")
	    private BigDecimal IGSTAmount;

	    @SerializedName("IGSTRate")
	    private BigDecimal IGSTRate;

	    @SerializedName("CGSTAmount")
	    private BigDecimal CGSTAmount;

	    @SerializedName("CGSTRate")
	    private BigDecimal CGSTRate;

	    @SerializedName("SGSTAmount")
	    private BigDecimal SGSTAmount;

	    @SerializedName("SGSTRate")
	    private BigDecimal SGSTRate;

	    @SerializedName("CessAmountAdvalorem")
	    private BigDecimal cessAmountAdvalorem;

	    @SerializedName("CessRateAdvalorem")
	    private BigDecimal cessRateAdvalorem;
	    
	    @SerializedName("CessAmountSpecific")
	    private BigDecimal cessAmountSpecific;

	    @SerializedName("CessRateSpecific")
	    private BigDecimal cessRateSpecific;

	    @SerializedName("InvoiceValue")
	    private BigDecimal invoiceValue;

	    @SerializedName("ReverseCharge")
	    private String reverseCharge;
	    
	    @SerializedName("EligibilityIndicator")
	    private String eligibilityIndicator;

	    @SerializedName("CommonSupplyIndicator")
	    private String commonSupplyIndicator;

	    @SerializedName("AvailableCESS")
	    private BigDecimal availableCESS;

	    @SerializedName("AvailableCGST")
	    private BigDecimal availableCGST;

	    @SerializedName("AvailableIGST")
	    private BigDecimal availableIGST;

	    @SerializedName("AvailableSGST")
	    private BigDecimal availableSGST;

	    @SerializedName("ITCReversalIdentifier")
	    private String ITCReversalIdentifier;

	    @SerializedName("ReasonForCreditDebitNote")
	    private String reasonForCreditDebitNote;

	    @SerializedName("PurchaseVoucherNumber")
	    private String purchaseVoucherNumber;
	    
	    @SerializedName("PurchaseVoucherDate")
	    private Object purchaseVoucherDate;

	    @SerializedName("PaymentVoucherNumber")
	    private String paymentVoucherNumber;

	    @SerializedName("DateofPayment")
	    private Object dateofPayment;

	    @SerializedName("ContractNumber")
	    private String contractNumber;
	    
	    @SerializedName("Contractdate")
	    private Object contractdate;

	    @SerializedName("ContractValue")
	    private BigDecimal contractValue;

	    @SerializedName("Userdefinedfield1")
	    private String userdefinedfield1;

	    @SerializedName("Userdefinedfield2")
	    private String userdefinedfield2;
	    
	    @SerializedName("Userdefinedfield3")
	    private String userdefinedfield3;
	    
	    @SerializedName("AggInvoice")
	    private BigDecimal aggInvoice;

	    @SerializedName("AggTaxableValue")
	    private BigDecimal aggTaxableValue;

	    @SerializedName("InvOrder")
	    private Integer invOrder;

	    @SerializedName("Status")
	    private String itemStatus;
	    
	    @SerializedName("RecordType")
	    private String tableType;

	    @SerializedName("SupplyCategory")
	    private String supplyCategory;
	    
	    @SerializedName("IsProcessed")
	    private boolean isProcessed;

	    @SerializedName("IsError")
	    private boolean isError;

	    @SerializedName("NewInvOrder")
	    private long newInvOrder;

	    @SerializedName("IsDuplicate")
	    private boolean isDuplicate;

	    @SerializedName("IsPreStageError")
	    private boolean isPreStageError;

	    @SerializedName("Chksum")
	    private String chksum;

	    @SerializedName("InvoiceKey")
	    private String invoiceKey;

	    @SerializedName("SubCategory")
	    private String subCategory;
	    
	    @SerializedName("PortCode")
	    private String portCode;

	    @SerializedName("IsISD")
	    private boolean isISD;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

       

        public String getDivision() {
            return division;
        }

        public void setDivision(String division) {
            this.division = division;
        }

        public String getSubDivision() {
            return subDivision;
        }

        public void setSubDivision(String subDivision) {
            this.subDivision = subDivision;
        }

        public String getProfitCentre1() {
            return profitCentre1;
        }

        public void setProfitCentre1(String profitCentre1) {
            this.profitCentre1 = profitCentre1;
        }

        public String getProfitCentre2() {
            return profitCentre2;
        }

        public void setProfitCentre2(String profitCentre2) {
            this.profitCentre2 = profitCentre2;
        }

        public String getPlantCode() {
            return plantCode;
        }

        public void setPlantCode(String plantCode) {
            this.plantCode = plantCode;
        }

        public String getTaxPeriod() {
            return taxPeriod;
        }

        public void setTaxPeriod(String taxPeriod) {
            this.taxPeriod = taxPeriod;
        }

        public String getCGSTIN() {
            return CGSTIN;
        }

        public void setCGSTIN(String cGSTIN) {
            CGSTIN = cGSTIN;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }

        public String getSupplyType() {
            return supplyType;
        }

        public void setSupplyType(String supplyType) {
            this.supplyType = supplyType;
        }

        public String getDocumentNo() {
            return documentNo;
        }

        public void setDocumentNo(String documentNo) {
            this.documentNo = documentNo;
        }

        public Object getDocumentDate() {
            return documentDate;
        }

        public void setDocumentDate(Object documentDate) {
            this.documentDate = documentDate;
        }

        public String getOriginalDocumentNo() {
            return originalDocumentNo;
        }

        public void setOriginalDocumentNo(String originalDocumentNo) {
            this.originalDocumentNo = originalDocumentNo;
        }

        public Object getOriginalDocumentDate() {
            return originalDocumentDate;
        }

        public void setOriginalDocumentDate(Object originalDocumentDate) {
            this.originalDocumentDate = originalDocumentDate;
        }

        public int getLineNumber() {
            return lineNumber;
        }

        public void setLineNumber(int lineNumber) {
            this.lineNumber = lineNumber;
        }

        public String getSGSTIN() {
            return SGSTIN;
        }

        public void setSGSTIN(String sGSTIN) {
            SGSTIN = sGSTIN;
        }

        public String getOriginalSGSTIN() {
            return originalSGSTIN;
        }

        public void setOriginalSGSTIN(String originalSGSTIN) {
            this.originalSGSTIN = originalSGSTIN;
        }

        public String getSupplierName() {
            return supplierName;
        }

        public void setSupplierName(String supplierName) {
            this.supplierName = supplierName;
        }

        public String getSupplierCode() {
            return supplierCode;
        }

        public void setSupplierCode(String supplierCode) {
            this.supplierCode = supplierCode;
        }

        public String getPos() {
            return pos;
        }

        public void setPos(String pos) {
            this.pos = pos;
        }

        public String getBillOfEntry() {
            return billOfEntry;
        }

        public void setBillOfEntry(String billOfEntry) {
            this.billOfEntry = billOfEntry;
        }

        public Object getBillOfEntryDate() {
            return billOfEntryDate;
        }

        public void setBillOfEntryDate(Object billOfEntryDate) {
            this.billOfEntryDate = billOfEntryDate;
        }

        public BigDecimal getCIFValue() {
            return CIFValue;
        }

        public void setCIFValue(BigDecimal cIFValue) {
            CIFValue = cIFValue;
        }

        public BigDecimal getCustomDuty() {
            return customDuty;
        }

        public void setCustomDuty(BigDecimal customDuty) {
            this.customDuty = customDuty;
        }

        public String getHSNorSAC() {
            return HSNorSAC;
        }

        public void setHSNorSAC(String hSNorSAC) {
            HSNorSAC = hSNorSAC;
        }

        public String getItemCode() {
            return itemCode;
        }

        public void setItemCode(String itemCode) {
            this.itemCode = itemCode;
        }

        public String getItemDescription() {
            return itemDescription;
        }

        public void setItemDescription(String itemDescription) {
            this.itemDescription = itemDescription;
        }

        public String getItemCategory() {
            return itemCategory;
        }

        public void setItemCategory(String itemCategory) {
            this.itemCategory = itemCategory;
        }

        public String getUnitofMeasurement() {
            return unitofMeasurement;
        }

        public void setUnitofMeasurement(String unitofMeasurement) {
            this.unitofMeasurement = unitofMeasurement;
        }

        public BigDecimal getQuantity() {
            return quantity;
        }

        public void setQuantity(BigDecimal quantity) {
            this.quantity = quantity;
        }

        public BigDecimal getTaxableValue() {
            return taxableValue;
        }

        public void setTaxableValue(BigDecimal taxableValue) {
            this.taxableValue = taxableValue;
        }

        public BigDecimal getIGSTAmount() {
            return IGSTAmount;
        }

        public void setIGSTAmount(BigDecimal iGSTAmount) {
            IGSTAmount = iGSTAmount;
        }

        public BigDecimal getIGSTRate() {
            return IGSTRate;
        }

        public void setIGSTRate(BigDecimal iGSTRate) {
            IGSTRate = iGSTRate;
        }

        public BigDecimal getCGSTAmount() {
            return CGSTAmount;
        }

        public void setCGSTAmount(BigDecimal cGSTAmount) {
            CGSTAmount = cGSTAmount;
        }

        public BigDecimal getCGSTRate() {
           
        	return CGSTRate;
        }

        public void setCGSTRate(BigDecimal cGSTRate) {
            CGSTRate = cGSTRate;
        }

        public BigDecimal getSGSTAmount() {
            return SGSTAmount;
        }

        public void setSGSTAmount(BigDecimal sGSTAmount) {
            SGSTAmount = sGSTAmount;
        }

        public BigDecimal getSGSTRate() {
            return SGSTRate;
        }

        public void setSGSTRate(BigDecimal sGSTRate) {
            SGSTRate = sGSTRate;
        }

        public BigDecimal getCessAmountAdvalorem() {
            return cessAmountAdvalorem;
        }

        public void setCessAmountAdvalorem(BigDecimal cessAmountAdvalorem) {
            this.cessAmountAdvalorem = cessAmountAdvalorem;
        }

        public BigDecimal getCessRateAdvalorem() {
            return cessRateAdvalorem;
        }

        public void setCessRateAdvalorem(BigDecimal cessRateAdvalorem) {
            this.cessRateAdvalorem = cessRateAdvalorem;
        }

        public BigDecimal getCessAmountSpecific() {
            return cessAmountSpecific;
        }

        public void setCessAmountSpecific(BigDecimal cessAmountSpecific) {
            this.cessAmountSpecific = cessAmountSpecific;
        }

        public BigDecimal getCessRateSpecific() {
            return cessRateSpecific;
        }

        public void setCessRateSpecific(BigDecimal cessRateSpecific) {
            this.cessRateSpecific = cessRateSpecific;
        }

        public BigDecimal getInvoiceValue() {
            return invoiceValue;
        }

        public void setInvoiceValue(BigDecimal invoiceValue) {
            this.invoiceValue = invoiceValue;
        }

        public String getReverseCharge() {
            return reverseCharge;
        }

        public void setReverseCharge(String reverseCharge) {
            this.reverseCharge = reverseCharge;
        }

        public String getEligibilityIndicator() {
            return eligibilityIndicator;
        }

        public void setEligibilityIndicator(String eligibilityIndicator) {
            this.eligibilityIndicator = eligibilityIndicator;
        }

        public String getCommonSupplyIndicator() {
            return commonSupplyIndicator;
        }

        public void setCommonSupplyIndicator(String commonSupplyIndicator) {
            this.commonSupplyIndicator = commonSupplyIndicator;
        }

        public BigDecimal getAvailableCESS() {
            return availableCESS;
        }

        public void setAvailableCESS(BigDecimal availableCESS) {
            this.availableCESS = availableCESS;
        }

        public BigDecimal getAvailableCGST() {
            return availableCGST;
        }

        public void setAvailableCGST(BigDecimal availableCGST) {
            this.availableCGST = availableCGST;
        }

        public BigDecimal getAvailableIGST() {
            return availableIGST;
        }

        public void setAvailableIGST(BigDecimal availableIGST) {
            this.availableIGST = availableIGST;
        }

        public BigDecimal getAvailableSGST() {
            return availableSGST;
        }

        public void setAvailableSGST(BigDecimal availableSGST) {
            this.availableSGST = availableSGST;
        }

        public String getITCReversalIdentifier() {
            return ITCReversalIdentifier;
        }

        public void setITCReversalIdentifier(String iTCReversalIdentifier) {
            ITCReversalIdentifier = iTCReversalIdentifier;
        }

        public String getReasonForCreditDebitNote() {
            return reasonForCreditDebitNote;
        }

        public void setReasonForCreditDebitNote(String reasonForCreditDebitNote) {
            this.reasonForCreditDebitNote = reasonForCreditDebitNote;
        }

        public String getPurchaseVoucherNumber() {
            return purchaseVoucherNumber;
        }

        public void setPurchaseVoucherNumber(String purchaseVoucherNumber) {
            this.purchaseVoucherNumber = purchaseVoucherNumber;
        }

        public Object getPurchaseVoucherDate() {
            return purchaseVoucherDate;
        }

        public void setPurchaseVoucherDate(Object purchaseVoucherDate) {
            this.purchaseVoucherDate = purchaseVoucherDate;
        }

        public String getPaymentVoucherNumber() {
            return paymentVoucherNumber;
        }

        public void setPaymentVoucherNumber(String paymentVoucherNumber) {
            this.paymentVoucherNumber = paymentVoucherNumber;
        }

        public Object getDateofPayment() {
            return dateofPayment;
        }

        public void setDateofPayment(Object dateofPayment) {
            this.dateofPayment = dateofPayment;
        }

        public String getContractNumber() {
            return contractNumber;
        }

        public void setContractNumber(String contractNumber) {
            this.contractNumber = contractNumber;
        }

        public Object getContractdate() {
            return contractdate;
        }

        public void setContractdate(Object contractdate) {
            this.contractdate = contractdate;
        }

        public BigDecimal getContractValue() {
            return contractValue;
        }

        public void setContractValue(BigDecimal contractValue) {
            this.contractValue = contractValue;
        }

        public BigDecimal getAggInvoice() {
            return aggInvoice;
        }

        public void setAggInvoice(BigDecimal aggInvoice) {
            this.aggInvoice = aggInvoice;
        }

        public BigDecimal getAggTaxableValue() {
            return aggTaxableValue;
        }

        public void setAggTaxableValue(BigDecimal aggTaxableValue) {
            this.aggTaxableValue = aggTaxableValue;
        }

        public Integer getInvOrder() {
            return invOrder;
        }

        public void setInvOrder(Integer invOrder) {
            this.invOrder = invOrder;
        }

        public String getItemStatus() {
            return itemStatus;
        }

        public void setItemStatus(String itemStatus) {
            this.itemStatus = itemStatus;
        }

        public String getTableType() {
            return tableType;
        }

        public void setTableType(String tableType) {
            this.tableType = tableType;
        }

        public String getSupplyCategory() {
            return supplyCategory;
        }

        public void setSupplyCategory(String supplyCategory) {
            this.supplyCategory = supplyCategory;
        }

        public boolean isProcessed() {
            return isProcessed;
        }

        public void setProcessed(boolean isProcessed) {
            this.isProcessed = isProcessed;
        }

        public boolean isError() {
            return isError;
        }

        public void setError(boolean isError) {
            this.isError = isError;
        }

        public long getNewInvOrder() {
            return newInvOrder;
        }

        public void setNewInvOrder(long newInvOrder) {
            this.newInvOrder = newInvOrder;
        }

        public boolean isDuplicate() {
            return isDuplicate;
        }

        public void setDuplicate(boolean isDuplicate) {
            this.isDuplicate = isDuplicate;
        }

        public boolean isPreStageError() {
            return isPreStageError;
        }

        public void setPreStageError(boolean isPreStageError) {
            this.isPreStageError = isPreStageError;
        }

        public String getChksum() {
            return chksum;
        }

        public void setChksum(String chksum) {
            this.chksum = chksum;
        }

        public String getInvoiceKey() {
            return invoiceKey;
        }

        public void setInvoiceKey(String invoiceKey) {
            this.invoiceKey = invoiceKey;
        }

        public String getSubCategory() {
            return subCategory;
        }

        public void setSubCategory(String subCategory) {
            this.subCategory = subCategory;
        }

        public String getSourceIdentifier() {
            return sourceIdentifier;
        }

        public void setSourceIdentifier(String sourceIdentifier) {
            this.sourceIdentifier = sourceIdentifier;
        }

        public String getSourceFileName() {
            return sourceFileName;
        }
        
        public int getFileID() {
			return fileID;
		}

		public void setFileID(int fileID) {
			this.fileID = fileID;
		}

		public void setSourceFileName(String sourceFileName) {
            this.sourceFileName = sourceFileName;
        }

        public String getgLAccountCode() {
            return gLAccountCode;
        }

        public void setgLAccountCode(String gLAccountCode) {
            this.gLAccountCode = gLAccountCode;
        }

        public String getCRDRPreGST() {
            return CRDRPreGST;
        }

        public void setCRDRPreGST(String cRDRPreGST) {
            CRDRPreGST = cRDRPreGST;
        }

        public String getUserdefinedfield1() {
            return userdefinedfield1;
        }

        public void setUserdefinedfield1(String userdefinedfield1) {
            this.userdefinedfield1 = userdefinedfield1;
        }

        public String getUserdefinedfield2() {
            return userdefinedfield2;
        }

        public void setUserdefinedfield2(String userdefinedfield2) {
            this.userdefinedfield2 = userdefinedfield2;
        }

        public String getUserdefinedfield3() {
            return userdefinedfield3;
        }

        public void setUserdefinedfield3(String userdefinedfield3) {
            this.userdefinedfield3 = userdefinedfield3;
        }

		public String getPortCode() {
			return portCode;
		}

		public void setPortCode(String portCode) {
			this.portCode = portCode;
		}

		public boolean getIsISD() {
			return isISD;
		}

		public void setIsISD(boolean isISD) {
			this.isISD = isISD;
		}


	
}

