package com.ey.advisory.asp.storm.bolt.common;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.client.domain.ReconciliationStatusDTO;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.error.LogGSTR2RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.sun.jersey.api.client.ClientResponse;

public class GSTR2AReconRedisWSBolt extends CustomBaseRichBolt {

	private final Logger log = LoggerFactory.getLogger(getClass());
	
	private CustomOutputCollector collector;
	
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;	   		
	}

	@Override
	public void execute(Tuple input) {
		ReconciliationDTO reconciliationDTO = null;
		long startTime=System.currentTimeMillis();
        int invOrder=0;
		try{
			log.info("In GSTR1RedisWSBolt.execute() start");
			reconciliationDTO = (ReconciliationDTO) input.getValue(0);
			
			RedisTemplate<String,Object> redisTemplate= JedisConnectionUtil.getRedisTemplateKVStringObject();
        	

            String redisKey=reconciliationDTO.getRedisKey();
            String invStatusKey=redisKey+"_"+Constant.INVOICE_STATUS;
            String invErrKey=redisKey+"_"+Constant.INVOICE_ERROR_DETAILS;
			String invProcessedKey=redisKey+"_"+Constant.INVOICE_PSD_COUNT;
			
			ReconciliationStatusDTO reconStatusDTO = new ReconciliationStatusDTO(reconciliationDTO);
			
			log.info("In GSTR1RedisWSBolt  redis key : "+reconciliationDTO.getRedisKey() + " Recon Status Id : "+ reconciliationDTO.getReconStatusId());
            redisTemplate.opsForHash().put(invStatusKey,reconciliationDTO.getReconStatusId(),reconStatusDTO);
			redisTemplate.opsForHash().put(invProcessedKey,reconciliationDTO.getReconStatusId(),reconciliationDTO.getReconStatusId());
			
			/*Set<TblPurchaseErrorInfo> errorList = reconciliationDTO.getErrorList();
			if(errorList!=null && !errorList.isEmpty()){
            	redisTemplate.opsForHash().put(invErrKey,reconciliationDTO.getReconStatusId(),errorList);
            }*/
			
		}catch(Exception ex){
			log.error("Error GSTR1RedisWSBolt", ex);
            //logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}finally {
            collector.ack(input);
            if(log.isInfoEnabled())
            	log.info("In GSTR2AReconRedisWSBolt Time taken for file : "+reconciliationDTO.getRedisKey()+" Recon Status Id: "+ reconciliationDTO.getReconStatusId() +" is "+(System.currentTimeMillis()-startTime));
        }
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR2_Stream3,new Fields("inv"));
		
	}

	
}

