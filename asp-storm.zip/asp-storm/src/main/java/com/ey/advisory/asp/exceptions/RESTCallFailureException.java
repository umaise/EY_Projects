package com.ey.advisory.asp.exceptions;

public class RESTCallFailureException extends Exception{

	private static final long serialVersionUID = 1L;
	private String message = null;
	 
    public RESTCallFailureException() {
        super();
    }
 
    public RESTCallFailureException(String message) {
        super(message);
        this.message = message;    }
 
    public RESTCallFailureException(Throwable cause) {
        super(cause);
    }
 
    @Override
    public String toString() {
        return message;
    }
 
    @Override
    public String getMessage() {
        return message;
    }
}
