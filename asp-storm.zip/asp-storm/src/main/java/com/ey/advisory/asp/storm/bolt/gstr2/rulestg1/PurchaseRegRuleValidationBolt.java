package com.ey.advisory.asp.storm.bolt.gstr2.rulestg1;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.runtime.Globals;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.KnowledgeBaseFactory;
import org.kie.internal.definition.KnowledgePackage;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.error.LogGSTR2RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.service.gstr2.Gstr2ValidationRuleService;
import com.ey.advisory.asp.service.gstr2.Gstr2ValidationRuleServiceImpl;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;

/**
 * @author  Nisha Kumari
 * @version 1.0
 * @since   17-03-2017
 */

public class PurchaseRegRuleValidationBolt extends CustomBaseRichBolt{

	private static final long serialVersionUID = 1L;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;
	private Gstr2ValidationRuleService validationRuleService;

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		validationRuleService = new Gstr2ValidationRuleServiceImpl();
	}
	@Override
	public void execute(Tuple input) {
		InwardInvoiceDTO inwardInvoiceDTO = null;
		InputStream fout = null;
		ObjectInputStream oos  = null;
		LogRunTimeErros logRunTimeErros = new LogGSTR2RunTimeErros();
		Set<TblPurchaseErrorInfo> errorList = new HashSet<TblPurchaseErrorInfo>();
		try{

			inwardInvoiceDTO = (InwardInvoiceDTO) input.getValues().get(0);
			if(inwardInvoiceDTO.getErrorList() != null) {
				errorList = inwardInvoiceDTO.getErrorList();
			}

			//FileInputStream fout = new FileInputStream("/GSTR2_RuleValidation.ser");
			fout = PurchaseRegRuleValidationBolt.class.getResourceAsStream("/GSTR2_RuleValidation.ser");
			oos = new ObjectInputStream(fout);

			Collection<KnowledgePackage> knowledgePackages = (Collection<KnowledgePackage>) oos.readObject();
			KieBaseConfiguration kBaseConfig = KnowledgeBaseFactory.newKnowledgeBaseConfiguration();
			KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase(kBaseConfig);
			kbase.addKnowledgePackages(knowledgePackages);
			StatefulKnowledgeSession kSession = kbase.newStatefulKnowledgeSession();

			Globals globals = kSession.getGlobals();
			globals.set("errorList", errorList);

			InwardInvoiceModel inaWardstgTbl = inwardInvoiceDTO.getLineItemList().get(0);
			log.info("rediskey : " + inwardInvoiceDTO.getRedisKey() + " InvOrder : "+ inaWardstgTbl.getInvOrder());

			kSession.insert(inaWardstgTbl);
			kSession.fireAllRules();

			if ((inwardInvoiceDTO.getInvStatus() == null || inwardInvoiceDTO.getInvStatus().isEmpty()
					|| inwardInvoiceDTO.getInvStatus().equals(
							Constant.GSTR2_BR_STG1)) && inaWardstgTbl.getItemStatus() != null) {
				inwardInvoiceDTO.setInvStatus(inaWardstgTbl.getItemStatus());
			}

			inwardInvoiceDTO.setErrorList(errorList);
			kSession.destroy();

			inwardInvoiceDTO=validationRuleService.executeGSTR2ITCValidationRules(inwardInvoiceDTO);

			if(inwardInvoiceDTO != null){
				collector.emit(input,new Values(inwardInvoiceDTO));
			}else{
				logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
			}
		}catch(Exception ex){
			log.error("Error in PurchaseRegRuleValidationBolt "+ex.getMessage());
			//collector.customReportError(input, ex, "Exception in Bolt PurchaseRegRuleValidationBolt");
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}
		finally {
			try {
				if(oos!=null)
					oos.close();
				if(fout!=null)
					fout.close();
			} catch(IOException e) {
				log.error("Error closing stream", e);
			}
			collector.ack(input);
			//collector.emit(new Values(inwardInvoiceDTO));
			//collector.emit(Constant.GSTR2_Stream1,new Values(invoiceDTO));
			//RestClientUtility restClientUtil = new RestClientUtility();
			//restClientUtil.callRestService(validatedInvoiceDTO);
			log.info("In PurchaseRegReadBolt.execute() end");
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR2_Stream1,new Fields("inv"));
	}
}