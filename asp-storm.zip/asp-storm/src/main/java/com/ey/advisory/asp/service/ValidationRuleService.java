package com.ey.advisory.asp.service;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;

public interface ValidationRuleService {
	
	public OutwardInvoiceDTO executeGSTR1ValidationRules(OutwardInvoiceDTO outwardInvoiceDTO);

	public OutwardInvoiceDTO executeLineItemValidationRules(OutwardInvoiceDTO outwardInvoiceDTO);
	
}
