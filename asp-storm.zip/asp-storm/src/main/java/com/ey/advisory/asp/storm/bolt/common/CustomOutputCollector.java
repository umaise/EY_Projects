package com.ey.advisory.asp.storm.bolt.common;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.storm.task.IOutputCollector;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ey.advisory.asp.common.RedisTemplateUtil;
import com.ey.advisory.asp.dto.InvoiceDTO;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;

/**
 * Redirect Bolt's exceptions to Storm UI and Redis.
 * 
 * @author Mayank3.Kumar
 *
 */
public class CustomOutputCollector extends OutputCollector{

	private static final Logger log = LoggerFactory.getLogger(CustomOutputCollector.class);
	
	RedisTemplateUtil<String, Object> redisTemplateUtil = null;
	public CustomOutputCollector(IOutputCollector delegate) {
		super(delegate);		
		redisTemplateUtil = new RedisTemplateUtil<String, Object>();
	}
	
	/**
	 * Use when input tuple to bolt is not of type InvoiceDTO but you are converting it to InvoiceDTO(Ex: SaleRegCatRuleBolt).
	 * Will log Bolt's Exceptions to both Storm UI and Redis.
     * This method will not ack the tuple assuming caller's finally block will do acking.
	 * @param invoiceDTO : json/etc to converted InvoiceDTO
	 * @param e : exception caught
	 * @param boltMessage : additional message from bolt(something bolt specific)
	 */
	public void customReportError(InvoiceDTO invoiceDTO,Throwable e,String boltMessage){
		
		log.error("CustomOutputCollector.customReportError(InvoiceDTO): EXCEPTION : "+ExceptionUtils.getFullStackTrace(e));
		// Commented for testing huge-file issue
		/*
	try{ 		  
		  RedisTemplate<String,Object> redisTemplate = redisTemplateUtil.getRedisTemplate();
		  String redisKey=null;	 
		  
			  if(invoiceDTO !=null){
				  
			    	redisKey=invoiceDTO.getRedisKey();
			    	if(redisKey !=null){
						  
			    		String sysErrKey=getErrorRecordKey(redisKey,invoiceDTO);
						SystemErrorLogInfo systemErrorLogInfo = new SystemErrorLogInfo(boltMessage,new Date(),e,invoiceDTO);						
				        // push error info to redis						
				        //redisTemplate.opsForHash().put(redisKey,sysErrKey,systemErrorLogInfo);
				        log.error("Errorlogged to redis sysErrKey ..."+sysErrKey);
					}else{
						log.error("Error CustomOutputCollector.customReportError() : Can't find redisKey for input tuple.");
					}		    	
			    }
		} catch(Exception ex){			
				log.error("Error CustomOutputCollector.customReportError()", ex);
				
				// report error to Storm UI alone				
		    	super.reportError(new Exception("Exception in logging Bolt's error to redis, Bolt message : "+boltMessage+" boltError : "+e,ex));
	        }		
		  
		  super.reportError(e);	  // comment if not to show bolt exception on Storm-UI
			
	*/
		}
	
  	/**
  	 * Use when input tuple to bolt is of type InvoiceDTO.
	 * Will log Bolt's Exceptions to both Storm UI and Redis.
     * This method will not ack the tuple assuming caller's finally block will do acking.
	 * @param input : bolt's tuple 
	 * @param e : exception caught
	 * @param boltMessage : additional message from bolt(something bolt specific)
	 */
	public void customReportError(Tuple input,Throwable e,String boltMessage){
		
		log.error("CustomOutputCollector.customReportError(Tuple): EXCEPTION : "+ExceptionUtils.getFullStackTrace(e));
		// Commented for testing huge-file issue
		/*
		InvoiceDTO invoiceDTO = null;
		if(input.getValue(0) instanceof InvoiceDTO){
			invoiceDTO = (InvoiceDTO) input.getValue(0); // Is all bolt has input instance of OutwardInvoiceDTO/InwardInvoiceDTO ??
			customReportError(invoiceDTO,e,boltMessage);
			
		}else{
	    	log.error("Error CustomOutputCollector.customReportError() : Invalid tuple, Can't log this exception. Tuple should be instance of InvoiceDTO");
	    	// report error to Storm UI alone
	    	super.reportError(new Exception("Invalid Tuple: Tuple should be of type InvoiceDTO or Call customReportError(InvoiceDTO invoiceDTO,Throwable e,String boltMessage) method if bolt is receving json in Tuple. Bolt message: "+boltMessage));
		}*/
	}
	
	private String getErrorRecordKey(String redisKey,InvoiceDTO invoiceDTO){
		StringBuilder key = new StringBuilder(redisKey);
		
		if(invoiceDTO instanceof InwardInvoiceDTO){
			/*List<InwardInvoiceModel> lineItems = ((InwardInvoiceDTO)invoiceDTO).getLineItemList();
			InwardInvoiceModel inwardInvoiceModel = lineItems.get(0);
			key.append("_").append(inwardInvoiceModel.getfILEID()).append("_").append(inwardInvoiceModel.getId());
			
		}else if(invoiceDTO instanceof OutwardInvoiceDTO){
			List<OutwardInvoiceModel> lineItems = ((OutwardInvoiceDTO)invoiceDTO).getLineItemList();
			OutwardInvoiceModel outwardInvoiceModel = lineItems.get(0);
			key.append("_").append(outwardInvoiceModel.getFileID()).append("_").append(outwardInvoiceModel.getId());
			
		}else if(invoiceDTO instanceof ReconciliationDTO){
			List<InwardInvoiceModel> lineItems = ((ReconciliationDTO)invoiceDTO).getPurchaseStagingLineItems();
			InwardInvoiceModel inwardInvoiceModel = lineItems.get(0);
			key.append("_").append(inwardInvoiceModel.getfILEID()).append("_").append(inwardInvoiceModel.getId());
		*/}else{
			log.warn("Unknown DTO, logging bolt error with redisKey alone: "+redisKey);
			super.reportError(new Exception("Unknown DTO, add your DTO here. Logging bolt error with redisKey alone: "+redisKey));
		}
		
		return null;//key.append("_").append(Constant.SYSTEM_ERROR_DETAILS).toString();	
	}
	
		
}
