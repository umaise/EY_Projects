package com.ey.advisory.asp.storm.topology.gstr6.reconciliation;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseRichBolt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.storm.bolt.common.GSTR6AReconRedisWSBolt;
import com.ey.advisory.asp.storm.bolt.gstr6.reconciliation.GSTR6AReconcBolt;
import com.ey.advisory.asp.storm.spout.gstr6.reconciliation.GSTR6AReconSpoutBuilder;
import com.ey.advisory.asp.storm.topology.StormTopologyBuilder;

public class GSTR6AReconTopologyBuilder extends StormTopologyBuilder {

	private final Logger log = LoggerFactory.getLogger(getClass());
	
	private GSTR6AReconSpoutBuilder gstr6aReconSpoutBuilder;
	private BaseRichBolt gstr6aReconBolt;	
	//private BaseRichBolt gstr2ItcBolt;
	private BaseRichBolt gstr6aReconRedisWSBolt;
	
	public GSTR6AReconTopologyBuilder(Properties configs) {
		super(configs);
		initialize();
	}
	
	
	private void initialize() {
		gstr6aReconSpoutBuilder = new GSTR6AReconSpoutBuilder(configs);
		gstr6aReconBolt = new GSTR6AReconcBolt();
		//gstr2ItcBolt = new GSTR2ITCBolt();
		gstr6aReconRedisWSBolt = new GSTR6AReconRedisWSBolt();
		
		
	}

	@Override
	public void buildDataPipeline(TopologyBuilder builder) {
		log.info("GSTR6AReconTopologyBuilder.setBuilderDataPipeline() starts");
		
		if(builder != null){
			try{
				KafkaSpout gstr6ReconSpout=gstr6aReconSpoutBuilder.buildKafkaSpout();
				builder.setSpout(configs.getProperty(Constant.STORM_SPOUT_GSTR6A_RECON), gstr6ReconSpout);
				
				builder.setBolt(configs.getProperty(Constant.BOLT_GSTR6A_RECON),gstr6aReconBolt).shuffleGrouping(configs.getProperty(Constant.STORM_SPOUT_GSTR6A_RECON));
				
				//builder.setBolt(configs.getProperty(Constant.BOLT_GSTR2A_RECON_ITC),gstr2ItcBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_GSTR2A_RECON));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_GSTR6A_RECON_REDIS_WS), gstr6aReconRedisWSBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_GSTR6A_RECON));
				log.info("GSTR6AReconTopologyBuilder.setBuilderDataPipeline() ends");
			
			}catch(Exception e){
				log.error("Error Building GSTR2ARecon Topology " + e);
			}
		}
	
	}

}
