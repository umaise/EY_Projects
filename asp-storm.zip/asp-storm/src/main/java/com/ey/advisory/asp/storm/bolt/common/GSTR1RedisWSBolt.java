package com.ey.advisory.asp.storm.bolt.common;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;

public class GSTR1RedisWSBolt extends CustomBaseRichBolt {

    private CustomOutputCollector collector;

    private final Logger log = LoggerFactory.getLogger(getClass());
    @Override
    public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
        this.collector = collector;
    }

    @Override
    public void execute(Tuple input) {
        OutwardInvoiceDTO outwardInvoiceDTO = null;
        LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();	
        long startTime=System.currentTimeMillis();
        int invOrder=0;
        
        try{
        	if(log.isInfoEnabled())
                log.info("In GSTR1RedisWSBolt.execute() start");
        	
        	outwardInvoiceDTO = (OutwardInvoiceDTO) input.getValue(0);
        	
        	log.info("In GSTR1RedisWSBolt message Id :"+input.getMessageId());
        	
        	RedisTemplate<String,Object> redisTemplate= JedisConnectionUtil.getRedisTemplateKVStringObject();
        	

            String redisKey=outwardInvoiceDTO.getRedisKey();
            String invStatusKey=redisKey+"_"+Constant.INVOICE_STATUS;
            String invErrKey=redisKey+"_"+Constant.INVOICE_ERROR_DETAILS;
			String invProcessedKey=redisKey+"_"+Constant.INVOICE_PSD_COUNT;

            InvoiceProcessDto invProcessDto=new InvoiceProcessDto();
            if(outwardInvoiceDTO.getLineItemList()!=null){
                OutwardInvoiceModel outwardStagingDetail=outwardInvoiceDTO.getLineItemList().get(0);
                invOrder=outwardStagingDetail.getInvOrder();
                invProcessDto.setStatus(outwardInvoiceDTO.getInvStatus());
                invProcessDto.setTableType(outwardStagingDetail.getTableType());
                invProcessDto.setSubCategory(outwardStagingDetail.getSubCategory());
                invProcessDto.setInvOrder(outwardStagingDetail.getInvOrder());
                invProcessDto.setsGstin(outwardStagingDetail.getsGSTIN());
                if(outwardInvoiceDTO.getCrdr_OrgInvNum() != null && outwardInvoiceDTO.getCrdr_OrgInvDate() != null) { 
                	invProcessDto.setOrgCRDocNo(outwardInvoiceDTO.getCrdr_OrgInvNum());
                	invProcessDto.setOrgCRDocDate(outwardInvoiceDTO.getCrdr_OrgInvDate());
                }
                log.info("In GSTR1RedisWSBolt  redis key : "+outwardInvoiceDTO.getRedisKey() + " Invoice order : "+outwardStagingDetail.getInvOrder());
                redisTemplate.opsForHash().put(invStatusKey,invProcessDto.getInvOrder(),invProcessDto);
				redisTemplate.opsForHash().put(invProcessedKey,invProcessDto.getInvOrder(),invProcessDto.getInvOrder());
                
                Set<TblSalesErrorInfo> errorList=outwardInvoiceDTO.getErrorList();
                if(errorList!=null && !errorList.isEmpty()){
                	redisTemplate.opsForHash().put(invErrKey,invProcessDto.getInvOrder(),errorList);
                }
                
            }
            
            //collector.emit(input,new Values(outwardInvoiceDTO));
           
        }
        catch(Exception ex){			
            log.error("Error GSTR1RedisWSBolt", ex);
            logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
        }
        finally {
            collector.ack(input);
            if(log.isInfoEnabled())
            	log.info("In GSTR1RedisWSBolt Time taken for file : "+outwardInvoiceDTO.getRedisKey()+" Inv Order : "+ invOrder+" is "+(System.currentTimeMillis()-startTime));
        }
        
       
    }

    @Override
    public void cleanup() {
        super.cleanup();
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
    	declarer.declare(new Fields("inv"));
    }
}
