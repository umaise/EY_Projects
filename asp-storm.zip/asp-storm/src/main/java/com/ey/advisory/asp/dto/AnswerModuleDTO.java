package com.ey.advisory.asp.dto;

import java.io.Serializable;

public class AnswerModuleDTO implements Serializable {

private static final long serialVersionUID = 1L;
    
    private String answerId;
    private String answerDescription;
    
    public String getAnswerId() {
        return answerId;
    }
    public void setAnswerId(String answerId) {
        this.answerId = answerId;
    }
    public String getAnswerDescription() {
        return answerDescription;
    }
    public void setAnswerDescription(String answerDescription) {
        this.answerDescription = answerDescription;
    }  
    
}
