package com.ey.advisory.asp.storm.bolt.gstr6.reconciliation;

import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.client.domain.ReconciliationDetailsDTO;
import com.ey.advisory.asp.client.domain.ReconciliationDetailsDrDTO;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.KSessionUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

/**

* @author  Yogesh Mittal
* @version 1.0
* @since   01-06-2017
*/

public class GSTR6AReconcBolt extends CustomBaseRichBolt {

	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;
	
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		
	}

	@Override
	public void execute(Tuple input) {/*
		log.info("In GSTR6AReconcBolt.execute() start");
		Double pRITCAmount = Constant.ZERO_DOUBLE;
		Double GSTR6AITCAmount = Constant.ZERO_DOUBLE;
		Double dRITCAmount = Constant.ZERO_DOUBLE;
		
		//Set<TblIsdErrorInfo> reconErrorList = new HashSet<TblIsdErrorInfo>();
		
		Gson gson = new Gson();
		String invString=input.getString(0);
		Type listType = new TypeToken<ReconciliationDTO>(){}.getType();
		log.info("Priniting recon JSON String " + input.getString(0));
		ReconciliationDTO reconciliationDTO = new ReconciliationDTO();
		try{
			reconciliationDTO = gson.fromJson(invString, listType);
			reconciliationDTO.setGroupCode(Utility.getGroupCode(reconciliationDTO.getRedisKey()));
			if(reconciliationDTO.getPurchaseRegister() != null && !reconciliationDTO.getPurchaseRegister().isEmpty()){
			for(ReconciliationDetailsDTO detail : reconciliationDTO.getPurchaseRegister()){
				pRITCAmount = pRITCAmount + (detail.getItcIgstAmt() != null ? detail.getItcIgstAmt() : Constant.ZERO_DOUBLE) + (detail.getItcSgstAmt() != null ? detail.getItcSgstAmt() : Constant.ZERO_DOUBLE)
						+ (detail.getItcCgstAmt() != null ? detail.getItcCgstAmt() : Constant.ZERO_DOUBLE) + (detail.getItcCessAmt() != null ? detail.getItcCessAmt() : Constant.ZERO_DOUBLE);
				}
			}
			
			if(reconciliationDTO.getGstr2A() != null && !reconciliationDTO.getGstr2A().isEmpty()){
				for(ReconciliationDetailsDTO detail : reconciliationDTO.getGstr2A()){
					GSTR6AITCAmount = GSTR6AITCAmount + (detail.getItcIgstAmt() != null ? detail.getItcIgstAmt() : Constant.ZERO_DOUBLE) + (detail.getItcSgstAmt() != null ? detail.getItcSgstAmt() : Constant.ZERO_DOUBLE)
							+ (detail.getItcCgstAmt() != null ? detail.getItcCgstAmt() : Constant.ZERO_DOUBLE) + (detail.getItcCessAmt() != null ? detail.getItcCessAmt() : Constant.ZERO_DOUBLE);
					}
			}
			
			if(reconciliationDTO.getDistributionRegister() != null && !reconciliationDTO.getDistributionRegister().isEmpty()){
				for(ReconciliationDetailsDrDTO detail : reconciliationDTO.getDistributionRegister()){
					dRITCAmount = dRITCAmount + (detail.getItcIGST() != null ? detail.getItcIGST() : Constant.ZERO_DOUBLE) + (detail.getItcSGST_UTGST() != null ? detail.getItcSGST_UTGST() : Constant.ZERO_DOUBLE)
							+ (detail.getItcCGST() != null ? detail.getItcCGST() : Constant.ZERO_DOUBLE) + (detail.getItcCESS() != null ? detail.getItcCESS() : Constant.ZERO_DOUBLE);
					}
			}
			reconciliationDTO.setPurchaseRegisterITCAmount(pRITCAmount);
			reconciliationDTO.setGstr2aITCAmount(GSTR6AITCAmount);
			reconciliationDTO.setdRITCAmount(dRITCAmount);

		//reconciliationDTO.setErrorList(reconErrorList);
		reconciliationDTO.setFilingRecordType(Constant.FILING_RECORD_TYPE_PURCHASE_REGISTER);
		
		KieSession kSession = KSessionUtility
				.getKSession("rules/GSTR6/GSTR6_Reconciliation.drl");
		//kSession.setGlobal("reconErrorList", reconErrorList);
		kSession.insert(reconciliationDTO);
		
		kSession.fireAllRules();
		kSession.destroy();
		
		}catch(Exception e){
			log.error("error Reconciling GSTR6a Data", e);
			//collector.customReportError(reconciliationDTO, e, "Exception in Bolt GSTR2AReconcBolt");
		}finally{
			collector.ack(input);
			collector.emit(new Values(reconciliationDTO));
		
			log.info("In GSTR6AReconBolt.execute() end");
		}
		
	*/}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		
	}
	
	

}
