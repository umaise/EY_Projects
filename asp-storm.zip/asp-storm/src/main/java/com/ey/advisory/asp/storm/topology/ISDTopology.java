package com.ey.advisory.asp.storm.topology;

import java.util.Properties;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.redis.common.config.JedisPoolConfig;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RedisConnectionUtil;
import com.ey.advisory.asp.common.configs.YamlConfigRunner;
import com.ey.advisory.asp.dto.InvoiceDTO;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.client.domain.ReconciliationDetailsDTO;
import com.ey.advisory.asp.storm.topology.gstr1.gstn.SendGstnTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr1.rulestg1.SaleRegTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr1.rulestg2.SaleRegPipelineTwoTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr2.gstn.SendGstr2GstnTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr2.reconciliation.GSTR2AReconTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr2.rulestg1.PurchaseRegTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr6.rulestg1.ISDTopologyBuilder;



public class ISDTopology {
	
	public Properties configs;
	public JedisPoolConfig jedisPoolConfig;

	
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	public ISDTopology(){
		configs = new Properties();
		try {
			log.info("In Topology constructor start");
			configs.load(ISDTopology.class.getResourceAsStream("/asp-storm-config.properties"));
			//jedisPoolConfig=new RedisConnectionUtil().getJedisPoolConfig();
			log.info("In Topology constructor ends");
		} catch (Exception ex) {
			ex.printStackTrace();
			//System.exit(0);
		}
	}
	
	private void submitTopology(){
		try{
			log.info("In Topology.submitTopology() start");
			TopologyBuilder builder = new TopologyBuilder();
			new ISDTopologyBuilder(configs).buildDataPipeline(builder);
			
			String topologyName = configs.getProperty(Constant.TOPOLOGY_NAME);
			
			Config config = new Config();
			//User defined YAML conf			
			YamlConfigRunner runner = new YamlConfigRunner();		
			runner.loadRedisConfigsLOCAL(getClass().getResourceAsStream("/storm_redis.yaml"),config);
			runner.loadRESTConfigsLOCAL(getClass().getResourceAsStream("/storm_rest-config.yaml"),config);
			config.setNumWorkers(4);
			config.setMaxSpoutPending(5000);
			
			
			config.registerSerialization(InwardInvoiceModel.class);
			config.registerSerialization(InwardInvoiceGstr6DTO.class);
			config.registerSerialization(InvoiceDTO.class);

		   /* LocalCluster cluster = new LocalCluster();
		    cluster.submitTopology(topologyName,  config, builder.createTopology());
		   */ 
		   StormSubmitter.submitTopology(topologyName, config, builder.createTopology());
		    
		    log.info("In Topology.submitTopology() ends");
		    
		}catch (Exception ex) {
			ex.printStackTrace();
			//System.exit(0);
		}
	    
	}
	
	public static void main(String[] args) {
		ISDTopology topology=new ISDTopology();
		DRLSerializer.preCompileDrls("rules/GSTR6/GSTR6_Classification.drl", "GSTR6_classification.ser");		
		DRLSerializer.preCompileDrls("rules/GSTR6/GSTR6_LineItemValidation.drl", "GSTR6_LineItemValidation.ser");
		topology.submitTopology();

	}

}
