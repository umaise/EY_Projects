package com.ey.advisory.asp.service.gstr2;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

public class CommonValidationRuleServiceImpl extends CommonValidationRuleService {
	private final Logger log = LoggerFactory.getLogger(getClass());
	Map<String, TblGstinDetailsDomain> gstinMap = new HashMap<String, TblGstinDetailsDomain>();
	Set<TblIsdErrorInfo> errorList = new HashSet<TblIsdErrorInfo>();
	
	@Override
	public InwardInvoiceGstr6DTO executeCommonBusinessRules(InwardInvoiceGstr6DTO inwardInvoiceDTO) {
		if(inwardInvoiceDTO.getErrorList()!=null){
			errorList = inwardInvoiceDTO.getErrorList();
		}
		
		List<InwardInvoiceModel> lineItems = inwardInvoiceDTO.getLineItemList();
		InwardInvoiceModel inwardInvoiceModel = inwardInvoiceDTO.getLineItemList().get(0);
		if (lineItems != null && !lineItems.isEmpty()) {
			 boolean isvalidateDocumentDateForRegDate= validateDocumentDateForRegDate(inwardInvoiceModel,inwardInvoiceDTO.getGroupCode());
				
			 boolean isvalidateDocumentDateForTaxPeriod = validateDocumentDateForTaxPeriod(inwardInvoiceModel);
			 if (!isvalidateDocumentDateForTaxPeriod || !isvalidateDocumentDateForRegDate){
				 inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
			 inwardInvoiceDTO.setErrorList(errorList);
			} else if(inwardInvoiceDTO.getInvStatus() == null) {
				inwardInvoiceDTO.setInvStatus(Constant.GSTR6_BR_STG1);
			}
		}
		
		int counter = 0;

		if (inwardInvoiceDTO.getLineItemList() != null) {

			for (InwardInvoiceModel inwardInvoiceModel2 : inwardInvoiceDTO.getLineItemList()) {
				checkforIntraorInterState(inwardInvoiceModel2);
				checkHSNorSAC(inwardInvoiceModel2,inwardInvoiceDTO.getGroupCode());
				validateTaxvalues(inwardInvoiceModel);
			}

			if (inwardInvoiceModel.getItemStatus() != null
					&& inwardInvoiceModel.getItemStatus() == Constant.BUS_RULE_ERROR) {
				counter = counter + 1;
			}
		}

		if (counter > 0) {
			inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
		} else if (inwardInvoiceDTO.getInvStatus() == null) {
			inwardInvoiceDTO.setInvStatus(Constant.GSTR6_BR_STG1);
		}
		inwardInvoiceDTO.setErrorList(errorList);
		
		return inwardInvoiceDTO;
	}
	
	/*
     * validating document date to be within tax period boundaries
     */

	private boolean validateDocumentDateForTaxPeriod(InwardInvoiceModel inwardInvoiceModel) {
		Calendar docDate = Calendar.getInstance();
		Calendar taxPeriod = Calendar.getInstance();
		// if(inwardInvoiceModel.getDocumentDate() != null &&
		// inwardInvoiceModel.getTaxperiod() != null &&
		// !inwardInvoiceModel.getTaxperiod().isEmpty()){
		try {

			docDate.setTime(
					Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getDocumentDate().toString()));
			taxPeriod.setTime(Utility.convertStringToDate(Constant.DATEFORMAT, inwardInvoiceModel.getTaxPeriod()));
			if (docDate.get(Calendar.YEAR) > taxPeriod.get(Calendar.YEAR)
					|| (docDate.get(Calendar.MONTH) > taxPeriod.get(Calendar.MONTH)
							&& docDate.get(Calendar.YEAR) == taxPeriod.get(Calendar.YEAR))) {

				// errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel.getId(),
				// "ER201", "DocumentDate", Constant.BUS_RULE_ERROR,
				// false,inwardInvoiceModel.getDocumentNo(),inwardInvoiceModel.getCGSTIN(),Constant.INVOICE));
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER223", "DocumentDate",
						Constant.BUSINESS_RULE, Boolean.FALSE, Constant.INVOICE));
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				log.warn("ER201: Error in transaction " + inwardInvoiceModel.getId()
						+ " The Doucment Date cannot be a future date beyond the tax period");
				return false;
			}
		} catch (ParseException pe) {
			log.error("Error Parsing Date for invoice ", inwardInvoiceModel.getId(), pe);
		} catch (Exception e) {
			log.error("Error Validating DocumentDate for TaxPeriod ", e);
		}

		// }
		return true;

	}

    
	/**
     * Validating Document Date for greater than Registration Date
     */
    private boolean validateDocumentDateForRegDate(InwardInvoiceModel inwardInvoiceModel, String groupCode ) {

		Date registrationDate = null;
		Date docDt = null;
		String gstinId = inwardInvoiceModel.getCGSTIN();

		RedisTemplate<String, Object> redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();
		gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(groupCode+"_"+ Constant.REDIS_CACHE,
				Constant.GSTIN_DEATILS);
		
		if(gstinMap == null){
				loadGSTINDetailsToRedis(groupCode);
				gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(
				    groupCode+"_"+ Constant.REDIS_CACHE, Constant.GSTIN_DEATILS);
			}
	

		TblGstinDetailsDomain gstin = null;
		if (gstinMap != null)
			gstin = gstinMap.get(gstinId);

		if (gstin == null) {
			ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
					"asp-restapi.getGSTIN", groupCode, gstinId, Constant.VERB_TYPE_POST);
			Gson gson = new Gson();
			if (response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
				gstin = gson.fromJson(response.getEntity(String.class), TblGstinDetailsDomain.class);
			}

		}

		if (gstin != null && gstin.getRegdt()!=null ){
			//registrationDate = Utility.convertStringToDate(Constant.DATE_FORMAT, gstin.getRegdt().toString());
			registrationDate = gstin.getRegdt();
		}

		if (registrationDate == null) {
			log.error("GST Registration Date is not available");
			inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER053", "Registration Date", Constant.BUSINESS_RULE, Boolean.FALSE
					,Constant.INVOICE));
			return false;
		} else {
			try {
				docDt = Utility.convertStringToDate(Constant.DATE_FORMAT,
						inwardInvoiceModel.getDocumentDate().toString());
			} catch (ParseException e) {
				e.printStackTrace();
				log.error("Error in parsing date" + e);
			}

			if (docDt!=null && docDt.compareTo(registrationDate) < 0) {

				log.error("Document Date is earlier than the Effective Date of GST Registration");

				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);

				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER220", "Document Date", Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.INVOICE));
				return false;
			}
		}

		return true;
	}	
    
    private String loadGSTINDetailsToRedis(String groupCode ) {
        String status = null;
    	
 		
    	 ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.LOAD_GSTIN_REDIS,  groupCode, null, Constant.VERB_TYPE_POST);
    	 Gson gson = new Gson();

 			if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
 				status = gson.fromJson(response.getEntity(String.class), String.class);
 			}
 			return status;
 		
 	}
 	@SuppressWarnings("unchecked")
 	@Override
 	public String validateHsnSacAgainstNonGST(String groupCode) {
 		ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host",
 				"asp-restapi.validateHSNSACISD", groupCode, "success", Constant.VERB_TYPE_POST);

 		if (response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
 			return "Success";
 		}

 		return "Failure";

 	}
 	
 	private void checkHSNorSAC(InwardInvoiceModel inwardInvoiceModel, String groupCode) {
		String hsnORsac = "";
		int count = 1;
		String hsnsac = inwardInvoiceModel.getHSNorSAC();
		Gson gson = new Gson();
		if (hsnsac != null) {

			try {
				ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host",
						"asp-restapi.checkHSNSACInRedis", groupCode, hsnsac, Constant.VERB_TYPE_POST);
				if (response != null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {

					count = gson.fromJson(response.getEntity(String.class), Integer.class);
				}
			} catch (Exception e) {
				log.error("Error in checkHSNorSAC, response : " + e);
			}
			if (count==0) {
				log.info("Invoices has non-SAC values");
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER607", Constant.HSN_SAC,
						Constant.BUSINESS_RULE, Boolean.FALSE, Constant.INVOICE));

			}
		}
	}
 	
	/**
	 * @param inwardInvoiceModel
	 *            BR 1367
	 */
	private void checkforIntraorInterState(InwardInvoiceModel inwardInvoiceModel) {

		if (inwardInvoiceModel.getIGSTAmount() != null || inwardInvoiceModel.getCGSTAmount() != null
				|| inwardInvoiceModel.getSGSTAmount() != null) {

			if (((inwardInvoiceModel.getIGSTAmount() != null)
					&& (inwardInvoiceModel.getCGSTAmount() != null || inwardInvoiceModel.getSGSTAmount() != null))
					|| ((inwardInvoiceModel.getCGSTAmount() != null && inwardInvoiceModel.getSGSTAmount() != null)
							&& (!(inwardInvoiceModel.getIGSTAmount() == null)))
					|| (inwardInvoiceModel.getCGSTAmount() != null && inwardInvoiceModel.getSGSTAmount() == null)
					|| (inwardInvoiceModel.getSGSTAmount() != null && inwardInvoiceModel.getCGSTAmount() == null)) {

				log.info("An invoice can either be intra-State or inter-State");
				String columnNames = Constant.CGST_AMOUNT + "," + Constant.IGST_AMOUNT + "," + Constant.SGST_AMOUNT;
				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER224", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE
						,Constant.INVOICE));

			}

		}

	}



 	// ER237 ER238 ER224 
	private void validateTaxvalues(InwardInvoiceModel inwardInvoiceModel) {

		if (checkEmptyornull(inwardInvoiceModel.getIGSTAmount())) {
			inwardInvoiceModel.setIGSTAmount(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getCGSTAmount())) {
			inwardInvoiceModel.setCGSTAmount(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getSGSTAmount())) {
			inwardInvoiceModel.setSGSTAmount(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getIGSTRate())) {
			inwardInvoiceModel.setIGSTRate(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getCGSTRate())) {
			inwardInvoiceModel.setCGSTRate(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getSGSTRate())) {
			inwardInvoiceModel.setSGSTRate(BigDecimal.ZERO);
		}
		if (!checksupplyType(inwardInvoiceModel.getSupplyType(),inwardInvoiceModel.getSGSTIN())) {
			validatetaxAmount(inwardInvoiceModel);
		} else {
			if (!(inwardInvoiceModel.getIGSTAmount().equals(BigDecimal.ZERO))
					&& (inwardInvoiceModel.getCGSTAmount().abs().add(inwardInvoiceModel.getSGSTAmount().abs()).compareTo(BigDecimal.ZERO)==1 )) {
				log.info("An invoice can either be intra-State or inter-State");
				String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
				errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER224", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
			}
		}

	}
	
	private Boolean checkEmptyornull(BigDecimal value) {
		if (value != null && !value.toString().isEmpty()) {
			return false;
		}
		return true;
	}
	
	private Boolean checksupplyType(String supplyType, String sGSTIN) {
		if (supplyType.equalsIgnoreCase(Constant.EXT) || (supplyType.equalsIgnoreCase(Constant.NIL))
				|| (supplyType.equalsIgnoreCase(Constant.NON)|| (supplyType.equalsIgnoreCase(Constant.NYS)) 
						||(supplyType.equalsIgnoreCase(Constant.IMPS)))||(supplyType.equalsIgnoreCase(Constant.SEZG)) || (supplyType.equalsIgnoreCase(Constant.SEZS)) ||(supplyType.equalsIgnoreCase(Constant.EXPT))
				||(supplyType.equalsIgnoreCase(Constant.EXPT))||(supplyType.equalsIgnoreCase(Constant.EXPWT))||(supplyType.equalsIgnoreCase(Constant.DXP ))||(supplyType.equalsIgnoreCase(Constant.COM))||(supplyType.equalsIgnoreCase(Constant.DTA))||(supplyType.equalsIgnoreCase(Constant.COM))||(supplyType.equalsIgnoreCase(Constant.IMPG))||(sGSTIN==null)||(sGSTIN.trim().isEmpty())) 
		{
			return true;
		}
		return false;
	}

 	private void validatetaxAmount(InwardInvoiceModel inwardInvoiceModel) {

 		if(inwardInvoiceModel.getSupplyType().equalsIgnoreCase(Constant.TAX) 
 				&& (inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==0)
 				&& (inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==0)
 				&& (inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==0) 
 				&& (inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==0)
 				&& (inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==0)
 				&& (inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==0)) {
 			return;
 		}

 		if (!(inwardInvoiceModel.getIGSTAmount().equals(BigDecimal.ZERO))
 				&& (inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==1)&&(inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==1)) {
 			log.info("An invoice can either be intra-State or inter-State");
 			String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
 			errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER224", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
 		} else if ((inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==0)
 				&& (inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==0)
 				&& (inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==0 &&(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==0)
 				&& (inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==0)
 				&& (inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==0))&&(inwardInvoiceModel.getReverseCharge()!=null)) {

 			checkforIntraorInterState(inwardInvoiceModel,Boolean.TRUE);
 		} else {

 			checkforIntraorInterState(inwardInvoiceModel,Boolean.FALSE);
 		} 
 	}

 	private void checkforIntraorInterState(InwardInvoiceModel inwardInvoiceModel, Boolean isZero) {

 		if(inwardInvoiceModel.getCGSTIN()!=null && !inwardInvoiceModel.getCGSTIN().trim().isEmpty() && (inwardInvoiceModel.getSGSTIN()!=null)&& (!inwardInvoiceModel.getSGSTIN().trim().isEmpty()) ){

 			if (inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2))&&(inwardInvoiceModel.getPos()==null)) {

 				if(!isZero && (inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==1 )||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==1)){

 					log.info("In case of Intra-State Supply, IGST Tax Rate and and/or Tax Amount cannot be applied ");
 					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT;
 					errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
 				}

 			} else if (inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2))&&(inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))) {

 				if(!isZero && (inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==1 ||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==1))){

 					log.info("In case of Intra-State Supply, IGST Tax Rate and and/or Tax Amount cannot be applied ");
 					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT;
 					errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
 				} 
 			} else if (inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2))&&(!inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))) {

 				if(!isZero && ((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==1)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==1)){

 					log.info("In case of Inter-State Supply, CGST & SGST/UTGST Tax Rate and/or Tax Amount cannot be applied");
 					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT;
 					errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

 				} 
 			} else if (!(inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))&&(inwardInvoiceModel.getPos()==null)) {

 				if(!isZero && ((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==1)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==1)){

 					log.info("In case of Inter-State Supply, CGST & SGST/UTGST Tax Rate and/or Tax Amount cannot be applied");
 					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT;
 					errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

 				} 
 			} else if (!(inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))&&(inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))) {

 				if(!isZero && (inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==1 ||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==1))){

 					log.info("In case of Intra-State Supply, IGST Tax Rate and and/or Tax Amount cannot be applied ");
 					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT;
 					errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
 				} 
 			} else if (!(inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))&&(inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getCGSTIN().substring(0, 2)))) {

 				if(!isZero &&  ((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==1)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==1)){

 					log.info("In case of Inter-State Supply, CGST & SGST/UTGST Tax Rate and/or Tax Amount cannot be applied");
 					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT;
 					errorList.add(ErrorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

 				}
 			}
 		}
 	}

}
