package com.ey.advisory.asp.storm.spout.gstr6.rulestg1;

import java.util.Properties;
import java.util.UUID;

import org.apache.storm.kafka.BrokerHosts;
import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.kafka.SpoutConfig;
import org.apache.storm.kafka.StringScheme;
import org.apache.storm.kafka.ZkHosts;
import org.apache.storm.spout.SchemeAsMultiScheme;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.storm.spout.SpoutBuilder;

import kafka.api.OffsetRequest;



public class ISDSpoutBuilder extends SpoutBuilder {
	
	private final Logger log = LoggerFactory.getLogger(getClass());

	public ISDSpoutBuilder(Properties configs) {
		super(configs);
	}

	@Override
	public KafkaSpout buildKafkaSpout() {
		log.info("In ISDSpoutBuilder.buildKafkaSpout() start");
		BrokerHosts hosts = new ZkHosts(configs.getProperty(Constant.KAFKA_ZOOKEEPER));
		String topic = configs.getProperty(Constant.KAFKA_TOPIC_ISDREG);
		String zkRoot = configs.getProperty(Constant.KAFKA_ISDREG_ZKROOT);
		SpoutConfig spoutConfig = new SpoutConfig(hosts, topic, zkRoot, UUID.randomUUID().toString());
		spoutConfig.startOffsetTime=OffsetRequest.LatestTime();
		spoutConfig.scheme = new SchemeAsMultiScheme(new StringScheme());
		KafkaSpout kafkaSpout = new KafkaSpout(spoutConfig);
		log.info("In ISDSpoutBuilder.buildKafkaSpout() end");
		return kafkaSpout;
	}

}

