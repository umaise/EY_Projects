package com.ey.advisory.asp.storm.bolt.common;

import java.util.Map;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.google.gson.JsonObject;

public class PublishRedisBolt extends CustomBaseRichBolt {
	
	private CustomOutputCollector collector;
	
	private RedisTemplate<String, Object> redisTemplate;
	
	 private final Logger log = LoggerFactory.getLogger(getClass());
	
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector=collector;
		
		redisTemplate= JedisConnectionUtil.getRedisTemplateKVStringObject();
	}

	@Override
	public void execute(Tuple input) {
		String tableType = input.getStringByField("tabletype");
		int count=(Integer) input.getValueByField("count");
		try{
		
		String[] params=tableType.split("~");
		
		JsonObject obj=new JsonObject();
		if(params!=null && params.length > 1){
			
			
			obj.addProperty("FileID", params[0]);
			obj.addProperty(params[1], count);
		}
		publish(obj.toString());
		
		}
		
		
		catch(Exception ex){
			
			log.error("Error PublishRedisBolt", ex);
			collector.customReportError(input, ex, "Exception in Bolt PublishRedisBolt");
		}
		
		finally {
			collector.ack(input);
			collector.emit(input, new Values(tableType, count));
			//collector.emit(Constant.GSTR2_COMMON_PUBREDIS_Stream,new Values(tableType, count));
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		
	}
	
	public void publish(String msg) { 
		
        redisTemplate.setHashValueSerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(new StringRedisSerializer());
        redisTemplate.afterPropertiesSet();
        redisTemplate.convertAndSend(Constant.REDIS_INVOICE_CHANNEL, msg);
        //redisTemplate.getConnectionFactory().getConnection().close(); 

}
}
