package com.ey.advisory.asp.storm.bolt.common;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;

public class GSTR6RestLogicBolt extends BoltBuilder {

    private CustomOutputCollector collector;

    private final Logger log = LoggerFactory.getLogger(getClass());
    @Override
    public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
        this.collector = collector;
    }

    @Override
    public void execute(Tuple input) {
    	InwardInvoiceGstr6DTO inwardInvoiceDTO = null;
        LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();	
        if(log.isInfoEnabled())
            log.info("In GSTR6RestLogicBolt.execute() start");
        try{
        	inwardInvoiceDTO = (InwardInvoiceGstr6DTO) input.getValue(0);
        	
        	RedisTemplate<String,Object> redisTemplate= JedisConnectionUtil.getRedisTemplateKVStringObject();
        	
            String redisKey=inwardInvoiceDTO.getRedisKey();
            
            String invProcessedKey=redisKey+"_"+Constant.INVOICE_PSD_COUNT;
            String invCntKey=redisKey+"_"+Constant.INVOICE_COUNT;
            
            Integer count=(Integer) redisTemplate.opsForValue().get(invCntKey);
            
            if(count==null || count==0 ){
            	 RedisTemplate<String, Integer> redisIntegertemplate=JedisConnectionUtil.getRedisTemplateKVStringInteger();
            	 count=redisIntegertemplate.opsForValue().get(invCntKey);
            	 redisTemplate.opsForValue().set(invCntKey,count);
            }
            
            if(inwardInvoiceDTO.getLineItemList()!=null){
            	InwardInvoiceModel stgTable = (InwardInvoiceModel)inwardInvoiceDTO.getLineItemList().get(0);
            	redisTemplate.opsForHash().put(invProcessedKey,stgTable.getInvOrder(),stgTable.getInvoiceKey());
            }
            
            Set<Object> psdInvSet= redisTemplate.opsForHash().keys(invProcessedKey);
            
            Integer invPsdCnt=psdInvSet.size();
            
            log.info("Invoice Count for "+redisKey+" : "+ count);
            log.info("Invoice processed for "+redisKey+" : "+ invPsdCnt);
            
            collector.emit(input,new Values(inwardInvoiceDTO,count,invPsdCnt));
        }
        catch(Exception ex){			
            log.error("Error GSTR6RestLogicBolt", ex);
            logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
        }
        finally {
            collector.ack(input);
            if(log.isInfoEnabled())
                log.info("In GSTR6RestLogicBolt.execute() end");
        }
        
       
    }

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv","invCount","invPsdCnt"));
		
	}

}
