package com.ey.advisory.asp.common.configs;

import java.util.Map;
import static java.lang.String.format;

public class Configurations {

	private Map< String, Object > config;	
	
	 public Map<String, Object> getConfig() {
		return config;
	}

	public void setConfig(Map<String, Object> config) {
		this.config = config;
	}

	@Override
	 public String toString() {
        return new StringBuilder()            
            .append( format( "YAML Conf: %s\n", config))
            .toString();
    }
	
}
