package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.SerializedName;


public class TDSInwardInvoiceModel implements Serializable 
{
	private static final long serialVersionUID = 1L;
	
	@SerializedName("ID")
	private int id;
	@SerializedName("FileID")
	private int fileID;
	@SerializedName("InwardSuppliesSubjectTTDS")
	private String inwardSuppliesSubjectTTDS;
	@SerializedName("ReceiverPlantCode")
	private String ReceiverPlantCode;
	@SerializedName("TaxPeriod")
	private String TaxPeriod;
	@SerializedName("ContractNumber")
	private String ContractNumber;
	@SerializedName("ContractDate")
	private Date Contractdate;
	@SerializedName("ContractValue")
	private int  ContractValue;
	@SerializedName("DocumentType")
	private String    DocumentType;
	@SerializedName("SupplyType")
	private String    SupplyType;
	@SerializedName("DcoumentAttribute")
	private String      DcoumentAttribute;
	@SerializedName("CompanyGSTIN")
	private String      CompanyGSTIN;
	@SerializedName("SupplierGSTIN")
	private String      SupplierGSTIN;
	@SerializedName("SupplierCode")
	private String      SupplierCode;
	@SerializedName("SupplierName")
	private String      SupplierName;
	@SerializedName("SupplierAddress")
	private String      SupplierAddress;
	@SerializedName("ImportReportNumber")
	private String      ImportReportNumber;
	@SerializedName("ImportReportDate")
	private Date      ImportReportDate;
	@SerializedName("DocumentNo")
	private String      DocumentNo;
	@SerializedName("DocumentDate")
	private Date      DocumentDate;
	@SerializedName("LineNumber")
	private String      LineNumber;
	@SerializedName("OriginalDocumentNo")
	private String     OriginalDocumentNo;
	@SerializedName("OriginalDocumentDate")
	private Date      OriginalDocumentDate;
	@SerializedName("UnitofMeasurement")
	private String     UnitofMeasurement;
	@SerializedName("BillQty")
	private int     BillQty;
	@SerializedName("Advances")
	private int     Advances;
	@SerializedName("GSTTaxableValue")
	private int      GSTTaxableValue;
	@SerializedName("TransactionIDforAdvances")
	private String      TransactionIDforAdvances;
	@SerializedName("GoodServices")
	private char      GoodServices;
	@SerializedName("HSNSAC")
	private String      HSNSAC;
	@SerializedName("ItemCode")
	private String      ItemCode;
	@SerializedName("ItemDescription")
	private String      ItemDescription;
	@SerializedName("CategoryItem")
	private String      CategoryItem;
	@SerializedName("IGSTRate")
	private int      IGSTRate;
	@SerializedName("IGSTAmount")
	private int      IGSTAmount;
	@SerializedName("CGSTRate")
	private int      CGSTRate;
	@SerializedName("CGSTAmount")
	private int      CGSTAmount;
	@SerializedName("SGSTRate")
	private int      SGSTRate;
	@SerializedName("SGSTAmount")
	private int     SGSTAmount;
	@SerializedName("UTGSTRate")
	private int      UTGSTRate;
	@SerializedName("UTGSTAmount")
	private int      UTGSTAmount;
	@SerializedName("CessRate")
	private int      CessRate;
	@SerializedName("CessAmount")
	private int      CessAmount;
	@SerializedName("ValueIncludingTax")
	private int     ValueIncludingTax;
	@SerializedName("POS")
	private String     POS;
	@SerializedName("ReverseCharge")
	private char     ReverseCharge;
	@SerializedName("CosumptionType")
	private String      CosumptionType;
	@SerializedName("PaymentVoucherNumber")
	private String      PaymentVoucherNumber;
	@SerializedName("DateofPayment")
	private Date      DateofPayment;
	@SerializedName("ValueOnTDS")
	private int     ValueOnTDS;
	@SerializedName("GLCodeCapitalGoods")
	private String      GLCodeCapitalGoods;
	@SerializedName("CapitalGoodsIdentifier")
	private String      CapitalGoodsIdentifier;
	@SerializedName("EligibleInput")
	private String      EligibleInput;
	@SerializedName("TotalTaxeligibleITC")
	private int      TotalTaxeligibleITC;
	@SerializedName("MonthlyITCavailability")
	private int     MonthlyITCavailability;
	@SerializedName("ItcIgstAmt")
	private int      ItcIgstAmt;
	@SerializedName("ItcCgstAmt")
	private int      ItcCgstAmt;
	@SerializedName("ItcSgstAmt")
	private int      ItcSgstAmt;
	@SerializedName("ItcCsgstAmt")
	private int     ItcCsgstAmt;
	@SerializedName("TcIgstAmt")
	private int      TcIgstAmt;
	@SerializedName("TcCgstAmt")
	private int     TcCgstAmt;
	@SerializedName("TcSgstAmt")
	private int     TcSgstAmt;
	@SerializedName("TcCsgstAmt")
	private int     TcCsgstAmt;
	@SerializedName("InwardSuppliesSubjectTTDS")
	private String      InwardSuppliesSubjectTTDS;
	@SerializedName("TDSIGSTrate")
	private int      TDSIGSTrate;
	@SerializedName("TDS_IGST")
	private int     TDS_IGST;
	@SerializedName("TDSGSTrate")
	private int      TDSGSTrate;
	@SerializedName("TDS_SGST")
	private int      TDS_SGST;
	@SerializedName("TDSCGSTrate")
	private int     TDSCGSTrate;
	@SerializedName("TDS_CGST")
	private int     TDS_CGST;
	@SerializedName("TDSUTGSTrate")
	private int      TDSUTGSTrate;
	@SerializedName("TDSUTGST")
	private int      TDSUTGST;
	@SerializedName("TDSCessrate")
	private int      TDSCessrate;
	@SerializedName("TDS_Cess")
	private int     TDS_Cess;
	@SerializedName("CompanyRoadPermitNumber")
	private int     CompanyRoadPermitNumber;
	@SerializedName("CompanyRoadPermitDate")
	private Date      CompanyRoadPermitDate;
	@SerializedName("TransporterName")
	private String      TransporterName;
	@SerializedName("LorryNumber")
	private String      LorryNumber;
	@SerializedName("SupplierRoadPermitNumber")
	private String     SupplierRoadPermitNumber;
	@SerializedName("SuppliersRoadPermitDate")
	private Date      SuppliersRoadPermitDate;
	@SerializedName("PosCd")
	private String      PosCd;
	@SerializedName("RecordType")
	private String      RecordType;
	@SerializedName("TDSType")
	private String      TDSType;
	
	        
	 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getFileID() {
		return fileID;
	}
	public void setFileID(int fileID) {
		this.fileID = fileID;
	}
	public String getReceiverPlantCode() {
		return ReceiverPlantCode;
	}
	public void setReceiverPlantCode(String receiverPlantCode) {
		ReceiverPlantCode = receiverPlantCode;
	}
	public String getTaxPeriod() {
		return TaxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		TaxPeriod = taxPeriod;
	}
	public String getContractNumber() {
		return ContractNumber;
	}
	public void setContractNumber(String contractNumber) {
		ContractNumber = contractNumber;
	}
	public Date getContractdate() {
		return Contractdate;
	}
	public void setContractdate(Date contractdate) {
		Contractdate = contractdate;
	}
	public int getContractValue() {
		return ContractValue;
	}
	public void setContractValue(int contractValue) {
		ContractValue = contractValue;
	}
	public String getDocumentType() {
		return DocumentType;
	}
	public void setDocumentType(String documentType) {
		DocumentType = documentType;
	}
	public String getSupplyType() {
		return SupplyType;
	}
	public void setSupplyType(String supplyType) {
		SupplyType = supplyType;
	}
	public String getDcoumentAttribute() {
		return DcoumentAttribute;
	}
	public void setDcoumentAttribute(String dcoumentAttribute) {
		DcoumentAttribute = dcoumentAttribute;
	}
	public String getCompanyGSTIN() {
		return CompanyGSTIN;
	}
	public void setCompanyGSTIN(String companyGSTIN) {
		CompanyGSTIN = companyGSTIN;
	}
	public String getSupplierGSTIN() {
		return SupplierGSTIN;
	}
	public void setSupplierGSTIN(String supplierGSTIN) {
		SupplierGSTIN = supplierGSTIN;
	}
	public String getSupplierCode() {
		return SupplierCode;
	}
	public void setSupplierCode(String supplierCode) {
		SupplierCode = supplierCode;
	}
	public String getSupplierName() {
		return SupplierName;
	}
	public void setSupplierName(String supplierName) {
		SupplierName = supplierName;
	}
	public String getSupplierAddress() {
		return SupplierAddress;
	}
	public void setSupplierAddress(String supplierAddress) {
		SupplierAddress = supplierAddress;
	}
	public String getImportReportNumber() {
		return ImportReportNumber;
	}
	public void setImportReportNumber(String importReportNumber) {
		ImportReportNumber = importReportNumber;
	}
	public Date getImportReportDate() {
		return ImportReportDate;
	}
	public void setImportReportDate(Date importReportDate) {
		ImportReportDate = importReportDate;
	}
	public String getDocumentNo() {
		return DocumentNo;
	}
	public void setDocumentNo(String documentNo) {
		DocumentNo = documentNo;
	}
	public Date getDocumentDate() {
		return DocumentDate;
	}
	public void setDocumentDate(Date documentDate) {
		DocumentDate = documentDate;
	}
	public String getLineNumber() {
		return LineNumber;
	}
	public void setLineNumber(String lineNumber) {
		LineNumber = lineNumber;
	}
	public String getOriginalDocumentNo() {
		return OriginalDocumentNo;
	}
	public void setOriginalDocumentNo(String originalDocumentNo) {
		OriginalDocumentNo = originalDocumentNo;
	}
	public Date getOriginalDocumentDate() {
		return OriginalDocumentDate;
	}
	public void setOriginalDocumentDate(Date originalDocumentDate) {
		OriginalDocumentDate = originalDocumentDate;
	}
	public String getUnitofMeasurement() {
		return UnitofMeasurement;
	}
	public void setUnitofMeasurement(String unitofMeasurement) {
		UnitofMeasurement = unitofMeasurement;
	}
	public int getBillQty() {
		return BillQty;
	}
	public void setBillQty(int billQty) {
		BillQty = billQty;
	}
	public int getAdvances() {
		return Advances;
	}
	public void setAdvances(int advances) {
		Advances = advances;
	}
	public int getGSTTaxableValue() {
		return GSTTaxableValue;
	}
	public void setGSTTaxableValue(int gSTTaxableValue) {
		GSTTaxableValue = gSTTaxableValue;
	}
	public String getTransactionIDforAdvances() {
		return TransactionIDforAdvances;
	}
	public void setTransactionIDforAdvances(String transactionIDforAdvances) {
		TransactionIDforAdvances = transactionIDforAdvances;
	}
	public char getGoodServices() {
		return GoodServices;
	}
	public void setGoodServices(char goodServices) {
		GoodServices = goodServices;
	}
	public String getHSNSAC() {
		return HSNSAC;
	}
	public void setHSNSAC(String hSNSAC) {
		HSNSAC = hSNSAC;
	}
	public String getItemCode() {
		return ItemCode;
	}
	public void setItemCode(String itemCode) {
		ItemCode = itemCode;
	}
	public String getItemDescription() {
		return ItemDescription;
	}
	public void setItemDescription(String itemDescription) {
		ItemDescription = itemDescription;
	}
	public String getCategoryItem() {
		return CategoryItem;
	}
	public void setCategoryItem(String categoryItem) {
		CategoryItem = categoryItem;
	}
	public int getIGSTRate() {
		return IGSTRate;
	}
	public void setIGSTRate(int iGSTRate) {
		IGSTRate = iGSTRate;
	}
	public int getIGSTAmount() {
		return IGSTAmount;
	}
	public void setIGSTAmount(int iGSTAmount) {
		IGSTAmount = iGSTAmount;
	}
	public int getCGSTRate() {
		return CGSTRate;
	}
	public void setCGSTRate(int cGSTRate) {
		CGSTRate = cGSTRate;
	}
	public int getCGSTAmount() {
		return CGSTAmount;
	}
	public void setCGSTAmount(int cGSTAmount) {
		CGSTAmount = cGSTAmount;
	}
	public int getSGSTRate() {
		return SGSTRate;
	}
	public void setSGSTRate(int sGSTRate) {
		SGSTRate = sGSTRate;
	}
	public int getSGSTAmount() {
		return SGSTAmount;
	}
	public void setSGSTAmount(int sGSTAmount) {
		SGSTAmount = sGSTAmount;
	}
	public int getUTGSTRate() {
		return UTGSTRate;
	}
	public void setUTGSTRate(int uTGSTRate) {
		UTGSTRate = uTGSTRate;
	}
	public int getUTGSTAmount() {
		return UTGSTAmount;
	}
	public void setUTGSTAmount(int uTGSTAmount) {
		UTGSTAmount = uTGSTAmount;
	}
	public int getCessRate() {
		return CessRate;
	}
	public void setCessRate(int cessRate) {
		CessRate = cessRate;
	}
	public int getCessAmount() {
		return CessAmount;
	}
	public void setCessAmount(int cessAmount) {
		CessAmount = cessAmount;
	}
	public int getValueIncludingTax() {
		return ValueIncludingTax;
	}
	public void setValueIncludingTax(int valueIncludingTax) {
		ValueIncludingTax = valueIncludingTax;
	}
	public String getPOS() {
		return POS;
	}
	public void setPOS(String pOS) {
		POS = pOS;
	}
	public char getReverseCharge() {
		return ReverseCharge;
	}
	public void setReverseCharge(char reverseCharge) {
		ReverseCharge = reverseCharge;
	}
	public String getCosumptionType() {
		return CosumptionType;
	}
	public void setCosumptionType(String cosumptionType) {
		CosumptionType = cosumptionType;
	}
	public String getPaymentVoucherNumber() {
		return PaymentVoucherNumber;
	}
	public void setPaymentVoucherNumber(String paymentVoucherNumber) {
		PaymentVoucherNumber = paymentVoucherNumber;
	}
	public Date getDateofPayment() {
		return DateofPayment;
	}
	public void setDateofPayment(Date dateofPayment) {
		DateofPayment = dateofPayment;
	}
	public int getValueOnTDS() {
		return ValueOnTDS;
	}
	public void setValueOnTDS(int valueOnTDS) {
		ValueOnTDS = valueOnTDS;
	}
	public String getGLCodeCapitalGoods() {
		return GLCodeCapitalGoods;
	}
	public void setGLCodeCapitalGoods(String gLCodeCapitalGoods) {
		GLCodeCapitalGoods = gLCodeCapitalGoods;
	}
	public String getCapitalGoodsIdentifier() {
		return CapitalGoodsIdentifier;
	}
	public void setCapitalGoodsIdentifier(String capitalGoodsIdentifier) {
		CapitalGoodsIdentifier = capitalGoodsIdentifier;
	}
	public String getEligibleInput() {
		return EligibleInput;
	}
	public void setEligibleInput(String eligibleInput) {
		EligibleInput = eligibleInput;
	}
	public int getTotalTaxeligibleITC() {
		return TotalTaxeligibleITC;
	}
	public void setTotalTaxeligibleITC(int totalTaxeligibleITC) {
		TotalTaxeligibleITC = totalTaxeligibleITC;
	}
	public int getMonthlyITCavailability() {
		return MonthlyITCavailability;
	}
	public void setMonthlyITCavailability(int monthlyITCavailability) {
		MonthlyITCavailability = monthlyITCavailability;
	}
	public int getItcIgstAmt() {
		return ItcIgstAmt;
	}
	public void setItcIgstAmt(int itcIgstAmt) {
		ItcIgstAmt = itcIgstAmt;
	}
	public int getItcCgstAmt() {
		return ItcCgstAmt;
	}
	public void setItcCgstAmt(int itcCgstAmt) {
		ItcCgstAmt = itcCgstAmt;
	}
	public int getItcSgstAmt() {
		return ItcSgstAmt;
	}
	public void setItcSgstAmt(int itcSgstAmt) {
		ItcSgstAmt = itcSgstAmt;
	}
	public int getItcCsgstAmt() {
		return ItcCsgstAmt;
	}
	public void setItcCsgstAmt(int itcCsgstAmt) {
		ItcCsgstAmt = itcCsgstAmt;
	}
	public int getTcIgstAmt() {
		return TcIgstAmt;
	}
	public void setTcIgstAmt(int tcIgstAmt) {
		TcIgstAmt = tcIgstAmt;
	}
	public int getTcCgstAmt() {
		return TcCgstAmt;
	}
	public void setTcCgstAmt(int tcCgstAmt) {
		TcCgstAmt = tcCgstAmt;
	}
	public int getTcSgstAmt() {
		return TcSgstAmt;
	}
	public void setTcSgstAmt(int tcSgstAmt) {
		TcSgstAmt = tcSgstAmt;
	}
	public int getTcCsgstAmt() {
		return TcCsgstAmt;
	}
	public void setTcCsgstAmt(int tcCsgstAmt) {
		TcCsgstAmt = tcCsgstAmt;
	}
	public String getInwardSuppliesSubjectTTDS() {
		return InwardSuppliesSubjectTTDS;
	}
	public void setInwardSuppliesSubjectTTDS(String inwardSuppliesSubjectTTDS) {
		InwardSuppliesSubjectTTDS = inwardSuppliesSubjectTTDS;
	}
	public int getTDSIGSTrate() {
		return TDSIGSTrate;
	}
	public void setTDSIGSTrate(int tDSIGSTrate) {
		TDSIGSTrate = tDSIGSTrate;
	}
	public int getTDS_IGST() {
		return TDS_IGST;
	}
	public void setTDS_IGST(int tDS_IGST) {
		TDS_IGST = tDS_IGST;
	}
	public int getTDSGSTrate() {
		return TDSGSTrate;
	}
	public void setTDSGSTrate(int tDSGSTrate) {
		TDSGSTrate = tDSGSTrate;
	}
	public int getTDS_SGST() {
		return TDS_SGST;
	}
	public void setTDS_SGST(int tDS_SGST) {
		TDS_SGST = tDS_SGST;
	}
	public int getTDSCGSTrate() {
		return TDSCGSTrate;
	}
	public void setTDSCGSTrate(int tDSCGSTrate) {
		TDSCGSTrate = tDSCGSTrate;
	}
	public int getTDS_CGST() {
		return TDS_CGST;
	}
	public void setTDS_CGST(int tDS_CGST) {
		TDS_CGST = tDS_CGST;
	}
	public int getTDSUTGSTrate() {
		return TDSUTGSTrate;
	}
	public void setTDSUTGSTrate(int tDSUTGSTrate) {
		TDSUTGSTrate = tDSUTGSTrate;
	}
	public int getTDSUTGST() {
		return TDSUTGST;
	}
	public void setTDSUTGST(int tDSUTGST) {
		TDSUTGST = tDSUTGST;
	}
	public int getTDSCessrate() {
		return TDSCessrate;
	}
	public void setTDSCessrate(int tDSCessrate) {
		TDSCessrate = tDSCessrate;
	}
	public int getTDS_Cess() {
		return TDS_Cess;
	}
	public void setTDS_Cess(int tDS_Cess) {
		TDS_Cess = tDS_Cess;
	}
	public int getCompanyRoadPermitNumber() {
		return CompanyRoadPermitNumber;
	}
	public void setCompanyRoadPermitNumber(int companyRoadPermitNumber) {
		CompanyRoadPermitNumber = companyRoadPermitNumber;
	}
	public Date getCompanyRoadPermitDate() {
		return CompanyRoadPermitDate;
	}
	public void setCompanyRoadPermitDate(Date companyRoadPermitDate) {
		CompanyRoadPermitDate = companyRoadPermitDate;
	}
	public String getTransporterName() {
		return TransporterName;
	}
	public void setTransporterName(String transporterName) {
		TransporterName = transporterName;
	}
	public String getLorryNumber() {
		return LorryNumber;
	}
	public void setLorryNumber(String lorryNumber) {
		LorryNumber = lorryNumber;
	}
	public String getSupplierRoadPermitNumber() {
		return SupplierRoadPermitNumber;
	}
	public void setSupplierRoadPermitNumber(String supplierRoadPermitNumber) {
		SupplierRoadPermitNumber = supplierRoadPermitNumber;
	}
	public Date getSuppliersRoadPermitDate() {
		return SuppliersRoadPermitDate;
	}
	public void setSuppliersRoadPermitDate(Date suppliersRoadPermitDate) {
		SuppliersRoadPermitDate = suppliersRoadPermitDate;
	}
	public String getPosCd() {
		return PosCd;
	}
	public void setPosCd(String posCd) {
		PosCd = posCd;
	}
	public String getRecordType() {
		return RecordType;
	}
	public void setRecordType(String recordType) {
		RecordType = recordType;
	}
	public String getTDSType() {
		return TDSType;
	}
	public void setTDSType(String tDSType) {
		TDSType = tDSType;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
	