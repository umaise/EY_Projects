package com.ey.advisory.asp.storm.bolt.gstr7.rulestg1;

import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.dto.InwardInvoiceGstr7DTO;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleService;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleServiceImpl;
import com.ey.advisory.asp.service.gstr7.Gstr7ValidationRuleService;
import com.ey.advisory.asp.service.gstr7.Gstr7ValidationRuleServiceImpl;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;


/**

* @author  Nisha Kumari
* @version 1.0
* @since   17-03-2017
*/
public class TdsRegRuleValidationBolt extends CustomBaseRichBolt{

	private static final long serialVersionUID = 1L;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;
	private Gstr7ValidationRuleService validationRuleService;

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		validationRuleService = new Gstr7ValidationRuleServiceImpl();
	}
	@Override
	public void execute(Tuple input) {
		InwardInvoiceGstr7DTO invoiceDTO = (InwardInvoiceGstr7DTO) input.getValues().get(0);
		try{
			invoiceDTO=validationRuleService.executeLineItemValidationRules(invoiceDTO);
		}
		catch(Exception ex){
			log.error("Error in TDSRegRuleValidationBolt "+ex.getMessage());
			collector.customReportError(input, ex, "Exception in Bolt TDSRegRuleValidationBolt");
		}
		finally {
			collector.ack(input);
			collector.emit(new Values(invoiceDTO));
			log.info("In TDSRegReadBolt.execute() end");
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
	}
}

