package com.ey.advisory.asp.storm.bolt.gstr6.rulestg1;

import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.KSessionUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.storm.bolt.common.BoltBuilder;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

/**

* @author  Nilanjan Karmakar
* @version 1.0
* @since   30-05-2017
*/
public class ISDCatRuleBolt extends BoltBuilder {
	
	private static final long serialVersionUID = 2637535324839911362L;

	private CustomOutputCollector collector;
	
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	private RedisTemplate<String, Object> redisTemplate;
	
	
	/*
	 public ISDCatRuleBolt(Properties configs) {
		super(configs);
	}
	*/

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
	}

	@SuppressWarnings("unchecked")
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		try {
			log.info("In ISDRegReadBolt.prepare() start");
		
			log.info("In ISDRegReadBolt.prepare() ends");

		} catch (Exception ex) {
            log.error(ex.getMessage());
        }
		
		
	}

	@SuppressWarnings({ "unchecked", "unused" })
	@Override
	public void execute(Tuple input) {
		Set<TblIsdErrorInfo> errorList = new HashSet<TblIsdErrorInfo>();
		LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();	
		InwardInvoiceGstr6DTO inwardInvoiceDTO=null;
		try{
			log.info("In IsdRegReadBolt.execute() start");
			
			Gson gson = new Gson();
			
			String invString=input.getString(0);
			Type listType = new TypeToken<InwardInvoiceGstr6DTO>(){}.getType();
			inwardInvoiceDTO=gson.fromJson(invString, listType);
			String groupCode = Utility.getGroupCode(inwardInvoiceDTO.getRedisKey());
			//String groupCode = "ERN00002";
			if(groupCode!=null){
            	log.info("In IsdRegReadBolt.execute() : Group code is : "+groupCode);
            	inwardInvoiceDTO.setGroupCode(groupCode);
            	
            }else{
            	log.info("In IsdRegReadBolt.execute() : Group code not found in REDIS");
            }
			if(inwardInvoiceDTO.getErrorList()!=null){
				 errorList =inwardInvoiceDTO.getErrorList();
				}
			
			InwardInvoiceModel stgTable = inwardInvoiceDTO.getLineItemList().get(0);
			System.out.println("Inv No."+stgTable.getDocumentNo());
			
			KieSession kSession = KSessionUtility.getKSession("rules/GSTR6/GSTR6_Classification.drl");
			
			kSession.insert(stgTable);
			kSession.setGlobal("errorList", errorList);
			
			kSession.fireAllRules();
			kSession.destroy();
			
			if (inwardInvoiceDTO.getInvStatus() == null
					|| inwardInvoiceDTO.getInvStatus().equals(
							Constant.GSTR6_BR_STG1)) {
				inwardInvoiceDTO.setInvStatus(stgTable.getItemStatus());
			}
			
			inwardInvoiceDTO.setErrorList(errorList);
			inwardInvoiceDTO.setTableType(stgTable.getTableType());
			
			log.info("Table Type identification complete:"+ stgTable.getTableType());
			
			log.info("Item Status:"+ stgTable.getItemStatus());
				
			
			
			log.info("In IsdRegReadBolt.execute() end");
		}catch(JsonSyntaxException ex){
			log.error(ex.getMessage());
			collector.customReportError(inwardInvoiceDTO, ex, "Exception in Bolt IsdRegReadBolt");
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}catch(Exception ex1){
			log.error(ex1.getMessage());
			collector.customReportError(inwardInvoiceDTO, ex1, "Exception in Bolt IsdRegReadBolt");
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}
		
		
		finally {
			collector.ack(input);
			if(inwardInvoiceDTO!=null){
			collector.emit(input,new Values(inwardInvoiceDTO));
			}
			else{
				
				collector.emit(new Values(input));
			}
		}
	}
	

}
