package com.ey.advisory.asp.common;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

public class TimeOutAndPersistDBUtil {
	private final static Logger log = LoggerFactory.getLogger(TimeOutAndPersistDBUtil.class);
	private static RedisTemplate<String, Object> redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();
	private static RedisTemplate<String, Integer> redisTemplate1 = JedisConnectionUtil.getRedisTemplateKVStringInteger();//
	private static String TIMEOUT_ROOT= "ASP_TIMEOUT";
	private static String TIMEOUT_ROOT_KEY = "ASP_TIMEOUT_KEY";

	public static void updateLatestDTM(String redisKey) {

		try {
			String updateLatestDTMKey = redisKey + "_" + Constant.INVOICE_UPDATE_TS;

			Map<String, Long> trackerMap = null;
			if (redisTemplate.opsForHash().get(TIMEOUT_ROOT, TIMEOUT_ROOT_KEY) == null) {
				trackerMap = new HashMap<String, Long>();
			} else {
				trackerMap = (Map<String, Long>) redisTemplate.opsForHash().get(TIMEOUT_ROOT, TIMEOUT_ROOT_KEY);

			}
			
			long time = System.currentTimeMillis() / 1000; // Ex : 1501333811
			trackerMap.put(updateLatestDTMKey, time);

			redisTemplate.opsForHash().put(TIMEOUT_ROOT, TIMEOUT_ROOT_KEY, trackerMap);
			redisTemplate.opsForHash().put(redisKey, redisKey+"_GroupCode", "EY");
			redisTemplate1.opsForHash().put(redisKey, redisKey+"_InvCount", new Integer(1));
			if (log.isInfoEnabled())
				log.info("Updating latest timestamp for file > " + updateLatestDTMKey + " : " + time);

			System.out.println(">> "+redisTemplate.opsForHash().get(TIMEOUT_ROOT, TIMEOUT_ROOT_KEY).toString());
		} catch (Exception e) {
			log.error("ERROR in updating timestamp for file > " + redisKey);
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		
		//gstr1_20
		updateLatestDTM("gstr1_20");
		updateLatestDTM("gstr1_21");
		System.out.println("Done!");
	}

}
