package com.ey.advisory.asp.storm.topology.gstr7.rulestg1;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseRichBolt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.redis.mapper.TdsRegRedisCompute;
import com.ey.advisory.asp.storm.bolt.common.GSTR2RedisWSBolt;
import com.ey.advisory.asp.storm.bolt.common.GSTR7RedisWSBolt;
import com.ey.advisory.asp.storm.bolt.common.PublishRedisBolt;
import com.ey.advisory.asp.storm.bolt.gstr7.rulestg1.TdsRegCatRuleBolt;
import com.ey.advisory.asp.storm.bolt.gstr7.rulestg1.TdsRegRuleValidationBolt;
import com.ey.advisory.asp.storm.bolt.gstr7.rulestg1.TdsRegValidationBolt;
import com.ey.advisory.asp.storm.spout.gstr7.rulestg1.TdsRegSpoutBuilder;
import com.ey.advisory.asp.storm.topology.StormTopologyBuilder;

/**

* @author  Nisha Kumari
* @version 1.0
* @since   30-05-2017
*/
public class TdsRegTopologyBuilder extends StormTopologyBuilder{

	private TdsRegSpoutBuilder tdsRegSpoutBuilder;
	private BaseRichBolt tdsRegCatRuleBolt;
	private BaseRichBolt tdsRegRuleValidationBolt;
	private BaseRichBolt tdsRegValidationBolt;
	private GSTR7RedisWSBolt gstr7RedisWSBolt;
	private BaseRichBolt tdsRegRedisCompute;
	private PublishRedisBolt publishRedisBolt;
	
	
	private final Logger log = LoggerFactory.getLogger(getClass());


	public TdsRegTopologyBuilder(Properties configs) {
		super(configs);
		initialize();
	}
	
	private void initialize() {
		tdsRegSpoutBuilder=new TdsRegSpoutBuilder(configs);
		tdsRegCatRuleBolt = new TdsRegCatRuleBolt();
		tdsRegRuleValidationBolt = new TdsRegRuleValidationBolt();
		tdsRegValidationBolt = new TdsRegValidationBolt();
		gstr7RedisWSBolt=new GSTR7RedisWSBolt();
		tdsRegRedisCompute = new TdsRegRedisCompute();
		publishRedisBolt=new PublishRedisBolt();
	}

	@Override
	public void buildDataPipeline(TopologyBuilder builder) {
		log.info("TDSRegTopologyBuilder.setBuilderDataPipeline() starts");
		
		if(builder != null){
			try{
				KafkaSpout tdsRegSpout=tdsRegSpoutBuilder.buildKafkaSpout();

				builder.setSpout(configs.getProperty(Constant.STORM_SPOUT_TDSREG), tdsRegSpout);
				
				builder.setBolt(configs.getProperty(Constant.BOLT_TDSREG_RULE1),tdsRegCatRuleBolt).shuffleGrouping(configs.getProperty(Constant.STORM_SPOUT_TDSREG));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_TDSREG_RULE2),tdsRegValidationBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_TDSREG_RULE1));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_TDSREG_RULE3),tdsRegRuleValidationBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_TDSREG_RULE2));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_GSTR7_REDIS_WS),gstr7RedisWSBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_TDSREG_RULE3));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_TDSCOMPUTE_REDIS),tdsRegRedisCompute).shuffleGrouping(configs.getProperty(Constant.BOLT_GSTR7_REDIS_WS));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_PUBLISH_REDIS),publishRedisBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_TDSCOMPUTE_REDIS));
				
				log.info("TDSRegTopologyBuilder.setBuilderDataPipeline() ends");
			}catch(Exception e){
				log.error("Error Building TDSReg Topology " + e);
			}
	
}
		
}
	}

