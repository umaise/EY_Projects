package com.ey.advisory.asp;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class TestJerseyClient {
	public static void main(String[] args) {
		try {

			Client client = Client.create();

			/*WebResource webResource = client
			   .resource("https://jsonplaceholder.typicode.com/posts/1");
			*/
			/*WebResource webResource = client
					   .resource("https://httpbin.org/get");*/
			WebResource webResource = client
					   .resource("http://INBANVMDCDTFS02.mea.ey.net:8081/receiveData");
			
			
			ClientResponse response = webResource.accept("application/json")
	                   .post(ClientResponse.class);

			if (response.getStatus() != 200) {
			   throw new RuntimeException("Failed : HTTP error code : "
				+ response.getStatus());
			}

			String output = response.getEntity(String.class);

			System.out.println("Output from Server .... \n");
			System.out.println(output);

		  } catch (Exception e) {

			e.printStackTrace();

		  }

		}
}
