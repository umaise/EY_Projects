package com.ey.advisory.asp.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.kie.api.KieBaseConfiguration;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.KnowledgeBaseFactory;
import org.kie.internal.definition.KnowledgePackage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.storm.bolt.gstr1.rulestg1.SaleRegTurnOverRuleBolt;

import clojure.main;

/**
 * This file creates knowledge base from the pre-compiled .drl files 
 * @author Mayank3.Kumar
 *
 */
public class KnowledgeBaseSingleton {
	private final static Logger log = LoggerFactory.getLogger(KnowledgeBaseSingleton.class);
	private static Map<String,KnowledgeBase> kbaseMap = new HashMap<String,KnowledgeBase>();
	
	public static KnowledgeBase getKnowledgeBaseFromSERFile(String serFilePath){
		KnowledgeBase kbase = null;
		
		if(kbaseMap.containsKey(serFilePath)){
			kbase = kbaseMap.get(serFilePath);
		}else{			
			log.info("Initializing KnowledgeBase with SER file : "+serFilePath);
			Collection<KnowledgePackage> knowledgePackages = null;
			KieBaseConfiguration kBaseConfig = KnowledgeBaseFactory.newKnowledgeBaseConfiguration();			
			InputStream fout = SaleRegTurnOverRuleBolt.class.getResourceAsStream(serFilePath);	        
			ObjectInputStream oos;
			try {
				oos = new ObjectInputStream(fout);
				knowledgePackages = (Collection<KnowledgePackage>) oos.readObject();
			} catch (ClassNotFoundException e) {				
				e.printStackTrace();
			} catch (IOException e) {				
				e.printStackTrace();
			}
		
			kbase = KnowledgeBaseFactory.newKnowledgeBase(kBaseConfig);		
			kbase.addKnowledgePackages(knowledgePackages);	
			kbaseMap.put(serFilePath, kbase);
		}
		
		return kbase;
		
	}
	
	public static void main(String[] args) {
		
		KnowledgeBaseSingleton.getKnowledgeBaseFromSERFile("/GSTR1_classification.ser"); 
		KnowledgeBaseSingleton.getKnowledgeBaseFromSERFile("/GSTR1_LineItemValidation.ser"); 
		System.out.println("Done");
		
	}

}
