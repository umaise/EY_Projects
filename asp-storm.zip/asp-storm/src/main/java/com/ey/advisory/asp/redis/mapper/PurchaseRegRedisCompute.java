package com.ey.advisory.asp.redis.mapper;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.redis.bolt.AbstractRedisBolt;
import org.apache.storm.redis.common.config.JedisClusterConfig;
import org.apache.storm.redis.common.config.JedisPoolConfig;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import redis.clients.jedis.JedisCommands;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;

public class PurchaseRegRedisCompute extends CustomBaseRichBolt {
	
/**
	 * 
	 */
private static final long serialVersionUID = 1L;
private final Logger log = LoggerFactory.getLogger(getClass());
private CustomOutputCollector collector;
	
	
	
	@Override
    public void execute(Tuple input) {
		  int count=0;
	        String key="";
        StringBuffer keyGen=new StringBuffer();
        InwardInvoiceModel stgTable=null;
      
        try {
            InwardInvoiceDTO inwardInvoiceDTO = (InwardInvoiceDTO) input.getValue(0);
            
            if(inwardInvoiceDTO!=null && inwardInvoiceDTO.getLineItemList()!=null && !inwardInvoiceDTO.getLineItemList().isEmpty()){
            	stgTable = inwardInvoiceDTO.getLineItemList().get(0);
            	log.info("rediskey : " + inwardInvoiceDTO.getRedisKey() + " InvOrder : "+ stgTable.getInvOrder());
    			
	            if(inwardInvoiceDTO.getInvStatus() !=null && inwardInvoiceDTO.getInvStatus().equalsIgnoreCase(Constant.GSTR2_BR_STG1) ){
					keyGen.append(stgTable.getFileID()).append("~").append(stgTable.getTableType()).append(Constant.PROCESSED_SUCCESS);
				}else{
					keyGen.append(stgTable.getFileID()).append("~").append(stgTable.getTableType()).append(Constant.PROCESSED_ERROR);
				}
            }
            
            key = keyGen.toString().toLowerCase();
            RedisTemplate<String,Object> redisTemplate=JedisConnectionUtil.getRedisTemplateKVStringObject();
            
            if(redisTemplate.opsForHash().get(Constant.REDIS_INVOICE_CHANNEL, key)==null){
            	//map.put(key, Constant.ZERO);
            	redisTemplate.opsForHash().put(Constant.REDIS_INVOICE_CHANNEL,key,Constant.INTIEGER_ZERO);
            	
            }
           else{
            		count=(Integer) redisTemplate.opsForHash().get(Constant.REDIS_INVOICE_CHANNEL,key);
            		//count=Integer.parseInt(countStr)+1;
            		count=count+1;
            		//map.put(key, Integer.toString(count));
            		redisTemplate.opsForHash().put(Constant.REDIS_INVOICE_CHANNEL,key,count);
            	}
        }catch(Exception ex){
        	log.info(ex.getMessage());
        	collector.customReportError(input, ex, "Exception in Bolt PurchaseRegRedisCompute");
        }
        finally {
        	collector.ack(input);
        	this.collector.emit(new Values(key,count));
        	//this.collector.emit(Constant.GSTR2_COMMON_PUBREDIS_Stream,new Values(key,count));
		}
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
    	 declarer.declare(new Fields("tabletype", "count"));
       // declarer.declareStream(Constant.GSTR2_COMMON_PUBREDIS_Stream,new Fields("tabletype", "count"));
    }

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		
		 this.collector=collector;
	}
}
