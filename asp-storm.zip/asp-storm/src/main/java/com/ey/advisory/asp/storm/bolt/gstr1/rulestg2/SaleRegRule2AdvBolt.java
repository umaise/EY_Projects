package com.ey.advisory.asp.storm.bolt.gstr1.rulestg2;

import java.lang.reflect.Type;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

public class SaleRegRule2AdvBolt extends CustomBaseRichBolt {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;

	@Override
	public void prepare(Map stormConf, TopologyContext context,
			CustomOutputCollector collector) {
		this.collector = collector;
	}

	@Override
	public void execute(Tuple input) {
		log.info("In SaleRegRule2AdvBolt.execute() entering");
		OutwardInvoiceDTO updatedInvoice = null;
		try {
			Gson gson = new Gson();
			String invString = input.getString(0);
			OutwardInvoiceDTO invoiceDTO = (OutwardInvoiceDTO) input.getValues().get(0);

			RestClientUtility restClientUtil = new RestClientUtility();
			/* updatedInvoice = restClientUtil.callRestServiceAdv(invString); */
			String groupCode = Utility.getGroupCode(invoiceDTO.getRedisKey());
			ClientResponse response = restClientUtil.getRestServiceResponse(
					Constant.ASP_REST_HOSTNAME, Constant.ASP_REST_ADVTAX,groupCode,
					invString, "POST");
			String output = response.getEntity(String.class);
			Type listType = new TypeToken<OutwardInvoiceDTO>() {
			}.getType();
			updatedInvoice = gson.fromJson(output, listType);

			log.info("In SaleRegRule2AdvBolt.execute() exiting");
		}

		catch (Exception ex) {

			log.error("Error SaleRegRule2AdvBolt" + ex);
			collector.customReportError(updatedInvoice, ex, "Exception in Bolt SaleRegRule2AdvBolt");
		}

		finally {
			collector.ack(input);
			if (updatedInvoice != null)
				collector.emit(new Values(updatedInvoice));
			else {
				Gson gson = new Gson();
				Type listType = new TypeToken<OutwardInvoiceDTO>() {
				}.getType();
				OutwardInvoiceDTO outwardInvoiceDTO = gson.fromJson(
						input.getString(0), listType);
				collector.emit(new Values(outwardInvoiceDTO));
			}

		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
	}

}
