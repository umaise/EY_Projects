package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.ey.advisory.asp.client.domain.InwardInvoiceModelGstr7;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.google.gson.annotations.SerializedName;

public class InwardInvoiceGstr7DTO extends InvoiceDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@SerializedName("gstr7")
	private List<InwardInvoiceModelGstr7> lineItemList;
	private String invStatus;
	private String tableType;
	private Set<TblTdsErrorInfo> errorList;
	private String groupCode;
	public List<InwardInvoiceModelGstr7> getLineItemList() {
		return lineItemList;
	}
	public void setLineItemList(List<InwardInvoiceModelGstr7> lineItemList) {
		this.lineItemList = lineItemList;
	}
	public String getInvStatus() {
		return invStatus;
	}
	public void setInvStatus(String invStatus) {
		this.invStatus = invStatus;
	}
	public String getTableType() {
		return tableType;
	}
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	public Set<TblTdsErrorInfo> getErrorList() {
		return errorList;
	}
	public void setErrorList(Set<TblTdsErrorInfo> errorList) {
		this.errorList = errorList;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}	

}

