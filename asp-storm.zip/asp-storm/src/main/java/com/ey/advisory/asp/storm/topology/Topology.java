package com.ey.advisory.asp.storm.topology;

import java.util.Properties;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.redis.common.config.JedisPoolConfig;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.client.domain.ReconciliationDetailsDTO;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.configs.YamlConfigRunner;
import com.ey.advisory.asp.dto.InvoiceDTO;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.storm.topology.gstr1.gstn.SendGstnTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr1.rulestg1.SaleRegTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr1.rulestg2.SaleRegPipelineTwoTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr2.gstn.SendGstr2GstnTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr2.reconciliation.GSTR2AReconTopologyBuilder;
import com.ey.advisory.asp.storm.topology.gstr2.rulestg1.PurchaseRegTopologyBuilder;


public class Topology {
	
	public Properties configs;
	public JedisPoolConfig jedisPoolConfig;

	
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	public Topology(){
		configs = new Properties();
		try {
			if(log.isInfoEnabled())
			log.info("In Topology constructor start");
			configs.load(Topology.class.getResourceAsStream("/asp-storm-config.properties"));
			//jedisPoolConfig=new RedisConnectionUtil().getJedisPoolConfig();
			if(log.isInfoEnabled())
			log.info("In Topology constructor ends");		
		} catch (Exception ex) {
			ex.printStackTrace();
			//System.exit(0);
		}
	}
	
	private void submitTopology(){
		try{
			if(log.isInfoEnabled())
			log.info("In Topology.submitTopology() start");
			TopologyBuilder builder = new TopologyBuilder();
			
			//creation of spout and bolts for the rulestg1 Data pipeline
			new SaleRegTopologyBuilder(configs).buildDataPipeline(builder);
			new SendGstnTopologyBuilder(configs).buildDataPipeline(builder);
			new SaleRegPipelineTwoTopologyBuilder(configs).buildDataPipeline(builder);
			
			//creation of spout and bolts for the rulestg2 Data pipeline
			new PurchaseRegTopologyBuilder(configs).buildDataPipeline(builder);
			new SendGstr2GstnTopologyBuilder(configs).buildDataPipeline(builder);
			//new GSTR2AReconTopologyBuilder(configs).buildDataPipeline(builder);
			
			// gstr 6 and 7 toplogy
			//new ISDTopologyBuilder(configs).buildDataPipeline(builder);
			//new TdsRegTopologyBuilder(configs).buildDataPipeline(builder);
			
			String topologyName = configs.getProperty(Constant.TOPOLOGY_NAME);
			
			org.apache.storm.Config config = new Config();			
			//User defined YAML conf			
			YamlConfigRunner runner = new YamlConfigRunner();		
			runner.loadRedisConfigsLOCAL(getClass().getResourceAsStream("/storm_redis.yaml"),config);
			runner.loadRESTConfigsLOCAL(getClass().getResourceAsStream("/storm_rest-config.yaml"),config);		
			
			//config.setNumWorkers(2);
			config.setMaxSpoutPending(5000);
			
			config.registerSerialization(OutwardInvoiceModel.class);
			config.registerSerialization(OutwardInvoiceDTO.class);
			
			config.registerSerialization(InwardInvoiceModel.class);
			config.registerSerialization(InwardInvoiceDTO.class);
			config.registerSerialization(InvoiceDTO.class);
		    //config.setDebug(true);
			
			config.registerSerialization(ReconciliationDTO.class);
			config.registerSerialization(ReconciliationDetailsDTO.class);

		    LocalCluster cluster = new LocalCluster();
		    cluster.submitTopology(topologyName,  config, builder.createTopology());
		    
		    //StormSubmitter.submitTopology(topologyName, config, builder.createTopology());
		    
		    if(log.isInfoEnabled())
		    log.info("In Topology.submitTopology() ends");
		    
		}catch (Exception ex) {
			//ex.printStackTrace();
			//System.exit(0);
			if(log.isInfoEnabled())
			log.error("Error Building Topology", ex);
		}
	    
	}
	
	public static void main(String[] args) {
		Topology topology=new Topology();
		DRLSerializer.preCompileDrls("rules/GSTR1/GSTR1_Classification.drl", "GSTR1_classification.ser");		
		DRLSerializer.preCompileDrls("rules/GSTR1/GSTR1_LineItemValidation.drl", "GSTR1_LineItemValidation.ser");
		DRLSerializer.preCompileDrls("rules/GSTR2/GSTR2_Classification.drl", "GSTR2_Classification.ser");
		DRLSerializer.preCompileDrls("rules/GSTR2/GSTR2_LineItemValidation.drl", "GSTR2_LineItemValidation.ser");
		DRLSerializer.preCompileDrls("rules/GSTR2/GSTR2_Reconciliation.drl", "GSTR2_Reconciliation.ser");
		DRLSerializer.preCompileDrls("rules/GSTR2/GSTR2_RuleValidation.drl", "GSTR2_RuleValidation.ser");
		topology.submitTopology();
		/*Properties props = new Properties();
		try {
			props.load(Topology.class.getResourceAsStream("/active-profile.properties"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String profile = props.getProperty("asp-profile-name");
		System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME,profile);*/
		
		//System.out.println(profile);
		/*GenericXmlApplicationContext context = new GenericXmlApplicationContext("/application-context.xml");
		context.getEnvironment().setActiveProfiles("local");*/
		
		//context.getBean(arg0)
		//System.out.println("${asp.topology.mode}");
		
		/*ClassA obj = (ClassA)context.getBean(ClassA.class);
		System.out.println(obj.toString());*/
	}

}
