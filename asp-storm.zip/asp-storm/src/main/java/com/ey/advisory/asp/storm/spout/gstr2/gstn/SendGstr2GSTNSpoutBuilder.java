package com.ey.advisory.asp.storm.spout.gstr2.gstn;

import java.util.Properties;
import java.util.UUID;

import kafka.api.OffsetRequest;

import org.apache.storm.kafka.BrokerHosts;
import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.kafka.SpoutConfig;
import org.apache.storm.kafka.StringScheme;
import org.apache.storm.kafka.ZkHosts;
import org.apache.storm.spout.SchemeAsMultiScheme;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.storm.spout.SpoutBuilder;

/**
 * @author Smruti.Pradhan
 *This Class is used to interfaceToGstn spout configuration
 */
public class SendGstr2GSTNSpoutBuilder extends SpoutBuilder{
	private final Logger log = LoggerFactory.getLogger(getClass());

	public SendGstr2GSTNSpoutBuilder(Properties configs) {
		super(configs);
	}
	
	@Override
	public KafkaSpout buildKafkaSpout() {
		log.info("In SendGstr2GSTNSpoutBuilder.buildKafkaSpout() start");
		BrokerHosts hosts = new ZkHosts(configs.getProperty(Constant.KAFKA_ZOOKEEPER));
		String topic = configs.getProperty(Constant.KAFKA_GSTN_TOPIC_GSTR2);
		String zkRoot =configs.getProperty(Constant.KAFKA_GSTN_GSTR2_ZKROOT);
		SpoutConfig spoutConfig = new SpoutConfig(hosts, topic, zkRoot, UUID.randomUUID().toString());
		spoutConfig.startOffsetTime=OffsetRequest.LatestTime();
		spoutConfig.scheme = new SchemeAsMultiScheme(new StringScheme());
		//spoutConfig.outputStreamId=Constant.GSTR2_Stream2;
		KafkaSpout kafkaSpout = new KafkaSpout(spoutConfig);
		log.info("In SendGstr2GSTNSpoutBuilder.buildKafkaSpout() end");
		return kafkaSpout;
	}

}
