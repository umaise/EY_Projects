package com.ey.advisory.asp.storm.bolt.gstr6.rulestg1;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;



public class ISDRuleBolt extends CustomBaseRichBolt{

	private static final long serialVersionUID = 1L;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
	}

	@Override
	public void execute(Tuple input) {
		InwardInvoiceGstr6DTO inwardInvoiceGstr6DTO = (InwardInvoiceGstr6DTO) input.getValue(0);
		try{
			log.info("In ISDRuleBolt.execute() start");
			Gson gson = new Gson();

			String jsonString = gson.toJson(inwardInvoiceGstr6DTO);
			if(StringUtils.isNotEmpty(inwardInvoiceGstr6DTO.getTableType())){
				ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host", inwardInvoiceGstr6DTO.getTableType(), jsonString,"", Constant.VERB_TYPE_POST);
				
				if(response != null && response.getStatusInfo().getStatusCode() == 200) {
					inwardInvoiceGstr6DTO = gson.fromJson(response.getEntity(String.class), InwardInvoiceGstr6DTO.class);
				}
			}
		}catch(Exception e){
			log.error("Error in ISDRuleBolt ", e);
			collector.customReportError(input, e, "Exception in Bolt ISDRuleBolt");
		}

		finally {
			collector.ack(input);
			collector.emit(new Values(inwardInvoiceGstr6DTO));
			log.info("In ISDRuleBolt.execute() end");
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
	}

}