package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * The persistent class for the tblErrorAction database table.
 * 
 */

public class TblPurchaseErrorInfo implements Serializable {
	private static final long serialVersionUID = 1L;


	private Integer errorInfoID;  
	
	private String processStatus;
	
	private Integer purchaseStagingID;
	
	private String invoiceNum;
	
	private String gstin;
	
	private String errorInfoCode;
	
	private String incidenceLevel;
	
	private String errorColumnName;

	private String errorDesc;
	
	private char isError;
	
	private boolean isProcessed;
	
	private Timestamp createDate;
	
	private String createdBy;

	private Timestamp updatedDate;

	private String invoiceKey;
	
	private String errorColumnId;
	
	private Integer lineNo;
	
	private Integer fileId;
	
	private String taxPeriod;
	
	public TblPurchaseErrorInfo(Integer purchaseStagingID,Integer fileId, String invoiceKey, String errorInfoCode, String errorDesc,String errorColumnId, String errorColumnName,
			String processStatus, boolean isProcessed, String invoiceNum, String gstin,String incidenceLevel, char isError, Integer lineNo, String taxPeriod) {
		this.purchaseStagingID=purchaseStagingID;
		this.errorInfoCode=errorInfoCode;
		this.errorDesc=errorDesc;
		this.errorColumnName=errorColumnName;
		this.processStatus=processStatus;
		this.isProcessed=isProcessed;
		this.invoiceNum = invoiceNum;
		this.gstin = gstin;
		this.incidenceLevel=incidenceLevel;
		this.isError = isError;
		this.errorColumnId=errorColumnId;
		this.fileId=fileId;
		this.invoiceKey = invoiceKey;
		this.lineNo = lineNo;
		this.taxPeriod = taxPeriod;
	}

	public String getInvoiceNum() {
		return this.invoiceNum;
	}

	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}
	
	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	
	public Integer getErrorInfoID() {
		return this.errorInfoID;
	}

	public void setErrorInfoID(Integer errorInfoID) {
		this.errorInfoID = errorInfoID;
	}


	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getErrorColumnName() {
		return this.errorColumnName;
	}

	public void setErrorColumnName(String errorColumnName) {
		this.errorColumnName = errorColumnName;
	}

	public String getErrorDesc() {
		return this.errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getErrorInfoCode() {
		return this.errorInfoCode;
	}

	public void setErrorInfoCode(String errorInfoCode) {
		this.errorInfoCode = errorInfoCode;
	}

	public boolean getIsProcessed() {
		return this.isProcessed;
	}

	public void setIsProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public Integer getPurchaseStagingID() {
		return purchaseStagingID;
	}

	public void setPurchaseStagingID(Integer purchaseStagingID) {
		this.purchaseStagingID = purchaseStagingID;
	}

	public Timestamp getUpdatedDate() {
		return this.updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getIncidenceLevel() {
		return incidenceLevel;
	}

	public void setIncidenceLevel(String incidenceLevel) {
		this.incidenceLevel = incidenceLevel;
	}

	public Timestamp getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

    public char getIsError() {
        return isError;
    }

    public void setIsError(char isError) {
        this.isError = isError;
    }

	public String getErrorColumnId() {
		return errorColumnId;
	}

	public void setErrorColumnId(String errorColumnId) {
		this.errorColumnId = errorColumnId;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public Integer getLineNo() {
		return lineNo;
	}

	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	
}