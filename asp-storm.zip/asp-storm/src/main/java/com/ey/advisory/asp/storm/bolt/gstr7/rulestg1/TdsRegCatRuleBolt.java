package com.ey.advisory.asp.storm.bolt.gstr7.rulestg1;

import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.ey.advisory.asp.client.domain.InwardInvoiceModelGstr7;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.KSessionUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.dto.InwardInvoiceGstr7DTO;
import com.ey.advisory.asp.storm.bolt.common.BoltBuilder;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;


/**

* @author  Nisha Kumari
* @version 1.0
* @since   30-05-2017
*/

public class TdsRegCatRuleBolt extends BoltBuilder {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 482114955637454566L;

	private CustomOutputCollector collector;
	
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	
	/*
	public TdsRegCatRuleBolt(Properties configs) {
		super(configs);
	}*/

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
	}

	@SuppressWarnings("unchecked")
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		try {
			log.info("In TDSRegReadBolt.prepare() start");
			log.info("In TDSRegReadBolt.prepare() ends");

		} catch (Exception ex) {
            log.error(ex.getMessage());
        }
		
		
	}

	@SuppressWarnings({ "unchecked", "unused" })
	@Override
	public void execute(Tuple input) {
		Set<TblTdsErrorInfo> errorList = new HashSet<TblTdsErrorInfo>();
		
		InwardInvoiceGstr7DTO inwardInvoiceDTO=null;
		try{
			log.info("In TdsRegReadBolt.execute() start");
			
			Gson gson = new Gson();
			
			String invString=input.getString(0);
			Type listType = new TypeToken<InwardInvoiceGstr7DTO>(){}.getType();
			inwardInvoiceDTO=gson.fromJson(invString, listType);
			inwardInvoiceDTO.setGroupCode(Utility.getGroupCode(inwardInvoiceDTO.getRedisKey()));
			if(inwardInvoiceDTO.getErrorList()!=null){
				 errorList =inwardInvoiceDTO.getErrorList();
				}
			
			InwardInvoiceModelGstr7 stgTable = inwardInvoiceDTO.getLineItemList().get(0);
			System.out.println("Inv No."+stgTable.getDocumentNo());
			
			KieSession kSession = KSessionUtility.getKSession("rules/GSTR7/GSTR7_Classification.drl");
			
			kSession.insert(stgTable);
			kSession.setGlobal("errorList", errorList);
			
			kSession.fireAllRules();
			kSession.destroy();
			
			if (inwardInvoiceDTO.getInvStatus() == null
					|| inwardInvoiceDTO.getInvStatus().equals(
							Constant.GSTR7_BR_STG1)) {
				inwardInvoiceDTO.setInvStatus(stgTable.getItemStatus());
			}
			
			inwardInvoiceDTO.setErrorList(errorList);
			inwardInvoiceDTO.setTableType(stgTable.getTableType());
			
			log.info("Table Type identification complete:"+ stgTable.getTableType());
			
			log.info("Item Status:"+ stgTable.getItemStatus());
				
			
			
			log.info("In TdsRegReadBolt.execute() end");
		}catch(JsonSyntaxException ex){
			log.error(ex.getMessage());
			collector.customReportError(inwardInvoiceDTO, ex, "Exception in Bolt TdsRegReadBolt");
		}catch(Exception ex1){
			log.error(ex1.getMessage());
			collector.customReportError(inwardInvoiceDTO, ex1, "Exception in Bolt TdsRegReadBolt");
		}
		
		
		finally {
			collector.ack(input);
			if(inwardInvoiceDTO!=null){
			collector.emit(new Values(inwardInvoiceDTO));
			}
			else{
				
				collector.emit(new Values(input));
			}
		}
	}
	

}
