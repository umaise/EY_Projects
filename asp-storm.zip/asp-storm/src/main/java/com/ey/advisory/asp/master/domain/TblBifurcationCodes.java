package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

public class TblBifurcationCodes implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Integer id;
    
    private String returnType;
    
    private String outboundTable;
    
    private String description;
    
    private String Code;
    
    private String value;
    
    private String bifurcationLevel;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getReturnType() {
        return returnType;
    }

    public void setReturnType(String returnType) {
        this.returnType = returnType;
    }

    public String getOutboundTable() {
        return outboundTable;
    }

    public void setOutboundTable(String outboundTable) {
        this.outboundTable = outboundTable;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        Code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getBifurcationLevel() {
        return bifurcationLevel;
    }

    public void setBifurcationLevel(String bifurcationLevel) {
        this.bifurcationLevel = bifurcationLevel;
    }
    

   
    
}