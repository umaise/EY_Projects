package com.ey.advisory.asp.storm.bolt.gstr6.rulestg1;

import java.lang.reflect.Type;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.service.gstr2.CommonValidationRuleService;
import com.ey.advisory.asp.service.gstr2.CommonValidationRuleServiceImpl;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleService;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleServiceImpl;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.ClientResponse;

/**
 * Author -Nilanjan Karmakar
 * @version 1.0
 * @since   30-05-2017
 */

public class ISDRuleValidationBolt extends CustomBaseRichBolt{

	private static final long serialVersionUID = 1L;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;
	private Gstr6ValidationRuleService validationRuleService;
	private CommonValidationRuleService commonValidationRuleService;

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		validationRuleService = new Gstr6ValidationRuleServiceImpl();
		commonValidationRuleService = new CommonValidationRuleServiceImpl();
	}
	@Override
	public void execute(Tuple input) {
		InwardInvoiceGstr6DTO invoiceDTO = (InwardInvoiceGstr6DTO) input.getValues().get(0);
		LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();	
		try{
			invoiceDTO = commonValidationRuleService.executeCommonBusinessRules(invoiceDTO);
			invoiceDTO = validationRuleService.executeGSTR6ITCValidationRules(invoiceDTO);
			String tableType = invoiceDTO.getTableType()  ;
			Gson gson = new Gson();
			//String tableType = Constant.GSTR6_CRDRITCDA ;
			String jsonString = gson.toJson(invoiceDTO);
			if(StringUtils.isNotEmpty(tableType) && tableType.equals(Constant.GSTR6_CRDRITCDA)){
				ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host", "GSTR6_"+tableType, invoiceDTO.getGroupCode(), jsonString, Constant.VERB_TYPE_POST);

				if(response != null && response.getStatusInfo().getStatusCode() == 200){
					String json = response.getEntity(String.class);
					invoiceDTO = gson.fromJson(json, InwardInvoiceGstr6DTO.class);
					log.info("RESPONSE : "+json);
				}else{
					log.error("Error RESPONSE : "+response);
				}

			}
			if(StringUtils.isNotEmpty(tableType) && tableType.equals(Constant.GSTR6_ITCDI)){
				ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host", "GSTR6_"+tableType, invoiceDTO.getGroupCode(), jsonString, Constant.VERB_TYPE_POST);

				if(response != null && response.getStatusInfo().getStatusCode() == 200){
					String json = response.getEntity(String.class);
					invoiceDTO = gson.fromJson(json, InwardInvoiceGstr6DTO.class);
					log.info("RESPONSE : "+json);
				}else{
					log.error("Error RESPONSE : "+response);
				}

			}
		}
		catch(Exception ex){
			log.error("Error in ISDRuleValidationBolt "+ex.getMessage());
			collector.customReportError(input, ex, "Exception in Bolt ISDRuleValidationBolt");
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}
		finally {
			collector.ack(input);
			collector.emit(input,new Values(invoiceDTO));
			//RestClientUtility restClientUtil = new RestClientUtility();
			//restClientUtil.callRestService(validatedInvoiceDTO);
			log.info("In ISDRuleValidationBolt.execute() end");
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
	}
}