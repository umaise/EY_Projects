package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import com.google.gson.annotations.SerializedName;

/**
 * @author  Nilanjan Karmakar
 * @version 1.0
 * @since   06-09-2017
 */
public class TblITCDInvoiceDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	    @SerializedName("ID")
	    private BigInteger id;

	    @SerializedName("FileID")
	    private BigInteger fileID;
	    
	    @SerializedName("GSTIN")
	    private String gstin;
	    
	    @SerializedName("PlantCode")
	    private String plantCode;

		@SerializedName("SourceIdentifier")
	    private String sourceIdentifier;
	    
	    @SerializedName("SourceFileName")
	    private String sourceFileName;
	    
	    @SerializedName("GLAccountCode")
	    private String gLAccountCode;
	    
	    @SerializedName("Division")
	    private String division;

	    @SerializedName("SubDivision")
	    private String subDivision;

	    @SerializedName("TaxPeriod")
	    private String taxPeriod;

	    @SerializedName("DocumentType")
	    private String documentType;

	    @SerializedName("SupplyType")
	    private String supplyType;

	    @SerializedName("DocumentNo")
	    private String documentNo;

	    @SerializedName("DocumentDate")
	    private Object documentDate;

	    @SerializedName("SGSTIN")
	    private String SGSTIN;

	    @SerializedName("SupplierName")
	    private String supplierName;

	    @SerializedName("POS")
	    private String pos;

	    @SerializedName("TaxableValue")
	    private BigDecimal taxableValue;
	    
	    @SerializedName("InvoiceValue")
	    private BigDecimal invoiceValue;

	    @SerializedName("InvoiceKey")
	    private String invoiceKey;

	    @SerializedName("SubCategory")
	    private String subCategory;
	    
	    @SerializedName("Category")
	    private String category;
	    
	    @SerializedName("IsDelete")
	    private boolean isDelete;

	    @SerializedName("TotalEligIGST")
	    private String totalEligIGST;
	    
	    @SerializedName("TotalEligCGST")
	    private String totalEligCGST;
	    
	    @SerializedName("TotalEligSGST")
	    private String totalEligSGST;
	    
	    @SerializedName("TotalEligCess")
	    private String totalEligCess;
	    
	    @SerializedName("TotalInEligIGST")
	    private String totalInEligIGST;
	    
	    @SerializedName("TotalInEligCGST")
	    private String totalInEligCGST;
	    
	    @SerializedName("TotalInEligSGST")
	    private String totalInEligSGST;
	    
	    @SerializedName("TotalInEligCess")
	    private String totalInEligCess;
	    
	    @SerializedName("CreatedDate")
	    private String createdDate;
	    
	    @SerializedName("IsActive")
	    private boolean isActive;

	    @SerializedName("CreatedDt")
	    private String createdDt;

	    @SerializedName("UpdatedDt")
	    private String updatedDt;
	    
	    @SerializedName("UpdatedBy")
	    private String updatedBy;
	    
	    @SerializedName("EligDeterminationID")
	    private String EligDeterminationID;
	    
	    @SerializedName("InEligDeterminationID")
	    private String inEligDeterminationID;
	    
	    @SerializedName("DistributionDate")
	    private String distributionDate;
	    
	    @SerializedName("FirstLineItemID")
	    private String firstLineItemID;
	    
	    
	

        public BigInteger getId() {
            return id;
        }

        public void setId(BigInteger id) {
            this.id = id;
        }

       

        public String getDivision() {
            return division;
        }

        public void setDivision(String division) {
            this.division = division;
        }

        public String getSubDivision() {
            return subDivision;
        }

        public void setSubDivision(String subDivision) {
            this.subDivision = subDivision;
        }

        public String getPlantCode() {
            return plantCode;
        }

        public void setPlantCode(String plantCode) {
            this.plantCode = plantCode;
        }

        public String getTaxPeriod() {
            return taxPeriod;
        }

        public void setTaxPeriod(String taxPeriod) {
            this.taxPeriod = taxPeriod;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }

        public String getSupplyType() {
            return supplyType;
        }

        public void setSupplyType(String supplyType) {
            this.supplyType = supplyType;
        }

        public String getDocumentNo() {
            return documentNo;
        }

        public void setDocumentNo(String documentNo) {
            this.documentNo = documentNo;
        }

        public Object getDocumentDate() {
            return documentDate;
        }

        public void setDocumentDate(Object documentDate) {
            this.documentDate = documentDate;
        }

        public String getSGSTIN() {
            return SGSTIN;
        }

        public void setSGSTIN(String sGSTIN) {
            SGSTIN = sGSTIN;
        }

        public String getSupplierName() {
            return supplierName;
        }

        public void setSupplierName(String supplierName) {
            this.supplierName = supplierName;
        }

        public String getPos() {
            return pos;
        }

        public void setPos(String pos) {
            this.pos = pos;
        }
        public BigDecimal getTaxableValue() {
            return taxableValue;
        }

        public void setTaxableValue(BigDecimal taxableValue) {
            this.taxableValue = taxableValue;
        }

        public BigDecimal getInvoiceValue() {
            return invoiceValue;
        }

        public void setInvoiceValue(BigDecimal invoiceValue) {
            this.invoiceValue = invoiceValue;
        }

        public String getInvoiceKey() {
            return invoiceKey;
        }

        public void setInvoiceKey(String invoiceKey) {
            this.invoiceKey = invoiceKey;
        }

        public String getSubCategory() {
            return subCategory;
        }

        public void setSubCategory(String subCategory) {
            this.subCategory = subCategory;
        }

        public String getSourceIdentifier() {
            return sourceIdentifier;
        }

        public void setSourceIdentifier(String sourceIdentifier) {
            this.sourceIdentifier = sourceIdentifier;
        }

        public String getSourceFileName() {
            return sourceFileName;
        }
        
        public BigInteger getFileID() {
			return fileID;
		}

		public void setFileID(BigInteger fileID) {
			this.fileID = fileID;
		}

		public void setSourceFileName(String sourceFileName) {
            this.sourceFileName = sourceFileName;
        }

        public String getgLAccountCode() {
            return gLAccountCode;
        }

        public void setgLAccountCode(String gLAccountCode) {
            this.gLAccountCode = gLAccountCode;
        }

      

		public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}

		public boolean getIsDelete() {
			return isDelete;
		}

		public void setIsDelete(boolean isDelete) {
			this.isDelete = isDelete;
		}

		public String getTotalEligIGST() {
			return totalEligIGST;
		}

		public void setTotalEligIGST(String totalEligIGST) {
			this.totalEligIGST = totalEligIGST;
		}

		public String getTotalEligCGST() {
			return totalEligCGST;
		}

		public void setTotalEligCGST(String totalEligCGST) {
			this.totalEligCGST = totalEligCGST;
		}

		public String getTotalEligSGST() {
			return totalEligSGST;
		}

		public void setTotalEligSGST(String totalEligSGST) {
			this.totalEligSGST = totalEligSGST;
		}

		public String getTotalEligCess() {
			return totalEligCess;
		}

		public void setTotalEligCess(String totalEligCess) {
			this.totalEligCess = totalEligCess;
		}

		public String getTotalInEligIGST() {
			return totalInEligIGST;
		}

		public void setTotalInEligIGST(String totalInEligIGST) {
			this.totalInEligIGST = totalInEligIGST;
		}

		public String getTotalInEligCGST() {
			return totalInEligCGST;
		}

		public void setTotalInEligCGST(String totalInEligCGST) {
			this.totalInEligCGST = totalInEligCGST;
		}

		public String getTotalInEligSGST() {
			return totalInEligSGST;
		}

		public void setTotalInEligSGST(String totalInEligSGST) {
			this.totalInEligSGST = totalInEligSGST;
		}

		public String getTotalInEligCess() {
			return totalInEligCess;
		}

		public void setTotalInEligCess(String totalInEligCess) {
			this.totalInEligCess = totalInEligCess;
		}

		public String getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}

		public boolean getIsActive() {
			return isActive;
		}

		public void setIsActive(boolean isActive) {
			this.isActive = isActive;
		}

		public String getCreatedDt() {
			return createdDt;
		}

		public void setCreatedDt(String createdDt) {
			this.createdDt = createdDt;
		}

		public String getUpdatedDt() {
			return updatedDt;
		}

		public void setUpdatedDt(String updatedDt) {
			this.updatedDt = updatedDt;
		}

		public String getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(String updatedBy) {
			this.updatedBy = updatedBy;
		}

		public String getEligDeterminationID() {
			return EligDeterminationID;
		}

		public void setEligDeterminationID(String eligDeterminationID) {
			EligDeterminationID = eligDeterminationID;
		}

		public String getInEligDeterminationID() {
			return inEligDeterminationID;
		}

		public void setInEligDeterminationID(String inEligDeterminationID) {
			this.inEligDeterminationID = inEligDeterminationID;
		}

		public String getDistributionDate() {
			return distributionDate;
		}

		public void setDistributionDate(String distributionDate) {
			this.distributionDate = distributionDate;
		}

		public String getFirstLineItemID() {
			return firstLineItemID;
		}

		public void setFirstLineItemID(String firstLineItemID) {
			this.firstLineItemID = firstLineItemID;
		}

		public String getGstin() {
			return gstin;
		}

		public void setGstin(String gstin) {
			this.gstin = gstin;
		}

		public void setDelete(boolean isDelete) {
			this.isDelete = isDelete;
		}

		public void setActive(boolean isActive) {
			this.isActive = isActive;
		}

		
	
}

