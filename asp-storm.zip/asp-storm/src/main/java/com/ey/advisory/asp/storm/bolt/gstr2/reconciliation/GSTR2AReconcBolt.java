package com.ey.advisory.asp.storm.bolt.gstr2.reconciliation;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.runtime.KieSession;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.KnowledgeBaseFactory;
import org.kie.internal.definition.KnowledgePackage;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.client.domain.ReconciliationDetailsDTO;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.KSessionUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

/**

* @author  Siddharth Pahuja
* @version 1.0
* @since   13-04-2017
*/

public class GSTR2AReconcBolt extends CustomBaseRichBolt {

	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;
	
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		
	}

	@Override
	public void execute(Tuple input) {
		log.info("In GSTR2AReconcBolt.execute() start");
		Double purchaseRegisterTaxAmount = Constant.ZERO_DOUBLE;
		Double gstr2aTaxAmount = Constant.ZERO_DOUBLE;
		Double itcAmount = Constant.ZERO_DOUBLE;
		
		Set<TblPurchaseErrorInfo> reconErrorList = new HashSet<TblPurchaseErrorInfo>();
		
		Gson gson = new Gson();
		String invString=input.getString(0);
		Type listType = new TypeToken<ReconciliationDTO>(){}.getType();
		log.info("Priniting recon JSON String " + input.getString(0));
		ReconciliationDTO reconciliationDTO = new ReconciliationDTO();
		try{
			reconciliationDTO = gson.fromJson(invString, listType);
			reconciliationDTO.setGroupCode(Utility.getGroupCode(reconciliationDTO.getRedisKey()));
		
		if(!reconciliationDTO.getTableKey().substring(reconciliationDTO.getTableKey().indexOf("_")+1).equalsIgnoreCase(Constant.RECON_TYPE_MATCHED)){
			if(!reconciliationDTO.getTableKey().substring(reconciliationDTO.getTableKey().indexOf("_")+1).equalsIgnoreCase(Constant.RECON_TYPE_MISSING) && 
					!reconciliationDTO.getTableKey().substring(reconciliationDTO.getTableKey().indexOf("_")+1).equalsIgnoreCase(Constant.RECON_TYPE_ADDITIONAL)){
				
				if(reconciliationDTO.getPurchaseRegister() != null && !reconciliationDTO.getPurchaseRegister().isEmpty()){
					/*for(ReconciliationDetailsDTO detail : reconciliationDTO.getPurchaseRegister()){
					purchaseRegisterTaxAmount = purchaseRegisterTaxAmount + (detail.getIgstAmt() != null ? detail.getIgstAmt() : Constant.ZERO_DOUBLE) + (detail.getSgstAmt() != null ? detail.getSgstAmt() : Constant.ZERO_DOUBLE)
							+ (detail.getCgstAmt() != null ? detail.getCgstAmt() : Constant.ZERO_DOUBLE) + (detail.getCessAmt() != null ? detail.getCessAmt() : Constant.ZERO_DOUBLE);
					
					itcAmount = itcAmount + (detail.getItcIgstAmt() != null ? detail.getItcIgstAmt() : Constant.ZERO_DOUBLE) + (detail.getItcSgstAmt() != null ? detail.getItcSgstAmt() : Constant.ZERO_DOUBLE)
							+ (detail.getItcCgstAmt() != null ? detail.getItcCgstAmt() : Constant.ZERO_DOUBLE) + (detail.getItcCessAmt() != null ? detail.getItcCessAmt() : Constant.ZERO_DOUBLE);
					}*/
					purchaseRegisterTaxAmount = reconciliationDTO.getPurchaseRegister().get(0).getTotalTax();
				}
				
				if(reconciliationDTO.getGstr2A() != null && !reconciliationDTO.getGstr2A().isEmpty()){
					/*for(ReconciliationDetailsDTO detail : reconciliationDTO.getGstr2A()){
						gstr2aTaxAmount = gstr2aTaxAmount + (detail.getIgstAmt() != null ? detail.getIgstAmt() : Constant.ZERO_DOUBLE) + (detail.getSgstAmt() != null ? detail.getSgstAmt() : Constant.ZERO_DOUBLE)
								+ (detail.getCgstAmt() != null ? detail.getCgstAmt() : Constant.ZERO_DOUBLE) + (detail.getCessAmt() != null ? detail.getCessAmt() : Constant.ZERO_DOUBLE);
						
						itcAmount = itcAmount + (detail.getItcIgstAmt() != null ? detail.getItcIgstAmt() : Constant.ZERO_DOUBLE) + (detail.getItcSgstAmt() != null ? detail.getItcSgstAmt() : Constant.ZERO_DOUBLE)
								+ (detail.getItcCgstAmt() != null ? detail.getItcCgstAmt() : Constant.ZERO_DOUBLE) + (detail.getItcCessAmt() != null ? detail.getItcCessAmt() : Constant.ZERO_DOUBLE);
						}*/
					gstr2aTaxAmount = reconciliationDTO.getGstr2A().get(0).getTotalTax();
				}
				
				
			}
			reconciliationDTO.setPurchaseRegisterTaxAmount(purchaseRegisterTaxAmount);
			reconciliationDTO.setGstr2aTaxAmount(gstr2aTaxAmount);
			//reconciliationDTO.setTotalITCAmount(itcAmount);
			
			FileInputStream fout = new FileInputStream("GSTR2_Reconciliation.ser");
			ObjectInputStream oos = new ObjectInputStream(fout);
			
			Collection<KnowledgePackage> knowledgePackages = (Collection<KnowledgePackage>) oos.readObject();
			KieBaseConfiguration kBaseConfig = KnowledgeBaseFactory.newKnowledgeBaseConfiguration();
			KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase(kBaseConfig);
			kbase.addKnowledgePackages(knowledgePackages);
			StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
			
			ksession.insert(reconciliationDTO);
			ksession.setGlobal("reconErrorList", reconErrorList);
			ksession.fireAllRules();
			ksession.destroy();
			
			
		}else if(reconciliationDTO.getTableKey().substring(reconciliationDTO.getTableKey().indexOf("_")+1).equalsIgnoreCase(Constant.RECON_TYPE_MATCHED)){
			reconciliationDTO.setFilingStatus(Constant.RECON_STATUS_ACCEPTED);
		}
		reconciliationDTO.setErrorList(reconErrorList);
		}catch(Exception e){
			log.error("error Reconciling GSTR2a Data", e);
			//collector.customReportError(reconciliationDTO, e, "Exception in Bolt GSTR2AReconcBolt");
		}finally{
			collector.ack(input);
			collector.emit(new Values(reconciliationDTO));
			//collector.emit(Constant.GSTR2_Stream3,new Values(reconciliationDTO));
		
			log.info("In GSTR2AReconBolt.execute() end");
		}
		
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR2_Stream3,new Fields("inv"));
		
	}
	
	

}
