package com.ey.advisory.asp.storm.spout.gstr6.reconciliation;

import java.util.Properties;
import java.util.UUID;

import org.apache.storm.kafka.BrokerHosts;
import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.kafka.SpoutConfig;
import org.apache.storm.kafka.StringScheme;
import org.apache.storm.kafka.ZkHosts;
import org.apache.storm.spout.SchemeAsMultiScheme;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.storm.spout.SpoutBuilder;

import kafka.api.OffsetRequest;

public class GSTR6AReconSpoutBuilder extends SpoutBuilder{
	
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	public GSTR6AReconSpoutBuilder(Properties configs) {
		super(configs);
	}

	@Override
	public KafkaSpout buildKafkaSpout() {
		log.info("In GSTR6AReconSpoutBuilder.buildKafkaSpout() start");
		BrokerHosts hosts = new ZkHosts(configs.getProperty(Constant.KAFKA_ZOOKEEPER));
		String topic = configs.getProperty(Constant.KAFKA_TOPIC_GSTR6A_RECON);
		String zkRoot = configs.getProperty(Constant.KAFKA_GSTR6A_RECON_ZKROOT);
		SpoutConfig spoutConfig = new SpoutConfig(hosts, topic, zkRoot, UUID.randomUUID().toString());
		spoutConfig.startOffsetTime=OffsetRequest.LatestTime();
		spoutConfig.scheme = new SchemeAsMultiScheme(new StringScheme());
		KafkaSpout kafkaSpout = new KafkaSpout(spoutConfig);
		log.info("In GSTR6AReconSpoutBuilder.buildKafkaSpout() end");
		return kafkaSpout;
	}
	
	

}
