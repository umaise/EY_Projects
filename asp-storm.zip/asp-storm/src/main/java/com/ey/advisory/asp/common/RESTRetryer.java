package com.ey.advisory.asp.common;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.exceptions.RESTCallFailureException;

class RESTRetryer implements Callable<Boolean> {

	private final Logger log = LoggerFactory.getLogger(getClass());
	private HttpURLConnection conn;
	private String redisInvoiceKey;

	public RESTRetryer(HttpURLConnection conn, String redisInvoiceKey) {
		this.conn = conn;
		this.redisInvoiceKey = redisInvoiceKey;
	}

	  @Override
	  public Boolean call() throws Exception {
		  
		    OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(redisInvoiceKey);
			out.flush();
			
			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED && conn.getResponseCode() != HttpURLConnection.HTTP_OK  ) {
				log.info("Failed : HTTP error code : "+ conn.getResponseCode());	
				// Send e-Mail notification for FAILED server status				
				throw new RESTCallFailureException("Failed : HTTP error code");
			}else{
				// Send e-Mail notification for SUCCESS server status
				log.info("Success : HTTP code : " + conn.getResponseCode());
			}
			
	return true;
}}
