package com.ey.advisory.asp.common;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message.Level;
import org.kie.api.io.Resource;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KSessionUtility {
	private static final Logger LOG = LoggerFactory.getLogger(KSessionUtility.class);
	
	public static KieSession getKSession(String drlFilePath){
		KieServices ks = KieServices.Factory.get();
		KieFileSystem kfs = ks.newKieFileSystem();
		Resource resourceRuleflow = ks
				.getResources()
				.newClassPathResource(drlFilePath)
				//.newFileSystemResource(drlFilePath)
				.setResourceType(ResourceType.DRL);
		kfs.write(resourceRuleflow);
		KieBuilder kieBuilder = ks.newKieBuilder(kfs).buildAll();
		if (kieBuilder.getResults().hasMessages(Level.ERROR)) {
			LOG.error("Error while building kbase ",kieBuilder.getResults().getMessages());
		}
		KieContainer kieContainer = ks.newKieContainer(ks.getRepository()
				.getDefaultReleaseId());
		return(kieContainer.newKieSession());
		
	}
	
	
	public static KieSession getSessionForPreCompiled(String fileName){
		KieServices kieServices = KieServices.Factory.get();
		KieFileSystem kfs = kieServices.newKieFileSystem();
		Resource resource = kieServices.getResources().newFileSystemResource(fileName);
		kfs.write(resource);
		KieContainer kieContainer = kieServices.newKieContainer(kieServices.getRepository()
				.getDefaultReleaseId());
		/*KieBase kBase = kieContainer.newKieBase(kBaseConfig);
		KieContainer kieContainer = kfs.newKieContainer(kieServices.getRepository()
				.getDefaultReleaseId());
		kieContainer.newKieSession();*/
		KieBuilder kieBuilder = kieServices.newKieBuilder(kfs);
		KieContainer kContainer = kieServices.newKieContainer(kieServices.getRepository()
				.getDefaultReleaseId());
		return kContainer.newKieSession();
		
	}

}
