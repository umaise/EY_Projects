package com.ey.advisory.asp.common;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.dto.EntityModelDTO;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.dto.AnswerModuleDTO;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.jersey.api.client.ClientResponse;

/**
 * Utility for common methods. 
 *
 * @author  Siddharth Pahuja
 * @version 1.0
 * @since   03-03-2017
 */

public class Utility {
    private static final Logger log = LoggerFactory.getLogger(Utility.class);

//    private static List<SimpleDateFormat> patternList; 
//
//    static {
//        patternList = new ArrayList<SimpleDateFormat>();
//        patternList.add(new SimpleDateFormat("yyyy-MM-dd"));
//        patternList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"));
//        patternList.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
//        patternList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"));
//        patternList.add(new SimpleDateFormat("MMyyyy"));
//        patternList.add(new SimpleDateFormat("MM.yyyy"));
//        patternList.add(new SimpleDateFormat("MM-yyyy"));
//    }
	private static final ThreadLocal<Map<String, SimpleDateFormat>> myThreadLocal = new ThreadLocal<Map<String, SimpleDateFormat>>() {
	};
	public static void initValues() {
		Map<String, SimpleDateFormat> mapDatePatterns = new HashMap<String, SimpleDateFormat>();
		mapDatePatterns.put("yyyy-MM-dd",new SimpleDateFormat("yyyy-MM-dd"));
		mapDatePatterns.put("yyyy-MM-dd'T'HH:mm:ss", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"));
		mapDatePatterns.put("yyyy-MM-dd HH:mm:ss",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		mapDatePatterns.put("yyyy-MM-dd'T'HH:mm:ss'Z'",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"));
		mapDatePatterns.put("MMyyyy",new SimpleDateFormat("MMyyyy"));
		mapDatePatterns.put("MM.yyyy",new SimpleDateFormat("MM.yyyy"));
		mapDatePatterns.put("MM-yyyy",new SimpleDateFormat("MM-yyyy"));
		
		mapDatePatterns.put("yyyy-MM-ddTHH:mm:ss", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")); //for 2017-09-19T00:00:00
		mapDatePatterns.put("yyyy-MM-ddTHH:mm:ss'Z'",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"));
		myThreadLocal.set(mapDatePatterns);
	}

    public static <T> Iterable<T> nullSafeList(Iterable<T> inputList){

        return inputList == null ? Collections.<T>emptyList() : inputList;

    }

    public static Date convertStringToDate(final String pattern, final String dateString) throws ParseException{

        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.parse(dateString);
    }


    public static String convertDateToString(String pattern, Date date){

        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(date);

    }

//    public static Date getDateByPattern(String dateStr) {
//
//        for(SimpleDateFormat sdf : patternList){
//            try{
//                if(dateStr != null && !dateStr.isEmpty()){
//                    return sdf.parse(dateStr);
//                }
//            }catch(ParseException pe){
//
//            }
//        }
//        throw new RuntimeException("Unknown Date Format for " + dateStr);
//    }

	public static Date getDateByPattern(String dateStr) {
		Boolean bflag = true;
		Map<String, SimpleDateFormat> patternMap = myThreadLocal.get();
		if (patternMap == null || patternMap.isEmpty()) {
				initValues();	
				patternMap = myThreadLocal.get();
		}
		for (String key : patternMap.keySet()) {
			if (dateStr.length() == key.length()) {
				try {
					return patternMap.get(key).parse(dateStr);
				} catch (ParseException parseException) {
					if(log.isWarnEnabled()){
						log.warn("KEY : "+key);
						log.warn(parseException.getMessage(), parseException);
					}
				}
			}
		}
		throw new RuntimeException("Unknown Date Format for " + dateStr);
	}
    public static String getGroupCode(String redisKey){
        RedisTemplate<String, String> redisTemplateString = JedisConnectionUtil.getRedisTemplateKVStringString();
        String groupCodeKey=redisKey+"_"+Constant.GROUP_CODE;
        String groupCode = (String) redisTemplateString.opsForValue().get( groupCodeKey);
        return groupCode;	

    }

    @SuppressWarnings("unchecked")
    public static Map<String, AnswerModuleDTO> getClientOnBoardingDetailFromRedis(String PAN, String groupCode) {

    	log.info("Utilty.getClientOnBoardingDetailFromRedis starts..");
        Map<String, Map<String, AnswerModuleDTO>> questionAnswerMappingMap = new HashMap<String, Map<String, AnswerModuleDTO>>();
        Map<String, AnswerModuleDTO> clientData = new HashMap<String, AnswerModuleDTO>();
        
        RedisTemplate<String, Object> redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();

        questionAnswerMappingMap = (Map<String, Map<String, AnswerModuleDTO>>) redisTemplate.opsForHash()
            .get(groupCode+"_"+Constant.REDIS_CACHE, Constant.QUESTION_ANSWER_MAPPING);

        if(questionAnswerMappingMap!=null) {
            clientData = questionAnswerMappingMap.get(PAN);
        } 
        
        if(questionAnswerMappingMap==null || clientData == null) {        

        	log.info("Calling loadClientOnBoardingInfo() to get client data for PAN : "+ PAN);
            ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
                Constant.CLIENT_ON_BOARDING_INFO, groupCode, PAN, Constant.VERB_TYPE_POST);

            if (response!=null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
                questionAnswerMappingMap = (Map<String, Map<String, AnswerModuleDTO>>) redisTemplate.opsForHash()
                    .get(groupCode+"_"+Constant.REDIS_CACHE, Constant.QUESTION_ANSWER_MAPPING);
                
                if(questionAnswerMappingMap!=null) {
                	clientData = questionAnswerMappingMap.get(PAN);
                }
                log.info("client data : " + clientData);
            }
        }
        
        log.info("Utilty.getClientOnBoardingDetailFromRedis ends..");
        return clientData;
    }
    
    public static boolean isPreviousTaxPeriod(Object documentDate, String taxPeriod){
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        
        cal1.setTime(getDateByPattern(documentDate.toString()));
        cal2.setTime(getDateByPattern(taxPeriod));
        
        cal1.set(Calendar.DATE, 1);
        
        if(cal1.before(cal2)){
               return true;
        }
        
        return false;
     }
    

    public static boolean checkAggInvoiceThreshold(OutwardInvoiceModel outwardInvoiceModel, int value) {
    	
    	BigDecimal aggInvoiceValue = outwardInvoiceModel.getAggInvoice();
    	if(Constant.CR.equalsIgnoreCase(outwardInvoiceModel.getDocumentType()) && aggInvoiceValue!=null) {
    		aggInvoiceValue = outwardInvoiceModel.getAggInvoice().abs();
    	}

        BigDecimal aggInvoice =  aggInvoiceValue==null? new BigDecimal(0): aggInvoiceValue;
        
        return (aggInvoice.compareTo(new BigDecimal(value)) > 0);
    }

    public static boolean isPreviousCutoffDate(String taxPeriod, String cutoffDate) {

    	Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        
        cal1.setTime(getDateByPattern(taxPeriod));
        cal2.setTime(getDateByPattern(cutoffDate));
        
        
        if((cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR)) && (cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH) || cal1.get(Calendar.MONTH) < cal2.get(Calendar.MONTH))){
        	return true;
        }
        
        return false;
    }

    public static boolean isValidReturnPeriod(String taxPeriod, String cutoffDate) {

    	Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        
        cal1.setTime(getDateByPattern(taxPeriod));
        cal2.setTime(getDateByPattern(cutoffDate));
        
        log.info("taxPeriod : " + taxPeriod + " cutoffDate : "+cutoffDate);
        
        if(cal1.before(cal2)){
        	log.info("dt1 : " + cal1 + "is before cutoffDate dt2 : "+cal2 + ".. ErrorCode logged");
        	return true;
        }
        
        return false;
    }

    
    public static boolean isValidDocumentDate(String taxPeriod, Object docDate) {

    	Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        
        cal1.setTime(getDateByPattern(taxPeriod));
        cal1.add(Calendar.MONTH, 1);
        cal1.get(Calendar.MONTH);
        cal2.setTime(getDateByPattern(docDate.toString()));
        
        log.info("taxPeriod : " + taxPeriod + " docDate : "+docDate);
        
        if(cal1.compareTo(cal2) <= 0){
        	log.info("dt1 : " + cal1 + "is before cutoffDate dt2 : "+cal2 + ".. ErrorCode logged");
        	return true;
        }
        
        return false;
    }
    
    public static String getFY(Object object) {
        String fy = null;
        if(object != null){
            Calendar cal = Calendar.getInstance();
            SimpleDateFormat dateFormat = new SimpleDateFormat(Constant.DATE_FORMAT);
            Date date=null;
            try {
				 date = dateFormat.parse(object.toString());
			} catch (ParseException e) {
				log.error("exception in  date parsing ", e);
			}
           // cal.setTime((Date) object);
            cal.setTime(date);
            int month = cal.get(Calendar.MONTH);
            int year = cal.get(Calendar.YEAR);
                     
            if(month < Calendar.APRIL){
                fy = String.valueOf(year - 1)+String.valueOf(year);
            }else{
                fy = String.valueOf(year)+String.valueOf(year+1);
            }
                       
        }
        return fy;
    }
    
	public static Set<Double> converBigDecimalToDouble(Set<BigDecimal> ratesList) {
		Set<Double> ratesListInDouble = new HashSet<Double>();
		
		for (BigDecimal rate : ratesList) {
			ratesListInDouble.add(rate.doubleValue());
		}
		return ratesListInDouble;
	}
	
	@SuppressWarnings("unchecked")
	public static BigDecimal getGrossTurnover(String gstin, RedisTemplate<String, Object> redisTemplate, String groupCode) {
		
		String pan = gstin.substring(2, 12);
		BigDecimal grossTurnover = new BigDecimal(0.00);
		EntityModelDTO entityModelTable = null;
		RestClientUtility restClientUtil = new RestClientUtility();
		Map<String, EntityModelDTO> entityMap = null;
		
		entityMap = (Map<String, EntityModelDTO>) redisTemplate.opsForHash()
				.get(groupCode+"_"+Constant.REDIS_CACHE, Constant.ENTITY_KEY);
		
		if(entityMap == null) {
			ClientResponse response = restClientUtil
					.getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
							"asp-restapi.loadEntityDet", groupCode, null,
							Constant.VERB_TYPE_POST);
			if (response!=null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
				entityMap = (Map<String, EntityModelDTO>) redisTemplate.opsForHash()
						.get(groupCode+"_"+Constant.REDIS_CACHE, Constant.ENTITY_KEY);
			}
		} 
		
		if(entityMap !=null && !entityMap.isEmpty()) {
			entityModelTable = entityMap.get(pan);
		}
		
		if (entityModelTable == null) {
			log.info("Client : " + pan + " not found in EntityMap, fetching details from DB");
			ClientResponse response = restClientUtil
					.getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
							"asp-restapi.getEntity", groupCode, pan,
							Constant.VERB_TYPE_POST);
			Gson gson = new GsonBuilder().setDateFormat(Constant.DATE_FORMAT).create(); 
			if (response!=null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
				entityModelTable = gson
						.fromJson(response.getEntity(String.class),
								EntityModelDTO.class);
				if(entityModelTable!=null)
					grossTurnover = entityModelTable.getGrossTurnOver();
			}
		} else {
			grossTurnover = entityModelTable.getGrossTurnOver();
		}
		return grossTurnover;
	}
	
	public static boolean isB2CLInvoice(OutwardInvoiceModel lineItem, String groupCode) {
		if(!Constant.Y.equalsIgnoreCase(lineItem.getcRDRPreGST())) {
			RestClientUtility restClientUtil = new RestClientUtility();
			Gson gson = new Gson();
			String jsonString = gson.toJson(lineItem);
			
			ClientResponse response = restClientUtil.getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.IS_B2CL_INVOICE , groupCode, jsonString, Constant.VERB_TYPE_POST);
	
			if(response != null && response.getStatusInfo().getStatusCode() == 200){
				String result = response.getEntity(String.class);
				return Constant.TRUE.equalsIgnoreCase(result);
			}
			log.error("Error calling rest service isB2CLInvoice... StatusCode : " + response);
		}
		return Boolean.FALSE;
	}
	
	public static String isB2CLEAInvoice(OutwardInvoiceModel lineItem, String groupCode) {
		if(!Constant.Y.equalsIgnoreCase(lineItem.getcRDRPreGST())) {
			RestClientUtility restClientUtil = new RestClientUtility();
			Gson gson = new Gson();
			String jsonString = gson.toJson(lineItem);
			
			String response = restClientUtil.getRestServiceResponseB2CLEA(Constant.ASP_REST_HOSTNAME, Constant.IS_B2CLEA_INVOICE , groupCode, jsonString, Constant.VERB_TYPE_POST);
	
			if(response != null ){
				return response;
			}
			log.error("Error calling rest service isB2CLEAInvoice... StatusCode : " + response);
		}
		return null;
	}
	
}
