package com.ey.advisory.asp.storm.topology.gstr2.reconciliation;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseRichBolt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.storm.bolt.common.GSTR2AReconRedisWSBolt;
import com.ey.advisory.asp.storm.bolt.gstr2.reconciliation.GSTR2ITCBolt;
import com.ey.advisory.asp.storm.bolt.gstr2.reconciliation.GSTR2AReconcBolt;
import com.ey.advisory.asp.storm.spout.gstr2.reconciliation.GSTR2AReconSpoutBuilder;
import com.ey.advisory.asp.storm.topology.StormTopologyBuilder;

public class GSTR2AReconTopologyBuilder extends StormTopologyBuilder {

	private final Logger log = LoggerFactory.getLogger(getClass());
	
	private GSTR2AReconSpoutBuilder gstr2aReconSpoutBuilder;
	private BaseRichBolt gstr2aReconBolt;	
	private BaseRichBolt gstr2ItcBolt;
	private BaseRichBolt gstr2aReconRedisWSBolt;
	
	public GSTR2AReconTopologyBuilder(Properties configs) {
		super(configs);
		initialize();
	}
	
	
	private void initialize() {
		gstr2aReconSpoutBuilder = new GSTR2AReconSpoutBuilder(configs);
		
		gstr2aReconBolt = new GSTR2AReconcBolt();
		gstr2ItcBolt = new GSTR2ITCBolt();
		gstr2aReconRedisWSBolt = new GSTR2AReconRedisWSBolt();
		
		
	}

	@Override
	public void buildDataPipeline(TopologyBuilder builder) {
		log.info("GSTR2AReconTopologyBuilder.setBuilderDataPipeline() starts");
		
		if(builder != null){
			try{
				KafkaSpout gstr2ReconSpout=gstr2aReconSpoutBuilder.buildKafkaSpout();
				builder.setSpout(configs.getProperty(Constant.STORM_SPOUT_GSTR2A_RECON), gstr2ReconSpout);
				
				builder.setBolt(configs.getProperty(Constant.BOLT_GSTR2A_RECON),gstr2aReconBolt).shuffleGrouping(configs.getProperty(Constant.STORM_SPOUT_GSTR2A_RECON));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_GSTR2A_RECON_ITC),gstr2ItcBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_GSTR2A_RECON));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_GSTR2A_RECON_REDIS_WS), gstr2aReconRedisWSBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_GSTR2A_RECON_ITC));
				log.info("GSTR2AReconTopologyBuilder.setBuilderDataPipeline() ends");
			
			}catch(Exception e){
				log.error("Error Building GSTR2ARecon Topology " + e);
			}
		}
	
	}

}
