package com.ey.advisory.asp.common.configs;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
/**
 * mayank
 * */
import java.util.Set;

import org.apache.storm.utils.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class ASPStormProperties {
	private static final  Logger log = LoggerFactory.getLogger(ASPStormProperties.class);
	private static Properties allConfig= null;

	private ASPStormProperties(){}
	
	public static Properties getAllProperties(){
		return allConfig;
	}	
	
	public static void setAllProperties(Map<String, Object> map){
	try{	
		if(allConfig == null){
		  allConfig = new Properties();
		}		
		for(Entry<String, Object> entry : map.entrySet()){
			String key = entry.getKey();
			String value = entry.getValue()+"";
			allConfig.setProperty(key, value);
		}
		
	}catch(Exception e){		
		log.error("Exception in setting configs/properties",e);
	}	
}	
}
