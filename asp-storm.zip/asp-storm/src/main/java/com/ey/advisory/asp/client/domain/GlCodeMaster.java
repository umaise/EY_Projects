package com.ey.advisory.asp.client.domain;

public class GlCodeMaster {

private static final long serialVersionUID = 1L;
	
	private Long glID;
	private String glCode;
	private String glDescription;
	private String eligibility;

	public Long getGlID() {
		return glID;
	}

	public void setGlID(Long glID) {
		this.glID = glID;
	}

	public String getGlCode() {
		return glCode;
	}

	public void setGlCode(String glCode) {
		this.glCode = glCode;
	}

	public String getGlDescription() {
		return glDescription;
	}

	public void setGlDescription(String glDescription) {
		this.glDescription = glDescription;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}
	
	
	
}
