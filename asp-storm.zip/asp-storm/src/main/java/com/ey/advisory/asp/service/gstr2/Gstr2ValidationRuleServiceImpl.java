package com.ey.advisory.asp.service.gstr2;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.GlCodeMaster;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.jersey.api.client.ClientResponse;

/**
 * 
 * @author Nisha Kumari
 * @version 1.0
 * @since 17-03-2017
 */

public class Gstr2ValidationRuleServiceImpl implements Gstr2ValidationRuleService {

	Set<TblPurchaseErrorInfo> errorList = new HashSet<TblPurchaseErrorInfo>();
	private final Logger log = LoggerFactory.getLogger(getClass());
	Map<String, TblGstinDetailsDomain> gstinMap = new HashMap<String, TblGstinDetailsDomain>();
	private Map<String, ItemMaster> itemHsnSacMap = null;
	private Map<String, GlCodeMaster> glCodeMasterMap = null;
	private RedisTemplate<String, Object> redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();
	private boolean isErrorFound = false;

	public InwardInvoiceDTO executeGSTR2ITCValidationRules(InwardInvoiceDTO inwardInvoiceDTO) {

		isErrorFound = false;
		if (inwardInvoiceDTO.getErrorList() != null) {
			errorList = inwardInvoiceDTO.getErrorList();
		}

		List<InwardInvoiceModel> lineItems = inwardInvoiceDTO.getLineItemList();
		if (lineItems != null && !lineItems.isEmpty()){

			validateDocumentDateForRegDate(lineItems.get(0),inwardInvoiceDTO.getGroupCode());

			/*Defect ID 1255 -Commenting as per the latest requirement
			createLiablityUnderReverseCharge(lineItems.get(0));*/

			validatePOS(lineItems);

			validateReverseCharge(lineItems);

			validateMultipleSupplyType(lineItems, inwardInvoiceDTO.isMultipleSupplyType());

			validateDocumentDateForTaxPeriod(lineItems.get(0));

			validateOrgDocumentNoAndDate(lineItems.get(0));
			
			validateWrongRNVreporting(inwardInvoiceDTO);

//			int counter = 0;

			if (inwardInvoiceDTO.getLineItemList() != null) {
				String groupCode = inwardInvoiceDTO.getGroupCode();

				for (InwardInvoiceModel inwardInvoiceModel : inwardInvoiceDTO.getLineItemList()) {

					validateItcEligiblity(inwardInvoiceModel, groupCode);
					validateItcTaxAvailability(inwardInvoiceModel, groupCode);
					validateItcTaxAmount(inwardInvoiceModel);

					validateTaxvalues(inwardInvoiceModel);
					validatetaxValue(inwardInvoiceModel);
					//					validateEntityHierarchy(inwardInvoiceModel, groupCode);

//					if (inwardInvoiceModel.getItemStatus() != null
//							&& inwardInvoiceModel.getItemStatus().equalsIgnoreCase(Constant.BUS_RULE_ERROR)) {
//						counter = counter + 1;
//					}
				}
			}

			if (isErrorFound) {
				inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
			} else if (inwardInvoiceDTO.getInvStatus() == null) {
				inwardInvoiceDTO.setInvStatus(Constant.GSTR2_BR_STG1);
			}
			
			inwardInvoiceDTO.setErrorList(errorList);
		}
		return inwardInvoiceDTO;

	}

	private void validateItcTaxAvailability(InwardInvoiceModel lineItem, String groupCode) {

		if(lineItem.getEligibilityIndicator() != null && lineItem.getEligibilityIndicator().equalsIgnoreCase(Constant.NONE) && ((lineItem.getAvailableCGST() != null && lineItem.getAvailableCGST().compareTo(BigDecimal.ZERO) > 0) 
				|| (lineItem.getAvailableSGST() != null && lineItem.getAvailableSGST().compareTo(BigDecimal.ZERO) > 0) || (lineItem.getAvailableIGST() != null &&lineItem.getAvailableIGST().compareTo(BigDecimal.ZERO) > 0)
				||(lineItem.getAvailableCESS() != null && lineItem.getAvailableCESS().compareTo(BigDecimal.ZERO) > 0))){
//			lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
			isErrorFound = true;
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER403", Constant.ELIGIBILITY_INDICATOR, Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
		}else if(lineItem.getEligibilityIndicator() != null && (lineItem.getEligibilityIndicator().equalsIgnoreCase(Constant.CAPITAL_GOODS) || lineItem.getEligibilityIndicator().equalsIgnoreCase(Constant.INPUT_SERVICES)
				|| lineItem.getEligibilityIndicator().equalsIgnoreCase(Constant.INPUTS)) && (lineItem.getAvailableSGST() == null || lineItem.getAvailableSGST().compareTo(BigDecimal.ZERO) == 0)
				&& (lineItem.getAvailableCGST() == null || lineItem.getAvailableCGST().compareTo(BigDecimal.ZERO) == 0) 
				&& (lineItem.getAvailableIGST() == null || lineItem.getAvailableIGST().compareTo(BigDecimal.ZERO) == 0)
				&& (lineItem.getAvailableCESS() == null || lineItem.getAvailableCESS().compareTo(BigDecimal.ZERO) == 0)){
//			lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
			isErrorFound = true;
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER403", Constant.ELIGIBILITY_INDICATOR, Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
		}
	}

	private void validateWrongRNVreporting(InwardInvoiceDTO inwardInvoiceDTO) {

		if(inwardInvoiceDTO!=null && inwardInvoiceDTO.getLineItemList().size()>0){

			InwardInvoiceModel inwardInvoiceModel = inwardInvoiceDTO.getLineItemList().get(0);

			Calendar docDate = Calendar.getInstance();
			Calendar orgDocDate = Calendar.getInstance();
			String taxPeriod = new String();
			if(inwardInvoiceModel.getDocumentType()!=null && inwardInvoiceModel.getDocumentType().equalsIgnoreCase(Constant.RNV)&& inwardInvoiceModel.getDocumentDate() != null && inwardInvoiceModel.getOriginalDocumentDate() != null && !inwardInvoiceModel.getOriginalDocumentDate().toString().isEmpty() && inwardInvoiceModel.getTaxPeriod() != null){
				try{

					docDate.setTime(Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getDocumentDate().toString()));
					orgDocDate.setTime(Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getOriginalDocumentDate().toString())); 
					taxPeriod = inwardInvoiceModel.getTaxPeriod();
					if(docDate.get(Calendar.YEAR) == orgDocDate.get(Calendar.YEAR) && 
							(docDate.get(Calendar.MONTH) == orgDocDate.get(Calendar.MONTH)) && (docDate.get(Calendar.MONTH) == Integer.parseInt(taxPeriod.substring(0,2)) && (docDate.get(Calendar.YEAR) == Integer.parseInt(taxPeriod.substring(2,6))))){
//						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER229", Constant.Document_Date, Constant.BUSINESS_RULE, Boolean.FALSE
								,Constant.INVOICE));
						log.info("ER229: Error in RNV document types " + inwardInvoiceModel.getId() + "INV and RNV document types cannot exists for a same Invoice number within the given tax period");

						isErrorFound=true;
					}
				}catch(ParseException pe){
					log.error("Error Parsing Date for invoice ", inwardInvoiceModel.getId(), pe);
				}catch(Exception e){
					log.error("Error Validating DocumentDate for document date ", e);
				}
			}
		}
	}

	private void validatetaxValue(InwardInvoiceModel inwardInvoiceModel) {


		BigDecimal taxableValue = inwardInvoiceModel.getTaxableValue() == null ? BigDecimal.ZERO
				: inwardInvoiceModel.getTaxableValue().abs();

		BigDecimal iGSTRate = inwardInvoiceModel.getIGSTRate() == null ? BigDecimal.ZERO
				: inwardInvoiceModel.getIGSTRate().divide(new BigDecimal(100));

		BigDecimal cGSTRate = inwardInvoiceModel.getCGSTRate() == null ?BigDecimal.ZERO
				: inwardInvoiceModel.getCGSTRate().divide(new BigDecimal(100));
		//		BigDecimal cessSpecifcRate = inwardInvoiceModel.getCessRateSpecific() == null ?BigDecimal.ZERO
		//				: inwardInvoiceModel.getCessRateSpecific().divide(new BigDecimal(100));
		//		
		//		
		//		BigDecimal cessRateAdvalorem = inwardInvoiceModel.getCessRateAdvalorem() == null ?BigDecimal.ZERO
		//				: inwardInvoiceModel.getCessRateAdvalorem().divide(new BigDecimal(100));

		BigDecimal sGSTRate = inwardInvoiceModel.getSGSTRate() == null ? BigDecimal.ZERO
				: inwardInvoiceModel.getSGSTRate().divide(new BigDecimal(100));

		BigDecimal taxValueIgST = taxableValue.multiply(iGSTRate);
		taxValueIgST=taxValueIgST.setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal taxValueCgST = taxableValue.multiply(cGSTRate);
		taxValueCgST=taxValueCgST.setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal taxValueSgST = taxableValue.multiply(sGSTRate);
		taxValueSgST=taxValueSgST.setScale(2, BigDecimal.ROUND_HALF_UP);

		//		BigDecimal taxValueCess = taxableValue.multiply(cessRateAdvalorem.add(cessSpecifcRate));
		//		taxValueCess=taxValueCess.setScale(2, BigDecimal.ROUND_HALF_UP);


		//		BigDecimal cessAmountAdvalorem = inwardInvoiceModel.getCessAmountAdvalorem()==null?BigDecimal.ZERO: inwardInvoiceModel.getCessAmountAdvalorem().setScale(2, BigDecimal.ROUND_HALF_UP).abs();
		//		BigDecimal cessAmountSpecific = inwardInvoiceModel.getCessAmountSpecific()==null?BigDecimal.ZERO: inwardInvoiceModel.getCessAmountSpecific().setScale(2, BigDecimal.ROUND_HALF_UP).abs();


		String columnNames = "";
		if (!taxValueIgST.equals(inwardInvoiceModel.getIGSTAmount() == null ? BigDecimal.ZERO
				: inwardInvoiceModel.getIGSTAmount().setScale(2, BigDecimal.ROUND_HALF_UP).abs())){

			log.info(
					"Report will be generated and shared with the taxpayer for any differences as per their calculation with our system calculation");

			columnNames= Constant.IGST_AMOUNT_GSTR2;
			//outwardInvoiceModel.setItemStatus(Constant.b);
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "IN208", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

		}

		if (!taxValueCgST.equals(inwardInvoiceModel.getCGSTAmount() == null ? BigDecimal.ZERO
				: inwardInvoiceModel.getCGSTAmount().setScale(2, BigDecimal.ROUND_HALF_UP).abs())) {
			log.info(
					"Report will be generated and shared with the taxpayer for any differences as per their calculation with our system calculation");
			columnNames = Constant.CGST_AMOUNT_GSTR2;
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "IN207", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
		}

		if (!taxValueSgST.equals(inwardInvoiceModel.getSGSTAmount() == null ? BigDecimal.ZERO
				: inwardInvoiceModel.getSGSTAmount().setScale(2, BigDecimal.ROUND_HALF_UP).abs())) {
			log.info(
					"Report will be generated and shared with the taxpayer for any differences as per their calculation with our system calculation");
			columnNames = Constant.SGST_AMOUNT_GSTR2;
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "IN202", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

		}

		//		 if (!taxValueCess.equals( (cessAmountAdvalorem.add(cessAmountSpecific)).setScale(2, BigDecimal.ROUND_HALF_UP).abs())){
		//
		//			log.info(
		//					"Report will be generated and shared with the taxpayer for any differences as per their calculation with our system calculation");
		//
		//			columnNames = Constant.CESS_AMT_ADV_GSTR2+ ","+Constant.CESS_AMT_SPECIFIC_GSTR2;
		//			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "IN209", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
		//
		//		}

	}

	private void validateTaxvalues(InwardInvoiceModel inwardInvoiceModel) {

		if (checkEmptyornull(inwardInvoiceModel.getIGSTAmount())) {
			inwardInvoiceModel.setIGSTAmount(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getCGSTAmount())) {
			inwardInvoiceModel.setCGSTAmount(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getSGSTAmount())) {
			inwardInvoiceModel.setSGSTAmount(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getIGSTRate())) {
			inwardInvoiceModel.setIGSTRate(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getCGSTRate())) {
			inwardInvoiceModel.setCGSTRate(BigDecimal.ZERO);
		}
		if (checkEmptyornull(inwardInvoiceModel.getSGSTRate())) {
			inwardInvoiceModel.setSGSTRate(BigDecimal.ZERO);
		}
		if (!checksupplyType(inwardInvoiceModel.getSupplyType(),inwardInvoiceModel.getSGSTIN())) {
			validatetaxAmount(inwardInvoiceModel);
		} else {
			if (!(inwardInvoiceModel.getIGSTAmount().equals(BigDecimal.ZERO))
					&& (inwardInvoiceModel.getCGSTAmount().abs().add(inwardInvoiceModel.getSGSTAmount().abs()).compareTo(BigDecimal.ZERO)==1 )) {
				log.info("An invoice can either be intra-State or inter-State");
				String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//				inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				isErrorFound = true;
				errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER224", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
			}
		}

	}


	private Boolean checksupplyType(String supplyType, String sGSTIN) {

		if (supplyType.equalsIgnoreCase(Constant.EXT) || (supplyType.equalsIgnoreCase(Constant.NIL))
				|| (supplyType.equalsIgnoreCase(Constant.NON)|| (supplyType.equalsIgnoreCase(Constant.NYS)) 
						||(supplyType.equalsIgnoreCase(Constant.IMPS)))||(supplyType.equalsIgnoreCase(Constant.SEZG)) || (supplyType.equalsIgnoreCase(Constant.SEZS)) ||(supplyType.equalsIgnoreCase(Constant.EXPT))
				||(supplyType.equalsIgnoreCase(Constant.EXPT))||(supplyType.equalsIgnoreCase(Constant.EXPWT))||(supplyType.equalsIgnoreCase(Constant.DXP ))||(supplyType.equalsIgnoreCase(Constant.COM))||(supplyType.equalsIgnoreCase(Constant.DTA))||(supplyType.equalsIgnoreCase(Constant.COM))||(supplyType.equalsIgnoreCase(Constant.IMPG))||(sGSTIN==null)||(sGSTIN.trim().isEmpty())) 
		{
			return true;

		}

		return false;

	}

	private Boolean checkEmptyornull(BigDecimal value) {

		if (value != null && !value.toString().isEmpty()) {
			return false;
		}
		return true;
	}

	private void validateItcEligiblity(InwardInvoiceModel lineItem, String groupCode) {
		boolean isEligibilitySet = false;
		String itcEligiblityFlag = lineItem.getEligibilityIndicator();
		String HSNorSAC = lineItem.getHSNorSAC();

		if(itcEligiblityFlag == null || itcEligiblityFlag.isEmpty()){
			/*String PAN = lineItem.getCGSTIN().substring(2, 12);
			clientOnBoardingData = Utility.getClientOnBoardingDetailFromRedis(PAN, groupCode);
			AnswerModuleDTO answerModuleDTO = null;

			if(clientOnBoardingData != null) {
				// ITC eligibility to be provided by Client or Fetched from Master 
				answerModuleDTO = clientOnBoardingData.get(Constant.QUESTION_ITC_ELIGIBILITY);
			}*/

			//Setting Error In case Answer is not present or ITC Eligibility had to be given by client 
			//if((answerModuleDTO == null || answerModuleDTO.getAnswerId().equalsIgnoreCase(Constant.ANSWER_ITC_ELIGIBILITY_CLIENT)) && !Constant.GSTR2_RCM.equalsIgnoreCase(lineItem.getTableType())){
			TblPurchaseErrorInfo purchaseErrorInfo = ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER402", Constant.ELIGIBILITY_INDICATOR,Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM);
			purchaseErrorInfo.setErrorDesc(purchaseErrorInfo.getErrorDesc().replace("<>", "<" + lineItem.getId() +">"));
			errorList.add(purchaseErrorInfo);
//			lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
			isErrorFound = true;
			log.debug(lineItem.getId() + Constant.ELIGIBILITY_INDICATOR + " Eligibility of ITC" + " Business Rule ");
			/*}else if(answerModuleDTO != null && answerModuleDTO.getAnswerId().equalsIgnoreCase(Constant.ANSWER_ITC_ELIGIBILITY_MASTER) && !Constant.GSTR2_RCM.equalsIgnoreCase(lineItem.getTableType())){
		    	getMasterDetailsfromRedis(redisTemplate,groupCode);

		    	//Get Eligibility by GL Code
				isEligibilitySet = deriveEligibilityByGLCode(lineItem, groupCode, redisTemplate);

				if(!isEligibilitySet){
					//Get Eligibility By HSNSAC
					isEligibilitySet = deriveEligibilityByHSNSAC(lineItem, groupCode, redisTemplate);
					}
				// IF eligibility couldn't be Derived from GLCode or HSNSAC then derive Eligibility based on GoodsAndServices
				if(!isEligibilitySet){
					if(HSNorSAC != null && !HSNorSAC.isEmpty()){
						if(HSNorSAC.startsWith(Constant.SERVICES_CODE)){
							lineItem.setEligibilityIndicator(Constant.INPUT_SERVICES);
						}else{
							lineItem.setEligibilityIndicator(Constant.INPUTS);
						}
					}

				}
			}*/
		}else{
			validateItcEligiblityForInputType(lineItem);
		}
	}

	/*
	 * validating eligliblity as per Eligible Input flag
	 */
	private void validateItcEligiblityForInputType(InwardInvoiceModel lineItem) {
		String itcEligiblityFlag = lineItem.getEligibilityIndicator();
		String HSNorSAC = lineItem.getHSNorSAC();
		if (itcEligiblityFlag != null && !itcEligiblityFlag.isEmpty() && !Constant.GSTR2_RCM.equalsIgnoreCase(lineItem.getTableType())) {

//			if (HSNorSAC != null && !HSNorSAC.isEmpty()) {
//				if(HSNorSAC.startsWith(Constant.SERVICES_CODE)){
//					if (lineItem.getEligibilityIndicator().equalsIgnoreCase(Constant.CAPITAL_GOODS)) {
//						log.info("Capital goods cannot be selected if S flag is there in the line item(s)");
////						lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
//						isErrorFound = true;
//						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER410", Constant.ELIGIBILITY_INDICATOR, Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
//
//					}else if(lineItem.getEligibilityIndicator().equalsIgnoreCase(Constant.INPUTS)){
//
//						log.info("Inputs cannot be selected if S flag is there in the line item(s)");
////						lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
//						isErrorFound = true;
//						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER411",
//								Constant.ELIGIBILITY_INDICATOR, Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
//
//					}
//				}else{
//
//					if (lineItem.getEligibilityIndicator().equalsIgnoreCase(Constant.INPUT_SERVICES)) {
//
//						log.info("Input Services can't be selected if G flag is there for line item(s)");
////						lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
//						isErrorFound = true;
//						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER412",
//								Constant.ELIGIBILITY_INDICATOR, Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
//
//					}
//				}
//			}

			if(lineItem.getCGSTIN() != null && !lineItem.getCGSTIN().substring(0, 2).equalsIgnoreCase(lineItem.getPos()) 
					&& (Constant.CAPITAL_GOODS.equalsIgnoreCase(itcEligiblityFlag) || Constant.INPUT_SERVICES.equalsIgnoreCase(itcEligiblityFlag) || Constant.INPUTS.equalsIgnoreCase(itcEligiblityFlag))){
				log.info("Receipient can claim ITC only when POS and his State code are same.");
				String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
				isErrorFound = true;
				errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER474", columnNames, Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
			}
		} 
	}

	/*
	 * check that Tax Available as ITC is not more than Total tax Amount in PR
	 */
	private void validateItcTaxAmount(InwardInvoiceModel lineItem) {

		BigDecimal itcCgst = lineItem.getAvailableCGST() == null ? Constant.ZERO_BIG_DECIMAL : lineItem.getAvailableCGST().abs();
		BigDecimal itcIgst = lineItem.getAvailableIGST() == null ? Constant.ZERO_BIG_DECIMAL : lineItem.getAvailableIGST().abs();
		BigDecimal itcSgst = lineItem.getAvailableSGST() == null ? Constant.ZERO_BIG_DECIMAL : lineItem.getAvailableSGST().abs();
		BigDecimal itcCess = lineItem.getAvailableCESS() == null ? Constant.ZERO_BIG_DECIMAL : lineItem.getAvailableCESS().abs();

		BigDecimal cgstAmount = lineItem.getCGSTAmount() == null ? Constant.ZERO_BIG_DECIMAL : lineItem.getCGSTAmount().abs();
		BigDecimal igstAmount = lineItem.getIGSTAmount() == null ? Constant.ZERO_BIG_DECIMAL : lineItem.getIGSTAmount().abs();
		BigDecimal sgstAmount = lineItem.getSGSTAmount() == null ? Constant.ZERO_BIG_DECIMAL : lineItem.getSGSTAmount().abs();
		BigDecimal cessAmount = lineItem.getCessAmountSpecific() == null ? Constant.ZERO_BIG_DECIMAL : lineItem.getCessAmountSpecific().abs();
		BigDecimal cessAmountAdv = lineItem.getCessAmountAdvalorem() == null ? Constant.ZERO_BIG_DECIMAL : lineItem.getCessAmountAdvalorem().abs();

		BigDecimal totalCessAmount = cessAmount.add(cessAmountAdv);
		
		if ((itcCgst.compareTo(cgstAmount) > 0) || (itcSgst.compareTo(sgstAmount) > 0)) {
			isErrorFound = true;
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER404", Constant.ITC_REVERSAL_IDENTIFIER,Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
		}
		
		if (itcIgst.compareTo(igstAmount) > 0) {
			isErrorFound = true;
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER404", Constant.ITC_REVERSAL_IDENTIFIER,Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
		}
		
		if (itcCess.compareTo(totalCessAmount) > 0) {
			isErrorFound = true;
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER404", Constant.ITC_REVERSAL_IDENTIFIER,Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
		}
		
//		BigDecimal totalITCAvailable = itcCgst.add(itcIgst).add(itcSgst).add(itcCess).abs();
//
//		BigDecimal totalTaxAmount = cgstAmount.add(igstAmount).add(sgstAmount).add(cessAmount).add(cessAmountAdv).abs();

//		if (totalITCAvailable.compareTo(totalTaxAmount) > 0) {
//
//			log.info("Eligibility of ITC can't more than the tax amount");
////			lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
//			isErrorFound = true;
//			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER404", Constant.ITC_REVERSAL_IDENTIFIER,Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM));
//		}
	}

	// Validating Document Date for greater than Registration Date
	@SuppressWarnings({ "unchecked" })
	private void validateDocumentDateForRegDate(InwardInvoiceModel inwardInvoiceModel, String groupCode ) {

		Date registrationDate = null;
		Date docDt = null;
		String gstinId = inwardInvoiceModel.getCGSTIN();
		String columnNames = "";

		gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(groupCode+"_"+ Constant.REDIS_CACHE,
				Constant.GSTIN_DEATILS);

		if(gstinMap == null){
			loadGSTINDetailsToRedis(groupCode);
			gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(
					groupCode+"_"+ Constant.REDIS_CACHE, Constant.GSTIN_DEATILS);
		}

		TblGstinDetailsDomain gstin = null;
		if (gstinMap != null)
			gstin = gstinMap.get(gstinId);

		if (gstin == null) {
			ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
					"asp-restapi.getGSTIN", groupCode, gstinId, Constant.VERB_TYPE_POST);
			//Gson gson = new Gson();
			Gson gson = new GsonBuilder().setDateFormat(Constant.DATE_FORMAT).create(); 
			if (response!=null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
				gstin = gson.fromJson(response.getEntity(String.class), TblGstinDetailsDomain.class);
			}
		}

		if (gstin != null && gstin.getRegdt()!=null )
			registrationDate = gstin.getRegdt();

		if (registrationDate == null) {
			log.error("GST Registration Date is not available");
			columnNames = Constant.Document_Date;
//			inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER129",
					columnNames, Constant.BUSINESS_RULE, false, Constant.INVOICE));
			isErrorFound = true;
		} else {
			try {
				docDt = Utility.convertStringToDate(Constant.DATE_FORMAT,
						inwardInvoiceModel.getDocumentDate().toString());
				log.info("DocDate :" + docDt.toString() +" ----- " + "RegDate :" + registrationDate.toString());
			} catch (ParseException e) {
				log.error("Error in parsing date" + e);
			}

			if (docDt!=null && docDt.compareTo(registrationDate) < 0) {

				log.error("Document Date is earlier than the Effective Date of GST Registration");
				columnNames = Constant.Document_Date;

				errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "IN311",
						columnNames, Constant.BUSINESS_RULE, false, Constant.INVOICE));
			}else {
				Calendar docDate = Calendar.getInstance();
				Calendar regDate = Calendar.getInstance();
				docDate.setTime(docDt);
				regDate.setTime(registrationDate);
				if((inwardInvoiceModel.getDocumentType().equals(Constant.RCR) || inwardInvoiceModel.getDocumentType().equals(Constant.RDR) || inwardInvoiceModel.getDocumentType().equals(Constant.RNV)
						|| inwardInvoiceModel.getDocumentType().equals(Constant.RDLC)) &&((docDate.get(Calendar.MONTH) == (regDate.get(Calendar.MONTH))) 
								&& (docDate.get(Calendar.YEAR) == (regDate.get(Calendar.YEAR)))) ){
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(
							inwardInvoiceModel, "ER230",Constant.Document_Date,
							Constant.BUSINESS_RULE, false,Constant.INVOICE));
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					log.error(inwardInvoiceModel.getId() + " ER230 " + Constant.Document_Date + Constant.BUSINESS_RULE);
					isErrorFound = true;
				}
			}
		}
	}

/*	Defect ID 1255 -Commenting as per the latest requirement
 * private void createLiablityUnderReverseCharge(InwardInvoiceModel inwardInvoiceModel) {

		if (inwardInvoiceModel.getDocumentType().equalsIgnoreCase(Constant.SLF) && inwardInvoiceModel.getSupplyType().equalsIgnoreCase(Constant.UNR)
				&& (inwardInvoiceModel.getSGSTIN() == null || inwardInvoiceModel.getSGSTIN().trim().isEmpty())
				&& (Constant.Y.equalsIgnoreCase(inwardInvoiceModel.getReverseCharge()))) {

			log.info(
					"Input tax Credit on this invoice shall be given only when valid GSTR-3 with full payment of tax liability has been filed");

			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "IN301",
					Constant.REVERSE_CHARGE_GSTR2, Constant.BUSINESS_RULE, false, Constant.INVOICE));

		}
	}*/

	@SuppressWarnings("unchecked")
	@Override
	public String validateHsnSacAgainstNonGST(String groupCode) {
		ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
				"asp-restapi.validateHSNSACPurchase", groupCode, "success", Constant.VERB_TYPE_POST);

		if (response!=null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK) {
			return Constant.SUCCESS;
		}
		return Constant.FAILED;
	}


	private String loadGSTINDetailsToRedis(String groupCode ) {
		String status = null;

		ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.LOAD_GSTIN_REDIS,  groupCode, null, Constant.VERB_TYPE_POST);
		Gson gson = new Gson();

		if(response!=null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			status = gson.fromJson(response.getEntity(String.class), String.class);
		}
		return status;
	}

	/*
	 * ITC Eligibility derived by GL Code
	 */
	private boolean deriveEligibilityByGLCode(InwardInvoiceModel lineItem, String groupCode, RedisTemplate<String, Object> redisTemplate) {

		Gson gson = new Gson();

		if(glCodeMasterMap == null || glCodeMasterMap.isEmpty()){
			ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.LOAD_GL_MASTER_REST, groupCode, null, Constant.VERB_TYPE_GET);
			if(response != null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
				getMasterDetailsfromRedis(redisTemplate, groupCode);
			}
		}

		GlCodeMaster glCodeMaster = null;
		if(!glCodeMasterMap.isEmpty() && glCodeMasterMap.containsKey(lineItem.getgLAccountCode())){
			glCodeMaster = glCodeMasterMap.get(lineItem.getgLAccountCode());
		}else{
			ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.GL_MASTER_BY_CODE_REST, groupCode, lineItem.getgLAccountCode(), Constant.VERB_TYPE_POST);
			if(response != null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
				glCodeMaster = gson.fromJson(response.getEntity(String.class), GlCodeMaster.class);
			}
		}
		if(glCodeMaster != null && glCodeMaster.getEligibility().equalsIgnoreCase(Constant.GL_ELIGIBILITY_CAPITALGOOD)){
			lineItem.setEligibilityIndicator(Constant.CAPITAL_GOODS);
			return true;
		}
		return false;
	}

	/*
	 * ITC Eligibility Derived based on HSNSAC
	 */
	private boolean deriveEligibilityByHSNSAC(InwardInvoiceModel lineItem, String groupCode, RedisTemplate<String, Object> redisTemplate) {
		//Load HsnSacMap from Redis

		if (itemHsnSacMap == null || itemHsnSacMap.isEmpty() ){
			if(validateHsnSacAgainstNonGST(groupCode).equalsIgnoreCase("Success")){
				getMasterDetailsfromRedis(redisTemplate,groupCode);

			}
		}

		ItemMaster master = null;
		if(!itemHsnSacMap.isEmpty() && itemHsnSacMap.containsKey(lineItem.getHSNorSAC())){
			master = itemHsnSacMap.get(lineItem.getHSNorSAC());
		}else{
			ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.FETCH_ITEM_BY_HSNSAC, groupCode,lineItem.getHSNorSAC(), Constant.VERB_TYPE_POST);
			if(response != null && response.getStatusInfo().getStatusCode() == 200 && response.getEntity(String.class).equalsIgnoreCase(Constant.SUCCESS)){
				getMasterDetailsfromRedis(redisTemplate, groupCode);
				if(!itemHsnSacMap.isEmpty() && itemHsnSacMap.containsKey(lineItem.getHSNorSAC())){
					master = itemHsnSacMap.get(lineItem.getHSNorSAC());
				}
			}
		}
		if(master != null){
			if(Constant.Y.equals(master.getNonCreditable())){
				lineItem.setEligibilityIndicator(Constant.NONE);
				return true;
			}
		}else{
			TblPurchaseErrorInfo errorInfo = ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "IN303", Constant.HSN_SAC, Constant.BUSINESS_RULE, false, Constant.INCIDENCE_LEVEL_LINE_ITEM);
			if(errorInfo.getErrorDesc() != null && !errorInfo.getErrorDesc().equals(Constant.UNKNOWN_ERROR)){
				errorInfo.setErrorDesc(errorInfo.getErrorDesc().replace("<>", "<"+lineItem.getHSNorSAC()+">"));
				errorList.add(errorInfo);
			}
		}
		return false;
	}

	private void getMasterDetailsfromRedis(RedisTemplate<String, Object> redisTemplate, String groupCode) {

		if(itemHsnSacMap==null){
			itemHsnSacMap= new HashMap<>();
		}

		itemHsnSacMap = (Map<String, ItemMaster>)redisTemplate.opsForHash().get(groupCode+"_"+Constant.REDIS_CACHE, Constant.ITEM_MASTER_DETAILS);

		if(glCodeMasterMap == null){
			glCodeMasterMap = new HashMap<>();
		}

		glCodeMasterMap = (Map<String, GlCodeMaster>) redisTemplate.opsForHash().get(groupCode+"_"+Constant.REDIS_CACHE, Constant.GL_CODE_MASTER_DETAILS);
	}


	private void validatetaxAmount(InwardInvoiceModel inwardInvoiceModel) {

		if(inwardInvoiceModel.getSupplyType().equalsIgnoreCase(Constant.TAX) 
				&& (inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==0)
				&& (inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==0)
				&& (inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==0) 
				&& (inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==0)
				&& (inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==0)
				&& (inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==0)) {
			return;
		}
		
		if (!(inwardInvoiceModel.getIGSTAmount().equals(BigDecimal.ZERO))
				&& (inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==1)&&(inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==1)) {
			log.info("An invoice can either be intra-State or inter-State");
			String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//			inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			isErrorFound = true;
			errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER224", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
		} else if ((inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==0)
				&& (inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==0)
				&& (inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==0 &&(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==0)
				&& (inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==0)
				&& (inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==0))&&(inwardInvoiceModel.getReverseCharge()!=null)) {

			checkforIntraorInterState(inwardInvoiceModel,Boolean.TRUE);
		} else {

			checkforIntraorInterState(inwardInvoiceModel,Boolean.FALSE);
		} 
	}

	private void checkforIntraorInterState(InwardInvoiceModel inwardInvoiceModel, Boolean isZero) {

		if(inwardInvoiceModel.getCGSTIN()!=null && !inwardInvoiceModel.getCGSTIN().trim().isEmpty() && (inwardInvoiceModel.getSGSTIN()!=null)&& (!inwardInvoiceModel.getSGSTIN().trim().isEmpty()) ){

			if (inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2))&&(inwardInvoiceModel.getPos()==null)) {

				if(!isZero && (inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==1 )||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==1)){

					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}

				else if((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==0|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==0)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==0|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==0){

					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}

			} else if (inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2))&&(inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))) {

				if(!isZero && (inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==1 ||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==1))){

					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				} else if((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==0|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==0)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==0|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==0){

					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}
			} else if (inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2))&&(!inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))) {

				if(!isZero && ((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==1)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==1)){

					log.info("IGST can't be Zero for Inter State Supply");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

				} else if(inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==0 ||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==0)){

					log.info("In case of Inter-State Supply, IGST is applicable");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}
			} else if (!(inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))&&(inwardInvoiceModel.getPos()==null)) {

				if(!isZero && ((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==1)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==1)){

					log.info("IGST can't be Zero for Inter State Supply");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

				} else if(inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==0 ||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==0)){

					log.info("In case of Inter-State Supply, IGST is applicable");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}
			} else if (!(inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))&&(inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))) {

				if(!isZero && (inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==1 ||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==1))){

					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				} else if((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==0|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==0)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==0|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==0){

					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}
			} else if (!(inwardInvoiceModel.getCGSTIN().substring(0, 2).equalsIgnoreCase(inwardInvoiceModel.getSGSTIN().substring(0, 2)))&&(inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getCGSTIN().substring(0, 2)))) {

				if(!isZero &&  ((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==1)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==1)){

					log.info("IGST can't be Zero for Inter State Supply");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

				} else if(inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==0 ||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==0)){

					log.info("In case of Inter-State Supply, IGST is applicable");
					String columnNames = Constant.CGST_AMOUNT_GSTR2 + ","+Constant.IGST_AMOUNT_GSTR2+","+Constant.SGST_AMOUNT_GSTR2;
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER252", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

				}
			}
		}

		//removed  for Sgtin== null

		/* else if(inwardInvoiceModel.getSGSTIN()==null|| (inwardInvoiceModel.getSGSTIN().trim().isEmpty())){


				if (inwardInvoiceModel.getPos()==null||(inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getCGSTIN().substring(0, 2)))) {


					if(!isZero && (inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==1 ||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==1))){

						log.info("CGST/SGST can't be Zero for Intra State Supply");
						String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
					} else if((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==0|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==0)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==0|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==0){

						log.info("In case of Intra-State Supply, CGST & SGST is applicable");
						String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));


					}

				} else if (!inwardInvoiceModel.getPos().equalsIgnoreCase(inwardInvoiceModel.getCGSTIN().substring(0, 2))) {

					if(!isZero && ((inwardInvoiceModel.getCGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getCGSTRate().abs().compareTo(BigDecimal.ZERO)==1)|| inwardInvoiceModel.getSGSTAmount().abs().compareTo(BigDecimal.ZERO)==1|| inwardInvoiceModel.getSGSTRate().abs().compareTo(BigDecimal.ZERO)==1)){

						log.info("IGST can't be Zero for Inter State Supply");
						String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

					} else if(inwardInvoiceModel.getIGSTAmount().abs().compareTo(BigDecimal.ZERO)==0 ||(inwardInvoiceModel.getIGSTRate().abs().compareTo(BigDecimal.ZERO)==0)){

						log.info("In case of Inter-State Supply, IGST is applicable");
						String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER252", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}
				}
	       }
		 */

	}

	private void validatePOS(List<InwardInvoiceModel> lineItems) {

		String posCd1 = lineItems.get(0).getPos();
		if (posCd1 != null && !posCd1.trim().isEmpty()) {
			for (InwardInvoiceModel lineItem : lineItems) {
				if (!posCd1.equals(lineItem.getPos())) {
					String columnNames= Constant.POS;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER201", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
//					lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
					log.info(lineItem.getId() + " ER201 " + Constant.POS + Constant.BUSINESS_RULE);
					isErrorFound = true;
				}
			}
		} else {
			for (InwardInvoiceModel lineItem : lineItems) {
				if (lineItem.getPos() != null && !lineItem.getPos().trim().isEmpty()) {
					String columnNames = Constant.POS;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER201",columnNames,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
//					lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
					log.info(lineItem.getId() + " ER201 " + Constant.POS + Constant.BUSINESS_RULE);
					isErrorFound = true;
				}
			}
		}
	}

	private void validateReverseCharge(List<InwardInvoiceModel> lineItems) {

		String reverseChargeFlag = lineItems.get(0).getReverseCharge();
		if (reverseChargeFlag != null  && !reverseChargeFlag.trim().isEmpty()) {
			for (InwardInvoiceModel lineItem : lineItems) {
				if (!reverseChargeFlag.equals(lineItem.getReverseCharge())) {
					String columnNames=Constant.REVERSE_CHARGE_GSTR2;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER202", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
//					lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
				}
			}
		} else {
			for (InwardInvoiceModel lineItem : lineItems) {
				if (lineItem.getReverseCharge() != null  && !lineItem.getReverseCharge().trim().isEmpty()) {
					String columnNames=Constant.REVERSE_CHARGE_GSTR2;
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER202", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
//					lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
				}
			}
		}
	}

	/*
	 * Method to check Original Doc Date and Original Doc Number should not be null for Amendment invoices 
	 */
	private void validateOrgDocumentNoAndDate(InwardInvoiceModel lineItem) {

		List<String> docTypeList = Arrays.asList(Constant.RNV,Constant.CR,Constant.RCR,Constant.DR, Constant.RDR, Constant.RSLF, Constant.RRFV, Constant.RFV);

		if(docTypeList.contains(lineItem.getDocumentType())) {
			if(lineItem.getOriginalDocumentNo() == null || lineItem.getOriginalDocumentNo().trim().isEmpty() || lineItem.getOriginalDocumentDate() == null){

				// ----- Commenting check for CRDRPreGST=Y as per UAT requirement, error message expected
				//				if((Constant.CR.equalsIgnoreCase(lineItem.getDocumentType()) || Constant.DR.equalsIgnoreCase(lineItem.getDocumentType()))
				//						&& (Constant.Y.equals(lineItem.getCRDRPreGST()) || Constant.YES.equals(lineItem.getCRDRPreGST()))){
				//					if(lineItem.getOriginalDocumentNo() == null || lineItem.getOriginalDocumentNo().isEmpty()){
				//						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "IN201", Constant.ORG_DOC_NO, Constant.BUSINESS_RULE, Boolean.FALSE, 
				//								Constant.INVOICE));
				//					}
				//					if(lineItem.getOriginalDocumentDate() == null){
				//						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "IN210", Constant.ORG_DOC_DATE, Constant.BUSINESS_RULE, Boolean.FALSE, 
				//								Constant.INVOICE));
				//					}
				//				}else{
//				lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
				String columnNames = Constant.GSTR2_ORG_DOC_NO + "," + Constant.GSTR2_ORG_DOC_DATE;
				errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER414", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE, 
						Constant.INVOICE));
				isErrorFound = true;
				//				}
			}else{
				if(lineItem.getDocumentDate() != null && Utility.getDateByPattern(lineItem.getDocumentDate().toString()).before(Utility.getDateByPattern(lineItem.getOriginalDocumentDate().toString()))){
//					lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER254", Constant.GSTR2_ORG_DOC_DATE, Constant.BUSINESS_RULE, Boolean.FALSE, Constant.INVOICE));
					isErrorFound = true;
				}
			}
		}
	}

	private void validateMultipleSupplyType(List<InwardInvoiceModel> lineItems, boolean isMultipleSupplyType) {

		if(isMultipleSupplyType) {
			return;
		}
		String supplyType = lineItems.get(0).getSupplyType();
		for (InwardInvoiceModel lineItem : lineItems) {
			if (!supplyType.equals(lineItem.getSupplyType())) {
				String columnNames= Constant.SupplyType;
				errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "ER226", columnNames , Constant.BUSINESS_RULE, Boolean.FALSE, Constant.INVOICE));
//				lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
				isErrorFound = true;
			}
		}
	}

	private void validateDocumentDateForTaxPeriod(InwardInvoiceModel inwardInvoiceModel) {
		Calendar docDate = Calendar.getInstance();
		Calendar taxPeriod = Calendar.getInstance();
		Calendar currentDate = Calendar.getInstance();
		if(inwardInvoiceModel.getDocumentDate() != null && inwardInvoiceModel.getTaxPeriod() != null && !inwardInvoiceModel.getTaxPeriod().isEmpty()){
			try{
				docDate.setTime(Utility.convertStringToDate(Constant.DATE_FORMAT, inwardInvoiceModel.getDocumentDate().toString()));
				taxPeriod.setTime(Utility.convertStringToDate(Constant.DATEFORMAT, inwardInvoiceModel.getTaxPeriod())); 
				currentDate.setTime(new Date());

				if(taxPeriod.after(currentDate)){
					errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER413", Constant.RETURN_PERIOD, Constant.BUSINESS_RULE, false,Constant.INVOICE));
//					inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					isErrorFound = true;
					log.info("ER413: Error in transaction " + inwardInvoiceModel.getId() + " The Tax Period cannot be a future date beyond the current Date");
				}else{

					if(docDate.get(Calendar.YEAR) > taxPeriod.get(Calendar.YEAR) || 
							(docDate.get(Calendar.MONTH) > taxPeriod.get(Calendar.MONTH) && docDate.get(Calendar.YEAR) == taxPeriod.get(Calendar.YEAR))){
						String columnNames = Constant.Document_Date;
						errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(inwardInvoiceModel, "ER223", columnNames, Constant.BUSINESS_RULE, false,Constant.INVOICE));
//						inwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
						isErrorFound = true;
						log.info("ER223: Error in transaction " + inwardInvoiceModel.getId() + " The Document Date cannot be a future date beyond the tax period");
					}

				}
			}catch(ParseException pe){
				log.error("Error Parsing Date for invoice ", inwardInvoiceModel.getId(), pe);
			}catch(Exception e){
				log.error("Error Validating DocumentDate for TaxPeriod ", e);
			}
		}
	}

	private void validateEntityHierarchy(InwardInvoiceModel lineItem, String groupCode) {
		Map<String, List<EntityHierarchy>> entityHierarchyMap = new HashMap<>();
		List<EntityHierarchy> entityHierarchyList = new ArrayList<>();
		try{
			entityHierarchyMap = (Map<String, List<EntityHierarchy>>) redisTemplate.opsForHash().get(groupCode +"_"+ Constant.REDIS_CACHE, Constant.ENTITY_HIERARCHY_DETAILS);

			if(entityHierarchyMap == null || entityHierarchyMap.isEmpty()){
				if(loadEntityHierarchyMap(groupCode).equalsIgnoreCase(Constant.SUCCESS)){
					entityHierarchyMap = (Map<String, List<EntityHierarchy>>) redisTemplate.opsForHash().get(groupCode +"_"+ Constant.REDIS_CACHE, Constant.ENTITY_HIERARCHY_DETAILS);
				}
			} else {
				if(!entityHierarchyMap.containsKey(lineItem.getCGSTIN())){
					if(loadEntityHierarchyMap(groupCode).equalsIgnoreCase(Constant.SUCCESS)){
						entityHierarchyMap = (Map<String, List<EntityHierarchy>>) redisTemplate.opsForHash().get(groupCode +"_"+ Constant.REDIS_CACHE, Constant.ENTITY_HIERARCHY_DETAILS);
					}
				}
			}

			if(entityHierarchyMap != null && entityHierarchyMap.containsKey(lineItem.getCGSTIN())){
				entityHierarchyList = entityHierarchyMap.get(lineItem.getCGSTIN());
				Set<String> columnSet = new HashSet<>();
				int counter = 0;
				if(entityHierarchyList != null && !entityHierarchyList.isEmpty()){
					for(EntityHierarchy details : entityHierarchyList){
						if(details.isEqualHierarchy(lineItem.getId(), lineItem.getDivision(), lineItem.getSubDivision(), lineItem.getProfitCentre1(), lineItem.getProfitCentre2(), lineItem.getPlantCode())){
							counter = counter + 1;
							break;
						}
						details.validateEntityHierarchyData(lineItem.getId(), lineItem.getDivision(), lineItem.getSubDivision(), lineItem.getProfitCentre1(), lineItem.getProfitCentre2(), lineItem.getPlantCode(), columnSet);
					}
					if(counter == 0){
						for(String column : columnSet){
							if(Constant.DIVISION.equals(column)){
								errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "IN001", Constant.DIVISION, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}else if(Constant.SUB_DIVISION.equals(column)){
								errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "IN002", Constant.SUB_DIVISION, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}else if(Constant.PROFIT_CENTER_1.equals(column)){
								errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "IN003", Constant.PROFIT_CENTER_1, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}else if(Constant.PROFIT_CENTER_2.equals(column)){
								errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "IN004", Constant.PROFIT_CENTER_2, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}else if(Constant.PLANT_CODE.equals(column)){
								errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(lineItem, "IN005", Constant.PLANT_CODE, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}
						}
					}
				}
			} else {
				log.error("No Entity Hierarchy found for GSTIN:" + lineItem.getCGSTIN());
			}

		}catch(Exception e){
			log.error("Error Validating Entity Hierarchy for transaction" + lineItem.getId(), e);
		}

	}

	private String loadEntityHierarchyMap(String groupCode) {
		String status = Constant.FAILED;
		ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.ENTITY_HIERARCHY_REST, groupCode, null, Constant.VERB_TYPE_POST);
		Gson gson = new Gson();
		if(response!=null && response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			status = gson.fromJson(response.getEntity(String.class), String.class);
		}
		return status;
	}
}