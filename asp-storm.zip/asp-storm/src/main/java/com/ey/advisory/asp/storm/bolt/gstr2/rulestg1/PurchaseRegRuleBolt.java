package com.ey.advisory.asp.storm.bolt.gstr2.rulestg1;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.error.LogGSTR2RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

/**

 * @author  Ashutosh Srivastava
 * @version 1.0
 * @since   21-04-2017
 */

public class PurchaseRegRuleBolt extends CustomBaseRichBolt{

	private static final long serialVersionUID = 1L;
	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
	}

	@Override
	public void execute(Tuple input) {
		InwardInvoiceDTO inwardInvoiceDTO = null;
		LogRunTimeErros logRunTimeErros = new LogGSTR2RunTimeErros();
		try{
			log.info("In PurchaseRegRuleBolt.execute() start");
			Gson gson = new Gson();
			inwardInvoiceDTO = (InwardInvoiceDTO) input.getValue(0);
			if(inwardInvoiceDTO.getLineItemList()!=null)
				log.info("rediskey : " + inwardInvoiceDTO.getRedisKey() + " InvOrder : "+ inwardInvoiceDTO.getLineItemList().get(0).getInvOrder());
			
			String jsonString = gson.toJson(inwardInvoiceDTO);
			if(StringUtils.isNotEmpty(inwardInvoiceDTO.getTableType())){
				ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, "GSTR2_" + inwardInvoiceDTO.getTableType(), inwardInvoiceDTO.getGroupCode(), jsonString, Constant.VERB_TYPE_POST);

				if(response != null && response.getStatusInfo().getStatusCode() == 200) {
					String json = response.getEntity(String.class);
					inwardInvoiceDTO = gson.fromJson(json, InwardInvoiceDTO.class);
					log.info("RESPONSE : "+json);
				}else{
					log.error("Error RESPONSE : "+response + " TableType : " + inwardInvoiceDTO.getTableType());
				}
			}
			if(inwardInvoiceDTO != null){
				collector.emit(input,new Values(inwardInvoiceDTO));
		    }else{
		    	logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		    }
		}catch(Exception e){
			log.error("Error in PurchaseRegRuleBolt ", e);
			//collector.customReportError(input, e, "Exception in Bolt PurchaseRegRuleBolt");
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}

		finally {
			collector.ack(input);
			//collector.emit(new Values(inwardInvoiceDTO));
			//collector.emit(Constant.GSTR2_Stream1,new Values(inwardInvoiceDTO));
			log.info("In PurchaseRegRuleBolt.execute() end");
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR2_Stream1,new Fields("inv"));
	}

}