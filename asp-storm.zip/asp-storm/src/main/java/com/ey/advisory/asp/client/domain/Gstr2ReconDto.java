package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.SerializedName;

public class Gstr2ReconDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SerializedName("ID")
	private String id;
	
	@SerializedName("CustGSTIN")
	private String custGSTIN;
	
	@SerializedName("CntrPrtyFilingStatus")
	private String cntrPrtyFilingStatus;
	
	@SerializedName("InvNum")
	private String invNum;
	
	@SerializedName("InvDate")
	private Date invDate;
	
	@SerializedName("InvValue")
	private Double invValue;
	
	@SerializedName("POS")
	private String pOS;
	
	@SerializedName("RevChrg")
	private String revChrg;
	
	@SerializedName("OrgInvNum")
	private String orgInvNum;
	
	@SerializedName("OrgInvDt")
	private Date orgInvDt;
	
	@SerializedName("InvoiceUploader")
	private String invoiceUploader;
	
	@SerializedName("TaxableValue")
	private Double taxableValue;
	
	@SerializedName("TaxPeriod")
	private String taxPeriod;
	
	@SerializedName("Gstin")
	private String gstin;
	
	@SerializedName("SupplierName")
	private String supplierName;
	
	@SerializedName("IsAccepted")
	private String isAccepted;
	
	@SerializedName("Status")
	private String status;
	
	@SerializedName("LineNo")
	private Integer lineNo;
	
	@SerializedName("ItemStatus")
	private String itemStatus;
	
	@SerializedName("ItemType")
	private String itemType;
	
	@SerializedName("HSNSC")
	private String hSNSC;
	
	@SerializedName("ItemTxval")
	private Double itemTxval;
	
	@SerializedName("IGSTRt")
	private Double iGSTRt;
	
	@SerializedName("IGSTAmt")
	private Double iGSTAmt;
	
	@SerializedName("CGSTRt")
	private Double cGSTRt;
	
	@SerializedName("CGSTAmt")
	private Double cGSTAmt;
	
	@SerializedName("SGSTRt")
	private Double sGSTRt;
	
	@SerializedName("SGSTAmt")
	private Double sGSTAmt;
	
	@SerializedName("CessRt")
	private Double cessRt;
	
	@SerializedName("CessAmt")
	private Double cessAmt;
	
	@SerializedName("InvoiceDetailsId")
	private Integer invoiceDetailsId;
	
	@SerializedName("ITCEligiblity")
	private String iTCEligiblity;
	
	@SerializedName("ItcIgstAmt")
	private Double itcIgstAmt;
	
	@SerializedName("ItcCgstAmt")
	private Double itcCgstAmt;
	
	@SerializedName("ItcSgstAmt")
	private Double itcSgstAmt;
	
	@SerializedName("ItcCessAmt")
	private Double itcCessAmt;
	
	@SerializedName("TcIgstAmt")
	private Double tcIgstAmt;
	
	@SerializedName("TcCgstAmt")
	private Double tcCgstAmt;
	
	@SerializedName("TcSgstAmt")
	private Double tcSgstAmt;
	
	@SerializedName("TcCessAmt")
	private Double tcCessAmt;
	
	@SerializedName("InvTyp")
	private String invTyp;
	
	@SerializedName("CustName")
	private String custName;
	
	@SerializedName("NoteTyp")
	private String noteTyp;
	//private String cTIN;
	
	@SerializedName("NoteNum")
	private Integer noteNum;
	
	@SerializedName("NoteDate")
	private Date noteDate;
	
	@SerializedName("OrgNoteNum")
	private Integer orgNoteNum;
	
	@SerializedName("OrgNoteDate")
	private Integer orgNoteDate;
	
	@SerializedName("Reason")
	private String reason;
	
	@SerializedName("DiffValue")
	private Double diffValue;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCustGSTIN() {
		return custGSTIN;
	}
	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}
	public String getCntrPrtyFilingStatus() {
		return cntrPrtyFilingStatus;
	}
	public void setCntrPrtyFilingStatus(String cntrPrtyFilingStatus) {
		this.cntrPrtyFilingStatus = cntrPrtyFilingStatus;
	}
	public String getInvNum() {
		return invNum;
	}
	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}
	public Date getInvDate() {
		return invDate;
	}
	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}
	public Double getInvValue() {
		return invValue;
	}
	public void setInvValue(Double invValue) {
		this.invValue = invValue;
	}
	public String getpOS() {
		return pOS;
	}
	public void setpOS(String pOS) {
		this.pOS = pOS;
	}
	public String getRevChrg() {
		return revChrg;
	}
	public void setRevChrg(String revChrg) {
		this.revChrg = revChrg;
	}
	public String getOrgInvNum() {
		return orgInvNum;
	}
	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}
	public Date getOrgInvDt() {
		return orgInvDt;
	}
	public void setOrgInvDt(Date orgInvDt) {
		this.orgInvDt = orgInvDt;
	}
	public String getInvoiceUploader() {
		return invoiceUploader;
	}
	public void setInvoiceUploader(String invoiceUploader) {
		this.invoiceUploader = invoiceUploader;
	}
	public Double getTaxableValue() {
		return taxableValue;
	}
	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getIsAccepted() {
		return isAccepted;
	}
	public void setIsAccepted(String isAccepted) {
		this.isAccepted = isAccepted;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getLineNo() {
		return lineNo;
	}
	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}
	public String getItemStatus() {
		return itemStatus;
	}
	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String gethSNSC() {
		return hSNSC;
	}
	public void sethSNSC(String hSNSC) {
		this.hSNSC = hSNSC;
	}
	
	public Double getItemTxval() {
		return itemTxval;
	}
	public void setItemTxval(Double itemTxval) {
		this.itemTxval = itemTxval;
	}
	public Double getiGSTRt() {
		return iGSTRt;
	}
	public void setiGSTRt(Double iGSTRt) {
		this.iGSTRt = iGSTRt;
	}
	public Double getiGSTAmt() {
		return iGSTAmt;
	}
	public void setiGSTAmt(Double iGSTAmt) {
		this.iGSTAmt = iGSTAmt;
	}
	public Double getcGSTRt() {
		return cGSTRt;
	}
	public void setcGSTRt(Double cGSTRt) {
		this.cGSTRt = cGSTRt;
	}
	public Double getcGSTAmt() {
		return cGSTAmt;
	}
	public void setcGSTAmt(Double cGSTAmt) {
		this.cGSTAmt = cGSTAmt;
	}
	public Double getsGSTRt() {
		return sGSTRt;
	}
	public void setsGSTRt(Double sGSTRt) {
		this.sGSTRt = sGSTRt;
	}
	public Double getsGSTAmt() {
		return sGSTAmt;
	}
	public void setsGSTAmt(Double sGSTAmt) {
		this.sGSTAmt = sGSTAmt;
	}
	public Double getCessRt() {
		return cessRt;
	}
	public void setCessRt(Double cessRt) {
		this.cessRt = cessRt;
	}
	public Double getCessAmt() {
		return cessAmt;
	}
	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}
	public Integer getInvoiceDetailsId() {
		return invoiceDetailsId;
	}
	public void setInvoiceDetailsId(Integer invoiceDetailsId) {
		this.invoiceDetailsId = invoiceDetailsId;
	}
	public String getiTCEligiblity() {
		return iTCEligiblity;
	}
	public void setiTCEligiblity(String iTCEligiblity) {
		this.iTCEligiblity = iTCEligiblity;
	}
	public Double getItcIgstAmt() {
		return itcIgstAmt;
	}
	public void setItcIgstAmt(Double itcIgstAmt) {
		this.itcIgstAmt = itcIgstAmt;
	}
	public Double getItcCgstAmt() {
		return itcCgstAmt;
	}
	public void setItcCgstAmt(Double itcCgstAmt) {
		this.itcCgstAmt = itcCgstAmt;
	}
	public Double getItcSgstAmt() {
		return itcSgstAmt;
	}
	public void setItcSgstAmt(Double itcSgstAmt) {
		this.itcSgstAmt = itcSgstAmt;
	}
	public Double getItcCessAmt() {
		return itcCessAmt;
	}
	public void setItcCessAmt(Double itcCessAmt) {
		this.itcCessAmt = itcCessAmt;
	}
	public Double getTcIgstAmt() {
		return tcIgstAmt;
	}
	public void setTcIgstAmt(Double tcIgstAmt) {
		this.tcIgstAmt = tcIgstAmt;
	}
	public Double getTcCgstAmt() {
		return tcCgstAmt;
	}
	public void setTcCgstAmt(Double tcCgstAmt) {
		this.tcCgstAmt = tcCgstAmt;
	}
	public Double getTcSgstAmt() {
		return tcSgstAmt;
	}
	public void setTcSgstAmt(Double tcSgstAmt) {
		this.tcSgstAmt = tcSgstAmt;
	}
	public Double getTcCessAmt() {
		return tcCessAmt;
	}
	public void setTcCessAmt(Double tcCessAmt) {
		this.tcCessAmt = tcCessAmt;
	}
	public String getInvTyp() {
		return invTyp;
	}
	public void setInvTyp(String invTyp) {
		this.invTyp = invTyp;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getNoteTyp() {
		return noteTyp;
	}
	public void setNoteTyp(String noteTyp) {
		this.noteTyp = noteTyp;
	}
	public Integer getNoteNum() {
		return noteNum;
	}
	public void setNoteNum(Integer noteNum) {
		this.noteNum = noteNum;
	}
	public Date getNoteDate() {
		return noteDate;
	}
	public void setNoteDate(Date noteDate) {
		this.noteDate = noteDate;
	}
	public Integer getOrgNoteNum() {
		return orgNoteNum;
	}
	public void setOrgNoteNum(Integer orgNoteNum) {
		this.orgNoteNum = orgNoteNum;
	}
	public Integer getOrgNoteDate() {
		return orgNoteDate;
	}
	public void setOrgNoteDate(Integer orgNoteDate) {
		this.orgNoteDate = orgNoteDate;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Double getDiffValue() {
		return diffValue;
	}
	public void setDiffValue(Double diffValue) {
		this.diffValue = diffValue;
	}

}
