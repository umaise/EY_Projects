package com.ey.advisory.asp.storm.topology;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.Collection;

import org.drools.compiler.builder.impl.KnowledgeBuilderConfigurationImpl;
import org.drools.core.util.DroolsStreamUtils;
import org.kie.api.io.ResourceType;
import org.kie.internal.builder.KnowledgeBuilder;
import org.kie.internal.builder.KnowledgeBuilderConfiguration;
import org.kie.internal.builder.KnowledgeBuilderFactory;
import org.kie.internal.definition.KnowledgePackage;
import org.kie.internal.io.ResourceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.configs.ASPStormProperties;
import com.ey.advisory.asp.common.configs.YamlConfigRunner;

/**
 * Run this file before maven build. Make sure you check-in serialized files to SVN.
 * This class will compile the .drl files and place serialized(.ser) file in /resources
 * 
 * @author Mayank3.Kumar
 *
 */
public class DRLSerializer {
	private final static Logger log = LoggerFactory.getLogger(DRLSerializer.class);
	
	public static void preCompileDrls(String drlFilePath, String serializedName) {
		String path="/";
		try{
		KnowledgeBuilderConfiguration kbuilderConf = KnowledgeBuilderFactory
				.newKnowledgeBuilderConfiguration();
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder(kbuilderConf);
		
		kbuilder.add(ResourceFactory
				.newClassPathResource(drlFilePath),
				ResourceType.DRL);

		Collection<KnowledgePackage> knowledgePackages = (Collection<KnowledgePackage>) DroolsStreamUtils
				.streamIn(DroolsStreamUtils.streamOut(kbuilder
						.getKnowledgePackages()),
						((KnowledgeBuilderConfigurationImpl) kbuilderConf)
								.getClassLoader());
		ClassLoader classLoader = DRLSerializer.class.getClassLoader();
		URL serURL = classLoader.getResource("rules/");
		File fullPathToSubfolder = new File(serURL.toURI()).getAbsoluteFile();
		String projectFolder = fullPathToSubfolder.getAbsolutePath().split("target")[0];		
		FileOutputStream fout = new FileOutputStream(projectFolder+"src\\main\\resources\\"+serializedName);
		ObjectOutputStream oos = new ObjectOutputStream(fout);
		oos.writeObject(knowledgePackages);
		oos.flush();
		oos.close();
		}catch(Exception e){
			log.error("Error Precompiling Drl file: " + drlFilePath, e);
			throw new RuntimeException(e);
		}
			
	}

	public static void main(String[] args) {
		System.out.println("Precompiling Drl file: ");
		preCompileDrls("rules/GSTR1/GSTR1_Classification.drl", "GSTR1_classification.ser");
		preCompileDrls("rules/GSTR1/GSTR1_LineItemValidation.drl", "GSTR1_LineItemValidation.ser");
		preCompileDrls("rules/GSTR2/GSTR2_Classification.drl", "GSTR2_Classification.ser");
		preCompileDrls("rules/GSTR2/GSTR2_LineItemValidation.drl", "GSTR2_LineItemValidation.ser");
		preCompileDrls("rules/GSTR2/GSTR2_Reconciliation.drl", "GSTR2_Reconciliation.ser");
		log.info("DRL to .SER file conversion done !!");
		System.out.println("Done !!");
	}
}
