package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * The persistent class for the tblErrorAction database table.
 * 
 */

public class TblSalesErrorInfo implements Serializable {
	private static final long serialVersionUID = 1L;


	private String gstin;
	
	private Integer errorInfoID;  

	private String createdBy;

	private String errorColumnId;

	private String errorDesc;

	private String errorInfoCode;

	private boolean isProcessed;

	private String processStatus;

	private String incidenceLevel;
	
	private char isError;
	
	private Timestamp createDate;
	
	private String invoiceKey;
	
	private Integer lineNo;
	
	private Integer salesStagingID;
	
	private Integer fileId;
	
	private String taxPeriod;
	
	public TblSalesErrorInfo(Integer salesStagingID,Integer fileId,String invoiceKey, String errorInfoCode, String errorDesc, String errorColumnId,
			String processStatus, boolean isProcessed, String gstin,String incidenceLevel, char isError, Integer lineNo, String taxPeriod) {
		this.invoiceKey=invoiceKey;
		this.errorInfoCode=errorInfoCode;
		this.errorDesc=errorDesc;
		this.errorColumnId=errorColumnId;
		this.processStatus=processStatus;
		this.isProcessed=isProcessed;
		this.gstin=gstin;
		this.incidenceLevel=incidenceLevel;
		this.isError = isError;
		this.lineNo = lineNo;
		this.salesStagingID=salesStagingID;
		this.fileId=fileId;
		this.taxPeriod = taxPeriod;
	}

	public char getIsError() {
        return isError;
    }

    public void setIsError(char isError) {
        this.isError = isError;
    }


	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	
	public Integer getErrorInfoID() {
		return this.errorInfoID;
	}

	public void setErrorInfoID(Integer errorInfoID) {
		this.errorInfoID = errorInfoID;
	}


	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getErrorDesc() {
		return this.errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getErrorInfoCode() {
		return this.errorInfoCode;
	}

	public void setErrorInfoCode(String errorInfoCode) {
		this.errorInfoCode = errorInfoCode;
	}

	public boolean getIsProcessed() {
		return this.isProcessed;
	}

	public void setIsProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public String getIncidenceLevel() {
		return incidenceLevel;
	}

	public void setIncidenceLevel(String incidenceLevel) {
		this.incidenceLevel = incidenceLevel;
	}

	public Timestamp getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	public String getErrorColumnId() {
		return errorColumnId;
	}

	public void setErrorColumnId(String errorColumnId) {
		this.errorColumnId = errorColumnId;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public Integer getLineNo() {
		return lineNo;
	}

	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}

	public Integer getSalesStagingID() {
		return salesStagingID;
	}

	public void setSalesStagingID(Integer salesStagingID) {
		this.salesStagingID = salesStagingID;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	
	
}