package com.ey.advisory.asp.storm.bolt.common;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.error.LogGSTR2RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.exceptions.RESTCallFailureException;
import com.ey.advisory.asp.service.gstr2.Gstr2ValidationRuleService;
import com.ey.advisory.asp.service.gstr2.Gstr2ValidationRuleServiceImpl;


public class GSTR2RedisWSBolt extends CustomBaseRichBolt {

    private CustomOutputCollector collector;

    private Gstr2ValidationRuleService ValidationRuleService;

    //private Integer count=0;
    private final Logger log = LoggerFactory.getLogger(getClass());
    @Override
    public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
        this.collector = collector;
        ValidationRuleService = new Gstr2ValidationRuleServiceImpl();	   		
    }

    @Override
    public void execute(Tuple input) {

        log.info("In GSTR2RedisWSBolt.execute() start");

        InwardInvoiceDTO inwardInvoiceDTO = null;
        LogRunTimeErros logRunTimeErros = new LogGSTR2RunTimeErros();
        
        try{
        inwardInvoiceDTO = (InwardInvoiceDTO) input.getValue(0);	

        RedisTemplate<String,Object> redisTemplate=JedisConnectionUtil.getRedisTemplateKVStringObject();

        RedisTemplate<String, Integer> redisIntegertemplate=JedisConnectionUtil.getRedisTemplateKVStringInteger();
        redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.setValueSerializer(new GenericToStringSerializer<Integer>(Integer.class));
        redisIntegertemplate.afterPropertiesSet();


        String redisKey=inwardInvoiceDTO.getRedisKey();
        String invStatusKey=redisKey+"_"+Constant.INVOICE_STATUS;
        String invErrKey=redisKey+"_"+Constant.INVOICE_ERROR_DETAILS;
        String invProcessedKey=redisKey+"_"+Constant.INVOICE_PSD_COUNT;

        InwardInvoiceModel inwardStagingDetail=inwardInvoiceDTO.getLineItemList().get(0);
        Set<InvoiceProcessDto> invProcessSet = new HashSet<>();
        log.info("rediskey : " + redisKey + " InvOrder : "+ inwardStagingDetail.getInvOrder());
        
        if(inwardInvoiceDTO != null && inwardInvoiceDTO.getLineItemList() != null && !inwardInvoiceDTO.getLineItemList().isEmpty()){
        	for(InwardInvoiceModel lineItem : inwardInvoiceDTO.getLineItemList()){
        		
        		InvoiceProcessDto invProcessDto = new InvoiceProcessDto(lineItem.getDocumentNo(), lineItem.getDocumentDate(), lineItem.getTaxPeriod(), inwardStagingDetail.getTableType(), inwardInvoiceDTO.getInvStatus(),
        				lineItem.getInvOrder(), lineItem.getSGSTIN(), lineItem.getCGSTIN(),	inwardStagingDetail.getSubCategory(), lineItem.getEligibilityIndicator(),lineItem.getAvailableCESS(), 
        				lineItem.getAvailableCGST(), lineItem.getAvailableIGST(), lineItem.getAvailableSGST(), lineItem.getLineNumber());
        		
        		invProcessSet.add(invProcessDto);
        		
        	}
        	
        	redisTemplate.opsForHash().put(invStatusKey,inwardStagingDetail.getInvOrder(),invProcessSet);
        	//added for chunk as gstr1.. confirm with mayank kumar
        	redisTemplate.opsForHash().put(invProcessedKey,inwardStagingDetail.getInvOrder(),inwardStagingDetail.getInvOrder());
        }
        

        Set<TblPurchaseErrorInfo> errorList=inwardInvoiceDTO.getErrorList();

        if(errorList!=null && !errorList.isEmpty()){
            /*errorSet.addAll(errorList);
            redisTemplate.opsForHash().put(redisKey, invErrKey,errorSet);*/
        		redisTemplate.opsForHash().put(invErrKey, inwardStagingDetail.getInvOrder(), errorList);
        }

        //collector.emit(input,new Values(inwardInvoiceDTO));
        
        }catch(Exception ex){
        	log.error("Error GSTR2RedisWSBolt", ex);
            logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
        }finally{

        collector.ack(input);
        log.info("In GSTR2RedisWSBolt.execute() end");
        }
    }

    @Override
    public void cleanup() {
        super.cleanup();
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
    	declarer.declare(new Fields("gstr2"));
       // declarer.declareStream(Constant.GSTR2_Stream1,new Fields("gstr2"));

    }
}

