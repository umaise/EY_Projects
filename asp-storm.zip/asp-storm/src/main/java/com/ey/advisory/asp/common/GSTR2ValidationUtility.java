package com.ey.advisory.asp.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jersey.api.client.ClientResponse;

public class GSTR2ValidationUtility {
	
	private final static Logger log = LoggerFactory.getLogger(GSTR2ValidationUtility.class);
	

	public static String loadHsnSac(String hsnSac, String groupCode){
		String result ="";
		ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, "asp-restapi.fetchParticaularHsnsac", groupCode, hsnSac, Constant.VERB_TYPE_POST);
		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			result = response.getEntity(String.class);
		}
		
		System.out.println(result);
		return result;
		
		}
		
		
					
	}
