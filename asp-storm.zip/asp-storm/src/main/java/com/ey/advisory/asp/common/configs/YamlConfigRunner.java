package com.ey.advisory.asp.common.configs;

import org.apache.storm.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;
import java.io.InputStream;


public class YamlConfigRunner {
	private final static Logger log = LoggerFactory.getLogger(YamlConfigRunner.class);
	
	
	public static void loadRedisConfigsLOCAL(InputStream in, Config stormConf){				
	 Yaml yaml = new Yaml();  	 
     try{
    	 Configurations config = yaml.loadAs( in, Configurations.class );
    	 log.info("Loading conf for redis : ");
    	 log.info(config.toString());
    	 stormConf.putAll(config.getConfig());
     } catch (Exception e) {
    	 log.error("Error in loading redis's yaml configs",e);
		//e.printStackTrace();
	}
     
	}
	
	public static void loadRESTConfigsLOCAL(InputStream in, Config stormConf){				
		 Yaml yaml = new Yaml();  	 
	     try {
	    	 Configurations config = yaml.loadAs( in, Configurations.class );
	    	 log.info("Loading conf for REST : ");
	    	 log.info(config.toString());
	    	 stormConf.putAll(config.getConfig());
	     } catch (Exception e) {
	    	 log.error("Error in loading REST yaml configs",e);
			//e.printStackTrace();
		}
	     
		}
}
