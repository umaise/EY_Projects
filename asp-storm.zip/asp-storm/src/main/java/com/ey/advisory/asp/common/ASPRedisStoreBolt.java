package com.ey.advisory.asp.common;

import org.apache.storm.redis.bolt.RedisStoreBolt;
import org.apache.storm.redis.common.config.JedisPoolConfig;
import org.apache.storm.redis.common.mapper.RedisStoreMapper;

public class ASPRedisStoreBolt extends RedisStoreBolt{
	
	public ASPRedisStoreBolt(JedisPoolConfig config, RedisStoreMapper storeMapper) {
		super(config, storeMapper);
	}
}
