package com.ey.advisory.asp.storm.bolt.common;

import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.exceptions.RESTCallFailureException;

public class GSTR2ARestCallBolt extends BoltBuilder {

	private CustomOutputCollector collector;
    RestClientUtility restClientUtil = null;

    private final Logger log = LoggerFactory.getLogger(getClass());
    @Override
    public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
        this.collector = collector;
        restClientUtil = new RestClientUtility();
    }
	@Override
	public void execute(Tuple input) {
        ReconciliationDTO reconDTO = null;
        long startTime=System.currentTimeMillis();
        try{
            log.info("In GSTR1RestCallBolt.execute() start");
            
            reconDTO = (ReconciliationDTO) input.getValueByField("inv");
        	log.info("In GSTR1RestCallBolt  redis key : "+reconDTO.getRedisKey() + " Recon Status Id : "+reconDTO.getReconStatusId());
        	
        	Integer incInvCnt=(Integer) input.getValueByField("invCount");
        	
			Long incPsdCnt=(Long) input.getValueByField("invPsdCnt");
        	
			Integer invPsdCnt= incPsdCnt.intValue();
        	log.info("Invoice Count > "+incInvCnt);
        	log.info("Invoice processed Count > "+incPsdCnt);
         
            if(invPsdCnt!=null && invPsdCnt.equals(incInvCnt)){
                log.info("Going to call GSTR1 save rest call for "+reconDTO.getRedisKey());
                log.info("Invoice Count >> "+incInvCnt);
                log.info("Invoice processed Count >> "+incPsdCnt);  
                
                try{
                	collector.ack(input);
                    restClientUtil.callRestServiceJersey(reconDTO.getRedisKey(), reconDTO.getGroupCode(),Constant.REST_HOSTNAME+Constant.UPDATE_RECON_FILING_REST);
                }catch(RESTCallFailureException e){
                    log.error("Exception in Bolt GSTR1RestCallBolt due to REST call failure : ", e);
                    //collector.customReportError(input, e, "Exception in Bolt GSTR1RestCallBolt due to REST call failure");
                }	
            }

        }
        catch(Exception ex){			
            log.error("Error in bolt GSTR1RestCallBolt : ", ex);
            //logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
        }
        finally {
            collector.ack(input);
            if(log.isInfoEnabled())
            	log.info("In GSTR1RestCallBolt Time taken for file : "+reconDTO.getRedisKey()+" Recon Status Id : "+ reconDTO.getReconStatusId() +" is "+(System.currentTimeMillis()-startTime));
        }
        
       
    }

	@Override
	public void declareOutputFields(OutputFieldsDeclarer arg0) {
		// TODO Auto-generated method stub
		
	}

}
