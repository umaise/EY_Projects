package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import com.ey.advisory.asp.dto.InvoiceDTO;

public class SystemErrorLogInfo implements Serializable{	
		
	private static final long serialVersionUID = 9051558291364559664L;
	
	private String boltMessage;
	private Date ts;
	private Throwable boltException;
	private InvoiceDTO invoiceDTO;
	
	
	public SystemErrorLogInfo(String boltMessage,Date ts,Throwable boltException,InvoiceDTO invoiceDTO){
		this.boltMessage=boltMessage;
		this.ts=ts;
		this.boltException=boltException;	
		this.invoiceDTO=invoiceDTO;
	}
	public InvoiceDTO getInvoiceDTO() {
		return invoiceDTO;
	}
	public void setInvoiceDTO(InvoiceDTO invoiceDTO) {
		this.invoiceDTO = invoiceDTO;
	}
	public String getBoltMessage() {
		return boltMessage;
	}
	public void setBoltMessage(String boltMessage) {
		this.boltMessage = boltMessage;
	}
	public Date getTs() {
		return ts;
	}
	public void setTs(Date ts) {
		this.ts = ts;
	}
	public Throwable getBoltException() {
		return boltException;
	}
	public void setBoltException(Throwable boltException) {
		this.boltException = boltException;
	}	

}
