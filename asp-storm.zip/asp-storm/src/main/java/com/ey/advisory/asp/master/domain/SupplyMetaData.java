package com.ey.advisory.asp.master.domain;
import java.io.Serializable;


public class SupplyMetaData implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Long Id;
	private String columnName;
	private Integer columnOrderNo;
	private String columnCode;
	private String dataType;
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	
	public void setColumnOrderNo(Integer columnOrderNo) {
		this.columnOrderNo = columnOrderNo;
	}
	public void setColumnCode(String columnCode) {
		this.columnCode = columnCode;
	}
	
	public String getColumnCode() {
		return columnCode;
	}
	public Integer getColumnOrderNo() {
		return columnOrderNo;
	}

	
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	
	
}
