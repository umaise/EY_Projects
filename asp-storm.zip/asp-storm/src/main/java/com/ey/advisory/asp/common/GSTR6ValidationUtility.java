package com.ey.advisory.asp.common;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.dto.InwardInvoiceGstr6DTO;
import com.sun.jersey.api.client.ClientResponse;

public class GSTR6ValidationUtility {
	
	private RedisTemplate<String, Object> redisTemplate;
	
	private final static Logger log = LoggerFactory.getLogger(GSTR6ValidationUtility.class);
	
	public GSTR6ValidationUtility(){
		 redisTemplate=JedisConnectionUtil.getRedisTemplateKVStringObject();
	}
	

	public static String loadHsnSac(String hsnSac, String groupCode){
		String result ="";
		ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host", "asp-restapi.fetchParticaularHsnsacISD", groupCode, hsnSac, Constant.VERB_TYPE_POST);
		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			result = response.getEntity(String.class);
		}
		
		return result;
		
		}
	
	public static String fetchEligibleIndicator(InwardInvoiceModel inwardInvoiceModel,InwardInvoiceGstr6DTO inwardInvoiceDTO, String groupCode){
		String result ="";
		log.info("Gstr6 file Document No : "+inwardInvoiceModel.getDocumentNo());
		ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host", "asp-restapi.retrieveGstr6Invoice", groupCode, inwardInvoiceModel.getOriginalDocumentNo(),  Constant.VERB_TYPE_POST);
		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			result = response.getEntity(String.class);
		}
		return result;
	}

	public static String fetchCRTaxableValue(InwardInvoiceModel inwardInvoiceModel,InwardInvoiceGstr6DTO inwardInvoiceDTO, String groupCode){

		String result ="";
		log.info("Gstr6 file original Document No : "+inwardInvoiceModel.getOriginalDocumentNo());
		ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host", "asp-restapi.fetchGstr6CRTaxableValue", groupCode, inwardInvoiceModel.getOriginalDocumentNo(),  Constant.VERB_TYPE_POST);
		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			result = response.getEntity(String.class);
		}
		return result;
	}
	
	public static String fetchDocumentDetails(InwardInvoiceGstr6DTO inwardInvoiceDTO, String groupCode){

		String result ="";
		
		ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host", "asp-restapi.fetchGstr6CRdocumentValue", groupCode, inwardInvoiceDTO.getRedisKey(),  Constant.VERB_TYPE_POST);
		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			result = response.getEntity(String.class);
		}
		return result;
	}
	
	public static String fetchInvoiceNo(InwardInvoiceModel inwardInvoiceModel, InwardInvoiceGstr6DTO inwardInvoiceDTO, String groupCode){
		String result ="";
		log.info("Gstr6 file Invoice Key : "+inwardInvoiceModel.getInvoiceKey());
		ClientResponse response = new RestClientUtility().getRestServiceResponse("GSTR6_Host", "asp-restapi.fetchInvoiceNo", groupCode, inwardInvoiceModel.getInvoiceKey(),  Constant.VERB_TYPE_POST);
		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			result = response.getEntity(String.class);
		}
		return result;
	}
	
	}

