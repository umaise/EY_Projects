package com.ey.advisory.asp.redis.mapper;

import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;

public class SaleRegRedisCompute  extends CustomBaseRichBolt {
	
	private final Logger log = LoggerFactory.getLogger(getClass());
	private CustomOutputCollector collector;

	@Override
    public void execute(Tuple input) {
		  int count=0;
	        String key="";
		try{
        StringBuffer keyGen=new StringBuffer();
        OutwardInvoiceModel stgTable=null;
        	/*RedisTemplateUtil<String, Object> redisTemplateUtil= new RedisTemplateUtil<String, Object>();
            RedisTemplate<String,Object> redisTemplate=redisTemplateUtil.getRedisTemplate();*/
        	RedisTemplate<String,Object> redisTemplate=JedisConnectionUtil.getRedisTemplateKVStringObject();
        	
           /*redisTemplate.setKeySerializer(new StringRedisSerializer());
            redisTemplate.setHashKeySerializer(new StringRedisSerializer());
            redisTemplate.setValueSerializer(new StringRedisSerializer());
            redisTemplate.setHashValueSerializer(new StringRedisSerializer());
            redisTemplate.afterPropertiesSet();*/
            //OutwardInvoiceDTO outwardInvoiceDTO = (OutwardInvoiceDTO) input.getValueByField("inv");
            OutwardInvoiceDTO outwardInvoiceDTO = (OutwardInvoiceDTO) input.getValue(0);
            
            if(outwardInvoiceDTO.getLineItemList()!=null && !outwardInvoiceDTO.getLineItemList().isEmpty()){
            	stgTable = outwardInvoiceDTO.getLineItemList().get(0);
            }
            
            if(stgTable!=null){
            if(outwardInvoiceDTO.getInvStatus() !=null && outwardInvoiceDTO.getInvStatus().equalsIgnoreCase(Constant.GSTR1_BR_STG1) ){
				keyGen.append(stgTable.getFileID()).append("~").append(stgTable.getTableType()).append(Constant.PROCESSED_SUCCESS);
			}else{
				keyGen.append(stgTable.getFileID()).append("~").append(stgTable.getTableType()).append(Constant.PROCESSED_ERROR);
			}
            
            key = keyGen.toString().toLowerCase();
            if(redisTemplate.opsForHash().get(Constant.REDIS_INVOICE_CHANNEL, key)==null){
            	//map.put(key, Constant.ZERO);
            	redisTemplate.opsForHash().put(Constant.REDIS_INVOICE_CHANNEL,key,Constant.INTIEGER_ZERO);
            	
            }
           else{
            		count=(Integer) redisTemplate.opsForHash().get(Constant.REDIS_INVOICE_CHANNEL,key);
            		//count=Integer.parseInt(countStr)+1;
            		count=count+1;
            		//map.put(key, Integer.toString(count));
            		redisTemplate.opsForHash().put(Constant.REDIS_INVOICE_CHANNEL,key,count);
            	}
            }
            collector.ack(input);
            this.collector.emit(new Values(key,count));
			//collector.emit(Constant.GSTR1_COMMON_PUBREDIS_Stream,new Values(key,count));			
			
            
		}
		
		catch(Exception ex){			
			log.error("Error SaleRegRedisCompute", ex);
			collector.customReportError(input, ex, "Exception in Bolt SaleRegRedisCompute");
			}
		finally {			
			collector.ack(input);
			this.collector.emit(new Values(key,count));
			//collector.emit(Constant.GSTR1_COMMON_PUBREDIS_Stream,new Values(key,count));		

		}
            
        
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("tabletype", "count"));
		//declarer.declareStream(Constant.GSTR1_COMMON_PUBREDIS_Stream, new Fields("tabletype", "count"));

    }

	@Override
	public void prepare(Map stormConf, TopologyContext arg1, CustomOutputCollector collector) {
		this.collector = collector;         		
	}
	
}
