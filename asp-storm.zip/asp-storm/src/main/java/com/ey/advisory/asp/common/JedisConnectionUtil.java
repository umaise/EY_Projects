package com.ey.advisory.asp.common;


import java.util.Properties;

import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.common.configs.ASPStormProperties;
import com.ey.advisory.asp.common.configs.PasswordProtection;

import redis.clients.jedis.JedisPoolConfig;

public class JedisConnectionUtil {
	
	private static volatile JedisConnectionFactory jedisConnectionFactory;

	private static JedisConnectionFactory createJedisConnectionFactory(){
		JedisPoolConfig jedisPoolConfig;		
		try {			
			
			Properties props= ASPStormProperties.getAllProperties();
			
			String hostname = props.getProperty(Constant.REDIS_HOST);
			int port = Integer.parseInt(props.getProperty(Constant.REDIS_PORT));			
			int poolMaxActive=Integer.parseInt(props.getProperty(Constant.REDIS_POOL_MAX_ACTIVE));
			int poolMaxIdle=Integer.parseInt(props.getProperty(Constant.REDIS_POOL_MAX_IDLE));
			long poolMaxWait=Long.parseLong(props.getProperty(Constant.REDIS_POOL_MAX_WAIT));
			boolean testOnBorrow=Boolean.parseBoolean(props.getProperty(Constant.REDIS_POOL_TEST_ON_BORROW));
			int timeOut=Integer.parseInt(props.getProperty(Constant.REDIS_TIME_OUT));
			boolean isPasswordEncrypted=Boolean.parseBoolean(props.getProperty(Constant.REDIS_PASSWORD_ENC));
			String password=props.getProperty(Constant.REDIS_PASSWORD);
			
			
		
			/*String hostname = "localhost";
			int port = 6379;
			int poolMaxActive= 100;
			int poolMaxIdle= 10;
			long poolMaxWait=10000;
			boolean testOnBorrow=true;
			int timeOut=5000;
			boolean isPasswordEncrypted=false;
			String password="";*/

			
			if(isPasswordEncrypted){
				password = PasswordProtection.getDecriptedPassword(password);
			}
			
			jedisPoolConfig=new JedisPoolConfig();
			jedisPoolConfig.setMaxTotal(poolMaxActive);
			jedisPoolConfig.setMaxIdle(poolMaxIdle);
			jedisPoolConfig.setMaxWaitMillis(poolMaxWait);
			jedisPoolConfig.setTestOnBorrow(testOnBorrow);
			
			jedisConnectionFactory=new JedisConnectionFactory();
			jedisConnectionFactory.setHostName(hostname);
			jedisConnectionFactory.setPort(port);
			jedisConnectionFactory.setPoolConfig(jedisPoolConfig);
			jedisConnectionFactory.setTimeout(timeOut);
			jedisConnectionFactory.setPassword(password);
			
			jedisConnectionFactory.afterPropertiesSet();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return jedisConnectionFactory;
	}
	
	private static JedisConnectionFactory getJedisConnectionFactory(){
		if(jedisConnectionFactory==null){
			synchronized (JedisConnectionFactory.class) {
				if(jedisConnectionFactory==null){
					jedisConnectionFactory=createJedisConnectionFactory();
				}
			}
		}
		return jedisConnectionFactory;
	}	
	
	
	public static RedisTemplate<String,String> getRedisTemplateKVStringString(){
		  RedisTemplate<String,String> redisTemplateWithStringSer = null;
		  redisTemplateWithStringSer = new RedisTemplate<String,String>();
		  redisTemplateWithStringSer.setKeySerializer(new StringRedisSerializer());
		  redisTemplateWithStringSer.setValueSerializer(new StringRedisSerializer());
		  redisTemplateWithStringSer.setConnectionFactory(JedisConnectionUtil.getJedisConnectionFactory());		
		  redisTemplateWithStringSer.afterPropertiesSet();
		return redisTemplateWithStringSer;
	}
	public static RedisTemplate<String,Integer> getRedisTemplateKVStringInteger(){
		  RedisTemplate<String,Integer> redisTemplateWithIntegergSer = null;
		  redisTemplateWithIntegergSer = new RedisTemplate<String,Integer>();
		  redisTemplateWithIntegergSer.setKeySerializer(new StringRedisSerializer());
		  redisTemplateWithIntegergSer.setValueSerializer(new GenericToStringSerializer<Integer>(Integer.class));
		  redisTemplateWithIntegergSer.setConnectionFactory(JedisConnectionUtil.getJedisConnectionFactory());
		  redisTemplateWithIntegergSer.afterPropertiesSet();
		return redisTemplateWithIntegergSer;
	}
	public static RedisTemplate<String, Object> getRedisTemplateKVStringObject(){
		  RedisTemplate<String, Object> redisTemplateWithDefaultSer = null;
		  redisTemplateWithDefaultSer = new RedisTemplate<String,Object>();
		  redisTemplateWithDefaultSer.setKeySerializer(new JdkSerializationRedisSerializer());
		  redisTemplateWithDefaultSer.setValueSerializer(new JdkSerializationRedisSerializer());
		  redisTemplateWithDefaultSer.setConnectionFactory(JedisConnectionUtil.getJedisConnectionFactory());
		  redisTemplateWithDefaultSer.afterPropertiesSet();
		return redisTemplateWithDefaultSer;
	}	
}