package com.ey.advisory.asp;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

public class JasonConversion {
	public static void main(String[] args) throws JsonProcessingException, IOException{
		
		Gson gson = new Gson();

		
		//String sample="{\"Players\":[{\"uid\": \"1\", \"name\": \"Mike\"},{\"uid\": \"2\", \"name\": \"John\"}]}";
		//String sample="[{\"uid\": \"1\", \"name\": \"Mike\"},{\"uid\": \"2\", \"name\": \"John\"}]";
		
		String sample="[{\"ID\":1,\"FileID\":2,\"Group\":\"Shiva\",\"LegalEntity\":\"SKM\",\"Division\":\"Tyres\",\"SupplierIssuerGSTIN\":\"06AAMFS3061K1Z7\",\"Taxperiod\":null,\"DocumentType\":\"ADG\",\"Org_DocType\":null,\"SupplyType\":\"Tax\",\"DocNum\":\"AD01600001\",\"DocumentDate\":null,\"OriginalDocumentNo\":null,\"OriginalDocumentDate\":null,\"LineNoOfDocno\":null,\"CustomerGSTINUIN\":\"06AECPG5123Q0Z1\",\"SalesOrderAgreementNo\":null,\"SalesOrderAgreementDate\":null,\"CustomerCode\":\"11000001\",\"CustomerName\":\"Lakshi Sales Enterprise\",\"CustomerAddress\":\"Haryana\",\"CustomerLocationState\":null,\"PlantCodeSupplier\":null,\"ShipFromLocationSupplier\":null,\"BillState\":\"Haryana\",\"ShipState\":\"Haryana\",\"POS\":null,\"ShippingBillNo\":null,\"ShippingBillDate\":null,\"GoodsServices\":\"G\",\"HSNSAC\":\"82011000\",\"ItemCode\":\"RT0001\",\"ItemDescription\":\"Radial tyre\",\"UnitMeasurement\":\"nos\",\"QtySuppliedinvoiced\":null,\"InvoicedForeignCurrency\":null,\"BasicUnitValue\":null,\"BasicValueQtySupplied\":80000,\"Discount\":null,\"Advance\":null,\"NetBasicValue\":null,\"Othertaxes1\":null,\"TaxableValue\":80000.0,\"TransactionIDAdvances\":\"7912562313\",\"IGSTRate\":null,\"IGSTAmount\":0.0,\"CGSTRate\":0.08,\"CGSTAmount\":7200.0,\"SGSTRate\":0.08,\"SGSTAmount\":7200.0,\"CessRate\":null,\"CessAmount\":null,\"ValueIncludingTax\":94400.0,\"Othertaxes2\":null,\"ValueIncludingTaxes\":null,\"IndicateSupplyAttractsReversecharge\":null,\"TaxPaidUnderProvisionalAssessment\":null,\"GSTINEOperator\":null,\"MerchantID\":null,\"SubjectToTDS\":null,\"SupplierERN\":null,\"SupplierERNDate\":null,\"TransporterName\":null,\"LorryReceiptNumber\":null,\"LorryReceiptDate\":null,\"PaymentAmountReceived\":null,\"DateReceiptFromRecepient\":null,\"SupplyGoodsServicesReferenceDocumentNumber\":null,\"DateSupplyGoodsServices\":null,\"PsnlCnsmptnLstDstrydGiftwoffsamples\":null,\"Vouchers\":null,\"VouchersIssueDate\":null,\"VoucherRedemptionDate\":null,\"SupStCd\":null,\"CustStCd\":null,\"ShipStateCd\":null,\"POSCd\":null,\"AggInvoice\":null,\"AggTaxableValue\":null,\"Rank\":1},{\"ID\":2,\"FileID\":2,\"Group\":\"Shiva\",\"LegalEntity\":\"SKM\",\"Division\":\"Tyres\",\"SupplierIssuerGSTIN\":\"06AAMFS3061K1Z7\",\"Taxperiod\":null,\"DocumentType\":\"ADG\",\"Org_DocType\":null,\"SupplyType\":\"Tax\",\"DocNum\":\"AD01600001\",\"DocumentDate\":null,\"OriginalDocumentNo\":null,\"OriginalDocumentDate\":null,\"LineNoOfDocno\":null,\"CustomerGSTINUIN\":\"06AECPG5123Q0Z1\",\"SalesOrderAgreementNo\":null,\"SalesOrderAgreementDate\":null,\"CustomerCode\":\"11000001\",\"CustomerName\":\"Lakshi Sales Enterprise\",\"CustomerAddress\":\"Haryana\",\"CustomerLocationState\":null,\"PlantCodeSupplier\":null,\"ShipFromLocationSupplier\":null,\"BillState\":\"Haryana\",\"ShipState\":\"Haryana\",\"POS\":null,\"ShippingBillNo\":null,\"ShippingBillDate\":null,\"GoodsServices\":\"G\",\"HSNSAC\":\"23069021\",\"ItemCode\":\"TT0001\",\"ItemDescription\":\"Tubeless tyre\",\"UnitMeasurement\":\"nos\",\"QtySuppliedinvoiced\":null,\"InvoicedForeignCurrency\":null,\"BasicUnitValue\":null,\"BasicValueQtySupplied\":20000,\"Discount\":null,\"Advance\":null,\"NetBasicValue\":null,\"Othertaxes1\":null,\"TaxableValue\":20000.0,\"TransactionIDAdvances\":\"7912562313\",\"IGSTRate\":null,\"IGSTAmount\":null,\"CGSTRate\":0.08,\"CGSTAmount\":1800.0,\"SGSTRate\":0.08,\"SGSTAmount\":1800.0,\"CessRate\":null,\"CessAmount\":null,\"ValueIncludingTax\":23600.0,\"Othertaxes2\":null,\"ValueIncludingTaxes\":null,\"IndicateSupplyAttractsReversecharge\":null,\"TaxPaidUnderProvisionalAssessment\":null,\"GSTINEOperator\":null,\"MerchantID\":null,\"SubjectToTDS\":null,\"SupplierERN\":null,\"SupplierERNDate\":null,\"TransporterName\":null,\"LorryReceiptNumber\":null,\"LorryReceiptDate\":null,\"PaymentAmountReceived\":null,\"DateReceiptFromRecepient\":null,\"SupplyGoodsServicesReferenceDocumentNumber\":null,\"DateSupplyGoodsServices\":null,\"PsnlCnsmptnLstDstrydGiftwoffsamples\":null,\"Vouchers\":null,\"VouchersIssueDate\":null,\"VoucherRedemptionDate\":null,\"SupStCd\":null,\"CustStCd\":null,\"ShipStateCd\":null,\"POSCd\":null,\"AggInvoice\":null,\"AggTaxableValue\":null,\"Rank\":1}]";
		
		/*final JsonNode arrNode = new ObjectMapper().readTree(sample).get("Players");
		ObjectMapper mapper = new ObjectMapper();
		
		if (arrNode.isArray()) {
		    for (final JsonNode objNode : arrNode) {
		    	Player obj = mapper.readValue(objNode.toString(), Player.class);
		        System.out.println(obj.getName());
		    }
		}*/
		
		//Player[] data = gson.fromJson(sample, Player[].class);
		
		//TblClientSalesStaging[] salStgList=gson.fromJson(sample, TblClientSalesStaging[].class);
		
		Type listType = new TypeToken<List<OutwardInvoiceModel>>(){}.getType();
		List<OutwardInvoiceModel> salStgList=gson.fromJson(sample, listType);
		
		for(OutwardInvoiceModel item:salStgList){
			System.out.println(item.getId());
		}
		
		JsonObject obj=new JsonObject();
		obj.addProperty("type", "val");
		obj.addProperty("cnt", "1");
		System.out.println(obj.toString()); 
	}
}
