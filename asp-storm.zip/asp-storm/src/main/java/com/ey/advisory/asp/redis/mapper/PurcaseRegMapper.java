package com.ey.advisory.asp.redis.mapper;

import org.apache.storm.redis.common.mapper.RedisDataTypeDescription;
import org.apache.storm.redis.common.mapper.RedisStoreMapper;
import org.apache.storm.tuple.ITuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PurcaseRegMapper implements RedisStoreMapper {
	
	private RedisDataTypeDescription description;
	private final String hashKey = "PURCHASE_INVOICE_PROCESSED";
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	public PurcaseRegMapper(){
		description = new RedisDataTypeDescription(
                RedisDataTypeDescription.RedisDataType.HASH, hashKey);
	}
	
	@Override
	public String getKeyFromTuple(ITuple tuple) {
		return tuple.getStringByField("key");
	}

	@Override
	public String getValueFromTuple(ITuple tuple) {
		return tuple.getStringByField("purchaseregdata");
		
	}

	@Override
	public RedisDataTypeDescription getDataTypeDescription() {
		return description;
	}
}