package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import com.google.gson.annotations.SerializedName;

public class OutwardInvoiceModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@SerializedName("Id")
	private int id;
	
	@SerializedName("FileID")
	private int fileID;
	
	@SerializedName("PlantCode")
	private String plantCode;
	
	@SerializedName("SGSTIN")
	private String sGSTIN ;
	
	@SerializedName("TaxPeriod")
	private String taxperiod;
	
	@SerializedName("DocumentType")
	private String documentType;
	
	@SerializedName("SupplyType")
	private String supplyType;
	
	@SerializedName("DocumentNo")
	private String documentNo ;
	
	@SerializedName("DocumentDate")
	private Object documentDate;
	
	@SerializedName("OriginalDocumentNo")
	private String originalDocumentNo;
	
	@SerializedName("OriginalDocumentDate")
	private Object originalDocumentDate;
	
	@SerializedName("LineNumber")
	private String lineNumber ;
	
	@SerializedName("CGSTIN")
	private String cGSTIN ;
	
	@SerializedName("CustomerCode")
	private String customerCode;
	
	@SerializedName("CustomerName")
	private String customerName;
	
	@SerializedName("BillToState")
	private String billToState ;
	
	@SerializedName("ShipToState")
	private String shipToState ;
	
	@SerializedName("POS")
	private String pos;
	
	@SerializedName("ShippingBillNo")
	private String shippingBillNo;

	@SerializedName("ShippingBillDate")
	private Object shippingBillDate;
	
	@SerializedName("HSNSAC")
	private String hsnsac;
	
	@SerializedName("ItemCode")
	private String itemCode;
	
	@SerializedName("ItemDescription")
	private String itemDescription;
	
	@SerializedName("ItemCategory")
	private String itemCategory;
	
	@SerializedName("UnitofMeasurement")
	private String unitofMeasurement ;
	
	@SerializedName("QtySupplied")
	private BigDecimal qtySupplied ;
	
	@SerializedName("TaxableValue")
	private Double taxableValue;
	
	@SerializedName("IGSTAmount")
	private Double igstAmount;

	@SerializedName("IGSTRate")
	private Double igstRate;
	
	@SerializedName("CGSTAmount")
	private Double cgstAmount;

	@SerializedName("CGSTRate")
	private Double cgstRate;
	
	@SerializedName("SGSTAmount")
	private Double sgstAmount;

	@SerializedName("SGSTRate")
	private Double sgstRate;
	
	@SerializedName("ReverseCharge")
	private String reverseCharge ;
	
	@SerializedName("EGSTIN")
	private String eGSTIN;
	
	/*@SerializedName("SupplierERN")
	private String supplierERN;*/
	
	/*@SerializedName("ERNDate")
	private Object eRNDate ;*/
	
	/*@SerializedName("TransportName")
	private String transportName;*/
	
	/*@SerializedName("LorryReceiptNo")
	private String lorryReceiptNo;*/
	
	/*@SerializedName("LorryReceiptDate")
	private String lorryReceiptDate;*/
	
	@SerializedName("AggInvoice")
	private BigDecimal aggInvoice;

	@SerializedName("AggTaxableValue")
	private BigDecimal aggTaxableValue;
	
	@SerializedName("InvOrder")
	private Integer invOrder;
	
	@SerializedName("Status")
	private String status;
	
	@SerializedName("RecordType")
	private String tableType;
	
	@SerializedName("InvoiceKey")
	private String invoiceKey;
	
	@SerializedName("AccountingVoucherNumber")
    private String accountingVoucherNumber ;

    @SerializedName("AccountingVoucherDate")
    private Object accountingVoucherDate;
    
    @SerializedName("CessAmountAdvalorem")
    private Double cessAmountAdvalorem;
    
    @SerializedName("CessAmountSpecific")
    private Double cessAmountSpecific;
    
    @SerializedName("CessRateAdvalorem")
    private Double cessRateAdvalorem;

    @SerializedName("CessRateSpecific")
    private Double cessRateSpecific;
    
    @SerializedName("Division")
    private String division;

    @SerializedName("ExportDuty")
    private Double exportDuty;

    @SerializedName("FOB")
    private Double fob;
    
    /*@SerializedName("GoodsReceiptDate")
    private Object goodsReceiptDate;*/

    @SerializedName("InvoiceValue")
    private Double invoiceValue;

    @SerializedName("IsPreStageError")
    private boolean isPreStageError;

    @SerializedName("ITCFlag")
    private String itcFlag;

    /*@SerializedName("MaterialSentForJobwork")
    private String materialSentForJobwork;*/

    @SerializedName("OriginalCGSTIN")
    private String OriginalCGSTIN;

    @SerializedName("ProfitCentre1")
    private String ProfitCentre1;
    
    @SerializedName("ProfitCentre2")
    private String ProfitCentre2;

    @SerializedName("ReasonForCreditDebitNote")
    private String reasonForCreditDebitNote;

    @SerializedName("SubDivision")
    private String subDivision;
    
    @SerializedName("TCSFlag")
    private String tcsFlag;
    
    @SerializedName("SubCategory")
    private String subCategory;
    
    @SerializedName("SourceIdentifier")
    private String sourceIdentifier;
    
    @SerializedName("SourceFileName")
    private String sourceFileName;
    
    @SerializedName("GLAccountCode")
    private String glAccountCode;
    
    @SerializedName("CRDRPreGST")
    private String cRDRPreGST;
    
    @SerializedName("UINorComposition")
    private String uinORComposition;
    
    @SerializedName("PortCode")
    private String portCode;
    
    @SerializedName("Userdefinedfield1")
    private String userdefinedfield1;
    
    @SerializedName("Userdefinedfield2")
    private String userdefinedfield2;
    
    @SerializedName("Userdefinedfield3")
    private String userdefinedfield3;
	
	private String itemStatus;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFileID() {
		return fileID;
	}

	public void setFileID(int fileID) {
		this.fileID = fileID;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getsGSTIN() {
		return sGSTIN;
	}

	public void setsGSTIN(String sGSTIN) {
		this.sGSTIN = sGSTIN;
	}

	public String getTaxperiod() {
		return taxperiod;
	}

	public void setTaxperiod(String taxperiod) {
		this.taxperiod = taxperiod;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getSupplyType() {
		return supplyType;
	}

	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}

	public String getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public Object getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(Object documentDate) {
		this.documentDate = documentDate;
	}

	public String getOriginalDocumentNo() {
		return originalDocumentNo;
	}

	public void setOriginalDocumentNo(String originalDocumentNo) {
		this.originalDocumentNo = originalDocumentNo;
	}

	public Object getOriginalDocumentDate() {
		return originalDocumentDate;
	}

	public void setOriginalDocumentDate(Object originalDocumentDate) {
		this.originalDocumentDate = originalDocumentDate;
	}

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getcGSTIN() {
		return cGSTIN;
	}

	public void setcGSTIN(String cGSTIN) {
		this.cGSTIN = cGSTIN;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getBillToState() {
		return billToState;
	}

	public void setBillToState(String billToState) {
		this.billToState = billToState;
	}

	public String getShipToState() {
		return shipToState;
	}

	public void setShipToState(String shipToState) {
		this.shipToState = shipToState;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getShippingBillNo() {
		return shippingBillNo;
	}

	public void setShippingBillNo(String shippingBillNo) {
		this.shippingBillNo = shippingBillNo;
	}

	public Object getShippingBillDate() {
		return shippingBillDate;
	}

	public void setShippingBillDate(Object shippingBillDate) {
		this.shippingBillDate = shippingBillDate;
	}

	public String getHsnsac() {
		return hsnsac;
	}

	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getItemCategory() {
		return itemCategory;
	}

	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}

	public String getUnitofMeasurement() {
		return unitofMeasurement;
	}

	public void setUnitofMeasurement(String unitofMeasurement) {
		this.unitofMeasurement = unitofMeasurement;
	}

	public BigDecimal getQtySupplied() {
		return qtySupplied;
	}

	public void setQtySupplied(BigDecimal qtySupplied) {
		this.qtySupplied = qtySupplied;
	}

	public Double getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public Double getIgstAmount() {
		return igstAmount;
	}

	public void setIgstAmount(Double igstAmount) {
		this.igstAmount = igstAmount;
	}

	public Double getIgstRate() {
		return igstRate;
	}

	public void setIgstRate(Double igstRate) {
		this.igstRate = igstRate;
	}

	public Double getCgstAmount() {
		return cgstAmount;
	}

	public void setCgstAmount(Double cgstAmount) {
		this.cgstAmount = cgstAmount;
	}

	public Double getCgstRate() {
		return cgstRate;
	}

	public void setCgstRate(Double cgstRate) {
		this.cgstRate = cgstRate;
	}

	public Double getSgstAmount() {
		return sgstAmount;
	}

	public void setSgstAmount(Double sgstAmount) {
		this.sgstAmount = sgstAmount;
	}

	public Double getSgstRate() {
		return sgstRate;
	}

	public void setSgstRate(Double sgstRate) {
		this.sgstRate = sgstRate;
	}

	public String getReverseCharge() {
		return reverseCharge;
	}

	public void setReverseCharge(String reverseCharge) {
		this.reverseCharge = reverseCharge;
	}

	public String geteGSTIN() {
		return eGSTIN;
	}

	public void seteGSTIN(String eGSTIN) {
		this.eGSTIN = eGSTIN;
	}

	/*public String getSupplierERN() {
		return supplierERN;
	}

	public void setSupplierERN(String supplierERN) {
		this.supplierERN = supplierERN;
	}

	public Object geteRNDate() {
		return eRNDate;
	}

	public void seteRNDate(Object eRNDate) {
		this.eRNDate = eRNDate;
	}

	public String getTransportName() {
		return transportName;
	}

	public void setTransportName(String transportName) {
		this.transportName = transportName;
	}

	public String getLorryReceiptNo() {
		return lorryReceiptNo;
	}

	public void setLorryReceiptNo(String lorryReceiptNo) {
		this.lorryReceiptNo = lorryReceiptNo;
	}

	public String getLorryReceiptDate() {
		return lorryReceiptDate;
	}

	public void setLorryReceiptDate(String lorryReceiptDate) {
		this.lorryReceiptDate = lorryReceiptDate;
	}*/

	public BigDecimal getAggInvoice() {
		return aggInvoice;
	}

	public void setAggInvoice(BigDecimal aggInvoice) {
		this.aggInvoice = aggInvoice;
	}

	public BigDecimal getAggTaxableValue() {
		return aggTaxableValue;
	}

	public void setAggTaxableValue(BigDecimal aggTaxableValue) {
		this.aggTaxableValue = aggTaxableValue;
	}

	public Integer getInvOrder() {
		return invOrder;
	}

	public void setInvOrder(Integer invOrder) {
		this.invOrder = invOrder;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTableType() {
		return tableType;
	}

	public void setTableType(String tableType) {
		this.tableType = tableType;
	}

	public String getItemStatus() {
		return itemStatus;
	}

	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

    public String getAccountingVoucherNumber() {
        return accountingVoucherNumber;
    }

    public void setAccountingVoucherNumber(String accountingVoucherNumber) {
        this.accountingVoucherNumber = accountingVoucherNumber;
    }

    public Object getAccountingVoucherDate() {
        return accountingVoucherDate;
    }

    public void setAccountingVoucherDate(Object accountingVoucherDate) {
        this.accountingVoucherDate = accountingVoucherDate;
    }

    public Double getCessAmountAdvalorem() {
        return cessAmountAdvalorem;
    }

    public void setCessAmountAdvalorem(Double cessAmountAdvalorem) {
        this.cessAmountAdvalorem = cessAmountAdvalorem;
    }

    public Double getCessAmountSpecific() {
        return cessAmountSpecific;
    }

    public void setCessAmountSpecific(Double cessAmountSpecific) {
        this.cessAmountSpecific = cessAmountSpecific;
    }

    public Double getCessRateAdvalorem() {
        return cessRateAdvalorem;
    }

    public void setCessRateAdvalorem(Double cessRateAdvalorem) {
        this.cessRateAdvalorem = cessRateAdvalorem;
    }

    public Double getCessRateSpecific() {
        return cessRateSpecific;
    }

    public void setCessRateSpecific(Double cessRateSpecific) {
        this.cessRateSpecific = cessRateSpecific;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public Double getExportDuty() {
        return exportDuty;
    }

    public void setExportDuty(Double exportDuty) {
        this.exportDuty = exportDuty;
    }

    public Double getFob() {
        return fob;
    }

    public void setFob(Double fob) {
        this.fob = fob;
    }

    /*public Object getGoodsReceiptDate() {
        return goodsReceiptDate;
    }

    public void setGoodsReceiptDate(Object goodsReceiptDate) {
        this.goodsReceiptDate = goodsReceiptDate;
    }*/

    public Double getInvoiceValue() {
        return invoiceValue;
    }

    public void setInvoiceValue(Double invoiceValue) {
        this.invoiceValue = invoiceValue;
    }

    public boolean isPreStageError() {
        return isPreStageError;
    }

    public void setPreStageError(boolean isPreStageError) {
        this.isPreStageError = isPreStageError;
    }

    public String getItcFlag() {
        return itcFlag;
    }

    public void setItcFlag(String itcFlag) {
        this.itcFlag = itcFlag;
    }

    /*public String getMaterialSentForJobwork() {
        return materialSentForJobwork;
    }

    public void setMaterialSentForJobwork(String materialSentForJobwork) {
        this.materialSentForJobwork = materialSentForJobwork;
    }*/

    public String getOriginalCGSTIN() {
        return OriginalCGSTIN;
    }

    public void setOriginalCGSTIN(String originalCGSTIN) {
        OriginalCGSTIN = originalCGSTIN;
    }

    public String getProfitCentre1() {
        return ProfitCentre1;
    }

    public void setProfitCentre1(String profitCentre1) {
        ProfitCentre1 = profitCentre1;
    }

    public String getProfitCentre2() {
        return ProfitCentre2;
    }

    public void setProfitCentre2(String profitCentre2) {
        ProfitCentre2 = profitCentre2;
    }

    public String getReasonForCreditDebitNote() {
        return reasonForCreditDebitNote;
    }

    public void setReasonForCreditDebitNote(String reasonForCreditDebitNote) {
        this.reasonForCreditDebitNote = reasonForCreditDebitNote;
    }

    public String getSubDivision() {
        return subDivision;
    }

    public void setSubDivision(String subDivision) {
        this.subDivision = subDivision;
    }

    public String getTcsFlag() {
        return tcsFlag;
    }

    public void setTcsFlag(String tcsFlag) {
        this.tcsFlag = tcsFlag;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }
    
    public String getSourceIdentifier() {
		return sourceIdentifier;
	}

	public void setSourceIdentifier(String sourceIdentifier) {
		this.sourceIdentifier = sourceIdentifier;
	}

	public String getSourceFileName() {
		return sourceFileName;
	}

	public void setSourceFileName(String sourceFileName) {
		this.sourceFileName = sourceFileName;
	}

	public String getGlAccountCode() {
		return glAccountCode;
	}

	public void setGlAccountCode(String glAccountCode) {
		this.glAccountCode = glAccountCode;
	}

	public String getcRDRPreGST() {
		return cRDRPreGST;
	}

	public void setcRDRPreGST(String cRDRPreGST) {
		this.cRDRPreGST = cRDRPreGST;
	}

	public String getUinORComposition() {
		return uinORComposition;
	}

	public void setUinORComposition(String uinORComposition) {
		this.uinORComposition = uinORComposition;
	}

	public String getPortCode() {
		return portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getUserdefinedfield1() {
		return userdefinedfield1;
	}

	public void setUserdefinedfield1(String userdefinedfield1) {
		this.userdefinedfield1 = userdefinedfield1;
	}

	public String getUserdefinedfield2() {
		return userdefinedfield2;
	}

	public void setUserdefinedfield2(String userdefinedfield2) {
		this.userdefinedfield2 = userdefinedfield2;
	}

	public String getUserdefinedfield3() {
		return userdefinedfield3;
	}

	public void setUserdefinedfield3(String userdefinedfield3) {
		this.userdefinedfield3 = userdefinedfield3;
	}

	
}