package com.ey.advisory.asp.storm.topology.gstr1.rulestg1;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.redis.bolt.AbstractRedisBolt;
import org.apache.storm.redis.common.config.JedisPoolConfig;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseRichBolt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.redis.mapper.SaleRegRedisCompute;
import com.ey.advisory.asp.storm.bolt.common.GSTR1RedisWSBolt;
import com.ey.advisory.asp.storm.bolt.common.PublishRedisBolt;
import com.ey.advisory.asp.storm.bolt.gstr1.rulestg1.InvoiceAmendmentValidationBolt;
import com.ey.advisory.asp.storm.bolt.gstr1.rulestg1.SaleRegCatRuleBolt;
import com.ey.advisory.asp.storm.bolt.gstr1.rulestg1.SaleRegRuleValidationBolt;
import com.ey.advisory.asp.storm.bolt.gstr1.rulestg1.SaleRegTurnOverRuleBolt;
import com.ey.advisory.asp.storm.bolt.gstr1.rulestg1.SaleRegValidationBolt;
import com.ey.advisory.asp.storm.spout.gstr1.rulestg1.SaleRegSpoutBuilder;
import com.ey.advisory.asp.storm.topology.StormTopologyBuilder;

/**
* Subclass for StormTopologybuilder for Rule stage 1 of GSTR1
* related to SaleReg. 
*
* @author  Siddharth Pahuja
* @version 1.0
* @since   06-03-2017
*/

public class SaleRegTopologyBuilder extends StormTopologyBuilder{
	
	private SaleRegSpoutBuilder saleRegSpoutBuilder;
	private BaseRichBolt saleRegValidationBolt;	
	private BaseRichBolt saleRegCatRuleBolt;
	private BaseRichBolt invoiveAmendmentBolt;
	private BaseRichBolt saleRegRuleBolt;
	private BaseRichBolt saleRegTurnOverRuleBolt;
	
	private GSTR1RedisWSBolt gstr1RedisWSBolt;
	private BaseRichBolt saleRegRedisCompute;
	private PublishRedisBolt publishRedisBolt;
	
	private final Logger log = LoggerFactory.getLogger(getClass());


	public SaleRegTopologyBuilder(Properties configs) {
		super(configs);
		initialize();
	}

	private void initialize() {
		saleRegSpoutBuilder=new SaleRegSpoutBuilder(configs);	
		
		saleRegCatRuleBolt=new SaleRegCatRuleBolt();
		invoiveAmendmentBolt = new InvoiceAmendmentValidationBolt();
		saleRegValidationBolt=new SaleRegValidationBolt();
		saleRegRuleBolt= new SaleRegRuleValidationBolt();
		saleRegTurnOverRuleBolt = new SaleRegTurnOverRuleBolt();
		gstr1RedisWSBolt=new GSTR1RedisWSBolt();
		saleRegRedisCompute=new SaleRegRedisCompute();
		publishRedisBolt=new PublishRedisBolt();
		
	}

	@Override
	public void buildDataPipeline(TopologyBuilder builder) {
		if(log.isInfoEnabled())
		log.info("SaleRegTopologyBuilder.setBuilderDataPipeline() starts");
		
		if(builder != null){
			try{
				KafkaSpout salRegSpout=saleRegSpoutBuilder.buildKafkaSpout();
				builder.setSpout(configs.getProperty(Constant.STORM_SPOUT_SALEREG), salRegSpout);
				
				builder.setBolt(configs.getProperty(Constant.BOLT_SALEREG_RULE1),saleRegCatRuleBolt).shuffleGrouping(configs.getProperty(Constant.STORM_SPOUT_SALEREG));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_SALEREG_RULE2),invoiveAmendmentBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_SALEREG_RULE1));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_SALEREG_RULE3),saleRegValidationBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_SALEREG_RULE2));
				
				//Other ruls will intgrate via bolts
				builder.setBolt(configs.getProperty(Constant.BOLT_SALEREG_RULE4), saleRegRuleBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_SALEREG_RULE3));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_SALEREG_RULE5),saleRegTurnOverRuleBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_SALEREG_RULE4));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_GSTR1_REDIS_WS),gstr1RedisWSBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_SALEREG_RULE5));
			
				builder.setBolt(configs.getProperty(Constant.BOLT_COMPUTE_REDIS),saleRegRedisCompute).shuffleGrouping(configs.getProperty(Constant.BOLT_GSTR1_REDIS_WS));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_PUBLISH_REDIS),publishRedisBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_COMPUTE_REDIS));
				if(log.isInfoEnabled())
				log.info("SaleRegTopologyBuilder.setBuilderDataPipeline() ends");
			
			}catch(Exception e){
				log.error("Error Building SaleReg Topology " + e);
			}
		}
	
	}
	

}
