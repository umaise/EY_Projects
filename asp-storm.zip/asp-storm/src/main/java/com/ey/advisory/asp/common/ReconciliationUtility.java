package com.ey.advisory.asp.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

public class ReconciliationUtility {
	
	private final static Logger log = LoggerFactory.getLogger(ReconciliationUtility.class);
	

	public static void getPurchaseByPan(ReconciliationDTO dto){
		ClientResponse response = null;
		Gson gson = new Gson();
		if(dto != null ){
			 dto.setPurchasePresentForPAN(false);
			if(dto.getFilingRecordType() != null && !dto.getFilingRecordType().isEmpty() && dto.getTableKey() != null && !dto.getTableKey().isEmpty()){
			try{
				String jsonString = gson.toJson(dto);
				response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.RECON_PURCHASE_BY_PAN, dto.getGroupCode(), jsonString, Constant.VERB_TYPE_POST);
				
				if(response != null && response.getStatusInfo().getStatusCode() == 200){
					dto = gson.fromJson(response.getEntity(String.class), ReconciliationDTO.class);
					if(dto != null && dto.getPurchaseGSTINList() != null && !dto.getPurchaseGSTINList().isEmpty()){
						dto.setPurchasePresentForPAN(true);
						return;
					}
				}
			}catch(Exception e){
				log.error("Error Fetching purchase List By PAN", e);
			}
		}
			
		}
		
		
		}
		
		
					
	}
