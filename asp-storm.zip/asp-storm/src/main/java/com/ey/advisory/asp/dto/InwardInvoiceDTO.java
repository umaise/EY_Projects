package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.google.gson.annotations.SerializedName;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;

public class InwardInvoiceDTO extends InvoiceDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@SerializedName("gstr2")
	private List<InwardInvoiceModel> lineItemList;
	private String invStatus;
	private String tableType;
	private Set<TblPurchaseErrorInfo> errorList;
	private String groupCode;
	private boolean isMultipleSupplyType;
	
	public List<InwardInvoiceModel> getLineItemList() {
		return lineItemList;
	}
	public void setLineItemList(List<InwardInvoiceModel> lineItemList) {
		this.lineItemList = lineItemList;
	}
	public String getInvStatus() {
		return invStatus;
	}
	public void setInvStatus(String invStatus) {
		this.invStatus = invStatus;
	}
	public String getTableType() {
		return tableType;
	}
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	public Set<TblPurchaseErrorInfo> getErrorList() {
		return errorList;
	}
	public void setErrorList(Set<TblPurchaseErrorInfo> errorList) {
		this.errorList = errorList;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public boolean isMultipleSupplyType() {
		return isMultipleSupplyType;
	}
	public void setMultipleSupplyType(boolean isMultipleSupplyType) {
		this.isMultipleSupplyType = isMultipleSupplyType;
	}
}
