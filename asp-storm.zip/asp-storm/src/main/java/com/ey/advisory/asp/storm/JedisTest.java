package com.ey.advisory.asp.storm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import redis.clients.jedis.Jedis;

public class JedisTest {

	public static void main(String[] args) {
		Jedis jedis =new Jedis ("inbanvmdapp01",6379);
		System.out.println("running");
		List<String> invoiceData = jedis.hmget("INV_PROCESSED", "key1234");
		
		List<String> testList= new ArrayList<String>();
		Map<String,List<String>> testMap = new HashMap<String,List<String>>();
		testList.add("1");
		testList.add("2");
		
		//Gson gson = new Gson();
        //Type type = new TypeToken<List<Task>>() {}.getType();
        //String json = gson.toJson(list, type);
		
		//jedis.hmset("", testList);
	}

}
