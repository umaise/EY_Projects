package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;





public class TblGstinDetailsDomain implements Serializable{
    private static final long serialVersionUID = 1L;

    private String gstinId;
    
    
    private String  gSTNUserName;
    
    
    private Boolean isRegCertificate;
    
    private Integer entityID;
    
    private String stateCode;
    
    private Double turnOverAmount;
    
    private Boolean isActive;
    
    
    private String typeOfReg;
    
    private String createdBy;
    
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd") 
    private Timestamp createdDate;
    
    private String updatedBy;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
    private Timestamp updatedDate;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd") 
    private Date regdt;
    
    private Double quarterTurnOvrAmt;
    
    private String regMobileNumber;
    
    
    private String bankAccountNumber;
    
   
    
    /**
     * @return the regMobileNumber
     */
    public String getRegMobileNumber() {
        return regMobileNumber;
    }

    /**
     * @return the bankAccountNumber
     */
    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    /**
     * @param regMobileNumber the regMobileNumber to set
     */
    public void setRegMobileNumber(String regMobileNumber) {
        this.regMobileNumber = regMobileNumber;
    }

    /**
     * @param bankAccountNumber the bankAccountNumber to set
     */
    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public Date getRegdt() {
        return regdt;
    }

    public void setRegdt(Date regdt) {
        this.regdt = regdt;
    }


    /**
     * @return the gstinId
     */
    public String getGstinId() {
        return gstinId;
    }

    /**
     * @return the gSTNUserName
     */
    public String getgSTNUserName() {
        return gSTNUserName;
    }

    /**
     * @return the isRegCertificate
     */
    public Boolean getIsRegCertificate() {
        return isRegCertificate;
    }

    /**
     * @return the entityID
     */
    public Integer getEntityID() {
        return entityID;
    }

    /**
     * @return the stateCode
     */
    public String getStateCode() {
        return stateCode;
    }

    /**
     * @return the turnOverAmount
     */
    public Double getTurnOverAmount() {
        return turnOverAmount;
    }

    /**
     * @return the isActive
     */
    public Boolean getIsActive() {
        return isActive;
    }

    /**
     * @return the typeOfReg
     */
    public String getTypeOfReg() {
        return typeOfReg;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @return the createdDate
     */
    public Timestamp getCreatedDate() {
        return createdDate;
    }

    /**
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @return the updatedDate
     */
    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param gstinId the gstinId to set
     */
    public void setGstinId(String gstinId) {
        this.gstinId = gstinId;
    }

    /**
     * @param gSTNUserName the gSTNUserName to set
     */
    public void setgSTNUserName(String gSTNUserName) {
        this.gSTNUserName = gSTNUserName;
    }

    /**
     * @param isRegCertificate the isRegCertificate to set
     */
    public void setIsRegCertificate(Boolean isRegCertificate) {
        this.isRegCertificate = isRegCertificate;
    }

    /**
     * @param entityID the entityID to set
     */
    public void setEntityID(Integer entityID) {
        this.entityID = entityID;
    }

    /**
     * @param stateCode the stateCode to set
     */
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    /**
     * @param turnOverAmount the turnOverAmount to set
     */
    public void setTurnOverAmount(Double turnOverAmount) {
        this.turnOverAmount = turnOverAmount;
    }

    /**
     * @param isActive the isActive to set
     */
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    /**
     * @param typeOfReg the typeOfReg to set
     */
    public void setTypeOfReg(String typeOfReg) {
        this.typeOfReg = typeOfReg;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

	public Double getQuarterTurnOvrAmt() {
		return quarterTurnOvrAmt;
	}

	public void setQuarterTurnOvrAmt(Double quarterTurnOvrAmt) {
		this.quarterTurnOvrAmt = quarterTurnOvrAmt;
	}



}
