package com.ey.advisory.asp.client.domain;
/**
 * @author Nisha.Kumari
 */

import java.io.Serializable;
import java.sql.Date;

import com.google.gson.annotations.SerializedName;

public class InwardInvoiceModelGstr7 implements Serializable{
	
		
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3520227666931792013L;

	@SerializedName("TDSStagingID")
	private int id;
	
	@SerializedName("FileID")
	private int fILEID;
	
	@SerializedName("ReceiverPlantCode")
	private String receiverPlantCode;
	
	@SerializedName("TaxPeriod")
	private String taxPeriod;
	
	@SerializedName("ContractNumber")
	private String contractNumber;
	
	@SerializedName("Contractdate")
	private Object contractdate;
	
	@SerializedName("ContractValue")
	private Double contractValue;
	
	@SerializedName("DocumentType")
	private String documentType;
	
	@SerializedName("SupplyType")
	private String supplyType;
	
	@SerializedName("CompanyGSTIN")
	private String companyGSTIN;
	
	@SerializedName("SupplierGSTIN")
	private String supplierGSTIN;
	
	@SerializedName("SupplierCode")
	private String supplierCode;
	
	@SerializedName("SupplierName")
	private String supplierName;
	
	@SerializedName("SupplierAddress")
	private String supplierAddress;
	
	@SerializedName("ImportReportNumber")
	private String importReportNumber;
	
	@SerializedName("ImportReportDate")
	private Object importReportDate;
	
	@SerializedName("DocumentNo")
	private String documentNo;
	
	@SerializedName("DocumentDate")
	private Object documentDate;
	
	@SerializedName("LineNumber")
	private String lineNumber;
	
	@SerializedName("OriginalDocumentNo")
	private String originalDocumentNo;
	
	@SerializedName("OriginalDocumentDate")
	private Object originalDocumentDate;
	
	@SerializedName("UnitofMeasurement")
	private String unitofMeasurement;
	
	@SerializedName("BillQty")
	private Double billQty;
	
	@SerializedName("Advances")
	private Double advances;
	
	@SerializedName("GSTTaxableValue")
	private Double gSTTaxableValue;
	
	@SerializedName("TransactionIDforAdvances")
	private String transactionIDforAdvances;
	
	@SerializedName("GoodServices")
	private String goodServices;
	
	@SerializedName("HSNSAC")
	private String hSNSAC;
	
	@SerializedName("ItemCode")
	private String itemCode;
	
	@SerializedName("ItemDescription")
	private String itemDescription;
	
	@SerializedName("CategoryItem")
	private String categoryItem;
	
	@SerializedName("IGSTRate")
	private Double igstRate;
	
	@SerializedName("IGSTAmount")
	private Double iGSTAmount;
	
	@SerializedName("CGSTRate")
	private Double cgstRate;
	
	@SerializedName("CGSTAmount")
	private Double cGSTAmount;
	
	@SerializedName("SGSTRate")
	private Double sgstRate;
	
	@SerializedName("SGSTAmount")
	private Double sGSTAmount;
	
	@SerializedName("UTGSTRate")
	private Double uTGSTRate;
	
	@SerializedName("UTGSTAmount")
	private Double uTGSTAmount;
	
	@SerializedName("CessRate")
	private Double cessRate;
	
	@SerializedName("CessAmount")
	private Double cessAmount;
	
	@SerializedName("ValueIncludingTax")
	private Double valueIncludingTax;
	
	@SerializedName("POS")
	private String pOS;
	
	@SerializedName("ReverseCharge")
	private String reverseCharge;
	
	@SerializedName("CosumptionType")
	private String cosumptionType;
	
	@SerializedName("PaymentVoucherNumber")
	private String paymentVoucherNumber;
	
	@SerializedName("DateofPayment")
	private Object dateofPayment;
	
	@SerializedName("ValueOnTDS")
	private Double valueOnTDS;
	
	@SerializedName("GLCodeCapitalGoods")
	private String gLCodeCapitalGoods;
	
	@SerializedName("CapitalGoodsIdentifier")
	private String capitalGoodsIdentifier;
	
	@SerializedName("EligibleInput")
	private String eligibleInput;
	
	@SerializedName("TotalTaxeligibleITC")
	private Double totalTaxeligibleITC;
	
	@SerializedName("MonthlyITCavailability")
	private Double monthlyITCavailability;
	
	@SerializedName("ItcIgstAmt")
	private Double itcIgstAmt;
	
	@SerializedName("ItcCgstAmt")
	private Double itcCgstAmt;
	
	@SerializedName("ItcSgstAmt")
	private Double itcSgstAmt;
	
	@SerializedName("ItcCsgstAmt")
	private Double itcCsgstAmt;
	
	@SerializedName("TcIgstAmt")
	private Double tcIgstAmt;
	
	@SerializedName("TcCgstAmt")
	private Double tcCgstAmt;
	
	@SerializedName("TcSgstAmt")
	private Double tcSgstAmt;
	
	@SerializedName("TcCsgstAmt")
	private Double tcCsgstAmt;
	
	@SerializedName("DcoumentAttribute")
	private String dcoumentAttribute;
	
	public Double getItcIgstAmt() {
		return itcIgstAmt;
	}
	
	
	public void setItcIgstAmt(Double itcIgstAmt) {
		this.itcIgstAmt = itcIgstAmt;
	}
	
	
	public Double getItcCgstAmt() {
		return itcCgstAmt;
	}
	
	
	public void setItcCgstAmt(Double itcCgstAmt) {
		this.itcCgstAmt = itcCgstAmt;
	}
	
	
	public Double getItcSgstAmt() {
		return itcSgstAmt;
	}
	
	
	public void setItcSgstAmt(Double itcSgstAmt) {
		this.itcSgstAmt = itcSgstAmt;
	}
	
	
	public Double getItcCsgstAmt() {
		return itcCsgstAmt;
	}
	
	
	public void setItcCsgstAmt(Double itcCsgstAmt) {
		this.itcCsgstAmt = itcCsgstAmt;
	}
	
	
	public Double getTcIgstAmt() {
		return tcIgstAmt;
	}
	
	
	public void setTcIgstAmt(Double tcIgstAmt) {
		this.tcIgstAmt = tcIgstAmt;
	}
	
	
	public Double getTcCgstAmt() {
		return tcCgstAmt;
	}
	
	
	public void setTcCgstAmt(Double tcCgstAmt) {
		this.tcCgstAmt = tcCgstAmt;
	}
	
	
	public Double getTcSgstAmt() {
		return tcSgstAmt;
	}
	
	
	public void setTcSgstAmt(Double tcSgstAmt) {
		this.tcSgstAmt = tcSgstAmt;
	}
	
	
	public Double getTcCsgstAmt() {
		return tcCsgstAmt;
	}
	
	
	public void setTcCsgstAmt(Double tcCsgstAmt) {
		this.tcCsgstAmt = tcCsgstAmt;
	}
	
	
	@SerializedName("InwardSuppliesSubjectTTDS")
	private String inwardSuppliesSubjectTTDS;
	
	@SerializedName("TDSIGSTrate")
	private Double tDSIGSTrate;
	
	@SerializedName("TDS_IGST")
	private Double tDS_IGST;
	
	@SerializedName("TDSGSTrate")
	private Double tDSGSTrate;
	
	@SerializedName("TDS_SGST")
	private Double tDS_SGST;
	
	@SerializedName("TDSCGSTrate")
	private Double tDSCGSTrate;
	
	@SerializedName("TDS_CGST")
	private Double tDS_CGST;
	
	@SerializedName("TDSUTGSTrate")
	private Double tDSUTGSTrate;
	
	@SerializedName("TDSUTGST")
	private Double tDSUTGST;
	
	@SerializedName("TDSCessrate")
	private Double tDSCessrate;
	
	@SerializedName("TDS_Cess")
	private Double tDS_Cess;
	
	@SerializedName("CompanyRoadPermitNumber")
	private String companyRoadPermitNumber;
	
	@SerializedName("CompanyRoadPermitDate")
	private Object companyRoadPermitDate;
	
	@SerializedName("TransporterName")
	private String transporterName;
	
	@SerializedName("LorryNumber")
	private String lorryNumber;
	
	@SerializedName("SupplierRoadPermitNumber")
	private String supplierRoadPermitNumber;
	
	@SerializedName("SuppliersRoadPermitDate")
	private Object suppliersRoadPermitDate;
	
	@SerializedName("ShipStateCd")
	private String shipStateCd;
	
	@SerializedName("CustStCd")
	private String custStCd;
	
	@SerializedName("SupStCd")
	private String supStCd;	
	
	@SerializedName("AggTaxableValue")
	private Double aggTaxableValue;
	
	@SerializedName("AggInvoice")
	private Double aggInvoice;
	
	@SerializedName("POScd")
	private String pOScd;
	
	@SerializedName("InvOrder")
	private Integer invOrder;
	
	@SerializedName("Status")
	private String status;
	
	@SerializedName("RecordType")
	private String tableType;
	
	private String itemStatus;
	
	
	public InwardInvoiceModelGstr7() {
		super();
	}
	
	
	public int getId() {
		return id;
	}
	
	
	public void setId(int id) {
		this.id = id;
	}
	
	
	public int getfILEID() {
		return fILEID;
	}
	
	
	public void setfILEID(int fILEID) {
		this.fILEID = fILEID;
	}
	
	
	public String getReceiverPlantCode() {
		return receiverPlantCode;
	}
	
	
	public void setReceiverPlantCode(String receiverPlantCode) {
		this.receiverPlantCode = receiverPlantCode;
	}
	
	
	public String getTaxPeriod() {
		return taxPeriod;
	}
	
	
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	
	
	public String getContractNumber() {
		return contractNumber;
	}
	
	
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}
	
	
	public Object getContractdate() {
		return contractdate;
	}
	
	
	public void setContractdate(Date contractdate) {
		this.contractdate = contractdate;
	}
	
	
	public Double getContractValue() {
		return contractValue;
	}
	
	
	public String getDocumentType() {
		return documentType;
	}
	
	
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	
	
	public String getSupplyType() {
		return supplyType;
	}
	
	
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	
	
	public String getCompanyGSTIN() {
		return companyGSTIN;
	}
	
	
	public void setCompanyGSTIN(String companyGSTIN) {
		this.companyGSTIN = companyGSTIN;
	}
	
	
	public String getSupplierGSTIN() {
		return supplierGSTIN;
	}
	
	
	public void setSupplierGSTIN(String supplierGSTIN) {
		this.supplierGSTIN = supplierGSTIN;
	}
	
	
	public String getSupplierCode() {
		return supplierCode;
	}
	
	
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}
	
	
	public String getSupplierName() {
		return supplierName;
	}
	
	
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	
	
	public String getSupplierAddress() {
		return supplierAddress;
	}
	
	
	public void setSupplierAddress(String supplierAddress) {
		this.supplierAddress = supplierAddress;
	}
	
	
	public String getImportReportNumber() {
		return importReportNumber;
	}
	
	
	public void setImportReportNumber(String importReportNumber) {
		this.importReportNumber = importReportNumber;
	}
	
	
	public Object getImportReportDate() {
		return importReportDate;
	}
	
	
	public void setImportReportDate(Date importReportDate) {
		this.importReportDate = importReportDate;
	}
	
	
	public String getDocumentNo() {
		return documentNo;
	}
	
	
	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}
	
	
	public Object getDocumentDate() {
		return documentDate;
	}
	
	
	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}
	
	
	public String getLineNumber() {
		return lineNumber;
	}
	
	
	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	
	
	public String getOriginalDocumentNo() {
		return originalDocumentNo;
	}
	
	
	public void setOriginalDocumentNo(String originalDocumentNo) {
		this.originalDocumentNo = originalDocumentNo;
	}
	
	
	public Object getOriginalDocumentDate() {
		return originalDocumentDate;
	}
	
	
	public void setOriginalDocumentDate(Date originalDocumentDate) {
		this.originalDocumentDate = originalDocumentDate;
	}
	
	
	public String getUnitofMeasurement() {
		return unitofMeasurement;
	}
	
	
	public void setUnitofMeasurement(String unitofMeasurement) {
		this.unitofMeasurement = unitofMeasurement;
	}
	
	
	public Double getBillQty() {
		return billQty;
	}
	
	
	public void setBillQty(Double billQty) {
		this.billQty = billQty;
	}
	
	
	public Double getAdvances() {
		return advances;
	}
	
	
	public void setAdvances(Double advances) {
		this.advances = advances;
	}
	
	
	
	
	
	public Double getgSTTaxableValue() {
		return gSTTaxableValue;
	}
	
	
	public void setgSTTaxableValue(Double gSTTaxableValue) {
		this.gSTTaxableValue = gSTTaxableValue;
	}
	
	
	public String getTransactionIDforAdvances() {
		return transactionIDforAdvances;
	}
	
	
	public void setTransactionIDforAdvances(String transactionIDforAdvances) {
		this.transactionIDforAdvances = transactionIDforAdvances;
	}
	
	
	public String getGoodServices() {
		return goodServices;
	}
	
	
	public void setGoodServices(String goodServices) {
		this.goodServices = goodServices;
	}
	
	
	public String gethSNSAC() {
		return hSNSAC;
	}
	
	
	public void sethSNSAC(String hSNSAC) {
		this.hSNSAC = hSNSAC;
	}
	
	
	public String getItemCode() {
		return itemCode;
	}
	
	
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	
	
	public String getItemDescription() {
		return itemDescription;
	}
	
	
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	
	
	public String getCategoryItem() {
		return categoryItem;
	}
	
	
	public void setCategoryItem(String categoryItem) {
		this.categoryItem = categoryItem;
	}
	
	
	public Double getIgstRate() {
		return igstRate;
	}
	
	
	public void setIgstRate(Double igstRate) {
		this.igstRate = igstRate;
	}
	
	
	public Double getiGSTAmount() {
		return iGSTAmount;
	}
	
	
	public void setiGSTAmount(Double iGSTAmount) {
		this.iGSTAmount = iGSTAmount;
	}
	
	
	public Double getCgstRate() {
		return cgstRate;
	}
	
	
	public void setCgstRate(Double cgstRate) {
		this.cgstRate = cgstRate;
	}
	
	
	public Double getcGSTAmount() {
		return cGSTAmount;
	}
	
	
	public void setcGSTAmount(Double cGSTAmount) {
		this.cGSTAmount = cGSTAmount;
	}
	
	
	public Double getSgstRate() {
		return sgstRate;
	}
	
	
	public void setSgstRate(Double sgstRate) {
		this.sgstRate = sgstRate;
	}
	
	
	public Double getsGSTAmount() {
		return sGSTAmount;
	}
	
	
	public void setsGSTAmount(Double sGSTAmount) {
		this.sGSTAmount = sGSTAmount;
	}
	
	
	public Double getuTGSTRate() {
		return uTGSTRate;
	}
	
	
	public void setuTGSTRate(Double uTGSTRate) {
		this.uTGSTRate = uTGSTRate;
	}
	
	
	public Double getuTGSTAmount() {
		return uTGSTAmount;
	}
	
	
	public void setuTGSTAmount(Double uTGSTAmount) {
		this.uTGSTAmount = uTGSTAmount;
	}
	
	
	public Double getCessRate() {
		return cessRate;
	}
	
	
	public void setCessRate(Double cessRate) {
		this.cessRate = cessRate;
	}
	
	
	public Double getCessAmount() {
		return cessAmount;
	}
	
	
	public void setCessAmount(Double cessAmount) {
		this.cessAmount = cessAmount;
	}
	
	
	public Double getValueIncludingTax() {
		return valueIncludingTax;
	}
	
	
	public void setValueIncludingTax(Double valueIncludingTax) {
		this.valueIncludingTax = valueIncludingTax;
	}
	
	
	public String getpOS() {
		return pOS;
	}
	
	
	public void setpOS(String pOS) {
		this.pOS = pOS;
	}
	
	
	public String getReverseCharge() {
		return reverseCharge;
	}
	
	
	public void setReverseCharge(String reverseCharge) {
		this.reverseCharge = reverseCharge;
	}
	
	
	public String getCosumptionType() {
		return cosumptionType;
	}
	
	
	public void setCosumptionType(String cosumptionType) {
		this.cosumptionType = cosumptionType;
	}
	
	
	public String getPaymentVoucherNumber() {
		return paymentVoucherNumber;
	}
	
	
	public void setPaymentVoucherNumber(String paymentVoucherNumber) {
		this.paymentVoucherNumber = paymentVoucherNumber;
	}
	
	
	public Object getDateofPayment() {
		return dateofPayment;
	}
	
	
	public void setDateofPayment(Date dateofPayment) {
		this.dateofPayment = dateofPayment;
	}
	
	
	public Double getValueOnTDS() {
		return valueOnTDS;
	}
	
	
	public void setValueOnTDS(Double valueOnTDS) {
		this.valueOnTDS = valueOnTDS;
	}
	
	
	public String getgLCodeCapitalGoods() {
		return gLCodeCapitalGoods;
	}
	
	
	public void setgLCodeCapitalGoods(String gLCodeCapitalGoods) {
		this.gLCodeCapitalGoods = gLCodeCapitalGoods;
	}
	
	
	public String getCapitalGoodsIdentifier() {
		return capitalGoodsIdentifier;
	}
	
	
	public void setCapitalGoodsIdentifier(String capitalGoodsIdentifier) {
		this.capitalGoodsIdentifier = capitalGoodsIdentifier;
	}
	
	
	public String getEligibleInput() {
		return eligibleInput;
	}
	
	
	public void setEligibleInput(String eligibleInput) {
		this.eligibleInput = eligibleInput;
	}
	
	
	public Double getTotalTaxeligibleITC() {
		return totalTaxeligibleITC;
	}
	
	
	public void setTotalTaxeligibleITC(Double totalTaxeligibleITC) {
		this.totalTaxeligibleITC = totalTaxeligibleITC;
	}
	
	
	public Double getMonthlyITCavailability() {
		return monthlyITCavailability;
	}
	
	
	public void setMonthlyITCavailability(Double monthlyITCavailability) {
		this.monthlyITCavailability = monthlyITCavailability;
	}
	
	
	public String getInwardSuppliesSubjectTTDS() {
		return inwardSuppliesSubjectTTDS;
	}
	
	
	public void setInwardSuppliesSubjectTTDS(String inwardSuppliesSubjectTTDS) {
		this.inwardSuppliesSubjectTTDS = inwardSuppliesSubjectTTDS;
	}
	
	
	public Double gettDSIGSTrate() {
		return tDSIGSTrate;
	}
	
	
	public void settDSIGSTrate(Double tDSIGSTrate) {
		this.tDSIGSTrate = tDSIGSTrate;
	}
	
	
	public Double gettDS_IGST() {
		return tDS_IGST;
	}
	
	
	public void settDS_IGST(Double tDS_IGST) {
		this.tDS_IGST = tDS_IGST;
	}
	
	
	public Double gettDSGSTrate() {
		return tDSGSTrate;
	}
	
	
	public void settDSGSTrate(Double tDSGSTrate) {
		this.tDSGSTrate = tDSGSTrate;
	}
	
	
	public Double gettDS_SGST() {
		return tDS_SGST;
	}
	
	
	public void settDS_SGST(Double tDS_SGST) {
		this.tDS_SGST = tDS_SGST;
	}
	
	
	public Double gettDSCGSTrate() {
		return tDSCGSTrate;
	}
	
	
	public void settDSCGSTrate(Double tDSCGSTrate) {
		this.tDSCGSTrate = tDSCGSTrate;
	}
	
	
	public Double gettDS_CGST() {
		return tDS_CGST;
	}
	
	
	public void settDS_CGST(Double tDS_CGST) {
		this.tDS_CGST = tDS_CGST;
	}
	
	
	public Double gettDSUTGSTrate() {
		return tDSUTGSTrate;
	}
	
	
	public void settDSUTGSTrate(Double tDSUTGSTrate) {
		this.tDSUTGSTrate = tDSUTGSTrate;
	}
	
	
	public Double gettDSUTGST() {
		return tDSUTGST;
	}
	
	
	public void settDSUTGST(Double tDSUTGST) {
		this.tDSUTGST = tDSUTGST;
	}
	
	
	public Double gettDSCessrate() {
		return tDSCessrate;
	}
	
	
	public void settDSCessrate(Double tDSCessrate) {
		this.tDSCessrate = tDSCessrate;
	}
	
	
	public Double gettDS_Cess() {
		return tDS_Cess;
	}
	
	
	public void settDS_Cess(Double tDS_Cess) {
		this.tDS_Cess = tDS_Cess;
	}
	
	
	public String getCompanyRoadPermitNumber() {
		return companyRoadPermitNumber;
	}
	
	
	public void setCompanyRoadPermitNumber(String companyRoadPermitNumber) {
		this.companyRoadPermitNumber = companyRoadPermitNumber;
	}
	
	
	public Object getCompanyRoadPermitDate() {
		return companyRoadPermitDate;
	}
	
	
	public void setCompanyRoadPermitDate(Date companyRoadPermitDate) {
		this.companyRoadPermitDate = companyRoadPermitDate;
	}
	
	
	public String getTransporterName() {
		return transporterName;
	}
	
	
	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}
	
	
	public String getLorryNumber() {
		return lorryNumber;
	}
	
	
	public void setLorryNumber(String lorryNumber) {
		this.lorryNumber = lorryNumber;
	}
	
	
	public String getSupplierRoadPermitNumber() {
		return supplierRoadPermitNumber;
	}
	
	
	public void setSupplierRoadPermitNumber(String supplierRoadPermitNumber) {
		this.supplierRoadPermitNumber = supplierRoadPermitNumber;
	}
	
	
	public Object getSuppliersRoadPermitDate() {
		return suppliersRoadPermitDate;
	}
	
	
	public void setSuppliersRoadPermitDate(Date suppliersRoadPermitDate) {
		this.suppliersRoadPermitDate = suppliersRoadPermitDate;
	}
	
	
	public String getShipStateCd() {
		return shipStateCd;
	}
	
	
	public void setShipStateCd(String shipStateCd) {
		this.shipStateCd = shipStateCd;
	}
	
	
	public String getCustStCd() {
		return custStCd;
	}
	
	
	public void setCustStCd(String custStCd) {
		this.custStCd = custStCd;
	}
	
	
	public String getSupStCd() {
		return supStCd;
	}
	
	
	public void setSupStCd(String supStCd) {
		this.supStCd = supStCd;
	}
	
	
	public Double getAggTaxableValue() {
		return aggTaxableValue;
	}
	
	
	public void setAggTaxableValue(Double aggTaxableValue) {
		this.aggTaxableValue = aggTaxableValue;
	}
	
	
	public Double getAggInvoice() {
		return aggInvoice;
	}
	
	
	public void setAggInvoice(Double aggInvoice) {
		this.aggInvoice = aggInvoice;
	}
	
	
	public String getpOScd() {
		return pOScd;
	}
	
	
	public void setpOScd(String pOScd) {
		this.pOScd = pOScd;
	}
	
	
	public Integer getInvOrder() {
		return invOrder;
	}
	
	
	public void setInvOrder(Integer invOrder) {
		this.invOrder = invOrder;
	}
	
	
	public String getStatus() {
		return status;
	}
	
	
	public void setStatus(String status) {
		this.status = status;
	}
		
	public String getTableType() {
		return tableType;
	}
	
	
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	
	
	public String getItemStatus() {
		return itemStatus;
	}
	
	
	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}
	
	
	public String getDcoumentAttribute() {
		return dcoumentAttribute;
	}
	
	
	public void setDcoumentAttribute(String dcoumentAttribute) {
		this.dcoumentAttribute = dcoumentAttribute;
	}
	
	
	public void setContractdate(Object contractdate) {
		this.contractdate = contractdate;
	}
	
	
	public void setContractValue(Double contractValue) {
		this.contractValue = contractValue;
	}
	
	
	public void setImportReportDate(Object importReportDate) {
		this.importReportDate = importReportDate;
	}
	
	
	public void setDocumentDate(Object documentDate) {
		this.documentDate = documentDate;
	}
	
	
	public void setOriginalDocumentDate(Object originalDocumentDate) {
		this.originalDocumentDate = originalDocumentDate;
	}
	public void setDateofPayment(Object dateofPayment) {
		this.dateofPayment = dateofPayment;
	}
	
	
	public void setCompanyRoadPermitDate(Object companyRoadPermitDate) {
		this.companyRoadPermitDate = companyRoadPermitDate;
	}
	
	
	public void setSuppliersRoadPermitDate(Object suppliersRoadPermitDate) {
		this.suppliersRoadPermitDate = suppliersRoadPermitDate;
	}



}
