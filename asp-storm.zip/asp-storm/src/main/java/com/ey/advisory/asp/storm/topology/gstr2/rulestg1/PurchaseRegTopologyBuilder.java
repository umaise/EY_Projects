package com.ey.advisory.asp.storm.topology.gstr2.rulestg1;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.redis.bolt.AbstractRedisBolt;
import org.apache.storm.redis.common.config.JedisPoolConfig;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseRichBolt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.redis.mapper.PurchaseRegRedisCompute;
import com.ey.advisory.asp.storm.bolt.common.GSTR1RedisWSBolt;
import com.ey.advisory.asp.storm.bolt.common.GSTR2RedisWSBolt;
import com.ey.advisory.asp.storm.bolt.common.PublishRedisBolt;
import com.ey.advisory.asp.storm.bolt.gstr2.rulestg1.PurchaseRegCatRuleBolt;
import com.ey.advisory.asp.storm.bolt.gstr2.rulestg1.PurchaseRegLineItemBolt;
import com.ey.advisory.asp.storm.bolt.gstr2.rulestg1.PurchaseRegRuleBolt;
import com.ey.advisory.asp.storm.bolt.gstr2.rulestg1.PurchaseRegRuleValidationBolt;
import com.ey.advisory.asp.storm.spout.gstr2.rulestg1.PurchaseRegSpoutBuilder;
import com.ey.advisory.asp.storm.topology.StormTopologyBuilder;

/**

* @author  Nisha Kumari
* @version 1.0
* @since   17-03-2017
*/


public class PurchaseRegTopologyBuilder extends StormTopologyBuilder{

	private PurchaseRegSpoutBuilder purchaseRegSpoutBuilder;
	private BaseRichBolt purchaseRegCatRuleBolt;
	private BaseRichBolt purchaseRegRuleValidationBolt;
	private BaseRichBolt purchaseRegRuleBolt;
	private BaseRichBolt purchaseRegLineItemBolt;
	private GSTR2RedisWSBolt gstr2RedisWSBolt;
	private BaseRichBolt purchaseRegRedisCompute;
	private PublishRedisBolt publishRedisBolt;
	
	
	private final Logger log = LoggerFactory.getLogger(getClass());


	public PurchaseRegTopologyBuilder(Properties configs) {
		super(configs);
		initialize();
	}
	
	private void initialize() {
		purchaseRegSpoutBuilder=new PurchaseRegSpoutBuilder(configs);
		purchaseRegCatRuleBolt = new PurchaseRegCatRuleBolt();
		purchaseRegRuleValidationBolt = new PurchaseRegRuleValidationBolt();
		purchaseRegRuleBolt = new PurchaseRegRuleBolt();
		purchaseRegLineItemBolt= new PurchaseRegLineItemBolt();
		gstr2RedisWSBolt=new GSTR2RedisWSBolt();
		purchaseRegRedisCompute = new PurchaseRegRedisCompute();
		publishRedisBolt=new PublishRedisBolt();
	}

	@Override
	public void buildDataPipeline(TopologyBuilder builder) {
		log.info("PurchaseRegTopologyBuilder.setBuilderDataPipeline() starts");
		
		if(builder != null){
			try{
				KafkaSpout purchaseRegSpout=purchaseRegSpoutBuilder.buildKafkaSpout();

				builder.setSpout(configs.getProperty(Constant.STORM_SPOUT_PURCHASEREG), purchaseRegSpout);
				
				//int sinkPurchaseBoltCount = Integer.parseInt(configs.getProperty(Constant.PURCHASEREG_READ_BOLT_COUNT));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_PURCHASEREG_RULE1),purchaseRegCatRuleBolt).shuffleGrouping(configs.getProperty(Constant.STORM_SPOUT_PURCHASEREG));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_PURCHASEREG_RULE2),purchaseRegRuleValidationBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_PURCHASEREG_RULE1));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_PURCHASEREG_RULE3),purchaseRegRuleBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_PURCHASEREG_RULE2));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_PURCHASEREG_RULE4),purchaseRegLineItemBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_PURCHASEREG_RULE3));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_GSTR2_REDIS_WS),gstr2RedisWSBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_PURCHASEREG_RULE4));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_PURCHSECOMPUTE_REDIS),purchaseRegRedisCompute).shuffleGrouping(configs.getProperty(Constant.BOLT_GSTR2_REDIS_WS));
				
				builder.setBolt(configs.getProperty(Constant.BOLT_PUBLISH_REDIS),publishRedisBolt).shuffleGrouping(configs.getProperty(Constant.BOLT_PURCHSECOMPUTE_REDIS));
				
				log.info("PurchaseRegTopologyBuilder.setBuilderDataPipeline() ends");
			}catch(Exception e){
				log.error("Error Building PurchaseReg Topology " + e);
			}
	
}
		
}
}
