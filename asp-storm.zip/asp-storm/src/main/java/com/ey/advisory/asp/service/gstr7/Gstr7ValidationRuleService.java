package com.ey.advisory.asp.service.gstr7;

import com.ey.advisory.asp.dto.InwardInvoiceGstr7DTO;

/**

* @author  Nisha Kumari
* @version 1.0
* @since   30-05-2017
*/
public interface Gstr7ValidationRuleService {
	
	public InwardInvoiceGstr7DTO executeGSTR7ValidationRules(InwardInvoiceGstr7DTO inwardInvoiceDTO);

	public InwardInvoiceGstr7DTO executeLineItemValidationRules(InwardInvoiceGstr7DTO inwardInvoiceDTO);

}
