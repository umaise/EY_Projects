package com.ey.advisory.asp.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.master.domain.HsnSacMasterDetailsDto;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.jersey.api.client.ClientResponse;

public class ValidationRuleServiceImpl implements ValidationRuleService {

	Set<TblSalesErrorInfo> errorList = new HashSet<TblSalesErrorInfo>();
	private final Logger log = LoggerFactory.getLogger(getClass());
	RedisTemplate<String, Object> redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();
	Map<String, List<HsnSacMasterDetailsDto>> hsnMasterDtos = new HashMap<String, List<HsnSacMasterDetailsDto>>();
	Map<String, TblGstinDetailsDomain> gstinMap = new HashMap<String, TblGstinDetailsDomain>();
	private boolean isErrorFound = false;

	public OutwardInvoiceDTO executeGSTR1ValidationRules(OutwardInvoiceDTO outwardInvoiceDTO) {

		isErrorFound = false;
		if(outwardInvoiceDTO.getErrorList()!=null){
			errorList = outwardInvoiceDTO.getErrorList();
		}

		List<OutwardInvoiceModel> lineItems = outwardInvoiceDTO.getLineItemList();
		if (lineItems != null && !lineItems.isEmpty()) {

			OutwardInvoiceModel outwardInvoiceModel = outwardInvoiceDTO.getLineItemList().get(0);

			validatePOS(lineItems);

			validateReverseCharge(lineItems);

			//commented  as per latest sheet removing

			//boolean isValidateReverseChargeTax =  validateReverseChargeTax(lineItems);

			validateDocumentDateForRegDate(outwardInvoiceModel, outwardInvoiceDTO.getGroupCode());

			validateDocumentDateForTaxPeriod(outwardInvoiceModel);

			validateMultipleSupplyType(lineItems, outwardInvoiceDTO.isMultipleSupplyType());

			validateOrgDocumentNoAndDate(outwardInvoiceModel);

			validateWrongRNVreporting(outwardInvoiceModel);

			validateOrgDocNoPresentForRFVDocument(outwardInvoiceModel);

			
			structuralValidationForOriginalDocumentDate(lineItems); 
			
			structuralValidationForPortCode(lineItems);
			
			structuralValidationForShippingBillNumber(lineItems);
			
			structuralValidationForShippingBillDate(lineItems);
			
			structuralValidationForReasonForIssuingNote(lineItems);
			
			structuralValidationForEcomGstin(lineItems);
	
			//Added By Ashwini
			validateTaxperiod(lineItems);
			
			validatePreGSTFlagSameForDRCRNote(lineItems);
			
			validateCGSTINSame(lineItems);
			
			validateOriginalCGSTINSame(lineItems);
			
			validateOriginalDocNumSame(lineItems);
			
			validateDocDateSame(lineItems);


			if(isErrorFound) {
				outwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
			}
			outwardInvoiceDTO.setErrorList(errorList);
		} else if(outwardInvoiceDTO.getInvStatus() == null) {
			outwardInvoiceDTO.setInvStatus(Constant.GSTR1_BR_STG1);
		}

		return outwardInvoiceDTO;
	}

	
	


	private void validateOrgDocNoPresentForRFVDocument(OutwardInvoiceModel outwardInvoiceModel) {

		if((Constant.RFV.equals(outwardInvoiceModel.getDocumentType()) || Constant.ARFV.equals(outwardInvoiceModel.getDocumentType()) ) && (outwardInvoiceModel.getOriginalDocumentNo() == null || outwardInvoiceModel.getOriginalDocumentNo().trim().isEmpty())) {
			errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER232", Constant.ORG_DOC_NO, Constant.BUSINESS_RULE, Boolean.FALSE
					,Constant.INVOICE));
			log.info("validateOrgDocNoPresentForRFVDocument - "+ outwardInvoiceModel.getId() + " ER232 " + Constant.ORG_DOC_NO +" "+ Constant.BUSINESS_RULE);
			isErrorFound = true;
		}
	}

	private void validateWrongRNVreporting(OutwardInvoiceModel outwardInvoiceModel) {

		Calendar docDate = Calendar.getInstance();
		Calendar orgDocDate = Calendar.getInstance();
		String taxPeriod = new String();

		if(outwardInvoiceModel.getDocumentType()!=null && outwardInvoiceModel.getDocumentType().equalsIgnoreCase(Constant.RNV)&& outwardInvoiceModel.getDocumentDate() != null && outwardInvoiceModel.getOriginalDocumentDate() != null && !outwardInvoiceModel.getOriginalDocumentDate().toString().isEmpty() && outwardInvoiceModel.getTaxperiod() != null){
			try{

				docDate.setTime(Utility.convertStringToDate(Constant.DATE_FORMAT, outwardInvoiceModel.getDocumentDate().toString()));
				orgDocDate.setTime(Utility.convertStringToDate(Constant.DATE_FORMAT, outwardInvoiceModel.getOriginalDocumentDate().toString()));
				taxPeriod = outwardInvoiceModel.getTaxperiod();

				if(docDate.get(Calendar.YEAR) == orgDocDate.get(Calendar.YEAR) && 
						(docDate.get(Calendar.MONTH) == orgDocDate.get(Calendar.MONTH)) && (docDate.get(Calendar.MONTH) == Integer.parseInt(taxPeriod.substring(0,2)) && (docDate.get(Calendar.YEAR) == Integer.parseInt(taxPeriod.substring(2,6))))){
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER229", Constant.DOC_DATE, Constant.BUSINESS_RULE, Boolean.FALSE
							,Constant.INVOICE));
					log.info("ER229: Error in RNV document types " + outwardInvoiceModel.getId() + "INV and RNV document types cannot exists for a same Invoice number within the given tax period");

					isErrorFound = true;
				}
			}catch(ParseException pe){
				log.error("Error Parsing Date for invoice ", outwardInvoiceModel.getId(), pe);
			}catch(Exception e){
				log.error("Error Validating DocumentDate for document date ", e);
			}

		}
	}

	private void validatePOS(List<OutwardInvoiceModel> lineItems) {

		String posCd1 = lineItems.get(0).getPos();
		if (posCd1 != null && !posCd1.trim().isEmpty()) {
			for (OutwardInvoiceModel lineItem : lineItems) {
				if (!posCd1.equals(lineItem.getPos())) {
					String columnNames= Constant.POS;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER201", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
					isErrorFound = true;
					log.error(lineItem.getId() + " ER201 " + Constant.POS + Constant.BUSINESS_RULE);
				}
			}
		} else {
			for (OutwardInvoiceModel lineItem : lineItems) {
				if (lineItem.getPos() != null && !lineItem.getPos().trim().isEmpty()) {
					String columnNames = Constant.POS;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER201",columnNames,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
					isErrorFound = true;
					log.error(lineItem.getId() + " ER201 " + Constant.POS + Constant.BUSINESS_RULE);
				}
			}
		}
	}

	private void validateReverseCharge(List<OutwardInvoiceModel> lineItems) {

		String reverseChargeFlag = lineItems.get(0).getReverseCharge();
		if (reverseChargeFlag != null && !reverseChargeFlag.trim().isEmpty()) {
			for (OutwardInvoiceModel lineItem : lineItems) {
				if (!reverseChargeFlag.equals(lineItem.getReverseCharge())) {
					String columnNames=Constant.REVERSE_CHARGE;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER202", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
					isErrorFound = true;
					log.warn(lineItem.getId() + " ER202 " + Constant.REVERSE_CHARGE + Constant.BUSINESS_RULE);
				}
			}
		} else {
			for (OutwardInvoiceModel lineItem : lineItems) {
				if (lineItem.getReverseCharge() != null && !lineItem.getReverseCharge().trim().isEmpty()) {
					String columnNames=Constant.REVERSE_CHARGE;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER202", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
					isErrorFound = true;
					log.warn(lineItem.getId() + " ER202 " + Constant.REVERSE_CHARGE + Constant.BUSINESS_RULE);
				}
			}
		}
	}

	//Commented as per latest Sheet

	/*private boolean validateReverseChargeTax(List<OutwardInvoiceModel> lineItems){

			for(OutwardInvoiceModel lineItem : lineItems){
				if(Constant.YES.equalsIgnoreCase(lineItem.getReverseCharge()) || Constant.Y.equalsIgnoreCase(lineItem.getReverseCharge())){
					Double cgStRate=  lineItem.getCgstRate()==null? Constant.ZERO_DOUBLE: lineItem.getCgstRate();
					Double igStRate=  lineItem.getIgstRate()==null? Constant.ZERO_DOUBLE: lineItem.getIgstRate();
					Double sgStRate=  lineItem.getSgstRate()==null? Constant.ZERO_DOUBLE: lineItem.getSgstRate();



					Double cgStAmount=  lineItem.getCgstAmount()==null? Constant.ZERO_DOUBLE: lineItem.getCgstAmount();
					Double igStAmount=  lineItem.getIgstAmount()==null? Constant.ZERO_DOUBLE: lineItem.getIgstAmount();
					Double sgStAmount=  lineItem.getSgstAmount()==null? Constant.ZERO_DOUBLE: lineItem.getSgstAmount();

					if(cgStRate > Constant.ZERO_DOUBLE || cgStAmount != Constant.ZERO_DOUBLE || 
							igStRate > Constant.ZERO_DOUBLE || igStAmount!= Constant.ZERO_DOUBLE || 
							sgStRate > Constant.ZERO_DOUBLE || sgStAmount != Constant.ZERO_DOUBLE)
							{
								String columnNames = "";
								if(cgStRate > Constant.ZERO_DOUBLE)
									columnNames = Constant.CGSTRATE;
						if(cgStAmount != Constant.ZERO_DOUBLE)
									columnNames = columnNames.isEmpty()?Constant.CGST_AMOUNT:columnNames + ","+Constant.CGST_AMOUNT;
								if(igStRate > Constant.ZERO_DOUBLE)
									columnNames = columnNames.isEmpty()?Constant.IGSTRATE:columnNames + ","+Constant.IGSTRATE;
						if(igStAmount != Constant.ZERO_DOUBLE)
									columnNames = columnNames.isEmpty()?Constant.IGST_AMOUNT:columnNames + ","+Constant.IGST_AMOUNT;
								if(sgStRate > Constant.ZERO_DOUBLE)
									columnNames = columnNames.isEmpty()?Constant.SGSTRATE:columnNames + ","+Constant.SGSTRATE;
						if(sgStAmount != Constant.ZERO_DOUBLE)
									columnNames = columnNames.isEmpty()?Constant.SGST_AMOUNT:columnNames + ","+Constant.SGST_AMOUNT;

								columnNames= columnNames + "," + Constant.REVERSE_CHARGE;

								errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER054", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE,Constant.LINE_ITEM));
								lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
								log.warn(lineItem.getId()+" ER054 " + Constant.REVERSE_CHARGE + Constant.BUSINESS_RULE);
								return false;

							}
				}
			}
			return true;
		}*/

	@SuppressWarnings("unchecked")
	public OutwardInvoiceDTO executeLineItemValidationRules(OutwardInvoiceDTO outwardInvoiceDTO) {


		if(outwardInvoiceDTO.getErrorList()!=null){
			errorList= outwardInvoiceDTO.getErrorList();
		}

		int counter = 0;
		if(outwardInvoiceDTO.getLineItemList()!=null){
			for (OutwardInvoiceModel outwardInvoiceModel : outwardInvoiceDTO.getLineItemList()) {

				// Rule: BR_RAW_OF_26 check for hsncode
				//checkForHSNCode(outwardInvoiceModel);

				// Rule: BR_RAW_OF_2 check for taxvalue

				validatetaxValue(outwardInvoiceModel);


				// Rule: BR_RAW_OF_1 check for TaxRate

				//validateRatebasedOnSlab(outwardInvoiceModel);


				// Rule: BR_RAW_OF_17 check for invoice igst,cgst and sgst
				validateInvoicevalues(outwardInvoiceModel);

				//Structural Validation
				//validateEntityHierarchy(outwardInvoiceModel, outwardInvoiceDTO.getGroupCode());                

				if(outwardInvoiceModel.getItemStatus() != null && outwardInvoiceModel.getItemStatus().equals(Constant.BUS_RULE_ERROR)){
					counter = counter + 1;
				}


			}
		}

		if (counter > 0  ) {
			outwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
		}else if (outwardInvoiceDTO.getInvStatus() == null) {
			outwardInvoiceDTO.setInvStatus(Constant.GSTR1_BR_STG1);
		}

		// set the error to ErrorList
		outwardInvoiceDTO.setErrorList(errorList);
		return outwardInvoiceDTO;

	}

	private void validateEntityHierarchy(OutwardInvoiceModel lineItem, String groupCode) {
		Map<String, List<EntityHierarchy>> entityHierarchyMap = new HashMap<>();
		List<EntityHierarchy> entityHierarchyList = new ArrayList<>();
		try{
			entityHierarchyMap = (Map<String, List<EntityHierarchy>>) redisTemplate.opsForHash().get(groupCode +"_"+ Constant.REDIS_CACHE, Constant.ENTITY_HIERARCHY_DETAILS);

			if(entityHierarchyMap == null || entityHierarchyMap.isEmpty()){
				if(loadEntityHierarchyMap(groupCode).equalsIgnoreCase(Constant.SUCCESS)){
					entityHierarchyMap = (Map<String, List<EntityHierarchy>>) redisTemplate.opsForHash().get(groupCode +"_"+ Constant.REDIS_CACHE, Constant.ENTITY_HIERARCHY_DETAILS);
				}
			}else{
				if(!entityHierarchyMap.containsKey(lineItem.getsGSTIN())){
					if(loadEntityHierarchyMap(groupCode).equalsIgnoreCase(Constant.SUCCESS)){
						entityHierarchyMap = (Map<String, List<EntityHierarchy>>) redisTemplate.opsForHash().get(groupCode +"_"+ Constant.REDIS_CACHE, Constant.ENTITY_HIERARCHY_DETAILS);
					}
				}
			}

			if(entityHierarchyMap != null && entityHierarchyMap.containsKey(lineItem.getsGSTIN())){
				entityHierarchyList = entityHierarchyMap.get(lineItem.getsGSTIN());
				Set<String> columnSet = new HashSet<>();
				int counter = 0;
				if(entityHierarchyList != null && !entityHierarchyList.isEmpty()){
					for(EntityHierarchy details : entityHierarchyList){
						if(details.isEqualHierarchy(lineItem.getId(), lineItem.getDivision(), lineItem.getSubDivision(), lineItem.getProfitCentre1(), lineItem.getProfitCentre2(), lineItem.getPlantCode())){
							counter = counter + 1;
							break;
						}
						details.validateEntityHierarchyData(lineItem.getId(), lineItem.getDivision(), lineItem.getSubDivision(), lineItem.getProfitCentre1(), lineItem.getProfitCentre2(), lineItem.getPlantCode(), columnSet);
					}
					if(counter == 0){
						for(String column : columnSet){
							if(Constant.DIVISION.equals(column)){
								errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "IN001", Constant.DIVISION, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}else if(Constant.SUB_DIVISION.equals(column)){
								errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "IN002", Constant.SUB_DIVISION, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}else if(Constant.PROFIT_CENTER_1.equals(column)){
								errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "IN003", Constant.PROFIT_CENTER_1, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}else if(Constant.PROFIT_CENTER_2.equals(column)){
								errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "IN004", Constant.PROFIT_CENTER_2, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}else if(Constant.PLANT_CODE.equals(column)){
								errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "IN005", Constant.PLANT_CODE, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
							}
						}
					}
				}
			}else{
				log.error("No Entity Hierarchy found for GSTIN:" + lineItem.getsGSTIN());
			}

		}catch(Exception e){
			log.error("Error Validating Entity Hierarchy for transaction" + lineItem.getId(), e);
		}

	}

	private String loadEntityHierarchyMap(String groupCode) {
		String status = Constant.FAILED;
		ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.ENTITY_HIERARCHY_REST, groupCode, null, Constant.VERB_TYPE_POST);
		Gson gson = new Gson();
		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			status = gson.fromJson(response.getEntity(String.class), String.class);
		}
		return status;
	}

	private void validatetaxValue(OutwardInvoiceModel outwardInvoiceModel) {

		DecimalFormat df = new DecimalFormat("#.##");
		df.setRoundingMode(RoundingMode.CEILING);		


		Double taxableValue = outwardInvoiceModel.getTaxableValue() == null|| outwardInvoiceModel.getTaxableValue().toString().isEmpty() ? Constant.ZERO_DOUBLE
				:Math.abs(outwardInvoiceModel.getTaxableValue()); 


		Double iGSTRate = outwardInvoiceModel.getIgstRate() == null || outwardInvoiceModel.getIgstRate().toString().isEmpty()  ? Constant.ZERO_DOUBLE
				: outwardInvoiceModel.getIgstRate()/100;
		Double cGSTRate = outwardInvoiceModel.getCgstRate() == null|| outwardInvoiceModel.getCgstRate().toString().isEmpty() ? Constant.ZERO_DOUBLE
				: outwardInvoiceModel.getCgstRate()/100;
		Double siGSTRate = outwardInvoiceModel.getSgstRate() == null || outwardInvoiceModel.getSgstRate().toString().isEmpty() ? Constant.ZERO_DOUBLE
				: outwardInvoiceModel.getSgstRate()/100;

		//		Double cessSpecficRate = outwardInvoiceModel.getCessRateSpecific() == null || outwardInvoiceModel.getCessRateSpecific().toString().isEmpty() ? Constant.ZERO_DOUBLE
		//				: outwardInvoiceModel.getCessRateSpecific()/100;
		//		Double cessAdavaloremRate = outwardInvoiceModel.getCessRateAdvalorem() == null|| outwardInvoiceModel.getCessRateAdvalorem().toString().isEmpty() ? Constant.ZERO_DOUBLE
		//				: outwardInvoiceModel.getCessRateAdvalorem()/100;
		double taxValueIgST =  round(taxableValue * iGSTRate,2);		
		double taxValueCgST =  round(taxableValue * cGSTRate,2);
		double taxValueSgST =  round(taxableValue * siGSTRate,2);

		//		double taxValueCess =  round(taxableValue * cessAdavaloremRate,2);

		//		double cessAdvaloremAmount= outwardInvoiceModel.getCessAmountAdvalorem()==null || outwardInvoiceModel.getCessAmountAdvalorem().toString().isEmpty() ? Constant.ZERO_DOUBLE: Double.parseDouble(df.format(outwardInvoiceModel.getCessAmountAdvalorem()));
		//		double cessSpecificAmount= outwardInvoiceModel.getCessAmountSpecific()==null || outwardInvoiceModel.getCessAmountSpecific().toString().isEmpty() ? Constant.ZERO_DOUBLE: Double.parseDouble(df.format(outwardInvoiceModel.getCessAmountSpecific()));
		String columnNames = "";
		if (taxValueIgST != (outwardInvoiceModel.getIgstAmount() == null || outwardInvoiceModel.getIgstAmount().toString().isEmpty()  ? Constant.ZERO_DOUBLE
				: Math.abs(outwardInvoiceModel.getIgstAmount()))){

			log.info(
					"Report will be generated and shared with the taxpayer for any differences as per their calculation with our system calculation");

			columnNames= Constant.IGST_AMOUNT;
			errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "IN208", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

		}

		if (taxValueCgST != (outwardInvoiceModel.getCgstAmount() == null || outwardInvoiceModel.getCgstAmount().toString().isEmpty() ? Constant.ZERO_DOUBLE
				: Math.abs(outwardInvoiceModel.getCgstAmount()))) {
			log.info(
					"Report will be generated and shared with the taxpayer for any differences as per their calculation with our system calculation");
			columnNames = Constant.CGST_AMOUNT;
			errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "IN207", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
		}

		if (taxValueSgST != (outwardInvoiceModel.getSgstAmount() == null || outwardInvoiceModel.getSgstAmount().toString().isEmpty() ? Constant.ZERO_DOUBLE
				: Math.abs(outwardInvoiceModel.getSgstAmount()))) {
			log.info(
					"Report will be generated and shared with the taxpayer for any differences as per their calculation with our system calculation");
			columnNames = Constant.SGST_AMOUNT;
			errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "IN202", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

		}


		//		if (taxValueCess !=  (Math.abs(cessAdvaloremAmount))) {
		//			log.info(
		//					"Report will be generated and shared with the taxpayer for any differences as per their calculation with our system calculation");
		//			columnNames = Constant.CESS_AMT_ADV+ ","+Constant.CESS_AMT_SPECIFIC;
		//			errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "IN209", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
		//
		//		}

	}

	private void validateInvoicevalues(OutwardInvoiceModel outwardInvoiceModel) {

		if (checkEmptyornull(outwardInvoiceModel.getIgstAmount())) {

			outwardInvoiceModel.setIgstAmount(Constant.ZERO_DOUBLE);
		}

		if (checkEmptyornull(outwardInvoiceModel.getCgstAmount())) {

			outwardInvoiceModel.setCgstAmount(Constant.ZERO_DOUBLE);
		}

		if (checkEmptyornull(outwardInvoiceModel.getSgstAmount())) {

			outwardInvoiceModel.setSgstAmount(Constant.ZERO_DOUBLE);
		}

		if (checkEmptyornull(outwardInvoiceModel.getSgstRate())) {

			outwardInvoiceModel.setSgstRate(Constant.ZERO_DOUBLE);
		}
		if (checkEmptyornull(outwardInvoiceModel.getIgstRate())) {

			outwardInvoiceModel.setIgstRate(Constant.ZERO_DOUBLE);
		}
		if (checkEmptyornull(outwardInvoiceModel.getCgstRate())) {

			outwardInvoiceModel.setCgstRate(Constant.ZERO_DOUBLE);
		}

		if (!checksupplyType(outwardInvoiceModel.getSupplyType())) {

			validatetaxAmount(outwardInvoiceModel);

		}

		else{

			if (!(outwardInvoiceModel.getIgstAmount().equals(Constant.ZERO_DOUBLE))
					&& (outwardInvoiceModel.getCgstAmount() + outwardInvoiceModel.getSgstAmount() != Constant.ZERO_DOUBLE)) {
				log.info("An invoice can either be intra-State or inter-State");
				String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT;
				outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER224", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
			}
		}

	}

	private Boolean checkEmptyornull(Double value) {

		if (value != null && !value.toString().isEmpty()) {

			return false;
		}

		return true;

	}

	private Boolean checksupplyType(String supplyType) {

		if (supplyType.equalsIgnoreCase(Constant.EXT) || (supplyType.equalsIgnoreCase(Constant.NIL))
				|| (supplyType.equalsIgnoreCase(Constant.NON)|| (supplyType.equalsIgnoreCase(Constant.NSY))||(supplyType.equalsIgnoreCase(Constant.SEZ))||(supplyType.equalsIgnoreCase(Constant.EXPT))||(supplyType.equalsIgnoreCase(Constant.EXPT))||(supplyType.equalsIgnoreCase(Constant.EXPWT))||(supplyType.equalsIgnoreCase(Constant.DXP )))
				|| supplyType.equalsIgnoreCase(Constant.DTA)) {
			return true;

		}

		return false;

	}

	private void validatetaxAmount(OutwardInvoiceModel outwardInvoiceModel) {

		if (!(outwardInvoiceModel.getIgstAmount().equals(Constant.ZERO_DOUBLE))
				&& (outwardInvoiceModel.getCgstAmount() + outwardInvoiceModel.getSgstAmount() != Constant.ZERO_DOUBLE)) {
			log.info("An invoice can either be intra-State or inter-State");
			String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT;
			outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER224", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
		} else if ((outwardInvoiceModel.getIgstAmount().equals(Constant.ZERO_DOUBLE))
				&& (outwardInvoiceModel.getCgstAmount().equals(Constant.ZERO_DOUBLE))
				&& (outwardInvoiceModel.getSgstAmount().equals(Constant.ZERO_DOUBLE)&&(outwardInvoiceModel.getIgstRate().equals(Constant.ZERO_DOUBLE))
						&& (outwardInvoiceModel.getCgstRate().equals(Constant.ZERO_DOUBLE))
						&& (outwardInvoiceModel.getSgstRate().equals(Constant.ZERO_DOUBLE)))) {
			checkforIntraorInterState(outwardInvoiceModel,Boolean.TRUE);
		} else {
			checkforIntraorInterState(outwardInvoiceModel,Boolean.FALSE);
		}  
	}

	private void checkforIntraorInterState(OutwardInvoiceModel outwardInvoiceModel, Boolean isZero) {

		if(outwardInvoiceModel.getcGSTIN()!=null && !outwardInvoiceModel.getcGSTIN().trim().isEmpty() && outwardInvoiceModel.getsGSTIN()!=null&& !outwardInvoiceModel.getsGSTIN().trim().isEmpty() ){

			if (outwardInvoiceModel.getcGSTIN().substring(0, 2).equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2))&&(outwardInvoiceModel.getPos()==null)) {

				if(!isZero && ((outwardInvoiceModel.getIgstAmount()!=Constant.ZERO_DOUBLE) || (outwardInvoiceModel.getIgstRate()!= Constant.ZERO_DOUBLE))){
					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				} /*else if((outwardInvoiceModel.getCgstAmount().equals(Constant.ZERO_DOUBLE)|| outwardInvoiceModel.getCgstRate().equals(Constant.ZERO_DOUBLE))|| outwardInvoiceModel.getSgstAmount().equals(Constant.ZERO_DOUBLE)|| outwardInvoiceModel.getSgstRate().equals(Constant.ZERO_DOUBLE)){
					log.info("In case of Intra-State Supply, CGST & SGST is applicable");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+ Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}*/
			} else if(outwardInvoiceModel.getcGSTIN().substring(0, 2).equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2))&&(outwardInvoiceModel.getPos().equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2)))) {

				if(!isZero &&((outwardInvoiceModel.getIgstAmount()!=Constant.ZERO_DOUBLE)||(outwardInvoiceModel.getIgstRate()!=Constant.ZERO_DOUBLE))){
					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				} /*else if((outwardInvoiceModel.getCgstAmount().equals(Constant.ZERO_DOUBLE)|| outwardInvoiceModel.getCgstRate().equals(Constant.ZERO_DOUBLE))|| outwardInvoiceModel.getSgstAmount().equals(Constant.ZERO_DOUBLE)|| outwardInvoiceModel.getSgstRate().equals(Constant.ZERO_DOUBLE)){
					log.info("In case of Intra-State Supply, CGST & SGST is applicable");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+ Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}*/
			} else if (outwardInvoiceModel.getcGSTIN().substring(0, 2).equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2))&&(!outwardInvoiceModel.getPos().equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2)))) {

				if(!isZero && ((!outwardInvoiceModel.getCgstAmount().equals(Constant.ZERO_DOUBLE)||(!outwardInvoiceModel.getCgstRate().equals(Constant.ZERO_DOUBLE))||  (!outwardInvoiceModel.getSgstAmount().equals(Constant.ZERO_DOUBLE)||(!outwardInvoiceModel.getSgstRate().equals(Constant.ZERO_DOUBLE)))))){

					log.info("IGST can't be Zero for Inter State Supply");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

				} /*else if(outwardInvoiceModel.getIgstAmount()==Constant.ZERO_DOUBLE||(outwardInvoiceModel.getIgstRate()==Constant.ZERO_DOUBLE)){

					log.info("In case of Inter-State Supply, IGST is applicable");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER252", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}*/

			} else if (!(outwardInvoiceModel.getcGSTIN().substring(0, 2).equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2)))&&(outwardInvoiceModel.getPos()==null)) {

				if(!isZero && ((!outwardInvoiceModel.getCgstAmount().equals(Constant.ZERO_DOUBLE)||(!outwardInvoiceModel.getCgstRate().equals(Constant.ZERO_DOUBLE))||  (!outwardInvoiceModel.getSgstAmount().equals(Constant.ZERO_DOUBLE)||(!outwardInvoiceModel.getSgstRate().equals(Constant.ZERO_DOUBLE)))))){

					log.info("IGST can't be Zero for Inter State Supply");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

				} /*else if(outwardInvoiceModel.getIgstAmount()==Constant.ZERO_DOUBLE||(outwardInvoiceModel.getIgstRate()==Constant.ZERO_DOUBLE)){

					log.info("In case of Inter-State Supply, IGST is applicable");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER252", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}*/
			} else if (!(outwardInvoiceModel.getcGSTIN().substring(0, 2).equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2)))&&(outwardInvoiceModel.getPos().equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2)))) {

				if(!isZero && (outwardInvoiceModel.getIgstAmount()!=Constant.ZERO_DOUBLE)||(outwardInvoiceModel.getIgstRate()!=Constant.ZERO_DOUBLE)){
					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				} /*else if((outwardInvoiceModel.getCgstAmount().equals(Constant.ZERO_DOUBLE)|| outwardInvoiceModel.getCgstRate().equals(Constant.ZERO_DOUBLE))|| outwardInvoiceModel.getSgstAmount().equals(Constant.ZERO_DOUBLE)|| outwardInvoiceModel.getSgstRate().equals(Constant.ZERO_DOUBLE)){
					log.info("In case of Intra-State Supply, CGST & SGST is applicable");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+ Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}*/
			} else if (!(outwardInvoiceModel.getcGSTIN().substring(0, 2).equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2)))&&(outwardInvoiceModel.getPos().equalsIgnoreCase(outwardInvoiceModel.getcGSTIN().substring(0, 2)))) {

				if(!isZero && ((!outwardInvoiceModel.getCgstAmount().equals(Constant.ZERO_DOUBLE)||(!outwardInvoiceModel.getCgstRate().equals(Constant.ZERO_DOUBLE))||  (!outwardInvoiceModel.getSgstAmount().equals(Constant.ZERO_DOUBLE)||(!outwardInvoiceModel.getSgstRate().equals(Constant.ZERO_DOUBLE)))))){

					log.info("IGST can't be Zero for Inter State Supply");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				} /*else if(outwardInvoiceModel.getIgstAmount()==Constant.ZERO_DOUBLE||(outwardInvoiceModel.getIgstRate()==Constant.ZERO_DOUBLE)){

					log.info("In case of Inter-State Supply, IGST is applicable");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER252", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}*/
			}
		} else if(outwardInvoiceModel.getcGSTIN()==null||(outwardInvoiceModel.getcGSTIN().trim().isEmpty())){
			if (outwardInvoiceModel.getPos()==null ||(outwardInvoiceModel.getPos().trim().isEmpty())||(outwardInvoiceModel.getPos().equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2)))) {

				if(!isZero && (outwardInvoiceModel.getIgstAmount()!=Constant.ZERO_DOUBLE||(outwardInvoiceModel.getIgstRate()!=Constant.ZERO_DOUBLE)) ){

					log.info("CGST/SGST can't be Zero for Intra State Supply");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER238", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				} /*else if((outwardInvoiceModel.getCgstAmount().equals(Constant.ZERO_DOUBLE)|| outwardInvoiceModel.getCgstRate().equals(Constant.ZERO_DOUBLE))|| outwardInvoiceModel.getSgstAmount().equals(Constant.ZERO_DOUBLE)|| outwardInvoiceModel.getSgstRate().equals(Constant.ZERO_DOUBLE)){
					log.info("In case of Intra-State Supply, CGST & SGST is applicable");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+ Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER251", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}*/
			} else if (!outwardInvoiceModel.getPos().equalsIgnoreCase(outwardInvoiceModel.getsGSTIN().substring(0, 2))) {

				if(!isZero && ((!outwardInvoiceModel.getCgstAmount().equals(Constant.ZERO_DOUBLE)||(!outwardInvoiceModel.getCgstRate().equals(Constant.ZERO_DOUBLE))||  (!outwardInvoiceModel.getSgstAmount().equals(Constant.ZERO_DOUBLE)||(!outwardInvoiceModel.getSgstRate().equals(Constant.ZERO_DOUBLE)))))){

					log.info("IGST can't be Zero for Inter State Supply");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER237", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));

				} /*else if(outwardInvoiceModel.getIgstAmount()==Constant.ZERO_DOUBLE||(outwardInvoiceModel.getIgstRate()==Constant.ZERO_DOUBLE)){

					log.info("In case of Inter-State Supply, IGST is applicable");
					String columnNames = Constant.CGST_AMOUNT + ","+Constant.IGST_AMOUNT+","+Constant.SGST_AMOUNT+","+Constant.SGSTRATE+","+Constant.CGSTRATE+","+Constant.IGSTRATE;
					outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER252", columnNames, Constant.BUSINESS_RULE, false,Constant.LINE_ITEM));
				}*/
			}
		}
	}

	/*private void validateRatebasedOnSlab(OutwardInvoiceModel outwardInvoiceModel) {

		HsnSacMasterDetailsDto hsnSacMasterdto = null;
		List<HsnSacMasterDetailsDto> hsnSacMasterDetailsDtoList = hsnMasterDtos.get(outwardInvoiceModel.getHsnsac());


		for (HsnSacMasterDetailsDto hsnSacMasterDetailsDto : Utility.nullSafeList(hsnSacMasterDetailsDtoList)) {
			// todo for check
			if (!StringUtils.containsIgnoreCase(hsnSacMasterDetailsDto.getRangeFormula(), Constant.ANY)) {

				ScriptEngineManager scriptengineMgr = new ScriptEngineManager();
				ScriptEngine engine = scriptengineMgr.getEngineByName(Constant.JAVASCRIPT);
				String taxValueFormula = outwardInvoiceModel.getTaxableValue().toString()
						+ hsnSacMasterDetailsDto.getRangeFormula();
				try {

					if (engine.eval(taxValueFormula).equals(true)) {

						hsnSacMasterdto = hsnSacMasterDetailsDto;

						break;

					}

				}
				catch (ScriptException e) {
					log.error("Eror in evaluating the range Formula " + e.toString());
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel.getInvoiceKey(), "S0001", Constant.HSN_MASTER_DET, Constant.BUSINESS_RULE, false,outwardInvoiceModel.getDocumentNo(),outwardInvoiceModel.getsGSTIN(),Constant.INVOICE));
				}
			}

			else {

				hsnSacMasterdto = hsnSacMasterDetailsDto;
				break;

			}
		}

		if ((hsnSacMasterdto != null)
				&& (outwardInvoiceModel.getHsnsac() != null || hsnSacMasterdto.gethSNSACCode() != null)) {

			// Rule: BR_RAW_OF_1 check for taxrate comparison
			validatetaxRate(hsnSacMasterdto, outwardInvoiceModel);

		}

	}

	private void validatetaxRate(HsnSacMasterDetailsDto validatedRateSlab, OutwardInvoiceModel outwardInvoiceModel) {

		if (!validatedRateSlab.getiGSTRt().equals(outwardInvoiceModel.getIgstRate() == null ? Constant.ZERO_DOUBLE
				: outwardInvoiceModel.getIgstRate())) {
			/// Loggin into error table

			log.info("IGST Tax rate seems to be incorrect as per HSN/SAC mentioned for the transaction");
			outwardInvoiceModel.setItemStatus(Constant.BUSINESS_RULE);
			errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel.getInvoiceKey(), "E0001", Constant.IGSTRATE, Constant.BUSINESS_RULE, false,outwardInvoiceModel.getDocumentNo(),outwardInvoiceModel.getsGSTIN(),Constant.INVOICE));
		}

		if (!validatedRateSlab.getcGSTRt().equals(outwardInvoiceModel.getCgstRate() == null ? Constant.ZERO_DOUBLE
				: outwardInvoiceModel.getCgstRate())) {
			log.info("CGST Tax rate seems to be incorrect as per HSN/SAC mentioned for the transaction <> ");

			outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel.getInvoiceKey(), "E0001", Constant.CGSTRATE, Constant.BUSINESS_RULE, false,outwardInvoiceModel.getDocumentNo(),outwardInvoiceModel.getsGSTIN(),Constant.INVOICE));
		}

		if (!StringUtils.isBlank(outwardInvoiceModel.getSupStCd())
				&& (!outwardInvoiceModel.getSupStCd().equalsIgnoreCase(validatedRateSlab.getStatecode())
						&& ((!validatedRateSlab.getsGSTRt()
								.equals(outwardInvoiceModel.getSgstRate() == null ? Constant.ZERO_DOUBLE
										: outwardInvoiceModel.getSgstRate()))))) {
			log.info("SGST Tax rate seems to be incorrect as per HSN/SAC mentioned for the transaction <> ");

			outwardInvoiceModel.setItemStatus(Constant.BUS_RULE_ERROR);
			errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel.getInvoiceKey(), "E0001", Constant.SGSTRATE, Constant.BUSINESS_RULE, false,outwardInvoiceModel.getDocumentNo(),outwardInvoiceModel.getsGSTIN(),Constant.INVOICE));

		}

	}
	 */

	/**
	 * Validating Document Date for greater than Registration Date
	 */
	@SuppressWarnings({ "unchecked"}) 
	private void validateDocumentDateForRegDate(OutwardInvoiceModel outwardInvoiceModel, String groupCode) {

		Date registrationDate=null;
		Date docDt = null;
		String gstinId = outwardInvoiceModel.getsGSTIN();

		gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(
				groupCode+"_"+ Constant.REDIS_CACHE,
				Constant.GSTIN_DEATILS);
		
		TblGstinDetailsDomain gstin = null;
		if(gstinMap != null){
			gstin = gstinMap.get(gstinId);
			if(gstin != null && gstin.getRegdt() != null){
				registrationDate = gstin.getRegdt();
				
				log.info("In validateDocumentDateForRegDate, GSTIN and Effective Registration Date is " + gstinId + "AND" + gstin.getRegdt());
			}
			else {
				
				log.warn("Before Loading the Redis From DB for method validateDocumentDateForRegDate" + groupCode);
				loadGSTINDetailsToRedis(groupCode);
				gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(groupCode+"_"+ Constant.REDIS_CACHE,
						Constant.GSTIN_DEATILS);
				
				log.warn("After Loading the Redis From DB for method validateDocumentDateForRegDate" + groupCode);
			}
		}else{
			
			log.warn("Before Loading the Redis From DB for method validateDocumentDateForRegDate" + groupCode);
			
			loadGSTINDetailsToRedis(groupCode);
			gstinMap = (Map<String, TblGstinDetailsDomain>) redisTemplate.opsForHash().get(groupCode+"_"+ Constant.REDIS_CACHE,
					Constant.GSTIN_DEATILS);
			
			log.warn("After Loading the Redis From DB for method validateDocumentDateForRegDate" + groupCode);
		}

		
		if(gstinMap!=null)
			gstin = gstinMap.get(gstinId);

		if (gstin == null) {

			ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, "asp-restapi.getGSTIN", groupCode, gstinId, Constant.VERB_TYPE_POST);
			//Gson gson = new Gson();
			Gson gson = new GsonBuilder().setDateFormat(Constant.DATE_FORMAT).create(); 

			if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
				gstin = gson.fromJson(response.getEntity(String.class), TblGstinDetailsDomain.class);
			}
		} 

		try {
			if(gstin != null && gstin.getRegdt() != null){
				//				registrationDate=Utility.convertStringToDate(Constant.DATE_FORMAT, gstin.getRegdt().toString());
				registrationDate=gstin.getRegdt();
			}

			String columnNames = "";

			if (registrationDate == null) {

				log.info("GST Registration Date is not available");
				columnNames = Constant.DOC_DATE;

				isErrorFound = true;
				errorList.add(ErrorActionUtility.getSalesTblErrorInfo(
						outwardInvoiceModel, "ER129", columnNames,
						Constant.BUSINESS_RULE, false,Constant.INVOICE));
			} else {

				docDt= Utility.convertStringToDate(Constant.DATE_FORMAT, outwardInvoiceModel.getDocumentDate().toString());

				log.info("DocDate :" + docDt.toString() +" ----- " + "RegDate :" + registrationDate.toString());
				if (docDt.compareTo(registrationDate) < 0) {

					log.error("Document Date is earlier than the Effective Date of GST Registration");

					isErrorFound = true;
					columnNames = Constant.DOC_DATE;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(
							outwardInvoiceModel, "ER220",columnNames,
							Constant.BUSINESS_RULE, false,Constant.INVOICE));
					log.info(outwardInvoiceModel.getId() + " ER220 " + Constant.DOC_DATE + Constant.BUSINESS_RULE);
				}else {
					Calendar docDate = Calendar.getInstance();
					Calendar regDate = Calendar.getInstance();
					docDate.setTime(docDt);
					regDate.setTime(registrationDate);
					if((outwardInvoiceModel.getDocumentType().equals(Constant.RCR) || outwardInvoiceModel.getDocumentType().equals(Constant.RDR) || outwardInvoiceModel.getDocumentType().equals(Constant.RNV)
							|| outwardInvoiceModel.getDocumentType().equals(Constant.RDLC)) &&((docDate.get(Calendar.MONTH) == (regDate.get(Calendar.MONTH))) 
									&& (docDate.get(Calendar.YEAR) == (regDate.get(Calendar.YEAR)))) ){
						errorList.add(ErrorActionUtility.getSalesTblErrorInfo(
								outwardInvoiceModel, "ER230",Constant.DOC_DATE,
								Constant.BUSINESS_RULE, false,Constant.INVOICE));
						isErrorFound = true;
						log.info(outwardInvoiceModel.getId() + " ER230 " + Constant.DOC_DATE + Constant.BUSINESS_RULE);
					}
				}
			}

		} catch (ParseException e1) {
			log.error("validateDocumentDateForRegDate() - ", e1);
		}
	}	


	/*
	 * validating document date to be within tax period boundaries
	 */

	private String loadGSTINDetailsToRedis(String groupCode ) {
		String status = null;

		ClientResponse response = new RestClientUtility().getRestServiceResponse(Constant.ASP_REST_HOSTNAME, Constant.LOAD_GSTIN_REDIS,  groupCode, null, Constant.VERB_TYPE_POST);
		Gson gson = new Gson();

		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			status = gson.fromJson(response.getEntity(String.class), String.class);
		}
		return status;

	}

	private void validateDocumentDateForTaxPeriod(OutwardInvoiceModel outwardInvoiceModel) {
		Calendar docDate = Calendar.getInstance();
		Calendar taxPeriod = Calendar.getInstance();
		Calendar currentDate = Calendar.getInstance();
		if(outwardInvoiceModel.getDocumentDate() != null && outwardInvoiceModel.getTaxperiod() != null && !outwardInvoiceModel.getTaxperiod().isEmpty()){
			try{
				docDate.setTime(Utility.convertStringToDate(Constant.DATE_FORMAT, outwardInvoiceModel.getDocumentDate().toString()));
				taxPeriod.setTime(Utility.convertStringToDate(Constant.DATEFORMAT, outwardInvoiceModel.getTaxperiod())); 
				currentDate.setTime(new Date());

				if(taxPeriod.after(currentDate)){
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER413", Constant.RETURN_PERIOD, Constant.BUSINESS_RULE, false,Constant.INVOICE));
					isErrorFound = true;
					log.info("ER413: Error in transaction " + outwardInvoiceModel.getId() + " The Tax Period cannot be a future date beyond the current Date");
				}else{

					if(docDate.get(Calendar.YEAR) > taxPeriod.get(Calendar.YEAR) || 
							(docDate.get(Calendar.MONTH) > taxPeriod.get(Calendar.MONTH) && docDate.get(Calendar.YEAR) == taxPeriod.get(Calendar.YEAR))){
						String columnNames = Constant.DOC_DATE;
						errorList.add(ErrorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, "ER223", columnNames, Constant.BUSINESS_RULE, false,Constant.INVOICE));
						isErrorFound = true;
						log.info("ER223: Error in transaction " + outwardInvoiceModel.getId() + " The Doucment Date cannot be a future date beyond the tax period");
					}

				}
			}catch(ParseException pe){
				log.error("Error Parsing Date for invoice ", outwardInvoiceModel.getId(), pe);
			}catch(Exception e){
				log.error("Error Validating DocumentDate for TaxPeriod ", e);
			}

		}
	}

	/*
	 * Method to check Original Doc Date and Original Doc Number should not be null for Amendment invoices 
	 */
	private void validateOrgDocumentNoAndDate(OutwardInvoiceModel lineItem) {

		List<String> docTypeList = Arrays.asList(Constant.RNV,Constant.CR,Constant.RCR,Constant.DR, Constant.RDR, Constant.ARFV, Constant.RDLC);

		if(docTypeList.contains(lineItem.getDocumentType())) {
			if(lineItem.getOriginalDocumentNo() == null || lineItem.getOriginalDocumentNo().trim().isEmpty() || lineItem.getOriginalDocumentDate() == null){

				isErrorFound = Boolean.TRUE;
				String columnNames = Constant.ORG_DOC_NO + "," + Constant.ORG_DOC_DATE;
				errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER414", columnNames, Constant.BUSINESS_RULE, Boolean.FALSE, 
						Constant.INVOICE));
			}else{
				if(lineItem.getDocumentDate() != null && Utility.getDateByPattern(lineItem.getDocumentDate().toString()).before(Utility.getDateByPattern(lineItem.getOriginalDocumentDate().toString()))){
					isErrorFound = Boolean.TRUE;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER254", Constant.ORG_DOC_DATE, Constant.BUSINESS_RULE, Boolean.FALSE, Constant.INVOICE));
				}
			}
		}
	}

	// BR_OUTWARD_34
	private void validateMultipleSupplyType(List<OutwardInvoiceModel> lineItems, boolean isMultipleSupplyType) {

		if(isMultipleSupplyType) {
			return;
		} else {
			String supplyType = lineItems.get(0).getSupplyType();
			for (OutwardInvoiceModel lineItem : lineItems) {
				if (!supplyType.equals(lineItem.getSupplyType())) {
					String columnNames= Constant.SupplyType;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER226", columnNames , Constant.BUSINESS_RULE, Boolean.FALSE, Constant.INVOICE));
					isErrorFound = true;
					log.info(lineItem.getId() + " ER226 " + Constant.SupplyType + Constant.BUSINESS_RULE);
				}
			}
		}
	}
	private void structuralValidationForOriginalDocumentDate(List<OutwardInvoiceModel> lineItems) {
		log.info("In structuralValidationForOriginalDocumentDate ");
		String originalDocumentDate = lineItems.get(0).getOriginalDocumentDate().toString();
		for (OutwardInvoiceModel lineItem : lineItems){
			String docType = lineItem.getDocumentType();
			if(Constant.RNV.equals(docType) || Constant.CR.equals(docType) || Constant.DR.equals(docType) || Constant.RCR.equals(docType)
					|| Constant.RDR.equals(docType) || Constant.RFV.equals(docType)){
				if(!originalDocumentDate.equals(lineItem.getOriginalDocumentDate().toString())){
					String columnNames= Constant.ORG_DOC_DATE;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER140", columnNames , Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
					isErrorFound = true;
					log.debug(lineItem.getId() + "ER140" + Constant.ORG_DOC_DATE + Constant.BUSINESS_RULE);
				}
			}
			
		}
		
	}
	
private void structuralValidationForPortCode(List<OutwardInvoiceModel> lineItems) {
	log.info("In structuralValidationForPortCode ");
		String portCode = lineItems.get(0).getPortCode();
		for (OutwardInvoiceModel lineItem : lineItems){
			String supplyType= lineItem.getSupplyType();
			if(Constant.EXPT.equalsIgnoreCase(supplyType) ||Constant.EXPWT.equalsIgnoreCase(supplyType)){
				if(!portCode.equals(lineItem.getPortCode())){
					String columnNames= Constant.PortCode;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER135", columnNames , Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
					isErrorFound = true;
					log.debug(lineItem.getId() + "ER135" + Constant.PortCode+ Constant.BUSINESS_RULE);
				}
			}
			
		}
		
	}


private void structuralValidationForShippingBillDate(List<OutwardInvoiceModel> lineItems) {
	log.info("In structuralValidationForShippingBillDate ");
	String shippingBillDate = lineItems.get(0).getShippingBillDate().toString();
	for (OutwardInvoiceModel lineItem : lineItems){
		String supplyType= lineItem.getSupplyType();
		if(Constant.EXPT.equalsIgnoreCase(supplyType) ||Constant.EXPWT.equalsIgnoreCase(supplyType)){
			if(!shippingBillDate.equals(lineItem.getShippingBillDate().toString())){
				String columnNames= Constant.SHIPPING_BILL_DATE;
				errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER137", columnNames , Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
				isErrorFound = true;
				log.debug(lineItem.getId() + "ER137" + Constant.SHIPPING_BILL_DATE+ Constant.BUSINESS_RULE);
			}
		}
		
	}
	
}


private void structuralValidationForShippingBillNumber(List<OutwardInvoiceModel> lineItems) {
	log.info("In structuralValidationForShippingBillNumber ");
	String shippingBillNumber =  lineItems.get(0).getShippingBillNo();
	for (OutwardInvoiceModel lineItem : lineItems){
		String supplyType= lineItem.getSupplyType();
		if(Constant.EXPT.equalsIgnoreCase(supplyType) ||Constant.EXPWT.equalsIgnoreCase(supplyType)){
			if(!shippingBillNumber.equals(lineItem.getShippingBillNo())){
				String columnNames= Constant.SHIPPING_BILL_NO;
				errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER136", columnNames , Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
				isErrorFound = true;
				log.debug(lineItem.getId() + "ER136" + Constant.SHIPPING_BILL_NO+ Constant.BUSINESS_RULE);
			}
		}
		
	}
	
}

// error code req
private void structuralValidationForReasonForIssuingNote(List<OutwardInvoiceModel> lineItems) {
	log.info("In structuralValidationForReasonForIssuingNote ");
	String reasonForCreditDebitNote= lineItems.get(0).getReasonForCreditDebitNote();
	for (OutwardInvoiceModel lineItem : lineItems){
		String docType =  lineItem.getDocumentType();
		if(Constant.CR.equalsIgnoreCase(docType) ||Constant.DR.equalsIgnoreCase(docType)||
				Constant.RCR.equalsIgnoreCase(docType) ||Constant.RDR.equalsIgnoreCase(docType) ||Constant.RNV.equalsIgnoreCase(docType)){
			if(!reasonForCreditDebitNote.equals(lineItem.getReasonForCreditDebitNote())){
				String columnNames= Constant.ReasonForCreditDebitNote;
				errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER141", columnNames , Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
				isErrorFound = true;
				log.debug(lineItem.getId() + "ER141" + Constant.ReasonForCreditDebitNote+ Constant.BUSINESS_RULE);
			}
		}
		
	}
	
}

private void structuralValidationForEcomGstin(List<OutwardInvoiceModel> lineItems) {
	log.info("In structuralValidationForEcomGstin ");
	String eGstin =  lineItems.get(0).geteGSTIN();
	for (OutwardInvoiceModel lineItem : lineItems){
		String docType =  lineItem.getDocumentType();
		if(!(Constant.DLC.equalsIgnoreCase(docType) || Constant.RDLC.equalsIgnoreCase(docType))){
			if(!eGstin.equals(lineItem.geteGSTIN())){
				String columnNames= Constant.EGSTIN;
				errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER138", columnNames , Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
				isErrorFound = true;
				log.debug(lineItem.getId() + "ER138" + Constant.EGSTIN+ Constant.BUSINESS_RULE);
			}
		}
			
		
	}
	
}

	public static double round(double value, int numberOfDigitsAfterDecimalPoint) {
		BigDecimal bigDecimal = new BigDecimal(value);
		bigDecimal = bigDecimal.setScale(numberOfDigitsAfterDecimalPoint,
				BigDecimal.ROUND_HALF_UP);
		return bigDecimal.doubleValue();
	} 
	
	//Added by Ashwini
	public void validateTaxperiod(List<OutwardInvoiceModel> lineItems) {
		String taxperiod = lineItems.get(0).getTaxperiod();
		if (taxperiod != null && !taxperiod.isEmpty()) {
			for (OutwardInvoiceModel lineItem : lineItems) {
				String docType = lineItem.getDocumentType();
				if (!docType.equalsIgnoreCase(Constant.DLC) && !docType.equalsIgnoreCase(Constant.RDLC)) {
					if (!taxperiod.equals(lineItem.getTaxperiod())) {
						String columnNames = Constant.TaxPeriod;
						errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER130", columnNames,
								Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
						log.debug(lineItem.getId() + " ER130 " + Constant.TaxPeriod + Constant.BUSINESS_RULE);
						isErrorFound = true;
					}
				}
			}
		}
	}

	public void validatePreGSTFlagSameForDRCRNote(List<OutwardInvoiceModel> lineItems) {
		String crDrPreGST = lineItems.get(0).getcRDRPreGST();
		for (OutwardInvoiceModel lineItem : lineItems) {
			String docType = lineItem.getDocumentType();
			if (docType.equalsIgnoreCase(Constant.DR) || docType.equalsIgnoreCase(Constant.CR)
					|| docType.equalsIgnoreCase(Constant.RCR) || docType.equalsIgnoreCase(Constant.RDR)) {
				if (!crDrPreGST.equals(lineItem.getcRDRPreGST())) {
					String columnNames = Constant.CR_DR_PRE_GST_FLAG;
					errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER132", columnNames,
							Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
					log.debug(lineItem.getId() + " ER132 " + Constant.CR_DR_PRE_GST_FLAG + Constant.BUSINESS_RULE);
					isErrorFound = true;
				}
			}
		}
	}

	public void validateCGSTINSame(List<OutwardInvoiceModel> lineItems) {
		String cGSTIN = lineItems.get(0).getcGSTIN();
		if (cGSTIN != null && !cGSTIN.isEmpty()) {
			for (OutwardInvoiceModel lineItem : lineItems) {
				String docType = lineItem.getDocumentType();
				if (!docType.equalsIgnoreCase(Constant.DLC) && !docType.equalsIgnoreCase(Constant.RDLC)) {
					if (!cGSTIN.equals(lineItem.getcGSTIN())) {
						String columnNames = Constant.CGSTIN;
						errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER133", columnNames,
								Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
						log.debug(lineItem.getId() + " ER133 " + Constant.CGSTIN + Constant.BUSINESS_RULE);
						isErrorFound = true;
					}
				}
			}
		}
	}

	public void validateOriginalCGSTINSame(List<OutwardInvoiceModel> lineItems) {
		String originalCGSTIN = lineItems.get(0).getOriginalCGSTIN();
		if (originalCGSTIN != null && !originalCGSTIN.isEmpty()) {
			for (OutwardInvoiceModel lineItem : lineItems) {
				String docType = lineItem.getDocumentType();
				if (docType.equalsIgnoreCase(Constant.RNV) || docType.equalsIgnoreCase(Constant.CR)
						|| docType.equalsIgnoreCase(Constant.DR) || docType.equalsIgnoreCase(Constant.RCR)
						|| docType.equalsIgnoreCase(Constant.RDR) || docType.equalsIgnoreCase(Constant.RFV)) {
					if (!originalCGSTIN.equals(lineItem.getOriginalCGSTIN())) {
						String columnNames = Constant.ORG_CGSTIN;
						errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER134", columnNames,
								Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
						log.debug(lineItem.getId() + " ER134 " + Constant.ORG_CGSTIN + Constant.BUSINESS_RULE);
						isErrorFound = true;
					}
				}
			}
		}
	}

	public void validateOriginalDocNumSame(List<OutwardInvoiceModel> lineItems) {
		String originalDocumentNo = lineItems.get(0).getOriginalDocumentNo();
		if (originalDocumentNo != null && !originalDocumentNo.isEmpty()) {
			for (OutwardInvoiceModel lineItem : lineItems) {
				String docType = lineItem.getDocumentType();
				if (docType.equalsIgnoreCase(Constant.RNV) || docType.equalsIgnoreCase(Constant.CR)
						|| docType.equalsIgnoreCase(Constant.DR) || docType.equalsIgnoreCase(Constant.RCR)
						|| docType.equalsIgnoreCase(Constant.RDR) || docType.equalsIgnoreCase(Constant.RFV)) {
					if (!originalDocumentNo.equals(lineItem.getOriginalDocumentNo())) {
						String columnNames = Constant.ORG_DOC_NO;
						errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER134", columnNames,
								Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
						log.debug(lineItem.getId() + " ER134 " + Constant.ORG_DOC_NO + Constant.BUSINESS_RULE);
						isErrorFound = true;
					}
				}
			}
		}
	}

	public void validateDocDateSame(List<OutwardInvoiceModel> lineItems) {
		String docDateStr = lineItems.get(0).getDocumentDate().toString();
		if (docDateStr != null && !docDateStr.isEmpty()) {
			for (OutwardInvoiceModel lineItem : lineItems) {
				String docType = lineItem.getDocumentType();
				if (!docType.equalsIgnoreCase(Constant.DLC) && !docType.equalsIgnoreCase(Constant.RDLC)) {
					if (!lineItem.getDocumentDate().toString().equalsIgnoreCase(docDateStr)) {
						errorList.add(ErrorActionUtility.getSalesTblErrorInfo(lineItem, "ER131", Constant.DOC_DATE,
								Constant.BUSINESS_RULE, Boolean.FALSE, Constant.LINE_ITEM));
						log.debug(lineItem.getId() + " ER131 " + Constant.DOC_DATE + Constant.BUSINESS_RULE);
					}
				}
			}
		}
	}

}

