package com.ey.advisory.asp.storm.bolt.gstr7.rulestg1;

import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.dto.InwardInvoiceGstr7DTO;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleService;
import com.ey.advisory.asp.service.gstr6.Gstr6ValidationRuleServiceImpl;
import com.ey.advisory.asp.service.gstr7.Gstr7ValidationRuleService;
import com.ey.advisory.asp.service.gstr7.Gstr7ValidationRuleServiceImpl;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;


/**

* @author  Nisha Kumari
* @version 1.0
* @since   30-05-2017
*/
public class TdsRegValidationBolt extends CustomBaseRichBolt {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private CustomOutputCollector collector;
	
	private Gstr7ValidationRuleService validationRuleService;
	private final Logger log = LoggerFactory.getLogger(getClass());
	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		validationRuleService=new Gstr7ValidationRuleServiceImpl();
	}

	@Override
	public void execute(Tuple input) {
		
		InwardInvoiceGstr7DTO inwardInvoiceDTO = (InwardInvoiceGstr7DTO) input.getValue(0);
		
		try{
		log.info("Bolt1 Starts");
		
		inwardInvoiceDTO=validationRuleService.executeGSTR7ValidationRules(inwardInvoiceDTO);
		}
		catch(Exception e){
			
			log.info("TdsRegValidationBolt error"+ e);
			collector.customReportError(input, e, "Exception in Bolt TdsRegValidationBolt");
			
		}
		
		finally {
			collector.ack(input);
			if(inwardInvoiceDTO!=null){
			collector.emit(new Values(inwardInvoiceDTO));
			}
			else{
				collector.emit(new Values(input));
				}
			log.info("Bolt1 Ends");
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
	}
//rule 1 bolt
	
}

