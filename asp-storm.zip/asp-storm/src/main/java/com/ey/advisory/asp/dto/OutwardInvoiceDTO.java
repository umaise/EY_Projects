package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.google.gson.annotations.SerializedName;

public class OutwardInvoiceDTO extends InvoiceDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	
	@SerializedName(value = "gstr1",alternate={"inv"})
	private List<OutwardInvoiceModel> lineItemList;
	private String invStatus;
	private String tableType;
	private Set<TblSalesErrorInfo> errorList;
	private String groupCode;
	private boolean skipAmendmentCheck;
	private boolean isMultipleSupplyType;
	private String crdr_OrgInvNum;
	private String crdr_OrgInvDate;
	
	public String getCrdr_OrgInvNum() {
		return crdr_OrgInvNum;
	}
	public void setCrdr_OrgInvNum(String crdr_OrgInvNum) {
		this.crdr_OrgInvNum = crdr_OrgInvNum;
	}
	public String getCrdr_OrgInvDate() {
		return crdr_OrgInvDate;
	}
	public void setCrdr_OrgInvDate(String crdr_OrgInvDate) {
		this.crdr_OrgInvDate = crdr_OrgInvDate;
	}
	
	public List<OutwardInvoiceModel> getLineItemList() {
		return lineItemList;
	}
	public void setLineItemList(List<OutwardInvoiceModel> lineItemList) {
		this.lineItemList = lineItemList;
	}
	public String getInvStatus() {
		return invStatus;
	}
	public void setInvStatus(String invStatus) {
		this.invStatus = invStatus;
	}
	public String getTableType() {
		return tableType;
	}
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	public Set<TblSalesErrorInfo> getErrorList() {
		return errorList;
	}
	public void setErrorList(Set<TblSalesErrorInfo> errorList) {
		this.errorList = errorList;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
    public boolean isSkipAmendmentCheck() {
        return skipAmendmentCheck;
    }
    public void setSkipAmendmentCheck(boolean skipAmendmentCheck) {
        this.skipAmendmentCheck = skipAmendmentCheck;
    }
	public boolean isMultipleSupplyType() {
		return isMultipleSupplyType;
	}
	public void setMultipleSupplyType(boolean isMultipleSupplyType) {
		this.isMultipleSupplyType = isMultipleSupplyType;
	}

}
