package com.ey.advisory.asp.service.gstr2;

import com.ey.advisory.asp.dto.InwardInvoiceDTO;

public interface Gstr2ValidationRuleService {
	
	public InwardInvoiceDTO executeGSTR2ITCValidationRules(InwardInvoiceDTO inwardInvoiceDTO);

	public String validateHsnSacAgainstNonGST(String groupCode);
}
