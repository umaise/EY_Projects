package com.ey.advisory.asp.storm.bolt.common;

import java.util.Properties;

import org.apache.storm.topology.base.BaseRichBolt;

public abstract class BoltBuilder extends CustomBaseRichBolt {
	//private Properties configs;
	
	/*public BoltBuilder(Properties configs){
		this.configs=configs;
	}
	
	public Properties getConfigs() {
		return configs;
	}

	public void setConfigs(Properties configs) {
		this.configs = configs;
	}
	*/
	
}
