package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.SerializedName;

public class ReconciliationInvoiceDetails implements Serializable  {
	private static final long serialVersionUID = 1L;
	
	@SerializedName("ID")
	private long id;

	@SerializedName("CustGSTIN")
	private String custGSTIN;

	@SerializedName("Gstin")
	private String gstin;

	@SerializedName("InvDate")
	private String invDate;

	@SerializedName("InvNum")
	private String invNum;

	@SerializedName("GSTR2A")
	private Double invValue;

	@SerializedName("Taxablevalue")
	private Double taxablevalue;

	@SerializedName("TaxPeriod")
	private String taxPeriod;
	
	@SerializedName("Status")
	private String status;
	
	@SerializedName("IsAccepted")
	private boolean accepted;
	
	@SerializedName("itm_dtl")
	private List<ReconciliationItemDetails> itemDetails = new ArrayList<>();

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCustGSTIN() {
		return custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getInvDate() {
		return invDate;
	}

	public void setInvDate(String invDate) {
		this.invDate = invDate;
	}

	public String getInvNum() {
		return invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public Double getInvValue() {
		return invValue;
	}

	public void setInvValue(Double invValue) {
		this.invValue = invValue;
	}

	public Double getTaxablevalue() {
		return taxablevalue;
	}

	public void setTaxablevalue(Double taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isAccepted() {
		return accepted;
	}

	public void setAccepted(boolean accepted) {
		this.accepted = accepted;
	}

	public List<ReconciliationItemDetails> getItemDetails() {
		return itemDetails;
	}

	public void setItemDetails(List<ReconciliationItemDetails> itemDetails) {
		this.itemDetails = itemDetails;
	}
	
	

}
