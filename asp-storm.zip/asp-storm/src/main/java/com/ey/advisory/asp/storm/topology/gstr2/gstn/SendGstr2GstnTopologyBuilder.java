package com.ey.advisory.asp.storm.topology.gstr2.gstn;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.storm.bolt.gstr2.gstn.PublishGstr2RestBolt;
import com.ey.advisory.asp.storm.spout.gstr2.gstn.SendGstr2GSTNSpoutBuilder;
import com.ey.advisory.asp.storm.topology.StormTopologyBuilder;

/**
* Subclass for StormTopologybuilder for Send Gstr2 to GSTN
* related to SaleReg. 
*
* @author  Smruti Priya
* @version 1.0
* @since   06-03-2017
*/

public class SendGstr2GstnTopologyBuilder extends StormTopologyBuilder{
	
	private SendGstr2GSTNSpoutBuilder sendGstr2GSTNSpoutBuilder;
	private PublishGstr2RestBolt publishGstr2RestBolt;
	
	private final Logger log = LoggerFactory.getLogger(getClass());


	public SendGstr2GstnTopologyBuilder(Properties configs) {
		super(configs);
		initialize();
	}

	private void initialize() {
		sendGstr2GSTNSpoutBuilder=new SendGstr2GSTNSpoutBuilder(configs);
		publishGstr2RestBolt=new PublishGstr2RestBolt();
		
	}

	@Override
	public void buildDataPipeline(TopologyBuilder builder) {
		log.info("SaleRegTopologyBuilder.setBuilderDataPipeline() starts");
		
		if(builder != null){
			try{
				/*Send gstr2data to gstn spout config*/
				KafkaSpout sendgstr1TogstnSpout=sendGstr2GSTNSpoutBuilder.buildKafkaSpout();			
				builder.setSpout(configs.getProperty(Constant.STORM_SPOUT_GSTN_GSTR2), sendgstr1TogstnSpout);
				int sinkgstnBoltCount = Integer.parseInt(configs.getProperty(Constant.KAFKA_GSTN_GSTR2_SPOUT_COUNT));
				builder.setBolt("gstr2boltid",publishGstr2RestBolt).shuffleGrouping(configs.getProperty(Constant.STORM_SPOUT_GSTN_GSTR2));

				log.info("SaleRegTwoTopologyBuilder.setBuilderDataPipeline() ends");
			
			}catch(Exception e){
				log.error("Error Building SaleRegTwoTopologyBuilder Topology " + e);
			}
		}
	
	}
	

}
