package com.ey.advisory.asp.storm.bolt.gstr1.rulestg1;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblDocandSupplyType;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.KSessionUtility;
import com.ey.advisory.asp.common.KnowledgeBaseSingleton;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.TimeOutAndPersistDBUtil;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.master.domain.TblBifurcationCodes;
import com.ey.advisory.asp.storm.bolt.common.BoltBuilder;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.sun.jersey.api.client.ClientResponse;

public class SaleRegCatRuleBolt extends BoltBuilder {

	private CustomOutputCollector collector;
	private RedisTemplate<String, Object> redisTemplate;

	/*private KieSession kSession;*/

	private final Logger log = LoggerFactory.getLogger(getClass());
	private Map<String, TblBifurcationCodes> tableTypeMap = new HashMap<String, TblBifurcationCodes>();
	private Map<String, TblBifurcationCodes> subCategoryTypeMap = new HashMap<String, TblBifurcationCodes>();
	private Map<String, TblDocandSupplyType> docTypeMap = null;
	private Map<String, TblDocandSupplyType> supplyTypeMap = null;
	private KnowledgeBase kbase = null;
	private RestClientUtility restClientUtil = null;
	boolean firstLineItemChanged = false;

	/*public SaleRegCatRuleBolt(Properties configs) {
        super(configs);
	}*/

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR1_Stream1, new Fields("inv"));

	}

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		restClientUtil = new RestClientUtility();
		//KSessionUtility.getKSession("src/main/resources/rules/GSTR1/GSTR1_Classification.drl");
		this.kbase =  KnowledgeBaseSingleton.getKnowledgeBaseFromSERFile("/GSTR1_classification.ser");

		try {
			log.info("In SaleRegReadBolt.prepare() start");
			/*RedisTemplateUtil<String, Object> redisTemplateUtil = new RedisTemplateUtil<String, Object>();
        redisTemplate = redisTemplateUtil.getRedisTemplate();*/

			redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();


			/*kSession = KSessionUtility.getKSession("src/main/resources/rules/GSTR1/GSTR1Classification.drl");*/
			log.info("In SaleRegReadBolt.prepare() ends");

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}}

	@Override
	public void execute(Tuple input) {

		firstLineItemChanged = false;
		Set<TblSalesErrorInfo> errorList = new HashSet<TblSalesErrorInfo>();
		OutwardInvoiceDTO outwardInvoiceDTO = null;
		LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();
        long startTime=System.currentTimeMillis();
		try{
			Gson gson = new Gson();
			String invString=input.getString(0);
			Type listType = new TypeToken<OutwardInvoiceDTO>(){}.getType();

			outwardInvoiceDTO=gson.fromJson(invString, listType);
			log.info("In SaleRegReadBolt.execute() start");

			String groupCode = Utility.getGroupCode(outwardInvoiceDTO.getRedisKey());
			if(groupCode!=null){
				log.info("In SaleRegReadBolt.execute() : Group code is : "+groupCode);
				outwardInvoiceDTO.setGroupCode(groupCode);
			}else{
				log.info("In SaleRegReadBolt.execute() : Group code not found in REDIS");
			}
			OutwardInvoiceModel stgTable = outwardInvoiceDTO.getLineItemList().get(0);

			String orgSupplyType = stgTable.getSupplyType();
			
            log.info("In SaleRegReadBolt  redis key : "+outwardInvoiceDTO.getRedisKey() + " Invoice order : "+stgTable.getInvOrder());

			// SFT_OTGSTR1_009_a
            stgTable = validateForTAXorNIL(outwardInvoiceDTO, stgTable);


			/* InputStream fout = SaleRegCatRuleBolt.class.getResourceAsStream("/GSTR1_classification.ser");
            ObjectInputStream oos = new ObjectInputStream(fout);

            Collection<KnowledgePackage> knowledgePackages = (Collection<KnowledgePackage>) oos.readObject();
            KieBaseConfiguration kBaseConfig = KnowledgeBaseFactory.newKnowledgeBaseConfiguration();
            KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase(kBaseConfig);
            kbase.addKnowledgePackages(knowledgePackages);*/

			StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();

			getBifurcationMetadatafromRedis(redisTemplate, outwardInvoiceDTO.getGroupCode());

			if (tableTypeMap == null || subCategoryTypeMap==null) {
				if(loadBifurcationDataInRedis(outwardInvoiceDTO.getGroupCode()).equalsIgnoreCase(Constant.SUCCESS)){
					getBifurcationMetadatafromRedis(redisTemplate, outwardInvoiceDTO.getGroupCode());
				}
			}

			Double cgStAmount=  stgTable.getCgstAmount()==null? Constant.ZERO_DOUBLE: stgTable.getCgstAmount();
			Double igStAmount=  stgTable.getIgstAmount()==null? Constant.ZERO_DOUBLE: stgTable.getIgstAmount();
			Double sgStAmount=  stgTable.getSgstAmount()==null? Constant.ZERO_DOUBLE: stgTable.getSgstAmount();

			if(stgTable.getcGSTIN()!=null)
				stgTable.setcGSTIN(stgTable.getcGSTIN().trim().isEmpty() ? null: stgTable.getcGSTIN());
			if(stgTable.getPos()!=null)
				stgTable.setPos(stgTable.getPos().trim().isEmpty() ? null: stgTable.getPos());
			if(stgTable.getReverseCharge()!=null)
				stgTable.setReverseCharge(stgTable.getReverseCharge().trim().isEmpty() ? null: stgTable.getReverseCharge());
			if(stgTable.getTcsFlag()!=null)
				stgTable.setTcsFlag(stgTable.getTcsFlag().trim().isEmpty() ? null: stgTable.getTcsFlag());

			stgTable.setCgstAmount(cgStAmount);
			stgTable.setIgstAmount(igStAmount);
			stgTable.setSgstAmount(sgStAmount);
			
			Boolean isB2CLInvoice = Boolean.FALSE;
			Boolean isB2CLEAInvoice = Boolean.FALSE;
			if(Constant.CR.equalsIgnoreCase(stgTable.getDocumentType()) || Constant.DR.equalsIgnoreCase(stgTable.getDocumentType())){
				isB2CLInvoice = Utility.isB2CLInvoice(stgTable, outwardInvoiceDTO.getGroupCode());
			}
			if(Constant.RCR.equalsIgnoreCase(stgTable.getDocumentType()) || Constant.RDR.equalsIgnoreCase(stgTable.getDocumentType())){
				String B2CLEAInvoice = Utility.isB2CLEAInvoice(stgTable, groupCode);
				JsonParser parse = new JsonParser();
				JsonObject B2CLEAJson = (JsonObject) parse.parse(B2CLEAInvoice);
				if(!B2CLEAJson.isJsonNull() && B2CLEAJson.get("orgInvNum") != null && B2CLEAJson.get("orgInvDate") != null){
					isB2CLEAInvoice = Boolean.TRUE;
					outwardInvoiceDTO.setCrdr_OrgInvNum(B2CLEAJson.get("orgInvNum").getAsString());
					outwardInvoiceDTO.setCrdr_OrgInvDate(B2CLEAJson.get("orgInvDate").getAsString());
				}
			}
			
			ksession.setGlobal("errorList", errorList);
			ksession.setGlobal("isB2CLInvoice", isB2CLInvoice);
			ksession.setGlobal("isB2CLEAInvoice", isB2CLEAInvoice);
			ksession.insert(stgTable);
			ksession.fireAllRules();
			ksession.destroy();
			if(stgTable.getTableType() != null && stgTable.getSubCategory()!=null) {

				if(tableTypeMap.get(Constant.GSTR1_+stgTable.getTableType())!=null){
					stgTable.setTableType(tableTypeMap.get(Constant.GSTR1_+stgTable.getTableType()).getValue());
				}
				else{
					stgTable.setTableType("");

				}
				if(subCategoryTypeMap.get(Constant.GSTR1_+stgTable.getSubCategory())!=null){
					stgTable.setSubCategory(subCategoryTypeMap.get(Constant.GSTR1_+stgTable.getSubCategory()).getValue());
				}
				else{

					stgTable.setSubCategory("");
				}
			}
			else {
				stgTable.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getSalesTblErrorInfo(stgTable,"ER245", Constant.DOC_TYPE,"GSTR1 Bifurcation", false,Constant.INVOICE));
			}


			if (outwardInvoiceDTO.getInvStatus() == null
					|| outwardInvoiceDTO.getInvStatus().equals(
							Constant.GSTR1_BR_STG1)) {
				outwardInvoiceDTO.setInvStatus(stgTable.getItemStatus());
			}

			outwardInvoiceDTO.setErrorList(errorList);
			outwardInvoiceDTO.setTableType(stgTable.getTableType());
			log.info("Table Type identification complete:"+ stgTable.getTableType() +"--"+stgTable.getSubCategory());

			if(!firstLineItemChanged)
				stgTable.setSupplyType(orgSupplyType);
			else {
				OutwardInvoiceModel frstObject = outwardInvoiceDTO.getLineItemList().get(0);
				frstObject.setTableType(stgTable.getTableType());
				frstObject.setSubCategory(stgTable.getSubCategory());
			}
				
			
			collector.emit(input,new Values(outwardInvoiceDTO));
            //TimeOutAndPersistDBUtil.updateLatestDTM(redisKey); // move to first bolt's starting
             log.info("In SaleRegCatBolt Time taken for file : "+outwardInvoiceDTO.getRedisKey()+" Inv Order : "+ stgTable.getInvOrder()+" is "+(System.currentTimeMillis()-startTime));
		}catch(JsonSyntaxException ex){
			log.error(ex.getMessage(), ex);
			logRunTimeErros.logErrorsInredis(input.getString(0), Constant.DATA_ERROR);
			//collector.customReportError(outwardInvoiceDTO, ex, "Exception in Bolt SaleRegCatRuleBolt");
		}catch(Exception ex1){
			log.error(ex1.getMessage(), ex1);
			logRunTimeErros.logErrorsInredis(input.getString(0), Constant.DATA_ERROR);
			//collector.customReportError(outwardInvoiceDTO, ex1, "Exception in Bolt SaleRegCatRuleBolt");
		} finally {

			collector.ack(input);
            String redisKey=outwardInvoiceDTO.getRedisKey();
            //TimeOutAndPersistDBUtil.updateLatestDTM(redisKey); // move to first bolt's starting
			log.info("In SaleRegCatBolt.execute() end : "+redisKey);
            
		}
	}

	private String loadBifurcationDataInRedis(String groupCode) {
		String status = null;

		ClientResponse response = restClientUtil
				.getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
						Constant.BIFURCATION_DETAILS, groupCode, null,
						Constant.VERB_TYPE_POST);

		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			Gson gson = new Gson();
			status = gson.fromJson(response.getEntity(String.class), String.class);
		}
		return status;
	}
	
    public OutwardInvoiceModel validateForTAXorNIL(OutwardInvoiceDTO outwardInvoiceDTO, OutwardInvoiceModel firstLineItem) {

        int nilCount=0;
        int extCount=0;
        int taxCount=0;
        boolean nilFoundAtFirst = false;
        
        if(Constant.NIL.equalsIgnoreCase(firstLineItem.getSupplyType()) || Constant.EXT.equalsIgnoreCase(firstLineItem.getSupplyType())) {
        	nilFoundAtFirst = true;
        }
        
        for (OutwardInvoiceModel lineItem : outwardInvoiceDTO.getLineItemList()) {
        	if(Constant.NIL.equalsIgnoreCase(lineItem.getSupplyType())) {
                nilCount++;
            } else if (Constant.EXT.equalsIgnoreCase(lineItem.getSupplyType())){
                extCount++;
            } else if (Constant.TAX.equalsIgnoreCase(lineItem.getSupplyType())) {
            	if(nilFoundAtFirst && !firstLineItemChanged) {
            		firstLineItem = lineItem;
            		firstLineItemChanged = true;
            	}
                taxCount++;
            }  
            
            if(nilCount>0 && extCount>0 && taxCount>0) {
            	break;
            }
        }

        if((extCount > 0 && taxCount > 0) || (nilCount > 0 && taxCount > 0)) {
            firstLineItem.setSupplyType(Constant.TAX);
            outwardInvoiceDTO.setMultipleSupplyType(true);
        } else if(nilCount > 0 && extCount > 0) {
            firstLineItem.setSupplyType(Constant.EXT);
            outwardInvoiceDTO.setMultipleSupplyType(true);
        }

        return firstLineItem;
    }

	@SuppressWarnings("unchecked")
	private void getBifurcationMetadatafromRedis(RedisTemplate<String, Object> redisTemplate, String groupCode) {
		tableTypeMap = (Map<String, TblBifurcationCodes>) redisTemplate.opsForHash()
				.get(Constant.REDIS_CACHE, Constant.CATEGORY);

		subCategoryTypeMap = (Map<String, TblBifurcationCodes>)redisTemplate.opsForHash().get(Constant.REDIS_CACHE, Constant.SUB_CATEGORY);
	}

	/*
	private KnowledgeBase readKnowledgeBase() throws Exception {
		log.info("In SaleRegReadBolt.readKnowledgeBase() starts");
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
        kbuilder.add(ResourceFactory.newClassPathResource("rules/GSTR1/GSTR1Classification.drl"), ResourceType.DRL);
        KnowledgeBuilderErrors errors = kbuilder.getErrors();
        if (errors.size() > 0) {
            for (KnowledgeBuilderError error: errors) {
                log.error(error.getMessage());
            }
            throw new IllegalArgumentException("Could not parse knowledge.");
        }
        KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
        log.info("In SaleRegReadBolt.readKnowledgeBase() ends");
        return kbase;
    }*/



}
