package com.ey.advisory.asp.common.error;

import java.util.HashSet;
import java.util.Set;

import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.exceptions.RESTCallFailureException;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

public class LogGSTR2RunTimeErros extends LogRunTimeErros {
	
	private static final Logger log = LoggerFactory.getLogger(LogGSTR2RunTimeErros.class);

	@Override
	public void logErrorsInredis(Tuple input, String errorCode) {
		try{
			 InwardInvoiceDTO inwardInvoiceDTO = (InwardInvoiceDTO) input.getValue(0);
			 
			 String redisKey=inwardInvoiceDTO.getRedisKey();
			 
			 RedisTemplate<String,Object> redisTemplate=JedisConnectionUtil.getRedisTemplateKVStringObject();
			 
			 Set<TblPurchaseErrorInfo> errorList=inwardInvoiceDTO.getErrorList();
			 Set<InvoiceProcessDto> invProcessSet;
            Set<TblPurchaseErrorInfo> errorSet;
            
			 if(inwardInvoiceDTO.getLineItemList()!=null){
				 InwardInvoiceModel inwardStagingDetail=inwardInvoiceDTO.getLineItemList().get(0);
				 String invStatusKey=redisKey+"_"+Constant.INVOICE_STATUS;
	             String invErrKey=redisKey+"_"+Constant.INVOICE_ERROR_DETAILS;
	             
	             InvoiceProcessDto invProcessDto=new InvoiceProcessDto();
	             invProcessDto.setStatus(errorCode);
	             invProcessDto.setInvOrder(inwardStagingDetail.getInvOrder());
	             
				if (redisTemplate.opsForHash().get(redisKey, invStatusKey) == null) {
					invProcessSet = new HashSet<InvoiceProcessDto>();
				} else {
					invProcessSet = (Set<InvoiceProcessDto>) redisTemplate.opsForHash().get(redisKey, invStatusKey);
				}
				invProcessSet.add(invProcessDto);
				redisTemplate.opsForHash().put(redisKey, invStatusKey,invProcessSet);
				
				errorList = inwardInvoiceDTO.getErrorList();

				if (redisTemplate.opsForHash().get(redisKey, invErrKey) == null) {
					errorSet = new HashSet<TblPurchaseErrorInfo>();
				} else {
					errorSet = (Set<TblPurchaseErrorInfo>) redisTemplate.opsForHash().get(redisKey, invErrKey);
				}
				TblPurchaseErrorInfo purchaseErrorInfo=ErrorActionUtility.getPurchaseTblErrorInfo(inwardStagingDetail, errorCode, null, Constant.TECH_ERROR, false, Constant.INVOICE);
				if(errorList==null){
					errorList=new HashSet<>();
				}
				errorList.add(purchaseErrorInfo);
				errorSet.addAll(errorList);
				redisTemplate.opsForHash().put(redisKey, invErrKey, errorSet);
				
				decrementInvoiceCount(redisKey);
			 }
			 
		}catch(Exception ex){
			log.error("Exception in LogGSTR1RunTimeErros.logErrorsInredis() : "+ex.getMessage());
		}
		
	}

	@Override
	public void logErrorsInredis(String jsonString, String errorCode) {
		String redisKey="";
		try{
			Gson gson = new Gson();
			JsonObject jsonObject = gson.fromJson( jsonString, JsonObject.class);
			JsonElement jsonElement=jsonObject.get("uk");
			redisKey= jsonElement.getAsString();
			//TODO Need to insert into new Data model for tracking
		}catch(JsonSyntaxException jsonSyntExce){
			log.error("Recevied message is not in Json format LogGSTR2RunTimeErros.logErrorsInredis() : "+jsonString);
		}catch(Exception ex){
			log.error("Exception in LogGSTR2RunTimeErros.logErrorsInredis() : "+ex.getMessage());
		}
		
	}

	@Override
	public void decrementInvoiceCount(String redisKey) {
		try{
            RedisTemplate<String, Integer> redisIntegertemplate=JedisConnectionUtil.getRedisTemplateKVStringInteger();
            
            String invCntKey=redisKey+"_"+Constant.INVOICE_COUNT;
            
            RedisAtomicInteger count=new RedisAtomicInteger(invCntKey,redisIntegertemplate);
            if(log.isInfoEnabled()){
            	 log.info("redisKey from LogGSTR2RunTimeErros.decrementInvoiceCount : "+redisKey+"   Count****"+ count);
            }
               
            if(count.intValue()==0){
                if(log.isInfoEnabled()){
                	log.info("Invoice count is coming as ZERO LogGSTR2RunTimeErros.decrementInvoiceCount  : "+redisKey);
                }
            }
            
            if(count.intValue()==1){
                //Trigger web service to update invoice status and error details to DB
                RestClientUtility restClientUtil = new RestClientUtility();
                synchronized (count) {
                	saveInvoceDetails(redisKey);  					 
                }
            }else{
                count.getAndSet(count.intValue()-1);
                if(log.isInfoEnabled())
                    log.info("After decrement count from redis : "+ count);
            }
            
		}catch(Exception ex){
			log.error("Exception in LogGSTR2RunTimeErros.decrementInvoiceCount() : "+ex.getMessage());
		}
		
	}

	@Override
	public void saveInvoceDetails(String redisKey) {
		try{
			RestClientUtility restClientUtil = new RestClientUtility();
        	String groupCode = Utility.getGroupCode(redisKey);
            restClientUtil.callRestServiceJersey(redisKey, groupCode,Constant.REST_HOST_GSTR2);
        }catch(RESTCallFailureException e){
            log.error("Error LogGSTR2RunTimeErros.saveInvoceDetails ", e);
        }catch(Exception ex){
			log.error("Exception in LogGSTR2RunTimeErros.saveInvoceDetails() : "+ex.getMessage());
		}	
		
	}
	
	

}
