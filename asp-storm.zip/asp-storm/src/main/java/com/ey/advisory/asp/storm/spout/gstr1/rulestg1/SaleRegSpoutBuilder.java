package com.ey.advisory.asp.storm.spout.gstr1.rulestg1;

import java.util.Properties;
import java.util.UUID;

import org.apache.storm.kafka.BrokerHosts;
import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.kafka.SpoutConfig;
import org.apache.storm.kafka.StringScheme;
import org.apache.storm.kafka.ZkHosts;
import org.apache.storm.spout.SchemeAsMultiScheme;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.storm.spout.SpoutBuilder;

import kafka.api.OffsetRequest;


public class SaleRegSpoutBuilder extends SpoutBuilder {
	
	private final Logger log = LoggerFactory.getLogger(getClass());

	public SaleRegSpoutBuilder(Properties configs) {
		super(configs);
	}

	@Override
	public KafkaSpout buildKafkaSpout() {
		if(log.isInfoEnabled())
		log.info("In SaleRegSpoutBuilder.buildKafkaSpout() start");
		BrokerHosts hosts = new ZkHosts(configs.getProperty(Constant.KAFKA_ZOOKEEPER));
		String topic = configs.getProperty(Constant.KAFKA_TOPIC_SALEREG);
		String zkRoot = configs.getProperty(Constant.KAFKA_SALEREG_ZKROOT);
		//String spoutId=  configs.getProperty(Constant.s)
		SpoutConfig spoutConfig = new SpoutConfig(hosts, topic, zkRoot, "SaleRegSpout-ID");
		spoutConfig.startOffsetTime=OffsetRequest.LatestTime();
		spoutConfig.scheme = new SchemeAsMultiScheme(new StringScheme());
		//spoutConfig.outputStreamId=Constant.GSTR1_Stream1;
		KafkaSpout kafkaSpout = new KafkaSpout(spoutConfig);
		if(log.isInfoEnabled())
		log.info("In SaleRegSpoutBuilder.buildKafkaSpout() end");
		return kafkaSpout;
	}

}
