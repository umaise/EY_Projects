package com.ey.advisory.asp.common.error;

import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class LogRunTimeErros {
	
	/*This  method used log run time errors occurred  in Topology
	 * Use this method only when your tuple of Type InvoiceDTO or any any othr Object apart from String.
	 */
	public abstract void logErrorsInredis(Tuple input,String errorCode);
	
	/*This  method used log run time errors occurred  in Topology
	 * Use this method only when your tuple of Type String.
	 */
	public abstract void logErrorsInredis(String jsonString,String errorCode);
	
	/*
	 * This  method will decrement the invoice count from redis.
	 */
	public abstract void decrementInvoiceCount(String redisKey);
	
	/*
	 * This  method will the save the invoice details (status and errors)  from redis to DB.
	 */
	public abstract void saveInvoceDetails(String redisKey);

}
