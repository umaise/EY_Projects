package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import com.google.gson.annotations.SerializedName;

/**
 * @author  Nilanjan Karmakar
 * @version 1.0
 * @since   06-09-2017
 */

public class TblCrDrITCAItemDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    @SerializedName("CrDrITCAItemDetailsID")
    private BigInteger crDrITCAItemDetailsID;
   
    @SerializedName("ItemNo")
    private int itemNo;
    
    @SerializedName("ItemTaxVal")
    private BigDecimal itemTaxVal;
    
    @SerializedName("TaxableValue")
    private BigDecimal taxableValue;
   
    @SerializedName("InvoiceDetailsID")
    private BigInteger invoiceDetailsID;
   
    @SerializedName("IGSTAmt")
    private BigDecimal igstAmt;

    @SerializedName("CGSTAmt")
    private BigDecimal cgstAmt;
    
    @SerializedName("SGSTAmt")
    private BigDecimal sgstAmt;
    
    @SerializedName("CessAmt")
    private BigDecimal cessAmt;
    
    @SerializedName("ITCEligiblity")
    private String itcEligibility;
    
    @SerializedName("ItcIgstAmt")
    private BigDecimal itcIgstAmt;
    
    @SerializedName("ItcCgstAmt")
    private BigDecimal itcCgstAmt;
    
    @SerializedName("ItcSgstAmt")
    private BigDecimal itcSgstAmt;

    @SerializedName("ItcCessAmt")
    private BigDecimal itcCessAmt;
    
    @SerializedName("Rate")
    private BigDecimal rate;

    @SerializedName("CRDRPreGST")
    private char crDRPreGST;    
    
	
	public BigInteger getCrDrITCAItemDetailsID() {
		return crDrITCAItemDetailsID;
	}

	public void setCrDrITCAItemDetailsID(BigInteger crDrITCAItemDetailsID) {
		this.crDrITCAItemDetailsID = crDrITCAItemDetailsID;
	}

	public int getItemNo() {
		return itemNo;
	}

	public void setItemNo(int itemNo) {
		this.itemNo = itemNo;
	}

	public BigDecimal getItemTaxVal() {
		return itemTaxVal;
	}

	public void setItemTaxVal(BigDecimal itemTaxVal) {
		this.itemTaxVal = itemTaxVal;
	}

	public BigDecimal getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(BigDecimal taxableValue) {
		this.taxableValue = taxableValue;
	}

	public BigInteger getInvoiceDetailsID() {
		return invoiceDetailsID;
	}

	public void setInvoiceDetailsID(BigInteger invoiceDetailsID) {
		this.invoiceDetailsID = invoiceDetailsID;
	}

	public BigDecimal getIgstAmt() {
		return igstAmt;
	}

	public void setIgstAmt(BigDecimal igstAmt) {
		this.igstAmt = igstAmt;
	}

	public BigDecimal getCgstAmt() {
		return cgstAmt;
	}

	public void setCgstAmt(BigDecimal cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	public BigDecimal getSgstAmt() {
		return sgstAmt;
	}

	public void setSgstAmt(BigDecimal sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	public BigDecimal getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(BigDecimal cessAmt) {
		this.cessAmt = cessAmt;
	}

	public String getItcEligibility() {
		return itcEligibility;
	}

	public void setItcEligibility(String itcEligibility) {
		this.itcEligibility = itcEligibility;
	}

	public BigDecimal getItcIgstAmt() {
		return itcIgstAmt;
	}

	public void setItcIgstAmt(BigDecimal itcIgstAmt) {
		this.itcIgstAmt = itcIgstAmt;
	}

	public BigDecimal getItcCgstAmt() {
		return itcCgstAmt;
	}

	public void setItcCgstAmt(BigDecimal itcCgstAmt) {
		this.itcCgstAmt = itcCgstAmt;
	}

	public BigDecimal getItcSgstAmt() {
		return itcSgstAmt;
	}

	public void setItcSgstAmt(BigDecimal itcSgstAmt) {
		this.itcSgstAmt = itcSgstAmt;
	}

	public BigDecimal getItcCessAmt() {
		return itcCessAmt;
	}

	public void setItcCessAmt(BigDecimal itcCessAmt) {
		this.itcCessAmt = itcCessAmt;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public char getCrDRPreGST() {
		return crDRPreGST;
	}

	public void setCrDRPreGST(char crDRPreGST) {
		this.crDRPreGST = crDRPreGST;
	}

	
}
