package com.ey.advisory.asp.storm.bolt.common;
import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.exceptions.RESTCallFailureException;

public class GSTR1RestCallBolt extends BoltBuilder {

    private CustomOutputCollector collector;
    RestClientUtility restClientUtil = null;

    private final Logger log = LoggerFactory.getLogger(getClass());
    @Override
    public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
        this.collector = collector;
        restClientUtil = new RestClientUtility();
    }
    

    @Override
    public void execute(Tuple input) {
        OutwardInvoiceDTO outwardInvoiceDTO = null;
        long startTime=System.currentTimeMillis();
        int invOrder=0;
        try{
            log.info("In GSTR1RestCallBolt.execute() start");
            
        	outwardInvoiceDTO = (OutwardInvoiceDTO) input.getValueByField("inv");
        	OutwardInvoiceModel stgTable = outwardInvoiceDTO.getLineItemList().get(0);
        	invOrder=stgTable.getInvOrder();
        	log.info("In GSTR1RestCallBolt  redis key : "+outwardInvoiceDTO.getRedisKey() + " Invoice order : "+stgTable.getInvOrder());
        	
        	Integer incInvCnt=(Integer) input.getValueByField("invCount");
        	
			Long incPsdCnt=(Long) input.getValueByField("invPsdCnt");
        	
			Integer invPsdCnt= incPsdCnt.intValue();
        	log.info("Invoice Count > "+incInvCnt);
        	log.info("Invoice processed Count > "+incPsdCnt);
         
            if(invPsdCnt!=null && invPsdCnt.equals(incInvCnt)){
                log.info("Going to call GSTR1 save rest call for "+outwardInvoiceDTO.getRedisKey());
                log.info("Invoice Count >> "+incInvCnt);
                log.info("Invoice processed Count >> "+incPsdCnt);  
                
                try{
                	collector.ack(input);
                    restClientUtil.callRestServiceJersey(outwardInvoiceDTO.getRedisKey(), outwardInvoiceDTO.getGroupCode(),Constant.REST_HOST);
                }catch(RESTCallFailureException e){
                    log.error("Exception in Bolt GSTR1RestCallBolt due to REST call failure : ", e);
                    //collector.customReportError(input, e, "Exception in Bolt GSTR1RestCallBolt due to REST call failure");
                }	
            }

        }
        catch(Exception ex){			
            log.error("Error in bolt GSTR1RestCallBolt : ", ex);
            //logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
        }
        finally {
            collector.ack(input);
            if(log.isInfoEnabled())
            	log.info("In GSTR1RestCallBolt Time taken for file : "+outwardInvoiceDTO.getRedisKey()+" Inv Order : "+ invOrder+" is "+(System.currentTimeMillis()-startTime));
        }
        
       
    }

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		//declarer.declare(new Fields("inv","invCount","invPsdCnt"));
		
	}

}
