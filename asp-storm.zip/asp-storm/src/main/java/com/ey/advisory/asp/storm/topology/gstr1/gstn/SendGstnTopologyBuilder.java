package com.ey.advisory.asp.storm.topology.gstr1.gstn;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.redis.bolt.AbstractRedisBolt;
import org.apache.storm.redis.common.config.JedisPoolConfig;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseRichBolt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.redis.mapper.SaleRegRedisCompute;
import com.ey.advisory.asp.storm.bolt.gstr1.gstn.PublishGstr1RestBolt;
import com.ey.advisory.asp.storm.spout.gstr1.gstn.SendGSTNSpoutBuilder;
import com.ey.advisory.asp.storm.topology.StormTopologyBuilder;

/**
* Subclass for StormTopologybuilder for Rule stage 1 of GSTR1
* related to SaleReg. 
*
* @author  Siddharth Pahuja
* @version 1.0
* @since   06-03-2017
*/

public class SendGstnTopologyBuilder extends StormTopologyBuilder{
	
	private SendGSTNSpoutBuilder sendGSTNSpoutBuilder;
	private PublishGstr1RestBolt publishGstr1RestBolt;
	
	private final Logger log = LoggerFactory.getLogger(getClass());


	public SendGstnTopologyBuilder(Properties configs) {
		super(configs);
		initialize();
	}

	private void initialize() {
		sendGSTNSpoutBuilder=new SendGSTNSpoutBuilder(configs);
		publishGstr1RestBolt=new PublishGstr1RestBolt();
		
	}

	@Override
	public void buildDataPipeline(TopologyBuilder builder) {
		log.info("SaleRegTopologyBuilder.setBuilderDataPipeline() starts");
		
		if(builder != null){
			try{
				/*Send gstr1data to gstn spout config*/
				KafkaSpout sendgstr1TogstnSpout=sendGSTNSpoutBuilder.buildKafkaSpout();			
				builder.setSpout(configs.getProperty(Constant.STORM_SPOUT_GSTN_GSTR1), sendgstr1TogstnSpout);
				int sinkgstnBoltCount = Integer.parseInt(configs.getProperty(Constant.KAFKA_GSTN_GSTR1_SPOUT_COUNT));
				builder.setBolt("gstr1boltid",publishGstr1RestBolt).shuffleGrouping(configs.getProperty(Constant.STORM_SPOUT_GSTN_GSTR1));

				if(log.isInfoEnabled())
				log.info("SaleRegTwoTopologyBuilder.setBuilderDataPipeline() ends");
			
			}catch(Exception e){
				log.error("Error Building SaleRegTwoTopologyBuilder Topology " + e);
			}
		}
	
	}
	

}
