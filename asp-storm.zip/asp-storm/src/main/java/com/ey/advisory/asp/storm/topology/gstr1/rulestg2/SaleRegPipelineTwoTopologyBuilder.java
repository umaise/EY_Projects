package com.ey.advisory.asp.storm.topology.gstr1.rulestg2;

import java.util.Properties;

import org.apache.storm.kafka.KafkaSpout;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.topology.base.BaseRichBolt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.redis.mapper.SaleRegRedisCompute;
import com.ey.advisory.asp.storm.bolt.common.GSTR1RedisWSBolt;
import com.ey.advisory.asp.storm.bolt.common.PublishRedisBolt;
import com.ey.advisory.asp.storm.bolt.gstr1.rulestg2.SaleRegRule2AdvBolt;
import com.ey.advisory.asp.storm.spout.gstr1.rulestg2.SaleRegPipelineTwoSpoutBuilder;
import com.ey.advisory.asp.storm.topology.StormTopologyBuilder;

/**
* Subclass for StormTopologybuilder for Rule stage 2 of GSTR1
* related to SaleReg. 
*
* @author  Siddharth Pahuja
* @version 1.0
* @since   06-03-2017
*/

public class SaleRegPipelineTwoTopologyBuilder extends StormTopologyBuilder{
	
	private SaleRegPipelineTwoSpoutBuilder saleRegPipelineTwoSpoutBuilder;
	private SaleRegRule2AdvBolt saleRegRule2AdvBolt;
	private GSTR1RedisWSBolt gstr1RedisWSBolt;
	private BaseRichBolt saleRegRedisCompute;
	private PublishRedisBolt publishRedisBolt;
	
	private final Logger log = LoggerFactory.getLogger(getClass());


	public SaleRegPipelineTwoTopologyBuilder(Properties configs) {
		super(configs);
		initialize();
	}

	private void initialize() {
		saleRegPipelineTwoSpoutBuilder=new SaleRegPipelineTwoSpoutBuilder(configs);
		saleRegRule2AdvBolt=new SaleRegRule2AdvBolt();
		gstr1RedisWSBolt=new GSTR1RedisWSBolt();
		saleRegRedisCompute=new SaleRegRedisCompute();
		publishRedisBolt=new PublishRedisBolt();
	}

	@Override
	public void buildDataPipeline(TopologyBuilder builder) {
		if(log.isInfoEnabled())
		log.info("SaleRegTopologyBuilder.setBuilderDataPipeline() starts");
		
		if(builder != null){
			try{
				KafkaSpout salRegSpout=saleRegPipelineTwoSpoutBuilder.buildKafkaSpout();
				
				builder.setSpout("salreg2-spout", salRegSpout);
				
				builder.setBolt("saleRegAdvBolt1",saleRegRule2AdvBolt).shuffleGrouping("salreg2-spout");
				
				builder.setBolt("saleRegAdvBolt2",gstr1RedisWSBolt).shuffleGrouping("saleRegAdvBolt1"); 
				
				builder.setBolt("saleRegAdvBolt3",saleRegRedisCompute).shuffleGrouping("saleRegAdvBolt2");
				
				builder.setBolt("saleRegAdvBolt4",publishRedisBolt).shuffleGrouping("saleRegAdvBolt3");
				
				if(log.isInfoEnabled())
				log.info("SaleRegTopologyBuilder.setBuilderDataPipeline() ends");
			
			}catch(Exception e){
				log.error("Error SaleRegPipelineTwoTopologyBuilder " + e);
			}
		}
	
	}
	

}
