package com.ey.advisory.asp.common;

import java.math.BigDecimal;

public class Constant {

    public static final String TOPOLOGY_NAME = "asp.topology";

    public static final String KAFKA_ZOOKEEPER = "kafka.zookeeper";

    public static final String REDIS_HOST = "redis.host";
    public static final String REDIS_PORT = "redis.port";
    
    public static final String REDIS_POOL_MAX_ACTIVE="redis.pool.maxActive";
    public static final String REDIS_POOL_MAX_IDLE="redis.pool.maxIdle";
    public static final String REDIS_POOL_MAX_WAIT="redis.pool.maxWait";
    public static final String REDIS_POOL_TEST_ON_BORROW="redis.pool.testOnBorrow";
    public static final String REDIS_PASSWORD_ENC="redis.password.encrypted";
    public static final String REDIS_TIME_OUT="redis.pool.timeout";

    // Sales register Spout info
    public static final String STORM_SPOUT_SALEREG = "storm.spout.salreg";
    public static final String KAFKA_SALEREG_ZKROOT = "kafka.salereg.zkRoot";
    public static final String KAFKA_TOPIC_SALEREG = "kafka.topic.salereg";
    public static final String KAFKA_SALEREG_SPOUT_COUNT = "kafka.salereg.spout.count";

    // Purchase register Spout info
    public static final String STORM_SPOUT_PURCHASEREG = "storm.spout.purchasereg";
    public static final String KAFKA_PURCHASEREG_ZKROOT = "kafka.purchasereg.zkRoot";
    public static final String KAFKA_TOPIC_PURCHASEREG = "kafka.topic.purchasereg";
    public static final String KAFKA_PURCHASEREG_SPOUT_COUNT = "kafka.purchasereg.spout.count";

    // GSTR2A Reconciliation Spout Info
    public static final String STORM_SPOUT_GSTR2A_RECON = "storm.spout.gstr2aRecon";
    public static final String KAFKA_GSTR2A_RECON_ZKROOT = "kafka.gstr2aRecon.zkRoot";
    public static final String KAFKA_TOPIC_GSTR2A_RECON = "kafka.topic.gstr2aRecon";
    public static final String KAFKA_GSTR2A_RECON_SPOUT_COUNT = "kafka.gstr2aRecon.spout.count";
    
    // GSTR6A Reconciliation Spout Info
    public static final String STORM_SPOUT_GSTR6A_RECON = "storm.spout.gstr6aRecon";
    public static final String KAFKA_GSTR6A_RECON_ZKROOT = "kafka.gstr6aRecon.zkRoot";
    public static final String KAFKA_TOPIC_GSTR6A_RECON = "kafka.topic.gstr6aRecon";
    public static final String KAFKA_GSTR6A_RECON_SPOUT_COUNT = "kafka.gstr6aRecon.spout.count";
    
 // ISD register Spout info
    public static final String STORM_SPOUT_ISDREG = "storm.spout.isdreg";
    public static final String KAFKA_ISDREG_ZKROOT = "kafka.isdreg.zkRoot";
    public static final String KAFKA_TOPIC_ISDREG = "kafka.topic.isdreg";
    public static final String KAFKA_ISDREG_SPOUT_COUNT = "kafka.isdreg.spout.count";
    
    // ISD register Spout info
    public static final String STORM_SPOUT_TDSREG = "storm.spout.tdsreg";
    public static final String KAFKA_TDSREG_ZKROOT = "kafka.tdsreg.zkRoot";
    public static final String KAFKA_TOPIC_TDSREG = "kafka.topic.tdsreg";
    public static final String KAFKA_TDSREG_SPOUT_COUNT = "kafka.tdsreg.spout.count";

    // Sales register Bolt info
    public static final String SALEREG_READ_BOLT_COUNT = "kafka.salereg.spout.count";

    public static final String BOLT_SALEREG_RULE1="bolt.salreg.rule1";
    public static final String BOLT_SALEREG_RULE2="bolt.salreg.rule2";
    public static final String BOLT_SALEREG_RULE3="bolt.salreg.rule3";
    public static final String BOLT_SALEREG_RULE4="bolt.salreg.rule4";
    public static final String BOLT_SALEREG_RULE5="bolt.salreg.rule5";

    public static final String BOLT_COMPUTE_REDIS="bolt.compute.redis";
    public static final String BOLT_PUBLISH_REDIS="bolt.publish.redis";
    public final static String ENTITY_KEY ="ENTITY_KEY";

    public final static String BOLT_GSTR1_REDIS_WS ="bolt.gstr1.redis.ws";

    // Purchase register Bolt info
    public static final String PURCHASEREG_READ_BOLT_COUNT = "kafka.purchasereg.spout.count";

    public static final String BOLT_PURCHASEREG_RULE1 = "bolt.purchasereg.rule1";
    public static final String BOLT_PURCHASEREG_RULE2 = "bolt.purchasereg.rule2";
    public static final String BOLT_PURCHASEREG_RULE3 = "bolt.purchasereg.rule3";
    public static final String BOLT_PURCHASEREG_RULE4 = "bolt.purchasereg.rule4";

    public static final String BOLT_GSTR2_REDIS_WS = "bolt.gstr2.redis.ws";
    public static final String BOLT_PURCHASEPUBLISH_REDIS = "bolt.purchasepublish.redis";
    public static final String BOLT_PURCHSECOMPUTE_REDIS = "bolt.purchsecompute.redis";
    
    // ISD register Bolt info
    public static final String ISDREG_READ_BOLT_COUNT = "kafka.isdreg.spout.count";

    public static final String BOLT_ISDREG_RULE1 = "bolt.isdreg.rule1";
    public static final String BOLT_ISDREG_RULE2 = "bolt.isdreg.rule2";
    public static final String BOLT_ISDREG_RULE3 = "bolt.isdreg.rule3";
    public static final String BOLT_ISDREG_RULE4 = "bolt.isdreg.rule4";
    public static final String BOLT_ISDREG_RULE5 = "bolt.isdreg.rule5";
    public static final String BOLT_ISDREG_RULE6 = "bolt.isdreg.rule6";

    public static final String BOLT_ISDCOMPUTE_REDIS = "bolt.isdcompute.redis";
    
    // TDS register Bolt info
    public static final String TDSREG_READ_BOLT_COUNT = "kafka.tdsreg.spout.count";

    public static final String BOLT_TDSREG_RULE1 = "bolt.tdsreg.rule1";
    public static final String BOLT_TDSREG_RULE2 = "bolt.tdsreg.rule2";
    public static final String BOLT_TDSREG_RULE3 = "bolt.tdsreg.rule3";
    public static final String BOLT_GSTR7_REDIS_WS= "bolt.gstr7.redis.ws";
    public static final String BOLT_TDSCOMPUTE_REDIS = "bolt.tdscompute.redis";

    //GSTR2A Reconciliation Bolt Info
    public static final String BOLT_GSTR2A_RECON = "bolt.gstr2a.recon";
    public static final String BOLT_GSTR2A_RECON_ITC="bolt.gstr2a.itc";
    public static final String BOLT_GSTR2A_RECON_REDIS_WS = "bolt.gstr2a.recon.redisWS";
    
    //GSTR6A Reconciliation Bolt Info
    public static final String BOLT_GSTR6A_RECON = "bolt.gstr6a.recon";
    public static final String BOLT_GSTR6A_RECON_ITC="bolt.gstr6a.itc";
    public static final String BOLT_GSTR6A_RECON_REDIS_WS = "bolt.gstr6a.recon.redisWS";

    public final static String PROCESSED_SUCCESS = "processed";
    public final static String PROCESSED_ERROR = "error";
    public final static String REDIS_INVOICE_CHANNEL="INVOICE_STATUS";

    public final static String SUCCESS = "SUCCESS";
    public final static String BUS_RULE_ERROR = "BUS_RULE_ERROR";
    public final static String ERROR_LIST_CACHE = "ERROR_LIST_CACHE";
    
    public final static String DATA_ERROR = "DATA_ERROR";
    public final static String TECH_ERROR = "TECH_ERROR";
    
    public final static String B2B = "B2B";
    public final static String B2BA = "B2BA";
    public final static String CDN = "CDN" ;
    public final static String CDNA = "CDNA";
    public final static String B2CL = "B2CL";
    public final static String B2CLA = "B2CLA";
    public final static String B2CS = "B2CS";
    public final static String B2CSA = "B2CSA";
    public final static String NIL = "NIL";
    public final static String EXPA = "EXPA";
    public final static String TXPD = "TXPD";
    public final static String ECOM ="ECOM";
    public final static String ANVA ="ANVA";
    public final static String RADV="RADV";
    
    public static final String GSTR1_B2B="B2B";
    public static final String GSTR1_B2BA="B2BA";
    public static final String GSTR1_B2CL="B2CL";
    public static final String GSTR1_B2CLA="B2CLA";
    public static final String GSTR1_CDNRA="CDNRA";
    public static final String GSTR1_CDNURA="CDNURA";
    public static final String GSTR1_EXP="EXP";
    public static final String GSTR1_EXPA="EXPA";
    public static final String GSTR1_B2CS="B2CS";
    public static final String GSTR1_B2CSA="B2CSA";
    public static final String GSTR1_NIL="NIL";
    
    public final static String ZERO ="0";
    public final static int INTIEGER_ZERO =0;

    public static final String REST_HOST = "asp-restapi.host";
    public static final String REST_HOSTNAME= "asp-restapi.host";
    public static final String REDIS_PASSWORD="redis.password";

    public static final String REST_HOST_GSTR2 = "asp-restapi.gstr2.host";
    public static final String REST_HOST_GSTR2A_RECON = "asp-restapi.gstr2a.recon.host";
    

	public static final String TaxPeriod = "TaxPeriod";
    public static final String HSN_MASTER_DET = "HSN_MASTER_DETAILS";
    public static final String REDIS_CACHE = "REDIS_CACHE";
    public static final String CLIENT_STG_DETAILS = "CLIENT_STG_DETAILS";
    public static final String ERROR_MASTER_LIST = "ERROR_MASTER_LIST";
    public final static String INFORMATION = "INFORMATION";
    public static final String PROC_HSN_MASTER_NAME	="dbo.usp_GetMasterHSNCodeDetails";
    public static final String EXT	="EXT";
    public static final String NON	="NON";
    public static final double ZERO_DOUBLE	=0.0;
    public static final String ANY = "ANY";
	public static final String UPDATE_RECON_FILING_REST = "recon_update_filing_rest";
	public static final String UPDATE_RECON_6_FILING_REST = "recon_6_update_filing_rest";

	// GSTN sPOUT INFO
    public static final String STORM_SPOUT_GSTN_GSTR1 = "storm.spout.gstn.gstr1";
    public static final String KAFKA_GSTN_GSTR1_SPOUT_COUNT = "kafka.gstn.gstr1.spout.count";
    public static final String KAFKA_GSTN_TOPIC_GSTR1 = "kafka.topic.gstn.gstr1";
    public static final String KAFKA_GSTN_GSTR1_ZKROOT = "kafka.gstn.gstr1.zkRoot";
    public final static String ASP_REST_HOST = "asp-restapi.retsave.host";

    public static final String INVOICE_COUNT = "InvCount";
    public static final String INVOICE_STATUS = "InvStatus";
    public static final String INVOICE_STATUS_VAL = "InvStatusVal";
    public static final String INVOICE_PSD_COUNT = "InvPsdCount";
    public static final String INVOICE_ERROR_DETAILS = "InvError";
    public static final String INVOICE_UPDATE_TS = "LatestDTM";
    public static final String RECON_COUNT = "ReconCount";
    public static final String RECON_FILING_STATUS = "ReconFilingStatus";
    public static final String SYSTEM_ERROR_DETAILS = "SysError";
    public static final String INPUTS = "IG";
    public static final String CAPITAL_GOODS = "CG";
    public static final String INPUT_SERVICES = "IS";
    public static final String NONE = "NO";
    public static final String NO = "NO";

    public static final String GOODS = "G";
    public static final String SERVICES = "S";

    public static final String INV = "INV";
    public static final String RNV = "RNV";
    public static final String RSLF = "RSLF";
    public static final String SLF = "SLF";
    public static final String INA = "INA";
    public static final String TAX = "TAX";
    public static final String UNR = "UNR";
    public static final String IMP = "IMP";
    public static final String CR = "CR";
    public static final String DR = "DR";
    public static final String RCR = "RCR";
    public static final String RDR = "RDR";
    public static final String COM = "COM";
    public static final String ISD = "ISD";
    public static final String TCS = "TCS";
    public static final String ADG = "ADG";
    public static final String ADV = "ADV";
    public static final String RADG = "RADG";
    public static final String ADS = "ADS";
    public static final String RADS = "RADS";
    public static final String NA = "NA";
    public static final String SEZ = "SEZ";
    public static final String SEZG = "SEZG";
    public static final String SEZS = "SEZS";
    public static final String EXP = "EXP";
    public static final String EXPT = "EXPT";
    public static final String EXPWT = "EXPWT";
    public static final String DXP = "DXP";
    public static final String RFV = "RFV";
    public static final String ARFV = "ARFV";
    public static final String RANV = "RANV";
    public static final String DLC = "DLC";
    public static final String RDLC = "RDLC";
    public static final String NYS = "NYS";
    public static final String DTA = "DTA";
    public static final String IMPS = "IMPS";
    public static final String IMPG = "IMPG";
    public static final String RRFV = "RRFV";
    public static final String CAN = "CAN";
   
    public static final String RLDC = "RLDC";
    public static final String NSY = "NSY";
    public static final String VERB_TYPE_POST = "POST";
    public static final String VERB_TYPE_GET = "GET";
    public static final String YES = "YES";

    public final static String GSTR2_B2B = "GSTR2_B2B";
    public final static String GSTR2_B2BUR = "GSTR2_B2BUR";
    public final static String GSTR2_B2BURA = "GSTR2_B2BURA";
    public final static String GSTR2_B2BA = "GSTR2_B2BA";
    public final static String GSTR2_CDN = "GSTR2_CDN";
    public final static String GSTR2_CDNA = "GSTR2_CDNA";
    public final static String GSTR2_AT = "GSTR2_AT";
    public final static String GSTR2_ATA = "GSTR2_ATA";
    public final static String GSTR2_IMPG = "GSTR2_IMPG";
    public final static String GSTR2_IMPGA = "GSTR2_IMPGA";
    public final static String GSTR2_IMPS = "GSTR2_IMPS";
    public final static String GSTR2_IMPSA = "GSTR2_IMPSA";
    public final static String GSTR2_ISD = "GSTR2_ISD";
    public final static String GSTR2_TCS = "GSTR2_TCS";
    public final static String GSTR2_TXP = "GSTR2_TXP";
    public final static String GSTR2_NIL = "GSTR2_NIL";
    public final static String GSTR2_RCM = "GSTR2_RCM";
    public final static String GSTR2_SEZG = "GSTR2_SEZG";
    
    public final static String GSTR6_B2B = "GSTR6_B2B";
    public final static String GSTR6_B2BA = "GSTR6_B2BA";
    public final static String GSTR6_IMPG = "GSTR6_IMPG";
    public final static String GSTR6_IMPGA = "GSTR6_IMPGA";
    public final static String GSTR6_INV = "GSTR6_INV";
    public final static String GSTR6_REVISED_INV = "GSTR6_REVISED_INV";
    public final static String GSTR6_DRCR_INV = "GSTR6_DRCR_INV";
    public final static String GSTR6_RCRDR_INV = "GSTR6_RCRDR_INV";
    public final static String GSTR6_ITCDI = "ITCDI";
    public final static String GSTR6_CRDRITCDA = "CRDRITCDA";

    public static final String GSTR1_BR_STG1 = "GSTR1_BR_STG1";
    public static final String GSTR2_BR_STG1 = "GSTR2_BR_STG1";

    public static final String GSTR6_BR_STG1 = "GSTR6_BR_STG1";
    public static final String GSTR7_BR_STG1 = "GSTR7_BR_STG1";
    
    public final static String GSTR7_B2B = "GSTR7_B2B";
    public final static String GSTR7_B2BA = "GSTR7_B2BA";


    public static final String GSTIN_DEATILS = "GSTIN_DEATILS";
    public static final String ASP_REST_ADVTAX = "asp-restapi.advTax.host";

    public static final String KAFKA_TOPIC_SALEREG_PIPE2 = "kafka.gstr1.topic.pipeline2";

    public static final String KAFKA_SALEREG_ZKROOT_PIPE2 = "kafka.gstr1.zkroot.pipeline2";
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final int STATUS_OK = 200;
    public static final int HTTP_CREATED = 201;

    // GSTN SPOUT INFO for Gstr2
    public static final String STORM_SPOUT_GSTN_GSTR2 = "storm.spout.gstn.gstr2";
    public static final String KAFKA_GSTN_GSTR2_SPOUT_COUNT = "kafka.gstn.gstr2.spout.count";
    public static final String KAFKA_GSTN_TOPIC_GSTR2 = "kafka.topic.gstn.gstr2";
    public static final String KAFKA_GSTN_GSTR2_ZKROOT = "kafka.gstn.gstr2.zkRoot";
    public static final String ASP_GSTR2_REST_HOST = "asp-restapi.gstr2.sendGstn.host";

    // GSTR2A Reconciliation
    public static final String RECON_STATUS_MODIFIED = "M";
    public static final String RECON_STATUS_ACCEPTED = "A";
    public static final String RECON_STATUS_PENDING = "P";
    public static final String RECON_STATUS_NO_ACTION = "N";
    public static final String RECON_STATUS_UPLOADED = "U";
    public static final String RECON_STATUS_REJECTED = "R";
    public static final String RECON_STATUS_DELETE = "D";

    public static final String FILING_RECORD_TYPE_PURCHASE_REGISTER = "PR";
    public static final String FILING_RECORD_TYPE_GSTR2A = "GSTR2A";
    public static final String FILING_RECORD_TYPE_RECON = "RECON";

    public static final String UNKNOWN_ERROR = "UNKNOWN ERROR";

    // other constants'
    public static final String TYPE = "type";
    public static final String VALUE = "val";
    public static final String COUNT = "cnt";
    public static final String DATE_T_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_Z_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String DATEFORMAT = "MMyyyy";
    public static final String DATE_M_FORMAT = "MM.yyyy";
    public static final String DATE_YEARFORMAT = "MM-yyyy";
    public static final String TILDE = "~";
    public static final String KEY = "key";
    public static final String PURCHASE_REGDATA = "purchaseregdata";
    public static final String SALE_REGDATA = "saleregdata";
    public static final String JAVASCRIPT = "JavaScript";
    public static final String REVERSE_CHARGE = "REVERSE_CHARGE";
    public static final String BUSINESS_RULE = "Business Rule";
    public static final String PROVISIONAL_ASSESSMENT = "PROVISIONAL_ASSESSMENT";
    
    //----- SupplyMetaData------
    public static final String IGST_AMOUNT = "IGST_AMT";
    public static final String CGST_AMOUNT = "CGST_AMT";
    public static final String SGST_AMOUNT = "SGST_AMT";
    public static final String CESS_AMT_ADV = "SGST_AMT_ADV";
    public static final String CESS_AMT_SPECIFIC = "CESS_AMT";
    
    public static final String IGSTRATE="IGST_RATE";
    public static final String CGSTRATE="CGST_RATE";
    public static final String SGSTRATE="SGST_RATE";
    public static final String CESS_RATE_ADV="SGST_RATE_ADV";
    public static final String CESS_RATE_SPECIFIC="CESS_RATE";
    
    public static final String IGST_AMOUNT_GSTR2 = "IGSTAmount";
    public static final String CGST_AMOUNT_GSTR2 = "CGSTAmount";
    public static final String SGST_AMOUNT_GSTR2 = "SGSTAmount";
    public static final String CESS_AMT_ADV_GSTR2 = "CessAmountAdvalorem";
    public static final String CESS_AMT_SPECIFIC_GSTR2 = "CessAmountSpecific";
 
    
    public static final String IGSTRATE_GSTR2="IGSTRate";
    public static final String CGSTRATE_GSTR2="CGSTRate";
    public static final String SGSTRATE_GSTR2="SGSTRate";
    public static final String CESS_RATE_ADV_GSTR2="CessRateAdvalorem";
    public static final String CESS_RATE_SPECIFIC_GSTR2="CessRateSpecific";
    
    public static final String TAXABLE_VALUE = "TaxableValue";
    public static final String INVOICE_VALUE = "InvoiceValue";
	public static final String ORG_DOC_NO = "ORG_DOC_NO";
    public static final String ORG_DOC_DATE = "OrgDocDate";
    public static final String DOC_NO = "DOC_NO";
    public static final String DOC_DATE = "DOC_DATE";
    public static final String SupplyType = "SupplyType";
	public static final String DOC_TYPE = "DOC_TYPE";
	public static final String GSTR2_DOC_TYPE = "DocumentType";
	public static final String HSN_SAC = "HSNorSAC";
	public static final String SHIPPING_BILL_NO = "SHIPPING_BILL_NO";
	public static final String SHIPPING_BILL_DATE = "SHIPPING_BILL_DATE";
	public static final String POS = "POS";
	public static final String EXPORT_DUTY = "ExportDuty";
	public static final String CGSTIN = "CGSTIN";
	public static final String ORG_CGSTIN = "ORG_GSTIN";
	public static final String RETURN_PERIOD = "TaxPeriod";
	public static final String PortCode = "PortCode";
	public static final String ReasonForCreditDebitNote="ReasonForCreditDebitNote";
	public static final String EGSTIN="EGSTIN";
	
	//-----Purchase MetaData -----------
	public static final String SGSTIN = "SGSTIN";
	public static final String ORG_SGSTIN = "OriginalSGSTIN";
	public static final String REVERSE_CHARGE_GSTR2 = "ReverseCharge";
	public static final String GSTR2_ORG_DOC_NO = "OriginalDocumentNo";
	
    public static final String FAIL = "FAIL";
    public static final String FAILED= "Failed";
    public static final String INV_PROCESSED = "INV_PROCESSED";
    public static final String JEDIS_SERVER = "inbanvmdapp01";
    public static final int JEDIS_PORT = 6379;
    public static final String INVOICE_KEY = "key1234";
    public static final String ONE = "1";
    public static final String TWO = "2";
    public static final String GSTR2 = "gstr2";
    public static final String TABLETYPE = "tabletype";
    public static final String FileID = "FileID";
    public static final String GSTR1_ = "GSTR1_";

    public static final String Y = "Y";

    public static final String ASP_REST_HOSTNAME = "asp.restHostName";
    public static final String ASP_InitalTIME_MS="asp.retry-initialTime-ms";
    public static final String ASP_MaxTIME_MS="asp.retry-maximumTime-ms";
    public static final String ASP_MAX_RETRY="asp.max-retry";
    public static final String LINE_ITEM = "Line-Item";
    public static final String INVOICE = "Invoice";

    public static final String DATE_FORMAT_MMM_YYYY = "MMM yyyy";

    //Incidence Level for rule Errors
    public static final String INCIDENCE_LEVEL_LINE_ITEM = "Line-Item";
    public static final String INCIDENCE_LEVEL_INVOICE = "Invoice";

    public static final String PROCESS_STATUS_RECONCILIATION = "RECON";

    public static final String RECONCILIATION_HOST = "reconciliation_host";

    public static final String RECON_PURCHASE_BY_PAN = "RECON_PURCHASE_BY_PAN";

    public static final String RECON_TYPE_ADDITIONAL = "ADD";
    public static final String RECON_TYPE_MISSING = "MIS";
    public static final String RECON_TYPE_MATCHED = "MAT";
    public static final String RECON_TYPE_MISMATCHED = "MISMAT";

    public static final char IS_ERROR_E = 'E';
    
    public static final String ITEM_MASTER_DETAILS = "ITEM_MASTER_DETAILS";
    
    public static final String FETCH_ITEM_MASTER_REST = "FETCH_ITEM_MASTER_REST";

	public static final String GLOBAL_MASTER_DETAILS="GLOBAL_MASTER_DETAILS";
	public static final String PRODUCT_MASTER_DETAILS="PRODUCT_MASTER_DETAILS";    
	public static final String IGST_RATE_LIST = "IGST_RATE_LIST";
	public static final String CGST_RATE_LIST = "CGST_RATE_LIST";
	public static final String SGST_RATE_LIST = "SGST_RATE_LIST";
	public static final String GLOBAL_RATES_MAP = "GLOBAL_RATES_MAP";
	
	public static final String LOAD_GSTIN_REDIS = "asp-restapi.loadGSTINDet";
	public static final String GROUP_CODE = "GroupCode";
	public static final String TENANT_CODE ="X-TENANT-ID";
	public static final String LOAD_ENTITY_REDIS = "asp-restapi.loadEntityDet";
	
	public static final String IS_B2CL_INVOICE = "asp-restapi.isB2CLInvoice";
	public static final String IS_B2CLEA_INVOICE = "asp-restapi.isB2CLEAInvoice";
	
	public static final String LOAD_HSNSAC_REDIS = "asp-restapi.loadHSNSACDetails";
	public static final String LOAD_SPECIFIC_HSNSAC_REDIS = "asp-restapi.loadSpecificHSNSACInRedis";
	public static final String REFRESH_ERRORMASTER_MAP_REDIS = "asp-restapi.refreshErrorCodeMapInRedis";
	public static final String CONTRACT = "Contract";
	public static final String N = "N";
	public static final String RINV = "RINV";
	
	public static final String KAFKA_ISD_ZKROOT = "kafka.isd.zkRoot";
    public static final String KAFKA_TOPIC_ISD = "kafka.topic.isd";
    public static final String BOLT_GSTR6_REDIS_WS = "bolt.gstr6.redis.ws";
    public static final String REST_HOST_GSTR6 = "asp-restapi.gstr6.host";

    public static final String SUPPLY_METADATA = "SUPPLY_METADATA";
    public static final String PURCHASE_METADATA = "PURCHASE_METADATA";
	
/*	public static final String CESS_ADAL_AMT = "CessAmountAdvalorem";
	public static final String CESS_SPECIFIC_AMT = "CessAmountSpecific";*/
	
	public static final String QUESTION_ANSWER_MAPPING = "QUESTION_ANSWER_MAPPING";
    public static final String CLIENT_ON_BOARDING_INFO = "asp-restapi.loadClientOnBoardingInfo";
    public static final String BIFURCATION_DETAILS = "asp-restapi.loadTableSubCategoryType";
    public static final String DOC_SUPPLY_TYPE_DETAILS = "asp-restapi.loadSupplyDocType";
    
    public static final String LINE_ITEM_CODE = "2";
    public static final String INVOICE_CODE = "1";

    public static final String GSTR1_4A="4A";
    public static final String GSTR1_4B="4B";
    public static final String GSTR1_4C="4C";
    public static final String GSTR1_5A="5A";
    public static final String GSTR1_5B="5B";
    public static final String GSTR1_6A="6A";
    public static final String GSTR1_6B="6B";
    public static final String GSTR1_6C="6C";
    public static final String GSTR1_7A="7A";
    public static final String GSTR1_7B="7B";
    public static final String GSTR1_8A="8A";
    public static final String GSTR1_8B="8B";
    public static final String GSTR1_8C="8C";
    public static final String GSTR1_8D="8D";
    public static final String GSTR1_9A="9A";
    public static final String GSTR1_9B="9B";
    public static final String GSTR1_9C="9C";
    public static final String GSTR1_10A="10A";
    public static final String GSTR1_10B="10B";
    
    public static final String GSTR2_7A="GSTR2_7A";
    public static final String GSTR2_7B="GSTR2_7B";
    public static final String GSTR2_4A="GSTR2_4A";
    public static final String GSTR2_4B="GSTR2_4B";
    public static final String GSTR2_4C="GSTR2_4C";
    public static final String GSTR2_5A="GSTR2_5A";
    public static final String GSTR2_5B="GSTR2_5B";
    public static final String GSTR2_6A="GSTR2_6A";
    public static final String GSTR2_6B="GSTR2_6B";
    public static final String GSTR2_6C="GSTR2_6C";
    public static final String GSTR2_6D="GSTR2_6D";
    public static final String GSTR2_3="GSTR2_3";
    
    public static final String GSTR6_6A="6A";
    public static final String GSTR6_6B="6B";
    public static final String GSTR6_6C="6C";
    public static final String GSTR6_3="GSTR6_3";
    
    
    public static final String DOC_TYPE_METADATA = "DOC_TYPE";
    public static final String SUPPLY_TYPE_METADATA = "SUPPLY_TYPE";
    
    public static final String CATEGORY = "Category";
    public static final String SUB_CATEGORY = "SubCategory";

	public static final String BOLT_REDIS_PROPERTIES_LOAD = "bolt.redis.properties.load";
    public static final String SERVICES_CODE = "99"; 
    
    public static final String Document_Date = "DocumentDate";
    public static final String ORIGINAL_DOC_DATE = "OriginalDocumentDate";
    public static final String Document_Type = "DocumentType";
    public static final String REVERSE_CHARGE_FLAG = "ReverseCharge";
    // Streams for topologies    
    public static final String GSTR1_Stream1="SaleReg-stream1";
    public static final String GSTR1_Stream2="SendGstn-stream2";
    public static final String GSTR2_Stream1="PurchaseReg-stream1";
    public static final String GSTR2_Stream2="SendGstr2Gstn-stream2";
    public static final String GSTR2_Stream3="GSTR2ARecon-stream3";
    
    public static final String GSTR1_COMMON_PUBREDIS_Stream="gstr1-PublishRedis-stream1";
    public static final String GSTR2_COMMON_PUBREDIS_Stream="gstr2-PublishRedis-stream1";

    public static final BigDecimal ZERO_BIG_DECIMAL  = new BigDecimal(0);

	public static final String FETCH_ITEM_BY_HSNSAC = "asp-restapi.gstr2.fetchParticaularHsnsac";

	public static final String BUSINESS_TYPE_TELECOMMUNICATION = "Telecommunications";
	public static final String BUSINESS_TYPE_PIPELINE = "CWIP";
	
	public static final Object GL_CODE_MASTER_DETAILS = "GL_CODE_MASTER_DETAILS";
	
	public static final String LOAD_GL_MASTER_REST = "asp-restapi.loadGLMaster";

	public static final String GL_MASTER_BY_CODE_REST = "asp-restapi.glMasterByCode";
	
	public static final String CUT_OFF_DATE = "2017-07-01";

	public static final String GL_ELIGIBILITY_CAPITALGOOD = "CapitalGood";

	public static final String ELIGIBILITY_INDICATOR = "EligibilityIndicator";

	public static final String FALSE = "FALSE";
	public static final String TRUE = "TRUE";

	public static final String ITC_REVERSAL_IDENTIFIER = "ITCReversalIdentifier";
  
	//------------ CLIENT ON BOARDING DETAILS STARTS -----------------------------------
	public static final String PRODUCT_MASTER_PROVIDED_QUE_ID = "6";
	public static final String PRODUCT_MASTER_PROVIDED_YES = "2";
	
	public static final String QUESTION_ITC_ELIGIBILITY = "20";
	public static final String ANSWER_ITC_ELIGIBILITY_CLIENT = "1";
	public static final String ANSWER_ITC_ELIGIBILITY_MASTER = "2";
	
	public static final Object QUESTION_TAX_CAL_LEVEL = "21";
	public static final String ANSWER_TAX_CAL_LEVEL_INVOICE = "Invoice";
	public static final String ANSWER_TAX_CAL_LEVEL_LINE_ITEM = "Line Item";
	
	public static final String QUESTION_TOTAL_TAX_ITC = "32A";
	public static final String ANSWER_TOTAL_TAX_ITC_CLIENT = "1";
	public static final String ANSWER_TOTAL_TAX_ITC_MASTER = "2";	

	public static final String QUESTION_TOTAL_TAX_PERCENT_ITC = "32B";
	
	//------------ CLIENT ON BOARDING DETAILS ENDS -----------------------------------

	public static final String ENTITY_HIERARCHY_DETAILS = "ENTITY_HIERARCHY_DETAILS";

	public static final String ENTITY_HIERARCHY_REST = "asp-restapi.loadEntityHierarchy";

	public static final String DIVISION = "Division";

	public static final String SUB_DIVISION = "SubDivision";

	public static final String PROFIT_CENTER_1 = "ProfitCentre1";

	public static final String PROFIT_CENTER_2 = "ProfitCentre2";

	public static final String PLANT_CODE = "PlantCode";
	
	public static final String BILL_OF_ENTRY = "BillOfEntry";
	
	public static final String BILL_OF_ENTRY_DATE = "BillOfEntryDate";
	
	public static final String GSTR2_ORG_DOC_DATE = "OriginalDocumentDate";
	
	public static final String GSTR1_ORG_DOC_DATE = "OriginalDocumentDate";
	
	public static final String CR_DR_PRE_GST_FLAG = "CRDRPreGST";
	
	public static final String CUSTOMER_GSTIN = "CustomerGSTIN";
	
	public static final String ORIGINAL_CGSTIN = "OriginalCustomerGSTIN";
	
	public static final String ORIGINAL_DOC_NUM = "OriginalDocumentNumber";
	
	public static final String DOCUMENT_DATE = "DocumentDate";
	
}	