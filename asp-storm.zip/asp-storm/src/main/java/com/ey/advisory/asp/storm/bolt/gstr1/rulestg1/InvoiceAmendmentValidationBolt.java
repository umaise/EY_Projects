package com.ey.advisory.asp.storm.bolt.gstr1.rulestg1;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.storm.bolt.common.BoltBuilder;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

public class InvoiceAmendmentValidationBolt extends BoltBuilder {


	private CustomOutputCollector collector;
	RestClientUtility restClientUtil = null;

	//private Properties restProps;

	private final Logger log = LoggerFactory.getLogger(getClass());
	/*public InvoiceAmendmentValidationBolt(Properties configs) {
		super(configs);
	}*/

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		restClientUtil = new RestClientUtility();
		if(log.isInfoEnabled())
			log.info("In InvoiceAmendmentValidationBolt.prepare() start");
		//restProps = new Properties();
		this.collector = collector;
		/*try {
			restProps.load(InvoiceAmendmentValidationBolt.class.getResourceAsStream("/rest-config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		if(log.isInfoEnabled())
			log.info("In InvoiceAmendmentValidationBolt.prepare() ends");
	}

	@Override
	public void execute(Tuple input) {
		OutwardInvoiceDTO outwardInvoiceDTO = null;
		LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();
		long startTime=System.currentTimeMillis();
		int invOrder=0;
		try{
			if(log.isInfoEnabled())
				log.info("In InvoiceAmendmentValidationBolt.execute() start");
			Gson gson = new Gson();
			outwardInvoiceDTO = (OutwardInvoiceDTO) input.getValue(0);
			
			log.info("rediskey : "+ outwardInvoiceDTO.getRedisKey() +" InvOrder : "+ outwardInvoiceDTO.getLineItemList().get(0).getInvOrder());
			
			if(outwardInvoiceDTO.getLineItemList() !=null) {
				OutwardInvoiceModel lineItem = outwardInvoiceDTO.getLineItemList().get(0);
				invOrder=lineItem.getInvOrder();
				log.info("In InvoiceAmendmentValidationBolt  redis key : "+outwardInvoiceDTO.getRedisKey() + " Invoice order : "+lineItem.getInvOrder());
				String taxPeriod = lineItem.getTaxperiod();
				Object documentDate = lineItem.getDocumentDate();
				if(lineItem.getDocumentType().equals(Constant.INV))
					outwardInvoiceDTO.setSkipAmendmentCheck(Utility.isPreviousTaxPeriod(documentDate, taxPeriod));
			}

			String jsonString = gson.toJson(outwardInvoiceDTO);
			if(StringUtils.isNotEmpty(outwardInvoiceDTO.getTableType())){
				ClientResponse response = restClientUtil.getRestServiceResponse(Constant.ASP_REST_HOSTNAME, "GSTR1_"+outwardInvoiceDTO.getTableType(), outwardInvoiceDTO.getGroupCode(), jsonString, Constant.VERB_TYPE_POST);
				
				if(response != null && response.getStatusInfo().getStatusCode() == 200){
					String json = response.getEntity(String.class);
					outwardInvoiceDTO = gson.fromJson(json, OutwardInvoiceDTO.class);
					log.info("RESPONSE : "+json);
				}else{
					log.error("Error RESPONSE : "+response + " TableType : " + outwardInvoiceDTO.getTableType());
				}

			}
			if(log.isInfoEnabled())
				log.info("Amendment Check Complete:");
			collector.emit(input,new Values(outwardInvoiceDTO));

		}catch(Exception e){
			log.error("Error Validation Invoice Amendment", e);
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
			//collector.customReportError(input, e, "Exception in Bolt InvoiceAmendmentValidationBolt");
		}finally {
			collector.ack(input);
			String redisKey=outwardInvoiceDTO.getRedisKey();
			if(log.isInfoEnabled())
				log.info("In InvoiceAmendmentValidationBolt Time taken for file : "+redisKey+" Inv Order : "+ invOrder+" is "+(System.currentTimeMillis()-startTime));
		}

	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR1_Stream1, new Fields("inv"));


	}

}
