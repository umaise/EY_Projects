package com.ey.advisory.asp.storm.bolt.common;

import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.exceptions.RESTCallFailureException;

public class GSTR2RestCallBolt extends BoltBuilder{
	
	private CustomOutputCollector collector;
    RestClientUtility restClientUtil = null;

    private final Logger log = LoggerFactory.getLogger(getClass());
    @Override
    public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
        this.collector = collector;
        restClientUtil = new RestClientUtility();
    }
    

    @Override
    public void execute(Tuple input) {
        InwardInvoiceDTO inwardInvoiceDTO = null;
        
        try{
            log.info("In GSTR2RestCallBolt.execute() start");
            inwardInvoiceDTO = (InwardInvoiceDTO) input.getValueByField("inv");
        	
        	Integer incInvCnt=(Integer) input.getValueByField("invCount");
        	
        	Integer incPsdCnt=(Integer) input.getValueByField("invPsdCnt");
        	
            
            if(incPsdCnt!=null && incInvCnt.equals(incPsdCnt)){
                log.info("Going to call GSTR2 save rest call for "+inwardInvoiceDTO.getRedisKey());
              
                try{
                    restClientUtil.callRestServiceJersey(inwardInvoiceDTO.getRedisKey(), inwardInvoiceDTO.getGroupCode(),Constant.REST_HOST_GSTR2);
                }catch(RESTCallFailureException e){
                    log.error("Exception in Bolt GSTR2RestCallBolt due to REST call failure : ", e);
                    //collector.customReportError(input, e, "Exception in Bolt GSTR2RestCallBolt due to REST call failure");
                }	
            }

        }
        catch(Exception ex){			
            log.error("Error in bolt GSTR2RestCallBolt : ", ex);
            //logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
        }
        finally {
            collector.ack(input);
            if(log.isInfoEnabled())
                log.info("In GSTR2RestCallBolt.execute() end");
        }
        
       
    }

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		//declarer.declare(new Fields("inv","invCount","invPsdCnt"));
		
	}

}
