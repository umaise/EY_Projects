package com.ey.advisory.asp.storm.bolt.gstr1.rulestg1;

import java.lang.reflect.Type;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.error.LogGSTR1RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.service.ValidationRuleService;
import com.ey.advisory.asp.service.ValidationRuleServiceImpl;
import com.ey.advisory.asp.storm.bolt.common.CustomBaseRichBolt;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

public class SaleRegValidationBolt extends CustomBaseRichBolt {
	
	private CustomOutputCollector collector;	
	private ValidationRuleService validationRuleService;
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		validationRuleService=new ValidationRuleServiceImpl();
	}

	@Override
	public void execute(Tuple input) {
		LogRunTimeErros logRunTimeErros=new LogGSTR1RunTimeErros();		
		OutwardInvoiceDTO outwardInvoiceDTO = null;
		long startTime=System.currentTimeMillis();
		int invOrder=0;
		try{
			outwardInvoiceDTO = (OutwardInvoiceDTO) input.getValue(0);
			if(log.isInfoEnabled())	
		    log.info("SaleRegValidationBolt Starts");
		    //OutwardInvoiceDTO outwardInvoiceDTO = new OutwardInvoiceDTO();
		    //outwardInvoiceDTO.setLineItemList(salStgList);
			
			if(outwardInvoiceDTO.getLineItemList() !=null) {
				OutwardInvoiceModel lineItem = outwardInvoiceDTO.getLineItemList().get(0);
				invOrder=lineItem.getInvOrder();
				log.info("In SaleRegValidationBolt  redis key : "+outwardInvoiceDTO.getRedisKey() + " Invoice order : "+lineItem.getInvOrder());
			}
				
		
		    outwardInvoiceDTO=validationRuleService.executeGSTR1ValidationRules(outwardInvoiceDTO);
		    
		    if(outwardInvoiceDTO!=null){
				collector.emit(input,new Values(outwardInvoiceDTO));
		    }else{
		    	logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		    }
		    
		}
		catch(Exception e){
			logRunTimeErros.logErrorsInredis(input, Constant.TECH_ERROR);
		}
		
		finally {
			collector.ack(input);
			if(log.isInfoEnabled()){
				String redisKey=outwardInvoiceDTO.getRedisKey();
				log.info("In SaleRegValidationBolt Time taken for file : "+redisKey+" Inv Order : "+ invOrder+" is "+(System.currentTimeMillis()-startTime));
			}
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR1_Stream1, new Fields("inv"));

	}
//rule 1 bolt
	
}
