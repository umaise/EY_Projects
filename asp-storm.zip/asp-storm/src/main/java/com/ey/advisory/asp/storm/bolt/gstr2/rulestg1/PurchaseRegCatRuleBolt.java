package com.ey.advisory.asp.storm.bolt.gstr2.rulestg1;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.kie.api.KieBaseConfiguration;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.KnowledgeBaseFactory;
import org.kie.internal.definition.KnowledgePackage;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.ErrorActionUtility;
import com.ey.advisory.asp.common.JedisConnectionUtil;
import com.ey.advisory.asp.common.RestClientUtility;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.common.error.LogGSTR2RunTimeErros;
import com.ey.advisory.asp.common.error.LogRunTimeErros;
import com.ey.advisory.asp.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.master.domain.TblBifurcationCodes;
import com.ey.advisory.asp.storm.bolt.common.BoltBuilder;
import com.ey.advisory.asp.storm.bolt.common.CustomOutputCollector;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.ClientResponse;

/**

 * @author  Nisha Kumari
 * @version 1.0
 * @since   17-03-2017
 */


public class PurchaseRegCatRuleBolt extends BoltBuilder {


	private static final long serialVersionUID = 1L;

	private CustomOutputCollector collector;
	private RedisTemplate<String, Object> redisTemplate;	
	private final Logger log = LoggerFactory.getLogger(getClass());
	private Map<String, TblBifurcationCodes> tableTypeMap = new HashMap<String, TblBifurcationCodes>();
	private Map<String, TblBifurcationCodes> subCategoryTypeMap = new HashMap<String, TblBifurcationCodes>();
	boolean firstLineItemChanged = false;
	
	/*public PurchaseRegCatRuleBolt(Properties configs) {
		super(configs);
	}*/

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("inv"));
		//declarer.declareStream(Constant.GSTR2_Stream1,new Fields("inv"));

	}

	@Override
	public void prepare(Map stormConf, TopologyContext context, CustomOutputCollector collector) {
		this.collector = collector;
		try {
			log.info("In PurchaseRegCatRuleBolt.prepare() start");
			redisTemplate = JedisConnectionUtil.getRedisTemplateKVStringObject();
			log.info("In PurchaseRegCatRuleBolt.prepare() ends");

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}


	}

	@Override
	public void execute(Tuple input) {
		
		firstLineItemChanged = false;
		Set<TblPurchaseErrorInfo> errorList = new HashSet<TblPurchaseErrorInfo>();
		InwardInvoiceDTO inwardInvoiceDTO=null;
		LogRunTimeErros logRunTimeErros=new LogGSTR2RunTimeErros();
		try{
			log.info("In PurchaseRegCatRuleBolt.execute() start");

			Gson gson = new Gson();

			String invString=input.getString(0);
			Type listType = new TypeToken<InwardInvoiceDTO>(){}.getType();
			inwardInvoiceDTO=gson.fromJson(invString, listType);
			String groupCode = Utility.getGroupCode(inwardInvoiceDTO.getRedisKey());
			if(groupCode!=null && !groupCode.isEmpty()){
				log.info("In PurchaseRegCatRuleBolt.execute() : Group code is : "+groupCode);
				inwardInvoiceDTO.setGroupCode(groupCode);
			}else{
				log.info("In PurchaseRegCatRuleBolt.execute() : Group code not found in REDIS");
			}
			if(inwardInvoiceDTO.getErrorList()!=null){
				errorList =inwardInvoiceDTO.getErrorList();
			}

			InwardInvoiceModel stgTable = inwardInvoiceDTO.getLineItemList().get(0);
			String orgSupplyType = stgTable.getSupplyType();
			
			stgTable = validateForTAXorNIL(inwardInvoiceDTO, stgTable);
            
			if(stgTable.getCGSTIN()!=null)
				stgTable.setCGSTIN(stgTable.getCGSTIN().trim().isEmpty() ? null: stgTable.getCGSTIN());
			if(stgTable.getSGSTIN()!=null)
				stgTable.setSGSTIN(stgTable.getSGSTIN().trim().isEmpty() ? null: stgTable.getSGSTIN());
			if(stgTable.getPos()!=null)
				stgTable.setPos(stgTable.getPos().trim().isEmpty() ? null: stgTable.getPos());
			if(stgTable.getReverseCharge()!=null)
				stgTable.setReverseCharge(stgTable.getReverseCharge().trim().isEmpty() ? null: stgTable.getReverseCharge());
			if(stgTable.getBillOfEntry()!=null)
				stgTable.setBillOfEntry(stgTable.getBillOfEntry().trim().isEmpty() ? null: stgTable.getBillOfEntry());
			if(stgTable.getHSNorSAC()!=null)
				stgTable.setHSNorSAC(stgTable.getHSNorSAC().trim().isEmpty() ? null: stgTable.getHSNorSAC());
			
			log.info("rediskey : " + inwardInvoiceDTO.getRedisKey() + " InvOrder : "+ stgTable.getInvOrder());

			InputStream fout = PurchaseRegCatRuleBolt.class.getResourceAsStream("/GSTR2_Classification.ser");
			ObjectInputStream oos = new ObjectInputStream(fout);

			Collection<KnowledgePackage> knowledgePackages = (Collection<KnowledgePackage>) oos.readObject();
			KieBaseConfiguration kBaseConfig = KnowledgeBaseFactory.newKnowledgeBaseConfiguration();
			KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase(kBaseConfig);
			kbase.addKnowledgePackages(knowledgePackages);
			StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();

			ksession.insert(stgTable);
			ksession.setGlobal("errorList", errorList);
			ksession.fireAllRules();
			ksession.destroy();

			//KieSession kSession = KSessionUtility.getKSession("rules/GSTR2/GSTR2_Classification.drl");
			//kSession.setGlobal("errorList", errorList);

			getBifurcationMetadatafromRedis(redisTemplate, inwardInvoiceDTO.getGroupCode());

//			 if (tableTypeMap == null || subCategoryTypeMap==null) {
//            if(loadBifurcationDataInRedis(inwardInvoiceDTO.getGroupCode()).equalsIgnoreCase(Constant.SUCCESS)){
//                getBifurcationMetadatafromRedis(redisTemplate, inwardInvoiceDTO.getGroupCode());
//            }
//        }

			if (tableTypeMap == null){

				tableTypeMap = new HashMap<String, TblBifurcationCodes>();
				log.info("tableTypeMap is empty from redis");
			}

			if (subCategoryTypeMap==null){

				subCategoryTypeMap = new HashMap<String, TblBifurcationCodes>();

				log.info("subCategoryTypeMap is empty from redis");
			}

			if(stgTable.getTableType() != null && stgTable.getSubCategory()!=null) {

				if(tableTypeMap.get(stgTable.getTableType())!=null){
					stgTable.setTableType(tableTypeMap.get(stgTable.getTableType()).getValue());
				}
				else{
					stgTable.setTableType("");

				}

				if(subCategoryTypeMap.get(stgTable.getSubCategory())!=null){
					stgTable.setSubCategory(subCategoryTypeMap.get(stgTable.getSubCategory()).getValue());
				}

				else{
					stgTable.setSubCategory("");

				}
			}else {
				stgTable.setItemStatus(Constant.BUS_RULE_ERROR);
				errorList.add(ErrorActionUtility.getPurchaseTblErrorInfo(stgTable,"ER407", Constant.GSTR2_DOC_TYPE,"GSTR2 Bifurcation", false,Constant.INVOICE));
			}

			if (inwardInvoiceDTO.getInvStatus() == null || inwardInvoiceDTO.getInvStatus().isEmpty()
					|| inwardInvoiceDTO.getInvStatus().equals(
							Constant.GSTR2_BR_STG1)) {
				inwardInvoiceDTO.setInvStatus(stgTable.getItemStatus());
			}

			inwardInvoiceDTO.setErrorList(errorList);
			inwardInvoiceDTO.setTableType(stgTable.getTableType());
			
			if(!firstLineItemChanged)
				stgTable.setSupplyType(orgSupplyType);
			else {
				InwardInvoiceModel frstObject = inwardInvoiceDTO.getLineItemList().get(0);
				frstObject.setTableType(stgTable.getTableType());
				frstObject.setSubCategory(stgTable.getSubCategory());
			}
			
			log.info("Table Type identification complete:"+ stgTable.getTableType() +"--"+ stgTable.getSubCategory());

			log.info("Item Status:"+ stgTable.getItemStatus());
			collector.emit(input,new Values(inwardInvoiceDTO));

		}catch(JsonSyntaxException ex){
			log.error(ex.getMessage());
			//collector.customReportError(inwardInvoiceDTO, ex, "Exception in PurchaseRegCatRuleBolt");
			logRunTimeErros.logErrorsInredis(input.getString(0), Constant.DATA_ERROR);
		}catch(Exception ex1){
			log.error(ex1.getMessage());
			//collector.customReportError(inwardInvoiceDTO, ex1, "Exception in PurchaseRegCatRuleBolt");
			logRunTimeErros.logErrorsInredis(input.getString(0), Constant.DATA_ERROR);
		}


		finally {
			collector.ack(input);
			log.info("InPurchaseRegCatRuleBolt.execute() end");
		}

	}

    private InwardInvoiceModel validateForTAXorNIL(final InwardInvoiceDTO inwardInvoiceDTO, InwardInvoiceModel firstLineItem) {

        int nilCount=0;
        int extCount=0;
        int taxCount=0;
        boolean nilFoundAtFirst = false;
        
        if(Constant.NIL.equalsIgnoreCase(firstLineItem.getSupplyType()) || Constant.EXT.equalsIgnoreCase(firstLineItem.getSupplyType())) {
        	nilFoundAtFirst = true;
        }
        
        for (InwardInvoiceModel lineItem : inwardInvoiceDTO.getLineItemList()) {
        	if(Constant.NIL.equalsIgnoreCase(lineItem.getSupplyType())) {
                nilCount++;
            } else if (Constant.EXT.equalsIgnoreCase(lineItem.getSupplyType())){
                extCount++;
            } else if (Constant.TAX.equalsIgnoreCase(lineItem.getSupplyType())) {
            	if(nilFoundAtFirst && !firstLineItemChanged) {
            		firstLineItem = lineItem;
            		firstLineItemChanged = true;
            	}
                taxCount++;
            }  
            
            if(nilCount>0 && extCount>0 && taxCount>0) {
            	break;
            }
        }

        if((extCount > 0 && taxCount > 0) || (nilCount > 0 && taxCount > 0)) {
            firstLineItem.setSupplyType(Constant.TAX);
            inwardInvoiceDTO.setMultipleSupplyType(true);
        } else if(nilCount > 0 && extCount > 0) {
            firstLineItem.setSupplyType(Constant.EXT);
            inwardInvoiceDTO.setMultipleSupplyType(true);
        }

        return firstLineItem;
    }
    
	@SuppressWarnings("unchecked")
	private void getBifurcationMetadatafromRedis(RedisTemplate<String, Object> redisTemplate, String groupCode) {
		tableTypeMap = (Map<String, TblBifurcationCodes>) redisTemplate.opsForHash()
				.get(Constant.REDIS_CACHE, Constant.CATEGORY);

		subCategoryTypeMap = (Map<String, TblBifurcationCodes>)redisTemplate.opsForHash().get(Constant.REDIS_CACHE, Constant.SUB_CATEGORY);
	}

	private String loadBifurcationDataInRedis(String groupCode) {
		String status = null;

		ClientResponse response = new RestClientUtility()
				.getRestServiceResponse(Constant.ASP_REST_HOSTNAME,
						Constant.BIFURCATION_DETAILS, groupCode, null,
						Constant.VERB_TYPE_POST);

		if(response.getStatusInfo().getStatusCode() == Constant.STATUS_OK){
			Gson gson = new Gson();
			status = gson.fromJson(response.getEntity(String.class), String.class);
		}
		return status;
	}
}
