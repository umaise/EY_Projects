package com.ey.advisory.asp.master.service;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;

import com.ey.advisory.asp.master.domain.AppRoleFunction;
import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.repository.AppRoleFunctionRepository;


public class AppRoleFunctionServiceImplTest {
	
	@Mock
	private AppRoleFunctionRepository appRoleFunctionRepository;
	private static Role mockedRole;
	private static AppRoleFunction appRoleFunction1;
	private static AppRoleFunction appRoleFunction2;
	
	
	@InjectMocks
	private final AppRoleFunctionService appRoleFunctionService = new AppRoleFunctionServiceImpl();
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Ignore
	public void testGetEntityManager() {
		fail("Not yet implemented");
	}

	@Ignore
	public void testSetEntityManager() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindByRoleId() {
	
		when(appRoleFunctionRepository.findByRole(mockedRole)).thenReturn(Arrays.asList(appRoleFunction1, appRoleFunction2));
		when(appRoleFunctionService.findByRoleId(mockedRole)).thenReturn(Arrays.asList(appRoleFunction1, appRoleFunction2));
		assertNotNull("Error fetching App role function by Role ID", appRoleFunctionService.findByRoleId(mockedRole));
		assertEquals(appRoleFunctionService.findByRoleId(mockedRole).size(), 2);
	}

}
