package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.Role;

@Transactional
public interface RoleRepository extends JpaRepository<Role, Long> {
	
	@Query("SELECT role.roleId,role.rolename,role.roleDescription,role.createdBy,role.createdDate,role.defaultRole,role.roleType,role.parentId,role.category from Role role order by role.rolename asc")
	public List<Role> getRoles();
	
	/*@Query("select role.roleId,role.rolename from Role role inner join UserGSTNRoleMaping rmap on rmap.roleId.roleId=role.roleId where rmap.userId.userId= :userID")
	public List<Role> getUserRoles(@Param("userID") Long userId);
*/
	
	@Query("select role from Role role where role.parentId= :parentId")
	public List<Role> getRoleById(@Param("parentId") Long parentId);
	
	public List<Role> getRolesByCategory(String category);
	
}
