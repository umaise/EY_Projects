package com.ey.advisory.asp.master.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.RoleAccessHierarchyMap;
import com.ey.advisory.asp.master.repository.RoleAccessHierarchyMapRepository;

@Service
public class RoleAccessHierarchyMapServiceImpl implements RoleAccessHierarchyMapService {
	
	
	private static final Logger LOGGER = Logger.getLogger(RoleAccessHierarchyMapServiceImpl.class);
			
	protected EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	@PersistenceContext(unitName = "masterDataUnit")
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Autowired
	private RoleAccessHierarchyMapRepository roleAccessHierarchyMapRepository;
	
	
	@Override
	public List<RoleAccessHierarchyMap> findAll() {
		LOGGER.info("com.ey.advisory.asp.master.service.RoleAccessHierarchyMapServiceImpl.findAll()");
		List<RoleAccessHierarchyMap> roleAccessHierarchyMapList=  roleAccessHierarchyMapRepository.findAll();
		return 	roleAccessHierarchyMapList;
	}

}
