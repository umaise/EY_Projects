package com.ey.advisory.asp.master.service;

import com.ey.advisory.asp.master.domain.GstinSubmitDateMaster;


public interface GstinSubmitDateMasterService {
	
	public GstinSubmitDateMaster fetchGstinSubmitDates(String returnType);

}
