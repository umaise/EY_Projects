package com.ey.advisory.asp.master.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.exception.AzureStoreDetailsNotFoundException;
import com.ey.advisory.asp.master.domain.GroupConfig;
import com.ey.advisory.asp.master.repository.GroupConfigRepository;

@Service
public class GroupConfigServiceImpl implements GroupConfigService {

	private static final Logger LOGGER = Logger.getLogger(GroupConfigServiceImpl.class);
	
    protected EntityManager entityManager;

    public EntityManager getEntityManager() {
        return entityManager;
    }

    @PersistenceContext(unitName = "masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Autowired
    GroupConfigRepository groupConfigRepository;

	@Override
	public Map<String, Map<String, String>> getAzureStorageDetailsForGroup(String groupCode) {
		Map<String, Map<String, String>> azureDetailsForGroupMap= null;
		try{
		Map<String, String> azureDetailsMap=getAzureGroupConfigDetails(groupCode);
			if(azureDetailsMap!=null && azureDetailsMap.size()>0){
				azureDetailsForGroupMap=new HashMap<String, Map<String,String>>();
				azureDetailsForGroupMap.put(groupCode, azureDetailsMap);
		}
			}catch(Exception e){
				LOGGER.error("Exception in getAzureStorageDetailsForGroup"+e);
			}
		return azureDetailsForGroupMap;
	}

	@Override
	public Map<String, Map<String, String>> getAzureStorageDetails() {
		Map<String, Map<String, String>> azureDetailsForGroupMap= null;
		List<String> activeGroups=groupConfigRepository.findDistinctGroupCode();
		if(activeGroups!=null && activeGroups.size()>0){
			azureDetailsForGroupMap=new HashMap<String, Map<String,String>>();
			for(String groupCode:activeGroups){
				try{
				Map<String, String> azureDetailsMap=getAzureGroupConfigDetails(groupCode);
				if(azureDetailsMap!=null && azureDetailsMap.size()>0){
					azureDetailsForGroupMap.put(groupCode, azureDetailsMap);
				}
				}catch(Exception e){
					LOGGER.error("Exception in getAzureStorageDetailsForGroup for group "+e);
				}
				
			}
		}
		return azureDetailsForGroupMap;
	}

    private Map<String, String> getAzureGroupConfigDetails(String groupCode) throws Exception{
    	List<GroupConfig> groupConfigList = groupConfigRepository.getGroupConfigvalues(groupCode);
		Map<String, String> azureDetailsMap=null;
		if (groupConfigList != null && groupConfigList.size() > 0) {
			azureDetailsMap=new HashMap<String, String>();
			for (GroupConfig groupConfig : groupConfigList) {
				if (groupConfig.getConfigCode().equalsIgnoreCase(Constant.STORE_ACC_NAME)) {
					azureDetailsMap.put(Constant.STORE_ACC_NAME, groupConfig.getConfigValue());
				} else if (groupConfig.getConfigCode().equalsIgnoreCase(Constant.STORE_ACC_KEY)) {
					azureDetailsMap.put(Constant.STORE_ACC_KEY, groupConfig.getConfigValue());
				} 
				}
		}
		if(!azureDetailsMap.containsKey(Constant.STORE_ACC_NAME) || !azureDetailsMap.containsKey(Constant.STORE_ACC_KEY)){
			LOGGER.info("Either STORE_ACC_NAME or STORE_ACC_KEY is missing");
			throw new AzureStoreDetailsNotFoundException("Either STORE_ACC_NAME or STORE_ACC_KEY is Missing");
		}
		return azureDetailsMap;
    	
    }


}
