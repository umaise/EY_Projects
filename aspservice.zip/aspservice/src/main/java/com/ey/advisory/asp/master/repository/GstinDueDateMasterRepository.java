package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.DueDateMaster;
import com.ey.advisory.asp.master.domain.GstinDueDateMaster;
@Repository
public interface GstinDueDateMasterRepository extends JpaRepository<GstinDueDateMaster, Long> {

	/*@Override
	public List<GstinDueDateMaster> findAll();*/
	//@Query("select DISTINCT(groupCode) from FileUploadMaster file where file.fileId IN (:fileIds)")
	@Query("select d from GstinDueDateMaster d WHERE d.contentType IN (:contentType)")
	public List<GstinDueDateMaster> findGstnDueDate(@Param("contentType") List<String> contentType);
	

}
