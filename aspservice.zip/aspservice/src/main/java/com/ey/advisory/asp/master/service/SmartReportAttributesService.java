package com.ey.advisory.asp.master.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.ey.advisory.asp.master.domain.SmartReportAttributes;

public interface SmartReportAttributesService {
	public List<SmartReportAttributes> findAttributesByFileCategory(@Param("fileCategory") String fileCategory);

}
