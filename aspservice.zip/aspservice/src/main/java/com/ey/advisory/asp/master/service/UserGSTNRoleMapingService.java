package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.domain.User;
import com.ey.advisory.asp.master.domain.UserGSTNRoleMaping;

public interface UserGSTNRoleMapingService{
	
	
	public List<UserGSTNRoleMaping> findByUserId(User userId);
	
	public List<UserGSTNRoleMaping> findByRoleId(Role role);
	
	public List<UserGSTNRoleMaping> findByUserId(long userId);
	
	public  String deleteByUserIdAndGroupId(Long userId,Long groupId);

}
