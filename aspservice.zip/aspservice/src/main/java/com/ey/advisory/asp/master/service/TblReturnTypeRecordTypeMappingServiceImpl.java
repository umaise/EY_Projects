package com.ey.advisory.asp.master.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.TblReturnTypeRecordTypeMapping;
import com.ey.advisory.asp.master.repository.TblReturnTypeRecordTypeMappingRepository;

@Service("tblReturnTypeRecordTypeMappingService")
public class TblReturnTypeRecordTypeMappingServiceImpl implements TblReturnTypeRecordTypeMappingService{

	protected EntityManager entityManager;
    public EntityManager getEntityManager() {
        return entityManager;
    }
    
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
   
    @Autowired
    private TblReturnTypeRecordTypeMappingRepository tblReturnTypeRecordTypeMappingRepository;
	@Override
	public List<TblReturnTypeRecordTypeMapping> findAll() {
		// TODO Auto-generated method stub
		return tblReturnTypeRecordTypeMappingRepository.findAll();
	}
    
}
