package com.ey.advisory.asp.master.service;

import java.util.Calendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.asp.master.repository.IReturnPeriodRepository;

@Service
public class Gstr1ServiceMasterImpl implements Gstr1ServiceMaster {
	
	protected static final Logger LOGGER = Logger.getLogger(Gstr1ServiceMasterImpl.class);
	
	@Autowired
	private IReturnPeriodRepository iReturnPeriodRepository;
	
	String taxPeriod;
	@Override
	public String getReturnPeriod(){
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Inside getReturnPeriod");
		}
		ReturnPeriod returnPeriod= iReturnPeriodRepository.findByIsCurrentPeriod(true);
		Calendar cal = Calendar.getInstance();
		cal.setTime(returnPeriod.getStartDt());
		int month = cal.get(Calendar.MONTH)+1;
		int year = cal.get(Calendar.YEAR);
		String monthTwoDigits=(month)<10 ? "0"+String.valueOf(month): String.valueOf(month);
		taxPeriod= monthTwoDigits + String.valueOf(year);
		return taxPeriod;
	}
}
