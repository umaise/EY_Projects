package com.ey.advisory.asp.master.domain;

import java.io.Serializable;
import javax.persistence.*;

import com.ey.advisory.asp.common.Constant;

import java.math.BigDecimal;


/**
 * The persistent class for the tblGlobalGSTRatesMasterI database table.
 * 
 */
@Entity
@Table(name="tblGlobalGSTRatesMasterI", schema=Constant.MASTER_SCHEMA)
public class GlobalGSTRatesMasterI implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MasterId")
	private Long masterId;

	@Column(name="Description")
	private String description;
	
	@Column(name="GstCessRt")
	private BigDecimal gstCessRt;

	@Column(name="GstCGSTRt")
	private BigDecimal gstCGSTRt;

	@Column(name="GstIGSTRt")
	private BigDecimal gstIGSTRt;

	@Column(name="GstSGSTRt")
	private BigDecimal gstSGSTRt;

	@Column(name="GstUTGSTRt")
	private BigDecimal gstUTGSTRt;

	@Column(name="HSNorSAC")
	private String HSNorSAC;

	@Column(name="HSNSAC")
	private String hsnsac;

	public Long getMasterId() {
		return masterId;
	}

	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getGstCessRt() {
		return gstCessRt;
	}

	public void setGstCessRt(BigDecimal gstCessRt) {
		this.gstCessRt = gstCessRt;
	}

	public BigDecimal getGstCGSTRt() {
		return gstCGSTRt;
	}

	public void setGstCGSTRt(BigDecimal gstCGSTRt) {
		this.gstCGSTRt = gstCGSTRt;
	}

	public BigDecimal getGstIGSTRt() {
		return gstIGSTRt;
	}

	public void setGstIGSTRt(BigDecimal gstIGSTRt) {
		this.gstIGSTRt = gstIGSTRt;
	}

	public BigDecimal getGstSGSTRt() {
		return gstSGSTRt;
	}

	public void setGstSGSTRt(BigDecimal gstSGSTRt) {
		this.gstSGSTRt = gstSGSTRt;
	}

	public BigDecimal getGstUTGSTRt() {
		return gstUTGSTRt;
	}

	public void setGstUTGSTRt(BigDecimal gstUTGSTRt) {
		this.gstUTGSTRt = gstUTGSTRt;
	}

	public String getHSNorSAC() {
		return HSNorSAC;
	}

	public void setHSNorSAC(String hSNorSAC) {
		HSNorSAC = hSNorSAC;
	}

	public String getHsnsac() {
		return hsnsac;
	}

	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}

}