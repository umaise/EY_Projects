package com.ey.advisory.returnfiling.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;
import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.asp.master.repository.FileUploadStatusRepository;
import com.ey.advisory.asp.master.repository.IReturnPeriodRepository;

@Service
public class ReturnFilingServiceImpl implements ReturnFilingService {
	
	
	@Autowired
	private FileUploadStatusRepository tblSalesFileStatusRepo;
	
	@Autowired
	private IReturnPeriodRepository iReturnPeriodRepository;


	@Override
	public ReturnPeriod findByIsCurrentPeriod(boolean currentPeriod) {
		return iReturnPeriodRepository.findByIsCurrentPeriod(currentPeriod);
	}

	@Override
	public List<FileUploadStatusMaster> findByIsStageProcessedAndJobStatusAndFileData(String isStageProcessed,
			String jobStatus, String fileData, Pageable topTen) {
		return tblSalesFileStatusRepo.findByIsStageProcessedAndJobStatusAndFileData(isStageProcessed, jobStatus,
				fileData, topTen);
	}}
