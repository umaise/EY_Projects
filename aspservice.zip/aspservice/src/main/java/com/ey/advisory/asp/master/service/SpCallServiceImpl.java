package com.ey.advisory.asp.master.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.master.repository.FileUploadRepository;
import com.ey.advisory.asp.master.repository.FileUploadStatusRepository;
import com.ey.advisory.asp.master.repository.TblPipeLineDtlsRepo;


@Service
public class SpCallServiceImpl implements SpCallService {
	
	@Autowired
	FileUploadStatusRepository tblSalesFileStatusRepo;
	
	@Autowired
	FileUploadRepository tblFileUploadRepo;
	
	@Autowired
	TblPipeLineDtlsRepo tblPipeLineDtlsRepo;

	protected EntityManager entityManager;
	private static final Logger logger = Logger
			.getLogger(SpCallServiceImpl.class);
	private static final String CLASS_NAME = SpCallServiceImpl.class.getName();
	

	public EntityManager getEntityManager() {
		return entityManager;
	}

	@PersistenceContext(unitName="masterDataUnit")
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public String executeStoredProcedure(String storedProcName) {
		String procStatus="";
		StoredProcedureQuery query;
		 try
		    {
			 query = entityManager.createStoredProcedureQuery(storedProcName);
			 procStatus=String.valueOf(query.getSingleResult());
			 
		    }catch(Exception e){
		    	logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : executeStoredProcedure" ,e);
		    }
		return procStatus;
	}
	
	@Override
	public String executeStoredProcedure(String storedProcSchema, String storedProcName, int inputParamsCount, List<String> inputParamsList) {
		String procStatus="";
		StoredProcedureQuery query;
		try{
		 query = entityManager.createStoredProcedureQuery(storedProcName);
		for(int i=0;i<inputParamsCount;i++){
			query.registerStoredProcedureParameter(i, String.class, ParameterMode.IN);
			query.setParameter(i, inputParamsList.get(i));
		}
		  procStatus =String.valueOf(query.getResultList());
		}catch(Exception e)
		{
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : executeStoredProcedure" ,e);
		}
		return procStatus;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Object[]> executeSPReturnList(String storedProcName) {
		List<Object[]> procStatus=null;
		StoredProcedureQuery query;
		try{
		 query = entityManager.createStoredProcedureQuery(storedProcName);
		 procStatus=query.getResultList();
		}catch(Exception e){
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : executeStoredProcedure" ,e);
		}
		return procStatus;
	}

	@Override
	public void updateFileIdDetails(String updateIsProcessedTo,
			String updateJobStatusTo, String isProccessed, String jobStatus,
			String fileData) {
		tblSalesFileStatusRepo.updateFileIdDetails(updateIsProcessedTo, updateJobStatusTo, isProccessed, jobStatus, fileData);
		
	}

	@Override
	public List<String> getFileList(String isProccessed, String jobStatus,
			String fileData,long fileId) {
		return tblSalesFileStatusRepo.fetchDetails(isProccessed, jobStatus, fileData,fileId);
	}

	@Override
	public String getDataLevel(String applicableState, String returnType,
			String recordType) {
		return tblPipeLineDtlsRepo.getDataLevel(applicableState, returnType, recordType);
	}
	
	@Override
	public String getGroupCode(List<String> fileIds) {
		return tblFileUploadRepo.getGroupCode(fileIds);
	}
	@Override
	public List<String> executeStoredProcedureReturnList(
			String storedProcSchema, String storedProcName,
			int inputParamsCount, List<String> inputParamsList)
			 {
		List<String> resultList=null;
		StoredProcedureQuery query;
		try{
		 query = entityManager.createStoredProcedureQuery(storedProcName);
		for(int i=0;i<inputParamsCount;i++){
			query.registerStoredProcedureParameter(i, String.class, ParameterMode.IN);
			query.setParameter(i, inputParamsList.get(i));
		}
		resultList =query.getResultList();
		}catch(Exception e)
		{
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : executeStoredProcedure" ,e);
		}
		return resultList;
	}
	
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.master.service.SpCallService#fetchgroupIdSummaryDetails(java.lang.String)
	 */
	@Override
	public List<String> fetchgroupIdSummaryDetails(String status) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : fetchgroupIdSummaryDetails()");
		}
		List<String> listItem=null;
		String strQuery=null;
	    try {
	    	
	    	
	    	strQuery="select TOP 100 PERCENT  concat('{\"groupId\":',groupId,',\"groupCode\":',groupCode,',\"fileId\":',fileList,'}')  from " 
	    			+"(select TOP 100 PERCENT (select tbl1.SummaryFileID from  "
	    					+"master.tblSummaryFileLoad tbl1 where tbl.EYGrpcode = tbl1.EYGrpcode and "
	    						+"tbl1.Status ='"+status+"'  "
	    						+"FOR JSON AUTO ,INCLUDE_NULL_VALUES) as 'fileList' ,tbl.EYGrpcode as 'groupCode'"
	    						+",(select groupid from master.tblGroup where GroupCode=tbl.EYGrpcode) as 'groupId'"
	    						+"from master.tblSummaryFileLoad tbl  where  tbl.Status='"+status+"'  "
	    						+" order by EYGrpcode asc   ) " 
	    						+"	AS TotalInvList  group by fileList,groupCode,groupId ORDER BY fileList ASC ";
		    	
	     listItem = (List<String>) entityManager.createNativeQuery(strQuery).getResultList();
	
	    } catch (Exception e) {
	    	logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : fetchgroupIdSummaryDetails()",e);
	    }
	    if(logger.isInfoEnabled()){
	    logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : fetchgroupIdSummaryDetails()");
	    }
		return listItem;
	}
}
