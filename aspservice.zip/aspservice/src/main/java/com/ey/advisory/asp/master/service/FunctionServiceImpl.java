package com.ey.advisory.asp.master.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;
import com.ey.advisory.asp.master.domain.Function;

@Service
public class FunctionServiceImpl implements FunctionService{

	protected EntityManager entityManager;
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
	@Override
	public List<Function> getRoleFunctions(Long roleId) {
	
	return null;
		}

}
