package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name = "QuestionModule",schema=Constant.MASTER_SCHEMA)
public class QuestionModule  implements Serializable {
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "QuestionModuleID")
    private long questionModuleID;
   
    @Column(name = "QuestionID")
    private String questionID;
    
    @Column(name = "QuestionValue")
    private String questionValue;
    
    @Column(name = "OrderNo")
    private int orderNo;
    
    @Column(name = "Tooltip")
    private String tooltip;
    
    @Column(name = "IsManadatory")
    private Character isManadatory;

    public Character getIsManadatory() {
        return isManadatory;
    }

    public void setIsManadatory(Character isManadatory) {
        this.isManadatory = isManadatory;
    }

    public long getQuestionModuleID() {
        return questionModuleID;
    }

    public void setQuestionModuleID(long questionModuleID) {
        this.questionModuleID = questionModuleID;
    }

    public String getQuestionID() {
        return questionID;
    }

    public void setQuestionID(String questionID) {
        this.questionID = questionID;
    }

    public String getQuestionValue() {
        return questionValue;
    }

    public void setQuestionValue(String questionValue) {
        this.questionValue = questionValue;
    }

    public int getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(int orderNo) {
        this.orderNo = orderNo;
    }

    public String getTooltip() {
        return tooltip;
    }

    public void setTooltip(String tooltip) {
        this.tooltip = tooltip;
    }

    
    @Override
    public String toString() {
        return "QuestionModule [questionModuleID=" + questionModuleID + ", questionID=" + questionID
            + ", questionValue=" + questionValue + ", orderNo=" + orderNo + ", tooltip=" + tooltip + ", isManadatory="
            + isManadatory + "]";
    }

}
