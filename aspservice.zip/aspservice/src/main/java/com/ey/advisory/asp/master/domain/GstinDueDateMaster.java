package com.ey.advisory.asp.master.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name = "tblDueDateMaster",schema = Constant.MASTER_SCHEMA)
public class GstinDueDateMaster implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DueDateID")
	private Long dueDateID;
	
	@Column(name = "ContentType")
	private String contentType; 

	//@Temporal(TemporalType.DATE)
	@Column(name = "GSTNDueDate")
	private int gstnDueDate;


	public Long getDueDateID() {
		return dueDateID;
	}

	public void setDueDateID(Long dueDateID) {
		this.dueDateID = dueDateID;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public int getGstnDueDate() {
		return gstnDueDate;
	}

	public void setGstnDueDate(int gstnDueDate) {
		this.gstnDueDate = gstnDueDate;
	}

	

}
