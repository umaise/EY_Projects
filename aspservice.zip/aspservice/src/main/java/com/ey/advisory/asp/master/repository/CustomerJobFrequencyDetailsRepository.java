package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.CustomerJobFrequencyDetails;

@Repository
@Transactional(readOnly = true)
public interface CustomerJobFrequencyDetailsRepository extends JpaRepository<CustomerJobFrequencyDetails, String>{
	
	 @Query("select groupCode from CustomerJobFrequencyDetails where frequency = :jobFrequency and flag = 0"
			+ " order by customerPriority")
	 public List<String> getJobPriorityDetails(@Param("jobFrequency") String jobFrequency, Pageable pageable);
	
	
     @Modifying
	 @Query("update CustomerJobFrequencyDetails jobDetails set jobDetails.frequency =:jobFrequency where jobDetails.groupCode = :groupCode")
	 public void updateFrequencyForCustomerGroupCode(@Param("jobFrequency") String jobFrequency,@Param("groupCode") String groupCode);
     
     
     @Modifying
	 @Query("update CustomerJobFrequencyDetails jobDetails set jobDetails.flag =0")
     public void updateScheduledFlagForMaster();
     
     public CustomerJobFrequencyDetails findByGroupCode(String groupCode);
     
     @Modifying
	 @Query("update CustomerJobFrequencyDetails jobDetails set jobDetails.flag =1 where jobDetails.groupCode in :groupCodes")
	 public void updateScheduledFlagForCustomerGroupCode(@Param("groupCodes") List<String> groupCodes);

}
