package com.ey.advisory.asp.master.service;

import java.util.List;

import org.json.simple.JSONObject;

import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.MasterHierarchyConfig;
import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.domain.States;

public interface RedisLoadService {
	
	/**
	 * To fetch HSN Master details from StoredProcedure
	 */
	public void fetchHSNMasterDetails();
	
	
	/**
	 * To fetch Error Master details from Table tblErrorMaster
	 */
	public void fetchErrorMaster();
	/*
	*//**
	 * To fetch Gross TurnOver details from table tblGSTIN
	 *//*
	public void fetchGrossTurnOver();*/
	
	/**
	 * To fetch GSTIN details from table tblGSTIN
	 */
	//public void fetchGstinDetails();
	
	
	public void loadStateCodeMaster();
	public void loadQuestionMaster();
	
	public void loadAnswerMaster();
	public List<States> fetchStateList();
	
	
	public void loadGroupMaster();
	
	public List<Group> fetchGroupList();

	public void loadSupplyMetaData();
	public void loadPurchaseMetaData();
	
	public void loadRoleMaster();
	public List<Role> fetchRoleList();
	
	public void loadMasterHierarchyConfig();
	
	public List<MasterHierarchyConfig> fetchMasterHierarchyConfigList();
	
	public void load();
	public void reLoad();


	public void loadReturnTypeMaster();
	
	public void loadGroupADConfig();
	
	public void saveDataToRedis(JSONObject jsonEncryptResponse,JSONObject UserObj);
	
	public void loadRoleLevelMap();
	
	public void loadGlobalGSTRatesMasterI();
	public String getSpecificGlobalGSTRatesMasterI(String hsnsac);
	
	
	public void loadAzureStoreDetails();


	public void loadGroupConfigDetails();

	
	public void loadReconReportResponseConsolidatedMetadata();
	public void loadReconReportResponseConsolidatedMetadataGstr6();
	

	public void loadSmartReportAttributes();
	
	public void loadTblReturnTypeRecordTypeMapping();

}
