package com.ey.advisory.asp.master.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.ForgotPassword;
@Transactional(readOnly = true)
public interface ForgotPasswordRepository extends JpaRepository<ForgotPassword, Long> {
	
	public ForgotPassword findByUserName(String userName);
	
	@Query("SELECT forgotPassword from ForgotPassword forgotPassword where userName =:userName and createdDate = (SELECT max(createdDate) from ForgotPassword)")
	public ForgotPassword getLatestDetails(@Param("userName") String userName);


}
