package com.ey.advisory.asp.master.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.ReconStatusMaster;
@Repository
@Transactional
public interface ReconStatusMasterRepository extends JpaRepository<ReconStatusMaster, Long> {
	
	@Query("select rm from ReconStatusMaster rm where rm.gstin = :gstin and rm.taxPeriod = :taxPeriod and rm.groupCode = :groupCode and rm.returnType = 'GSTR2' and rm.isActive = 'true'")
	public ReconStatusMaster getReconStatus(@Param("gstin") String gstin,@Param("taxPeriod") String taxPeriod,@Param("groupCode") String groupCodes);
	

}
