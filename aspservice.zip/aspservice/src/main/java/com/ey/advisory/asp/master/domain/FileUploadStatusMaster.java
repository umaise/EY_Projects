package com.ey.advisory.asp.master.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="tblFileUploadStatus", schema="etl")
public class FileUploadStatusMaster implements Serializable{
	
	public FileUploadStatusMaster(){
		super();
	}
	
	public FileUploadStatusMaster(long fileId, String errorDesc,
			String uiDate, String jobstatusDesc,String fileName,String fileData) {
		super();
		this.fileId = fileId;
		this.errorDesc = errorDesc;
		this.uiDate = uiDate;
		this.jobStatusDesc = jobstatusDesc;
		this.fName=fileName;
		this.fileData=fileData;
	}
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="FileId")
	private long fileId;
	
	@Column(name="UserId")
    private long userId;
	
	@Column(name="GroupId")
	private long groupId;
	
	@Column(name="FName")
	private String fName;
	
	@Column(name="FileType")
	private String fileType;
	
	@Column(name="FilePath")
	private String filePath;
		
	@Column(name="FileData")
	private String fileData;
	
	@Column(name="MapId")
	private Integer mapId;
	
	@Column(name="UploadDt")
    private Date uploadDt;
    
	@Column(name="IsStageProcessed")
    private String isStageProcessed;
    
	@Column(name="JobStatus")
    private String jobStatus;
    
	@Column(name="PipeStage")
    private String pipeStage;
	
	@Column(name="GSTIN")
	private String gstin;
    
	@Column(name="Updatedon")
    private Date updateOn;
    
	@Column(name="ErrorCode")
    private String errorCode;
    
	@Column(name="ErrorDesc")
    private String errorDesc;
     
	@Column(name="TotalErrorInvoices")
	private Integer totalErrorInvoices;
	
	@Column(name="TotalInvoices")
	private Integer totalInvoices;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="GroupId", insertable = false, updatable = false)
	private Group group;

	@Transient
	private String uiDate;
	
	@Transient
	private String jobStatusDesc;
	
	@Transient
	private String taxPeriod;
	
	public String getJobStatusDesc() {
		return jobStatusDesc;
	}

	public void setJobStatusDesc(String jobStatusDesc) {
		this.jobStatusDesc = jobStatusDesc;
	}

	public String getUiDate() {
		return uiDate;
	}

	public void setUiDate(String uiDate) {
		this.uiDate = uiDate;
	}

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public String getFileData() {
		return fileData;
	}

	public void setFileData(String fileData) {
		this.fileData = fileData;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getIsStageProcessed() {
		return isStageProcessed;
	}

	public void setIsStageProcessed(String isStageProcessed) {
		this.isStageProcessed = isStageProcessed;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getPipeStage() {
		return pipeStage;
	}

	public void setPipeStage(String pipeStage) {
		this.pipeStage = pipeStage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public Group getGroup() {
		return group;
	}

	public void setGroup(Group group) {
		this.group = group;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public int getMapId() {
		return mapId;
	}

	public void setMapId(int mapId) {
		this.mapId = mapId;
	}

	public Date getUploadDt() {
		return uploadDt;
	}

	public void setUploadDt(Date uploadDt) {
		this.uploadDt = uploadDt;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Date getUpdateOn() {
		return updateOn;
	}

	public void setUpdateOn(Date updateOn) {
		this.updateOn = updateOn;
	}

	public int getTotalErrorInvoices() {
		return totalErrorInvoices;
	}

	public void setTotalErrorInvoices(int totalErrorInvoices) {
		this.totalErrorInvoices = totalErrorInvoices;
	}

	public int getTotalInvoices() {
		return totalInvoices;
	}

	public void setTotalInvoices(int totalInvoices) {
		this.totalInvoices = totalInvoices;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	
	@Override
	public String toString() {
		return "FileUploadStatusMaster [fileId=" + fileId + ", userId=" + userId + ", groupId=" + groupId + ", fName="
				+ fName + ", fileType=" + fileType + ", filePath=" + filePath + ", fileData=" + fileData + ", mapId="
				+ mapId + ", uploadDt=" + uploadDt + ", isStageProcessed=" + isStageProcessed + ", jobStatus="
				+ jobStatus + ", pipeStage=" + pipeStage + ", gstin=" + gstin + ", updateOn=" + updateOn
				+ ", errorCode=" + errorCode + ", errorDesc=" + errorDesc + ", totalErrorInvoices=" + totalErrorInvoices
				+ ", totalInvoices=" + totalInvoices + ", group=" + group + ", uiDate=" + uiDate + ", jobStatusDesc="
				+ jobStatusDesc + ", taxPeriod=" + taxPeriod + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fileData == null) ? 0 : fileData.hashCode());
		result = prime * result + (int) (fileId ^ (fileId >>> 32));
		result = prime * result + (int) (groupId ^ (groupId >>> 32));
		result = prime * result + ((isStageProcessed == null) ? 0 : isStageProcessed.hashCode());
		result = prime * result + ((jobStatus == null) ? 0 : jobStatus.hashCode());
		result = prime * result + ((pipeStage == null) ? 0 : pipeStage.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileUploadStatusMaster other = (FileUploadStatusMaster) obj;
		if (fileData == null) {
			if (other.fileData != null)
				return false;
		} else if (!fileData.equals(other.fileData))
			return false;
		if (fileId != other.fileId)
			return false;
		if (groupId != other.groupId)
			return false;
		if (isStageProcessed == null) {
			if (other.isStageProcessed != null)
				return false;
		} else if (!isStageProcessed.equals(other.isStageProcessed))
			return false;
		if (jobStatus == null) {
			if (other.jobStatus != null)
				return false;
		} else if (!jobStatus.equals(other.jobStatus))
			return false;
		if (pipeStage == null) {
			if (other.pipeStage != null)
				return false;
		} else if (!pipeStage.equals(other.pipeStage))
			return false;
		return true;
	}

	
	
}
