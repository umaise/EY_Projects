/**
 * 
 */
package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.ReturnType;

/**
 * @author Kundan.Kumar
 *
 */

@Repository
@Transactional(readOnly = true)
public interface MasterReturnTypeRepository extends JpaRepository<ReturnType,Long>{
	
	@Override
	public List<ReturnType> findAll();

}
