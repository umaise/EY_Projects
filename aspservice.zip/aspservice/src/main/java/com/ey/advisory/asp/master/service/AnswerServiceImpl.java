package com.ey.advisory.asp.master.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.AnswerModule;
import com.ey.advisory.asp.master.repository.AnswerRepository;

@Service
public class AnswerServiceImpl implements AnswerService{

    
    protected EntityManager entityManager;
    public EntityManager getEntityManager() {
        return entityManager;
    }
    
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Autowired
    private AnswerRepository answerRepository;
    
    @Override
    public List<AnswerModule> findAll() {
       return  answerRepository.findAll();
    }
  

}
