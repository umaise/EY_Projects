package com.ey.advisory.asp.master.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.master.domain.FileUploadMaster;
import com.ey.advisory.asp.master.repository.FileUploadRepository;

@Service
public class FileUploadServiceImpl implements FileUploadService {
	
	private static final Logger LOGGER = Logger.getLogger(FileUploadServiceImpl.class);
	private static final String CLASS_NAME = FileUploadServiceImpl.class.getName();
	
	@Autowired
	private SpCallService spCallService;
	
	@Autowired
	private FileUploadRepository uploadRepository;
	
	protected EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	@PersistenceContext(unitName="masterDataUnit")
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Override
	public String insertFileDetail(FileUploadMaster fileUploadMaster) throws Exception{
		List<String> inputParamsList=new ArrayList<>();
		inputParamsList.add(fileUploadMaster.getGroupCode());
		inputParamsList.add(fileUploadMaster.getContent());
		return spCallService.executeStoredProcedure("dbo", "insertFileDetail", 2, inputParamsList);
	}

	

	@Override
	public void updateUploadStatus(String stageBifurcation, int fileId) {
		
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " Uploading to Master in Service");
		
		uploadRepository.updateUploadStatus(stageBifurcation, fileId);
		
	}

}
