/**
 * 
 */
package com.ey.advisory.asp.dto;

/**
 * @author Nitesh.Tripathi
 *
 */

public class UserAccessMapping_dto {

	/**
	 * 
	 */
	
	private Integer userAccessID;
	
	
    private Integer userID;
	
	
    private String accessLevel;
	
	
    private String accessValue;
    
    private String accessName;
    
	/**
	 * @return the accessName
	 */
	public String getAccessName() {
		return accessName;
	}
	/**
	 * @param accessName the accessName to set
	 */
	public void setAccessName(String accessName) {
		this.accessName = accessName;
	}
	/**
	 * @return the userAccessID
	 */
	public Integer getUserAccessID() {
		return userAccessID;
	}
	/**
	 * @return the userID
	 */
	public Integer getUserID() {
		return userID;
	}
	/**
	 * @return the accessLevel
	 */
	public String getAccessLevel() {
		return accessLevel;
	}
	/**
	 * @return the accessValue
	 */
	public String getAccessValue() {
		return accessValue;
	}
	/**
	 * @param userAccessID the userAccessID to set
	 */
	public void setUserAccessID(Integer userAccessID) {
		this.userAccessID = userAccessID;
	}
	/**
	 * @param userID the userID to set
	 */
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	/**
	 * @param accessLevel the accessLevel to set
	 */
	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}
	/**
	 * @param accessValue the accessValue to set
	 */
	public void setAccessValue(String accessValue) {
		this.accessValue = accessValue;
	}
	
}
