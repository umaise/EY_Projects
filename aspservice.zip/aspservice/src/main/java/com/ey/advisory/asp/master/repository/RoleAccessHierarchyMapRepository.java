/**
 * 
 */
package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.advisory.asp.master.domain.RoleAccessHierarchyMap;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface RoleAccessHierarchyMapRepository extends JpaRepository<RoleAccessHierarchyMap,Long>{
	
	@Override
    public List<RoleAccessHierarchyMap> findAll();

}
