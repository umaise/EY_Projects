package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.FileUploadMaster;

@Repository
@Transactional
public interface FileUploadRepository extends JpaRepository<FileUploadMaster, Long>{
	
	public List<FileUploadMaster> findByStatus(String status, Pageable top);
	
	@Query("select DISTINCT(groupCode) from FileUploadMaster file where file.fileId IN (:fileIds)")
	public String getGroupCode(@Param("fileIds") List<String> fileIds);
	
    public List<FileUploadMaster> findByFileHash(String fileHash);
    
    @Modifying
	@Query("update FileUploadMaster file set file.stage =:stage  where file.fileId =:fileId ")
	void updateUploadStatus(@Param("stage") String stage,@Param("fileId") int fileId);
    
    @Query("select fileId from FileUploadMaster file where file.content='GSTR2IS' and file.status='PSD' and file.stage='BIF' ")
    public List<Integer> getBifurcatedFileIdsForGstr2();
		
}
