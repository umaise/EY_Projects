package com.ey.advisory.asp.master.domain;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;



@Entity
@Table(name="tblReturnMaster",schema=Constant.MASTER_SCHEMA)
public class ReturnMasterDto implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ReturnId")
	private BigInteger returnId;
	@Column(name = "ReturnType")
	private String returnType;
	@Column(name = "Description")
	private String Description;
	@Column(name = "DueDate")
	private int DueDate;
	@Column(name = "LateFeePerDay")
	private Double lateFee;
	@Column(name = "StateCode")
	private String stateCode;
	
	
	public ReturnMasterDto() {
		
	}
	public BigInteger getReturnId() {
		return returnId;
	}
	public void setReturnId(BigInteger returnId) {
		this.returnId = returnId;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public int getDueDate() {
		return DueDate;
	}
	public void setDueDate(int dueDate) {
		DueDate = dueDate;
	}
	
	public Double getLateFee() {
		return lateFee;
	}
	public void setLateFee(Double lateFee) {
		this.lateFee = lateFee;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	
	
}
