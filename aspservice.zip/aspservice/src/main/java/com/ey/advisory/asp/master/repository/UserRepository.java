package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.User;



@Transactional(readOnly = true)
public interface UserRepository extends JpaRepository<User, Long> {
	
	public User findByUserId(Long userId);

	public User findByUserName(String userName);

	public User findByEmailId(String emailId);
	
	@Query("from User where userId IN :userId and emailId is not null and mobileNo is not null")
	public List<User> findByUserIdInAndEmailIdNotNull(@Param("userId") List<Long> userId);
	
	@Query("from User where userId IN :userId and emailId is not null")
	public List<User> findByUserIdInEmailIdNotNull(@Param("userId") List<Long> userId);
	
	@Query("from User where userId IN :userId")
	public List<User> findByUserIdIn(@Param("userId") List<Long> userId);
	
	@Query("select userName,userId from User")
	public List<Object[]> getUsernames();
	
	 @Modifying
	 @Query("UPDATE User usr SET usr.emailId = :emailId, usr.mobileNo = :mobileNo, usr.isActive =:isActive where usr.userId = :userId")
	 int updateUserDetail(@Param("emailId") String emailId, @Param("mobileNo") String mobileNo, @Param("userId") Long userId, @Param("isActive") Boolean isActive);
	 
	//@Query("from User where userName <> :userName and emailId = :emailId ")
	public List<User> findByUserNameNotAndEmailId(String userName,String emailId);
	 
} 

