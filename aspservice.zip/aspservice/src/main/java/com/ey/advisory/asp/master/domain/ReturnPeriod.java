package com.ey.advisory.asp.master.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;


/**
 * The persistent class for the tblReturnPeriod database table.
 * 
 */
@Entity
@Table(name="tblReturnPeriod", schema="master")
public class ReturnPeriod implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="PeriodId")
	private Integer periodId;

	@Temporal(TemporalType.DATE)
	@Column(name="EndDt")
	private Date endDt;

	@Column(name="IsCurrentPeriod")
	private boolean isCurrentPeriod;

	@Temporal(TemporalType.DATE)
	@Column(name="StartDt")
	private Date startDt;
	
	@Column(name="TaxPeriod")
	@Generated(GenerationTime.INSERT)
	private String taxPeriod;
	
	@Column(name="TaxPeriodMMYYYY")
	@Generated(GenerationTime.INSERT)
	private String taxPeriodMMYYYY;

	public ReturnPeriod() {
	}

	public Integer getPeriodId() {
		return this.periodId;
	}

	public void setPeriodId(Integer periodId) {
		this.periodId = periodId;
	}

	public Date getEndDt() {
		return this.endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public boolean getIsCurrentPeriod() {
		return this.isCurrentPeriod;
	}

	public void setIsCurrentPeriod(boolean isCurrentPeriod) {
		this.isCurrentPeriod = isCurrentPeriod;
	}

	public Date getStartDt() {
		return this.startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	/**
	 * @return the taxPeriod
	 */
	public String getTaxPeriod() {
		return taxPeriod;
	}

	/**
	 * @param taxPeriod the taxPeriod to set
	 */
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	/**
	 * @return the taxPeriodMMYYYY
	 */
	public String getTaxPeriodMMYYYY() {
		return taxPeriodMMYYYY;
	}

	/**
	 * @param taxPeriodMMYYYY the taxPeriodMMYYYY to set
	 */
	public void setTaxPeriodMMYYYY(String taxPeriodMMYYYY) {
		this.taxPeriodMMYYYY = taxPeriodMMYYYY;
	}

	/**
	 * @param isCurrentPeriod the isCurrentPeriod to set
	 */
	public void setCurrentPeriod(boolean isCurrentPeriod) {
		this.isCurrentPeriod = isCurrentPeriod;
	}

}