package com.ey.advisory.asp.master.service;

import java.io.File;
import java.util.List;

import com.ey.advisory.asp.domain.UploadFileStatus;
import com.ey.advisory.asp.dto.FileSearchDTO;
import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;


public interface UploadedFileService {
	
	public List<FileUploadStatusMaster> getUploadedFiles(FileSearchDTO fileDTO);
	
	/**
	 * This method is used to populate the UploadFileStatus bean .
	 */
	public UploadFileStatus getFileUploadParams(String filePath,String fileName,Long userId);

	public UploadFileStatus getFileUploadParams(String path,Integer flag, String userEmail,File File,String hashString);
	public UploadFileStatus getFileUploadParams(String path, Long userId, File File, String supplyType, String hashString,String groupCode);

	public UploadFileStatus getFileUploadParams(String path, Long userId, File File, String supplyType, String hashString,
			String groupCode, String userEmail);
	
	public UploadFileStatus getFileUploadParams(String path, Integer flag, String userEmail, String fileName,
			String hashString) ;
	
}
