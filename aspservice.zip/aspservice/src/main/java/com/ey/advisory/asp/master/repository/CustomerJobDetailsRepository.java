package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.CustomerJobDetails;

@Repository
@Transactional(readOnly = true)
public interface CustomerJobDetailsRepository extends JpaRepository<CustomerJobDetails, String>{
    
    @Query("from CustomerJobDetails")
    public List<CustomerJobDetails> getCustomerDetails();
    
    
    public CustomerJobDetails findByBeanNameAndGroupCode(String beanName, String groupCode);   
   
}
