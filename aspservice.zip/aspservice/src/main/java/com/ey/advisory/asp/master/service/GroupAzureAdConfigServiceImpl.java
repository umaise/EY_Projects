/**
 * 
 */
package com.ey.advisory.asp.master.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.GroupAzureAdConfig;
import com.ey.advisory.asp.master.repository.GroupAzureAdConfigRepository;

/**
 * @author Nitesh.Tripathi
 *
 */

@Service
public class GroupAzureAdConfigServiceImpl implements GroupAzureAdConfigService{
	
	protected EntityManager entityManager;
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Autowired
    private GroupAzureAdConfigRepository groupAdRepo;
	
	public List<GroupAzureAdConfig> findAll(){
		
		List<GroupAzureAdConfig> groupAzureAdConfig = groupAdRepo.findAll();
		return groupAzureAdConfig;
		
	}

}
