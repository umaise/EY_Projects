package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.TblReturnTypeRecordTypeMapping;

@Repository
@Transactional
public interface TblReturnTypeRecordTypeMappingRepository extends JpaRepository<TblReturnTypeRecordTypeMapping, Long>{

	@Override
    public List<TblReturnTypeRecordTypeMapping> findAll();
}
