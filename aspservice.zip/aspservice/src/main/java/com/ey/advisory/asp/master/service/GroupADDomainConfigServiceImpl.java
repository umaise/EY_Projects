/**
 * 
 */
package com.ey.advisory.asp.master.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.GroupADDomainConfigDomain;
import com.ey.advisory.asp.master.repository.GroupADDomainConfigRepository;

/**
 * @author Nitesh.Tripathi
 *
 */
@Service
public class GroupADDomainConfigServiceImpl implements GroupADDomainConfigService{

	private static final Logger LOGGER = Logger.getLogger(GroupADDomainConfigServiceImpl.class);
	
	protected EntityManager entityManager;
	
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
	
	@Autowired
	private GroupADDomainConfigRepository groupADDomainConfigRepository;
	
	@Override
	public List<GroupADDomainConfigDomain> findGroupsUsingDomain(String userDomains) {
		
		List<GroupADDomainConfigDomain> outputlist = null;
		
		try{
			outputlist = groupADDomainConfigRepository.findByUserDomains(userDomains);
		}catch(Exception e){
			
			LOGGER.error("findGroupsUsingDomain for "+userDomains+" Error :- "+e.fillInStackTrace());
			
		}
		
		if(outputlist == null){
			outputlist = new ArrayList<GroupADDomainConfigDomain>(0);
		}
		
		return outputlist;
	}
	
	
	@Override
	public List<Long> getGroupIdsForDomains(String userDomains){
		
		List<Long> groupId = new ArrayList<Long>();
		List<GroupADDomainConfigDomain> outputlist = findGroupsUsingDomain(userDomains);
		for(GroupADDomainConfigDomain domains: outputlist){
			groupId.add(domains.getGroupId());
		}
		
		return groupId;
	}
	
	
	public GroupADDomainConfigDomain save(GroupADDomainConfigDomain groupADDomainConfigDomain){
		
		GroupADDomainConfigDomain domains = groupADDomainConfigRepository.save(groupADDomainConfigDomain);
		
		return domains;
		
	}
	

	public List<GroupADDomainConfigDomain> findByGroupId(Long groupId){
		
		

		List<GroupADDomainConfigDomain> outputlist = null;
		
		try{
			outputlist = groupADDomainConfigRepository.findByGroupId(groupId);
		}catch(Exception e){
			
			LOGGER.error("findGroupsUsingDomain for "+groupId+" Error :- "+e.fillInStackTrace());
			
		}
		
		if(outputlist == null){
			outputlist = new ArrayList<GroupADDomainConfigDomain>(0);
		}
		
		return outputlist;
		
	}
}
