package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GeneratorType;

import com.ey.advisory.asp.common.Constant;

/**
 * @author Nisha.Kumari
 *
 */
@Entity
@Table(name="tblPurchaseMetadata",schema=Constant.MASTER_SCHEMA)
public class PurchaseMetaData implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer Id;
	private String columnName;
	private Integer columnOrderNo;
	private String columnCode;
	private String dataType;
	private String mandatory;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PurchaseID")
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	
	@Column(name="ColumnName")
	public String getColumnName() {
		return columnName;
	}
	
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	
	@Column(name="ColumnOrderNo")
	public Integer getColumnOrderNo() {
		return columnOrderNo;
	}
	public void setColumnOrderNo(Integer columnOrderNo) {
		this.columnOrderNo = columnOrderNo;
	}
	
	@Column(name="ColumnCode")
	public String getColumnCode() {
		return columnCode;
	}
	public void setColumnCode(String columnCode) {
		this.columnCode = columnCode;
	}
	
	@Column(name="DataType")
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	
	@Column(name="Mandatory")
	public String getMandatory() {
		return mandatory;
	}
	public void setMandatory(String mandatory) {
		this.mandatory = mandatory;
	}
	
	

}
