/**
 * 
 */
package com.ey.advisory.asp.master.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.MasterHierarchyConfig;
import com.ey.advisory.asp.master.repository.MasterHierarchyConfigRepo;

/**
 * @author Nitesh.Tripathi
 *
 */
@Service
public class MasterHierarchyConfigServiceImpl implements MasterHierarchyConfigService {

	 
    protected EntityManager entityManager;
    public EntityManager getEntityManager() {
        return entityManager;
    }
    
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Autowired
    private MasterHierarchyConfigRepo masterHierarchyConfigRepo;
    
	@Override
	public List<MasterHierarchyConfig> findAll() {
		// TODO Auto-generated method stub
		return masterHierarchyConfigRepo.findAll();
	}

}
