package com.ey.advisory.asp.master.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.PortCodeMaster;
import com.ey.advisory.asp.master.repository.PortCodeMasterRepository;

@Service
public class PortCodeMasterServiceImpl implements PortCodeMasterService{

	@Autowired
	private PortCodeMasterRepository portCodeMasterRepository;
	 
	protected EntityManager entityManager;
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
	@Override
	public List<PortCodeMaster> findAll() {
		return portCodeMasterRepository.findAll();
	}

}
