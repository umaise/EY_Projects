package com.ey.advisory.asp.master.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.advisory.asp.master.domain.PurchaseMetaData;

/**
 * @author Nisha.Kumari
 *
 */
public interface PurchaseMetaDataRepository extends JpaRepository<PurchaseMetaData, Long>{

}
