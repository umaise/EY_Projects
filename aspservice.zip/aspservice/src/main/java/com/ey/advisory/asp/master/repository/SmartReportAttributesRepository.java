package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.SmartReportAttributes;

@Repository
@Transactional(readOnly = true)
public interface SmartReportAttributesRepository  extends JpaRepository<SmartReportAttributes, Long> {

	@Query("from  SmartReportAttributes s WHERE s.fileCategory= :fileCategory order by mandatory desc")
	public List<SmartReportAttributes> findAttributesByFileCategory(@Param("fileCategory") String fileCategory);
	
	
	
}
