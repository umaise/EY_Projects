/**
 * 
 */
package com.ey.advisory.asp.service;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchResult;

/**
 * @author Uma.Chandranaik
 *
 */
public interface ActiveDirectoryService {
	
	 public DirContext intitializeActiveDirectory(String userName, String password);
	 public NamingEnumeration<SearchResult> searchUser(DirContext dirContext,String searchValue, String searchBy, String searchBase) throws NamingException;
	 public boolean addUser(String userName, String firstName, String lastName, String password) throws NamingException;
	 public void updateUser();
	 public void updateUserPassword(String username, String password);
	 public void deleteUser(String username);
	 public void closeLdapConnection();
}
