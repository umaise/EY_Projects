package com.ey.advisory.asp.master.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.ReturnPeriod;

@Repository
@Transactional
public interface IReturnPeriodRepository  extends JpaRepository<ReturnPeriod, Integer> {

	public ReturnPeriod findByIsCurrentPeriod(boolean currentPeriod);
	
	@Modifying
	@Query("update ReturnPeriod period set period.isCurrentPeriod='0' where period.periodId =:periodId ")
	public void deActivateReturnPeriod(@Param("periodId")  int  periodId);
}
