package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.List;

public class RoleDto implements Serializable {

	private Long roleID;
	private String roleName;
	private String roleDescription;
	private List<FunctionDto> function;
	private String roleType;
	private String category;
	
	public Long getRoleID() {
		return roleID;
	}
	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getRoleDescription() {
		return roleDescription;
	}
	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}
	public List<FunctionDto> getFunction() {
		return function;
	}
	public void setFunction(List<FunctionDto> function) {
		this.function = function;
	}
	/**
	 * @return the roleType
	 */
	public String getRoleType() {
		return roleType;
	}
	/**
	 * @param roleType the roleType to set
	 */
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
}
