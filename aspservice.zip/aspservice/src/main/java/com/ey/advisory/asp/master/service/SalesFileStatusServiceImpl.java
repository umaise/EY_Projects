package com.ey.advisory.asp.master.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.master.repository.FileUploadStatusRepository;

@Service
public class SalesFileStatusServiceImpl implements SalesFileStatusService {

	 private static final Logger LOGGER = Logger
		        .getLogger(SalesFileStatusServiceImpl.class);
	@Autowired
	
	FileUploadStatusRepository tblSalesFileStatusRepo;

	@Override
	public boolean updateFilejobStatus(String key) {
		if(LOGGER.isInfoEnabled())
		  LOGGER.info("entering updateFilejobStatus"+key);
		String[] split = key.split("_");
		Integer fileId = Integer.parseInt(split[1]);
		if(split.length==2){
			if(LOGGER.isInfoEnabled())
			 LOGGER.info("key contains  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
			if(key.contains(Constant.KEY_GSTR2)){
				if(LOGGER.isInfoEnabled())
				 LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
			tblSalesFileStatusRepo.updateIsProcessedJobStatus(Constant.IS_PROCESSED_PIPELINE2,Constant.JOB_STATUS_PIPELINE, fileId);
			if(LOGGER.isInfoEnabled()) 
			LOGGER.info("After  updateFilejobStatus");
			}
			
			else{
				
				LOGGER.info("before  updateFilejobStatus gstr1");
				tblSalesFileStatusRepo.updateIsProcessedJobStatus(Constant.IS_PROCESSED_PIPELINE1,Constant.JOB_STATUS_PIPELINE, fileId);
				
				LOGGER.info("before  updateFilejobStatus gstr1");
			}
		}
		else if(split.length==3 && key.contains("")){
			
			LOGGER.info("before  updateFilejobStatus gstrPipe2");
			
			tblSalesFileStatusRepo.updateIsProcessedJobStatus(Constant.IS_PROCESSED_PIPELINE2,Constant.JOB_STATUS_PIPELINE, fileId);
			
			LOGGER.info("before  updateFilejobStatus gstrPipe2");
		}
		
		return true;
	}

}
