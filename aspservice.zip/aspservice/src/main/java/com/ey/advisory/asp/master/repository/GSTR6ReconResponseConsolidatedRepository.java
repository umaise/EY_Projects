package com.ey.advisory.asp.master.repository;

import java.util.LinkedList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.master.domain.GSTR2ReconResponseConsolidatedMetadata;
import com.ey.advisory.asp.master.domain.GSTR6ReconResponseConsolidatedMetadata;
@Repository
public interface GSTR6ReconResponseConsolidatedRepository extends JpaRepository<GSTR6ReconResponseConsolidatedMetadata, Integer> {
	
	@Query("from  GSTR2ReconResponseConsolidatedMetadata g WHERE g.reconResponseType= :sheetName order by g.columnOrderNo")
	public LinkedList<GSTR6ReconResponseConsolidatedMetadata> getMetadataBySheetName(@Param("sheetName") String sheetName);
}
