package com.ey.advisory.asp.dto;

import com.ey.advisory.asp.master.domain.User;

public class YearMonthDto {
	
	private String gstinId;
	private String month;
	private String year;
	private boolean dbFlag; 
	private User user;
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public boolean isDbFlag() {
		return dbFlag;
	}
	public void setDbFlag(boolean dbFlag) {
		this.dbFlag = dbFlag;
	}
	
	public String getGstinId() {
		return gstinId;
	}
	public void setGstinId(String gstinId) {
		this.gstinId = gstinId;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "YearMonthDto [gstinId=" + gstinId + ", month=" + month
				+ ", year=" + year +  ", dbFlag=" + dbFlag
				+  "]";
	}

}
