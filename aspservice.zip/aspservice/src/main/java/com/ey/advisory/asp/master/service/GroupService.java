package com.ey.advisory.asp.master.service;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.GroupConfig;

public interface GroupService {
	
	public List<Group> getAllGroups();
	
	public Map<String, Group> getAllGroupsByGroupCodeMap();

	/**
	 * get group active config values for groupCode
	 * @param groupCode
	 * @return
	 */
	public List<GroupConfig> getGroupConfigvalues(String groupCode);
	
	public List<String> getAllActiveGroups();

	public List<GroupConfig> getGroupvaluesByReportType(String string, String string2);

	public List<GroupConfig> findAllGroupConfig();
	
	public Long count();
	
	public List<Group> getAllActiveGroupsByPagination(int pagenumber, int pageSize);
	
	public List<Group> getGroupCode(String searchText);

	public Long getGroupCount(String searchText);
	
	public Group findGroupByGroupdId(Long groupId);
	
}
