package com.ey.advisory.asp.master.service;

public interface Gstr1ServiceMaster {
	public String getReturnPeriod();

}
