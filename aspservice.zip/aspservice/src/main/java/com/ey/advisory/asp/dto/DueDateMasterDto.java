package com.ey.advisory.asp.dto;

public class DueDateMasterDto {

	private Long returnId;

	private String gstnId;

	private String applicableReturn;

	private Long dueDates;

	private Long gstnMandatedDate;

	public Long getGstnMandatedDate() {
		return gstnMandatedDate;
	}

	public void setGstnMandatedDate(Long gstnMandatedDate) {
		this.gstnMandatedDate = gstnMandatedDate;
	}

	public String getApplicableReturn() {
		return applicableReturn;
	}

	public Long getReturnId() {
		return returnId;
	}

	public void setReturnId(Long returnId) {
		this.returnId = returnId;
	}

	public String getGstnId() {
		return gstnId;
	}

	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}

	public void setApplicableReturn(String applicableReturn) {
		this.applicableReturn = applicableReturn;
	}

	public Long getDueDates() {
		return dueDates;
	}

	public void setDueDates(Long dueDates) {
		this.dueDates = dueDates;
	}

}
