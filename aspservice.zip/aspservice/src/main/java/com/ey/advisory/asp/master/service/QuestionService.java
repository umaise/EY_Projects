package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.QuestionModule;

public interface QuestionService {

    List<QuestionModule> findAll();
}

