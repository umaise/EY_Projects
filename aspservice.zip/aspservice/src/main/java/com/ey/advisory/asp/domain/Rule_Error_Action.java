package com.ey.advisory.asp.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType (XmlAccessType.NONE)
@Entity
@Table(name = "Error_Action")
public class Rule_Error_Action {
	
	private int slNo;
	 private String errorCDE;
	 private String actionCDE;
	 private String clientFileID;
	 private Date createdDate;
	
	 @Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "Sl_No")
	 public int getSlNo() {
		return slNo;
	}
	public void setSlNo(int slNo) {
		this.slNo = slNo;
	}
	@Column(name = "Error_CDE")
	public String getErrorCDE() {
		return errorCDE;
	}
	public void setErrorCDE(String errorCDE) {
		this.errorCDE = errorCDE;
	}
	@Column(name = "Action_CDE")
	public String getActionCDE() {
		return actionCDE;
	}
	public void setActionCDE(String actionCDE) {
		this.actionCDE = actionCDE;
	}
	
	@Column(name = "Client_File_ID")
	public String getClientFileID() {
		return clientFileID;
	}
	public void setClientFileID(String clientFileID) {
		this.clientFileID = clientFileID;
	}
	@Column(name = "Created_Date")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	 

}
