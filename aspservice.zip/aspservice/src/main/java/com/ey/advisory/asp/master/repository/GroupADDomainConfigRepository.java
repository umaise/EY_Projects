package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ey.advisory.asp.master.domain.GroupADDomainConfigDomain;

@Repository
public interface GroupADDomainConfigRepository extends JpaRepository<GroupADDomainConfigDomain, Long> {

	public List<GroupADDomainConfigDomain> findByUserDomains(String userDomains);
	
	public GroupADDomainConfigDomain save(GroupADDomainConfigDomain groupADDomainConfigDomain);
	
	public List<GroupADDomainConfigDomain> findByGroupId(Long groupId);
	
	
}
