package com.ey.advisory.asp.master.service;

import java.util.ArrayList;
import java.util.List;

import com.ey.advisory.asp.master.domain.DocAndSupplyTypeMetadata;

public interface DocAndSupplyTypeService {
	
	public List<DocAndSupplyTypeMetadata> findByFileCategoryAndDocType(List<String> fileCategory,String typeOfDoc);

}
