package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblSmartReportAttributes",schema="metadata")
public class SmartReportAttributes  implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AttributeID")
    private long attributeID;
    
    @Column(name = "Description")
    private String description;
    
    @Column(name = "Property")
    private String property;
    
    @Column(name = "Header")
    private String header;
    
    @Column(name = "FileCategory")
    private String fileCategory;
    
    @Column(name = "Mandatory")
    private String mandatory;

   	public String getMandatory() {
   		return mandatory;
   	}

   	public void setMandatory(String mandatory) {
   		this.mandatory = mandatory;
   	}


	public long getAttributeID() {
		return attributeID;
	}

	public void setAttributeID(long attributeID) {
		this.attributeID = attributeID;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getFileCategory() {
		return fileCategory;
	}

	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}

	@Override
	public String toString() {
		return "SmartReportAttributes [attributeID=" + attributeID + ", description=" + description + ", property="
				+ property + ", header=" + header + ", fileCategory=" + fileCategory + "]";
	}
    
    
}
