package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;
@Repository
@Transactional
public interface FileUploadStatusRepository extends JpaRepository<FileUploadStatusMaster, Long>{
	
	public List<FileUploadStatusMaster> findByUserId(long userId);
	
	public List<FileUploadStatusMaster> findByIsStageProcessedAndJobStatusAndFileData(String isStageProcessed, String jobStatus, String fileData, Pageable topTen);
	
	public List<FileUploadStatusMaster> findByIsStageProcessedAndJobStatus(String isStageProcessed, String jobStatus, Pageable pageSize);

	public List<FileUploadStatusMaster> findByIsStageProcessedAndJobStatusAndFileData(String isStageProcessed, String jobStatus, String fileData);
	
	@Modifying
	@Query("update FileUploadStatusMaster file set file.isStageProcessed =:isProcessed, file.jobStatus=:jobStatus where file.fileId =:fileId ")
	void updateIsProcessedJobStatus(@Param("isProcessed") String isProcessed, @Param("jobStatus") String jobStatus, @Param("fileId") long fileId);

	public List<FileUploadStatusMaster>  findByJobStatusAndFileData(String jobStatus, String fileData);
	
	@Modifying
	@Query("update FileUploadStatusMaster file set file.jobStatus=:jobStatus where file.fileId =:fileId ")
	public void updateJobStatus(@Param("jobStatus")  String jobStatus,@Param("fileId") long fileId);
	
	@Modifying
	@Query("update  FileUploadStatusMaster file set file.isStageProcessed=:updateIsProcessedTo , file.jobStatus=:updateJobStatusTo where "
			+"file.fileId in(select fileId from FileUploadStatusMaster file1 "
			+"where file1.isStageProcessed=:isProccessed and file1.jobStatus=:jobStatus and file1.fileData=:fileData) " )
	public void updateFileIdDetails(@Param("updateIsProcessedTo")String updateIsProcessedTo,@Param("updateJobStatusTo")String updateJobStatusTo,
			@Param("isProccessed")String isProccessed,
			@Param("jobStatus")String jobStatus,@Param("fileData")String fileData);
	
	@Modifying
	@Query("select fileId from FileUploadStatusMaster file "
	    				+"	where file.isStageProcessed=:isProccessed and file.jobStatus=:jobStatus and file.fileData=:fileData and file.fileId=:fileId" )
	public List<String> fetchDetails(@Param("isProccessed") String isProccessed,
			@Param("jobStatus")String jobStatus,@Param("fileData")String fileData,@Param("fileId")long fileId);


}
