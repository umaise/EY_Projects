package com.ey.advisory.asp.master.service;

import java.util.LinkedList;

import com.ey.advisory.asp.master.domain.GSTR2ReconResponseConsolidatedMetadata;

public interface GSTR2ReconResponseConsolidatedService {
	public LinkedList<GSTR2ReconResponseConsolidatedMetadata> getMetadataBySheetName(String sheetName);
}
