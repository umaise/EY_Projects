package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.ErrorMasterDto;
import com.ey.advisory.asp.master.domain.User;


@Transactional(readOnly = true)
public interface ErrorMasterRepository extends JpaRepository<ErrorMasterDto, String> {
	
	
	@Query("select userdetails from User userdetails , FileUploadStatusMaster file where userdetails.userId=file.userId and file.fileId= :fileId")
	public List<User> getFileUploaderDetails(@Param("fileId") Long fileId);
	
	public List<ErrorMasterDto> findByIsError(char isError);
		
	}
