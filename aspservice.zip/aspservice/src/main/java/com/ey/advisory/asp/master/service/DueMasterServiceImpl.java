package com.ey.advisory.asp.master.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.DueDateMaster;
import com.ey.advisory.asp.master.repository.DueDateMasterRepository;


@Service("dueMasterService")
public class DueMasterServiceImpl implements DueMasterService {
	
	@Autowired
	DueDateMasterRepository dueDateMasterRepository;

	@Override
	public List<DueDateMaster> findAll() {
		// TODO Auto-generated method stub
		return dueDateMasterRepository.findAll();
	}
	
	
}