package com.ey.advisory.asp.master.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.ReturnMasterDto;

@Transactional
public interface ReturnMasterRepository extends JpaRepository<ReturnMasterDto, Double>{
	
	public List<ReturnMasterDto> findByReturnType(String returnType);
	

}
