package com.ey.advisory.asp.master.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.GstinDueDateMaster;
import com.ey.advisory.asp.master.repository.GstinDueDateMasterRepository;

@Service
@PropertySource("classpath:RestConfig.properties")
@Transactional
public class GstinDueDateMasterServiceImpl implements GstinDueDateMasterService{
	@Autowired
    private GstinDueDateMasterRepository gstinDueDateMasterRepository;
	@Override
	public List<GstinDueDateMaster> findGstnDueDate(List<String> contentType) {
		List<GstinDueDateMaster> list = null;
		try{
			list = gstinDueDateMasterRepository.findGstnDueDate(contentType);
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
}
