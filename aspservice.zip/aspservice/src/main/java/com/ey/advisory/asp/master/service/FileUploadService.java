package com.ey.advisory.asp.master.service;

import com.ey.advisory.asp.master.domain.FileUploadMaster;

public interface FileUploadService {

	String insertFileDetail(FileUploadMaster fileUploadMaster)  throws Exception; 
	void updateUploadStatus(String stageBifurcation, int fileId);
}
