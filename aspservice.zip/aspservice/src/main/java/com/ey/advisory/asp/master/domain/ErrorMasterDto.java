package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblErrorMaster",schema="master")
public class ErrorMasterDto implements Serializable {
	
	

	//private String ruleID;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String errorInfoCode;
	private String errorInfoDesc;
	private char isError;
	private String incidenceLevel;
	private String returnImpacted;
	private int errorId;
	
	@Id
	@Column(name = "ErrorInfoCode",nullable=false )
	public String getErrorInfoCode() {
		return errorInfoCode;
	}
	public void setErrorInfoCode(String errorInfoCode) {
		this.errorInfoCode = errorInfoCode;
	}
	
	@Column(name = "ErrorInfoDesc")
	public String getErrorInfoDesc() {
		return errorInfoDesc;
	}
	public void setErrorInfoDesc(String errorInfoDesc) {
		this.errorInfoDesc = errorInfoDesc;
	}
	
	@Column(name = "IsError")
    public char getIsError() {
        return isError;
    }
    public void setIsError(char isError) {
        this.isError = isError;
    }
    
    @Column(name="IncidenceLevel")
    public String getIncidenceLevel() {
		return incidenceLevel;
	}
	public void setIncidenceLevel(String incidenceLevel) {
		this.incidenceLevel = incidenceLevel;
	}
	
	@Column(name="ReturnImpacted")
	public String getReturnImpacted() {
		return returnImpacted;
	}
	
	public void setReturnImpacted(String returnImpacted) {
		this.returnImpacted = returnImpacted;
	}
	
	@Column(name="ErrorId")
	public int getErrorId() {
		return errorId;
	}
	
	public void setErrorId(int errorId) {
		this.errorId = errorId;
	}
    	

}
