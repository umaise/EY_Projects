package com.ey.advisory.asp.master.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.ErrorMasterDto;
import com.ey.advisory.asp.master.repository.ErrorMasterRepository;

@Service("masterErrorTableService")
public class MasterErrorTableServiceImpl implements MasterErrorTableService {
	
	@Autowired
	private ErrorMasterRepository errorMasterRepository;
	
	@Override
	public List<ErrorMasterDto> findByIsError(char isError) {
	
		return errorMasterRepository.findByIsError(isError);
	}

}
