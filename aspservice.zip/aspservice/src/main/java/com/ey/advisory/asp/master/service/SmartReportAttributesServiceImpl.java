package com.ey.advisory.asp.master.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.master.domain.SmartReportAttributes;
import com.ey.advisory.asp.master.repository.SmartReportAttributesRepository;

@Service
public class SmartReportAttributesServiceImpl implements SmartReportAttributesService{

	protected EntityManager entityManager;
    public EntityManager getEntityManager() {
        return entityManager;
    }
    
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Autowired
    private SmartReportAttributesRepository smartReportAttributesRepository;
	@Override
	public List<SmartReportAttributes> findAttributesByFileCategory(String fileCategory) {
		return smartReportAttributesRepository.findAttributesByFileCategory(fileCategory);
	}
    
}
