/**
 * 
 */
package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Nitesh.Tripathi
 *
 */
@Entity
@Table(name = "tblHierarchyConfig",schema="master")
public class MasterHierarchyConfig implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HierarchyConfigID")
	private Integer hierarchyConfigID;

	@Column(name = "OrgLevel")
	private String orgLevel;

	@Column(name = "OrgLevelValue")
	private String orgLevelValue;

	@Column(name = "HomePageRef")
	private String homePageRef;

	/**
	 * @return the hierarchyConfigID
	 */
	public Integer getHierarchyConfigID() {
		return hierarchyConfigID;
	}

	/**
	 * @return the orgLevel
	 */
	public String getOrgLevel() {
		return orgLevel;
	}

	/**
	 * @return the orgLevelValue
	 */
	public String getOrgLevelValue() {
		return orgLevelValue;
	}

	/**
	 * @return the homePageRef
	 */
	public String getHomePageRef() {
		return homePageRef;
	}

	/**
	 * @param hierarchyConfigID
	 *            the hierarchyConfigID to set
	 */
	public void setHierarchyConfigID(Integer hierarchyConfigID) {
		this.hierarchyConfigID = hierarchyConfigID;
	}

	/**
	 * @param orgLevel
	 *            the orgLevel to set
	 */
	public void setOrgLevel(String orgLevel) {
		this.orgLevel = orgLevel;
	}

	/**
	 * @param orgLevelValue
	 *            the orgLevelValue to set
	 */
	public void setOrgLevelValue(String orgLevelValue) {
		this.orgLevelValue = orgLevelValue;
	}

	/**
	 * @param homePageRef
	 *            the homePageRef to set
	 */
	public void setHomePageRef(String homePageRef) {
		this.homePageRef = homePageRef;
	}

}
