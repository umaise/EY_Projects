package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.SummaryFileLoadMaster;

@Repository
@Transactional
public interface SummaryFileUploadRepository extends JpaRepository<SummaryFileLoadMaster, Long>{

	public List<SummaryFileLoadMaster> findByFileHash(String fileHash);

	
	@Modifying
	@Query("update SummaryFileLoadMaster file set file.status =:status where file.summaryFileId in (:fileIdlist) ")
	void updateSummaryStatus(@Param("fileIdlist") List<Integer> fileIdlist,@Param("status") String status);

	
	@Modifying
    @Query("UPDATE SummaryFileLoadMaster sumFileLoad SET sumFileLoad.status = :status WHERE sumFileLoad.summaryFileId = :summaryFileId")
    public int updateSummaryFileLoadMaster(@Param("status") String status, @Param("summaryFileId") int summaryFileId);  

}
