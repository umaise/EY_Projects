package com.ey.advisory.asp.master.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.master.domain.AnswerModule;
import com.ey.advisory.asp.master.domain.ErrorMasterDto;
import com.ey.advisory.asp.master.domain.GSTR2ReconResponseConsolidatedMetadata;
import com.ey.advisory.asp.master.domain.GSTR6ReconResponseConsolidatedMetadata;
import com.ey.advisory.asp.master.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.GroupAzureAdConfig;
import com.ey.advisory.asp.master.domain.GroupConfig;
import com.ey.advisory.asp.master.domain.HsnSacMasterDetailsDto;
import com.ey.advisory.asp.master.domain.MasterHierarchyConfig;
import com.ey.advisory.asp.master.domain.PurchaseMetaData;
import com.ey.advisory.asp.master.domain.QuestionModule;
import com.ey.advisory.asp.master.domain.ReturnType;
import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.domain.RoleAccessHierarchyMap;
import com.ey.advisory.asp.master.domain.SmartReportAttributes;
import com.ey.advisory.asp.master.domain.States;
import com.ey.advisory.asp.master.domain.SupplyMetaData;
import com.ey.advisory.asp.master.domain.TblBifurcationCodes;
import com.ey.advisory.asp.master.domain.TblReturnTypeRecordTypeMapping;
import com.ey.advisory.asp.master.repository.ErrorMasterRepository;
import com.ey.advisory.asp.master.repository.GlobalGSTRatesMasterIRepository;
import com.ey.advisory.asp.master.repository.PurchaseMetaDataRepository;
import com.ey.advisory.asp.master.repository.SmartReportAttributesRepository;
import com.ey.advisory.asp.master.repository.SupplyMetaDataRepository;
import com.ey.advisory.asp.master.repository.TblBifercationCodeRepository;
import com.ey.advisory.asp.util.DateUtillity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


@Service
public class RedisLoadInfoServiceImpl implements RedisLoadService {

	private static final Logger LOGGER = Logger
			.getLogger(RedisLoadInfoServiceImpl.class);
	
	@Autowired
	private TblReturnTypeRecordTypeMappingService tblReturnTypeRecordTypeMappingService;
	
	@Autowired
	private SpCallService spCallService;

	@Autowired
	private ErrorMasterRepository errorMasterRepository;

	@Autowired
	private StatesService statesService;

	@Autowired
	private QuestionService questionService;

	@Autowired
	private AnswerService answerService;

	@Autowired
	private GroupService groupService;

	@Autowired
	private SupplyMetaDataRepository supplyMetaDataRepository;

	@Autowired
	private GlobalGSTRatesMasterIRepository globalGSTRatesMasterIRepository;

	@Autowired
	private PurchaseMetaDataRepository purchaseMetaDataRepository;

	@Autowired(required = false)
	private RedisTemplate<String, Object> redisTemplate;

	@Autowired
	private RoleService roleService;

	@Autowired
	private MasterHierarchyConfigService masterHierarchyConfigService;

	@Autowired
	private MasterReturnTypeService  masterReturnTypeService;

	@Autowired
	private GroupAzureAdConfigService groupAzureAdConfigService;

	@Autowired
	private RoleAccessHierarchyMapService roleAccessHierarchyMapService;
	
	@Autowired
	private TblBifercationCodeRepository bifercationCodeRepository;
	
	@Autowired
	private SmartReportAttributesRepository  smartReportAttributesRepository;
	
	
	@Autowired
	private GroupConfigService groupConfigService;
	
	@Autowired
	private GSTR2ReconResponseConsolidatedService gstr2ReconResponseConsolidatedService;
	
	@Autowired
	private GSTR6ReconResponseConsolidatedService gstr6ReconResponseConsolidatedService;
	
	
	@Override
	public void fetchHSNMasterDetails() {

		List<Object[]> executeHSNMasterProc;
		try {
			executeHSNMasterProc = spCallService
					.executeSPReturnList(Constant.PROC_HSN_MASTER_NAME);
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("Entering " + " proc Executed : executeStoredProcedure");
			}

			Map<String, List<HsnSacMasterDetailsDto>> hsnMatermap = new HashMap<>();

			for (Object[] object : executeHSNMasterProc) {

				HsnSacMasterDetailsDto hsnDto = new HsnSacMasterDetailsDto();
				hsnDto.setIgsthSNSACId((object[0] == null) ? 0
						: (Integer) object[0]);
				hsnDto.setiGSTRt((BigDecimal) ((object[1] == null) ? 0.0
						: (BigDecimal) object[1]));
				hsnDto.setIgstcessRt((BigDecimal) ((object[2] == null) ? 0.0
						: (BigDecimal) object[2]));
				hsnDto.setIgstisActive((object[3] == null) ? ';'
						: (Character) object[3]);

				hsnDto.setIgstvalidUntil((object[4] == null) ? null
						: DateUtillity.getDate(object[4].toString()));
				hsnDto.setValidUntil((object[10] == null) ? null : DateUtillity
						.getDate(object[10].toString()));

				hsnDto.setsGSThSNSACId((object[5] == null) ? 0
						: (Integer) object[5]);
				hsnDto.setsGSTRt((BigDecimal) ((object[6] == null) ? 0.0
						: (BigDecimal) object[6]));
				hsnDto.setcGSTRt((BigDecimal) ((object[7] == null) ? 0.0
						: (BigDecimal) object[7]));
				hsnDto.setCessRt((BigDecimal) ((object[8] == null) ? 0.0
						: (BigDecimal) object[8]));
				hsnDto.setIsActive((object[9] == null) ? ';'
						: (Character) object[9]);

				hsnDto.sethSNSACId((object[11] == null) ? 0
						: (Integer) object[11]);
				hsnDto.setItemCode((object[12] == null) ? ""
						: (String) object[12]);
				hsnDto.setItemDescription((object[13] == null) ? ""
						: (String) object[13]);
				hsnDto.setItemType((object[14] == null) ? ';'
						: (Character) object[14]);
				hsnDto.sethSNSACCode((object[15] == null) ? ""
						: (String) object[15]);

				hsnDto.setSlabID((object[16] == null) ? 0
						: (Integer) object[16]);
				hsnDto.setMinValue((object[17] == null) ? 0
						: (Integer) object[17]);
				hsnDto.setMaxValue((object[18] == null) ? 0
						: (Integer) object[18]);
				hsnDto.setRangeFormula((object[19] == null) ? ""
						: (String) object[19]);
				hsnDto.setStatecode((object[20] == null) ? ""
						: (String) object[20]);

				if (hsnMatermap.size() == 0
						|| hsnMatermap.get(hsnDto.gethSNSACCode()) == null) {

					List<HsnSacMasterDetailsDto> masterDetailsList = new ArrayList<>();
					masterDetailsList.add(hsnDto);
					hsnMatermap.put(hsnDto.gethSNSACCode(), masterDetailsList);
				}

				else {

					hsnMatermap.get(hsnDto.gethSNSACCode()).add(hsnDto);
				}

			}



			redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
					Constant.HSN_MASTER_DET, hsnMatermap);

		} catch (Exception e1) {
			LOGGER.error("Error while loading HSN master details to cache" + e1);
		}
	}

	@Override
	public void fetchErrorMaster() {
		List<ErrorMasterDto> listofErrors = errorMasterRepository.findAll();

		Map<String, ErrorMasterDto> errorMastermap = new HashMap<String, ErrorMasterDto>();

		for (ErrorMasterDto errorMasterDto : listofErrors) {
			errorMastermap.put(errorMasterDto.getErrorInfoCode(),
					errorMasterDto);
		}

		redisTemplate.opsForHash().putAll(Constant.ERROR_MASTER_LIST, errorMastermap);
	}

	@Override
	public void loadStateCodeMaster(){

		List<States> stateList =  statesService.findAll();

		Gson gson = new Gson();
		String outString = gson.toJson(stateList);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				Constant.STATES_LIST, outString);

	}

	@Override
	public List<States> fetchStateList(){
		String stateListJson = (String) redisTemplate.opsForHash().get(Constant.REDIS_CACHE,
				Constant.STATES_LIST);
		Gson gson = new Gson();
		List<States> stateList = gson.fromJson(stateListJson, new TypeToken<List<States>>() {
		}.getType());
		return stateList;

	}

	@Override
	public void loadTblReturnTypeRecordTypeMapping() {
		List<TblReturnTypeRecordTypeMapping> returnTypeList = tblReturnTypeRecordTypeMappingService.findAll();
		Gson gson = new Gson();
		String returnTypeString = gson.toJson(returnTypeList);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,Constant.TBLRETURNTYPE_RECORDTYPEMAPPING, returnTypeString);
	}
	
	
	@Override
	public void loadGroupMaster(){

		List<Group> groupList =  groupService.getAllGroups();		
		Gson gson = new Gson();
		String outString = gson.toJson(groupList);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				Constant.GROUP_LIST, outString);

	}

	@Override
	public List<Group> fetchGroupList(){
		String groupListJson = (String) redisTemplate.opsForHash().get(Constant.REDIS_CACHE,
				Constant.GROUP_LIST);
		Gson gson = new Gson();
		List<Group> groupList = gson.fromJson(groupListJson, new TypeToken<List<Group>>() {
		}.getType());
		return groupList;

	}

	@Override
	public void loadQuestionMaster() {
		List<QuestionModule> questionList =  questionService.findAll();
		Map<String,QuestionModule> questionModuleMap = new HashMap<>();
		for(QuestionModule question : questionList){
			questionModuleMap.put(question.getQuestionID(), question);
		}

		Gson gson = new Gson();
		String questionString = gson.toJson(questionModuleMap);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				Constant.QUESTIONS_LIST, questionString);

	}

	@Override
	public void loadAnswerMaster() {
		List<AnswerModule> answerList =  answerService.findAll();

		Map<String,List<AnswerModule>> answerModuleMap = new HashMap<>();
		List<AnswerModule> answerModuleList;
		for(AnswerModule answer : answerList){

			if(answerModuleMap.get(answer.getQuestionID())==null){
				answerModuleList = new ArrayList<>();
			}else{
				answerModuleList =  answerModuleMap.get(answer.getQuestionID());
			}
			answerModuleList.add(answer);
			answerModuleMap.put(answer.getQuestionID(), answerModuleList);
		}
		Gson gson = new Gson();
		String answerString = gson.toJson(answerModuleMap);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				Constant.ANSWERS_LIST, answerString);
	}

	@Override
	public void loadSupplyMetaData() {
		List<SupplyMetaData> supplyMetaDataList = supplyMetaDataRepository.findAll();
		Map<String,SupplyMetaData> supplyMetaDataMap = null;
		if(supplyMetaDataList !=null  && !supplyMetaDataList.isEmpty()){
			supplyMetaDataMap = new HashMap<>();
			for(SupplyMetaData supplyMetaData:supplyMetaDataList){
				supplyMetaDataMap.put(supplyMetaData.getColumnCode(), supplyMetaData);

			}
		}
		redisTemplate.opsForHash().putAll(Constant.SUPPLY_METADATA, supplyMetaDataMap);

	}


	@Override
	public void loadRoleMaster(){

		List<Role> roleList =  roleService.getAllRoles();	
		Gson gson = new Gson();
		String outString = gson.toJson(roleList);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				Constant.ROLE_LIST, outString);

	}

	@Override
	public List<Role> fetchRoleList(){
		String roleListJson = (String) redisTemplate.opsForHash().get(Constant.REDIS_CACHE,
				Constant.ROLE_LIST);
		Gson gson = new Gson();
		List<Role> roleList = gson.fromJson(roleListJson, new TypeToken<List<Role>>() {
		}.getType());

		return roleList;

	}

	@Override
	public void loadMasterHierarchyConfig(){
		List<MasterHierarchyConfig> mhConfigList = masterHierarchyConfigService.findAll();
		Gson gson = new Gson();
		String outString = gson.toJson(mhConfigList);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				"masterHierarchyConfig", outString);
	}

	@Override
	public List<MasterHierarchyConfig> fetchMasterHierarchyConfigList(){
		String MasterHierarchyConfigJson = (String) redisTemplate.opsForHash().get(Constant.REDIS_CACHE,
				"masterHierarchyConfig");
		Gson gson = new Gson();
		List<MasterHierarchyConfig> MasterHierarchyConfigList = gson.fromJson(MasterHierarchyConfigJson, new TypeToken<List<MasterHierarchyConfig>>() {
		}.getType());

		return MasterHierarchyConfigList;

	}

	@Override
	public void loadReturnTypeMaster(){
		List<ReturnType> returnTypeList = masterReturnTypeService.findAll();
		Gson gson = new Gson();
		String outString = gson.toJson(returnTypeList);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				"masterReturnType", outString);
	}
	
	@Override
	public void loadGroupConfigDetails() {
		
		List<GroupConfig> groupConfigList =  groupService.findAllGroupConfig();
		
		Map<String, HashMap<String,String>> groupConfigMap = new HashMap<String, HashMap<String,String>>();
		Map<String, String> domainConfig = new HashMap<String, String>();
		for(GroupConfig grpConfig : groupConfigList){
			
			HashMap<String, String> configForGroupCode = groupConfigMap.getOrDefault(Constant.GROUP_CONFIG_KEY+grpConfig.getGroupCode(), new HashMap<String,String>());
			
			configForGroupCode.put(grpConfig.getConfigCode(), grpConfig.getConfigValue());
			groupConfigMap.put(Constant.GROUP_CONFIG_KEY+grpConfig.getGroupCode(), configForGroupCode);
			
			if(grpConfig.getConfigCode() !=null && grpConfig.getConfigCode().equalsIgnoreCase(Constant.DOMAIN_NAME))
			{
				domainConfig.put(Constant.GROUP_DOMAIN_KEY+grpConfig.getConfigValue(), grpConfig.getGroupCode());
			}
			
		}
		
		// put into redis key 
		redisTemplate.opsForHash().putAll(Constant.REDIS_CACHE, groupConfigMap);
		redisTemplate.opsForHash().putAll(Constant.REDIS_CACHE, domainConfig);
		
	}


	@Override
	public void load() {
		fetchErrorMaster();
		loadStateCodeMaster();
		loadGroupMaster();
		loadQuestionMaster();
		loadAnswerMaster();
		loadSupplyMetaData();
		loadRoleMaster();
		loadMasterHierarchyConfig();
		loadReturnTypeMaster();
		loadGroupADConfig();
		loadPurchaseMetaData();
		loadRoleLevelMap();
		loadGlobalGSTRatesMasterI();
		loadBifurcationCodes();
		loadSmartReportAttributes();
		loadGroupConfigDetails();
		loadTblReturnTypeRecordTypeMapping();
	}
		
	@Override
	public void loadSmartReportAttributes() {      
        
        LOGGER.info("loadsmartReportAttributes entering");

        List<SmartReportAttributes>  smartReportAttributes = smartReportAttributesRepository.findAll();
        LOGGER.info("smartReportAttributes size"+ smartReportAttributes.size() );
        
        Map<String, String> outwardAttributesmap = new HashMap<>();
        Map<String, String> inwardAttributesmap =new HashMap<>() ;
        List <String> mandatoryAttributesList= new ArrayList<>() ;
        List <String> mandatoryInwardAttributesList= new ArrayList<>() ;
        
        for (SmartReportAttributes reportAttributes : smartReportAttributes) {
               
               if(reportAttributes.getFileCategory().equalsIgnoreCase(Constant.OUTWARD)){
                     
                     outwardAttributesmap.put(reportAttributes.getProperty(), reportAttributes.getHeader());
                     LOGGER.info("outwardAttributesmap size"+ outwardAttributesmap.size() );
               }
               
               else if(reportAttributes.getFileCategory().equalsIgnoreCase(Constant.INWARD)){
                      
                     inwardAttributesmap.put(reportAttributes.getProperty(), reportAttributes.getHeader());
                     
               }
               
               if(reportAttributes.getMandatory().equals("Y")&& reportAttributes.getFileCategory().equalsIgnoreCase(Constant.OUTWARD)){
                     mandatoryAttributesList.add(reportAttributes.getProperty());
                     
                     
               }
               
               else if(reportAttributes.getMandatory().equals("Y")&& reportAttributes.getFileCategory().equalsIgnoreCase(Constant.INWARD)){
                     mandatoryInwardAttributesList.add(reportAttributes.getProperty());
                     
                     
               }
        }
               
               LOGGER.info("outwardAttributesmap size"+ outwardAttributesmap.size() );
               LOGGER.info("inwardAttributesmap size"+ inwardAttributesmap.size() );
               LOGGER.info("mandatoryAttributesmap size"+ mandatoryAttributesList.size() );
               LOGGER.info("mandatoryInwardAttributesList size"+ mandatoryInwardAttributesList.size() );
               
               redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
                            Constant.OUTWARDATTRIBUTE, outwardAttributesmap);
               redisTemplate.opsForHash().put( Constant.REDIS_CACHE,
                            Constant.INWARDATTRIBUTE, inwardAttributesmap);
               redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
                            Constant.MANDATORYATTRIBUTES, mandatoryAttributesList);
               
               redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
                            Constant.MANDATORYINWARDATTRIBUTES, mandatoryInwardAttributesList);
  
 }

	private void loadBifurcationCodes() {

		LOGGER.info("loadBifurcationCodes entering");

		List<TblBifurcationCodes> bifercationCode = bifercationCodeRepository.findAll();
		
		LOGGER.info("loadBifurcationCodes size"+ bifercationCode.size() );
		Map<String, TblBifurcationCodes> tableTypeMap ;
		Map<String, TblBifurcationCodes> subCategoryMap ;
		if (bifercationCode != null && !bifercationCode.isEmpty()) {
			tableTypeMap = new HashMap<>();
			subCategoryMap = new HashMap<>();
			for (TblBifurcationCodes tblBifurcationCodes : bifercationCode) {
				if (tblBifurcationCodes.getBifurcationLevel().equalsIgnoreCase(
						Constant.CATEGORY)) {
					tableTypeMap.put(tblBifurcationCodes.getReturnType().trim()+"_"+tblBifurcationCodes.getCode(),tblBifurcationCodes);
					
					LOGGER.info("tableTypeMap size"+ tableTypeMap.size() );
				} else if (tblBifurcationCodes.getBifurcationLevel().equalsIgnoreCase(
						Constant.SUB_CATEGORY)) {
					subCategoryMap.put(tblBifurcationCodes.getReturnType().trim()+"_"+tblBifurcationCodes.getCode(),tblBifurcationCodes);
					
					LOGGER.info("subCategoryMap size"+ subCategoryMap.size() );
				}
			}
			redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
					Constant.CATEGORY, tableTypeMap);
			redisTemplate.opsForHash().put( Constant.REDIS_CACHE,
					Constant.SUB_CATEGORY, subCategoryMap);
		}
		
	
		
		
	}

		public void loadGlobalGSTRatesMasterI() {

		List<GlobalGSTRatesMasterI> globalGSTRatesMasterIList = globalGSTRatesMasterIRepository.findAll();
		Map<String,Set<BigDecimal>> globalRatesMap = null;
		Map<String,GlobalGSTRatesMasterI> globalGSTRatesMasterIMap = null;
		if(globalGSTRatesMasterIList !=null  && !globalGSTRatesMasterIList.isEmpty()){
			globalGSTRatesMasterIMap = new HashMap<>();
			Set<BigDecimal> igstRateList = new HashSet<BigDecimal>();
			Set<BigDecimal> cgstRateList = new HashSet<BigDecimal>();
			Set<BigDecimal> sgstRateList = new HashSet<BigDecimal>();
			
			for(GlobalGSTRatesMasterI metaData : globalGSTRatesMasterIList){

				globalGSTRatesMasterIMap.put(metaData.getHsnsac(), metaData);
			//	redisTemplate.opsForHash().put(Constant.GLOBAL_MASTER_DETAILS,
				//		metaData.getHsnsac(), metaData);
				if(metaData.getGstIGSTRt()!=null)
					igstRateList.add(metaData.getGstIGSTRt());
				if(metaData.getGstCGSTRt()!=null)
					cgstRateList.add(metaData.getGstCGSTRt());
				if(metaData.getGstSGSTRt()!=null)
					sgstRateList.add(metaData.getGstSGSTRt());
			}
			redisTemplate.opsForHash().putAll(Constant.GLOBAL_MASTER_DETAILS, globalGSTRatesMasterIMap);
			globalRatesMap = new HashMap<String,Set<BigDecimal>>();
			globalRatesMap.put(Constant.IGST_RATE_LIST, igstRateList);
			globalRatesMap.put(Constant.CGST_RATE_LIST, cgstRateList);
			globalRatesMap.put(Constant.SGST_RATE_LIST, sgstRateList);
		}
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE, Constant.GLOBAL_RATES_MAP, globalRatesMap);
		
	}

	@SuppressWarnings("unchecked")
	public String getSpecificGlobalGSTRatesMasterI(String hsnsac) {

		String hsnFound = Constant.FALSE;
		List<GlobalGSTRatesMasterI> globalGSTRatesMasterIList = globalGSTRatesMasterIRepository.getHsnSacRecord(hsnsac);

		if(globalGSTRatesMasterIList !=null  && !globalGSTRatesMasterIList.isEmpty()){
			hsnFound = Constant.TRUE;
			for(GlobalGSTRatesMasterI metaData : globalGSTRatesMasterIList){
				redisTemplate.opsForHash().put(Constant.GLOBAL_MASTER_DETAILS,
						metaData.getHsnsac(), metaData);
			}
		}

		return hsnFound;
	}

	@Override
	public void reLoad() {
		LOGGER.info("Calling reload()");

	}

	@Override
	public void loadPurchaseMetaData() {
		List<PurchaseMetaData> purchaseMetaDataList = purchaseMetaDataRepository.findAll();
		Map<String,PurchaseMetaData> purchaseMetaDataMap = null;
		if(purchaseMetaDataList !=null  && purchaseMetaDataList.size()>0){
			purchaseMetaDataMap = new HashMap<String,PurchaseMetaData>();
			for(PurchaseMetaData purchaseMetaData:purchaseMetaDataList){
				purchaseMetaDataMap.put(purchaseMetaData.getColumnCode(), purchaseMetaData);

			}
		}
		redisTemplate.opsForHash().putAll(Constant.PURCHASE_METADATA, purchaseMetaDataMap);

	}


	public void loadGroupADConfig(){
		List<GroupAzureAdConfig> groupAzureAdConfig = groupAzureAdConfigService.findAll();

		Gson gson = new Gson();
		String outString = gson.toJson(groupAzureAdConfig);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				"GroupADConfigList", outString);
	}

	/*public void fetchGrossTurnOver() {
		Map<String, BigDecimal> map = new HashMap<String, BigDecimal>();

		List<Object[]> turnOvermap = (List<Object[]>) gSTINRepository.findGrossTurnOver();

		for (Object[] objects : turnOvermap) {

			map.put((String)objects[0], (BigDecimal)objects[2]);
		}


		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				Constant.GROSSTURNOVER_KEY, map);

	}*/

	/*	public void fetchGstinDetails(){
		Map<String,GSTIN> map = new HashMap<String,GSTIN>();

		List<GSTIN> gstinDetails = (List<GSTIN>) gSTINRepository.findAll();

		for(GSTIN gstin:gstinDetails){
			map.put(gstin.getGstinId(), gstin);
		}

		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				Constant.GSTIN_DEATILS, map);
	}*/

	/**
	 * this method will add asp gsp integeration data into redis for a gsp group code
	 */
	public void saveDataToRedis(JSONObject jsonEncryptResponse,JSONObject UserObj)
	{
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("Entering " + "saveDataToRedis");
		}
		if(jsonEncryptResponse!=null&& UserObj!=null){
			String groupId=String.valueOf(UserObj.get(Constant.GROUP_CODE));
			String api_key=String.valueOf(UserObj.get(Constant.API_KEY));
			String digigstUser=String.valueOf(UserObj.get(Constant.GSP_DIGIGST_USERNAME));

			Map<String,Map<String,String>> groupUserAuthDetails = new HashMap<>();
			Map<String,String> authDetails = new HashMap<>();
			String expires_in = String.valueOf(jsonEncryptResponse.get(Constant.EXPIRES_IN));
			String access_token = String.valueOf(jsonEncryptResponse.get(Constant.ACCESS_TOKEN));
			String refresh_token=String.valueOf(jsonEncryptResponse.get(Constant.REFRESH_TOKEN));
			authDetails.put(Constant.EXPIRES_IN, expires_in);
			authDetails.put(Constant.ACCESS_TOKEN, access_token);
			authDetails.put(Constant.REFRESH_TOKEN, refresh_token);
			authDetails.put(Constant.API_KEY, api_key);
			authDetails.put(Constant.GSP_DIGIGST_USERNAME, digigstUser);
			groupUserAuthDetails.put(groupId.toLowerCase(), authDetails);
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("Putting values: "+ Constant.GSP_DIGIGST_USERNAME +" : " +digigstUser +" : "+Constant.API_KEY +" : " +api_key);
			}
			redisTemplate.opsForHash().put(groupId.toLowerCase()+"_"+Constant.GSP_USERDETAILS,Constant.GSP_USERDETAILS,groupUserAuthDetails);
		}else{
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("No Data to saveDataToRedis");
			}
		}
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("Exiting " + "saveDataToRedis");
		}

	}


	@Override
	public void loadRoleLevelMap(){

		List<RoleAccessHierarchyMap> roleAccessHierarchyMapList =  roleAccessHierarchyMapService.findAll();
		Gson gson = new Gson();
		String outString = gson.toJson(roleAccessHierarchyMapList);
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,
				"RoleLevelMap", outString);
	}
	
	@Override
	public void loadAzureStoreDetails() {

		Map<String, Map<String, String>> azureDetailsMap = groupConfigService.getAzureStorageDetails();
		if (azureDetailsMap != null) {
			LOGGER.info("Placing the Azure Store Details in Redis " + "loadAzureStoreDetails");
			Gson gson = new Gson();
			String outString = gson.toJson(azureDetailsMap);

			redisTemplate.opsForHash().put(Constant.REDIS_CACHE, "AzureStoreDetailsMap", outString);
			LOGGER.info("Placing the Azure Store Details in Redis " + outString);
		}
	}

	public List<String> reoconReportSheets(){
		List<String> excelSheets = new ArrayList<String>();
		excelSheets.add("MIS-MATCH");
		excelSheets.add("MATCHED");
		excelSheets.add("MISSING");
		excelSheets.add("ADDITIONAL");
		excelSheets.add("MATCH-ASP");
		return excelSheets;
	}

	@Override
	public void loadReconReportResponseConsolidatedMetadata() {
		List<String> excelSheets = reoconReportSheets();
		Map<String, List<GSTR2ReconResponseConsolidatedMetadata>> metadataMap = new HashMap<>();
		for(int i=0;i<excelSheets.size();i++){
			String sheetName = excelSheets.get(i);
			LinkedList<GSTR2ReconResponseConsolidatedMetadata> metadataList = gstr2ReconResponseConsolidatedService.getMetadataBySheetName(excelSheets.get(i));
			metadataMap.put(sheetName, metadataList);
		}
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,Constant.RECON_REPORT_RESPONSE_CONSOLIDATED_METADATA, metadataMap);
	}
	@Override
	public void loadReconReportResponseConsolidatedMetadataGstr6() {
		List<String> excelSheets = reoconReportSheets();
		Map<String, List<GSTR6ReconResponseConsolidatedMetadata>> metadataMap = new HashMap<>();
		for(int i=0;i<excelSheets.size();i++){
			String sheetName = excelSheets.get(i);
			LinkedList<GSTR6ReconResponseConsolidatedMetadata> metadataList = gstr6ReconResponseConsolidatedService.getMetadataBySheetName(excelSheets.get(i));
			metadataMap.put(sheetName, metadataList);
		}
		redisTemplate.opsForHash().put(Constant.REDIS_CACHE,Constant.RECON_REPORT_RESPONSE_CONSOLIDATED_METADATA, metadataMap);
	}
	

}
