package com.ey.advisory.asp.service;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;


public interface MailService {

	/**
	 * @param user 
	 * @param gstn
	 * @param selMonth
	 * @param selYear
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	//void sendMailESign(User user, GSTIN gstn, String selMonth, String selYear) throws ClientProtocolException, IOException,Exception;

	/**
	 * @param gstin
	 * @param selMonth
	 * @param selYear
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	void sendMailProcessGstr1(String gstin, String selMonth, String selYear) throws ClientProtocolException, IOException;
	/*String sendMailTranactionId(User user ,GSTIN gstn , String selYear , String month , GSTR1SummaryDto dto) throws UnsupportedEncodingException, IOException,Exception;*/
	
	void fileGSTR1(String  toAddress , String gstin, String selMonth, String selYear) ;
	
	void fileGSTR2(String toAddress, String gstin, String selMonth, String selYear) ;
	
	void sendMailProcessGstr2(String toAddress, String gstin, String selMonth, String selYear) ;
	
	void sendOtp(String toAddress,String otp) ;
}
