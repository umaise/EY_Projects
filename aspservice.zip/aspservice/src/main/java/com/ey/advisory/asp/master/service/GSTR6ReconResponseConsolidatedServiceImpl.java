package com.ey.advisory.asp.master.service;

import java.util.LinkedList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.GSTR6ReconResponseConsolidatedMetadata;
import com.ey.advisory.asp.master.repository.GSTR6ReconResponseConsolidatedRepository;

@Service
public class GSTR6ReconResponseConsolidatedServiceImpl implements GSTR6ReconResponseConsolidatedService{
	protected EntityManager entityManager;
    public EntityManager getEntityManager() {
        return entityManager;
    }
    
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Autowired
    private GSTR6ReconResponseConsolidatedRepository gstr6ReconResponseAdditionalRepository;
	@Override
	public LinkedList<GSTR6ReconResponseConsolidatedMetadata> getMetadataBySheetName(String sheetName) {
		return gstr6ReconResponseAdditionalRepository.getMetadataBySheetName(sheetName);
	}
}
