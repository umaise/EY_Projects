package com.ey.advisory.asp.master.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.master.domain.ForgotPassword;
import com.ey.advisory.asp.master.repository.ForgotPasswordRepository;
@Service
public class ForgotPasswordServiceImpl implements ForgotPasswordService{
	
	private static final Logger LOGGER = Logger.getLogger(ForgotPasswordServiceImpl.class);
	
	protected EntityManager entityManager;
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
	
	@Autowired
	private ForgotPasswordRepository forgotPasswordRepository;
	
	@Autowired
	UserService userService;
	
	@Override
	public ForgotPassword findByUserName(String userName) {
		return forgotPasswordRepository.findByUserName(userName);
	}
	
	@Override
	@Transactional
	public String saveForgotPassword(ForgotPassword forgotPassword) {
		String status = "";
		try {
			forgotPasswordRepository.save(forgotPassword);
			status = Constant.SUCCESS;
		} catch (Exception e) {
			status = Constant.UPDATE_PASSWORD_FAILURE;
			LOGGER.error(e);
		}
		return status;
		
	}
	@Override
	public ForgotPassword getLatestDetails(String userName) {
		return forgotPasswordRepository.getLatestDetails(userName);
	}
	

}
