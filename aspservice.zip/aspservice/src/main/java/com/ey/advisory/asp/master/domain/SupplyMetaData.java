package com.ey.advisory.asp.master.domain;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name = "tblSupplyMetadata", schema=Constant.MASTER_SCHEMA)
public class SupplyMetaData implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Long Id;
	private String columnName;
	private Integer columnOrderNo;
	private String columnCode;
	private String dataType;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SupplyID")
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	
	@Column(name = "ColumnName")
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	
	@Column(name = "ColumnOrderNo")
	public void setColumnOrderNo(Integer columnOrderNo) {
		this.columnOrderNo = columnOrderNo;
	}
	public void setColumnCode(String columnCode) {
		this.columnCode = columnCode;
	}
	
	@Column(name = "ColumnCode")
	public String getColumnCode() {
		return columnCode;
	}
	public Integer getColumnOrderNo() {
		return columnOrderNo;
	}

	
	@Column(name = "DataType")
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	
	
}
