/**
 * 
 */
package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.ey.advisory.asp.common.Constant;

/**
 * @author Nitesh.Tripathi
 *
 */

@Entity
@Table(name = "tblRoleAccessHierarchyMap", schema = Constant.MASTER_SCHEMA)
public class RoleAccessHierarchyMap implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MapID")
	private Long mapID;

	@Column(name = "RoleID")
	private Long roleID;

	@Column(name = "HierarchyConfigID")
	private Long hierarchyConfigID;

	@ManyToOne(fetch = FetchType.EAGER)
	@Fetch(FetchMode.JOIN)
	@JoinColumn(name = "hierarchyConfigID", referencedColumnName = "hierarchyConfigID", nullable = false)
	private MasterHierarchyConfig masterHierarchyConfig;

	/**
	 * @return the mapID
	 */
	public Long getMapID() {
		return mapID;
	}

	/**
	 * @param mapID
	 *            the mapID to set
	 */
	public void setMapID(Long mapID) {
		this.mapID = mapID;
	}

	/**
	 * @return the roleID
	 */
	public Long getRoleID() {
		return roleID;
	}

	/**
	 * @param roleID
	 *            the roleID to set
	 */
	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}

	/**
	 * @return the hierarchyConfigID
	 */
	public Long getHierarchyConfigID() {
		return hierarchyConfigID;
	}

	/**
	 * @param hierarchyConfigID
	 *            the hierarchyConfigID to set
	 */
	public void setHierarchyConfigID(Long hierarchyConfigID) {
		this.hierarchyConfigID = hierarchyConfigID;
	}

	public MasterHierarchyConfig getMasterHierarchyConfig() {
		return masterHierarchyConfig;
	}

	public void setMasterHierarchyConfig(MasterHierarchyConfig masterHierarchyConfig) {
		this.masterHierarchyConfig = masterHierarchyConfig;
	}

}
