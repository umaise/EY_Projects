package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.TblBifurcationCodes;


	
	@Repository
	@Transactional
	public interface TblBifercationCodeRepository extends JpaRepository<TblBifurcationCodes, Long>{
		@Override
		public List<TblBifurcationCodes> findAll();
		

	}


