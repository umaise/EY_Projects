package com.ey.advisory.asp.master.domain;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblFunction", schema="master")
public class AppFunction implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Long appFunctionId;
	private String appFunction;
	private String appFunctionDesc;
	private String appModule;
	private String uri;
	private Long menuLevel;
	private String appFuncTagId;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "AppFunc_ID")
	public Long getAppFunctionId() {
		return appFunctionId;
	}
	
	public void setAppFunctionId(Long appFunctionId) {
		this.appFunctionId = appFunctionId;
	}
	
	@Column(name = "App_Func")
	public String getAppFunction() {
		return appFunction;
	}
	
	public void setAppFunction(String appFunction) {
		this.appFunction = appFunction;
	}
	
	@Column(name = "AppFunc_Desc")
	public String getAppFunctionDesc() {
		return appFunctionDesc;
	}
	
	public void setAppFunctionDesc(String appFunctionDesc) {
		this.appFunctionDesc = appFunctionDesc;
	}
	
	@Column(name = "App_Module")
	public String getAppModule() {
		return appModule;
	}

	public void setAppModule(String appModule) {
		this.appModule = appModule;
	}

	@Column(name = "URI")
	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	@Column(name = "Menu_Level")
	public Long getMenuLevel() {
		return menuLevel;
	}

	public void setMenuLevel(Long menuLevel) {
		this.menuLevel = menuLevel;
	}

	@Column(name = "AppFuncTagId")
	public String getAppFuncTagId() {
		return appFuncTagId;
	}

	public void setAppFuncTagId(String appFuncTagId) {
		this.appFuncTagId = appFuncTagId;
	}
	
	
	
	
	
	
	
	
	

}
