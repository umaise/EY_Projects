package com.ey.advisory.asp.master.domain;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;



/**
 * @author Raghavan.Venket
 *
 */

public class HsnSacMasterDetailsDto  implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer hSNSACId;
	private String itemCode;
	private String itemDescription;
	private Character itemType;
	
	private String hSNSACCode;
	private Integer slabID;
	private Integer minValue;
	private Integer maxValue;
	private String rangeFormula;
	
	private Integer tblIGSTHSNID;
	private BigDecimal iGSTRt;
	private BigDecimal igstcessRt;
	private Character igstisActive;
	private Date igstvalidUntil;
	private Integer igsthSNSACId;
	
	private Integer tblSGSTHSNID;
	private BigDecimal sGSTRt;
	private BigDecimal cGSTRt;
	private BigDecimal cessRt;
	private Character sGSTisActive;
	private Date sGSTvalidUntil;
	private Integer sGSThSNSACId;
	
	private String statecode;
	
	
	public Integer getSlabID() {
		return slabID;
	}
	public void setSlabID(Integer slabID) {
		this.slabID = slabID;
	}
	public Integer getMinValue() {
		return minValue;
	}
	public void setMinValue(Integer minValue) {
		this.minValue = minValue;
	}
	public Integer getMaxValue() {
		return maxValue;
	}
	public void setMaxValue(Integer maxValue) {
		this.maxValue = maxValue;
	}
	public String getRangeFormula() {
		return rangeFormula;
	}
	public void setRangeFormula(String rangeFormula) {
		this.rangeFormula = rangeFormula;
	}
	public Integer getTblIGSTHSNID() {
		return tblIGSTHSNID;
	}
	public void setTblIGSTHSNID(Integer tblIGSTHSNID) {
		this.tblIGSTHSNID = tblIGSTHSNID;
	}
	public BigDecimal getiGSTRt() {
		return iGSTRt;
	}
	public void setiGSTRt(BigDecimal iGSTRt) {
		this.iGSTRt = iGSTRt;
	}
	public BigDecimal getIgstcessRt() {
		return igstcessRt;
	}
	public void setIgstcessRt(BigDecimal igstcessRt) {
		this.igstcessRt = igstcessRt;
	}
	public Character getIgstisActive() {
		return igstisActive;
	}
	public void setIgstisActive(Character igstisActive) {
		this.igstisActive = igstisActive;
	}
	public Date getIgstvalidUntil() {
		return igstvalidUntil;
	}
	public void setIgstvalidUntil(Date igstvalidUntil) {
		this.igstvalidUntil = igstvalidUntil;
	}
	
	public Integer getIgsthSNSACId() {
		return igsthSNSACId;
	}
	public void setIgsthSNSACId(Integer igsthSNSACId) {
		this.igsthSNSACId = igsthSNSACId;
	}
	public Integer getTblSGSTHSNID() {
		return tblSGSTHSNID;
	}
	public void setTblSGSTHSNID(Integer tblSGSTHSNID) {
		this.tblSGSTHSNID = tblSGSTHSNID;
	}
	public BigDecimal getsGSTRt() {
		return sGSTRt;
	}
	public void setsGSTRt(BigDecimal sGSTRt) {
		this.sGSTRt = sGSTRt;
	}
	public BigDecimal getcGSTRt() {
		return cGSTRt;
	}
	public void setcGSTRt(BigDecimal cGSTRt) {
		this.cGSTRt = cGSTRt;
	}
	public BigDecimal getCessRt() {
		return cessRt;
	}
	public void setCessRt(BigDecimal cessRt) {
		this.cessRt = cessRt;
	}
	public Character getIsActive() {
		return sGSTisActive;
	}
	public void setIsActive(Character isActive) {
		this.sGSTisActive = isActive;
	}
	public Date getValidUntil() {
		return sGSTvalidUntil;
	}
	public void setValidUntil(Date validUntil) {
		this.sGSTvalidUntil = validUntil;
	}
	
	public Integer getsGSThSNSACId() {
		return sGSThSNSACId;
	}
	public void setsGSThSNSACId(Integer sGSThSNSACId) {
		this.sGSThSNSACId = sGSThSNSACId;
	}
	
	
	public String getStatecode() {
		return statecode;
	}
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}
	public Integer gethSNSACId() {
		return hSNSACId;
	}
	public void sethSNSACId(Integer hSNSACId) {
		this.hSNSACId = hSNSACId;
	}
	
	
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	
	
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	

	public Character getItemType() {
		return itemType;
	}
	public void setItemType(Character itemType) {
		this.itemType = itemType;
	}
	

	public String gethSNSACCode() {
		return hSNSACCode;
	}
	public void sethSNSACCode(String hSNSACCode) {
		this.hSNSACCode = hSNSACCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	

		

}
