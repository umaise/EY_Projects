package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.QuartzJobDetails;
@Repository
@Transactional(readOnly = true)
public interface QuartzJobDetailsRepository extends JpaRepository<QuartzJobDetails, String>{
	
	@Query("from QuartzJobDetails where quartzJobDetailsPK.jobGroup=:jobGroup")
	public List<QuartzJobDetails> findByJobGroup(@Param("jobGroup")String jobGroup);
	
	@Query("from QuartzJobDetails jobDetails where jobDetails.quartzJobDetailsPK.jobGroup IN :jobGroup")
	public List<QuartzJobDetails> findByJobGroupIn(@Param("jobGroup") List<String> jobGroup);
	
	@Modifying
	@Query(" select qtl from QuartzJobDetails qtl  where quartzJobDetailsPK.jobGroup"
			+ " in(select distinct quartzJobDetailsPK.jobGroup from QuartzJobDetails) " )
	
	public List<QuartzJobDetails> fetchDetails();
}
