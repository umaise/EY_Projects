package com.ey.advisory.asp.master.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.GroupConfig;
import com.ey.advisory.asp.master.repository.GroupConfigRepository;
import com.ey.advisory.asp.master.repository.GroupRepository;

@Service("groupService")
public class GroupServiceImpl implements GroupService{
	
	protected EntityManager entityManager;
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Autowired
    private GroupRepository repository;
    
    @Autowired
    private GroupConfigRepository groupConfigRepository;
	
    @Override
	public List<Group> getAllGroups() {
		return repository.findAll();
	}
    
    @Override
	public Map<String, Group> getAllGroupsByGroupCodeMap() {
		List<Group> group = repository.findAll();
		Map<String, Group> groupMap =new HashMap<>();
		if(group !=null && !group.isEmpty()){
			for(Group grp: group){
				groupMap.put(grp.getGroupCode(), grp);
			}
			return groupMap;
		}else
		 return null;
	}

	/*@Override
	public List<GroupConfig> getGroupvaluesByReportType(String grpCode, String configCode) {
		List<GroupConfig> group = groupConfigRepository.getGroupvaluesByReportType(grpCode,configCode);
		return group;
	}
	*/
	
    
	@Override
	public List<GroupConfig> getGroupConfigvalues(String groupCode) {
		List<GroupConfig> group = groupConfigRepository.getGroupConfigvalues(groupCode);
		return group;
	}

	@Override
	public List<String> getAllActiveGroups() {
		return repository.findByIsActiveTrue();
	}

	@Override
	public List<GroupConfig> getGroupvaluesByReportType(String grpCode, String configCode) {
		List<GroupConfig> group = groupConfigRepository.getGroupvaluesByReportType(grpCode,configCode);
		return group;
	}
	
	@Override
	public List<GroupConfig> findAllGroupConfig() {
		List<GroupConfig> groupConfigList = groupConfigRepository.findAllGroupConfig();
		return groupConfigList;
	}

	@Override
	public Long count(){
		return repository.count();
	}
	
	
	public List<Group> getAllActiveGroupsByPagination(int pagenumber, int pageSize) {
		Query query= entityManager.createQuery(
	            "from Group order by groupName asc");
		query.setFirstResult(pagenumber*pageSize);
		query.setMaxResults(pageSize);
	    List<Group>  listGroups = query.getResultList();
		return listGroups;
	}

	@Override
	public List<Group> getGroupCode(String searchText) {
		return repository.getGroupCode(searchText);
	}
	
	@Override
	public Long getGroupCount(String searchText){
		return repository.getGroupCount(searchText);
	}
	
	@Override
	public Group findGroupByGroupdId(Long groupId){
		
		return repository.findByGroupId(groupId);
	}
	
	
}
