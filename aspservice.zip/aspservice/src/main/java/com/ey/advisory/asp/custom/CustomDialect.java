package com.ey.advisory.asp.custom;

import java.sql.Types;

import org.hibernate.dialect.SQLServerDialect;
import org.hibernate.type.StandardBasicTypes;

public class CustomDialect extends SQLServerDialect{

	public CustomDialect(){
		super();
		this.registerHibernateType(Types.NVARCHAR, StandardBasicTypes.STRING.getName());
		 this.registerColumnType(Types.NVARCHAR, StandardBasicTypes.STRING.getName());
		 this.registerHibernateType(Types.LONGNVARCHAR, StandardBasicTypes.STRING.getName());
		 this.registerColumnType(Types.LONGNVARCHAR, StandardBasicTypes.STRING.getName());
	}
}
