package com.ey.advisory.asp.master.service;

import java.util.List;


public interface SalesFileStatusService {
	
	boolean updateFilejobStatus(String key);

}
