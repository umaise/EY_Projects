package com.ey.advisory.asp.master.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.common.Utility;
import com.ey.advisory.asp.domain.UploadFileStatus;
import com.ey.advisory.asp.dto.UserSearchDto;
import com.ey.advisory.asp.master.domain.AppRoleFunction;
import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.domain.SummaryFileLoadMaster;
import com.ey.advisory.asp.master.domain.User;
import com.ey.advisory.asp.master.domain.UserGSTNRoleMaping;
import com.ey.advisory.asp.master.repository.IReturnPeriodRepository;
import com.ey.advisory.asp.master.repository.RoleRepository;
import com.ey.advisory.asp.master.repository.SummaryFileUploadRepository;
import com.ey.advisory.asp.master.repository.UserGSTNRoleMapingRepository;
import com.ey.advisory.asp.master.repository.UserRepository;


@Service("userService")
public class UserServiceImpl implements UserService {
	
	private static final Logger LOGGER = Logger.getLogger(UserServiceImpl.class);
	protected EntityManager entityManager;
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
	 
	@Autowired
	private UserRepository repository;
	
	@Autowired
	private UserGSTNRoleMapingRepository userGSTNRoleMapingRepository;
	
	@Autowired
	private AppRoleFunctionService appRoleFunctionService;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private IReturnPeriodRepository iReturnPeriodRepository;
	
	@Autowired
	SummaryFileUploadRepository summaryFileRepository;
	
	@Override
	public User findByUserName(String userName) {
		return repository.findByUserName(userName);
	}
	
	@Override
	public User updateUser(User user,boolean isGroupEdited) {
		User existingUser = repository.findByUserId(user.getUserId());
		existingUser = setUserObj(existingUser,user);

		String[] groupTempArray = user.getGroupId()!=null?user.getGroupId().split(","):new String[0];
		for(String groupTemp:groupTempArray){
			if(groupTemp != null && groupTemp.trim().length()>0){
				Long groupId=groupTemp!=null?Long.parseLong(groupTemp):0;
				UserGSTNRoleMaping userGSTNRoleMaping=new UserGSTNRoleMaping();
				userGSTNRoleMaping.setCreatedBy(user.getUserName());
				userGSTNRoleMaping=	setUserGSTNRoleMapingObj(userGSTNRoleMaping,groupId,user.getRoleId(),user);
				userGSTNRoleMapingRepository.save(userGSTNRoleMaping);
			}
		}
		
		return repository.save(existingUser);
	}

	public User setUserObj(User existingUser,User newUser) {
		existingUser.setFirstName(newUser.getFirstName()!=null?newUser.getFirstName():"");
		existingUser.setMiddleName(newUser.getMiddleName()!=null?newUser.getMiddleName():"");
		existingUser.setLastName(newUser.getLastName()!=null?newUser.getLastName():"");
		existingUser.setUserName(newUser.getUserName()!=null?newUser.getUserName():"");
		existingUser.setPan(newUser.getPan()!=null?newUser.getPan():"");
		existingUser.setPrefix(newUser.getPrefix()!=null?newUser.getPrefix():"");
		existingUser.setGender(newUser.getGender()!=null?newUser.getGender():"");
		existingUser.setGpnNumber(newUser.getGpnNumber()!=null?newUser.getGpnNumber():"");
		existingUser.setGstUserName(newUser.getGstUserName()!=null?newUser.getGstUserName():"");
		existingUser.setEmailId(newUser.getEmailId()!=null?newUser.getEmailId():"");
		existingUser.setEngagementId(newUser.getEngagementId()!=null?newUser.getEngagementId():"");
		existingUser.setPassword(newUser.getPassword()!=null?newUser.getPassword():"");
		existingUser.setOfficeNo(newUser.getOfficeNo()!=null?newUser.getOfficeNo():"");
		existingUser.setMobileNo(newUser.getMobileNo()!=null?newUser.getMobileNo():"");
		existingUser.setIsActive(newUser.getIsActive());
		existingUser.setForcePasswordChange(true);
		existingUser.setIsApproved(true);
		//existingUser.setCategory(newUser.getCategory()!=null?newUser.getCategory():"");
		
		/*existingUser.setCreatedBy(newUser.getUserName()!=null?newUser.getUserName():"");
		existingUser.setCreatedDate(newUser.getCreatedDate()!=null?newUser.getCreatedDate():new Date());
		existingUser.setAccountExpired(false);
		existingUser.setLocked(false);
		existingUser.setPwdCreationDate(new Date());
		existingUser.setPwdExpired(false);
		existingUser.setForcePasswordChange(false);
		existingUser.setIsApproved(true);
		existingUser.setLastLogin(new Date());
		existingUser.setLastModifiedBy(newUser.getUserName()!=null?newUser.getUserName():"");
		existingUser.setLastModifieddDate(new Date());
		existingUser.setTypeOfUser(newUser.getTypeOfUser()!=null?newUser.getTypeOfUser():"Admin");*/
		//existingUser.setca
		//existingUser.setAccountExpired(newUser.geta);
		/*,[UserName],[Pwd],[Prefix],[FirstName],[MiddleName],[LastName],
		 * [Gender],[E_MailID],[PAN],[IsActive],[AccountExpired],[AccountLocked],[ForcePasswordChange],
		 * [LastLoginDate],[NoOfFailedAttempts],[PasswordCreationDate],[PasswordExpired],[CreatedBy]
		 * ,[CreatedDate],[UpdatedBy],[UpdatedDate],[GPNNo],[EngagementId],[TypOfUser],[GSTUserName],[MobileNo],[OfficeNo],[IsApproved],[CategoryID]
		 * */
		
		return existingUser;
	}
	
	@Override
	public List<Object[]> getUserGSTNRoles(Long userId){
		Query query = getEntityManager().createNativeQuery("exec  master.usp_GetGSTINsForUserID ? ");
		query.setParameter(1, userId);
		List<Object[]> resultList= query.getResultList();
       return resultList;
		
	}
	
    /*added by ashwini*/
	@Override
	public boolean isPasswordMatching(String userName,String password) {
		boolean isEqual = false;
		try {

			if (StringUtils.isNotBlank(password)
					&& StringUtils.isNotBlank(userName)) {

				User user = findByUserName(userName);
				if (null != user) {
					if (user.getPassword().equals(com.ey.advisory.asp.util.UtilitySHA.shaHex(password, userName))) {
						isEqual = true;
					}
				}
			}
		} catch (Exception ex) {
			LOGGER.error(ex);
		}
		return isEqual;
	}

	@Override
	public User findByEmailId(String emailId) {
		return repository.findByEmailId(emailId);
	}

	@Override
	public Map<String,Map<String,List<String>>> getUserGroupData(long userId) {
		Query query = getEntityManager().createNativeQuery("exec  dbo.proc_userGroupDetails ? ");
		query.setParameter(1, userId);
	
		List<Object[]> resultList= query.getResultList();
		if(resultList!=null && !resultList.isEmpty())
			return getGroupMap(resultList);
				
		return null;
	
	}
	
	private Map<String,Map<String,List<String>>> getGroupMap(List<Object[]> resultList)
	{
		Map<String,Map<String,List<String>>> userGroupMap=new HashMap<>();
		Map<String,List<String>> entityMap;
		List<String> gstinList;
		
		for (Object[] items : resultList) {
			String group=items[0].toString();
			String entity=items[1].toString();
			String gstin=items[2].toString();
			if(!userGroupMap.containsKey(group))
			{
				gstinList=new ArrayList<>();
				gstinList.add(gstin);
				
				entityMap=new HashMap<>();
				entityMap.put(entity, gstinList);
			
				userGroupMap.put(group, entityMap);
				gstinList=null;	entityMap=null;
			}
			else
			{
				entityMap=userGroupMap.get(group);
				if(!entityMap.containsKey(entity))
				{
					gstinList=new ArrayList<>();
					gstinList.add(gstin);
					
					entityMap.put(entity, gstinList);
					gstinList=null;
				}
				else
				{
					gstinList=entityMap.get(entity);
					gstinList.add(gstin);
				}
			}
		}
		return userGroupMap;
	}

	@SuppressWarnings("unchecked")
	public String insertFileStatus(UploadFileStatus fileStatus) {
		
		String msg;
		Query query = getEntityManager().createNativeQuery("exec dbo.insertFileStatus ?,?,?,?,?,?,?,?,?");
		query.setParameter(1,fileStatus.getUserId());
		query.setParameter(2,fileStatus.getGroupName());
		query.setParameter(3, fileStatus.getfName());
		query.setParameter(4,fileStatus.getFileType());
		query.setParameter(5,fileStatus.getMapId());
		query.setParameter(6, fileStatus.getGstin());
		query.setParameter(7, fileStatus.getFilePath());
		query.setParameter(8, fileStatus.getFileData());
		query.setParameter(9, fileStatus.getFileHash());
			
		List<BigDecimal> resultList= query.getResultList();
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug(" resultList for input:- "+fileStatus);
			int i = 0;
			for(BigDecimal bigDEc:resultList){
				LOGGER.debug("Output"+(i++)+" :- "+bigDEc);
			}
		}
		msg = String.valueOf(resultList.get(0));
		return msg;
	}

	@Override
	@Transactional
	public User saveUser(User user) {
		//user.setPassword("");
		user.setCreatedBy(user.getUserName());
		user.setCreatedDate(new Date());
		user.setAccountExpired(false);
		user.setLocked(false);
		user.setPwdCreationDate(new Date());
		user.setPwdExpired(false);
		user.setForcePasswordChange(false);
		user.setIsApproved(true);
		repository.saveAndFlush(user);
		
		String[] groupTempArray = user.getGroupId()!=null?user.getGroupId().split(","):new String[0];
		for(String groupTemp:groupTempArray){
			if(groupTemp != null && groupTemp.trim().length()>0){
				Long groupId=groupTemp!=null?Long.parseLong(groupTemp):0;
				UserGSTNRoleMaping userGSTNRoleMaping=new UserGSTNRoleMaping();
				userGSTNRoleMaping.setCreatedBy(user.getUserName());
				userGSTNRoleMaping=	setUserGSTNRoleMapingObj(userGSTNRoleMaping,groupId,user.getRoleId(),user);
				userGSTNRoleMapingRepository.save(userGSTNRoleMaping);
			}
		}
	
		return user;
	}
	
	@Override
	public List<User> loadAllUsers() {
		return repository.findAll();
	}
	
	@Override
	public String findByUserId(Long userId) {
		Query query = getEntityManager().createNativeQuery("exec  master.usp_GetUserMappingById ?"); 
		query.setParameter(1, userId);
		return String.valueOf(query.getSingleResult());
	}

	@Override
	public String getAllUsers(UserSearchDto userSearchDto) {
		Query query = getEntityManager().createNativeQuery("exec  dbo.usp_GetUserRoleMappingDetails ?, ?, ?, ?, ?, ?"); 
		query.setParameter(1, userSearchDto.getPage());
		query.setParameter(2, userSearchDto.getRows());
		query.setParameter(3, userSearchDto.getUserName());
		query.setParameter(4, userSearchDto.getFirstName());
		query.setParameter(5, userSearchDto.getLastName());
		query.setParameter(6, userSearchDto.getGroup());
		List<String> userList = query.getResultList();
		StringBuilder stringBuilder = new StringBuilder();
		for (String userJson : userList) {
			stringBuilder.append(userJson);
		}
		return String.valueOf(stringBuilder);
	}

	@Override
	public String getUserData(long userId) {
		Query query = getEntityManager().createNativeQuery("exec master.usp_GetUser ? ");
		query.setParameter(1, userId);
		return 	String.valueOf(query.getSingleResult()); 
	}

	public List<UserGSTNRoleMaping> findRolesByUserId(User userId) {
		List<UserGSTNRoleMaping> userGSTNRoleMaping = userGSTNRoleMapingRepository.findByUserId(userId.getUserId());
		return userGSTNRoleMaping;
	}
	@Override
	public List<AppRoleFunction> findAppRoleFunctionByRole(Role roleId){
		
		return appRoleFunctionService.findByRoleId(roleId);
		
	}
	
	@Override
	public User approveUser(User user) {
		User existingUser = repository.findByUserId(user.getUserId());
		existingUser.setIsApproved(user.getIsApproved());
		List<UserGSTNRoleMaping> mappings = userGSTNRoleMapingRepository.findByUserId(user.getUserId());
		userGSTNRoleMapingRepository.delete(mappings);
		UserGSTNRoleMaping userGSTNRoleMaping;
		for(int i=0;i<user.getUserGSTNRoleMapings().size();i++){
			userGSTNRoleMaping = user.getUserGSTNRoleMapings().get(i);
			userGSTNRoleMaping.setUserId(existingUser.getUserId());
			userGSTNRoleMapingRepository.save(userGSTNRoleMaping);
		}
		return repository.save(existingUser);
		
	}

	@Override
	public User activateUser(User user) {
		User existingUser = repository.findByUserId(user.getUserId());
		existingUser.setIsActive(user.getIsActive());
		return repository.save(existingUser);
	}
	
	@Override
	public Map<User, List<Role>> getAssociatedRoles(User userId) {
		List<UserGSTNRoleMaping> userGSTNRoleMaping = userGSTNRoleMapingRepository.findByUserId(userId.getUserId());
			
		List<Role> roleList;
		Map<User,List<Role>> userRoleMap = new HashMap<>();
		for (UserGSTNRoleMaping userGSTNRoleMaping2 : userGSTNRoleMaping) {
			roleList = new ArrayList<>();
			roleList.add(userGSTNRoleMaping2.getRoleId());
			Long parentId= new Long("0");
			Role role = userGSTNRoleMaping2.getRoleId();
			List<Role> secLvlRoles = new ArrayList<>();
			if(null != role) {
				while (!(role.getParentId().equals(parentId))) {
					if (!(role.equals(""))) {
						secLvlRoles = roleRepository.getRoleById(role.getRoleId());

					}
					roleList.add(role);
				}
			}
		}
		
		return userRoleMap;
	}

	@Override
	public User getUserByName(String userName) {
		Query query = getEntityManager().createQuery("from User where userName =:userName");
         query.setParameter("userName", userName);
         User  user=null;
         List<User> userList = query.getResultList();
         if(userList!=null){
        	user= userList.get(0);
         }
		return user;
	}
	
	@Override
	public String getCurrentPeriod(){
		String taxPeriod;
		ReturnPeriod returnPeriod= iReturnPeriodRepository.findByIsCurrentPeriod(true);
		Calendar cal = Calendar.getInstance();
		cal.setTime(returnPeriod.getStartDt());
		int month = cal.get(Calendar.MONTH)+1;
		int year = cal.get(Calendar.YEAR);
		String monthTwoDigits=(month)<10 ? "0"+String.valueOf(month): String.valueOf(month);
		taxPeriod= monthTwoDigits + String.valueOf(year);
		return taxPeriod;
	}
	
	private UserGSTNRoleMaping setUserGSTNRoleMapingObj(UserGSTNRoleMaping userGSTNRoleMaping, Long groupId,Long roleId, User user){
		String createdBy=userGSTNRoleMaping.getCreatedBy()!=null?userGSTNRoleMaping.getCreatedBy():null;
		userGSTNRoleMaping.setCreatedBy(createdBy);
		Date userCreatedDate=new Date();
		try{
			 userCreatedDate=user.getCreatedDate();
		}catch(Exception e){
			if(LOGGER.isDebugEnabled())
			LOGGER.debug("User creation date in db is empty",e);
		}
		userGSTNRoleMaping.setCreatedDate(new java.sql.Date(userCreatedDate!=null?userCreatedDate.getTime():new Date().getTime()));
		Group group= new Group();
		group.setGroupId(groupId);
		userGSTNRoleMaping.setGroupId(group);
		Role role= new Role();
		role.setRoleId(user.getRoleId());
		userGSTNRoleMaping.setRoleId(role);
		userGSTNRoleMaping.setUpdatedBy(userGSTNRoleMaping.getUpdatedBy()!=null?userGSTNRoleMaping.getUpdatedBy():null);
		userGSTNRoleMaping.setUpdatedDate(new java.sql.Date(userCreatedDate!=null?userCreatedDate.getTime():new Date().getTime()));
		userGSTNRoleMaping.setUserId(user.getUserId());
		return userGSTNRoleMaping;
	}
	
	@Override
	public String checkExistingFile(List<String> fileName) {
		String Param= Utility.toString(fileName);
		Query query = getEntityManager().createNativeQuery("select Distinct FName from etl.tblFileUpload where fname in ( ? )");
		query.setParameter(1, Param);
         List<String> nameList;
         nameList=query.getResultList();
         if(!nameList.isEmpty()){
        	 return "File(s) "+ nameList.toString() +" Exists in Database";
         }
		return "Doesnt Exists";
	}
	
	@Override
	@Transactional
	public User saveOnBoardUser(User user) {
		//user.setPassword(com.ey.advisory.asp.util.UtilitySHA.shaHex(user.getPassword(),user.getUserName()));
		user.setCreatedBy(user.getUserName());
		user.setCreatedDate(new Date());
		user.setAccountExpired(false);
		user.setLocked(false);
		user.setPwdCreationDate(new Date());
		user.setPwdExpired(false);
		user.setForcePasswordChange(false);
		user.setIsApproved(true);
		user.setIsActive(Boolean.TRUE);
		return repository.saveAndFlush(user);
	}
	
	@Override
	@Transactional
	public UserGSTNRoleMaping saveUserGroupRoleMapping(UserGSTNRoleMaping userGSTNRoleMaping) {
		return userGSTNRoleMapingRepository.save(userGSTNRoleMaping);
	}

	@Override
	public int insertFileStatusSummary(UploadFileStatus fileStatus) {
		SummaryFileLoadMaster fileData = new SummaryFileLoadMaster();
		fileData.setFileName(fileStatus.getfName());
		fileData.setFilePath(fileStatus.getFilePath());
		fileData.setContent(fileStatus.getFileData());
		fileData.setFileType(fileStatus.getFileType());
		fileData.setIsDuplicate('N');
		fileData.setIsDeleted('N');
		fileData.setFileHash(fileStatus.getFileHash());
		fileData.setStatus(Constant.UPLOADED_STATUS);
		fileData.setEyGroupCode(fileStatus.getGroupName());
		fileData.setCreatedBy(fileStatus.getUpdatedBy());
		fileData.setUpdatedBy(fileStatus.getUpdatedBy());
		SummaryFileLoadMaster filesummary = null;
		
		try {
			filesummary = summaryFileRepository.saveAndFlush(fileData);
		} catch (Exception e) {
			LOGGER.error("ERROR : Saving the summary into Master File Upload.",e);
		}
		
		return filesummary != null ? filesummary.getSummaryFileId() : 0;
	} 
	
	@Override
	public Map<String, Integer> getUserNameMap() {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering method getUserNameMap() in UserServiceImpl");
		}
		try
		{
			Map<String,Integer> userNameMap=null;
			List<Object[]> userNameList=repository.getUsernames();
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("UserNameList"+userNameList);
			}
			
			if(userNameList!=null && !userNameList.isEmpty())
			{
				userNameMap=new HashMap<>();
				for (Object[] arr : userNameList) {
					userNameMap.put(arr[0].toString(), Integer.valueOf(arr[1].toString()));
				}
			}
			return userNameMap;
		}catch(Exception e)
		{
			LOGGER.error("Error: ",e);
			return null;
		}
	} 
	
	
	public List<UserGSTNRoleMaping> findRolesByUserId(Long userId) {
		List<UserGSTNRoleMaping> userGSTNRoleMaping = userGSTNRoleMapingRepository.findByUserId(userId);
		return userGSTNRoleMaping;
	}

	@Override
	public List<User> findByUserIdList(List<Long> userIdList) {
		List<User>  userList = null;
		try{
		 userList = repository.findByUserIdIn(userIdList);
		}catch(Exception e){
			LOGGER.error("findByUserIdList Error: ",e);
		}
		return userList;
	}
	
	@Override
	public void deleteRoleMapping(List<UserGSTNRoleMaping> userRoleList) {
		for(UserGSTNRoleMaping userRole: userRoleList){
			userGSTNRoleMapingRepository.delete(userRole);		
		}
	}

	@Override
	public void deleteUsers(List<UserGSTNRoleMaping> userRoleList) {
		for(UserGSTNRoleMaping userRole: userRoleList){
			repository.delete(userRole.getUserId());		
		}
	}
	
	@Override
	public Map<Long, String> findEmailByUserIdList(List<Long> userIdList) {
		// TODO Auto-generated method stub
		Map<Long, String> userIdMailMap = new HashMap<Long,String>();
		List<User> userList = findByUserIdList(userIdList);
		for(User user: userList){
			userIdMailMap.put(user.getUserId(),user.getEmailId());
		}
		return userIdMailMap;
	}
	
	@Override
	@Transactional
	public User saveUserDetail(User user,  String groupId) {
		
		//save the user details in GSTUserLogin
		repository.saveAndFlush(user);
		
		// save the user role mappings tables
		UserGSTNRoleMaping userGSTNRoleMaping = new UserGSTNRoleMaping();
		userGSTNRoleMaping.setCreatedBy(user.getCreatedBy());
		userGSTNRoleMaping=	setUserGSTNRoleMapingObj(userGSTNRoleMaping,Long.valueOf(groupId),user.getRoleId(),user);
		userGSTNRoleMapingRepository.save(userGSTNRoleMaping);
	
		return user;
	}

	@Override
	public int updateUserDetail(String emailId, String mobileNo, String userId,Boolean isActive) {
		
		return repository.updateUserDetail(emailId, mobileNo, Long.valueOf(userId),isActive);
		
	}
	
	
	@Override
	public List<User> findByUserNameNoEqualsAndEmailIdEquals(String username,String emailId) {
		return repository.findByUserNameNotAndEmailId(username,emailId);
	}

}