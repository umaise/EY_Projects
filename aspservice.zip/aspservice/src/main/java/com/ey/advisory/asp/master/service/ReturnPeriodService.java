package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.ReturnMasterDto;
import com.ey.advisory.asp.master.domain.ReturnPeriod;

public interface ReturnPeriodService
{
	public ReturnPeriod getReturnPeriod();
	public List<ReturnMasterDto> getReturnType(String returnType);
	public String checkLateFee(String taxPeriod, ReturnMasterDto returnMasterDto);
	public void saveReturnPeriod(ReturnPeriod returnPeriod);
	public void deActivateReturnPeriod(int periodId);
	public  String getPreviousMonthTaxPeriod(); 
	public String getFormattedPreviousMonthTaxPeriod();
}
