package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.DueDateMaster;


public interface DueMasterService {
	
	public List<DueDateMaster> findAll();

}
