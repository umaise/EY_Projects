package com.ey.advisory.asp.common;

import java.util.ArrayList;
import java.util.List;

public class Utility {

	public static String toString(List<String> Param){
		List<String> finalParamList = new ArrayList<>();
		String finalString="";
		for(String s:Param){
			String str = "'"+s+"'";
			finalParamList.add(str);
		}
		if(!finalParamList.isEmpty()){
			finalString = finalParamList.toString().substring(1, finalParamList.toString().length()-1);
		}

		return finalString;

	}
	
}
