package com.ey.advisory.asp.master.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.json.simple.JSONObject;

import com.ey.advisory.asp.dto.DueDateMasterDto;
import com.ey.advisory.asp.dto.EntityHierarchyDto;
import com.ey.advisory.asp.dto.FunctionDto;
import com.ey.advisory.asp.dto.GSTINDetailsDto;
import com.ey.advisory.asp.dto.GroupDto;
import com.ey.advisory.asp.dto.RoleDto;
import com.ey.advisory.asp.dto.UserAccessMapping_dto;

@XmlRootElement
@XmlAccessorType (XmlAccessType.NONE)
@Entity
@Table(name = "tblGSTUserLogin",schema="master")
public class User implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UserID")
	private Long userId;
	
	@NotEmpty(message="{createUser.Username.required}")
	@Column(name = "UserName", length = 30, nullable = false)
	@XmlElement
	private String userName;
	
	@Column(name = "Pwd")
	private String password;
	
	@Column(name = "Prefix")
	private String prefix;
	
	@NotEmpty(message = "{createUser.FirstName.required}")
	@Column(name = "FirstName", length = 40, nullable = false)
	@XmlElement
	private String firstName;
	
	@Column(name = "MiddleName", length = 40)
	@XmlElement
	private String middleName;	
	
	@NotEmpty(message = "{createUser.LastName.required}")
	@Column(name = "LastName", length = 40)
	@XmlElement
	private String lastName;
	
	@Column(name = "Gender", length = 40)
	private String gender;
	
	@NotEmpty(message = "{createUser.Email.required}")
	@Email
	@Column(name = "E_MailID", length = 80)
	@XmlElement
	private String emailId;
	
	@Column(name = "PAN")
	private String pan;
	
	@Column(name = "IsActive")
	private Boolean isActive;
	
	@Column(name = "AccountExpired", nullable = false)
	private Boolean accountExpired;
	//Account locked
	@Column(name = "AccountLocked", nullable = false)	
	private Boolean locked;
	
	@Column(name = "ForcePasswordChange", nullable = false)
	private Boolean forcePasswordChange;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "LastLoginDate", length = 23, nullable = false)
	private Date lastLogin;
	
	//Number of failed attempts
	@Column(name = "NoOfFailedAttempts", nullable = false)
	private Integer countUnsucessful;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "PasswordCreationDate", length = 23, nullable = false)
	private Date pwdCreationDate;	
	
	@Column(name = "PasswordExpired", nullable = false)
	private Boolean pwdExpired;
	
	@Column(name = "CreatedBy", nullable = false)
	private String createdBy;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "CreatedDate", nullable = false)
	private Date createdDate;	
	
	@Column(name = "UpdatedBy")
	private String lastModifiedBy;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "UpdatedDate")
	private Date lastModifieddDate;	
	
	@Column(name = "GPNNo")
	private String gpnNumber;
	
	@Column(name = "EngagementId")
	private String engagementId;
	
	@Column(name = "TypOfUser")
	private String typeOfUser;
	
	@Column(name = "GSTUserName")
	private String gstUserName;
	
	@Column(name = "MobileNo")
	private String mobileNo;
	
	@Column(name = "OfficeNo")
	private String officeNo;
	
	@Column(name = "IsApproved")
	private Boolean isApproved;
	
	@Transient
	private List<UserGSTNRoleMaping> userGSTNRoleMapings;
	
	@Transient
	private List<Long> roles = new ArrayList<>(); 
	
	@Transient
	private List<Long> userMappingIds = new ArrayList<>(); 
	
	public List<Long> getUserMappingIds() {
		return userMappingIds;
	}

	public void setUserMappingIds(List<Long> userMappingIds) {
		this.userMappingIds = userMappingIds;
	}
	
	@Transient
	private Set<RoleDto> roleSet;
	
	@Transient
	private Set<FunctionDto> appFuncSet;
	
	@Transient
	private Set<GroupDto> groupDto;
	
	@Transient
	private List<States> statesList;
	
	@Transient
	private List<DueDateMasterDto> dueDateMasterDtoList;
	
	@Transient
	private List<GSTINDetailsDto> gstindtoList;
	
	@Transient
	private ReturnPeriod returnPeriod;
	
	@Transient
	private Long roleId;
	
	@Transient
	private JSONObject groupEntityDivInfo;
	
	@Transient
    private List<UserAccessMapping_dto> userAccMapDTOList;
    
	@Transient
    private List<EntityHierarchyDto>  entityHierarchyDtoList;
	
	@Transient
	private List<MasterHierarchyConfig> masterHierarchyConfigList;
	
	@Transient
	private Set<String> authSignGstins;
	
	@Transient
	private String isEyLogin;
	
	@Transient
	private String groupId;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String isEyLogin() {
		return isEyLogin;
	}

	public void setEyLogin(String isEyLogin) {
		this.isEyLogin = isEyLogin;
	}
	
	
	/**
	 * @return the authSignGstins
	 */
	public Set<String> getAuthSignGstins() {
		return authSignGstins;
	}

	/**
	 * @param authSignGstins the authSignGstins to set
	 */
	public void setAuthSignGstins(Set<String> authSignGstins) {
		this.authSignGstins = authSignGstins;
	}

	/**
	 * @return the masterHierarchyConfigList
	 */
	public List<MasterHierarchyConfig> getMasterHierarchyConfigList() {
		return masterHierarchyConfigList;
	}

	/**
	 * @param masterHierarchyConfigList the masterHierarchyConfigList to set
	 */
	public void setMasterHierarchyConfigList(List<MasterHierarchyConfig> masterHierarchyConfigList) {
		this.masterHierarchyConfigList = masterHierarchyConfigList;
	}

	/**
	 * @return the userAccMapDTOList
	 */
	public List<UserAccessMapping_dto> getUserAccMapDTOList() {
		return userAccMapDTOList;
	}

	/**
	 * @return the entityHierarchyDtoList
	 */
	public List<EntityHierarchyDto> getEntityHierarchyDtoList() {
		return entityHierarchyDtoList;
	}

	/**
	 * @param userAccMapDTOList the userAccMapDTOList to set
	 */
	public void setUserAccMapDTOList(List<UserAccessMapping_dto> userAccMapDTOList) {
		this.userAccMapDTOList = userAccMapDTOList;
	}

	/**
	 * @param entityHierarchyDtoList the entityHierarchyDtoList to set
	 */
	public void setEntityHierarchyDtoList(List<EntityHierarchyDto> entityHierarchyDtoList) {
		this.entityHierarchyDtoList = entityHierarchyDtoList;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public JSONObject getGroupEntityDivInfo() {
		return groupEntityDivInfo;
	}

	public void setGroupEntityDivInfo(JSONObject groupEntityDivInfo) {
		this.groupEntityDivInfo = groupEntityDivInfo;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public Set<RoleDto> getRoleSet() {
		return roleSet;
	}

	public void setRoleSet(Set<RoleDto> roleSet) {
		this.roleSet = roleSet;
	}

	/**
	 * @return the groupDto
	 */
	public Set<GroupDto> getGroupDto() {
		return groupDto;
	}

	/**
	 * @param groupDto the groupDto to set
	 */
	public void setGroupDto(Set<GroupDto> groupDto) {
		this.groupDto = groupDto;
	}

	/**
	 * @return the gstindtoList
	 */
	public List<GSTINDetailsDto> getGstindtoList() {
		return gstindtoList;
	}

	/**
	 * @param gstindtoList the gstindtoList to set
	 */
	public void setGstindtoList(List<GSTINDetailsDto> gstindtoList) {
		this.gstindtoList = gstindtoList;
	}

	/**
	 * @return the statesList
	 */
	public List<States> getStatesList() {
		return statesList;
	}

	/**
	 * @param statesList the statesList to set
	 */
	public void setStatesList(List<States> statesList) {
		this.statesList = statesList;
	}

	/**
	 * @return the dueDateMasterDtoList
	 */
	public List<DueDateMasterDto> getDueDateMasterDtoList() {
		return dueDateMasterDtoList;
	}

	/**
	 * @param dueDateMasterDtoList the dueDateMasterDtoList to set
	 */
	public void setDueDateMasterDtoList(List<DueDateMasterDto> dueDateMasterDtoList) {
		this.dueDateMasterDtoList = dueDateMasterDtoList;
	}

	public Set<FunctionDto> getAppFuncSet() {
		return appFuncSet;
	}

	public void setAppFuncSet(Set<FunctionDto> appFuncSet) {
		this.appFuncSet = appFuncSet;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean isAccountExpired() {
		return accountExpired;
	}

	public void setAccountExpired(Boolean accountExpired) {
		this.accountExpired = accountExpired;
	}

	public Boolean isLocked() {
		return this.locked;
	}

	public void setLocked(Boolean locked) {
		this.locked = locked;
	}

	public Boolean isForcePasswordChange() {
		return this.forcePasswordChange;
	}

	public void setForcePasswordChange(Boolean forcePasswordChange) {
		this.forcePasswordChange = forcePasswordChange;
	}

	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Integer getCountUnsucessful() {
		return countUnsucessful;
	}

	public void setCountUnsucessful(Integer countUnsucessful) {
		this.countUnsucessful = countUnsucessful;
	}

	public Date getPwdCreationDate() {
		return pwdCreationDate;
	}

	public void setPwdCreationDate(Date pwdCreationDate) {
		this.pwdCreationDate = pwdCreationDate;
	}

	/*public Boolean getPwdExpired() {
		return pwdExpired;
	}*/
	
	public Boolean isPwdExpired() {
		return pwdExpired;
	}

	public void setPwdExpired(Boolean pwdExpired) {
		this.pwdExpired = pwdExpired;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifieddDate() {
		return lastModifieddDate;
	}

	public void setLastModifieddDate(Date lastModifieddDate) {
		this.lastModifieddDate = lastModifieddDate;
	}

	public String getGpnNumber() {
		return gpnNumber;
	}

	public void setGpnNumber(String gpnNumber) {
		this.gpnNumber = gpnNumber;
	}

	public String getEngagementId() {
		return engagementId;
	}

	public void setEngagementId(String engagementId) {
		this.engagementId = engagementId;
	}

	public String getTypeOfUser() {
		return typeOfUser;
	}

	public void setTypeOfUser(String typeOfUser) {
		this.typeOfUser = typeOfUser;
	}

	public String getGstUserName() {
		return gstUserName;
	}

	public void setGstUserName(String gstUserName) {
		this.gstUserName = gstUserName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getOfficeNo() {
		return officeNo;
	}

	public void setOfficeNo(String officeNo) {
		this.officeNo = officeNo;
	}

	public List<UserGSTNRoleMaping> getUserGSTNRoleMapings() {
		return userGSTNRoleMapings;
	}

	public void setUserGSTNRoleMapings(List<UserGSTNRoleMaping> userGSTNRoleMapings) {
		this.userGSTNRoleMapings = userGSTNRoleMapings;
	}

	/*public Boolean getAccountExpired() {
		return accountExpired;
	}

	public Boolean getLocked() {
		return locked;
	}

	public Boolean getForcePasswordChange() {
		return forcePasswordChange;
	}

	public Boolean getPwdExpired() {
		return pwdExpired;
	}*/

	public User() {
		super();
	}
	
	public User(long userId, String userName) {
		this.userId = userId;
		this.userName = userName;
	}

	public User(Long userId, String userName,
			Boolean pwdExpired, Boolean accountExpired, 
			Boolean locked, Boolean forcePasswordChange,
			Integer countUnsucessful) {
		super();
		this.userId = userId;
		this.userId = userId;
		this.userName = userName;
		this.pwdExpired = pwdExpired;
		this.accountExpired = accountExpired;
		this.locked = locked;
		this.forcePasswordChange = forcePasswordChange;
		this.countUnsucessful = countUnsucessful;
	}
	
	@Override
	public int hashCode() {
		int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof User)) {
			return false;
		}
		User other = (User) obj;
		if (userId == null) {
			if (other.userId != null) {
				return false;
			}
		} else if (!userId.equals(other.userId)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName
				+ ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", emailId=" + emailId
				+ ", expired=" + pwdExpired + ", locked=" + locked
				+ ", forcePasswordChange=" + forcePasswordChange
				+ ", countUnsucessful=" + countUnsucessful + ", lastLogin="
				+ lastLogin + ", userAuthentication=" 
				+ "]";
	}

	/**
	 * @return the returnPeriod
	 */
	public ReturnPeriod getReturnPeriod() {
		return returnPeriod;
	}

	/**
	 * @param returnPeriod the returnPeriod to set
	 */
	public void setReturnPeriod(ReturnPeriod returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	
}
