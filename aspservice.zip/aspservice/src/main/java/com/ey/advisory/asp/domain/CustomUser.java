package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;




public class CustomUser extends User implements Serializable {

	private static final long serialVersionUID = 1L;
	private String currentRole;
	private String fullUserName;
	private Boolean forceChangePwd;
	private Boolean pwdExpired;
	private Long userId;

	

	public CustomUser(Long userId, final String username, final String password,
			final boolean enabled, final boolean accountNonExpired,
			final boolean credentialsNonExpired,
			final boolean accountNonLocked,
			final Collection<? extends GrantedAuthority> authorities,
			final String currentRole, final String fullUserName,
			 final boolean forceChangePwd, 
			final boolean pwdExpired) {

		super(username, password, enabled, accountNonExpired,
				credentialsNonExpired, accountNonLocked, authorities);
		
		
		this.currentRole = currentRole;
		this.fullUserName = fullUserName;
		this.forceChangePwd =forceChangePwd;
		this.pwdExpired = pwdExpired;
		this.userId = userId;
	}

	public String getCurrentRole() {
		return currentRole;
	}

	public void setCurrentRole(String currentRole) {
		this.currentRole = currentRole;
	}

	public String getFullUserName() {
		return fullUserName;
	}

	public void setFullUserName(String fullUserName) {
		this.fullUserName = fullUserName;
	}

	
	public Boolean getForceChangePwd() {
		return forceChangePwd;
	}

	public void setForceChangePwd(Boolean forceChangePwd) {
		this.forceChangePwd = forceChangePwd;
	}

	public Boolean isPwdExpired() {
		return pwdExpired;
	}

	public void setPwdExpired(Boolean pwdExpired) {
		this.pwdExpired = pwdExpired;
	}

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

}