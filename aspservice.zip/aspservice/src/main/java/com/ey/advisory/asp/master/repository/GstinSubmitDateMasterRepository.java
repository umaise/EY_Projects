package com.ey.advisory.asp.master.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.master.domain.GstinSubmitDateMaster;

@Repository
public interface GstinSubmitDateMasterRepository extends JpaRepository<GstinSubmitDateMaster,Integer> {
	
	@Query("from GstinSubmitDateMaster g where g.returnType =:returnType" )
	public GstinSubmitDateMaster getSubmitDatesByReturnType(@Param("returnType") String returnType);

}
