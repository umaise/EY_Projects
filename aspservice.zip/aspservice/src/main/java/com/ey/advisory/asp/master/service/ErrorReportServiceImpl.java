package com.ey.advisory.asp.master.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.etl.service.ETLSpServiceImpl;

@Service
public class ErrorReportServiceImpl implements ErrorReportService{
	
protected EntityManager entityManager;
	
	private static final Logger logger = Logger
			.getLogger(ETLSpServiceImpl.class);
	private static final String CLASS_NAME = ErrorReportServiceImpl.class.getName();

	public EntityManager getEntityManager() {
		return entityManager;
	}
	  
	@PersistenceContext(unitName="masterDataUnit")
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public String executeStoredProcedure(String storedProcName){		
		String procStatus="";
		StoredProcedureQuery query;
		 try
		    {
			 query = entityManager.createStoredProcedureQuery(storedProcName);
			 procStatus=String.valueOf(query.getSingleResult());
			 
		    }catch(Exception e){
		    	logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : executeStoredProcedure",e);
		    }
		return procStatus;
		}
		

	
}
