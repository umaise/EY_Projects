package com.ey.advisory.asp.master.service;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.domain.UserGSTNRoleMaping;
import com.ey.advisory.asp.master.repository.RoleRepository;
import com.ey.advisory.asp.master.repository.UserGSTNRoleMapingRepository;

@Service
public class RoleServiceImpl implements RoleService{
	
	private static final Logger LOGGER = Logger.getLogger(RoleServiceImpl.class);
	
	protected EntityManager entityManager;
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Autowired
	private RoleRepository roleRepository;
    
    @Autowired
    private UserGSTNRoleMapingRepository gstnRoleMapingRepository;
    
    public List<Role> getRoles() {
		return roleRepository.getRoles();
	}

	@Override
	public List<Role> getUserRoles(Long userId) {
		//return roleRepository.getUserRoles(userId);
		return null;
	}

	@Override
	public List<Role> getAllRoles() {
		
		return roleRepository.findAll();
	}

	@Override
	public Role saveRole(Role role) {
		
		return roleRepository.saveAndFlush(role);
	}

	@Override
	public String saveUserRoleMapping(List<UserGSTNRoleMaping> gstnRoleMapings) {
		String status="";
		for (UserGSTNRoleMaping userGSTNRoleMaping : gstnRoleMapings) {
			List<UserGSTNRoleMaping> result	= gstnRoleMapingRepository.findByUserId(userGSTNRoleMaping.getUserId());
			if(result!=null && !(result.isEmpty())){
				for (UserGSTNRoleMaping userGSTNRoleMaping2 : result) {
					gstnRoleMapingRepository.updateRole(userGSTNRoleMaping.getRoleId(),new Date(new java.util.Date().getTime()),"", userGSTNRoleMaping2.getUserId());
				}
			}
		}
		return status;
	}
	
	@Override
	public List<Role> getRolesByCategory(String category) {
		try{
			List<Role> roles= roleRepository.getRolesByCategory(category);
			return roles;
		}catch(Exception e){
			LOGGER.error("Exception while executing repository query in getRolesByCategory",e);
			return null;
		}
	}
}
