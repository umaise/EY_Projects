package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Smruti.Pradhan
 *
 */
@Entity
@Table(name="tblDataPipelineDtls", schema="config")
public class TblPipeLineDtls implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7501302731818496935L;
	@Id
	@Column(name="ID")
	private int id;
	@Column(name="ReturnType")
	private String returnType;
	@Column(name="RecordType")
	private String recordtype;
	@Column(name="Datalevel")
	private String datalevel;
	@Column(name="ApplicableState")
	private String applicableStatus;
	@Column(name="uri")
	private String uri;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public String getRecordtype() {
		return recordtype;
	}
	public void setRecordtype(String recordtype) {
		this.recordtype = recordtype;
	}
	public String getDatalevel() {
		return datalevel;
	}
	public void setDatalevel(String datalevel) {
		this.datalevel = datalevel;
	}
	public String getApplicableStatus() {
		return applicableStatus;
	}
	public void setApplicableStatus(String applicableStatus) {
		this.applicableStatus = applicableStatus;
	}
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}

}
