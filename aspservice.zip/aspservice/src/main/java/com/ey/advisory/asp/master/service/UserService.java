package com.ey.advisory.asp.master.service;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.domain.UploadFileStatus;
import com.ey.advisory.asp.dto.UserSearchDto;
import com.ey.advisory.asp.master.domain.AppRoleFunction;
import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.domain.User;
import com.ey.advisory.asp.master.domain.UserGSTNRoleMaping;



public interface UserService {
	
	public User findByUserName(String userName);
	
	public User saveUser(User user);

	public User updateUser(User user,boolean isGroupEdited);

	public List<Object[]> getUserGSTNRoles(Long userId);
	/*added by ashwini*/
	public boolean isPasswordMatching(String userName,String password);
	
	public User findByEmailId(String emailId);
	
	public Map<String,Map<String,List<String>>> getUserGroupData(long userId);
	
	public String insertFileStatus(UploadFileStatus fileStatus);
	
	public List<User> loadAllUsers();
	
	public String getUserData(long userId);
	
	public String findByUserId(Long userId);
	
	public String getAllUsers(UserSearchDto userSearchDto);
	
	public List<UserGSTNRoleMaping> findRolesByUserId(User userId);
	
	public List<AppRoleFunction> findAppRoleFunctionByRole(Role roleId);
	
	public Map<User, List<Role>> getAssociatedRoles(User userId);
	
	public User getUserByName(String userName);
	
	public User approveUser(User user);
	
	public User activateUser(User user);
	
	public String getCurrentPeriod();
	
	public String checkExistingFile(List<String> fileName);

	public User saveOnBoardUser(User user);
	
	public UserGSTNRoleMaping saveUserGroupRoleMapping(UserGSTNRoleMaping userGSTNRoleMaping);
	
	public int insertFileStatusSummary(UploadFileStatus fileStatus); 
	
	public Map<String,Integer> getUserNameMap();
	
	public List<UserGSTNRoleMaping> findRolesByUserId(Long userId);

	public List<User> findByUserIdList(List<Long> userIdList);

	
	public void deleteRoleMapping(List<UserGSTNRoleMaping> userRoleList);

	public void deleteUsers(List<UserGSTNRoleMaping> userRoleList);
	public Map<Long, String> findEmailByUserIdList(List<Long> userIdList);

	public User saveUserDetail(User user, String groupId);

	public int updateUserDetail(String emailId, String mobileNo, String userid,Boolean isActive);
	
	public List<User> findByUserNameNoEqualsAndEmailIdEquals(String emailId,String username);
}
