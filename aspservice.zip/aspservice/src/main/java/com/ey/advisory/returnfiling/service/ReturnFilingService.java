package com.ey.advisory.returnfiling.service;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;
import com.ey.advisory.asp.master.domain.ReturnPeriod;

public interface ReturnFilingService {

	 ReturnPeriod findByIsCurrentPeriod(boolean currentPeriod);
	public List<FileUploadStatusMaster> findByIsStageProcessedAndJobStatusAndFileData(String isStageProcessed, String jobStatus, String fileData, Pageable topTen);

}
