package com.ey.advisory.asp.domain;


public class Summary {
	
	String checksum, ttlInv, ttlTax ,ttlIgst,ttlCgst,ttlSgst;
	
	public Summary(String checksum, String ttlInv, String ttlTax, String ttlIgst, String ttlCgst, String ttlSgst) {
		super();
		this.checksum = checksum;
		this.ttlInv = ttlInv;
		this.ttlTax = ttlTax;
		this.ttlIgst = ttlIgst;
		this.ttlCgst = ttlCgst;
		this.ttlSgst = ttlSgst;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	public String getTtlInv() {
		return ttlInv;
	}

	public void setTtlInv(String ttlInv) {
		this.ttlInv = ttlInv;
	}

	public String getTtlTax() {
		return ttlTax;
	}

	public void setTtlTax(String ttlTax) {
		this.ttlTax = ttlTax;
	}

	public String getTtlIgst() {
		return ttlIgst;
	}

	public void setTtlIgst(String ttlIgst) {
		this.ttlIgst = ttlIgst;
	}

	public String getTtlCgst() {
		return ttlCgst;
	}

	public void setTtlCgst(String ttlCgst) {
		this.ttlCgst = ttlCgst;
	}

	public String getTtlSgst() {
		return ttlSgst;
	}

	public void setTtlSgst(String ttlSgst) {
		this.ttlSgst = ttlSgst;
	}



	
}
