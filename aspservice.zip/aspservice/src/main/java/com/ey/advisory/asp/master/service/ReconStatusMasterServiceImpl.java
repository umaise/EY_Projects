package com.ey.advisory.asp.master.service;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.master.domain.ReconStatusMaster;
import com.ey.advisory.asp.master.repository.ReconStatusMasterRepository;

@Service("reconStatusService")
public class ReconStatusMasterServiceImpl implements ReconStatusMasterService{
	
	private static final Logger LOGGER = Logger.getLogger(UserServiceImpl.class);
	protected EntityManager entityManager;
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Autowired
	private ReconStatusMasterRepository reconStatusRepository;
    
	@Override
	public ReconStatusMaster saveReconStatusMaster(String gstin, String taxPeriod, String groupCode, String returnType) {
		LOGGER.info("Start of saveReconStatus in Master");
		ReconStatusMaster reconStatus = new ReconStatusMaster();
		try {
			reconStatus.setGroupCode(groupCode);
			reconStatus.setGstin(gstin);
			reconStatus.setTaxPeriod(taxPeriod);
			reconStatus.setReturnType(returnType);
			reconStatus.setCreatedDate(new Date());
			reconStatus.setIsActive(true);
			reconStatus.setReconStatus("ReconInitiated");
			reconStatusRepository.saveAndFlush(reconStatus);
			LOGGER.info("End of saveReconStatus in Master");
		} catch (Exception e) {
			LOGGER.error("Exception of saveReconStatus in Master " + e);
		}
		return reconStatus;
	}

	@Override
	public ReconStatusMaster updateReconStatusMaster(String gstin, String taxPeriod, String groupCode) {
		LOGGER.info("Start of saveReconStatus in Master");
		ReconStatusMaster activeReconStatus = null;
		try {
			activeReconStatus = getReconStatusMaster(gstin, taxPeriod, groupCode);
			if (activeReconStatus != null) {
				activeReconStatus.setIsActive(false);
				activeReconStatus.setUpdatedDate(new Date());
				reconStatusRepository.save(activeReconStatus);
			}
			LOGGER.info("End of updateReconStatusMaster in Master");
		} catch (Exception e) {
			LOGGER.info("Exception in updateReconStatusMaster in Master "+e);
		}
		return activeReconStatus;
	}

	@Override
	public ReconStatusMaster getReconStatusMaster(String gstin, String taxPeriod, String groupCode) {
		return reconStatusRepository.getReconStatus(gstin, taxPeriod, groupCode);
	}

}
