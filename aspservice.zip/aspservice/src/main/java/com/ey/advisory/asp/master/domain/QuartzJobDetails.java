package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "QRTZ_JOB_DETAILS", schema = "dbo")
public class QuartzJobDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
	private QuartzJobDetailsPK quartzJobDetailsPK;
    
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "JOB_CLASS_NAME")
	private String jobClassName;
	
	@Column(name = "IS_DURABLE")
	private boolean isDurable;
	
	@Column(name = "IS_NONCONCURRENT")
	private boolean isNonConcurrent;
	
	@Column(name = "IS_UPDATE_DATA")
	private boolean isUpdateData;
	
	@Column(name = "REQUESTS_RECOVERY")
	private boolean requestsRecovery;
	
	@Column(name = "JOB_DATA")
	private String  jobData;


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getJobClassName() {
		return jobClassName;
	}

	public void setJobClassName(String jobClassName) {
		this.jobClassName = jobClassName;
	}

	public boolean isDurable() {
		return isDurable;
	}

	public void setDurable(boolean isDurable) {
		this.isDurable = isDurable;
	}

	public boolean isNonConcurrent() {
		return isNonConcurrent;
	}

	public void setNonConcurrent(boolean isNonConcurrent) {
		this.isNonConcurrent = isNonConcurrent;
	}

	public boolean isUpdateData() {
		return isUpdateData;
	}

	public void setUpdateData(boolean isUpdateData) {
		this.isUpdateData = isUpdateData;
	}

	public boolean isRequestsRecovery() {
		return requestsRecovery;
	}

	public void setRequestsRecovery(boolean requestsRecovery) {
		this.requestsRecovery = requestsRecovery;
	}

	public String getJobData() {
		return jobData;
	}

	public void setJobData(String jobData) {
		this.jobData = jobData;
	}
	
	

	public QuartzJobDetailsPK getQuartzJobDetailsPK() {
		return quartzJobDetailsPK;
	}

	public void setQuartzJobDetailsPK(QuartzJobDetailsPK quartzJobDetailsPK) {
		this.quartzJobDetailsPK = quartzJobDetailsPK;
	}

	@Override
	public String toString() {
		return "QuartzJobDetails [description=" + description
				+ ", jobClassName=" + jobClassName + ", isDurable=" + isDurable
				+ ", isNonConcurrent=" + isNonConcurrent + ", isUpdateData="
				+ isUpdateData + ", requestsRecovery=" + requestsRecovery
				+ ", jobData=" + jobData + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((quartzJobDetailsPK == null) ? 0 : quartzJobDetailsPK
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuartzJobDetails other = (QuartzJobDetails) obj;
		if (quartzJobDetailsPK == null) {
			if (other.quartzJobDetailsPK != null)
				return false;
		} else if (!quartzJobDetailsPK.equals(other.quartzJobDetailsPK))
			return false;
		return true;
	}

	
	
	
}
