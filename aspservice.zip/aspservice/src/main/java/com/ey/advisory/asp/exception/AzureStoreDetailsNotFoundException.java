package com.ey.advisory.asp.exception;

/**
 * @author Sai.Pakanati
 * Exception when the Azure Store Details is not available in the DB(GroupConfig)
 * 
 * TODO: Place the loggers
 * 
 */
public class AzureStoreDetailsNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	public String message;


	public AzureStoreDetailsNotFoundException(String message) {
		 this.message = message;
	}

	@Override
	public String getMessage() {

		return message;

	}
}
