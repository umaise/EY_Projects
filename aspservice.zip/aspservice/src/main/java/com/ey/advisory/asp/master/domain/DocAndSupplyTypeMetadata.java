package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name = "tblDocandSupplyType",schema="metadata")
public class DocAndSupplyTypeMetadata  implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DocandSupplyTypeID")
    private long docandSupplyTypeID;
    
    @Column(name = "Description")
    private String description;
    
    @Column(name = "Code")
    private String code;
    
    @Column(name = "Value")
    private String value;
    
    @Column(name = "OrderId")
    private Integer orderId;
    
    @Column(name = "TypeofDoc")
    private String typeofDoc;
    
    @Column(name = "FileCategory")
    private String fileCategory;

	public long getDocandSupplyTypeID() {
		return docandSupplyTypeID;
	}

	public void setDocandSupplyTypeID(long docandSupplyTypeID) {
		this.docandSupplyTypeID = docandSupplyTypeID;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getTypeofDoc() {
		return typeofDoc;
	}

	public void setTypeofDoc(String typeofDoc) {
		this.typeofDoc = typeofDoc;
	}

	public String getFileCategory() {
		return fileCategory;
	}

	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}

	@Override
	public String toString() {
		return "DocAndSupplyTypeMetadata [docandSupplyTypeID=" + docandSupplyTypeID + ", description=" + description
				+ ", code=" + code + ", value=" + value + ", orderId=" + orderId + ", typeofDoc=" + typeofDoc
				+ ", fileCategory=" + fileCategory + "]";
	}	
    
    
}
