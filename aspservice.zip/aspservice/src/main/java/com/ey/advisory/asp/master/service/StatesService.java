package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.States;

public interface StatesService {
	
	List<States> findAll();

}
