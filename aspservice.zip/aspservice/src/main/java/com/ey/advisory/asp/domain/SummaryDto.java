package com.ey.advisory.asp.domain;

public class SummaryDto {
private String gstinId;
private String month;
private String year;

private String data;
private String hmac;
private String signeddata;
private String signatureType;
private String sid;
private String payLoad;

private String action;

public String getGstinId() {
	return gstinId;
}
public void setGstinId(String gstinId) {
	this.gstinId = gstinId;
}
public String getMonth() {
	return month;
}
public void setMonth(String month) {
	this.month = month;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getData() {
	return data;
}
public void setData(String data) {
	this.data = data;
}
public String getSigneddata() {
	return signeddata;
}
public void setSigneddata(String signeddata) {
	this.signeddata = signeddata;
}
public String getSignatureType() {
	return signatureType;
}
public void setSignatureType(String signatureType) {
	this.signatureType = signatureType;
}
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public String getAction() {
	return action;
}
public void setAction(String action) {
	this.action = action;
}
public String getHmac() {
	return hmac;
}
public void setHmac(String hmac) {
	this.hmac = hmac;
}

public String getPayLoad() {
	return payLoad;
}
public void setPayLoad(String payLoad) {
	this.payLoad = payLoad;
}
}
