package com.ey.advisory.asp.master.service;

import java.util.Map;


public interface GroupConfigService {
	
	public Map<String,Map<String,String>> getAzureStorageDetailsForGroup(String groupCode);
	
	public Map<String,Map<String,String>> getAzureStorageDetails();
    
   
}
