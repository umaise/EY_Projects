/**
 * 
 */
package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

/**
 * @author Nitesh.Tripathi
 *
 */
@Entity
@Table(name = "tblGroupADDomainConfig", schema = Constant.MASTER_SCHEMA )
public class GroupADDomainConfigDomain implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GroupADDomainConfigID")
	private Long groupADDomainConfigID;
	
	@Column(name = "GroupId")
	private Long groupId;
	
	@Column(name = "UserDomains")
	private String userDomains;

	/**
	 * @return the groupADDomainConfigID
	 */
	public Long getGroupADDomainConfigID() {
		return groupADDomainConfigID;
	}

	/**
	 * @param groupADDomainConfigID the groupADDomainConfigID to set
	 */
	public void setGroupADDomainConfigID(Long groupADDomainConfigID) {
		this.groupADDomainConfigID = groupADDomainConfigID;
	}

	/**
	 * @return the groupId
	 */
	public Long getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the userDomains
	 */
	public String getUserDomains() {
		return userDomains;
	}

	/**
	 * @param userDomains the userDomains to set
	 */
	public void setUserDomains(String userDomains) {
		this.userDomains = userDomains;
	}

}
