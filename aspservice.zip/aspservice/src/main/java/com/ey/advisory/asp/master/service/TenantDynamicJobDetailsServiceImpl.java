package com.ey.advisory.asp.master.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;
import com.ey.advisory.asp.master.repository.TenantDynamicJobDetailsRepository;

@Service("TenantDynamicJobDetailsService")
public class TenantDynamicJobDetailsServiceImpl implements TenantDynamicJobDetailsService{
    
    @Autowired
    private TenantDynamicJobDetailsRepository tenantDynamicJobDetailsRepository;
    
	protected static final Logger LOGGER = Logger.getLogger(TenantDynamicJobDetailsServiceImpl.class);
	    
    protected EntityManager entityManager;

    public EntityManager getEntityManager() {
        return entityManager;
    }

    @PersistenceContext(unitName = "masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public void saveTenantDetails(TenantDynamicJobDetail tenantDynamicJobDetail) {
        tenantDynamicJobDetailsRepository.save(tenantDynamicJobDetail);
    }
    
        
	@Override
	public void updateJobDetail(String jobName, String groupCode, String type) {

		List<TenantDynamicJobDetail> jobDetails = tenantDynamicJobDetailsRepository.getJobDetailsForInput(jobName,
				groupCode);
		for (TenantDynamicJobDetail jobDetail : jobDetails) {
			if (type != null) {
				String param = readJobParam(jobDetail);
				if (param.equals(type)) {
					jobDetail.setStatus("CTD");
					tenantDynamicJobDetailsRepository.save(jobDetail);
					break;
				}
			} else {
				jobDetail.setStatus("CTD");
				tenantDynamicJobDetailsRepository.save(jobDetail);
			}
		}
	}
	
	 @SuppressWarnings("unchecked")
	    public String readJobParam(TenantDynamicJobDetail jobDetails){	    	
	    	String param = "";	    	
	    	 if (jobDetails.getJobParam() != null) {
	             InputStream is = new ByteArrayInputStream(jobDetails.getJobParam());
	             ObjectInputStream ois=null;
	             String values[] = null;
	             try {
	                 ois = new ObjectInputStream(is);
	                 Map<String, Object> inputJobMap = (Map<String, Object>) ois.readObject();
	                 if (inputJobMap != null) {
	                     Iterator<String> keys = inputJobMap.keySet().iterator();
	                     while (keys.hasNext()) {
	                         String key = (String) keys.next();
	                         Object value = inputJobMap.get(key);
	                         if(("paramsList").equals(key)){
	                             values= ((String)value).split(",");
	                             if(values.length>2)
	                             param = values[2];
	                             break;
	                         }
	                     }
	                 }
	             }
	             catch (Exception e) {
	             	if(LOGGER.isInfoEnabled()){
	                 LOGGER.info("Exception in  BifurcateJobListener",e);
	             	}
	                 throw new IllegalStateException("Not able to parse Job Param");
	             }finally {
	            	 try {
	            		 if(ois!=null){
	       				  ois.close();
	       				  }
	               		 if(is!=null){
	               			 is.close();
	       				  }
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
	         }
	    	 
	    	 return param;  
	    	
	    }

	@Override
	public boolean findByJobNameAndGroupCodeAndStatus(String jobName, String groupCode,
			List<String> status) {

		List<TenantDynamicJobDetail> jobDetails = tenantDynamicJobDetailsRepository
				.findByJobNameAndGroupCodeAndStatus(jobName, groupCode, status);
		if (jobDetails.isEmpty()) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public String getJobParamDetails(String jobName, String groupCode, List<String> status) {
		String param = null;
		List<TenantDynamicJobDetail> jobDetails = tenantDynamicJobDetailsRepository
				.findByJobNameAndGroupCodeAndStatus(jobName, groupCode, status);
		if (!jobDetails.isEmpty() && null != jobDetails) {
			param = readJobParamGSTN(jobDetails.get(0));
		}
		return param;
	}

	@SuppressWarnings("unchecked")
	public String readJobParamGSTN(TenantDynamicJobDetail jobDetails) {
		String param = "";
		if (jobDetails.getJobParam() != null) {
			InputStream is = new ByteArrayInputStream(jobDetails.getJobParam());
			ObjectInputStream ois=null;
			try {
				ois = new ObjectInputStream(is);
				Map<String, Object> inputJobMap = (Map<String, Object>) ois.readObject();
				if (inputJobMap != null) {
					Iterator<String> keys = inputJobMap.keySet().iterator();
					while (keys.hasNext()) {
						String key = (String) keys.next();
						Object value = inputJobMap.get(key);
						if (("gstin").equals(key)) {
							param = String.valueOf(value);
							break;
						}
					}
				}
			} catch (Exception e) {
				if (LOGGER.isInfoEnabled()) {
					LOGGER.info("Exception in  JobListener", e);
				}
				throw new IllegalStateException("Not able to parse Job Param");
			}finally {
           	 try {
        		
        		 if(ois!=null){
				  ois.close();
				  }
        		 if(is!=null){
        			 is.close();
				  }
        		 
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}

		return param;

	}

	 
	 
    
   }
