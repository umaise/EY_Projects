package com.ey.advisory.asp.master.service;

import java.util.List;

public interface SpCallService {
		
	String executeStoredProcedure(String storedProcName);

	String executeStoredProcedure(String storedProcSchema, String storedProcName, int inputParamsCount, List<String> inputParamsList);
	List<Object[]> executeSPReturnList(String storedProcName);
	void updateFileIdDetails(String updateIsProcessedTo, String updateJobStatusTo,String isProccessed,String jobStatus,String fileData);
	List<String> getFileList(String isProccessed, String jobStatus,String fileData,long fileId);
	String getDataLevel(String applicableState,String returnType,String recordType);
	List<String> executeStoredProcedureReturnList(String storedProcSchema, String storedProcName,int inputParamsCount, List<String> inputParamsList);
			
	String getGroupCode(List<String> fileIds);
	
	List<String> fetchgroupIdSummaryDetails(String status);
}
