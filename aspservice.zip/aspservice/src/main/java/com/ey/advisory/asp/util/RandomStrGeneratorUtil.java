/**
 * 
 */
package com.ey.advisory.asp.util;

import java.util.Random;

/**
 * @author Uma.Chandranaik
 *
 */
public class RandomStrGeneratorUtil {
	  private static final char[] alphNumerics;
	  
	  static {
		    StringBuilder stringBuilder = new StringBuilder();
		    for (char ch = '0'; ch <= '9'; ++ch)
		      stringBuilder.append(ch);
		    for (char ch = 'a'; ch <= 'z'; ++ch)
		      stringBuilder.append(ch);
		    alphNumerics = stringBuilder.toString().toCharArray();
		  }   
	  
	  private static final Random random = new Random();
	  

	  public static String generateRandamStr(int len) {
		char[] charArray = new char[len];
	    for (int index = 0; index < charArray.length; ++index){
	    	charArray[index] = alphNumerics[random.nextInt(alphNumerics.length)];
	    }
	    return new String(charArray);
	  }
}
