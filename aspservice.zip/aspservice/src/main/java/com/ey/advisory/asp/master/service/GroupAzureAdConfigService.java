/**
 * 
 */
package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.GroupAzureAdConfig;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface GroupAzureAdConfigService {
	
	public List<GroupAzureAdConfig> findAll();

}
