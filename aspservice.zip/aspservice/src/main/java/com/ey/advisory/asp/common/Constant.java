package com.ey.advisory.asp.common;



public class Constant {

	public static final String GSTNerrorReport = "error_report";
	public static final String FALSE = "FALSE";
	public static final String TRUE = "TRUE";
	public static final String YES = "Yes";
	public static final String NO = "No";
	public static final String CURRENTUSER = "CURRENTUSER";
	public static final String CURRENTUSEREMAILID = "CURRENTUSEREMAILID";
	public static final String USERGSTNROLES = "USERGSTNROLES";
	public static final String CURRENTROLE = "CURRENTROLE";
	public static final String GSTNTIME = "GSTNTIME";
	public static final String MAX_BAD_LOGIN = "MAX_BAD_LOGIN";
	public static final String PASS_EXPIRY_DAYS = "PASS_EXPIRY_DAYS";
	public static final String ENTER = "Enter ";
	public static final String EXIT = "Exit ";
	public final static String DATE_FORMAT = "yyyy-MM-dd";
	// Added for pagination
	public static final String DEFAULT_PAGE_SIZE = "DEFAULT_PAGE_SIZE";
	public final static String DATE_FORMAT_IN_HOURS = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String  FOLDER_STRUCT_SFTF = "folder.structure.SftFile";
	public static final String SYMBOL_COLON = ":";
	public static final String MOBILE_NUMBER = "mobile_number";

	public static final String BUS_RULE_ERROR = "BUS_RULE_ERROR";

	public static final String SEPERATOR_DOT = "\\.";

	// Service Map changes
	public static final String SERVICE_RELATION = "Level 4";
	public static final Long MENU_LEVEL = (long) 1;
	public static final String USER_ROLE_MENUS = "UserRoleMenus";
	public static final String USER_ROLE_FUNS = "UserRoleFuns";

	//
	/****** Resource Strings **********/
	public static final String AUTHENTICATE = "/taxpayerapi/v0.1/authenticate";

	public static final String RETURNS = "/taxpayerapi/v0.1/returns";

	public static final String GSTR1 = "/gstr1";

	public static final String GSTR2 = "/gstr2";
	public static final String GSTR6 = "/gstr6";
	public static final String GSTR2A = "/gstr2a";
	
	public static final String HOST = "http://devapi.gstsystem.co.in";

	public static final String LEDGERS = "/taxpayerapi/v0.1/ledgers";
	public static final String GSTIN = "GSTIN";
	public static final String DIGIGST_USERNAME = "digigstUserName";
	public static final String FILENUM = "fileNum";
	public static final String MONTH = "month";
	public static final String YEAR = "year";
	public static final String SHARED_PATH = "sharedPath";
	public static final String OUTWARD = "outward";
	public static final String INWARD = "inward";
	public static final String REGISTER_TYPE = "registerType";

	final public static String GSP_USER = "eygspuser";

	final public static String GSP_CLIENT_ID = "eygspclientid";

	final public static String GSP_CLIENT_SECRET = "eygspclientsecret";
	public static final String RETSAVE = "RETSAVE";
	public static final String OTPREQUEST = "OTPREQUEST";
	public static final String AUTHTOKEN = "AUTHTOKEN";
	public static final String RETSUBMIT = "RETSUBMIT";
	public static final String GSTR_1 = "Gstr1";
	public static final String GSTR_3 = "Gstr3";
	public static final String GSTR_7 = "Gstr7";
	public static final String GSTR_3_VALIDTION_MSG = "GSTR 1 can't be filed for the Current tax period if GSTR 3 for previous tax period is pending";
	public static final String GSTR_1_VALIDTION_MSG = "Normal Taxpayer cannot file GSTR 1 before the end of the Current tax period.";
	public static final String GSTR_2_VALIDTION_MSG = "Normal Taxpayer cannot file GSTR 2 before the end of the Current tax period.";
	public static final String GSTR_6_VALIDTION_MSG = "Normal Taxpayer cannot file GSTR 6 before the end of the Current tax period.";
	public static final String GSTR_6_FILING_VALIDTION_MSG = "GSTR6 is not filed for previous tax period";
	public static final String GSTR_7_VALIDTION_MSG = "Normal Taxpayer cannot file GSTR 7 before the end of the Current tax period.";
	public static final String GSTR_7_FILING_VALIDTION_MSG = "GSTR7 is not filed for previous tax period";

	public static final String MAILHOST = "http://inbanvmdwb02.mea.ey.net/MailAPI/api/sendmail";

	public static final String ESIGN = "ESIGN";
	public static final String STATUS = "status";
	public static final String ACK_NUM = "Ack_num";
	public static final String EMAILID = "emailId";
	public static final String OTP = "otp";
	public static final String NEW_PASSWORD = "newPassword";
	public static final String RESET_PASSWORD_VALIDATION = "New password must be different from Current password.";
	public static final String CHOOSE_PASSWORD_VALIDATION = "New password and confirm password does not match";
	public static final String CURRENT_PASSWORD_VALIDATION = "Current password does not match";
	public static final String SUCCESS = "success";
	public static final String DB = "DB";
	public static final String INVALID_EMAILID = "Entered emailId is not registered";
	public static final String STATECD = "state-cd";
	public static final String USERNAME = "username";
	public static final String TXN = "txn";
	public static final String GSTIN_HDR = "gstin";
	public static final String RET_PRD = "ret_period";
	public static final String GET_INITIAL = "?";
	public static final String PARAM_OAUTH = "auth-token";
	public static final String PARAM_GSTIN = "gstin=";
	public static final String PARAM_MONTH = "month=";
	public static final String PARAM_YEAR = "year=";
	public static final String AMPERSAND = "&";
	public static final String RETSUM = "RETSUM";
	public static final String IP_USR = "ip-usr";
	public static final String SPACE = " ";
	public static final String UNDERSCORE = "_";
	public static final String MASTER_SCHEMA = "master";
	public static final String CONFIG_SCHEMA = "config";
	public static final String UPDATE_PASSWORD_FAILURE = "Password could not be updated as something went wrong!";
	public static final String HSN_MASTER_DET = "HSN_MASTER_DETAILS";
	public static final String REDIS_CACHE = "REDIS_CACHE";
	public static final String CLIENT_STG_DETAILS = "CLIENT_STG_DETAILS";
	public static final String ERROR_MASTER_LIST = "ERROR_MASTER_LIST";
	public static final String PROC_HSN_MASTER_NAME = "dbo.usp_GetMasterHSNCodeDetails";
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String GROSSTURNOVER_KEY = "GROSSTURNOVER";
	public static final String ARNTRACK = "ARNTRACK";

	// logger related
	public static final String LOGGER_ENTERING = "Entering";
	public static final String LOGGER_EXITING = "Exiting";
	public static final String LOGGER_ERROR = "Error in";
	public static final String LOGGER_METHOD = " Method : ";

	public static final String USER_NAME = "userName";

	public static final boolean BOOLEAN_TRUE = true;
	public static final boolean BOOLEAN_FALSE = false;

	public static final int PASSWORD_LENGTH = 10;
	public static final int HOURS = 10;

	public static final String LINK_EXPIRED = "expired";
	public static final String LINK_NOT_EXPIRED = "notExpired";

	// For rules
	public static final String IS_PROCESSED_PIPELINE1 = "3";
	public static final String IS_PROCESSED_PIPELINE2 = "4";
	public static final String IS_PROCESSED_TRANSACTION_ACK = "8";
	public static final String JOB_STATUS_PIPELINE = "P";
	public static final int TAXPERIOD_MIN = 04;
	public static final int TAXPERIOD_MAX = 10;
	
	public static final String INVOICE_COUNT="InvCount";
	public static final String INVOICE_STATUS="InvStatus";
	public static final String INVOICE_ERROR_DETAILS="InvError";
	public static final String INVOICE_STATUS_VAL = "InvStatusVal";
	
	public static final String AMOUNT_OVER_DUE="amt_overdue";
	public static final String IGST="igst";
	public static final String CGST="cgst";
	public static final String SGST="sgst";
	public static final String CESS="cess";
	public static final String UTGST="utgst";
	public static final String TOTAL="tot";
	
	public static final String  SCHEMA="gstr3";
	public static final String  PROC_GSTR3_SAVE_ITCDATA="uspGSTR3SaveITCData";
	public static final String  PROC_GSTR3_SAVE_CASHDATA="uspGSTR3SaveCash";
	public static final String  PROC_GSTR3_SAVE_LIABDATA="uspGSTR3SaveTaxLiability";
	public static final String  LIABTYPE_TAXLIAB="tax_liability";
	public static final String  LIABTYPE_ITC="itc";
	public static final String  LIABTYPE_CASH="cash";
	public static final String  KEY_GSTR2="gstr2";
	public static final String UTF8 = "UTF-8";
	public static final String REK = "rek";
	public static final String DATA = "data";
	public static final String B2B = "B2B";
	public static final String B2BA = "B2BA";
	public static final String CDN = "CDN";
	public static final String CDNA = "CDNA";
	public static final String AT = "AT";
	public static final String ATA = "ATA";
	public static final String B2CL = "B2CL";
	public static final String B2CLA = "B2CLA";
	public static final String B2CS ="B2CS";
	public static final String B2CSA ="B2CSA";
	public static final String EXP = "EXP";
	public static final String EXPA = "EXPA";
	public static final String NIL = "NIL";
	public static final String SUMMARY = "SUMMARY";
	public static final String TXPD = "TXPD";	
	public static final String STATUS_CD = "status_cd";
	public static final String SESSION_KEY = "837ey46d-ooi9-12s3-lo90-19ijuys5";
	public static final String GSP_STUB_API_HOST ="gsp-stubapi.host";
	public static final String GSP_STUB_API_RESOURCE ="gsp-GSTR2Details";
	public static final String GSP_STUB_API_GSTR1_RESOURCE = "gsp-GSTR1Details";
	public static final String GSP_STUB_API_GSTR6_RESOURCE = "gsp-GSTR6Details";
	public static final String GSP_STUB_API_GSTR1A_RESOURCE = "gsp-GSTR1ADetails";
	public static final String FAILURE = "failure";
	public static final String GSP_GW_API_HOST ="gsp-gwapi.host";
	public static final String GSP_GW_API_RESOURCE ="gsp-gw-GSTR2ADetails";

	// doc type
		public static final String INV = "INV";
		public static final String RNV = "RNV";
		public static final String CR = "CR";
		public static final String DR = "DR";
		public static final String RCR = "RCR";
		public static final String RDR = "RDR";
		
		public static final String SCHEMA_NAME_DBO = "dbo";
		public static final String INSERT_FILE_STATUS_PROC = "insertFileStatus";
		public static final String INSERT_FILE_STATUS_PROC_INPUT_PARAM_COUNT = "10";
		
		public static final String FILE_UPLOAD_SUCCESS = "File uploaded successfully";
		public static final String FILE_UPLOAD_FAILURE = "Failed to upload file";
		public static final String FILE_DUPLICATE_FAILURE = "DUPLICATE";
		public static final String FAILED= "Failed";
		public static final String FAILED_UPPER= "FAILED";
		public static final String CANT_CALL_SP_ERROR_MSG="Can not call Stored Proc, Input parameters count and Input params list size is not equal";
		
		public static final String GSTIN_IDLIST = "GSTIN_IDLIST";

		public static final String RECON_FILING_STATUS = "ReconFilingStatus";
		public static final String RECON_COUNT = "ReconCount";
		public static final String ACKNOWLEDGE_ID = "ASDFSDF1241343";
		public static final String TAX_PERIOD = "taxPeriod";
		
		// GSTR3
		public static final String CASHSUM = "CASHSUM";
		public static final String ITCSUM = "ITCSUM";
		public static final String TAX = "TAX";
		public static final String DOC_NO = "DOC_NO";
		public static final String DOC_DATE = "DOC_DATE";
		
		
		public static final String OUTWARD_TYPE = "Sales";
		public static final String INWARD_TYPE = "Purchase";
		public static final String MONTHLY = "M";
		public static final String YEARLY = "Y";
		
		public static final char ERROR_MASTER_CODE = 'E';
		public static final char INFO_MASTER_CODE = 'I';
		
		public static final String FILED_STATUS = "FILED";
		
		public static final int MAP_ID_SFTP=1;
		public static final int MAP_ID_SFTP_ZERO=0;
		public static final String GSTR_2 = "Gstr2";
		public static final String STATES_LIST= "STATES_LIST";
		public static final String GROUP_LIST= "GROUP_LIST";
		public static final String ITEM_MASTER_DETAILS="ITEM_MASTER_DETAILS";
		public static final String GLOBAL_MASTER_DETAILS="GLOBAL_MASTER_DETAILS";
		public static final String PRODUCT_MASTER_DETAILS = "PRODUCT_MASTER_DETAILS";
		public static final String ANSWERS_LIST = "ANSWERS_LIST";
		public static final String QUESTIONS_LIST = "QUESTIONS_LIST";
		public static final String QUESTION_ANSWER_MAPPING = "QUESTION_ANSWER_MAPPING";
		public static final String IGST_RATE_LIST = "IGST_RATE_LIST";
		public static final String CGST_RATE_LIST = "CGST_RATE_LIST";
		public static final String SGST_RATE_LIST = "SGST_RATE_LIST";
		public static final String GLOBAL_RATES_MAP = "GLOBAL_RATES_MAP";
		
		//GSTR6
		public static final String GSTR_6 = "Gstr6";
		
		public static final String ENTITY_KEY = "ENTITY_KEY";
		public static final String GSTIN_DEATILS = "GSTIN_DEATILS";
		public static final String GSTINID = "gstinId";
		public static final String API_VERSION2 = "v0.2";
		public static final String REST_API_HOST_V2 = "gstn-restapi.host";
		public static final String REST_API_RESOURCE_V2 = "gstn-restapi.return";
		public static final String SUPPLY_METADATA = "SUPPLY_METADATA";
		public static final String PURCHASE_METADATA = "PURCHASE_METADATA";

		public static final String BUSINESS_RULE = "Business Rule";
		public static final String INVOICE = "Invoice";
		public static final String ORG_DOC_NO = "ORG_DOC_NO";
		public static final String SUBMITTED = "SUBMITTED";
		public static final String PENDING = "PENDING";
		
		public static final String ROLE_LIST= "ROLE_LIST";
		public static final int SUBMIT_MIN_DATE=5;
		public static final int SUBMIT_MAX_DATE=10;
		
		public static final String VERSION_1 = "v0.1";
		public static final String VERSION_2 = "v0.2";
		public static final String VERSION_3 = "v0.3";
		
		public static final String GSTN_RESTAPI_HOST="gstn-restapi.host";
		public static final String GSPGW_RESTAPI_HOST="gspgw-restapi.host";
		
		public static final String GSTN_RESTAPI_RETURN="gstn-restapi.return";
		public static final String GSPGW_RESTAPI_RETURN="gspgw-restapi.return";
		
		public static final String GSTN_RESTAPI_LEDGERS="gstn-restapi.ledgers";
		public static final String GSPGW_RESTAPI_LEDGERS="gstn-restapi.ledgers";
		
		public static final String GSPGW_RESTAPI_HOST_DOWNLOAD="gspgw-restapi.host_file_download";
		public static final String GSPGW_FILEDWNLOAD_RESTAPI_HOST_DOWNLOAD="gspgw-restapi.filedownload.host_file_download";
		
				
		
		public static final String ACTION_B2B="B2B";
		
		public static final String RETSTATUS="RETSTATUS";
		
		public static final String GSTR1_SCHEMA = "gstr1";
		public static final String GSTR2_SCHEMA = "gstr2";
		
		public static final String GSTR1_ADVANCE_ADJUSTED_PROC = "uspGSTR1AdvanceAdjusted";
		public static final String UPLOADED_STATUS = "ULD";
		
		public static final String GSTR1_ADVANCE_ADJUSTED_LIST = "GSTR1_ADVANCE_ADJUSTED_LIST";
		public static final String GSTR1_ADVANCE_RECEIVED_LIST = "GSTR1_ADVANCE_RECEIVED_LIST";
		public static final String GSTR1_B2C_CONSOLIDATED_LIST = "GSTR1_B2C_CONSOLIDATED_LIST";
		public static final String GSTR1_INVOICE_SERIES_LIST = "GSTR1_INVOICE_SERIES_LIST";
		
		public static final String GSTR2_ADVANCE_ADJUSTED_LIST = "GSTR2_ADVANCE_ADJUSTED_LIST";
		public static final String GSTR2_ADVANCE_PAID_LIST = "GSTR2_ADVANCE_PAID_LIST";
		public static final String GSTR2_ITC_REVERSAL_LIST = "GSTR2_ITC_REVERSAL_LIST";
		public static final String GSTR2_ADVANCE_ADJUSTED_RETURN_CODE="GSTR2AA";
		public static final String GSTR2_ADVANCE_PAID_RETURN_CODE="GSTR2AP";
		public static final String GSTR2_ITC_REVERSAL_RETURN_CODE="GSTR2IR";
		public static final String GSTR2RCM = "GSTR2RCM";
		public static final String RCM = "RCM";
		public static final String INVKEY = "INVKEY";
		public static final String SUPPLYTYPE = "SUPPLYTYPE";
		public static final String DOCDATE = "DOCDATE";
		public static final String YYYY_MM_DD = "yyyy-MM-dd";
		
		public static final String GSTR2_ADVANCE_PAID_METADATA = "Gstr2_Advance_Paid_Metadata";
		public static final String GSTR2_ADVANCE_ADJUSTED_METADATA = "Gstr2_Advance_Adjusted_Metadata";
		public static final String GSTR2_ITC_REVERSAL_METADATA = "Gstr2_Itc_Reversal_Metadata";
		
		public static final String RCM_CONSOLIDATED_METADATA = "RCM_Consolidated_Metadata";
		public static final String GSTR2_RCM_CONSOLIDATED_LIST = "GSTR2_RCM_CONSOLIDATED_LIST";
		public static final String RCM_FILE_ID ="RCMFileID";
		
		public static final String ADVANCE_ADJUSTED_METADATA = "Advance_Adjusted_Metadata";
		public static final String ADVANCE_RECEIVED_METADATA = "Advance_Received_Metadata";
		public static final String B2C_CONSOLIDATED_METADATA = "B2C_Consolidated_Metadata";
		public static final String INVOICE_SERIES_METADATA = "Invoice_Series_Metadata";
		public static final String GSTR1_ADVANCE_RECEIVED_PROC = "uspGSTR1AdvanceReceive";
		public static final String GSTR1_B2C_SUMMARY_PROC = "uspGSTR1B2C_Consolidate";
		public static final String GSTR1_INVOICE_SERIES_PROC = "uspGSTR1InvoiceSeries";
		public static final String SUMMARY_FILE_ID ="SummaryFileID";
		public static final String GSTR1_INVOICE_SERIES_RETURN_CODE="GSTR1IS";
		public static final String GSTR1_ADVANCE_ADJUSTED_RETURN_CODE="GSTR1AA";
		public static final String GSTR1_ADVANCE_RECEIVED_RETURN_CODE="GSTR1AR";
		public static final String GSTR1_B2C_RETURN_CODE="GSTR1B2C";
		public static final int JSON_SERIES_CHUNK_MAX_VALUE=2500;
		public static final String GSTR2_ADVANCE_ADJUSTED_PROC = "uspGSTR2AdvanceAdjusted";
		public static final String GSTR2_ADVANCE_PAID_PROC = "uspGSTR2AdvancePaid";
		public static final String GSTR2_ITC_REVERSAL_PROC = "uspGSTR2ITCReversal";
		public static final String USP_RCM_TRANSACTION_UPLOAD= "uspRCMTransactionUpload";
		
		public static final String SFTP_INWARD = "Inward";
		public static final String SFTP_OUTWARD = "Outward";
		public static final String NEW = "NEW";
		public static final String INPROGRESS = "INPROGRESS";
		public static final String SAVED = "SAVED";
		public static final String SAVE_ERROR = "SAVE_ERROR";
		public static final String SAVE_NILLINVOICE = "SaveNillInvoice";
		public static final String SAVE_INPROGRESS = "SaveInProgress";
		public static final String SAVESUCESS = "SaveSuccesfully";
		public static final String SAVE_WITH_ERROR = "SavewithError";
		public static final String PROCESSED_STATUS = "PSD";
	    public static final String FAILED_STATUS = "FLD";
	  	public static final String ROWCOUNT = "ROWCOUNT";
		public static final String SUMMARY_DATA = "summaryJson";
		public static final String BUSINESS_NAME = "businessName";
		public static final String JSON_SERIES_CHUNK_SUMMARY_METADATA = "Json_Series_Chunk_Summary_Metadata";
	  	public static final String JSON_SERIES_CHUNK_SUMMARY_LIST = "JSON_SERIES_CHUNK_SUMMARY_LIST";
		public static final String JOSN_SERIES_CHUNK_METADATA_URL="asp-loadJsonSeriesChunkMetadata";
		public static final String SUMMARY_PROC_INPUT_COUNT="3";
		public static final int EXCEL_ROW_NUMBER_ZERO=0;
		public static final int EXCEL_ROW_NUMBER_ONE=1;
		public static final int EXCEL_ROW_NUMBER_TWO=2;
		public static final int EXCEL_ROW_NUMBER_NINE=9;
		public static final int EXCEL_ROW_NUMBER_TEN=10;
		public static final String STARTED_STATUS = "STD";
		public static final int JSON_SERIES_CHUNK_MIN_VALUE=1;
		public static final String RETURNTYPES = "returnTypes";
		public static final int ZERO = 0;
		public static final String ONE = "1";
		public static final String SKIP = "SKIP";
		public static final String PRODUCTMASTERDETAILS = "productMasterDetails";
		public static final String CUSTOMERMASTER = "customerMaster";
		public static final String ITEMMASTERDETAILS = "itemMasterDetails";
		public static final String GLOBALGSTRATESMASTERDETAILS= "globalGstRatesMasterDetails";
		public static final String VENDORMASTERDETAILS = "vendorMasterDetails";
		public static final String GLOBALGSTRATESMASTERDETAILSSECOND="globalGstRatesMasterDetailsSecond";
		public static final String GLCODEMASTERDETAILS="glCodeMasterDetails";
		public static final int NEGONE = -1;
		public static final String zero ="0";
		public static final String FOLDER_STRUCT_SFTF_PROCESSED="folder.structure.SftFile.processed";
		public static final String GL_CODE_MASTER_DETAILS_KEY = "glCodeMasterDetails";
		public static final String GL_CODE_MASTER_DETAILS = "GL_CODE_MASTER_DETAILS";
		public static final String INVOICE_VALUE = "INVOICE_VALUE";
		public static final double ZERO_DOUBLE	=0.00;
		
		public static final String REDIS_GROUP_AD_CONFIGURATIONS = "GROUP_AD_CONFIGURATIONS";
		public static final String YMObj = "ymObj";
		public static final String Y = "Y";
		public static final String GET_FILE_VIEW_STATUS_PROC = "uspGSTR1ViewStatus";
		public static final String FILE_VIEW_STATUS_PROC_INPUT_PARAM_COUNT = "3";
		public static final String RAW_FILE="Raw File";
		public static final String GENRNATE_DUMP_REPORT_PROC = "DumpReportDemo";
		
		public static final String GSTN_ID = "gstnid";
		public static final String RETURN_PERIOD = "returnPeriod";
		public static final String E_FILED = "eFiled";
	
		public static final String GSTR1_MASTER_ERROR_REPORT_PROC_NAME = "uspGSTR1ErrorInfoMasterXml"; 
		public static final String GSTR2_MASTER_ERROR_REPORT_PROC_NAME = "";
		
		public static final String REGULAR="REGULAR";
	    public static final String TDS="TDS";
	    public static final String TCS="TCS";
	    public static final String ISD="ISD";
	    public static final int GENRNATE_DUMP_REPORT_PROC_INPUT_COUNT=3;
	    
	    public static final String GSP_OTP= "GSP_OTP";
		public static final String APIGW_USERNAME="APIGW_USERNAME";
		public static final String APIGW_PASSWORD="APIGW_PASSWORD";
		public static final String APIGW_APIKEY="APIGW_APIKEY";
		public final static String EXPIRES_IN="expires_in";
		public final static String GSP_DIGIGST_USERNAME="digigst_username"; 
		public final static String REFRESH_TOKEN="refresh_token";
		public final static String ACCESS_TOKEN="access_token";
		public final static String GSP_USERDETAILS="GSP_USERDETAILS";
		public static final String GROUP_CODE= "groupCode";
		public static final String GSP_AUTHTOKEN="GSP_AUTHTOKEN";
		public static final String GSP_REFRESH_TOKEN = "GSP_REFRESH_TOKEN";
		public final static String API_KEY="api_key";
		public final static String API_SECRET ="api_secret";
		
    	public static final String FILE_STATUS_SAVED="SAVED";
    	
    	public static final String WRK_SUB="Workflow approval request";
    	public static final String WRK_BODY="Please look in to the approval request";
		
    	public static final String EMAIL_TEMPLATE_INV_MAPPING="EmailInvoiceMappingSheet.vm";
    	public static final String EMAIL_TEMPLATE_DETERMINATION_SHEET="DeterminationSheetReady.vm";
		public static final String ENTITY_HIERARCHY_DETAILS = "ENTITY_HIERARCHY_DETAILS";
    	public static final String DETERMINATION_SUMMARY_DATA = "determinationSummaryJson";
    	public static final String PREGST_TURNOVER_DATA = "preGSTTurnOverJson";
    	public static final String CATEGORY = "Category";
        public static final String SUB_CATEGORY = "SubCategory";
		public static final String ORG_DOC_DATE = "ORG_DOC_DATE";
		public static final String INWARD_HEADERS = "csv.header.inwardHeaders";
		public static final String OUTWARD_HEADERS = "csv.header.outwardHeaders";
		public static final String EMPTY = "";
		public static final String COMMA = ",";
		
		public static final String STORE_ACC_NAME = "STORE_ACC_NAME";
        public static final String STORE_ACC_KEY = "STORE_ACC_KEY";
		public static final String GROUP_CONFIG_KEY="CONFIG_";
		public static final String DOMAIN_NAME="DOMAIN_NAME";
		public static final String GROUP_DOMAIN_KEY="DOMAIN_"; 
        
        public static final String CREDIT_REGISTER_SUMMARY_SHEET = "Summary Of CN";
        public static final String CREDIT_REGISTER_DETAILS_SHEET = "Credit_Note_Detailed";
        public static final String DEBIT_REGISTER_SUMMARY_SHEET = "Summary_Of_DN";
		public static final String DEBIT_REGISTER_DETAILS_SHEET = "Debit_Note_Detailed";
        
        public static final String  FOLDER_STRUCT_SMART_REPORT = "folder.structure.SmartReport.processed";
		public static final String APIGW_APISECRET="APIGW_APISECRET";
        public static final String STATUSCODE = "gsp_status_cd";
		public static final String EXPIRY = "expiry"; 
		
		public static final String GSTR1SUBMITSTARTDATE="1";
		public static final String GSTR1SUBMITENDDATE="31";
		public static final String INVALIDDATE="InvalidDate";
		public static final String STAGE_BIFURCATION = "BIF";
		public static final String ISMANDATORY = "N";
		public static final String OUTWARDATTRIBUTE = "OutwardAttribute";
		public static final String INWARDATTRIBUTE = "InwardAttribute";
		public static final String MANDATORYATTRIBUTES = "MandatoryAttribute";
		public static final String SUBMITTED_SMARTREPORT = "Submitted";
		public static final String FY_TURNOVER = "FY_TURNOVER";
		public static final String QY_TURNOVER = "QY_TURNOVER";
		public static final String OUTWARD_SUPPLIES_FILE = "outwardsupplies";
		public static final String INWARD_SUPPLIES_FILE = "inwardsupplies";
		public static final String STOCK_TRANSFER_FILE = "stocktransfer";
		public static final String REVERSE_CHARGE_FILE = "reversecharge";
		public static final String NODATA_SMARTREPORT = "No Data Available";
		public static final String FETCHING_DATA_SMARTREPORT = "Fetching Data";
		public static final String MANDATORYINWARDATTRIBUTES = "MandatoryInwardAttribute"; 
		public static final String REVERSE_CHARGE_Category = "Reversecharge Category";
		public static final String PATH_ERROR_SMARTREPORT = "FilePathNotFound";
		public static final String DATA_ERROR_SMARTREPORT = "InvalidParams";
		
		public static final String RECON_REPORT_RESPONSE_CONSOLIDATED_METADATA = "RECON_REPORT_RESPONSE_CONSOLIDATED_METADATA";
		public static final String GSTR2RECON_RESPONSE = "GSTR2RR";
		public static final String RECON = "RECON";
		public static final String GSTR2_RECON_REPORT_RESPONSE_PROC = "uspUpdateReconResponse";
		public static final String GSTR2_RECON_REPORT_RESPONSE_PROC_INPUT_COUNT="5";
		public static final String GSTR2SUBMITSTARTDATE="1";
		public static final String GSTR2SUBMITENDDATE="31";
		public static final String RETFILE = "RETFILE";
		public static final String GSTR2A_DOWNLOADED_STATUS = "DATA_RECEIVED";
		public static final String TOKEN_RECEIVED = "TOKEN_RECEIVED";
		public static final String RECONSTATE = "DATA_RECEIVED";
		public static final String GSTR2A_LINK_EXPIRED = "LINK_EXPIRED";
		 public static final String GSTR2A_FAILED = "FAILED";
		public static final String FILEDETAIL_JOB = "getGstr2aFileDetailsFromGstnJob";
		public static final String FILEDETAIL_API = "FILEDET";
		public static final String FILEDOWNLOAD_API = "FILE_DOWNLOAD";
		public static final String SCHEDULE_TENANT_SIMPLE_TRIGGER = "asp-scheduleTenantSimpleTrigger";
		public static final String GSTR2A_GSTIN = "gstin";
		public static final String GSTR2A_RETPERIOD = "retPeriod";
		public static final String GSTR2_STATUS = "status";
		public static final String GSTR2_RECON_STATUS = "reconStatus";
		public static final String GSTR2_LAST_RECON_DATE = "lastReconReq";
		public static final String INVOICE_KEY = "InvoiceKey";
		public static final String RESPONSE = "YourResponse";
		public static final String RECON_STATUS = "RECON_COMPLETE";
		public static final String RECON_INPROGRESS = "RECON_INPROGRESS";
		public static final String MATCHED_REPORT = "MATRR";
		public static final String MATCHED_REPORT_ASP ="MATRRASP";
		public static final String MISSING_REPORT = "MISSRR";
		public static final String ADDITIONAL_REPORT = "ARR";
		public static final String MISMATCH = "MISMRR";
		public static final String RECON_MATCHED_REPORT_TYPE = "MAT";
		public static final String RECON_MATCHED_REPORT_ASP_TYPE ="ASP";
		public static final String RECON_MISSING_REPORT_TYPE = "MIS";
		public static final String RECON_ADDITIONAL_REPORT_TYPE = "ADD";
		public static final String RECON_MISMATCH_REPORT_TYPE = "MIM";
		public static final String RECON_MATCHED_REPORT = "Matched";
		public static final String RECON_MISSING_REPORT = "Missing";
		public static final String RECON_ADDITIONAL_REPORT = "Additional";
		public static final String RECON_MISMATCH_REPORT = "Mismatch";		
		public static final String FOLDER_STRUCT_RECON_REPORT = "folder.structure.recon.report";
		public static final String DSC = "DSC";
		public static final String APISIGN_GSTR1_OTP_ENDPOINT ="aspendpoint.gsp.otp";
		public static final String APISIGN_GSTR1_OTP_VERIFY_ENDPOINT ="aspendpoint.gsp.otp.verify";
		public static final String GSTR2_RECON_RETURN_TYPE ="GSTR2";
		public static final String GSTR6_RECON_RETURN_TYPE = "GSTR6";
		
		public static final String INVOICE_TYPE = "InvoiceType";
		public static final String GSTIN_ID = "gstin";
		public static final String LoadId="loadId";
		public static final String ACTION="action";
		public static final String GSTR2A_FAILED_B2B="FAILED_B2B";
		public static final String GSTR2A_FAILED_CDN="FAILED_CDN";
		public static final String GSTR2A_NO_DETAILS_CODE="RET13508";
		public static final String GSTR2A_NO_INVOICES_CODE="RET13509";
		public static final String GSTR2A_NO_RECORDS_CODE="RET13510";
		public static final String EMPTY_B2B = "EMPTY_B2B";
		public static final String EMPTY_CDN = "EMPTY_CDN";
		public static final String GSTR2_GENERATED_RECON_REPORTS = "generatedReconReports";
		public static final String GENERATE = "GENERATE";
		public static final String BAL = "BAL";
		public static final String MISMATCHED = "Mismatch,";
		public static final String MATCHED = "Matched,";
		public static final String MATCHEDASP = "Matched Asp,";
		public static final String ADDITIONAL = "Additional,";
		public static final String MISSING = "Missing,";
		
		
		//gstr3
		public static final String GSTR3 = "/gstr3";
		public static final String SUBMIT_INTEREST = "RETACCEPT";
		public static final String SETOFF_LIABILITY = "RETOFFSET";
		public static final String SUBMIT_GSTR3 = "RETSUBMIT";
		public static final String GENERATE_GSTR3 = "GENERATE";
		public static final String GSTR3_GET_FINAL_Y = "Y";
        public static final String GSTR3_GET_FINAL_N = "N";
        
        public static final String GSPGW_RESTAPI_LEDGER="gspgw-restapi.ledger";
		
		 public static final String SMART_REPORT_JOB_NAME="createSmartReportForEachGroupJob"; 
		 public static final String SMART_REPORT_GSTN_FETCH_JOB_NAME="createSmartReportForEachGstnGroupJob"; 
        public static final String BATCH_API_HOST = "asp-restbatchapi.host";
        public static final String GSTR1_TRANSACTIONAL_SAVE_JOB_NAME ="savetransactionalGSTR1Gstn";
        public static final String GSTR2_TRANSACTIONAL_SAVE_JOB_NAME ="savetransactionalGSTR2Gstn";
        public static final int retryCount=3;
        public static final String CHUNKSIZE= "5242880";
    	public static final String EMAIL_TEMPLATE_TECH_ERROR="GstinTechErrorEmailTemplate.vm";
		public static final String EMAIL_TEMPLATE_AUTH_ERROR="GstinAuthErrorEmailTemplate.vm";
		public static final String HSN = "HSN";
		public static final String TXI = "TXI";
		public static final String ITCRVRSL = "ITCRVRSL";
		public static final String ALL = "ALL";
		public static final String TBLRETURNTYPE_RECORDTYPEMAPPING = "TblReturnTypeRecordTypeMapping";
		public static final String B2BCL = "B2BCL";
		public static final String TXR = "TXR";
		public static final String IS = "IS";
		public static final String TABLE_TYPE = "tableType";
		public static final String DISTRIBUTION_TURNOVER_DATA = "dtTurnOverJson";
		public static final String DATA_ERROR_PROCESSING_SMARTREPORT = "Generation_Failed";
		public static final String DATA_ERROR_REQUEST_SMARTREPORT = "Request_Failed";
		
		public static final String CLIENT_IP = "ip-usr";
		public static final String CO_RELATION_ID = "co-relation-id";
		public static final String USER_PRINCIPAL = "user-principal";
		public static final String UNKNOWN_USER = "UNKNOWN_USER";
		public static final String REQUEST_TENANT_HEADER ="X-TENANT-ID";

		
		// 1FF
		public static final String SMART_REPORT_RECORDS_SBMITTED_TO_GSTN = "RecordsSubmittedToGSTN";
		public static final String SMART_REPORT_RECORDS_SBMITTED_TO_GSTN_DETAILED = "RecordsSubmittedToGSTNDetailed";
		public static final String SMART_REPORT_RECORDS_SBMITTED_TO_GSTN_SUMMARY = "RecordsSubmittedToGSTNSummary";
		public static final String GSTR1FF = "GSTR1FF";
		public static final String FILING_RECORD_TYPE_GSTR1FF = "GSTR1FF";
		public static final String FILING_RECORD_TYPE_GSTR2FF_DONE = "GSTR1FF_DONE";
	 
		public static final String GSTR1FF_B2B= "GSTR1FF_B2B";
		public static final String GSTR1FF_B2BA= "GSTR1FF_B2BA";
		public static final String GSTR1FF_B2CL= "GSTR1FF_B2CL";
		public static final String GSTR1FF_B2CLA= "GSTR1FF_B2CLA";
		public static final String GSTR1FF_B2CS= "GSTR1FF_B2CS";
		public static final String GSTR1FF_B2CSA= "GSTR1FF_B2CSA";
		public static final String GSTR1FF_CDNR= "GSTR1FF_CDNR";
		public static final String GSTR1FF_CDNRA= "GSTR1FF_CDNRA";
		//public static final String GSTR1FF_Nil Rated Supplies
		public static final String GSTR1FF_EXP = "GSTR1FF_EXP";
		public static final String GSTR1FF_EXPA = "GSTR1FF_EXPA";
		public static final String GSTR1FF_AT = "GSTR1FF_AT";
		public static final String GSTR1FF_ATA = "GSTR1FF_ATA";
		public static final String GSTR1FF_TXP = "GSTR1FF_TXP";
		//public static final String GSTR1FF_HSN Summary details
		
		public static final String GSTR6_EMAIL_PROC = "uspGetISDGstinUser";
		 //GSTR6A
        public static final String GSTR_GSTIN = "gstin";
		public static final String GSTR_RETPERIOD = "retPeriod";
		public static final String GSTR_FAILED = "FAILED";
		public static final String GSTR_FAILED_B2B="FAILED_B2B";
		public static final String GSTR_FAILED_CDN="FAILED_CDN";
		public static final String GSTR6RECON_RESPONSE = "GSTR6RR";
		public static final String GSTR6_RECON_REPORT_RESPONSE_PROC = "uspUpdateGstr6ReconResponse";
		public static final String GSTR_RECON_REPORT_RESPONSE_PROC_INPUT_COUNT="5";
		
		//GSTN error report
		public static final String EXCEPTION_AT_GSTN_ERROR = "EXCEPTION_AT_GSTN_ERROR";
}	