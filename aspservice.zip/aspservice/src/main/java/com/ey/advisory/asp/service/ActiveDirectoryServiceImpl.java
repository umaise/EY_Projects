/**
 * 
 */
package com.ey.advisory.asp.service;

import java.util.Properties;
import java.util.logging.Logger;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

/**
 * @author Uma.Chandranaik
 *
 */
@Service("activeDirectory")
@PropertySource("classpath:AdConfig.properties")
public class ActiveDirectoryServiceImpl implements ActiveDirectoryService {

	// Logger
	private static final Logger LOG = Logger.getLogger(ActiveDirectoryServiceImpl.class.getName());

	// required private variables
	private Properties properties;
	private DirContext dirContext;
	private SearchControls searchCtls;
	private String[] returnAttributes = { "sAMAccountName", "givenName", "cn", "mail", "objectGUID",
			"telephoneNumber" };
	private String domainBase;

	@Value("${ad.baseFilter}")
	private String baseFilter;

	@Value("${ad.domainController}")
	private String domainController;

	@Value("${ad.initialContextFactory}")
	private String initialContextFactory;

	@Value("${ad.providerUrl}")
	private String providerUrl;

	@Value("${ad.securityAuth}")
	private String securityAuth;

	@Value("${ad.securityPrincipal}")
	private String securityPrincipal;
	
	private String domainRoot = "DC=INTRIHVDC003,DC=EYINNOVATION,DC=NET";//Need to change as per AD domain rot
	private String domainName = "EMEA.NET"; //Need to change

	public ActiveDirectoryServiceImpl() {
		LOG.info("ActiveDirectoryServiceImpl");
	}

	/**
	 * constructor with parameter for initializing a LDAP context
	 * 
	 * @param username
	 *            a {@link java.lang.String} object - username to establish a
	 *            LDAP connection
	 * @param password
	 *            a {@link java.lang.String} object - password to establish a
	 *            LDAP connection
	 * @param domainController
	 *            a {@link java.lang.String} object - domain controller name for
	 *            LDAP connection
	 */
	@Override
	public DirContext intitializeActiveDirectory(String userName, String password) {
		dirContext = null;
		properties = new Properties();

		properties.put(Context.INITIAL_CONTEXT_FACTORY, initialContextFactory);
		properties.put(Context.PROVIDER_URL, providerUrl);
		properties.put(Context.SECURITY_AUTHENTICATION, securityAuth);
		properties.put(Context.SECURITY_PRINCIPAL, userName + securityPrincipal);
		properties.put(Context.SECURITY_CREDENTIALS, password);
		// to supress Unprocessed Continuation Reference(s)
		// initializing active directory LDAP connection
		try {
			dirContext = new InitialDirContext(properties);
		} catch (NamingException e) {
			LOG.severe(e.getMessage());
		}

		// default domain base for search
		domainBase = getDomainBase(domainController);

        return dirContext;
	}

	/**
	 * creating a domain base value from domain controller name
	 * 
	 * @param base
	 *            a {@link java.lang.String} object - name of the domain
	 *            controller
	 * @return a {@link java.lang.String} object - base name for eg.
	 *         DC=name,DC=com
	 */
	private static String getDomainBase(String base) {
		char[] namePair = base.toUpperCase().toCharArray();
		String dn = "DC=";
		for (int i = 0; i < namePair.length; i++) {
			if (namePair[i] == '.') {
				dn += ",DC=" + namePair[++i];
			} else {
				dn += namePair[i];
			}
		}
		return dn;
	}

	/**
	 * search the Active directory by username/email id for given search base
	 * 
	 * @param searchValue
	 *            a {@link java.lang.String} object - search value used for AD
	 *            search for eg. username or email
	 * @param searchBy
	 *            a {@link java.lang.String} object - scope of search by
	 *            username or by email id
	 * @param searchBase
	 *            a {@link java.lang.String} object - search base value for
	 *            scope tree for eg. DC=name,DC=com 
	 * @return search result a {@link javax.naming.NamingEnumeration} object -
	 *         active directory search result
	 * @throws NamingException
	 */
	@Override
	public NamingEnumeration<SearchResult> searchUser(DirContext dirContext,String searchValue, String searchBy, String searchBase)
			throws NamingException {

		// initializing search controls
		searchCtls = new SearchControls();
		searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		searchCtls.setReturningAttributes(returnAttributes);
		
		String filter = getFilter(searchValue, searchBy);
		String base = (null == searchBase) ? domainBase : getDomainBase(searchBase); 

		return dirContext.search(base, filter, searchCtls);
	}

	/**
	 * closes the LDAP connection with Domain controller
	 */
	@Override
	public void closeLdapConnection() {
		try {
			if (dirContext != null)
				dirContext.close();
		} catch (NamingException e) {
			LOG.severe(e.getMessage());
		}
	}

	/**
	 * active directory filter string value
	 * 
	 * @param searchValue
	 *            a {@link java.lang.String} object - search value of
	 *            username/email id for active directory
	 * @param searchBy
	 *            a {@link java.lang.String} object - scope of search by
	 *            username or email id
	 * @return a {@link java.lang.String} object - filter string
	 */
	private String getFilter(String searchValue, String searchBy) {
		String filter = this.baseFilter;
		if (("email").equals(searchBy)) {
			filter += "(mail=" + searchValue + "))";
		} else if (("username").equals(searchBy)) {
			filter += "(samaccountname=" + searchValue + "))";
		}
		return filter;
	}

	@Override
	public void updateUser() {
		ModificationItem[] mods = new ModificationItem[1];
		mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
				new BasicAttribute("telephoneNumber", "+918033093998"));
		try {
			this.dirContext.modifyAttributes(domainRoot, mods);
		} catch (NamingException e) {
			LOG.info("" + e);
		}
	}

	@Override
	public boolean addUser(String userName, String firstName, String lastName, String password) throws NamingException {

		String groupName="OU=GST,OU=GSS Kerala,DC=EYINNOVATION,DC=NET";//need to change as per AD group
		// Create a container set of attributes
		Attributes container = new BasicAttributes();

		// Create the objectclass to add
		Attribute objClasses = new BasicAttribute("objectClass");
		objClasses.add("top");
		objClasses.add("person");
		objClasses.add("organizationalPerson");
		objClasses.add("user");

		// Assign the username, first name, and last name
		Attribute sAMAccountName = new BasicAttribute("sAMAccountName", userName);
		Attribute principalName = new BasicAttribute("userPrincipalName", userName + "@" + domainName);
		Attribute givenName = new BasicAttribute("givenName", firstName);
		Attribute sn = new BasicAttribute("sn", lastName);
		Attribute uid = new BasicAttribute("uid", userName);

		
		  //some useful constants from lmaccess.h
        int UF_ACCOUNTDISABLE = 0x0002;
        int UF_PASSWD_NOTREQD = 0x0020;
        int UF_NORMAL_ACCOUNT = 0x0200;
        int UF_PASSWORD_EXPIRED = 0x800000;
        
      //Note that you need to create the user object before you can
        //set the password. Therefore as the user is created with no 
        //password, user AccountControl must be set to the following
        //otherwise the Win2K3 password filter will return error 53
        //unwilling to perform.

        container.put("userAccountControl",Integer.toString(UF_NORMAL_ACCOUNT + UF_PASSWD_NOTREQD + UF_PASSWORD_EXPIRED+ UF_ACCOUNTDISABLE));

		// Add these to the container
		container.put(objClasses);
		container.put(sAMAccountName);
		container.put(principalName);
		container.put(sn);
		container.put(givenName);
		container.put(uid);
	
		// Create the context
        Context result = dirContext.createSubcontext("CN="+userName+","+groupName, container);
        LOG.info("Created disabled account for: " + userName);


		// Create the entry
		try {
			//this.dirContext.createSubcontext(getUserDN(cnValue, organisationUnit), container);
			return true;
		} catch (Exception e) {
			LOG.info("" + e);
			return false;
		}
	}
	
	/**
	 * Update User Password in Microsoft Active Directory
	 * 
	 * @param username
	 * @param password
	 */
	public void updateUserPassword(String username, String password) {
		try {
			LOG.info("updating password...\n");
			String quotedPassword = "\"" + password + "\"";
			char unicodePwd[] = quotedPassword.toCharArray();
			byte pwdArray[] = new byte[unicodePwd.length * 2];
			for (int i = 0; i < unicodePwd.length; i++) {
				pwdArray[i * 2 + 1] = (byte) (unicodePwd[i] >>> 8);
				pwdArray[i * 2 + 0] = (byte) (unicodePwd[i] & 0xff);
			}
			LOG.info("encoded password: ");
			for (int i = 0; i < pwdArray.length; i++) {
				LOG.info(pwdArray[i] + " ");
			}
			ModificationItem[] mods = new ModificationItem[1];
			mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("UnicodePwd", pwdArray));
			this.dirContext.modifyAttributes("cn=" + username + domainRoot, mods);
		} catch (Exception e) {
			LOG.info("update password error: " + e);
		}
	}
	
	 public void deleteUser(String username){
	        String dn ="CN="+username+",OU=GST,OU=GSS Kerala,DC=EYINNOVATION,DC=NET";
	        try{
	            dirContext.destroySubcontext(dn);
	            //update the group
	        }
	        catch(Exception e){
	        	LOG.info("Exception while removing user from DL" + e);
	        }
	    }  
}
