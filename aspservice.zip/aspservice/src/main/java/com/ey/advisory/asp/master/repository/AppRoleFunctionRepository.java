/**
 * 
 */
package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.advisory.asp.master.domain.AppRoleFunction;
import com.ey.advisory.asp.master.domain.Role;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface AppRoleFunctionRepository extends JpaRepository<AppRoleFunction, Long> {
	
	public List<AppRoleFunction> findByRole(Role roleId);

}
