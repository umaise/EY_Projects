package com.ey.advisory.asp.master.service;

import java.util.LinkedList;

import com.ey.advisory.asp.master.domain.GSTR6ReconResponseConsolidatedMetadata;

public interface GSTR6ReconResponseConsolidatedService {
	public LinkedList<GSTR6ReconResponseConsolidatedMetadata> getMetadataBySheetName(String sheetName);
}
