/**
 * 
 */
package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

/**
 * @author Sadhana.Holla
 *
 */
@Entity
@Table(name = "tblGroupConfig", schema = Constant.MASTER_SCHEMA)
public class GroupConfig implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GroupConfigId")
	private Long groupConfigId;
	
	@Column(name = "GroupCode",nullable=false)
	private String groupCode;
	@Column(name = "ConfigCode")
	private String configCode;
	@Column(name = "ConfigValue")
	private String configValue;
	@Column(name = "IsActive")
	private Boolean isActive;
	
	
	public Long getGroupConfigId() {
		return groupConfigId;
	}
	public void setGroupConfigId(Long groupConfigId) {
		this.groupConfigId = groupConfigId;
	}
	
	
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	
	
	public String getConfigCode() {
		return configCode;
	}
	public void setConfigCode(String configCode) {
		this.configCode = configCode;
	}
	
	
	public String getConfigValue() {
		return configValue;
	}
	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}
	
	
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	

}
