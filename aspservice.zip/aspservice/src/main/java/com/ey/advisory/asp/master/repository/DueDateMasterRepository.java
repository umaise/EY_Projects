package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.DueDateMaster;


@Repository
@Transactional
public interface DueDateMasterRepository extends JpaRepository<DueDateMaster, Long>{
	@Override
	public List<DueDateMaster> findAll();
	

}


