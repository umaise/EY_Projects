package com.ey.advisory.asp.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity(name="TaxPayerDetailsGstr2")
@Table(name = "TaxPayerDetails")
public class TaxPayerDetailsGstr2 implements Serializable {

	private static final long serialVersionUID = 1L;


	private Long rowNum;

	
	private String taxPayerGSTIN;

	
	private String ttaxPayerName;

	
	private String fyMonth;
		
	
	private String fyYear;

	
	private Float aggTurnoverPrevFY;

	
	private int gstinIdFK;
	
	

	@Column(name = "TaxPayer_GSTIN")
	public String getTaxPayerGSTIN() {
		return taxPayerGSTIN;
	}

	@Column(name = "TaxPayer_Name")
	public String getTtaxPayerName() {
		return ttaxPayerName;
	}

	@Column(name = "FY_Month")
	public String getFyMonth() {
		return fyMonth;
	}

	@Column(name = "FY_Year")
	public String getFyYear() {
		return fyYear;
	}

	@Column(name = "Agg_Turnover_PrevFY")
	public Float getAggTurnoverPrevFY() {
		return aggTurnoverPrevFY;
	}

	@Column(name = "GSTIN_ID_fk")
	public int getGstinIdFK() {
		return gstinIdFK;
	}

	
	public void setTaxPayerGSTIN(String taxPayerGSTIN) {
		this.taxPayerGSTIN = taxPayerGSTIN;
	}

	public void setTtaxPayerName(String ttaxPayerName) {
		this.ttaxPayerName = ttaxPayerName;
	}

	public void setFyMonth(String fyMonth) {
		this.fyMonth = fyMonth;
	}

	public void setFyYear(String fyYear) {
		this.fyYear = fyYear;
	}

	public void setAggTurnoverPrevFY(Float aggTurnoverPrevFY) {
		this.aggTurnoverPrevFY = aggTurnoverPrevFY;
	}

	public void setGstinIdFK(int gstinIdFK) {
		this.gstinIdFK = gstinIdFK;
	}

	@Id
	@Column(name = "ROWNUM")
	public Long getRowNum() {
		return rowNum;
	}

	public void setRowNum(Long rowNum) {
		this.rowNum = rowNum;
	}

	
	

	
	
	
	
}
