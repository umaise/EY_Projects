package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblGSTR2ReconResponseConsolidatedMetadata", schema = "metadata")
public class GSTR6ReconResponseConsolidatedMetadata implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ResponseID")
	private Integer responseID;
	
	@Column(name="ColumnName")
	private String columnName;
	
	@Column(name="ColumnCode")
	private String columnCode;
	
	@Column(name="DataType")
	private String dataType;
	
	@Column(name="ColumnOrderNo")
	private Integer columnOrderNo;
	
	@Column(name="ReconResponseType")
	private String reconResponseType;

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnCode() {
		return columnCode;
	}

	public void setColumnCode(String columnCode) {
		this.columnCode = columnCode;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public Integer getColumnOrderNo() {
		return columnOrderNo;
	}

	public void setColumnOrderNo(Integer columnOrderNo) {
		this.columnOrderNo = columnOrderNo;
	}

	public String getReconResponseType() {
		return reconResponseType;
	}

	public void setReconResponseType(String reconResponseType) {
		this.reconResponseType = reconResponseType;
	}

	public Integer getResponseID() {
		return responseID;
	}

	public void setResponseID(Integer responseID) {
		this.responseID = responseID;
	}
	
	
}
