/**
 * 
 */
package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.GroupADDomainConfigDomain;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface GroupADDomainConfigService {

	public List<GroupADDomainConfigDomain> findGroupsUsingDomain(String domain);
	

	public List<Long> getGroupIdsForDomains(String userDomains);
	
	
	public GroupADDomainConfigDomain save(GroupADDomainConfigDomain groupADDomainConfigDomain);
	
	public List<GroupADDomainConfigDomain> findByGroupId(Long groupId);
	
}
