/**
 * 
 */
package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

/**
 * @author Nitesh.Tripathi
 *
 */
@Entity
@Table(name = "tblStates",schema=Constant.MASTER_SCHEMA)
public class States implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "StateID")
	private long stateID;
	
	@Column(name = "StateName")
	private String stateName;
	
	@Column(name = "StateIdentifier")
	private String stateIdentifier;
	
	@Column(name = "Statecode")
	private String statecode;
	
	@Column(name = "IsUT")
	private boolean isUT;

	/**
	 * @return the stateID
	 */
	public long getStateID() {
		return stateID;
	}

	/**
	 * @param stateID the stateID to set
	 */
	public void setStateID(long stateID) {
		this.stateID = stateID;
	}

	/**
	 * @return the stateName
	 */
	public String getStateName() {
		return stateName;
	}

	/**
	 * @param stateName the stateName to set
	 */
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	/**
	 * @return the tIN
	 */
	
	/**
	 * @return the statecode
	 */
	public String getStatecode() {
		return statecode;
	}

	/**
	 * @param statecode the statecode to set
	 */
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}

	/**
	 * @return the isUT
	 */
	public boolean isUT() {
		return isUT;
	}

	/**
	 * @param isUT the isUT to set
	 */
	public void setUT(boolean isUT) {
		this.isUT = isUT;
	}

	public String getStateIdentifier() {
		return stateIdentifier;
	}

	public void setStateIdentifier(String stateIdentifier) {
		this.stateIdentifier = stateIdentifier;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "States [stateID=" + stateID + ", stateName=" + stateName + ",stateIdentifier="+stateIdentifier+ ", statecode=" + statecode
				+ ", isUT=" + isUT + "]";
	}

}
