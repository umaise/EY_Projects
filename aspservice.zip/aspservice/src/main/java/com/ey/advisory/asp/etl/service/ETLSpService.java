package com.ey.advisory.asp.etl.service;

import java.util.List;


public interface ETLSpService {
		
	String executeStoredProcedure(String storedProcName);
	String executeStoredProcedure(String storedProcSchema, String storedProcName, int inputParamsCount, List<String> inputParamsList);
	List<Object[]> executeSPReturnList(String storedProcName);
	public String executeSPSingleResult(String storedProcSchema, String storedProcName, int inputParamsCount, List<String> inputParamsList);

}
