//package com.ey.advisory.asp.service;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.io.UnsupportedEncodingException;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Properties;
//
//import org.apache.http.HttpHost;
//import org.apache.http.HttpResponse;
//import org.apache.http.client.ClientProtocolException;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.conn.params.ConnRouteParams;
//import org.apache.http.entity.StringEntity;
//import org.apache.http.impl.client.DefaultHttpClient;
//import org.codehaus.jackson.JsonGenerationException;
//import org.codehaus.jackson.map.JsonMappingException;
//import org.codehaus.jackson.map.ObjectMapper;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpMethod;
//import org.springframework.stereotype.Component;
//
//import com.ey.advisory.asp.master.domain.GSTIN;
//import com.ey.advisory.asp.master.domain.User;
//import com.ey.advisory.asp.util.RestUtility;
//
//@Component
//public class MailServiceImpl implements MailService {
//	
//	@Autowired
//	private RestUtility restClientUtil;
//
//	@Override
//	public void sendMailProcessGstr1(String gstin, String selMonth, String selYear) throws Exception {
//
//		// reads transaction ID
//		String transID = "kjifuyfyu";
//		if(transID!= null){
//             String revMailId  = "" ;
//			String subject = "ACKNOWLEDGEMENT : GSTR1 uploaded succesfully for GSTIN : " + gstin + " for the Period : " + selMonth+ "/" + selYear;
//			 
//			String body = "<html><BODY><p>Dear Tax Payer,</p><p>We acknowledge receipt of your GSTR1 filing request for GSTIN <b>" +gstin +"</b> for the Period <b>" + selMonth + "/" +selYear
//					+ " </b> with our Portal. Your GSTR1 is underway and will be successfully returned to you.</p><p>DISCLAIMER :*** This is an automatically generated email, please do not reply ***</p></BODY></html>";
//			sendEmail(revMailId, subject, body);
//			}
//		}
//	
//	@Override
//	public void sendMailESign(User currentUser , GSTIN gstin, String selMonth, String selYear) throws Exception {
//
//		// reads transaction ID
//		String transID = "test";
//		if(transID!= null){
//             String revMailId  = "";
//			String username = currentUser.getFirstName() ;
//			String credentials = username + currentUser.getLastName();
///*			DefaultHttpClient httpClient = new DefaultHttpClient();
//			
//			HttpPost postReq = new HttpPost("http://inbanvmdwb02.mea.ey.net/MailAPI/api/sendmail");*/
//			
//			String subject = "GSP GSTR1 Acknowledgement: GSTR1 (Period: " + selMonth + "/" +selYear+ ") successfully received for GSTIN: 23324" ;
//			String body = "Dear "+username+","+
//					"<p>We acknowledge receipt of your digitally signed GSTR1 filing request for GSTIN 23324 "  + 
//					" (Taxpayer Name:  Taxpayer ) for the Period "+selMonth +"/" +selYear+   //gstin.getLegalEntity().getLegalEntityName() 
//					" with our Portal at: " +new Date()+ ". The GSTR1 was signed by you " +credentials+"." +
//					"<p>The GSTR1 will be submitted to GSTN shortly, and we will notify you of the processing by GSTN once we receive GSTN�s inputs. We anticipate that GSTN should complete this processing within XX hours."+
//					"<p>Regards," +
//					 "<p>EY GST Suvidha Provider Team." +
//					 "<p>*** This is a system generated email. Please do not reply. *** "+
//					 "<p>[Mail sent at: "+new Date()+ "]";
//			sendEmail(revMailId, subject, body);
//			}
//		}
//	/*@Override
//	public String sendMailTranactionId(User user ,GSTIN gstn , String selYear , String month , GSTR1SummaryDto dto) throws Exception{
//		String transId = "test";
//if(transId!= null){
//			
//			 String revMailId = "";
//			String username = user.getFirstName() ;
//			DefaultHttpClient httpClient = new DefaultHttpClient();
//			
//			HttpPost postReq = new HttpPost("http://inbanvmdwb02.mea.ey.net/MailAPI/api/sendmail");
//			
//			String subject = "GSTR1 Submission to GSTN" ;
//			String body = "Dear "+username+","+ 
//					"<p>We successfully submitted GSTR1 data for period: " + selYear + "/" +month+ ", " 
//					+"<p>below mentioned is your transaction id \n"
//					+ "<p>Txn Id: " +dto.getTransactionId() +
//					"<p>Regards," +
//					 "<p>EY GST Suvidha Provider Team." +
//					 "<p>*** This is a system generated email. Please do not reply. *** "+
//					 "<p>[Mail sent at: "+new Date()+ "]";
//			sendEmail(revMailId, subject, body);
//			}
//		
//		return null;
//		
//	}
//*/
//
//	@Override
//	public void fileGSTR1(String toAddress, String gstin, String selMonth, String selYear) throws Exception {
//		String subjectGSTR1 = "ACKNOWLEDGEMENT: GSTR1 filed succesfully for GSTIN : " + gstin + " for the Period : " + selMonth+ "/" + selYear;
//        String bodyGSTR1 = "<html><BODY><p>Dear Tax Payer,</p><p>We acknowledge receipt of your GSTR1 filing request for GSTIN <b>" +gstin +"</b> for the Period <b>" + selMonth + "/" +selYear                                                                                + " </b> with our Portal. Your GSTR1 is underway and will be successfully returned to you.</p></BODY></html>"; 
//       sendEmail(toAddress, subjectGSTR1, bodyGSTR1);
//	}
//	
//	 @Override
//	    public void fileGSTR2(String  toAddress , String gstin, String selMonth, String selYear) throws Exception {
//	         String subjectGSTR2 = "ACKNOWLEDGEMENT: GSTR2 filed succesfully for GSTIN : " + gstin + " for the Period : " + selMonth+ "/" + selYear;
//	         String bodyGSTR2 = "<html><BODY><p>Dear Tax Payer,</p><p>We acknowledge receipt of your GSTR2 filing request for GSTIN <b>" +gstin +"</b> for the Period <b>" + selMonth + "/" +selYear
//	                                                                                                    + " </b> with our Portal. Your GSTR2 is underway and will be successfully returned to you.</p></BODY></html>"; 
//	         sendEmail(toAddress, subjectGSTR2, bodyGSTR2);
//	    }
//
//	private void sendEmail(String toAddress, String subject, String body)  throws Exception{
//		restClientUtil.executeRestCallGSTNPost(null,fileGstr1ReqPayload(toAddress,subject,body),null,null, HttpMethod.POST,false);	
//	}
//	private String fileGstr1ReqPayload(String toAddress,String subject,String body) throws JsonGenerationException, JsonMappingException, IOException{
//		Properties prop = new Properties();
//        InputStream input =  this.getClass().getClassLoader().getResourceAsStream("/DigioRestConfig.properties");
//        prop.load(input);
//        String revMailId  = prop.getProperty("receiverMailId") ;
//		Map<String, String> paramMap = new HashMap<String,String>();
//		paramMap.put("From", "EY_GST@in.ey.com");
//		paramMap.put("To", revMailId);
//		paramMap.put("Subject",subject);
//		paramMap.put("Body", body);
//		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
//		return mapAsJson;
//		
//	}
//
//	@Override
//	public void sendMailProcessGstr2(String toAddress, String gstin, String selMonth, String selYear) throws Exception {
//		String subjectGSTR2 = "ACKNOWLEDGEMENT: GSTR2 uploaded succesfully for GSTIN : " + gstin + " for the Period : " + selMonth+ "/" + selYear;
//		String bodyGSTR2 = "<html><BODY><p>Dear Tax Payer,</p><p>We acknowledge receipt of your GSTR2 uploading request for GSTIN <b>" +gstin +"</b> for the Period <b>" + selMonth + "/" +selYear
//							+ " </b> with our Portal. Your GSTR2 is underway and will be successfully returned to you.</p></BODY></html>";  
//		
//		sendEmail(toAddress, subjectGSTR2, bodyGSTR2);
//		
//	}
//
//	@Override
//	public void sendOtp(String toAddress,String otp) throws Exception {
//		String subject= "Forgot Password";
//		String body = "<html><BODY><p>Hi,</p><p>Your otp for Forgot Password for GST Portal is : "+otp+" </p></BODY></html>";
//		Map<String, String> paramMap = new HashMap<String,String>();
//		paramMap.put("From", "EY_GST@in.ey.com");
//		paramMap.put("To", toAddress);
//		paramMap.put("Subject",subject);
//		paramMap.put("Body", body);
//		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
//		restClientUtil.executeRestCallGSTNPost(null,mapAsJson,null,null, HttpMethod.POST,false);	
//	}
//
//
//}
