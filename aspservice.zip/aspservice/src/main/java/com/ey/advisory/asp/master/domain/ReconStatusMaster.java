package com.ey.advisory.asp.master.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblReconStatus",schema="dbo")
public class ReconStatusMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer masterid;

	@Column(name = "GroupCode")
	private String groupCode;

	@Column(name = "ReturnType")
	private String returnType;

	@Column(name = "GSTIN")
	private String gstin;

	@Column(name = "TaxPeriod")
	private String taxPeriod;

	@Column(name = "CreatedDate")
	private Date createdDate;
	
	@Column(name = "UpdatedDate")
	private Date updatedDate;
	
	@Column(name = "IsActive")
	private Boolean isActive;
	
	@Column(name = "ReconStatus")
	private String reconStatus;

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getReconStatus() {
		return reconStatus;
	}

	public void setReconStatus(String reconStatus) {
		this.reconStatus = reconStatus;
	}

	public Integer getMasterid() {
		return masterid;
	}

	public void setMasterid(Integer masterid) {
		this.masterid = masterid;
	}
	
	
	
}
