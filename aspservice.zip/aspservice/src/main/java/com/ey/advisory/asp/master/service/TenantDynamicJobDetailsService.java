package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;

public interface TenantDynamicJobDetailsService {
        
    public void saveTenantDetails(TenantDynamicJobDetail tenantDynamicJobDetail);
    
    public void updateJobDetail(String jobName,String groupCode, String type);
    
    public boolean findByJobNameAndGroupCodeAndStatus(String jobName, String groupCode, List<String> status); 
    
    public String getJobParamDetails(String jobName, String groupCode, List<String> status);

}
