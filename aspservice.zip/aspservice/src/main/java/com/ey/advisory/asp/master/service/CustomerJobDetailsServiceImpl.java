package com.ey.advisory.asp.master.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.CustomerJobDetails;
import com.ey.advisory.asp.master.repository.CustomerJobDetailsRepository;

@Service
public class CustomerJobDetailsServiceImpl implements CustomerJobDetailsService {

	private static final Logger LOGGER = Logger.getLogger(CustomerJobDetailsServiceImpl.class);
	
    protected EntityManager entityManager;

    public EntityManager getEntityManager() {
        return entityManager;
    }

    @PersistenceContext(unitName = "masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Autowired
    CustomerJobDetailsRepository customerJobDetailsRepository;

    @Override
    public List<CustomerJobDetails> getCustomerDetails() {
        return customerJobDetailsRepository.getCustomerDetails();
    }

    @Override
    @Transactional(propagation=Propagation.REQUIRED)
    public void saveCustomerDetails(CustomerJobDetails customerJobDetails) {
        customerJobDetailsRepository.save(customerJobDetails);
    }
    
    @Override
    @Transactional(propagation=Propagation.REQUIRED)
    public boolean updateCustomerDetails(CustomerJobDetails customerJobDetails) {
        if(customerJobDetails != null){
            customerJobDetailsRepository.save(customerJobDetails);
            return true;
        }
        return false;
     
     }
    
    @Override
    @Transactional(propagation=Propagation.REQUIRED)
    public void saveCustomerDetails(String groupId, String jobName, String cronExpression, Map<String, Object> jobData) throws IOException {
        CustomerJobDetails customerJobDetails =new CustomerJobDetails();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = null;
        byte[] jobParam = null;
        try {
            out = new ObjectOutputStream(bos);   
            out.writeObject(jobData);
            jobParam = bos.toByteArray();
        } catch(Exception ex){
        	LOGGER.error(ex);
        } finally {
        	if(out!=null){
        	out.close();
        	}
        	bos.close();
           
        } 
        customerJobDetails.setJobData(jobParam);
        //customerJobDetails.setJobData(jobData);
        customerJobDetails.setBeanName(jobName);
        customerJobDetails.setCronExpression(cronExpression);
        customerJobDetails.setGroupCode(groupId);
        customerJobDetailsRepository.save(customerJobDetails);
     }
    
    @Override    
    public boolean deleteCustomerDetails(String jobName,String groupCode) {
        CustomerJobDetails customerJobDetails = customerJobDetailsRepository.findByBeanNameAndGroupCode(jobName, groupCode);
         if(customerJobDetails != null){
           customerJobDetailsRepository.delete(customerJobDetails);
           return true;
        }
         return false;
    }

	@Override
	public CustomerJobDetails findByBeanNameAndGroupCode(String jobName,String groupId) {
		 CustomerJobDetails customerJobDetails = customerJobDetailsRepository.findByBeanNameAndGroupCode(jobName, groupId);
		return customerJobDetails;
	}

}
