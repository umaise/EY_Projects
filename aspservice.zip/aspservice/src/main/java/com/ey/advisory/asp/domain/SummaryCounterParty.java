package com.ey.advisory.asp.domain;

public class SummaryCounterParty {
	String ctin,checksum,ttlInv,ttlTax,ttlIgst,ttlCgst,ttlSgst;

	public SummaryCounterParty() {
		super();
	}

	public SummaryCounterParty(String ctin, String checksum, String ttlInv, String ttlTax, String ttlIgst,
			String ttlCgst, String ttlSgst) {
		super();
		this.ctin = ctin;
		this.checksum = checksum;
		this.ttlInv = ttlInv;
		this.ttlTax = ttlTax;
		this.ttlIgst = ttlIgst;
		this.ttlCgst = ttlCgst;
		this.ttlSgst = ttlSgst;
	}

	public String getCtin() {
		return ctin;
	}

	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	public String getTtlInv() {
		return ttlInv;
	}

	public void setTtlInv(String ttlInv) {
		this.ttlInv = ttlInv;
	}

	public String getTtlTax() {
		return ttlTax;
	}

	public void setTtlTax(String ttlTax) {
		this.ttlTax = ttlTax;
	}

	public String getTtlIgst() {
		return ttlIgst;
	}

	public void setTtlIgst(String ttlIgst) {
		this.ttlIgst = ttlIgst;
	}

	public String getTtlCgst() {
		return ttlCgst;
	}

	public void setTtlCgst(String ttlCgst) {
		this.ttlCgst = ttlCgst;
	}

	public String getTtlSgst() {
		return ttlSgst;
	}

	public void setTtlSgst(String ttlSgst) {
		this.ttlSgst = ttlSgst;
	}
}
