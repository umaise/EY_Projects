package com.ey.advisory.asp.master.service;

import java.util.LinkedList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.GSTR2ReconResponseConsolidatedMetadata;
import com.ey.advisory.asp.master.repository.GSTR2ReconResponseConsolidatedRepository;
@Service
public class GSTR2ReconResponseConsolidatedServiceImpl implements GSTR2ReconResponseConsolidatedService{
	protected EntityManager entityManager;
    public EntityManager getEntityManager() {
        return entityManager;
    }
    
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Autowired
    private GSTR2ReconResponseConsolidatedRepository gstr2ReconResponseAdditionalRepository;
	@Override
	public LinkedList<GSTR2ReconResponseConsolidatedMetadata> getMetadataBySheetName(String sheetName) {
		return gstr2ReconResponseAdditionalRepository.getMetadataBySheetName(sheetName);
	}
}
