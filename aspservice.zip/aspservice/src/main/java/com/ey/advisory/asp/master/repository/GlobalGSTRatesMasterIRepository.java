/**
 * 
 */
package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ey.advisory.asp.master.domain.GlobalGSTRatesMasterI;


/**
 * @author Ashutosh.Srivastava
 *
 */
public interface GlobalGSTRatesMasterIRepository extends JpaRepository<GlobalGSTRatesMasterI, Long> {
	
	
	@Query("from GlobalGSTRatesMasterI where hsnsac=:hsnsac")
	public List<GlobalGSTRatesMasterI> getHsnSacRecord(@Param("hsnsac") String hsnsac);
}
