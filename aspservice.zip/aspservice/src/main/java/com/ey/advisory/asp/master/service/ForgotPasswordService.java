package com.ey.advisory.asp.master.service;

import com.ey.advisory.asp.master.domain.ForgotPassword;


public interface ForgotPasswordService {
	
	public ForgotPassword findByUserName(String userName);
	
	public String saveForgotPassword(ForgotPassword forgotPassword);
	
	public ForgotPassword getLatestDetails(String userName);


}
