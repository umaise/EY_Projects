package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name = "tblCustomerJobFrequencyDetails", schema = Constant.CONFIG_SCHEMA)
public class CustomerJobFrequencyDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CustomerGroup")
	private String groupCode;

	@Column(name = "JobFrequency")
	private String frequency;

	@Column(name = "CustomerPriority")
	private Integer customerPriority;

	@Column(name = "Flag")
	private Integer flag;

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public Integer getCustomerPriority() {
		return customerPriority;
	}

	public void setCustomerPriority(Integer customerPriority) {
		this.customerPriority = customerPriority;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	

}
