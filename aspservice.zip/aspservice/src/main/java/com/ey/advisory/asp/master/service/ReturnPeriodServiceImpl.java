/**
 * 
 */
package com.ey.advisory.asp.master.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.ReturnMasterDto;
import com.ey.advisory.asp.master.domain.ReturnPeriod;
import com.ey.advisory.asp.master.repository.IReturnPeriodRepository;
import com.ey.advisory.asp.master.repository.ReturnMasterRepository;
import com.ey.advisory.asp.util.DateUtillity;

/**
 * @author Nitesh.Tripathi
 *
 */
@Service
public class ReturnPeriodServiceImpl implements ReturnPeriodService{
	
	private final Logger log = (Logger) LoggerFactory.getLogger(getClass()); 
	
	@Autowired
	private IReturnPeriodRepository iReturnPeriodRepository;
	
	@Autowired
	private ReturnMasterRepository returnMasterRepository; 

	@Override
	public ReturnPeriod getReturnPeriod(){
		
		return iReturnPeriodRepository.findByIsCurrentPeriod(true);
	}
	
	@Override
	public List<ReturnMasterDto> getReturnType(String returnType) {
		
		return returnMasterRepository.findByReturnType(returnType);
	}

	
	@Override
	public String checkLateFee(String taxPeriod, ReturnMasterDto returnMasterDto)
	{
		long diffDays;
        String message = null;
        Date sub_date = new Date();
        Calendar submissionDate = Calendar.getInstance();
        submissionDate.setTime(sub_date);
        
        double latefee = returnMasterDto.getLateFee();
		int returnDate = returnMasterDto.getDueDate();
        
        if(returnMasterDto.getLateFee() != null)
        {
        	Date date = DateUtillity.getDateByPattern(taxPeriod);
			Calendar dueDate = Calendar.getInstance();
			dueDate.setTime(date);
			dueDate.set(Calendar.DATE, returnDate);
			dueDate.set(Calendar.MONTH, dueDate.get(Calendar.MONTH)+1);

			if(submissionDate.after(dueDate))
			{
				long diff =  submissionDate.getTimeInMillis() - dueDate.getTimeInMillis();
	               diffDays = diff / (24 * 60 * 60 * 1000);
        	  	log.info("Due date of filing of GSTR-2 is 15th of succeeding month, Late fee of 300 per day shall be applicable as the delay is more than <x> days ");
        	  	message = "Due date for filing of GSTR-2 is "+ dueDate.get(Calendar.DATE)+ " " + dueDate.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault())+","+dueDate.get(Calendar.YEAR) 
        	  			+  ". Late fees of "+ latefee+" per day shall be applicable as the delay is more than "+ diffDays+" days ";
			}
			
       }	
       return message;
	}

	@Override
	public void saveReturnPeriod(ReturnPeriod returnPeriod) {
		iReturnPeriodRepository.save(returnPeriod);
	}

	@Override
	public void deActivateReturnPeriod(int periodId) {
		iReturnPeriodRepository.deActivateReturnPeriod(periodId);		
	} 
	
	public  String getPreviousMonthTaxPeriod(){
		
		ReturnPeriod rp = iReturnPeriodRepository.findByIsCurrentPeriod(true);
		Calendar cal =  Calendar.getInstance();
		cal.setTime(rp.getStartDt());  
		cal.add(Calendar.MONTH ,-1);
		String taxPeriod  = new SimpleDateFormat("MMyyyy").format(cal.getTime());
		return taxPeriod;
	}
	
	
	public  String getFormattedPreviousMonthTaxPeriod(){
		ReturnPeriod rp = iReturnPeriodRepository.findByIsCurrentPeriod(true);
		Calendar cal =  Calendar.getInstance();
		cal.setTime(rp.getStartDt());  
		cal.add(Calendar.MONTH ,-1);
		String taxPeriod  = new SimpleDateFormat("MMM, yyyy").format(cal.getTime());
		return taxPeriod;
	}
}	
	
	
	
	
