package com.ey.advisory.asp.master.service;

import com.ey.advisory.asp.master.domain.ReconStatusMaster;

public interface ReconStatusMasterService {

	public ReconStatusMaster saveReconStatusMaster(String gstin,String taxPeriod,String groupCode, String returnType);
	
	public ReconStatusMaster updateReconStatusMaster(String gstin,String taxPeriod,String groupCode);
	
	public ReconStatusMaster getReconStatusMaster(String gstin,String taxPeriod,String groupCode);
}
