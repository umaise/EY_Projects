package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.Function;

@Transactional
public interface FunctionRepository extends JpaRepository<Function,	Long> {
	
	/*@Query("SELECT function.functionId FROM Function function")
	public List<Function> getRoleFunctions(@Param("roleID") Long roleId);
*/
}
