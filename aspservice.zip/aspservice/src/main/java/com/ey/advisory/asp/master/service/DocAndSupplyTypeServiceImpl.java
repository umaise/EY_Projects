package com.ey.advisory.asp.master.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.DocAndSupplyTypeMetadata;
import com.ey.advisory.asp.master.repository.DocAndSupplyTypeRepository;
@Service
public class DocAndSupplyTypeServiceImpl implements DocAndSupplyTypeService{

	protected EntityManager entityManager;
    public EntityManager getEntityManager() {
        return entityManager;
    }
    
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Autowired
    private DocAndSupplyTypeRepository docAndSupplyTypeRepository;
	@Override
	public List<DocAndSupplyTypeMetadata> findByFileCategoryAndDocType(List<String> fileCategories, String typeOfDoc) {
		List<DocAndSupplyTypeMetadata> list = null;
		try{
			list = docAndSupplyTypeRepository.findByFileCategoryAndDocType(fileCategories, typeOfDoc);
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
}
