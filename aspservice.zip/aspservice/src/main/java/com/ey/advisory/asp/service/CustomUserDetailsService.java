package com.ey.advisory.asp.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.domain.CustomUser;
import com.ey.advisory.asp.master.domain.User;
import com.ey.advisory.asp.master.service.UserService;


@Component
public class CustomUserDetailsService implements UserDetailsService {


	@Autowired
	@Qualifier("userService")
	private UserService userService;

	private final Log log = LogFactory.getLog(getClass());
	@Override
	public UserDetails loadUserByUsername(String userName) 
			throws UsernameNotFoundException{
				
		CustomUser user = populateCustomUser(userName);			
		return user;
	}
	
	public CustomUser populateCustomUser(String userName){
		CustomUser customUser = null;
		try{
			User ofcUser=userService.findByUserName(userName);
			
			if(log.isInfoEnabled()){
			log.info("After userRoles ");
			}
			
			if (ofcUser == null) {
				throw new UsernameNotFoundException(userName + " user not found");
			} else {
				List<GrantedAuthority> roles = new LinkedList<>();
		
				if(!ofcUser.isPwdExpired() && checkIfPasswordExpired(ofcUser.getPwdCreationDate())){
					ofcUser.setPwdExpired(true);
					userService.updateUser(ofcUser,false);
				}
				customUser = new CustomUser(ofcUser.getUserId(), ofcUser.getUserName(), ofcUser.getPassword(),
						!ofcUser.isLocked(), !ofcUser.isAccountExpired(), Boolean.TRUE,
						!ofcUser.isLocked(), roles, null,
						ofcUser.getFirstName().concat(" ").concat(ofcUser.getLastName()), 
						 ofcUser.isForcePasswordChange(), ofcUser.isPwdExpired() );
			}
			
		}catch(Exception ex){
			log.error("Error in CustomUserDetailsService "+ex);
		}
		return customUser;
	}
	
	/**
	 * Gets the details of the user that is currently logged in, from the spring security context.
	 * @return User object
	 */
	public static User getLoggedInUser()
	{
		CustomUser customUser;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null) {
			customUser = (CustomUser) authentication.getPrincipal();	
			
			// Construct User from custom user
			User user = new User(); 
			user.setUserId(customUser.getUserId() );
			user.setUserName(customUser.getUsername());
			user.setFirstName(customUser.getFullUserName().split("\\ ")[0]);
			user.setLastName(customUser.getFullUserName().split("\\ ")[1]);
			user.setAccountExpired(!customUser.isAccountNonExpired());
			user.setPwdExpired(customUser.isPwdExpired());
			user.setLocked(!customUser.isAccountNonLocked());
			user.setForcePasswordChange(customUser.getForceChangePwd());		
			return user;
		}
		
		return null;
	}
	
	public boolean checkIfPasswordExpired (Date pwdCreationDate) {
		
		try {
			Calendar todaysDate = Calendar.getInstance();
    		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    		
    		Calendar passwordCreationDate = Calendar.getInstance();
    		passwordCreationDate.setTime(sdf.parse(pwdCreationDate.toString()));
    		
    		Long todayDate = todaysDate.getTimeInMillis(); 
    		Long pwdCreatedDate = passwordCreationDate.getTimeInMillis();
    		long dayDiff = todayDate - pwdCreatedDate; 
    		long diffDays = dayDiff / (24 * 60 * 60 * 1000);
    	
		} catch(ParseException e){
			log.error("Error in checkIfPasswordExpired "+ e);
		}
    		return false;	
	}
	
}