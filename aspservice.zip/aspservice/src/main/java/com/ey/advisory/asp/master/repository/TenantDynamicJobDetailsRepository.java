package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.TenantDynamicJobDetail;


@Repository
@Transactional
public interface TenantDynamicJobDetailsRepository extends JpaRepository<TenantDynamicJobDetail, String> {
	
    @Query("from TenantDynamicJobDetail jobDetails where jobDetails.status ='NEW'")
    public List<TenantDynamicJobDetail> getJobDetails();
    
    @Query("from TenantDynamicJobDetail jobDetails where jobDetails.status ='NEW' ")
    public List<TenantDynamicJobDetail> getPageableJobDetails(Pageable pageable);
    
    @Query("from TenantDynamicJobDetail jobDetails where jobDetails.jobName =:jobName and jobDetails.groupCode =:groupCode and jobDetails.status ='INP' ")
    public List<TenantDynamicJobDetail> getJobDetailsForInput(@Param("jobName") String jobName, @Param("groupCode") String groupCode);
    
    @Query("from TenantDynamicJobDetail jobDetails where jobDetails.jobName =:jobName and jobDetails.groupCode =:groupCode and jobDetails.status in:status ")
    public List<TenantDynamicJobDetail> findByJobNameAndGroupCodeAndStatus(@Param("jobName") String jobName, @Param("groupCode") String groupCode,@Param("status") List<String> status); 
    
    /*@Query("update TenantDynamicJobDetail jobDetails set jobDetails.status ='INP' where jobDetails.id =:id ")
    public void updateTenantDynamicJobDetailsWithInProgress(@Param("id") long id);*/
    
    /*@Modifying
    @Query("update TenantDynamicJobDetail jobDetails set jobDetails.status ='CTD' where jobDetails.id =:id")
    public void updateTenantDynamicJobDetailsWithCompleted(@Param("id") long id);*/
	
	public List<TenantDynamicJobDetail> findByJobNameAndGroupCodeAndStatus(String jobName, String groupCode, String status); 
   
}
