package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.QuestionModule;

@Repository
@Transactional(readOnly = true)
public interface QuestionRepository extends JpaRepository<QuestionModule, Long> {
	@Override
    public List<QuestionModule> findAll();
}
