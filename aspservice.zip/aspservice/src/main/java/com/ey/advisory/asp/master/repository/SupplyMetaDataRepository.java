/**
 * 
 */
package com.ey.advisory.asp.master.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.advisory.asp.master.domain.SupplyMetaData;


/**
 * @author Sadhana.Holla
 *
 */
public interface SupplyMetaDataRepository extends JpaRepository<SupplyMetaData, Long> {
	
	

}
