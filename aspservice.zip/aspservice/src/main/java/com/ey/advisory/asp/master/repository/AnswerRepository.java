package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.ey.advisory.asp.master.domain.AnswerModule;


@Repository
@Transactional(readOnly = true)
public interface AnswerRepository extends JpaRepository<AnswerModule, Long> {

	@Override
    public List<AnswerModule> findAll();
}
