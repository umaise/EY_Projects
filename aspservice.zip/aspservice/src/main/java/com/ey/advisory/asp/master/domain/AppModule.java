/**
 * 
 */
package com.ey.advisory.asp.master.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Uma.Chandranaik
 *
 */
@Entity
@Table(name = "tblAppModule",schema="master")
public class AppModule implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ModuleID")
	private Long moduleId;
	
	@Column(name = "ModuleName")
	private String moduleName;
	
	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="CreatedBy",referencedColumnName="UserID")*/
	
	@Column(name = "CratedBy")
	private Long createdBy;
	
	@Column(name = "CreatedDate")
	private Date createdDate;
	
	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="LastModifiedBy",referencedColumnName="UserID")*/
	@Column(name = "LastModifiedBy")
	private Long lastModifiedBy;
	
	@Column(name = "LastModifiedDate")
	private Date lastModifiedDate;
	
	
	public Long getModuleId() {
		return moduleId;
	}
	public void setModuleId(Long moduleId) {
		this.moduleId = moduleId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(Long lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	
}
