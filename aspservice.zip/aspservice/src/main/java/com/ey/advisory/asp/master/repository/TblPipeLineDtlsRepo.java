package com.ey.advisory.asp.master.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.TblPipeLineDtls;

@Repository
@Transactional
public interface TblPipeLineDtlsRepo extends JpaRepository<TblPipeLineDtls, Long>{
	
	@Query("select tbl.datalevel from TblPipeLineDtls tbl "
					+ "where tbl.returnType=:returnType and tbl.recordtype=:recordType and tbl.applicableStatus=:applicableState ")
	String getDataLevel(@Param("applicableState")String applicableState,@Param("returnType") String returnType,@Param("recordType") String recordType);

}
