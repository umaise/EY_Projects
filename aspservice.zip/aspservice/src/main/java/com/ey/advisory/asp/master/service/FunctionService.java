package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.Function;



public interface FunctionService {
	
	public List<Function> getRoleFunctions(Long roleId);

}
