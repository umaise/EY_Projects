package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.GstinDueDateMaster;

/**
 * Service contains all the methods related to Gstn Due date 
 *
 */
public interface GstinDueDateMasterService {

	List<GstinDueDateMaster> findGstnDueDate(List<String> returnType);

}
