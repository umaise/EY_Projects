package com.ey.advisory.asp.domain;

public class StateCodeSummary {


String	stateCd;
String	checksum;
Double	ttlInv;
Double		ttlTax;
Double		ttlIgst;
Double		ttlCgst;
Double		ttlSgst;

public String getStateCd() {
	return stateCd;
}
public void setStateCd(String stateCd) {
	this.stateCd = stateCd;
}
public String getChecksum() {
	return checksum;
}
public void setChecksum(String checksum) {
	this.checksum = checksum;
}
public Double getTtlInv() {
	return ttlInv;
}
public void setTtlInv(Double ttlInv) {
	this.ttlInv = ttlInv;
}
public Double getTtlTax() {
	return ttlTax;
}
public void setTtlTax(Double ttlTax) {
	this.ttlTax = ttlTax;
}
public Double getTtlIgst() {
	return ttlIgst;
}
public void setTtlIgst(Double ttlIgst) {
	this.ttlIgst = ttlIgst;
}
public Double getTtlCgst() {
	return ttlCgst;
}
public void setTtlCgst(Double ttlCgst) {
	this.ttlCgst = ttlCgst;
}
public Double getTtlSgst() {
	return ttlSgst;
}
public void setTtlSgst(Double ttlSgst) {
	this.ttlSgst = ttlSgst;
}
public StateCodeSummary(String stateCd, String checksum, Double ttlInv, Double ttlTax, Double ttlIgst,
		Double ttlCgst, Double ttlSgst) {
	super();
	this.stateCd = stateCd;
	this.checksum = checksum;
	this.ttlInv = ttlInv;
	this.ttlTax = ttlTax;
	this.ttlIgst = ttlIgst;
	this.ttlCgst = ttlCgst;
	this.ttlSgst = ttlSgst;
}
}
