package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.GroupConfig;

@Repository
@Transactional
public interface GroupConfigRepository extends JpaRepository<GroupConfig, Long>{
	
//and g.isActive = true
	@Query("SELECT g from  GroupConfig g WHERE g.groupCode= :groupCode and g.isActive = true ")
	public List<GroupConfig> getGroupConfigvalues(@Param("groupCode") String groupCode);
	
	@Query("SELECT g from  GroupConfig g WHERE g.groupCode= :groupCode and g.isActive = true and g.configCode like CONCAT('%',:configCode,'%')") 
	public List<GroupConfig> getGroupvaluesByReportType(@Param("groupCode") String groupCode, @Param("configCode") String configCode);
	
	@Query("SELECT DISTINCT g.groupCode from  GroupConfig g WHERE  g.isActive = true")
	List<String> findDistinctGroupCode(); 
	
	@Query("SELECT g from  GroupConfig g WHERE  g.isActive = true")
	List<GroupConfig> findAllGroupConfig();

	//@Query("SELECT g from  GroupConfig g WHERE g.groupCode= :groupCode and g.isActive = true and g.configCode like CONCAT('%',:configCode,'%')") 
	//public List<GroupConfig> getGroupvaluesByReportType(@Param("groupCode") String groupCode, @Param("configCode") String configCode);
}
