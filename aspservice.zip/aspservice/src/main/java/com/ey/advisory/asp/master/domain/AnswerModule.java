package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name = "AnswerModule",schema=Constant.MASTER_SCHEMA)
public class AnswerModule  implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AnswerModuleID")
    private long answerModuleID;
    
    @Column(name = "AnswerId")
    private String answerId;
    
    @Column(name = "QuestionModuleID")
    private long questionModuleID;
   
    @Column(name = "QuestionId")
    private String questionID;
    
    @Column(name = "AnswerValue")
    private String answerValue;
    
    @Column(name = "OrderNo")
    private int orderNo;
    
    @Column(name = "Tooltip")
    private String tooltip;
    
    @Column(name = "isDescriptive")
    private Character isDescriptive;
    
    @Column(name = "Description")
    private String description;

    public long getAnswerModuleID() {
        return answerModuleID;
    }

    public void setAnswerModuleID(long answerModuleID) {
        this.answerModuleID = answerModuleID;
    }

    public String getAnswerId() {
        return answerId;
    }

    public void setAnswerId(String answerId) {
        this.answerId = answerId;
    }

    public long getQuestionModuleID() {
        return questionModuleID;
    }

    public void setQuestionModuleID(long questionModuleID) {
        this.questionModuleID = questionModuleID;
    }

    public String getQuestionID() {
        return questionID;
    }

    public void setQuestionID(String questionID) {
        this.questionID = questionID;
    }

    public String getAnswerValue() {
        return answerValue;
    }

    public void setAnswerValue(String answerValue) {
        this.answerValue = answerValue;
    }

    public int getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(int orderNo) {
        this.orderNo = orderNo;
    }

    public String getTooltip() {
        return tooltip;
    }

    public void setTooltip(String tooltip) {
        this.tooltip = tooltip;
    }

    public Character getIsDescriptive() {
        return isDescriptive;
    }

    public void setIsDescriptive(Character isDescriptive) {
        this.isDescriptive = isDescriptive;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "AnswerModule [answerModuleID=" + answerModuleID + ", answerId=" + answerId + ", questionModuleID="
            + questionModuleID + ", questionID=" + questionID + ", answerValue=" + answerValue + ", orderNo=" + orderNo
            + ", tooltip=" + tooltip + ", isDescriptive=" + isDescriptive + ", description=" + description + "]";
    }
    
}
