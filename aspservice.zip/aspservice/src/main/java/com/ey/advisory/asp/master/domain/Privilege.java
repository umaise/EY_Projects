/**
 * 
 */
package com.ey.advisory.asp.master.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Uma.Chandranaik
 *
 */
@Entity
@Table(name = "tblPrivilege",schema="master")
public class Privilege implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PrivilageID")
	private Long privilageID;
	
	@Column(name = "PrivilageName")
	private String privilageName;
	
	@Column(name = "PrivilageDescription")
	private String privilageDescription;
	
	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="CreatedBy",referencedColumnName="UserID")*/
	@Column(name = "CreatedBy")
	private Long createdBy;
	
	@Column(name = "CreatedDate")
	private Date createdDate;
	
	public Long getPrivilageID() {
		return privilageID;
	}
	public void setPrivilageID(Long privilageID) {
		this.privilageID = privilageID;
	}
	public String getPrivilageName() {
		return privilageName;
	}
	public void setPrivilageName(String privilageName) {
		this.privilageName = privilageName;
	}
	public String getPrivilageDescription() {
		return privilageDescription;
	}
	public void setPrivilageDescription(String privilageDescription) {
		this.privilageDescription = privilageDescription;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	
}
