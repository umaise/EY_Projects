package com.ey.advisory.asp.etl.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;

@Service
@Transactional
public class ETLSpServiceImpl implements ETLSpService {

	protected EntityManager entityManager;
	
	private static final Logger logger = Logger
			.getLogger(ETLSpServiceImpl.class);
	private static final String CLASS_NAME = ETLSpServiceImpl.class.getName();

	public EntityManager getEntityManager() {
		return entityManager;
	}
	  
	@PersistenceContext(unitName="etlJobUnit")
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public String executeStoredProcedure(String storedProcName){
		String procStatus="";
		StoredProcedureQuery query;
		 try
		    {
			 query = entityManager.createStoredProcedureQuery(storedProcName);
			 procStatus=String.valueOf(query.getSingleResult());
			 
		    }catch(Exception e){
		    	logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : executeStoredProcedure",e);
		    	throw e;
		    }
		return procStatus;
		}
		
		@Override
		public String executeStoredProcedure(String storedProcSchema, String storedProcName, int inputParamsCount, List<String> inputParamsList) {
			String procStatus="";
			StoredProcedureQuery query;
			try{
				logger.info("Before Executing the stored Proc "+storedProcName);
			 query = entityManager.createStoredProcedureQuery(storedProcName);
			for(int i=0;i<inputParamsCount;i++){
				query.registerStoredProcedureParameter(i, String.class, ParameterMode.IN);
				query.setParameter(i, inputParamsList.get(i));
			}
			  procStatus = String.valueOf(query.getResultList());
			  logger.info("After Executing the stored Proc "+storedProcName);
			}catch(Exception e)
			{
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : executeStoredProcedure",e);
				throw e;
			}
			return procStatus;
			
		}
		
		@Override
		@SuppressWarnings("unchecked")
		public List<Object[]> executeSPReturnList(String storedProcName) {
			List<Object[]> procStatus=null;
			StoredProcedureQuery query;
			try{
			 query = entityManager.createStoredProcedureQuery(storedProcName);
			 procStatus=query.getResultList();
			}catch(Exception e){
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : executeStoredProcedure" ,e);
				throw e;
			}
			return procStatus;
		}
		
		@Override
		public String executeSPSingleResult(String storedProcSchema, String storedProcName, int inputParamsCount, List<String> inputParamsList) {
			
			String procStatus = "";
			StoredProcedureQuery query;
	
			try {
				logger.info("Before Executing the stored Proc : executeSPSingleResult " + storedProcName);
				query = entityManager.createStoredProcedureQuery(storedProcName);
				
				for (int i = 0; i < inputParamsCount; i++) {
					query.registerStoredProcedureParameter(i, String.class, ParameterMode.IN);
					query.setParameter(i, inputParamsList.get(i));
				}
				
				procStatus = String.valueOf(query.getSingleResult());
				logger.info("After Executing the stored Proc " + storedProcName);
	
			} catch (Exception e) {
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : executeSPSingleResult", e);
				throw e;
			}
			return procStatus;
			
		}
	
	
	
	
}
