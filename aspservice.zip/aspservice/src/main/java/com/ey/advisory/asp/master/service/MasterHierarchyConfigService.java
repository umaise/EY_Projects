/**
 * 
 */
package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.MasterHierarchyConfig;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface MasterHierarchyConfigService {

	
	public List<MasterHierarchyConfig> findAll();
	
}
