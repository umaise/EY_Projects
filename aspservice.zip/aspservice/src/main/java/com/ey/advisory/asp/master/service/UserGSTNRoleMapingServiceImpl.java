package com.ey.advisory.asp.master.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.domain.User;
import com.ey.advisory.asp.master.domain.UserGSTNRoleMaping;
import com.ey.advisory.asp.master.repository.UserGSTNRoleMapingRepository;

@Service
public class UserGSTNRoleMapingServiceImpl implements UserGSTNRoleMapingService{
	
	protected EntityManager entityManager;
	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    @Autowired
    private UserGSTNRoleMapingRepository userGSTNRoleMapingRepository;

	@Override
	public List<UserGSTNRoleMaping> findByUserId(User userId) {
		return userGSTNRoleMapingRepository.findByUserId(userId.getUserId());
	}

	@Override
	public List<UserGSTNRoleMaping> findByRoleId(Role role) {
		return userGSTNRoleMapingRepository.findByRoleId(role.getRoleId());
	}
	

	public List<UserGSTNRoleMaping> findByUserId(long userId) {
		return userGSTNRoleMapingRepository.findByUserId(userId);
	}
	
	public  String deleteByUserIdAndGroupId(Long userId,Long groupId){

		   @SuppressWarnings("unused")
		   List<UserGSTNRoleMaping> objectList = userGSTNRoleMapingRepository.findByUserIdAndGroupId(userId,groupId);
		   for(UserGSTNRoleMaping userMap: objectList){
			   
			   userGSTNRoleMapingRepository.delete(userMap.getId());
			   
		   }
		  // userGSTNRoleMapingRepository.delete(objectList);
		   
           return "Success"; 
	}

}
