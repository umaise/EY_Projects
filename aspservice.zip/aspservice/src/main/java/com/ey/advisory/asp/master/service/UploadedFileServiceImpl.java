package com.ey.advisory.asp.master.service;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.domain.UploadFileStatus;
import com.ey.advisory.asp.dto.FileSearchDTO;
import com.ey.advisory.asp.master.domain.FileUploadStatusMaster;
import com.ey.advisory.asp.master.domain.User;

@Service("uploadedFileService")
@PropertySource("classpath:sftp.properties")
public class UploadedFileServiceImpl implements UploadedFileService{

	@Autowired
	private Environment env;
	
	@Autowired
	private UserService userService;

	
	private static final Logger LOGGER = Logger.getLogger(UploadedFileServiceImpl.class);
	private static final String CLASS_NAME = UploadedFileServiceImpl.class.getName();
	
	protected EntityManager entityManager;

	public EntityManager getEntityManager() {
        return entityManager;
    }
	
    @PersistenceContext(unitName="masterDataUnit")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
	 
   	@Override
	public List<FileUploadStatusMaster> getUploadedFiles(FileSearchDTO fileDTO) {
	
   		if(fileDTO.getFromDate()!=null && fileDTO.getFromDate().length()!=0)
   			return getFilesByDate(fileDTO);
   		else
   			return getFilesByMonth(fileDTO);
	}
	
	
	private List<FileUploadStatusMaster> getFilesByDate(FileSearchDTO fileDTO)
	{
		List<Object[]> resultList;
		fileDTO.setFromDate(fileDTO.getFromDate()+" 00:00:00");
		fileDTO.setToDate(fileDTO.getToDate()+ " 23:59:59");
		
		String sql= "SELECT  t.FileId,df.StageDesc,t.UploadDt,sc.Description,t.fName,t.FileData FROM [etl].[tblFileUploadStatus] t"
		 +" INNER JOIN [dbo].[tblSystemCodes] sc ON t.JobStatus=sc.Code"
		 +" LEFT JOIN [dbo].[tblDataFlowStages] df ON t.ErrorCode=df.StageCode"
		 +" WHERE t.UserId= ? AND t.UploadDt BETWEEN ? AND ? " ;		
		 Query query = getEntityManager().createNativeQuery(sql);
		query.setParameter(1, fileDTO.getUserId());
		query.setParameter(2, fileDTO.getFromDate());
		query.setParameter(3, fileDTO.getToDate());
		
		resultList= query.getResultList();
		if(resultList!=null && !resultList.isEmpty())
			return prepareList(resultList);
					
		return null;
	}
	
	private List<FileUploadStatusMaster> getFilesByMonth(FileSearchDTO fileDTO)
	{
			String sql=	"SELECT  t.FileId,df.StageDesc,t.UploadDt,sc.Description,t.fName,t.FileData FROM [etl].[tblFileUploadStatus] t"
						 +" INNER JOIN [dbo].[tblSystemCodes] sc ON t.JobStatus=sc.Code"
						 +" LEFT JOIN [dbo].[tblDataFlowStages] df ON t.ErrorCode=df.StageCode "
						 + " WHERE t.UserId= ? AND MONTH(UploadDt)= ? AND YEAR(UploadDt)= ? ";
		Query query = getEntityManager().createNativeQuery(sql);
		query.setParameter(1, fileDTO.getUserId());
		query.setParameter(2, fileDTO.getMonth());
		query.setParameter(3, fileDTO.getYear());
	
		List<Object[]> resultList= query.getResultList();
		if(resultList!=null && !resultList.isEmpty())
			return prepareList(resultList);
				
		return null;
	}
	
	private List<FileUploadStatusMaster> prepareList(List<Object[]> responseList)
	{
		SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		List<FileUploadStatusMaster> fileList=new ArrayList<>();
		String errorDesc;
		for (Object[] objects : responseList) {
			errorDesc=objects[1]==null?"N.A":objects[1].toString();
			fileList.add(new FileUploadStatusMaster(Long.valueOf(objects[0].toString()),errorDesc,sdf.format((Timestamp)objects[2]),objects[3].toString(), objects[4].toString(), objects[5].toString()));
		}
		return fileList;
	}
	
	/**
	 * This method is used to populate the UploadFileStatus bean .
	 */
	public UploadFileStatus getFileUploadParams(String filePath,String fileName,Long userId){
		UploadFileStatus fileStatus = new UploadFileStatus();
		try{
		String[] fileParams = filePath.split(File.separator);
		
		int entityNameIndex = Integer.parseInt(env.getProperty("entityName.index"));
		int fileDataIndex = Integer.parseInt(env.getProperty("fileData.index"));
		int gstinIndex = Integer.parseInt(env.getProperty("gstin.index"));
		Long userIdVal = Long.parseLong(env.getProperty("fileUpload.userId"));
		
		fileStatus.setEntityName(fileParams[entityNameIndex]);
		fileStatus.setFileData(fileParams[fileDataIndex]);
		fileStatus.setFilePath(filePath);
		fileStatus.setGstin(fileParams[gstinIndex]);
		fileStatus.setMapId(Constant.MAP_ID_SFTP);//Created 2 constants ..one in web ,one in service
		fileStatus.setFileType(FilenameUtils.getExtension(fileName));
		fileStatus.setfName(fileName);
		
		if(userId != null){
			fileStatus.setUserId(userId);//userId
		}
		else{
			fileStatus.setUserId(userIdVal);//Pick User from property file
		}
		}catch(Exception e){
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getFileUploadParams()",e);
		}
		return fileStatus;
	}
	//SFTP details with srcPtah,trgtPath,Useremail,Flag as parameters

	@Override
	public UploadFileStatus getFileUploadParams(String path, Integer flag, String userEmail, File File,
			String hashString) 
	{
		UploadFileStatus fileStatus = new UploadFileStatus();
			try
			{
			String content=Constant.SFTP_INWARD;
				if(path.toLowerCase().indexOf(content.toLowerCase()) != -1 )
				{
					fileStatus.setFileData("GSTR2IS");
				}
				else
				{
					fileStatus.setFileData("GSTR1OS");
				}
				
			 String grpCode = "";

			 if(path.contains("\\")){
				 
				 String[] fileParams1 = path.split("\\\\");
				 for(String str : fileParams1){
					 if(str!= null &&str.trim().length()>0){
						 grpCode = str;
						 break;
					 }
				 }
				 
			 }else{
				 
				 String[] fileParams1 = path.split("/");
                 for(String str : fileParams1){
                     if(str!= null &&str.trim().length()==0){
                    	 grpCode = str;
						 break;
					 }
				 }
			 }
			
				
			User user =  userService.findByEmailId(userEmail);	
			fileStatus.setGroupName(grpCode);
			fileStatus.setEntityName("");
			fileStatus.setLegalName("");
			fileStatus.setFileHash(hashString);
			fileStatus.setFilePath(path);
			fileStatus.setGstin("");
			fileStatus.setMapId(Constant.MAP_ID_SFTP);//Created 2 constants ..one in web ,one in service
			fileStatus.setFileType(FilenameUtils.getExtension(File.getName()));
	        fileStatus.setfName(File.getName());
	        
		    fileStatus.setUserId(user.getUserId());//Pick User from property file
		    fileStatus.setUpdatedBy(user.getUserName());
			}
		catch(Exception e)
			{
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getFileUploadParams()",e);
			}
			return fileStatus;

		}
	
	

		@Override
		public UploadFileStatus getFileUploadParams(String path, Integer flag, String userEmail, String fileName,
				String hashString) 
		{
			UploadFileStatus fileStatus = new UploadFileStatus();
				try
				{
				String content=Constant.SFTP_INWARD;
					if(path.toLowerCase().indexOf(content.toLowerCase()) != -1 )
					{
						fileStatus.setFileData("GSTR2IS");
					}
					else
					{
						fileStatus.setFileData("GSTR1OS");
					}
					
				 String grpCode = "";

				 if(path.contains("\\")){
					 
					 String[] fileParams1 = path.split("\\\\");
					 for(String str : fileParams1){
						 if(str!= null &&str.trim().length()>0){
							 grpCode = str;
							 break;
						 }
					 }
					 
				 }else{
					 
					 String[] fileParams1 = path.split("/");
	                 for(String str : fileParams1){
	                     if(str!= null &&str.trim().length()==0){
	                    	 grpCode = str;
							 break;
						 }
					 }
				 }
				
					
				User user =  userService.findByEmailId(userEmail);	
				fileStatus.setGroupName(grpCode);
				fileStatus.setEntityName("");
				fileStatus.setLegalName("");
				fileStatus.setFileHash(hashString);
				fileStatus.setFilePath(path);
				fileStatus.setGstin("");
				fileStatus.setMapId(Constant.MAP_ID_SFTP);//Created 2 constants ..one in web ,one in service
				fileStatus.setFileType(FilenameUtils.getExtension(fileName));
		        fileStatus.setfName(fileName);
		        
			    fileStatus.setUserId(user.getUserId());//Pick User from property file
			    fileStatus.setUpdatedBy(user.getUserName());
				}
			catch(Exception e)
				{
					LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getFileUploadParams()",e);
				}
				return fileStatus;

			}
	
	
	@Override
    public UploadFileStatus getFileUploadParams(String path, Long userId, File File,String supplyType,String hashString,String groupCode,String userEmail) 
    {
        UploadFileStatus fileStatus = new UploadFileStatus();
            try
            {
            	User user =  userService.findByEmailId(userEmail);	
            fileStatus.setGroupName(groupCode);
            fileStatus.setEntityName("");
            fileStatus.setLegalName("");
            fileStatus.setFileHash(hashString);
            fileStatus.setFilePath(path);
            fileStatus.setGstin("");
            fileStatus.setMapId(Constant.MAP_ID_SFTP_ZERO);//Created 2 constants ..one in web ,one in service
            fileStatus.setFileType(FilenameUtils.getExtension(File.getName()));
            fileStatus.setfName(File.getName());
            fileStatus.setFileData(supplyType);
            fileStatus.setUserId(user.getUserId());//Pick User from property file
            fileStatus.setUpdatedBy(user.getUserName());
            }
        catch(Exception e)
            {
                LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getFileUploadParams()",e);
            }
            return fileStatus;

        }

	@Override
	public UploadFileStatus getFileUploadParams(String path, Long userId, File File, String supplyType,
			String hashString, String groupCode) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	}
	
	
	
	




