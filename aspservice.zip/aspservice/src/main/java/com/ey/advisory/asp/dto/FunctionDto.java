package com.ey.advisory.asp.dto;

import java.io.Serializable;

public class FunctionDto implements Serializable {

	private Long funcID;
	private String func;
	private String funcDesc;
	
	public Long getFuncID() {
		return funcID;
	}
	public void setFuncID(Long funcID) {
		this.funcID = funcID;
	}
	public String getFunc() {
		return func;
	}
	public void setFunc(String func) {
		this.func = func;
	}
	public String getFuncDesc() {
		return funcDesc;
	}
	public void setFuncDesc(String funcDesc) {
		this.funcDesc = funcDesc;
	}
	
	
}
