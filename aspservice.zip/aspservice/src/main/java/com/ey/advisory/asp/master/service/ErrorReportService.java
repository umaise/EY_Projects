package com.ey.advisory.asp.master.service;



public interface ErrorReportService {
	
	public String executeStoredProcedure(String storedProcName);

}
