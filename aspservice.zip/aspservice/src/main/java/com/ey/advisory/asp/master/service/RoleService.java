package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.domain.UserGSTNRoleMaping;

public interface RoleService {
	
	public List<Role> getRoles();
	
	public List<Role> getUserRoles(Long userId);
	
	public List<Role> getAllRoles();
	
	public Role saveRole(Role role);
	
	public String saveUserRoleMapping(List<UserGSTNRoleMaping> gstnRoleMapings);
	
	public List<Role> getRolesByCategory(String category);
}
