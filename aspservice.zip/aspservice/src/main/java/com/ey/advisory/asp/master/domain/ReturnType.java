package com.ey.advisory.asp.master.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;


@Entity
@Table(name="tblReturnType", schema=Constant.MASTER_SCHEMA)
public class ReturnType implements Serializable{
	
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ReturnTypeID")
	Integer returnTypeID;
	
	@Column(name="ReturnValue")
	String returnValue;
	
	@Column(name="ReturnCode")
	String returnCode;
	
	@Column(name="ReturnType")
	String returnType;
	
	@Column(name="DataTransType")
	String dataTransType;
	
	@Column(name="ReturnRelationShip")
	Integer returnRelationShip;
	
	
	
	public Integer getReturnTypeID() {
		return returnTypeID;
	}
	public void setReturnTypeID(Integer returnTypeID) {
		this.returnTypeID = returnTypeID;
	}
	public String getReturnValue() {
		return returnValue;
	}
	public void setReturnValue(String returnValue) {
		this.returnValue = returnValue;
	}
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public String getDataTransType() {
		return dataTransType;
	}
	public void setDataTransType(String dataTransType) {
		this.dataTransType = dataTransType;
	}


}