package com.ey.advisory.asp.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.Group;

@Repository
@Transactional
public interface GroupRepository extends JpaRepository<Group, Long>{
	
	@Override
	public List<Group> findAll();
	
	@Query("select groupCode from Group group where group.isActive= '1'")
	public List<String> findByIsActiveTrue();
	
	@Query("select count(*) from Group group")
	public long count();
	
	@Query("SELECT g from  Group g WHERE g.groupName like %:groupName%")
	public List<Group> getGroupCode(@Param("groupName") String groupName);

	@Query("SELECT count(*) from  Group g WHERE g.groupName like %:groupName%")
	public long getGroupCount(@Param("groupName") String groupName);
	
	public Group findByGroupId(Long groupId);
}
