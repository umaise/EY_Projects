package com.ey.advisory.asp.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ey.advisory.asp.common.Constant;

public class DateUtillity {

	private static List<SimpleDateFormat> patternList; 

	static DateFormat dateFormat = new SimpleDateFormat(Constant.DATE_FORMAT_YYYY_MM_DD);
	
	static {
		patternList = new ArrayList<SimpleDateFormat>(); 
		patternList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"));
		patternList.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		patternList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"));
		patternList.add(new SimpleDateFormat("MMyyyy"));
		patternList.add(new SimpleDateFormat("MM-yyyy"));
		patternList.add(new SimpleDateFormat("MM.yyyy"));
		patternList.add(new SimpleDateFormat("yyyy-MM-dd"));
	}


	public static Date getDate(Object data) throws ParseException {

		return dateFormat.parse(data.toString());
	}

	public static Date getDateByPattern(String dateStr) {
		
		for(SimpleDateFormat sdf : patternList){
		try{
			if(dateStr != null && !dateStr.isEmpty()){
				return sdf.parse(dateStr);
			}
		}catch(ParseException pe){
			
		}
		}
		throw new RuntimeException("Unknown Date Format for " + dateStr);
	}
}
