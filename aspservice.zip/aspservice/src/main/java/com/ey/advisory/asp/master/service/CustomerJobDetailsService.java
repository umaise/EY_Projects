package com.ey.advisory.asp.master.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import com.ey.advisory.asp.master.domain.CustomerJobDetails;

public interface CustomerJobDetailsService {
    
    public List<CustomerJobDetails> getCustomerDetails();
    
    public void saveCustomerDetails(CustomerJobDetails customerJobDetails);
    
    public boolean deleteCustomerDetails( String jobName,String groupId);
    
    public boolean updateCustomerDetails( CustomerJobDetails customerJobDetails);
    
    public void saveCustomerDetails(String groupId, String jobName, String cronExpression, Map<String, Object> jobData) throws IOException;
    
    public CustomerJobDetails findByBeanNameAndGroupCode(String jobName,String groupId);

}
