/**
 * 
 */
package com.ey.advisory.asp.master.service;

import java.util.List;

import com.ey.advisory.asp.master.domain.AppRoleFunction;
import com.ey.advisory.asp.master.domain.Role;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface AppRoleFunctionService {
	
	public List<AppRoleFunction> findByRoleId(Role roleId);

}
