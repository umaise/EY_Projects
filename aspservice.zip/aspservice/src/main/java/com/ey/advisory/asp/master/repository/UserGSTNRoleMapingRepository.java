package com.ey.advisory.asp.master.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.Role;
import com.ey.advisory.asp.master.domain.UserGSTNRoleMaping;

@Transactional
public interface UserGSTNRoleMapingRepository extends JpaRepository<UserGSTNRoleMaping, Long> {
	
	public List<UserGSTNRoleMaping> findByUserId(Long userId);
	
	//@Query("SELECT userRoleMapping.userId from UserGSTNRoleMaping userRoleMapping where userRoleMapping.roleId.roleId =:roleId")
	public List<UserGSTNRoleMaping> findByRoleId(@Param("roleId") Long roleId);
	
	
	public List<UserGSTNRoleMaping> findByRoleId(Role roleId);
	
	 @Modifying
	 @Query("UPDATE UserGSTNRoleMaping c SET c.roleId = :roleId, c.updatedDate =:updatedDate, c.updatedBy = :updatedBy WHERE c.userId = :userId")
		public void updateRole(@Param("roleId") Role roleId, @Param("updatedDate") Date updatedDate, @Param("updatedBy") String updatedBy,@Param("userId") Long userId);
	
	 
	 @Query("SELECT user.userId,user.userName,user.emailId,roleId.roleId,roleId.rolename from UserGSTNRoleMaping userRole WHERE userRole.roleId.roleId IN (:roleIds)")
	 public List<Object[]> getUsersFromRole(@Param("roleIds") List<Long> roleIds); 
	 
	 @Query("SELECT userRole.user.userId, userRole.user.firstName, userRole.user.lastName, userRole.user.userName, userRole.user.emailId , userRole.user.mobileNo, "
	 		+ "userRole.groupId.groupId , userRole.roleId.roleId, userRole.user.isActive from UserGSTNRoleMaping userRole WHERE userRole.groupId.groupId IN (:groupIds)")
	 public List<Object[]> fetchUsersFromGroupId(@Param("groupIds") List<Long> groupIds, Pageable top);
	 
	 @Query("SELECT userRole.user.userId, userRole.user.firstName, userRole.user.lastName, userRole.user.userName, userRole.user.emailId , userRole.user.mobileNo, "
		 		+ "userRole.groupId.groupId , userRole.roleId.roleId, userRole.user.isActive from UserGSTNRoleMaping userRole WHERE userRole.groupId.groupId IN (:groupIds) and userRole.user.firstName like CONCAT(:searchText,'%')")
	 public List<Object[]> searchUserDetailByText(@Param("groupIds") List<Long> groupIds, @Param("searchText") String searchText, Pageable top);
	 
	 @Query(" from UserGSTNRoleMaping userRole WHERE userRole.groupId.groupId = :groupId and userRole.userId = :userId")
	 public List<UserGSTNRoleMaping> findByUserIdAndGroupId(@Param("userId") Long userId,@Param("groupId") Long groupId);
	 
	 
}
