 package org.opensaml.saml2.metadata.provider;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.opensaml.xml.parse.StaticBasicParserPool;
import org.opensaml.xml.parse.XMLParserException;
import org.springframework.security.saml.metadata.CachingMetadataManager;
import org.springframework.security.saml.metadata.ExtendedMetadata;
import org.springframework.security.saml.metadata.ExtendedMetadataDelegate;



public class EYCachingMetadataManager extends CachingMetadataManager {

	private static final Logger LOGGER = Logger.getLogger(EYCachingMetadataManager.class);

	Map<String, Long> map = new HashMap<String, Long>();

	String filePath;
	
	String refMetadataInterval;

	public  String getRefMetadataInterval() {
		return refMetadataInterval;
	}

	public  void setRefMetadataInterval(String refMetadataInterval) {
		this.refMetadataInterval = refMetadataInterval;
	}
	
	public  String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	
	ThreadLocal<String> threadLocal = new ThreadLocal<String>(){
//		String
	};

	@Override
    public String getHostedSPName() {
        return threadLocal.get();
    }

    /**
     * Sets nameID of SP hosted on this machine. This can either be called from springContext or
     * automatically during invocation of metadata generation filter.
     *
     * @param hostedSPName name of metadata describing SP hosted on this machine
     */
	@Override
	public void setHostedSPName(String hostedSPName) {
        this.threadLocal.set(hostedSPName); 
    }

	public EYCachingMetadataManager(List<MetadataProvider> providers, String filePath, String refMetadataInterval) throws MetadataProviderException, XMLParserException {
		super(loadMetaFiles(filePath));
		this.setRefreshCheckInterval(Long.valueOf(refMetadataInterval));
		this.setFilePath(filePath);
	}

	
	public static List<MetadataProvider> loadMetaFiles(String filePath) throws MetadataProviderException, XMLParserException {
		List<MetadataProvider> filesystemMetadataProviders = new ArrayList<>();
		
		File file = new File(filePath);
		//if file path is not created, 
		if (!file.exists()) {
			file.mkdirs();
		}
		
		String arr[] = file.list();
		StaticBasicParserPool basicParserPool = new StaticBasicParserPool();
		basicParserPool.initialize();
		for (String string : arr) {
			try {
				FilesystemMetadataProvider filesystemMetadataProvider = new FilesystemMetadataProvider(
						new File(file.getAbsolutePath() + File.separator + string));
				filesystemMetadataProvider.setParserPool(basicParserPool);
				ExtendedMetadata extendedMetadata = new ExtendedMetadata();
				extendedMetadata.setSigningAlgorithm("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256");
				ExtendedMetadataDelegate extendedMetadataDelegate = new ExtendedMetadataDelegate(
						filesystemMetadataProvider, extendedMetadata);
				extendedMetadataDelegate.setMetadataTrustCheck(false);
				filesystemMetadataProviders.add(extendedMetadataDelegate);
			} catch (MetadataProviderException e) {
				LOGGER.fatal("LoadMetaFiles: Metadata provoider  : " + e, e);
			} catch (Exception e) {
				LOGGER.fatal("Exception  : " + e, e);
			}
		}

		return filesystemMetadataProviders;
	}

	
	@Override
	public boolean isRefreshRequired() {
		boolean bflag = super.isRefreshRequired();
		File file = new File(filePath);
		String arr[] = file.list();
		for (String string : arr) {
			File file2 = new File(file.getAbsolutePath() + File.separator + string);
			if (map.containsKey(string)) {
				long lastModified = map.get(string);
				if (file2.lastModified() > lastModified) {
					map.put(string, file2.lastModified());
					bflag = true;
				}
			} else {
				map.put(string, file2.lastModified());
				bflag = true;
			}
		}
		if (bflag) {
			try {
				Set<String> files = new HashSet<>();
				List<ExtendedMetadataDelegate> extendedMetadatas = this.getAvailableProviders();
				for (MetadataProvider metadataProvider : extendedMetadatas) {
					if (metadataProvider instanceof ExtendedMetadataDelegate) {
						ExtendedMetadataDelegate extendedMetadataDelegate = (ExtendedMetadataDelegate) metadataProvider;
						if(extendedMetadataDelegate.getDelegate() instanceof FilesystemMetadataProvider){
							FilesystemMetadataProvider filesystemMetadataProvider = (FilesystemMetadataProvider) extendedMetadataDelegate.getDelegate();
							files.add(filesystemMetadataProvider.getMetadataIdentifier());
						}
					}
				}
				
				List<ExtendedMetadataDelegate> filesystemMetadataProviders = new ArrayList<>();
				List<MetadataProvider> extendedMetadatas2 = loadMetaFiles(this.getFilePath());
				for (MetadataProvider metadataProvider : extendedMetadatas2) {
					if (metadataProvider instanceof ExtendedMetadataDelegate) {
						ExtendedMetadataDelegate extendedMetadataDelegate = (ExtendedMetadataDelegate) metadataProvider;
						if(extendedMetadataDelegate.getDelegate() instanceof FilesystemMetadataProvider){
							FilesystemMetadataProvider filesystemMetadataProvider = (FilesystemMetadataProvider) extendedMetadataDelegate.getDelegate();
							if(!files.contains(filesystemMetadataProvider.getMetadataIdentifier())){
								filesystemMetadataProviders.add(extendedMetadataDelegate);
							}
						}
					}
				}
				extendedMetadatas.addAll(filesystemMetadataProviders);
				List<MetadataProvider> metadataProvidersFinal = new ArrayList<>();
				for (MetadataProvider metadataProvider : extendedMetadatas) {
					metadataProvidersFinal.add(metadataProvider);
				}
				this.setProviders(metadataProvidersFinal);
			} catch (MetadataProviderException e) {
				LOGGER.fatal("isRefreshRequired: Metadata provoider  : " + e, e);

			} catch (XMLParserException e) {
				LOGGER.fatal("LoadMetaFiles : Parsing Error : Metadata " + e, e);

			}
		}
		return bflag;
	}
}
