package org.springframework.security.saml.metadata;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.opensaml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml2.metadata.provider.MetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.util.SimpleURLCanonicalizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EYMetadataGeneratorFilter extends MetadataGeneratorFilter {
	protected final static Logger log = LoggerFactory.getLogger(EYMetadataGeneratorFilter.class);

	Map<String, String> map = new HashMap<String, String>();

	public EYMetadataGeneratorFilter(MetadataGenerator generator) {
		super(generator);
	}

	protected String getDefaultBaseURL(HttpServletRequest request) {
		StringBuilder sb = new StringBuilder();
		String HostValue = request.getHeader("host");
		sb.append("https").append("://").append(HostValue);
		sb.append(request.getContextPath());
		String url = sb.toString();
		if (isNormalizeBaseUrl()) {
			if (log.isDebugEnabled()) {
				log.debug("Default isNormalizeBaseUrl SAML Url :" + url);
			}
			return SimpleURLCanonicalizer.canonicalize(url);
		} else {
			if (log.isDebugEnabled()) {
				log.debug("Default SAML Url :" + url);
			}
			return url;
		}
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		processMetadataInitialization((HttpServletRequest) request);
		chain.doFilter(request, response);
	}

	protected void processMetadataInitialization(HttpServletRequest request) throws ServletException {
		// In case the hosted SP metadata weren't initialized, let's do it now
		String baseURL = getDefaultBaseURL(request);
		
		log.info("processMetadataInitialization : baseURL "+baseURL);
			synchronized (MetadataManager.class) {
				log.info("map.containsKey(baseURL) : baseURL "+map.containsKey(baseURL));
				if (!map.containsKey(baseURL)) {
					
					log.info("map.containsKey(baseURL) : baseURL "+map.containsKey(baseURL));
				try {
					log.info(
							"No default metadata configured, generating with default values, please pre-configure metadata for production use");
					// Defaults
					String alias = generator.getEntityAlias();
					// Use default baseURL if not set
//					if (generator.getEntityBaseURL() == null) {
//						log.warn(
//								"Generated default entity base URL {} based on values in the first server request. Please set property entityBaseURL on MetadataGenerator bean to fixate the value.",
//								baseURL);
						generator.setEntityBaseURL(baseURL);
//					} else {
//						baseURL = generator.getEntityBaseURL();
//					}
					log.info("processMetadataInitialization : Final baseURL "+baseURL );
					
					// Use default entityID if not set
//					if (generator.getEntityId() == null) {
						generator.setEntityId(getDefaultEntityID(baseURL, alias));
//					}

					EntityDescriptor descriptor = generator.generateMetadata();
					ExtendedMetadata extendedMetadata = generator.generateExtendedMetadata();

					log.info("Created default metadata for system with entityID: " + descriptor.getEntityID());
					MetadataMemoryProvider memoryProvider = new MetadataMemoryProvider(descriptor);
					memoryProvider.initialize();
					extendedMetadata.setSigningAlgorithm("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256");
					MetadataProvider metadataProvider = new ExtendedMetadataDelegate(memoryProvider, extendedMetadata);

					manager.addMetadataProvider(metadataProvider);
					manager.setHostedSPName(descriptor.getEntityID());
					manager.refreshMetadata();
					map.put(baseURL, descriptor.getEntityID());
				} catch (MetadataProviderException e) {
					log.error("Error generating system metadata", e);
					throw new ServletException("Error generating system metadata", e);
				}
			} else {
				manager.setHostedSPName(map.get(baseURL));
			}
		}
	}
}
