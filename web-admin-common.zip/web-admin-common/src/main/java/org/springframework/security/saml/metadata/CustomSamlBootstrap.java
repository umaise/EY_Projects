package org.springframework.security.saml.metadata;

import org.opensaml.Configuration;
import org.opensaml.xml.security.BasicSecurityConfiguration;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.security.saml.SAMLBootstrap;

public class CustomSamlBootstrap extends SAMLBootstrap {
	@Override
	public void postProcessBeanFactory(
			ConfigurableListableBeanFactory beanFactory) throws BeansException {
		super.postProcessBeanFactory(beanFactory);
		BasicSecurityConfiguration config = (BasicSecurityConfiguration) Configuration
				.getGlobalSecurityConfiguration();
		config.registerSignatureAlgorithmURI("RSA",
				"http://www.w3.org/2001/04/xmldsig-more#rsa-sha256");
	}
}