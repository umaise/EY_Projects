package com.ey.advisory.asp.util;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import redis.clients.jedis.JedisPoolConfig;

import com.ey.advisory.asp.common.Constant;


public class RedisTemplateUtils<K,V> {
	private static final Logger LOGGER = Logger.getLogger(RedisTemplateUtils.class);
	
	RedisTemplate<K, V> redisTemplates;
	
	private RedisTemplate createRedisTemplate(){
		JedisConnectionFactory jedisConnectionFactory;
		JedisPoolConfig jedisPoolConfig;
		try {
			Properties props=new Properties();
			props.load(RedisTemplateUtils.class.getResourceAsStream("/redis.properties"));
			
			String hostname = props.getProperty(Constant.REDIS_HOST);
			int port = Integer.parseInt(props.getProperty(Constant.REDIS_PORT));
			
			int poolMaxActive=Integer.parseInt(props.getProperty(Constant.REDIS_POOL_MAX_ACTIVE));
			int poolMaxIdle=Integer.parseInt(props.getProperty(Constant.REDIS_POOL_MAX_IDLE));
			long poolMaxWait=Long.parseLong(props.getProperty(Constant.REDIS_POOL_MAX_WAIT));
			boolean testOnBorrow=Boolean.parseBoolean(props.getProperty(Constant.REDIS_POOL_TEST_ON_BORROW));
			int timeOut=5000;
			String password=props.getProperty(Constant.REDIS_PASSWORD);
			
			jedisPoolConfig=new JedisPoolConfig();
			jedisPoolConfig.setMaxTotal(poolMaxActive);
			jedisPoolConfig.setMaxIdle(poolMaxIdle);
			jedisPoolConfig.setMaxWaitMillis(poolMaxWait);
			jedisPoolConfig.setTestOnBorrow(testOnBorrow);
			
			jedisConnectionFactory=new JedisConnectionFactory();
			jedisConnectionFactory.setHostName(hostname);
			jedisConnectionFactory.setPort(port);
			jedisConnectionFactory.setPoolConfig(jedisPoolConfig);
			jedisConnectionFactory.setTimeout(timeOut);
			if (null != password && !"".equalsIgnoreCase(password)) {
				jedisConnectionFactory.setPassword(password);
			}
			jedisConnectionFactory.afterPropertiesSet();
			redisTemplates=new RedisTemplate<>();
			redisTemplates.setConnectionFactory(jedisConnectionFactory);
			redisTemplates.afterPropertiesSet();
			
		} catch (Exception ex) {
			LOGGER.error(ex);
		}
		return redisTemplates;
	}
	public RedisTemplate getRedisTemplate(){
		if(redisTemplates==null){
			redisTemplates=createRedisTemplate();
		}
		return redisTemplates;
	}
}
