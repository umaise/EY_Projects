package com.ey.advisory.asp.dto;

import java.util.List;

public class PreGSTTurnOverWrapper {

	private List<PreGSTTurnOverDto> dataRows;

	public List<PreGSTTurnOverDto> getDataRows() {
		return dataRows;
	}

	public void setDataRows(List<PreGSTTurnOverDto> dataRows) {
		this.dataRows = dataRows;
	}
	
}
