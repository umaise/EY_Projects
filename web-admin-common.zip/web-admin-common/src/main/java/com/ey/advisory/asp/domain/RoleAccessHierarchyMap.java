/**
 * 
 */
package com.ey.advisory.asp.domain;

import java.io.Serializable;

/**
 * @author Nitesh.Tripathi
 *
 */

public class RoleAccessHierarchyMap implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long mapID;

	private Long roleID;

	private Long hierarchyConfigID;

	private MasterHierarchyConfig masterHierarchyConfig;

	/**
	 * @return the mapID
	 */
	public Long getMapID() {
		return mapID;
	}

	/**
	 * @param mapID
	 *            the mapID to set
	 */
	public void setMapID(Long mapID) {
		this.mapID = mapID;
	}

	/**
	 * @return the roleID
	 */
	public Long getRoleID() {
		return roleID;
	}

	/**
	 * @param roleID
	 *            the roleID to set
	 */
	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}

	/**
	 * @return the hierarchyConfigID
	 */
	public Long getHierarchyConfigID() {
		return hierarchyConfigID;
	}

	/**
	 * @param hierarchyConfigID
	 *            the hierarchyConfigID to set
	 */
	public void setHierarchyConfigID(Long hierarchyConfigID) {
		this.hierarchyConfigID = hierarchyConfigID;
	}

	public MasterHierarchyConfig getMasterHierarchyConfig() {
		return masterHierarchyConfig;
	}

	public void setMasterHierarchyConfig(MasterHierarchyConfig masterHierarchyConfig) {
		this.masterHierarchyConfig = masterHierarchyConfig;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RoleAccessHierarchyMap [mapID=" + mapID + ", roleID=" + roleID + ", hierarchyConfigID="
				+ hierarchyConfigID + ", masterHierarchyConfig=" + masterHierarchyConfig + "]";
	}

}
