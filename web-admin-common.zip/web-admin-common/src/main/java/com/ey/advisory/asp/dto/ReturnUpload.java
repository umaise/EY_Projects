package com.ey.advisory.asp.dto;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ReturnUpload implements Serializable{
	 
	private static final long serialVersionUID = 1L;


	public Long getLoadId() {
		return loadId;
	}

	public void setLoadId(Long loadId) {
		this.loadId = loadId;
	}

	

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public Long getMinInvoice() {
		return minInvoice;
	}

	public void setMinInvoice(Long minInvoice) {
		this.minInvoice = minInvoice;
	}

	public Long getMaxInnvoice() {
		return maxInnvoice;
	}

	public void setMaxInnvoice(Long maxInnvoice) {
		this.maxInnvoice = maxInnvoice;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getTrxId() {
		return TrxId;
	}

	public void setTrxId(String trxId) {
		TrxId = trxId;
	}

	public String getGspRefId() {
		return gspRefId;
	}

	public void setGspRefId(String gspRefId) {
		this.gspRefId = gspRefId;
	}

	public Boolean getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(Boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Timestamp getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}

	public Timestamp getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Timestamp updatedDt) {
		this.updatedDt = updatedDt;
	}


	public Long getTblGstnreStatus() {
		return filingId;
	}

	public void setTblGstnreStatus(Long tblGstnreStatus) {
		this.filingId = tblGstnreStatus;
	}

	public String getGstnStatus() {
		return gstnStatus;
	}

	public void setGstnStatus(String gstnStatus) {
		this.gstnStatus = gstnStatus;
	}
	
	
	private Long loadId;

	private Long filingId;
	
	private String returnType;
	
	private Long minInvoice;
	
	private Long maxInnvoice;
	
	private String refId;
	
	private String TrxId; 	
	
	private String gspRefId;
	
	private Boolean isSuccess; 	
	
	private Boolean isActive;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss.SSS")
	private Timestamp createdDt;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss.SSS")
	private Timestamp updatedDt; 
	
	private String gstnStatus;
	
	private String errorDesc;


	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	

	
}	
