package com.ey.advisory.asp.dto;

import java.math.BigInteger;
import com.google.api.client.util.DateTime;

public class CashUtilizationTransaction {
	
	private BigInteger cashUtilizationTransactionUID  ;
	private String gstin;
	private String cashData  ;
	private String returnPeriod  ;
	private DateTime createdOn ;
	private Boolean isPrevMonth  ;
	private Boolean isSubmitted;
	
	public BigInteger getCashUtilizationTransactionUID() {
		return cashUtilizationTransactionUID;
	}
	public void setCashUtilizationTransactionUID(
			BigInteger cashUtilizationTransactionUID) {
		this.cashUtilizationTransactionUID = cashUtilizationTransactionUID;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getCashData() {
		return cashData;
	}
	public void setCashData(String cashData) {
		this.cashData = cashData;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public DateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(DateTime createdOn) {
		this.createdOn = createdOn;
	}
	public Boolean getIsPrevMonth() {
		return isPrevMonth;
	}
	public void setIsPrevMonth(Boolean isPrevMonth) {
		this.isPrevMonth = isPrevMonth;
	}
	public Boolean getIsSubmitted() {
		return isSubmitted;
	}
	public void setIsSubmitted(Boolean isSubmitted) {
		this.isSubmitted = isSubmitted;
	}
	

}
