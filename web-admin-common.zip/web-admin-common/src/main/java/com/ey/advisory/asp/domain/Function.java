package com.ey.advisory.asp.domain;

import java.util.Date;

public class Function {
	
		private static final long serialVersionUID = 1L;
		
		private Long functionId;
		private String function;
		private String funcDescription;
		private String module;
		private Date createdDate;
		private String createdBy;
		private String updatedBy;
		private Date updatedDate;

		public Long getFunctionId() {
			return functionId;
		}

		public void setFunctionId(Long functionId) {
			this.functionId = functionId;
		}

		public String getFunction() {
			return function;
		}

		public void setFunction(String function) {
			this.function = function;
		}

		public String getFuncDescription() {
			return funcDescription;
		}

		public void setFuncDescription(String funcDescription) {
			this.funcDescription = funcDescription;
		}

		public String getModule() {
			return module;
		}

		public void setModule(String module) {
			this.module = module;
		}

		public Date getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(Date createdDate) {
			this.createdDate = createdDate;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public String getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(String updatedBy) {
			this.updatedBy = updatedBy;
		}

		public Date getUpdatedDate() {
			return updatedDate;
		}

		public void setUpdatedDate(Date updatedDate) {
			this.updatedDate = updatedDate;
		}
	
}
