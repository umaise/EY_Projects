package com.ey.advisory.asp.dto;

import java.sql.Date;


public class GSTR2ISD {
	
	private Long id;
	
	private Character flag;
	
	private String checksum;
	
	private String cgstin;
	
	private String invNum;

	private Date invDate;
	
	private Float igstCr;

	private Float cgstCr;

	private Float sgstCr;
	
	private Float txValue;
	
	private Long taxPayerId;
	
	private int invoiceCnt;
	
	private Float igstTotal;
	
	private Float cgstTotal;

	private Float sgstTotal;
	/**
	 * @return the flag
	 */
	public Character getFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(Character flag) {
		this.flag = flag;
	}

	/**
	 * @return the checksum
	 */
	public String getChecksum() {
		return checksum;
	}

	/**
	 * @param checksum the checksum to set
	 */
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	/**
	 * @return the cgstin
	 */
	public String getCgstin() {
		return cgstin;
	}

	/**
	 * @param cgstin the cgstin to set
	 */
	public void setCgstin(String cgstin) {
		this.cgstin = cgstin;
	}

	/**
	 * @return the invNum
	 */
	public String getInvNum() {
		return invNum;
	}

	/**
	 * @param invNum the invNum to set
	 */
	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	/**
	 * @return the invDate
	 */
	public Date getInvDate() {
		return invDate;
	}

	/**
	 * @param invDate the invDate to set
	 */
	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	/**
	 * @return the igstCr
	 */
	public Float getIgstCr() {
		return igstCr;
	}

	/**
	 * @param igstCr the igstCr to set
	 */
	public void setIgstCr(Float igstCr) {
		this.igstCr = igstCr;
	}

	/**
	 * @return the cgstCr
	 */
	public Float getCgstCr() {
		return cgstCr;
	}

	/**
	 * @param cgstCr the cgstCr to set
	 */
	public void setCgstCr(Float cgstCr) {
		this.cgstCr = cgstCr;
	}

	/**
	 * @return the sgstCr
	 */
	public Float getSgstCr() {
		return sgstCr;
	}

	/**
	 * @param sgstCr the sgstCr to set
	 */
	public void setSgstCr(Float sgstCr) {
		this.sgstCr = sgstCr;
	}

	/**
	 * @return the txValue
	 */
	public Float getTxValue() {
		return txValue;
	}

	/**
	 * @param txValue the txValue to set
	 */
	public void setTxValue(Float txValue) {
		this.txValue = txValue;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTaxPayerId() {
		return taxPayerId;
	}

	public void setTaxPayerId(Long taxPayerId) {
		this.taxPayerId = taxPayerId;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}

	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}

	public Float getCgstTotal() {
		return cgstTotal;
	}

	public void setCgstTotal(Float cgstTotal) {
		this.cgstTotal = cgstTotal;
	}

	public Float getSgstTotal() {
		return sgstTotal;
	}

	public void setSgstTotal(Float sgstTotal) {
		this.sgstTotal = sgstTotal;
	}

	
	

}
