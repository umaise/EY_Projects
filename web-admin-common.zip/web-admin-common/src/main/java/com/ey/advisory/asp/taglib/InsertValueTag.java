package com.ey.advisory.asp.taglib;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspWriter;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.web.servlet.tags.RequestContextAwareTag;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.domain.EntityHierarchyDto;
import com.ey.advisory.asp.domain.User;
import com.ey.advisory.asp.dto.GroupDto;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;
import com.ey.advisory.asp.util.RedisSessionUtility;

@Configurable
public class InsertValueTag extends RequestContextAwareTag {

	/**
	 * 
	 */
	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	public static final String ImgPrefix = "<img src='resources/images/";
	
	public static final String ImgPostFix = "'/>";
	
	public static final String defaultImg = "logo-gst-header";
	
	public static final String defaultformat = ".jpg";

	protected static final Logger logger = Logger.getLogger(InsertValueTag.class);

	private static final long serialVersionUID = 1L;

	private String keyName;

	public String getKeyName() {
		return keyName;
	}

	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	/*
	 * @Override public int doStartTag() throws JspException {
	 * 
	 * try { //Get the writer object for output. JspWriter out =
	 * pageContext.getOut();
	 * 
	 * HttpServletRequest request = (HttpServletRequest)
	 * pageContext.getRequest(); //
	 * pageContext.getRequestContext().getWebApplicationContext().getBean(
	 * MyBea‌​n.class) User user = (User)
	 * redisOp.getValueFromRedis(Constant.CURRENTUSER, request);
	 * 
	 * //Perform substr operation on string. out.println(user.getFirstName());
	 * 
	 * } catch (IOException e) { LOGGER.error(e); } return SKIP_BODY; }
	 */

	@Override
	protected int doStartTagInternal() throws Exception {
		JspWriter out = pageContext.getOut();

		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		RedisOperationForSessionObj obj = getRequestContext().getWebApplicationContext()
				.getBean(RedisOperationForSessionObj.class);
		RedisSessionUtility util = getRequestContext().getWebApplicationContext().getBean(RedisSessionUtility.class);
		obj.setUtil(util);
		if (keyName.equalsIgnoreCase(Constant.USER_NAME)) {
			User user = (User) obj.getValueFromRedis(Constant.CURRENTUSER, request);
			out.println(user.getUserName());
		} else if (keyName.equalsIgnoreCase(Constant.GROUP_NAME)) {
			String groupName = (String) obj.getValueFromRedis(Constant.GROUP_NAME, request);
			List<EntityHierarchyDto> entityList = obj.getUserEntityHierarchy(request);
			if (entityList != null) {
				for (EntityHierarchyDto eh : entityList) {
					groupName = groupName + " > " + eh.getEntityName();
					break;
				}
			} else {
				groupName = "";
			}

			out.println(groupName);
		} else if (keyName.equalsIgnoreCase(Constant.GROUPDROPDOWN)) {
			List<GroupDto> groupDtoList = obj.getGroupListFromRedisAll(request);
			Collections.sort(groupDtoList, GroupDto.GrpNameComparator);
			for (GroupDto groupDto : groupDtoList) {
				out.println("<option value=" + groupDto.getGroupId() + ">" + groupDto.getGroupName() + "</option>");
			}
		} else if (keyName.equalsIgnoreCase("gstinId")) {
			String gstin = (String) redisOp.getValueFromRedis(Constant.SELECTED_GSTIN_REDIS, request);

			out.println(gstin);

		} else if (keyName.equalsIgnoreCase("entityLogo")) {
			String entityLogo ="";
			//String groupName = (String) obj.getValueFromRedis(Constant.GROUP_NAME, request);
			List<EntityHierarchyDto> entityList = obj.getUserEntityHierarchy(request);
			if (entityList != null) {
				for (EntityHierarchyDto eh : entityList) {
					entityLogo = "logo_"+eh.getEntityCode()+defaultformat;
					break;
				}
			}
			if(entityLogo.equalsIgnoreCase("")){
				entityLogo = defaultImg;
			}
			
			
			out.println(ImgPrefix+entityLogo+ImgPostFix);
			

		} else if (keyName.equalsIgnoreCase("GROUPDROPDOWN_Code")) {
			List<GroupDto> groupDtoList = obj.getGroupListFromRedisAll(request);
			Collections.sort(groupDtoList, GroupDto.GrpNameComparator);
			for (GroupDto groupDto : groupDtoList) {
				out.println("<option value=" + groupDto.getGroupCode() + ">" + groupDto.getGroupName() + "</option>");
			}
		}

		return 0;
	}

}
