/**
 * 
 */
package com.ey.advisory.asp.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.domain.User;
import com.ey.advisory.asp.dto.GroupDto;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;

/**
 * @author Nitesh.Tripathi
 *
 */
@Component
@PropertySource("classpath:AdFileter.properties")
public class CustomSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {
	
	protected static final Logger LOGGER = Logger
			.getLogger(CustomSuccessHandler.class);
	
	@Value("${redirectHost}")
    private String redirectHost;
	
	@Value("${adminLogin}")
    private String adminLogin;
	

	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
	 
    @Override
    protected void handle(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
            throws IOException {
    	
    	String adminPageRequest = (String) request.getSession(false).getAttribute("adminPageRequest");
    	
        String targetUrl = determineTargetUrl(request,authentication,adminPageRequest);
       
        if (response.isCommitted()) {
        	LOGGER.error("Can't redirect");
            return;
        }
 
        User user = (User) authentication.getPrincipal();
        redisOp.setValueToRedis(Constant.USER_GROUP, getGroupDto(user.getGroupDto()), request);
        redisOp.setGroupSetToRedis(user.getGroupDto(), request);
        redisOp.setValueToRedis(Constant.CURRENTUSER,user, (HttpServletRequest) request);
        redirectStrategy.sendRedirect(request, response, targetUrl);
    }
 
    /*
     * This method extracts the roles of currently logged-in user and returns
     * appropriate URL according to his/her role.
     */
    protected String determineTargetUrl(HttpServletRequest request,Authentication authentication,String adminPageRequest) {
        String url = "";
 
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
 
        List<String> roles = new ArrayList<String>();
 
        for (GrantedAuthority a : authorities) {
            roles.add(a.getAuthority());
        }
 
       if(Constant.TRUE.equalsIgnoreCase(adminLogin)){
    	   url = redirectHost+request.getContextPath()+ "/admin/home";
       }else{
    	   url = redirectHost+request.getContextPath()+ "/home";
       }
       
 
        return url;
    }
 
  
    public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
        this.redirectStrategy = redirectStrategy;
    }
 
    protected RedirectStrategy getRedirectStrategy() {
        return redirectStrategy;
    }
    
    private GroupDto getGroupDto(Set<GroupDto> groupDto) {
		GroupDto grpDto = new GroupDto();

		for (GroupDto groupDtoTmp : groupDto) {

			if (groupDtoTmp != null) {
				grpDto = groupDtoTmp;
				break;
			}

		}

		return grpDto;

	}
	

}
