package com.ey.advisory.asp.domain;

public class DigitalSigModel {
	
	String  documentId, emailId;

	public DigitalSigModel() {
		super();
	}

	public DigitalSigModel(String documentId, String emailId, String acknowledgementId) {
		super();
		this.documentId = documentId;
		this.emailId = emailId;
		
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

}
