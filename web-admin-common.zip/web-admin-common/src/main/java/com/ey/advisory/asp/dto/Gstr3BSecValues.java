package com.ey.advisory.asp.dto;

import javax.xml.bind.annotation.XmlElement;

public class Gstr3BSecValues {
	
	@XmlElement
	private Gstr3BSecValuesSubElements CompositionScheme = new Gstr3BSecValuesSubElements();
	
	@XmlElement
	private Gstr3BSecValuesSubElements NonGst = new Gstr3BSecValuesSubElements();

	@XmlElement
	public Gstr3BSecValuesSubElements getCompositionScheme() {
		return CompositionScheme;
	}

	public void setCompositionScheme(Gstr3BSecValuesSubElements compositionScheme) {
		CompositionScheme = compositionScheme;
	}

	@XmlElement
	public Gstr3BSecValuesSubElements getNonGst() {
		return NonGst;
	}

	public void setNonGst(Gstr3BSecValuesSubElements nonGst) {
		NonGst = nonGst;
	}

	@Override
	public String toString() {
		return "Gstr3BSecValues [CompositionScheme=" + CompositionScheme + ", NonGst=" + NonGst + "]";
	}
	
	

}
