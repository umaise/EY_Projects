package com.ey.advisory.asp.aspect;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.MDC;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Aspect
@Component
@EnableAspectJAutoProxy

public class AspWebLoggingAspect {

	private static final Logger LOGGER = Logger.getLogger(AspWebLoggingAspect.class);

	@Pointcut("within(com.ey.advisory.asp.*)")
	public void logDetails() {
		if(LOGGER.isInfoEnabled())
			LOGGER.info("logDetails");
	}
	
	@Pointcut("execution(* com.ey.advisory.asp.*.*.*(..))")
	public void restCallMethods() {
		 LOGGER.info("restCallMethods");
	}
	
	@Around("restCallMethods()")
	public Object aroundMethod(ProceedingJoinPoint joinpoint) {
		Object result=null;
		try {
			long start = System.nanoTime();
			Object[] args = joinpoint.getArgs();
			if(LOGGER.isInfoEnabled())
				LOGGER.info("@Around before joinpoint.proceed() :" + joinpoint.getSignature());
			if (LOGGER.isDebugEnabled() && args.length > 0) {
				LOGGER.debug("Arguments passed: ");
				for (int i = 0; i < args.length; i++) {
					LOGGER.debug("Arg" + (i + 1) + ":" + args[i]);
				}

			}
			for (Object obj : args) {
				if (obj instanceof HttpServletRequest) {
					HttpServletRequest httpRequest = (HttpServletRequest) obj;
					HttpSession session = httpRequest.getSession(false);
					if (session != null) {
						MDC.put("sessionID", session.getId());
					}
					break;
				}
			}

			result = joinpoint.proceed();
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("returned values ");
				LOGGER.debug(result);
			}
			long end = System.nanoTime();
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("before :" + joinpoint.getSignature());
				LOGGER.info(String.format("%s took %d ns", joinpoint.getSignature(), end - start));
			}
		} catch (Throwable e) {

			LOGGER.error(e);
		}
		return result;
	}

	
	@AfterReturning(pointcut = "within(com.ey.advisory.asp.*)", returning = "returnString")
	public void getReturningAdvice(String returnString) {
		if(LOGGER.isInfoEnabled())
			LOGGER.info("executed. Returned String=" + returnString);
	}

	@AfterThrowing(pointcut = "execution(* com.ey.advisory.asp.*.*.*(..))", throwing = "ex")
	public void logExceptions(Throwable ex) {
		if(LOGGER.isInfoEnabled())
		        LOGGER.info("****LoggingAspect.logExceptions() " + ex);
	}

}
