package com.ey.advisory.asp.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.security.saml.SAMLProcessingFilter;

public class EYSamlProcessingFilter extends SAMLProcessingFilter {

	private static final Logger LOGGER = Logger.getLogger(EYSamlProcessingFilter.class);


	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		if(LOGGER.isDebugEnabled())
			LOGGER.debug(httpServletRequest.getRequestURL() + "===" + httpServletRequest.getRequestURI());
		
		AddableHttpRequest addableHttpRequest = new AddableHttpRequest(httpServletRequest);

		super.doFilter(addableHttpRequest, response, chain);
	}

}
