package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class TblSalesFileStatus implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long fileId;
	private String errorDesc;
	private String fileData;
	private String filePath;
	private String fileType;
	private String fName;
	private String gstin;
	private String isProcessed;
	private int mapId;
	private Timestamp updatedon;
	private Timestamp uploadDt;
	private long userId;
	private String jobStatus;
	private String uiDate;
	private String jobStatusDesc;
	
	public String getJobStatusDesc() {
		return jobStatusDesc;
	}
	public void setJobStatusDesc(String jobStatusDesc) {
		this.jobStatusDesc = jobStatusDesc;
	}
	public String getUiDate() {
		return uiDate;
	}
	public void setUiDate(String uiDate) {
		this.uiDate = uiDate;
	}
	public long getFileId() {
		return fileId;
	}
	public void setFileId(long fileId) {
		this.fileId = fileId;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public String getFileData() {
		return fileData;
	}
	public void setFileData(String fileData) {
		this.fileData = fileData;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getFName() {
		return fName;
	}
	public void setFName(String fName) {
		this.fName = fName;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getIsProcessed() {
		return isProcessed;
	}
	public void setIsProcessed(String isProcessed) {
		this.isProcessed = isProcessed;
	}
	public int getMapId() {
		return mapId;
	}
	public void setMapId(int mapId) {
		this.mapId = mapId;
	}
	public Date getUpdatedon() {
		return updatedon;
	}
	public void setUpdatedon(Timestamp updatedon) {
		this.updatedon = updatedon;
	}
	public Date getUploadDt() {
		return uploadDt;
	}
	public void setUploadDt(Timestamp uploadDt) {
		this.uploadDt = uploadDt;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	
	

}
