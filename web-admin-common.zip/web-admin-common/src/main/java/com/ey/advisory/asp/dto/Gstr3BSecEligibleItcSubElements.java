package com.ey.advisory.asp.dto;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

public class Gstr3BSecEligibleItcSubElements {

	@XmlElement(defaultValue = "00.0")
	private BigDecimal Integrated;
	@XmlElement(defaultValue = "00.0")
	private BigDecimal Central;
	@XmlElement(defaultValue = "00.0")
	private BigDecimal State;
	@XmlElement(defaultValue = "00.0")
	private BigDecimal Cess;
	
	@XmlElement
	public BigDecimal getIntegrated() {
		return Integrated;
	}
	public void setIntegrated(BigDecimal integrated) {
		Integrated = integrated;
	}
	@XmlElement
	public BigDecimal getCentral() {
		return Central;
	}
	public void setCentral(BigDecimal central) {
		Central = central;
	}
	@XmlElement
	public BigDecimal getState() {
		return State;
	}
	public void setState(BigDecimal state) {
		State = state;
	}
	@XmlElement
	public BigDecimal getCess() {
		return Cess;
	}
	public void setCess(BigDecimal cess) {
		Cess = cess;
	}
	@Override
	public String toString() {
		return "Gstr3BSecEligibleItcSubElements [Integrated=" + Integrated + ", Central=" + Central + ", State=" + State
				+ ", Cess=" + Cess + "]";
	}
	
	
	
}
