package com.ey.advisory.asp.common;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Constant {
    public static final String EMPTY_STRING = ""; 
	public static final String FALSE = "FALSE";
	public static final String TRUE = "TRUE";
	public static final String YES = "Yes";
	public static final String NO = "No";
	public static final String CURRENTUSER = "CURRENTUSER";
	public static final String CURRENTUSEREMAILID = "CURRENTUSEREMAILID";
	public static final String USERGSTNROLES = "USERGSTNROLES";
	public static final String CURRENTROLE = "CURRENTROLE";
	public static final String USER_INFO = "USERINFO";
	public static final String GSTNTIME = "GSTNTIME";
	public static final String MAX_BAD_LOGIN = "MAX_BAD_LOGIN";
	public static final String PASS_EXPIRY_DAYS = "PASS_EXPIRY_DAYS";
	public static final String ENTER = "Enter ";
	public static final String EXIT = "Exit ";
	public static final String ERROR = "Error ";
	public final static String DATE_FORMAT = "MM-dd-yyyy";
	public final static String DATE_FORMAT_YEAR = "yyyy-MM-dd";
	//Added for pagination
	public static final String DEFAULT_PAGE_SIZE="DEFAULT_PAGE_SIZE";
	public final static String DATE_FORMAT_IN_HOURS = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String SYMBOL_COLON = ":";
    
    public static final String SEPERATOR_DOT = "\\.";
    
    public static final int ALLOWED_MONTH_DIFF_RCM_REPORT = 18;
    public static final int TOTAL_MONTHS = 12;
    
    public static final String RCM_CATEGORY_TAG="<RCMCategory>";
    public static final String GSTIN_TAG="<CGSTIN>";
		//Service Map changes
	public static final String SERVICE_RELATION = "Level 4";
	public static final Long MENU_LEVEL = (long) 1;
	public static final String USER_ROLE_MENUS = "UserRoleMenus";
	public static final String USER_ROLE_FUNS = "UserRoleFuns";
	
	public static final String MOBILENO="mobile_number";
	//
	/****** Resource Strings **********/
	public static final String AUTHENTICATE = "/taxpayerapi/v0.1/authenticate";
	
	public static final String RETURNS = "/taxpayerapi/v0.1/returns";
	
	public static final String GSTR1 = "/gstr1";
	
	public static final String GSTR2 ="/gstr2";
	public static final String GSTR3 ="/gstr3";
	
	public static final String HOST = "http://devapi.gstsystem.co.in";
	
	public static final String LEDGERS = "/taxpayerapi/v0.1/ledgers";
	public static final String GSTIN = "GSTIN";
	public static final String GSTIN_ID = "gstinId";
	public static final String DIGIGST_USERNAME = "digigstUserName";
	public static final String FILENUM = "fileNum";
	public static final String MONTH = "month";
	public static final String YEAR = "year";
	public static final String SHARED_PATH = "sharedPath";
	public static final String OUTWARD = "outward";
	public static final String INWARD = "inward";
	public static final String REGISTER_TYPE = "registerType";


	final public static String GSP_USER = "eygspuser";
	
	final public static String GSP_CLIENT_ID = "eygspclientid";
	
	final public static String GSP_CLIENT_SECRET = "eygspclientsecret";
	public static final String RETSAVE="RETSAVE";
	public static final String OTPREQUEST="OTPREQUEST";
	public static final String AUTHTOKEN="AUTHTOKEN";
	public static final String RETSUBMIT="RETSUBMIT";
	
	public static final String MAILHOST="http://inbanvmdwb02.mea.ey.net/MailAPI/api/sendmail";
	public static final String GSTR= "gstr";
	public static final String FLAG= "flag";
	public static final String DB= "db";
	public static final String URL= "url";
	public static final String UPLOADSUCCESS ="File upload was not successful .";
	public static final String MONTH_NAME = "monthName";
	public static final String SIGN_AND_FILE_GSTR2 ="signAndFileGstr2";
	public static final String SIGN_AND_FILE_GSTR3 ="signAndFileGstr3";
	public static final String SIGN_AND_FILE_GSTR7 ="signAndFileGstr7";
	public static final String ASP_SIGN_AND_FILE_GSTR2 = "asp-signAndFileGstr2";
	public static final String ASP_SIGN_AND_FILE_GSTR7 = "asp-signAndFileGstr7";
	public static final String ITEMS = "items";
	public static final String ITEMSTEMP = "itemstemp";
	public static final String GSTIN_AND_KEY = "gstinAndKey";
	public static final String GSTNVAL = "gstnval";
	public static final String JSON_INPUT = "JSON_INPUT";
	public static final String SIGN_AND_FILE_GSTR1 = "signAndFileGstr1";
	public static final String DIGITAL_SIGN_TEMPLATE = "DigitalSignTemplate";
	public static final String ONE = "1";
	public static final String TWO = "2";
	public static final String ASP_SUMMARY_SIGN_AND_FILE_GSTR1 = "asp-summarySignAndFileGstr1";
	public static final String ASP_SIGN_AND_FILE_GSTR3 = "asp-signAndFileGstr3";
	public static final String INVALID_CAPTCHA = "Invalid Captcha";
	//Considering OWASP vulnerability below hard codeded constants are complaint 
	public static final String NEW_PASSWORD = "newPassword";
	public static final String CONFIRM_PASSWORD = "confirmPassword";
	public static final String CURRENT_PASSWORD = "currentPassword";
	public static final String EMAILID = "emailId";
	public static final String OTP = "otp";
	public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	public static final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,20})";
	public static final String EMAILID_VALIDATION = "Please enter correct email id";
	public static final String PASSWORD_VALIDATION = "Please enter valid password. Password length must be 8 and must contain one or more uppercase letter, lower case letter, number and special charater(@#$%)";
	public static final String CHOOSE_PASSWORD_VALIDATION = "Choose password and confirm password does not match";
	public static final String SUCCESS = "success";
	public static final String LOGIN_VALIDATION = "Please Login to reset the password!";
	
	public static final String ROLE_TYPE_ADMIN = "Role_Admin";
	
	public static final String ROLE_TYPE_MEMBER = "Role_Member";
	
	public static final String ADMIN_HOME_URL = "/admin/home";
	
	public static final String LOGOUT_URL = "/logout";
	
	
	
	public static final String UPLOAD_FILE_RQST_PARAMETER_CHUNK="chunk";
	public static final String UPLOAD_FILE_RQST_PARAMETER_CHUNKS="chunks";
	public static final String MANAGEUSER_RESTPATH_INSERT_FILE="asp-insertFileStatus";
	public static final String MANAGEUSER_RESTPATH_GET_GROUP_DATA="asp-getUserGroupData";
	public static final String MANAGEUSER_RESTPATH_GET_UPLOADED_FILE="asp-getUploadedFiles";
	
	public static final String RESTPATH_GET_ROLES="asp-getRoles";
	public static final String RESTPATH_SAVE_ROLE="asp-saveRole";
	public static final String RESTPATH_SAVE_USERROLE_MAPPING="asp-saveUserRoleMapping";
	public static final String RESTPATH_GET_USERROLE="asp-getUserRole";
	public static final String RESTPATH_LOAD_ALL_USERS="asp-loadAllUsers";
	public static final String DEFAULT_ZERO="0";
	
	public static final String USER_NAME="userName";
	public static final String LINK_EXPIRED="expired";
	public static final String LINK_NOT_EXPIRED="notExpired";
	
	public static final Integer GSTR3_MIN_SUBMISSION_DATE=17;
	public static final Integer GSTR3_MAX_SUBMISSION_DATE=20;
public static final String RESTPATH_LOAD_ALL_JOBS="asp-loadAllJobs";
	public static final String GET_QUARTZ_JOB="asp-getJobsForGroup";
	public static final String ANSWERS_LIST= "ANSWERS_LIST";
    public static final String QUESTIONS_LIST= "QUESTIONS_LIST";
	
	public static final String LIABILITY_TYPE = "Return Liability";
	
	public static final String PAYLOAD="payLoad";
	public static final String SIGNED_DATA="signeddata";
	public static final String SIGNING_CONTENT="SIGNING_CONTENT";
	public static final String SIGNATURE_TYPE="signatureType";
	public static final String SID="sid";
	public static final String REDIS_CACHE = "REDIS_CACHE";
	public static final String DIGITAL_CACHE_MAP = "DIGITAL_CACHE_MAP";
	public static final String DIGITAL_CACHE_FILED_MAP = "DIGITAL_CACHE_FILED_MAP";
	
	public static final String USER_GROUP = "group"; 
	public static final String USER_GROUP_EDIT = "groupEdit"; 
	public static final String STATES_LIST= "STATES_LIST"; 

	public static final String COLOR_STATE_INVALID="cccccc";

	public static final String GROUP_NAME = "groupName";
	public static final String GSTINLIST = "GSTINList";
	public static final String GROUPDROPDOWN = "GroupDropDown";
	
	public static final String USER="user";
	public static final String RT_PERIOD = "rtPeriod";	
	public static final String GSTR3_IGST = "igst";	
	public static final String GSTR3_CGST = "cgst";	
	public static final String GSTR3_SGST = "sgst";	
	public static final String DELIMITER_PIPE = "|";
	public static final String USERID = "USERID";
	
	public static final String GSTR_1_GSTRTYPE="1";
	public static final String GSTR_2_GSTRTYPE="2";
	public static final String GSTR_3_GSTRTYPE="3";
	public static final String GSTR_3B_GSTRTYPE="3B";
	public static final String GSTR_6_GSTRTYPE="6";
	public static final String GSTR_7_GSTRTYPE="7";
	public static final String GSTR_8_GSTRTYPE="8";
		
	public static final String GSTR_1="GSTR1";
	public static final String GSTR_2="GSTR2";
	public static final String GSTR_3="GSTR3";
	public static final String GSTR_3B = "GSTR3B";
	public static final String GSTR_4="GSTR4";
	public static final String GSTR_5="GSTR5";
	public static final String GSTR_6="GSTR6";
	public static final String GSTR_7="GSTR7";
	public static final String GSTR_8="GSTR8";
	public static final String GSTR_1_TITLE="Outward supplies made by the taxpayer ";
	public static final String GSTR_2_TITLE="Inward supplies received by the taxpayer ";
	public static final String GSTR_MONTHLY_RETURN="Monthly Return ";
	public static final String GSTR_6_ISD_RETURN="ISD Return ";
	public static final String GSTR_7_TDS_RETURN="TDS Return ";
	
	public static final String GSTR3FILE_ENDDATE = "20";
	public final static String DATE_FORMAT_DDMMYYYY = "ddMMyyyy";
	
	public static final String GSTR6FILE_ENDDATE = "13";
	
	public static final BigDecimal LATE_FEE= new BigDecimal("300");
	public static final boolean BOOLEAN_FALSE = false;
	public static final boolean BOOLEAN_TRUE = true;
	
	public static final String NO_DATA_FOUND = "No Data Available";
	public static final String[] CPTY_GSTR1_HEADERS ={"GSTIN","Total Taxable Value of Records","Total IGST","Total CGST","Total SGST","Total Cess"};
	public static final String GSTR1_CPTY_FILE_PREFIX = "GSTR1_Counter_Party_";
	public static final String GSTR2_CPTY_FILE_PREFIX = "GSTR2_Counter_Party_";
	public static final Object CPTY_GSTR1 = "CPTY_GSTR1";
	public static final Object CPTY_GSTR2 = "CPTY_GSTR2";
	public static final Object CURRENT_TX = "CURRENT_TAXPERIOD";
	public static final String GSTIN_IDLIST = "GSTIN_IDLIST";
	public static final Object GSTIN_IDLIST_GSTR2 = "GSTIN_IDLIST_GSTR2";
	public static final String[] CPTY_GSTR2_HEADERS ={"GSTIN","Total Taxable Value","Total IGST","Total CGST","Total SGST","Total Cess","ITC availed IGST","ITC availed SGST","ITC availed CGST","ITC availed CESS"};
	
	
	public static final String DUE_DATE_LIST= "DUE_DATE_LIST"; 
	public static final String GSTIN_LIST= "GSTIN_LIST"; 
	public static final String MONTH_YEAR= "monthYear"; 
    public static final String USER_GROUP_SET = "GroupSet";
    public static final String FUNCTION_LIST = "FUNCTION_LIST";
    public static final String ROLE = "ROLE";
    public static final String RETURN_PERIOD = "ReturnPeriod";
   
    
    public static final String DOWNLOAD_LEDGER_DETAILS ="LEDGER_DETAILS";
	public static final String[] LEDGER_HEADERS =  {"LEDGERS","CGST","SGST/UTGST","IGST","CESS"};
	public static final String[] LEDGER_COL_HEADERS =  {"Input Tax Credit","Cash","TAX Liablility","Net Balance/Liability"};
	public static final String FILED="Filed";
	public static final String ISSUCCESS="true";
	public static final String TAX_PERIOD = "taxPeriod";
	public static final String LOGGER_ENTERING = "Entering ";
	public static final String LOGGER_METHOD = " Method : ";
	public static final String LOGGER_ERROR = "Error ";
	public static final String LOGGER_EXITING = "Exiting ";
	public static final String TAX_TYPE_MONTHLY="M";
	
	public static final String INTERNAL_CATEGORY="internal";
	public static final String EXTERNAL_CATEGORY="external";
	public static final String ADMIN_CATEGORY="admin";
	public static final int MAP_ID=1;
	
	public static final String GSTR6_RESTPATH_INSERT_FILE="asp-insertGSTR6FileStatus";
	public static final String GSTR6_RESTPATH_DUPLICATE_FILE="asp-DuplicateFileStatus";
	public static final String GSTR_6_TITLE="ISD Return ";

	public static final String ASP_SIGN_AND_FILE_GSTR8 = "asp-signAndFileGstr8";
	public static final String SIGN_AND_FILE_GSTR8 ="signAndFileGstr8";
	public static final String GSTR_8_TITLE="TCS Return ";
	public static final List<String> GSTR1_CPTY_TYPES = Arrays.asList("B2B","B2BA","CDNR","CDNRA");
	public static final List<String> GSTR2_CPTY_TYPES = Arrays.asList("B2B","B2BA","CDN","CDNA","TDS","TCS","ISD");
	public static final BigDecimal MAX_LATE_FEE=new BigDecimal(5000);
	public static final String SIGN_AND_FILE_GSTR6 = "signAndFileGstr6";
	public static final String GSTR6_SUMMARY_FILENAME="GSTR6Summary";
	public static final String JASPER_DIR = "jasperDir";
	public static final String JASPER_JRXML = ".jrxml";
	public static final String JASPER_DOTJASPER = ".jasper";
	public static final String UPDATED_USER_SESSION = "userSessionUpdated";
	public static final String AUTHORISED_SIGNATORY_ROLE="Authorised signatory";
	public static final String HOME_URL = "/home";
	public static final String OTP_VALIDATION = "OTP Validation Failed";
	public static final String GSTINID_VALIDATION = "Gstin validation Failed";
	
	public static final String  FOLDER_STRUCT_MAPF = "folder.structure.Mapfile";
	public static final String  FOLDER_STRUCT_SFTF = "folder.structure.SftFile";
	public static final String  FOLDER_STRUCT_INV_MAP_FILE = "folder.structure.invMapFile";
	
	//pdf generation 
	public static final String GSTR6_JSON="gstr6";
	public static final String SECTION_SUMMARY="section_summary";
	public static final String REPORT_NAME="reportName";
	public static final String GSTIN_JSON="gstin";
	public static final String BUSINESS_NAME="businessName";
	public static final String FINANCIAL_YEAR="fy";
	public static final String RETURNPERIOD="returnPeriod";
	public static final String DUE_DATE="dueDate";
	public static final String SECTION_NAME="section_name";
	public static final String TOTAL_TAXABLE_VALUE="ttl_value";
	public static final String TAX_PAID="tax_pd";
	public static final String ITC_AVAILED="itc_av";
	public static final String CHECKSUM="checksum";
	public static final String TEMPLATE_DIR = "/templates";
	public static final String COUNTER_PARTY_SUMMARY="counter_party_summary";
	
	
	//clientOnboarding
	public static final String REDIS_KEY_ONBOARD="onboardKey";
	
	public static final String ASP_SIGN_AND_FILE_GSTR6 = "asp-signAndFileGstr6";
	public static final String SIX = "6";
	public static final String SUBMITGSTR1 = "SUBMITGSTR1";
	public static final String FAILURE = "FAILURE";
	public static final String FAILED = "FAILED";
	public static final String FAILED0 = "FAILED0";
	public static final Integer EIGHTEEN = 18;
	public static final String FROM_TAXPERIOD = "fromTaxperiod";
	public static final String TO_TAXPERIOD = "toTaxperiod";
	public static final String GSTR1_REPORT = "GSTR1";
	public static final String GSTR2_ERROR_REPORT = "GSTR2";
	public static final String PROCESS_TYPE = "PROCESSTYPE"; 
	public static final String GROUP = "GROUP";
	public static final String ENTITY = "ENTITY";
	public static final String CIRCLE = "CIRCLE";
	public static final String GSTIN_CODE = "GSTIN";
	public static final String SUB_DIVISION = "SUBDIVISION";
	public static final String PROFIT_CENTER = "PROFITCENTER";
	public static final String BUSINESS_UNIT = "BUSINESSUNIT";
	public static final String PLANT_CODE = "PLANTCODE";
	public static final String TAXPERIOD_FORMAT = "MMyyyy";
	public static final String FILE_NAME_FORMAT = "ddMMyyyy_HH-mm-ss";//DDMMYYYY-HH:MM:SS
	public static final String RCM_FILE_NAME_DATE_FORMAT = "ddMMyy_HHmmss";
	public static final String RCM_TRANSACTIONS_FILE_NAME ="GSTIN_RCM Transactions_";
	public static final String RCM_SUMMARY_FILE_NAME ="Summary_RCM_";
	public static final String CONTENT_TYPE = "APPLICATION/OCTET-STREAM";
	public static final String GSTR1_ERROR_XML_START_TAG = "<SalesErrorReports>";
	public static final String GSTR1_ERROR_XML_END_TAG = "</SalesErrorReports>";
	public static final String GSTR2_ERROR_XML_START_TAG = "<PurchaseErrorReports>";	
	public static final String GSTR2_ERROR_XML_END_TAG = "</PurchaseErrorReports>";
	public static final String GSTR2_RCM_XML_START_TAG = "<RCMDetails>";
	public static final String GSTR2_RCM_XML_END_TAG = "</RCMDetails>";
	public static final List<String> GSTR1_TRANSACTIONAL_RAW_FILE_RETURN_CODE= new ArrayList<>(Arrays.asList("GSTR1OS","GSTR2IS","GSTR2FR"));
	public static final String MANAGEUSER_RESTPATH_INSERT_FILE_SUMMARY="asp-insertSummaryFileStatus";
	public static final String FILE_SUMMARY_EXCEL_TO_JSON="asp-processJsonToSummaryProc";
	public static final String DUPLICATE_FILE="DUPLICATE";
	public static final String UPLOAD_SUCCESS="File uploaded successfully";
	public static final String REST_API_404_ERROR ="404";
	public static final String GSTR1_INVOICE_SERIES_RETURN_CODE="GSTR1IS";
	
	public static final List<String> GSTR_ADVANCE_RETURN_CODE= new ArrayList<>(Arrays.asList("GSTR1AA","GSTR1AR","GSTR2AP","GSTR2AA"));
	public static final String GSTR1_ADVANCE_ADJUSTED_RETURN_CODE="GSTR1AA";
	public static final String GSTR1_ADVANCE_RECEIVED_RETURN_CODE="GSTR1AR";
	public static final String GSTR1_B2C_RETURN_CODE="GSTR1B2C";
	public static final String GSTR1_ADVANCE_ADJUSTED_LIST = "GSTR1_ADVANCE_ADJUSTED_LIST";
    public static final String GSTR1_ADVANCE_RECEIVED_LIST = "GSTR1_ADVANCE_RECEIVED_LIST";
    public static final String GSTR1_B2C_CONSOLIDATED_LIST = "GSTR1_B2C_CONSOLIDATED_LIST";
    public static final String GSTR1_INVOICE_SERIES_LIST = "GSTR1_INVOICE_SERIES_LIST";
    
    public static final String RCM_CONSOLIDATED_METADATA = "RCM_Consolidated_Metadata";
    public static final String GSTR2_RCM_CONSOLIDATED_LIST = "GSTR2_RCM_CONSOLIDATED_LIST";
    public static final String RCM_CONSOLIDATED_METADATA_URL = "asp-loadRCMConsolidatedMetadata";
    public static final String GSTR2RCM = "GSTR2RCM";
    public static final String GSTR6IM = "GSTR6IM";
    public static final String GSTR6IMF = "GSTR6IMF";
    public static final int ZERO=0;
    public static final String ZERO_STRING="0";
	public static final String Summary_RCM ="Summary_RCM";
	public static final String UNDERSCORE ="_";
	public static final int START_ROW_RCM = 7;
    
    public static final String ADVANCE_ADJUSTED_METADATA = "Advance_Adjusted_Metadata";
    public static final String ADVANCE_RECEIVED_METADATA = "Advance_Received_Metadata";
    public static final String B2C_CONSOLIDATED_METADATA = "B2C_Consolidated_Metadata";
    public static final String INVOICE_SERIES_METADATA = "Invoice_Series_Metadata";
    
    public static final String GSTR2_ADVANCE_ADJUSTED_METADATA = "Gstr2_Advance_Adjusted_Metadata";
    public static final String GSTR2_ADVANCE_PAID_METADATA = "Gstr2_Advance_Paid_Metadata";
    public static final String GSTR2_ITC_REVERSAL_METADATA = "Gstr2_Itc_Reversal_Metadata";
    public static final String GSTR2_ADVANCE_ADJUSTED_RETURN_CODE="GSTR2AA";
	public static final String GSTR2_ADVANCE_PAID_RETURN_CODE="GSTR2AP";
	public static final String GSTR2_ITC_REVERSAL_RETURN_CODE="GSTR2IR";
	public static final String GSTR2_ADVANCE_ADJUSTED_LIST = "GSTR2_ADVANCE_ADJUSTED_LIST";
    public static final String GSTR2_ADVANCE_PAID_LIST = "GSTR2_ADVANCE_PAID_LIST";
    public static final String GSTR2_ITC_REVERSAL_LIST = "GSTR2_ITC_REVERSAL_LIST";
    public static final String ADVANCE_ADJUSTED_METADATA_GSTR2_URL = "asp-loadGstr2AdvanceAdjustedMetadata";
    public static final String ADVANCE_PAID_METADATA_GSTR2_URL = "asp-loadGstr2AdvancePaidMetadata";
    public static final String ITC_REVERSAL_METADATA_GSTR2_URL = "asp-loadGstr2ItcReversalMetadata";
    
    public static final String ADVANCE_ADJUSTED_METADATA_URL = "asp-loadAdvanceAdjustedMetadata";
    public static final String ADVANCE_RECEIVED_METADATA_URL = "asp-loadAdvanceReceivedMetadata";
    public static final String B2C_CONSOLIDATED_METADATA_URL = "asp-loadB2CConsolidatedMetadata";
    public static final String INVOICE_SERIES_METADATA_URL = "asp-loadInvoiceSeriesMetadata"; 
    public static final String ERROR_MESSAGE = "Something went wrong, Please contact your admin";
    public static final String TRANSACTIONIDPOLLINGSUBMIT = "transactionIDPollingSubmit";
    
    

    public static final String LANDING_PAGE_CFO = "CFODash";
    public static final String LANDING_PAGE_GSTINSUMM = "GstinSum";
    public static final String LANDING_PAGE_PLANTCODE = "plantCode";
    public static final String GSTR1_RECTIFIED_XML_START_TAG = "<SalesRectifiedReport>";
	public static final String GSTR1_RECTIFIED_XML_END_TAG = "</SalesRectifiedReport>";
	public static final String GSTR1_RECTIFIED_FILE_NAME ="GSTR1_RECTIFIED_"; 
    public static final String SELECTED_ENTITY_REDIS = "selectedEntity";
    
	public static final String ALL_GSTIN_LIST= "ALL_GSTIN_LIST";
	public static final String SUMMARY_DATA = "summaryJson";
	public static final String DETERMINATION_SUMMARY_DATA = "determinationSummaryJson";
	public static final String SUMMARY = "SUMMARY";
	public static final String METADATA_VALIDATION_CORRECT_FILE_MSG="Please upload the correct file";
	public static final String PENDING = "pending";
	public static final String RCM_FILE_UPLOAD_DATE_VALIDATION="RCM file upload last date is 8th, you can not upload now. ";
	public static final int NUM_ONE = 1;
	public static final int NUM_THREE = 3;
	public static final int NUM_FIVE = 5;
	public static final int NUM_TWELVE = 12;
	public static final int NUM_EIGHT = 8;
	//redis properties file
  	public static final String REDIS_HOST = "redis.hostName";
  	public static final String REDIS_PORT = "redis.port";
  	
  	public static final String REDIS_POOL_MAX_ACTIVE="redis.pool.maxActive";
  	public static final String REDIS_POOL_MAX_IDLE="redis.pool.maxIdle";
  	public static final String REDIS_POOL_MAX_WAIT="redis.pool.maxWait";
  	public static final String REDIS_POOL_TEST_ON_BORROW="redis.pool.testOnBorrow";
  	public static final String REDIS_TIME_OUT="redis.pool.timeout";
  	public static final String REDIS_PASSWORD="redis.password";
  	public static final String RETURNTYPES = "returnTypes";
	public static final String MODELANDVIEW = "ModelAndView";
	public static final String HYPHEN = "-";
	public static final String ISAZURE = "isAzure";
	public static final String L3B = "L3B";
	public static final String L3A = "L3A";
	public static final String L2 = "L2";
	public static final String L1 = "L1";
	public static final String REGULAR = "Regular";
	public static final String TCS = "TCS";
	public static final String TDS = "TDS";
	public static final String ISD = "ISD";
	
	public static final String NULL = "null";
	public static final String ON = "on";
	public static final String SELECT = "Select";
	public static final String ASP_INPUT_VALIDATION_EXCEPTION_MESSAGE="Invalid input detected. Input Validation Failed for ";
  	public static final String ASP_INPUT_VALIDATION_EXCEPTION="ASPInputValidationException";
  	public static final String INPUT_VALIDATION_ERROR_LOG="Input Validation Error for ";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String CSV = "csv";
	public static final String JSON = "json";
	public static final String XLS = "xls";
	public static final String XLSX = "xlsx";
	public static final String XLX = "xlx";
	public static final List<String> FILE_EXTENSION = new ArrayList<>(Arrays.asList("csv","json","xls","xlsx","xlx","xml","txt","zip"));
	public static final String XML = "xml";
	public static final String TXT = "txt";
	public static final String ZIP = "zip";
	public static final String B2BA = "B2BA";
	public static final String B2CL = "B2CL";
	public static final String B2CLA = "B2CLA";
	public static final String EXP = "EXP";
	public static final String EXPA = "EXPA";
	public static final String CDNR = "CDNR";
	public static final String CDNRA = "CDNRA";
	public static final String B2CS = "B2CS";
	public static final String B2CSA = "B2CSA";
	public static final String NIL = "NILR";
	public static final String ADVREC = "ADVREC";
	public static final String ADVADJ = "ADVADJ";
	public static final String ADVRECA = "ADVRECA";
	public static final String ADVADJA = "ADVADJA";
	public static final String HSN = "HSN";
	public static final String HSNSAC = "HSNSAC";
	public static final String DOCTYPE = "DOCTYPE";
	public static final String PWD = "password";
	public static final String ITC = "ITC";
	public static final String CSL = "CSL";
	public static final String LLD = "LLD";
	public static final String NET = "net";
	public static final String XLSM = "xlsm";
	
    public static final String SELECTED_GSTIN_REDIS = "selectedGstin";
    public static final int RCM_SUMMARY_REPORT_AVAILABLE_DAY = 21;
    public static final String GSTR3B_SUMMARY_XML_START_TAG = "<Gstr3bSummary>";
	public static final String GSTR3B_SUMMARY_XML_END_TAG  = "</Gstr3bSummary>";
	public static final String TAXPERIOD = "taxPeriod";
    public static final String REQUEST_HEADER_KEY_HOST = "host";
	public static final String DB_DATA = "dbData";
	public static final String YMObj = "ymObj";
		
    public static final String GET_GSTIN_RETURN_TYPE = "asp-getGstinReturnType";
    public static final String ISD_DASHBOARD="isdgstinSummary";
    public static final String INVOICE_MAPPING_FILE_NAME="_InvoiceMapping_";
    public static final String GSTR6_INV_MAP_XML_START_TAG = "<InvoiceMappingReports>";
	public static final String GSTR6_INV_MAP_XML_END_TAG = "</InvoiceMappingReports>";
	public static final String GSTR6_INV_MAP_XML_ISD_START_TAG = "<Mapping>";
	public static final String GSTR6_INV_MAP_XML_ISD_END_TAG = "</Mapping>";
	public static final String DOWNLOAD_DUMP_REPORTS="asp-downloadDumpReport";
	public static final String GSTR6_RECTIFIED_REPORT_FILE_NAME="_GSTR6_RECTIFIED_";
	public static final String GSTR6_RECTIFIED_REPORT_XML_START_TAG = "<ISDRectifiedErrorReports>";
	public static final String GSTR6_RECTIFIED_REPORT_XML_END_TAG = "</ISDRectifiedErrorReports>";
	public static final String DETERMINATION_REGISTER_FILE_NAME = "_DeterminationSheet_";
	public static final String GSTR6_DETERMINATION_XML_START_TAG = "<DeterminationSheet>";
	public static final String GSTR6_DETERMINATION_XML_END_TAG = "</DeterminationSheet>";
	public static final String DETERMINATION_SUMM_FILE_NAME="DeterminationSummary_";
	
	/** Redis pub sub message : Group management **/
	public static final String GROUP_LIST= "GROUP_LIST";
	public static final String REDIS_PUB_SUB_CHANNEL= "pubsub:messageQueue";
	/** Redis pub sub message : Group management **/
	
	public static final String GSTR1_OUTWARD_SUPPLY="GSTR1OS";
	public static final String TOTAL_RECORD_TYPE="TOT";
	public static final String DUPLICATE_RECORD_TYPE="DUP";
	public static final String PROCESSED_RECORD_TYPE="PROSS";
	public static final String ERROR_RECORD_TYPE="ERR";
	public static final String GSTR1_OUTWARD_TOTAL_DUMP_URL="outwardDump/doc/";
	public static final String GSTR1_OUTWARD_DUPLICATE_DUMP_URL="outward/dupdump/";
	public static final String GSTR1_OUTWARD_PROCESSED_DUMP_URL="outward/prosdump/";
	public static final String GSTR1_OUTWARD_ERROR_DUMP_URL="outward/errordump/";
	public static final String GSTR1_ADV_ADJUSTED_DUMP_URL="advAdjusted/dump/";
	public static final String GSTR1_ADV_RECEIVEDL_DUMP_URL="advReceived/dump/";
	public static final String GSTR1_B2C_DUMP_URL="b2c/dump/";
	public static final String GSTR1_INVOCE_SERIES_DUMP_URL="invseries/dump/";
	public static final String RECTIFICATION_RECORD_TYPE="RECT";
	public static final String GSTR2_ADV_ADJUSTED_DUMP_URL="gstr2AdvAdjusted/dump/";
	public static final String GSTR2_ADV_PAID_DUMP_URL="advPaid/dump/";
	public static final String GSTR2_ITC_REVERSAL_DUMP_URL="itcReversal/dump/";
	
	public static final String GROUP_CODE = "groupCode";  
	public final static String GSP_USERDETAILS="GSP_USERDETAILS";
	public static final String GSP_DIGIGST_USERNAME = "digigst_username";
	
	public static final String RETURN_PERIOD_JOB="createMasterReturnPeriodJob";
	public static final String SMARTREPORTJOB="createSmartReportForEachGroupJob";
	
	public static final String RETURN_FILING_DETAILS_JOB="createClientReturnFilingDetailsJob";
    
	public static final String STATUS_SAVED="SAVED";
    public static final String WFS_DATAUPLOADED="DATAUPLOADED";
    public static final String WFS_PREPARED="PREPARED";
    public static final String WFS_REVIEWD="REVIEWD";
    public static final String WFS_APPROVED="APPROVED";
    public static final String ROLE_PREPARER="Preparer";
    public static final String ROLE_REVIEWR="Reviewer";
    public static final String ROLE_APPROVER="Approver";
    public static final String ACTION_APPROVE="Approve";
    public static final String ACTION_REJECT="Reject";
    
    public static final Integer FINAL_COMP_DATE = 11;
    public static final Integer ITC_REVERSAL_DATE = 21;
    public static final String EMPTY_XML_TEMPLATE="<NoData></NoData>";
    
    public static final String GSTR2_INWARD_SUPPLY="GSTR2IS";
    public static final String GSTR2_INWARD_TOTAL_DUMP_URL="inwardDump/doc/";
    	public static final String GSTR2_INWARD_DUPLICATE_DUMP_URL="inward/dupdump/";
    	public static final String GSTR2_INWARD_PROCESSED_DUMP_URL="inward/prosdump/";
    	public static final String GSTR2_INWARD_ERROR_DUMP_URL="inward/errordump/";
    	
    	//public static final String GSTR3_UPDATE__GSTR3_SAVECASH_PROC= "uspGSTR3SaveCash_Summary_Json";
    	public static final String GSTR6_SAVE_DETERMINATION= "uspGSTR6SaveDetermination";
    	public static final String SAVE_DETERMINATION_SCHEMA= "dbo";

    	public static final Object RCM_GSTR2 = "RCM_GSTR2";
    	public static final Object RCM_SMART_REPORT_GSTR2 = "RCM_SMART_REPORT_GSTR2";
    	
    	public static final String DETERMINATION_FILE_NAME="_DeterminationSheet_";
   
    	public static final String FINAL_ITC_COMPUTATION_FILE_NAME_DATE_FORMAT = "ddMMyy_HHmmss";
    	
    	public static final String CHECK_CLIENTGROUP_SETUP = "checkClientGroupSetup";
    	public static final Object RECTIFIED_GSTR1 = "RECTIFIED_GSTR1";
    	public static final String RECTIFICATION_GSTR1 = "RECTIFIED_GSTR1";
    	public static final String RECTIFICATION_GSTR2 = "RECTIFIED_GSTR2";
    	public static final String RECTIFICATION_GSTR6 = "RECTIFIED_GSTR6";
public static final String ITC_FINAL_COMPUTATION_DATA_INDICATOR="<CreditDeterminations>";
    	
    	public static final String ITC_REVERSAL_DATA_INDICATOR="<InputCreditGSTNLevel>";
    	public static final String SAML_ENDPOINT_URL ="SAML_ENDPOINT_URL";
		public static final String AUTH_TYPE="AUTH_TYPE";
		public static final String AUTH_TYE_SAML="SAML";
		public static final String SAML_ROLE_ANONYMOUS="ROLE_ANONYMOUS";
		public static final String SAML_LOGIN_URL="/saml/login";
		public static final String SAML_END_POINT_ENTRY_BEAN="samlEntryPoint";
		public static final String SAML_IDP_KEY="idp";
		public static final String SAML_LOGOUT_URL="/saml/logout";
		public static final String DOMAIN_NAME="DOMAIN_NAME";
		public static final String GROUP_DOMAIN_KEY="DOMAIN_";
		public static final String GROUP_CONFIG_KEY="CONFIG_";
		
		public static final String AUTH_SIGN_GSTIN_SET="authSignGstins";

		//Smart Reports
    	public static final String  FOLDER_STRUCT_SMARTF = "folder.structure.smartFile";
    	public static final String VIEW_REPORT_SATUS="asp-getSmartReportData";
    	public static final String SEARCH_REPORT_SATUS="asp-getSearchData";
    	public static final String CANCEL_REPORT_SATUS="asp-updateCancelStatus";
    	public static final String DOWNLOAD_SMART_REPORT="asp-getFileDetails";
		
    	public static final String GSTR2RECON_RESPONSE = "GSTR2RR";
    	public static final String RECON_REPORT_RESPONSE_METADATA = "recon_report_response_metadata";
    	public static final String RECON_REPORT_RESPONSE_MISMATCH_LIST = "recon_report_response_mismatch_list";
    	public static final String RECON_REPORT_RESPONSE_CONSOLIDATED_METADATA_URL = "asp-loadReconReportResponseConsolidatedMetadata";
    	public static final String RECON_REPORT_RESPONSE_CONSOLIDATED_METADATA = "RECON_REPORT_RESPONSE_CONSOLIDATED_METADATA";
		
		public static final String FY_TURNOVER = "FY_TURNOVER";
		public static final String QY_TURNOVER = "QY_TURNOVER";

		public static final String yyyy_MM_dd_hh_mm_ss = "yyyy-MM-dd HH:mm:ss";
		public static final String DUPLICATE = "DUPLICATE";
		//2A
		public static final String GSTR_2A_GSTRTYPE="2A"; 
	    public static final String GSTR_2A="GSTR2A";
	    public static final String GSTR2A_DOWNLOADED_STATUS = "DATA_RECEIVED";
	    public static final String GSTR2A_NEW_STATUS = "NEW";
	    public static final String TOKEN_RECEIVED = "TOKEN_RECEIVED";
	    public static final String RECON_MSG = "No incremental GSTR 2A data available for reconciliation.";
	    public static final String RECON_MSG_FOR_NEW_GSTR2A = "No data available to make Get Call for GSTR 2A";
	    public static final String RECON_MSG_FOR_INPROGRESS_GSTR2A = "No data available, a request for GSTR 2A is already pending";
	    public static final String RECON_MSG_FOR_SUCCESS_GSTR2A = "success";
	    public static final String GSTR2A_INPROGRESS_STATUS = "In-progress";
	    public static final String GSTR2A_GSTIN = "gstin";
	    public static final String GSTR2A_SUCCESS_MSG = "GSTR2A Downloaded Successfully!";
	    public static final String GSTR2A_INPROGRESS_MSG = "GSTR2A Download is in Progress... Please revisit after 30 mins for response!";
	    public static final String GSTR2A_RETPERIOD = "retPeriod";
	    public static final String GSTR2_RECON_INPROGRESS = "ReconInitiated";
	    public static final String RECON_MSG_FOR_RECON_INPROGRESS = "GSTR 2A Vs PR cannot be initiated, as a request is already in progress.";
	    public static final String GSTR2_RECON_SUCCESS = "GSTR 2A Vs PR has been initiated. You can download the GSTR 2A Vs PR Report after 30 mins.";
	    public static final String GSTR2_RECON_FAILURE = "GSTR 2A Vs PR cannot be initiated due to internal server issue.Kindly Contact Administrator.";
	    public static final String GSTR2_STATUS = "status";
	    public static final String GSTR2_RECON_STATUS = "reconStatus";
		public static final String GSTR2_LAST_RECON_DATE = "lastReconReq";
		public static final String RECON_STATUS="reconStatus";
		public static final String GSTR2_SUBMITTED_STATUS = "SUBMITTED";
		public static final String GSTR2_FILED_STATUS = "FILED";
		public static final List<String> FILE_CONTENT_TYPE = new ArrayList<>(Arrays.asList("text/csv","application/csv","application/json","application/vnd.ms-excel",
				"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/xml","text/html","text/plain","application/zip","application/x-zip-compressed",
				"application/octet-stream","text/xml","application/vnd.ms-excel.sheet.macroEnabled.12"));
		public static final String DOWNLOAD_GSTR2A_MSG_FOR_RECON_INPROGRESS = "GSTR2A cannot be downloaded, a request for GSTR 2A Vs PR is already in progress.";
		public static final String GSTR2_RECTIFIED_FILE_NAME ="GSTR2_RECTIFIED_";
		public static final String GSTR6_RECTIFIED_FILE_NAME ="GSTR6_RECTIFIED_";
		public static final String GSTR2_RECTIFIED_XML_START_TAG = "<PurchaseRectifiedReport>";
		public static final String GSTR2_RECTIFIED_XML_END_TAG = "</PurchaseRectifiedReport>";
		public static final String GSTR6_RECTIFIED_XML_START_TAG = "<ISDRectifiedErrorReports>";
		public static final String GSTR6_RECTIFIED_XML_END_TAG = "</ISDRectifiedErrorReports>";
		public static final String REPORT_TYPE = "Report_Type";
		public static final String RETURN_PERIOD_DROPDOWN = "Return_Period_DropDown";
		public static final String ROLE_LIST= "ROLE_LIST";
		public static final String GSTR2A_DATA_RECEIVED = "DATA_RECEIVED";
		public static final String GSTR2A_TOKEN_RECEIVED = "TOKEN_RECEIVED";
		public static final String GSTR2A_FAILED_B2B = "FAILED_B2B";
		public static final String GSTR2A_FAILED_CDN = "FAILED_CDN";
		public static final String GSTR2A_FAILED = "FAILED";
		public static final String GSTR2A_FAILED_B2B_CDN="FAILED_B2B_CDN";
		
		public static final String RECON_MSG_FOR_INPROGRESS_GSTR6A = "No data available, a request for GSTR 6A is already pending";
		public static final String DOWNLOAD_GSTR6A_MSG_FOR_RECON_INPROGRESS = "GSTR6A cannot be downloaded, a request for GSTR 6A Vs PR is already in progress.";
	    public static final String GSTR6A_SUCCESS_MSG = "GSTR6A Downloaded Successfully!";
	    public static final String GSTR6A_INPROGRESS_MSG = "GSTR6A Download is in Progress... Please revisit after 30 mins for response!";
	    public static final String GSTR6_RECON_SUCCESS = "GSTR 6A Vs PR has been initiated. You can download the GSTR 6A Vs PR Report after 30 mins.";
	    public static final String RECON_MSG_FOR_NEW_GSTR6A = "No data available, make Get Call for GSTR 6A";
	    public static final String RECON_MSG_FOR_GSTR6_RECON_INPROGRESS = "GSTR 6A Vs PR cannot be initiated, as a request is already in progress.";


		public static final Object OTP_AUTHENTICATION = "OTP_AUTHENTICATION";
		
		public static final String QUESTIONANSWER_MAPPING = "QUESTIONANSWER_MAPPING";
		//Adding for Edit Client
		public static final String REDIS_KEY_EDIT_CLIENT = "editClient";
		
		public static final String GSTR1_SAVE_STATUS_PE_ERROR_REPORT = "PE";
		public static final String GSTR1_SAVE_STATUS_PE_ERROR_REPORT_FILE_NAME = "GSTR1_GSTN_PE_ERROR_"; 

		public static final String GSTR2A_XML_START_TAG = "";
		public static final String GSTR2A_XML_END_TAG = "";
		public static final String GSTR2F_XML_START_TAG = "";
		public static final String GSTR2F_XML_END_TAG = "";
		public static final String GSTR2A_DUMP = "GSTR2A";
		public static final String GSTR2F_DUMP = "GSTR2F";
		
		public static final String GSTR2_SAVE_STATUS_PE_ERROR_REPORT = "PE";
		public static final String GSTR2_SAVE_STATUS_PE_ERROR_REPORT_FILE_NAME = "GSTR2_GSTN_PE_ERROR_";
		public static final String MOBILENUMBER = "mobileno";
		public static final String MASKMOBILENUMBER = "maskmobileno";
		public static final Object FAILED_MESSAGE = "OTP Generation failed";
		public static final String OTP_VALIDATION_VIEW = "otpValidation";
		public static final String ERROR_PAGE_VIEW = "errorPage"; 
		public static final String INTERNATIONAL_MOBILEPHONECODE = "international-mobilePhoneCode";
		public static final String INDIAN_MOBILECODE = "indian-mobileCode";
		public static final String GENERATE_OTP_VIEW = "generateOTP";
		public static final String GSTR2_GENERATED_RECON_REPORTS = "generatedReconReports";
		public static final Object USERNAME = "username";
		public static final String MFA_SUCCESS = "mfa_succ";
		
		public static final String GSTR3_ENABLE_STAT = "Gstr3_Enable";
		public static final String GSTR1AND2_CHK_REQ_STAT ="Gstr1And2_chk"; 
		
		public static final String CASH_ITC_RESERVED = "cashItcReserved";
		public static final String CASH_ITC_UTILIZATION = "cashITCUtilization";
		public static final boolean GSP_VALIDATION = false;
		public static final String USER_EMAILID = "userEmailId";
		public static final String SUBMITTED = "SUBMITTED";
		
		//Added for SmartReport Changes
		public static final String USER_ID = "userID";
		public static final String RESET_CHUNK_VIEW = "resetChunk";
		public static final String RETURN_TYPE_GSTR1 = "GSTR1";
		public static final String RETURN_TYPE_GSTR2 = "GSTR2";
		public static final String ENTITY_ID = "entityId";
		public static final String RETURN_TYPE = "returnType";
		public static final String TABLE_TYPE = "tableType";
		public static final String RETURN_TYPE_MAPPING = "TblReturnTypeRecordTypeMapping";
		public static final String TBLRETURNTYPE_RECORDTYPEMAPPING = "TblReturnTypeRecordTypeMapping";
		public static final String DISTRIBUTION_TURNOVER_DATA = "dtTurnOverJson";
		public static final String GROUPS = "groups";
		public static final String SELECT_MANDATORY_FIELDS = "Please select mandatory field";
		public static final String STARTDATE = "062017";
		public static final String FY17 = "FY17";
		
		public static final String GSTR6_SAVE_STATUS_PE_ERROR_REPORT = "PE";
		public static final String REFERENCE_ID = "refId";
		
		public static final String GSTR_SAVE_STATUS_PE_ERROR_REPORT = "PE";
		
		public static final String RETURNT_TYPE_GSTR1 = "GSTR1";
		
		public static final String RETURNT_TYPE_GSTR2 = "GSTR2";
		
		public static final String RETURNT_TYPE_GSTR6 = "GSTR6";
		//GSTR6A 
		public static final String GSTR_GSTIN = "gstin";
		public static final String GSTR_RETPERIOD = "retPeriod";
		public static final String GSTR_STATUS = "status";
		public static final String GSTR_RECON_STATUS = "reconStatus";
		public static final String GSTR_RECON_INPROGRESS = "ReconInitiated";
		public static final String GSTR_SUBMITTED_STATUS = "SUBMITTED";
		public static final String GSTR_FILED_STATUS = "FILED";
		public static final String GSTR_DOWNLOADED_STATUS = "DATA_RECEIVED";
		public static final String GSTR_DATA_RECEIVED = "DATA_RECEIVED";
		public static final String GSTR_TOKEN_RECEIVED = "TOKEN_RECEIVED";
		public static final String GSTR_INPROGRESS_STATUS = "In-progress";
		public static final String GSTR_FAILED_B2B = "FAILED_B2B";
		public static final String GSTR_FAILED_CDN = "FAILED_CDN";
		public static final String GSTR_FAILED = "FAILED";
		public static final String GSTR_FAILED_B2B_CDN="FAILED_B2B_CDN";
		public static final String GSTR6RECON_RESPONSE = "GSTR6RR";
		public static final String RECON_REPORT_RESPONSE_CONSOLIDATED_METADATA_URL_GSTR6 = "asp-loadReconReportResponseConsolidatedMetadataGstr6";
		public static final String CLIENT_IP = "ip-usr";
		public static final String CO_RELATION_ID = "co-relation-id";
		public static final String USER_PRINCIPAL = "user-principal";
		public static final String UNKNOWN_USER = "UNKNOWN_USER";
		public static final String LOGIN_URL="/login.jsp";
		
		//GSTN error report
		public static final String NO_GSTN_DATA_FOUND = "NO_GSTN_DATA_FOUND";
		public static final String EXCEPTION_AT_GSTN_ERROR = "EXCEPTION_AT_GSTN_ERROR";
}