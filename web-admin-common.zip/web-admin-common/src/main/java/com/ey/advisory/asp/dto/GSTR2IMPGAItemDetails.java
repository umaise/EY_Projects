package com.ey.advisory.asp.dto;


public class GSTR2IMPGAItemDetails {
	
	private Long lineNo;
	
	private String hscSc;

	private Float itemTxval;

	private Float igstRt;

	private Float igstAmt;
	
	private String itcEligiblity;
	
	private Float itcIGSTAmt;
	
	private Float tcIGSTAmt;
	
	private Long invDetailsId;
	
	private Float txValue;

	

	public Long getLineNo() {
		return lineNo;
	}

	public void setLineNo(Long lineNo) {
		this.lineNo = lineNo;
	}

	

	public String getHscSc() {
		return hscSc;
	}

	public void setHscSc(String hscSc) {
		this.hscSc = hscSc;
	}

	/**
	 * @return the itemTxval
	 */
	public Float getItemTxval() {
		return itemTxval;
	}

	/**
	 * @param itemTxval the itemTxval to set
	 */
	public void setItemTxval(Float itemTxval) {
		this.itemTxval = itemTxval;
	}

	/**
	 * @return the igstRt
	 */
	public Float getIgstRt() {
		return igstRt;
	}

	/**
	 * @param igstRt the igstRt to set
	 */
	public void setIgstRt(Float igstRt) {
		this.igstRt = igstRt;
	}

	/**
	 * @return the igstAmt
	 */
	public Float getIgstAmt() {
		return igstAmt;
	}

	/**
	 * @param igstAmt the igstAmt to set
	 */
	public void setIgstAmt(Float igstAmt) {
		this.igstAmt = igstAmt;
	}

	/**
	 * @return the itcEligiblity
	 */
	public String getItcEligiblity() {
		return itcEligiblity;
	}

	/**
	 * @param itcEligiblity the itcEligiblity to set
	 */
	public void setItcEligiblity(String itcEligiblity) {
		this.itcEligiblity = itcEligiblity;
	}

	/**
	 * @return the itcIGSTAmt
	 */
	public Float getItcIGSTAmt() {
		return itcIGSTAmt;
	}

	/**
	 * @param itcIGSTAmt the itcIGSTAmt to set
	 */
	public void setItcIGSTAmt(Float itcIGSTAmt) {
		this.itcIGSTAmt = itcIGSTAmt;
	}

	/**
	 * @return the tcIGSTAmt
	 */
	public Float getTcIGSTAmt() {
		return tcIGSTAmt;
	}

	/**
	 * @param tcIGSTAmt the tcIGSTAmt to set
	 */
	public void setTcIGSTAmt(Float tcIGSTAmt) {
		this.tcIGSTAmt = tcIGSTAmt;
	}

	/**
	 * @return the invDetailsId
	 */
	public Long getInvDetailsId() {
		return invDetailsId;
	}

	/**
	 * @param invDetailsId the invDetailsId to set
	 */
	public void setInvDetailsId(Long invDetailsId) {
		this.invDetailsId = invDetailsId;
	}

	/**
	 * @return the txValue
	 */
	public Float getTxValue() {
		return txValue;
	}

	/**
	 * @param txValue the txValue to set
	 */
	public void setTxValue(Float txValue) {
		this.txValue = txValue;
	}
	
}
