/**
 * 
 */
package com.ey.advisory.asp.dto;


/**
 * @author Uma.Chandranaik
 *
 */

public class CashITCUtilizationDto{

	private double igstTaxPayable;
	private double igstIntPayable;
	private double igstLateFee;
	private double igstTaxPaid;
	private double igstITCInt;
	private double igstITCCent;
	private double igstITCState;
	private double igstITCCess;
	private double igstCashPaid;
	private double igstIntPaid;
	private double igstLateFeePaid;
	private double cgstTaxPayable;
	private double cgstIntPayable;
	private double cgstLateFee;
	private double cgstTaxPaid;
	private double cgstITCInt;
	private double cgstITCCent;
	private double cgstITCState;
	private double cgstITCCess;
	private double cgstCashPaid;
	private double cgstIntPaid;
	private double cgstLateFeePaid;
	private double sgstTaxPayable;
	private double sgstIntPayable;
	private double sgstLateFee;
	private double sgstTaxPaid;
	private double sgstITCInt;
	private double sgstITCCent;
	private double sgstITCState;
	private double sgstITCCess;
	private double sgstCashPaid;
	private double sgstIntPaid;
	private double sgstLateFeePaid;
	private double cessTaxPayable;
	private double cessIntPayable;
	private double cessLateFee;
	private double cessTaxPaid;
	private double cessITCInt;
	private double cessITCCent;
	private double cessITCState;
	private double cessITCCess;
	private double cessCashPaid;
	private double cessIntPaid;
	private double cessLateFeePaid;
	
	private String gstinId;
	private String taxPeriod;
	private String cashITCJson;
	public double getIgstTaxPayable() {
		return igstTaxPayable;
	}
	public void setIgstTaxPayable(double igstTaxPayable) {
		this.igstTaxPayable = igstTaxPayable;
	}
	public double getIgstIntPayable() {
		return igstIntPayable;
	}
	public void setIgstIntPayable(double igstIntPayable) {
		this.igstIntPayable = igstIntPayable;
	}
	public double getIgstLateFee() {
		return igstLateFee;
	}
	public void setIgstLateFee(double igstLateFee) {
		this.igstLateFee = igstLateFee;
	}
	public double getIgstTaxPaid() {
		return igstTaxPaid;
	}
	public void setIgstTaxPaid(double igstTaxPaid) {
		this.igstTaxPaid = igstTaxPaid;
	}
	public double getIgstITCInt() {
		return igstITCInt;
	}
	public void setIgstITCInt(double igstITCInt) {
		this.igstITCInt = igstITCInt;
	}
	public double getIgstITCCent() {
		return igstITCCent;
	}
	public void setIgstITCCent(double igstITCCent) {
		this.igstITCCent = igstITCCent;
	}
	public double getIgstITCState() {
		return igstITCState;
	}
	public void setIgstITCState(double igstITCState) {
		this.igstITCState = igstITCState;
	}
	public double getIgstITCCess() {
		return igstITCCess;
	}
	public void setIgstITCCess(double igstITCCess) {
		this.igstITCCess = igstITCCess;
	}
	public double getIgstCashPaid() {
		return igstCashPaid;
	}
	public void setIgstCashPaid(double igstCashPaid) {
		this.igstCashPaid = igstCashPaid;
	}
	public double getIgstIntPaid() {
		return igstIntPaid;
	}
	public void setIgstIntPaid(double igstIntPaid) {
		this.igstIntPaid = igstIntPaid;
	}
	public double getIgstLateFeePaid() {
		return igstLateFeePaid;
	}
	public void setIgstLateFeePaid(double igstLateFeePaid) {
		this.igstLateFeePaid = igstLateFeePaid;
	}
	public double getCgstTaxPayable() {
		return cgstTaxPayable;
	}
	public void setCgstTaxPayable(double cgstTaxPayable) {
		this.cgstTaxPayable = cgstTaxPayable;
	}
	public double getCgstIntPayable() {
		return cgstIntPayable;
	}
	public void setCgstIntPayable(double cgstIntPayable) {
		this.cgstIntPayable = cgstIntPayable;
	}
	public double getCgstLateFee() {
		return cgstLateFee;
	}
	public void setCgstLateFee(double cgstLateFee) {
		this.cgstLateFee = cgstLateFee;
	}
	public double getCgstTaxPaid() {
		return cgstTaxPaid;
	}
	public void setCgstTaxPaid(double cgstTaxPaid) {
		this.cgstTaxPaid = cgstTaxPaid;
	}
	public double getCgstITCInt() {
		return cgstITCInt;
	}
	public void setCgstITCInt(double cgstITCInt) {
		this.cgstITCInt = cgstITCInt;
	}
	public double getCgstITCCent() {
		return cgstITCCent;
	}
	public void setCgstITCCent(double cgstITCCent) {
		this.cgstITCCent = cgstITCCent;
	}
	public double getCgstITCState() {
		return cgstITCState;
	}
	public void setCgstITCState(double cgstITCState) {
		this.cgstITCState = cgstITCState;
	}
	public double getCgstITCCess() {
		return cgstITCCess;
	}
	public void setCgstITCCess(double cgstITCCess) {
		this.cgstITCCess = cgstITCCess;
	}
	public double getCgstCashPaid() {
		return cgstCashPaid;
	}
	public void setCgstCashPaid(double cgstCashPaid) {
		this.cgstCashPaid = cgstCashPaid;
	}
	public double getCgstIntPaid() {
		return cgstIntPaid;
	}
	public void setCgstIntPaid(double cgstIntPaid) {
		this.cgstIntPaid = cgstIntPaid;
	}
	public double getCgstLateFeePaid() {
		return cgstLateFeePaid;
	}
	public void setCgstLateFeePaid(double cgstLateFeePaid) {
		this.cgstLateFeePaid = cgstLateFeePaid;
	}
	public double getSgstTaxPayable() {
		return sgstTaxPayable;
	}
	public void setSgstTaxPayable(double sgstTaxPayable) {
		this.sgstTaxPayable = sgstTaxPayable;
	}
	public double getSgstIntPayable() {
		return sgstIntPayable;
	}
	public void setSgstIntPayable(double sgstIntPayable) {
		this.sgstIntPayable = sgstIntPayable;
	}
	public double getSgstLateFee() {
		return sgstLateFee;
	}
	public void setSgstLateFee(double sgstLateFee) {
		this.sgstLateFee = sgstLateFee;
	}
	public double getSgstTaxPaid() {
		return sgstTaxPaid;
	}
	public void setSgstTaxPaid(double sgstTaxPaid) {
		this.sgstTaxPaid = sgstTaxPaid;
	}
	public double getSgstITCInt() {
		return sgstITCInt;
	}
	public void setSgstITCInt(double sgstITCInt) {
		this.sgstITCInt = sgstITCInt;
	}
	public double getSgstITCCent() {
		return sgstITCCent;
	}
	public void setSgstITCCent(double sgstITCCent) {
		this.sgstITCCent = sgstITCCent;
	}
	public double getSgstITCState() {
		return sgstITCState;
	}
	public void setSgstITCState(double sgstITCState) {
		this.sgstITCState = sgstITCState;
	}
	public double getSgstITCCess() {
		return sgstITCCess;
	}
	public void setSgstITCCess(double sgstITCCess) {
		this.sgstITCCess = sgstITCCess;
	}
	public double getSgstCashPaid() {
		return sgstCashPaid;
	}
	public void setSgstCashPaid(double sgstCashPaid) {
		this.sgstCashPaid = sgstCashPaid;
	}
	public double getSgstIntPaid() {
		return sgstIntPaid;
	}
	public void setSgstIntPaid(double sgstIntPaid) {
		this.sgstIntPaid = sgstIntPaid;
	}
	public double getSgstLateFeePaid() {
		return sgstLateFeePaid;
	}
	public void setSgstLateFeePaid(double sgstLateFeePaid) {
		this.sgstLateFeePaid = sgstLateFeePaid;
	}
	public double getCessTaxPayable() {
		return cessTaxPayable;
	}
	public void setCessTaxPayable(double cessTaxPayable) {
		this.cessTaxPayable = cessTaxPayable;
	}
	public double getCessIntPayable() {
		return cessIntPayable;
	}
	public void setCessIntPayable(double cessIntPayable) {
		this.cessIntPayable = cessIntPayable;
	}
	public double getCessLateFee() {
		return cessLateFee;
	}
	public void setCessLateFee(double cessLateFee) {
		this.cessLateFee = cessLateFee;
	}
	public double getCessTaxPaid() {
		return cessTaxPaid;
	}
	public void setCessTaxPaid(double cessTaxPaid) {
		this.cessTaxPaid = cessTaxPaid;
	}
	public double getCessITCInt() {
		return cessITCInt;
	}
	public void setCessITCInt(double cessITCInt) {
		this.cessITCInt = cessITCInt;
	}
	public double getCessITCCent() {
		return cessITCCent;
	}
	public void setCessITCCent(double cessITCCent) {
		this.cessITCCent = cessITCCent;
	}
	public double getCessITCState() {
		return cessITCState;
	}
	public void setCessITCState(double cessITCState) {
		this.cessITCState = cessITCState;
	}
	public double getCessITCCess() {
		return cessITCCess;
	}
	public void setCessITCCess(double cessITCCess) {
		this.cessITCCess = cessITCCess;
	}
	public double getCessCashPaid() {
		return cessCashPaid;
	}
	public void setCessCashPaid(double cessCashPaid) {
		this.cessCashPaid = cessCashPaid;
	}
	public double getCessIntPaid() {
		return cessIntPaid;
	}
	public void setCessIntPaid(double cessIntPaid) {
		this.cessIntPaid = cessIntPaid;
	}
	public double getCessLateFeePaid() {
		return cessLateFeePaid;
	}
	public void setCessLateFeePaid(double cessLateFeePaid) {
		this.cessLateFeePaid = cessLateFeePaid;
	}
	public String getGstinId() {
		return gstinId;
	}
	public void setGstinId(String gstinId) {
		this.gstinId = gstinId;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	public String getCashITCJson() {
		return cashITCJson;
	}
	public void setCashITCJson(String cashITCJson) {
		this.cashITCJson = cashITCJson;
	}
 	
}
