package com.ey.advisory.asp;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
 
@Controller
public class SessionController {
	
	
	@RequestMapping ( "/session" )
	public String showSession ( HttpSession session, Model model ) {
		model.addAttribute("sessionId", session.getId() );
		model.addAttribute("sessionNew", session.isNew());
		
		return "home";
	}
}