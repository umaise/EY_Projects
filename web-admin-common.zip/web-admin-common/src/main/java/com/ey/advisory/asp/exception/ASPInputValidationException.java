package com.ey.advisory.asp.exception;

public class ASPInputValidationException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String message;


	public ASPInputValidationException(String message) {
		 this.message = message;
	}

	@Override
	public String getMessage() {

		return message;

	}
}
