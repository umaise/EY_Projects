package com.ey.advisory.asp.dto;

public class GSTR2ATAItems {
	
	private Character itemType;
	
	private String hsnSC;
	
	private Float txValue;
	
	private Float igstRt;

	private Float igstAmt;

	private Float cgstRt;

	private Float cgstAmt;

	private Float sgstRt;

	private Float sgstAmt;
	
	private Float txbleValue;
	
	private Long taxLid;

	/**
	 * @return the itemType
	 */
	public Character getItemType() {
		return itemType;
	}

	/**
	 * @param itemType the itemType to set
	 */
	public void setItemType(Character itemType) {
		this.itemType = itemType;
	}

	/**
	 * @return the hsnSC
	 */
	public String getHsnSC() {
		return hsnSC;
	}

	/**
	 * @param hsnSC the hsnSC to set
	 */
	public void setHsnSC(String hsnSC) {
		this.hsnSC = hsnSC;
	}

	/**
	 * @return the txValue
	 */
	public Float getTxValue() {
		return txValue;
	}

	/**
	 * @param txValue the txValue to set
	 */
	public void setTxValue(Float txValue) {
		this.txValue = txValue;
	}

	/**
	 * @return the igstRt
	 */
	public Float getIgstRt() {
		return igstRt;
	}

	/**
	 * @param igstRt the igstRt to set
	 */
	public void setIgstRt(Float igstRt) {
		this.igstRt = igstRt;
	}

	/**
	 * @return the igstAmt
	 */
	public Float getIgstAmt() {
		return igstAmt;
	}

	/**
	 * @param igstAmt the igstAmt to set
	 */
	public void setIgstAmt(Float igstAmt) {
		this.igstAmt = igstAmt;
	}

	/**
	 * @return the cgstRt
	 */
	public Float getCgstRt() {
		return cgstRt;
	}

	/**
	 * @param cgstRt the cgstRt to set
	 */
	public void setCgstRt(Float cgstRt) {
		this.cgstRt = cgstRt;
	}

	/**
	 * @return the cgstAmt
	 */
	public Float getCgstAmt() {
		return cgstAmt;
	}

	/**
	 * @param cgstAmt the cgstAmt to set
	 */
	public void setCgstAmt(Float cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	/**
	 * @return the sgstRt
	 */
	public Float getSgstRt() {
		return sgstRt;
	}

	/**
	 * @param sgstRt the sgstRt to set
	 */
	public void setSgstRt(Float sgstRt) {
		this.sgstRt = sgstRt;
	}

	/**
	 * @return the sgstAmt
	 */
	public Float getSgstAmt() {
		return sgstAmt;
	}

	/**
	 * @param sgstAmt the sgstAmt to set
	 */
	public void setSgstAmt(Float sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	/**
	 * @return the txbleValue
	 */
	public Float getTxbleValue() {
		return txbleValue;
	}

	/**
	 * @param txbleValue the txbleValue to set
	 */
	public void setTxbleValue(Float txbleValue) {
		this.txbleValue = txbleValue;
	}

	public Long getTaxLid() {
		return taxLid;
	}

	public void setTaxLid(Long taxLid) {
		this.taxLid = taxLid;
	}

	

}
