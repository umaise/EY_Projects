package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;



public class GSTR2IMPGInvoiceDetails implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	
	private Character flag;
	
	private String chksum;
	
	private String invNum;
	
	private Date invDate;
	
	private Float invValue;
	
	private Long taxPayerId;
	
	private Float taxableVal;
	
	private List<GSTR2IMPGItemDetails> gstr2IMPGDetails;
	
	private int invoiceCnt;
	
	private Float igstTotal;

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Character getFlag() {
		return flag;
	}

	public void setFlag(Character flag) {
		this.flag = flag;
	}

	public String getChksum() {
		return chksum;
	}

	public void setChksum(String chksum) {
		this.chksum = chksum;
	}
	
	public String getInvNum() {
		return invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public Date getInvDate() {
		return invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public Float getInvValue() {
		return invValue;
	}

	public void setInvValue(Float invValue) {
		this.invValue = invValue;
	}

	public Long getTaxPayerId() {
		return taxPayerId;
	}

	public void setTaxPayerId(Long taxPayerId) {
		this.taxPayerId = taxPayerId;
	}
	
	public Float getTaxableVal() {
		return taxableVal;
	}

	public void setTaxableVal(Float taxableVal) {
		this.taxableVal = taxableVal;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}

	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}

	public List<GSTR2IMPGItemDetails> getGstr2IMPGDetails() {
		return gstr2IMPGDetails;
	}

	public void setGstr2IMPGDetails(List<GSTR2IMPGItemDetails> gstr2impgDetails) {
		gstr2IMPGDetails = gstr2impgDetails;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	



}
