package com.ey.advisory.asp.reports.jasper.entity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class GSTR7SummaryData {
	
	@Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String reportName;
	
	@Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	 String gstnId;
	
	@Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String businessName;
	
	String gstr7Sum;
	
	@Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String dueDate;
	
	@Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String fYear;
	
	@Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String returnPeriod;
	 
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public String getGstr7Sum() {
		return gstr7Sum;
	}
	public void setGstr7Sum(String gstr7Sum) {
		this.gstr7Sum = gstr7Sum;
	}
	public String getGstnId() {
		return gstnId;
	}
	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getfYear() {
		return fYear;
	}
	public void setfYear(String fYear) {
		this.fYear = fYear;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	 
	 
	 
}
