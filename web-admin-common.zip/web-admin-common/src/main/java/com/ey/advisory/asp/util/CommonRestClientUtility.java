package com.ey.advisory.asp.util;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Arrays;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.exception.RestCustomException;

@Component
public class CommonRestClientUtility {

	@Autowired
	RestTemplate restTemplate;

	SSLSocketFactory sslCont = null;

	private static Logger logger = Logger.getLogger(CommonRestClientUtility.class);
    private static final String CLASS_NAME = CommonRestClientUtility.class.getName();

	public String getForEntity(String uri) {
	
		String result = "";
		try {
			ResponseEntity<String> response = restTemplate.getForEntity(uri, String.class);
			result = response.getBody();
		} catch (HttpStatusCodeException hsce) {
			logger.error(hsce);
			if (hsce instanceof HttpClientErrorException) {
				return hsce.getMessage();
			} else {
				return hsce.getResponseBodyAsString();
			}
		} catch (RestClientException rce) {
			logger.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			logger.error(e);
			return e.getMessage();
		}

		return result;
	}

	public String executeRestCall(String uri, HttpHeaders httpHeaders, String inputData, HttpMethod httpMethod) {

		String result = "";
		HttpEntity<String> entity = new HttpEntity<>(inputData,  httpHeaders);
		try {
			ResponseEntity<String> response = restTemplate.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpStatusCodeException hsce) {
			if (hsce instanceof HttpClientErrorException)
				return hsce.getMessage();
			else
				return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			logger.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			logger.error(e);
			return e.getMessage();
		}

		return result;
	}

	public String executeRestCall(String uri, HttpServletRequest request, String inputData, HttpMethod httpMethod) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		String result = "";
		HttpEntity<String> entity = new HttpEntity<>(inputData, getCustomHeaders(httpHeaders, request));
		try {
			ResponseEntity<String> response = restTemplate.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpStatusCodeException hsce) {
			logger.error(hsce);
			if (hsce instanceof HttpClientErrorException) {
				return hsce.getMessage();
			} else {
				return hsce.getResponseBodyAsString();
			}
		} catch (RestClientException rce) {
			logger.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			logger.error(e);
			return e.getMessage();
		}

		return result;
	}

	public String executeRestCall(String uri, HttpServletRequest request, HttpMethod httpMethod) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		String result = "";
		HttpEntity<String> entity = new HttpEntity<>(getCustomHeaders(httpHeaders, request));
		try {
			ResponseEntity<String> response = restTemplate.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpStatusCodeException hsce) {
			logger.error(hsce);
			if (hsce instanceof HttpClientErrorException) {
				return hsce.getMessage();
			} else {
				return hsce.getResponseBodyAsString();
			}
		} catch (RestClientException rce) {
			logger.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			logger.error(e);
			return e.getMessage();
		}

		return result;
	}

	public String executeRestCall(String uri, HttpServletRequest request, Object inputData, HttpMethod httpMethod) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		String result = "";
		HttpEntity<Object> entity = new HttpEntity<>(inputData, getCustomHeaders(httpHeaders, request));
		try {
			ResponseEntity<String> response = restTemplate.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpStatusCodeException hsce) {
			logger.error(hsce);
			if (hsce instanceof HttpClientErrorException)
				return hsce.getMessage();
			else
				return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			logger.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			logger.error(e);
			return e.getMessage();
		}

		return result;
	}

	public HttpHeaders getCustomHeaders(HttpHeaders httpHeaders, HttpServletRequest request) {
		String ipAddress = request.getHeader("X-FORWARDED-FOR");
		if (ipAddress == null) {
			ipAddress = request.getRemoteAddr();
		}
		httpHeaders.remove(Constant.CLIENT_IP);
		httpHeaders.remove(Constant.CO_RELATION_ID);
		httpHeaders.remove(Constant.USER_PRINCIPAL);
		httpHeaders.add(Constant.CLIENT_IP, MDC.get(Constant.CLIENT_IP));
		httpHeaders.add(Constant.CO_RELATION_ID, request.getSession(false).getId());
		httpHeaders.add(Constant.USER_PRINCIPAL, MDC.get(Constant.USER_PRINCIPAL));
		return httpHeaders;

	}

	public ResponseEntity<Object> executeRestApiCall(String uri, String inputData, HttpServletRequest request,
			HttpMethod httpMethod, Class classz) throws RestCustomException {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		ResponseEntity<Object> response = null;
		HttpEntity<Object> entity = new HttpEntity<>(inputData, getCustomHeaders(httpHeaders, request));

		try {
			response = restTemplate.exchange(uri, httpMethod, entity, classz);
		} catch (HttpStatusCodeException hsce) {
			logger.error(hsce);
			if (hsce instanceof HttpClientErrorException)
				throw new RestCustomException(hsce.getMessage());
			else
				throw new RestCustomException(hsce.getResponseBodyAsString());
		} catch (RestClientException rce) {
			logger.error(rce);
			throw new RestCustomException(rce.getMessage());
		} catch (Exception e) {
			logger.error(e);
			throw new RestCustomException(e.getMessage());
		}

		return response;
	}

	public String executeRestCallTest(String uri, HttpHeaders httpHeaders, String inputData, HttpMethod httpMethod) {
		enableSSL();
		String result = "";
		HttpEntity<String> entity = new HttpEntity<>(inputData, httpHeaders);
		try {
			ResponseEntity<String> response = restTemplate.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpStatusCodeException hsce) {
			logger.error(hsce);
			if (hsce instanceof HttpClientErrorException)
				return hsce.getMessage();
			else
				return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			logger.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			logger.error(e);
			return e.getMessage();
		}
		disableSsl();

		return result;
	}

	 private void enableSSL() {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
                	 @Override
			public void checkClientTrusted(java.security.cert.X509Certificate[] x509Certificates, String s)
					throws CertificateException {
                     }

                	 @Override
			public void checkServerTrusted(java.security.cert.X509Certificate[] x509Certificates, String s)
					throws CertificateException {
                     }

                	 @Override
                     public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                         return new java.security.cert.X509Certificate[0];
                     }
		} };
    	 HostnameVerifier hostnameVerifier = new HostnameVerifier() {
    		 @Override
             public boolean verify(String hostname, SSLSession sslSession) {
                 return true;
             }
         };
         sslCont = HttpsURLConnection.getDefaultSSLSocketFactory();
         SSLContext sslContext = null;
		try {
			sslContext = SSLContext.getInstance("TLSv1.2");
		    sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
             HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
             HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);
         } catch (KeyManagementException e) {
			logger.error("Exception in " + CLASS_NAME + " Method : createJSONString", e);
         } catch (NoSuchAlgorithmException e1) {
			logger.error("Exception in " + CLASS_NAME + " Method : createJSONString", e1);
 		}

    }

	public void disableSsl() {
		 HttpsURLConnection.setDefaultSSLSocketFactory(sslCont);
	}

	public <T> ResponseEntity<T> executeRestApiCall(String uri, Object inputData, HttpMethod httpMethod,
			Class<T> classz) throws RestCustomException {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			ResponseEntity<T> response = null;
			HttpEntity<Object> entity = new HttpEntity<>(inputData);

			try {
				response = restTemplate.exchange(uri, httpMethod, entity, classz);
			} catch (HttpStatusCodeException hsce) {
				logger.error(hsce);
				if (hsce instanceof HttpClientErrorException)
					throw new RestCustomException(hsce.getMessage());
				else
					throw new RestCustomException(hsce.getResponseBodyAsString());
			} catch (RestClientException rce) {
				logger.error(rce);
				throw new RestCustomException(rce.getMessage());
			} catch (Exception e) {
				logger.error(e);
				throw new RestCustomException(e.getMessage());
			}

			return response;
		}

    public ResponseEntity<byte[]> executeRestApiCallGet(String uri) throws RestCustomException {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
        ResponseEntity<byte[]> response = null;
        HttpEntity<String> entity = new HttpEntity<>(httpHeaders);
        try {
            response = restTemplate.exchange(uri, HttpMethod.GET, entity, byte[].class, "1");
		} catch (HttpStatusCodeException hsce) {
        	logger.error(hsce);
            if (hsce instanceof HttpClientErrorException)
                throw new RestCustomException(hsce.getMessage());
            else
                throw new RestCustomException(hsce.getResponseBodyAsString());
		} catch (RestClientException rce) {
            logger.error(rce);
            throw new RestCustomException(rce.getMessage());
		} catch (Exception e) {
            logger.error(e);
            throw new RestCustomException(e.getMessage());
        }

        return response;
    }

    /* Rest service method to stream the response asynchronously */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Async
	public void streamBytes(String uri, String fileName, HttpServletResponse response) throws RestCustomException {

		restTemplate.getMessageConverters().add(new ByteArrayHttpMessageConverter());
		try {
			RequestCallback requestCallback = new RequestCallback() {
				@Override
				public void doWithRequest(ClientHttpRequest request) throws IOException {
					request.getHeaders().setContentType(MediaType.APPLICATION_OCTET_STREAM);
					request.getHeaders().setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
				}
			};
			ResponseExtractor responseExtractor = new ResponseExtractor() {
				@Override
				public Object extractData(ClientHttpResponse arg0) throws IOException {
					IOUtils.copy(arg0.getBody(), response.getOutputStream());
					return response;
				}
			};

			restTemplate.execute(uri, HttpMethod.GET, requestCallback, responseExtractor);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

	}

}
