/**
 * 
 */
package com.ey.advisory.asp.filter;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.GroupAzureAdConfigDto;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;

/**
 * @author Nitesh.Tripathi
 *
 */

@Component("myFirstFilter")
public class FirstFilter implements Filter {

	private static final Logger LOGGER = Logger.getLogger(FirstFilter.class);

	@Autowired
	private RedisOperationForSessionObj redisOp;

	@Value("${isEyLogin}")
	private String isEyLogin;

	@Value("${isHeaderLoggingIson}")
	private String isHeaderLoggingIson;

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}
	
	@SuppressWarnings("unused")
	private String checkForCookie(HttpServletRequest pHttpRequest, String pCookieName) {
		
		String custJsessionId = "";
		
		Object HostValue = pHttpRequest.getHeader("Cookie");
		try{
			
			if(HostValue !=null){
				String cookie = HostValue.toString();
				LOGGER.info("pHttpRequest.getHeader( cookie " + cookie);
				String[] cookieArr = cookie.split(";");
				if(cookieArr !=null){
					for(String cookieStr : cookieArr){
						if(cookieStr.contains(pCookieName) && !(cookieStr.contains("_"+pCookieName))){
							custJsessionId = cookieStr.substring(cookieStr.indexOf("=")+1).trim();
							break;
						}
						
					}
				}
			}
			
			
			
		}catch(Throwable e){
			LOGGER.fatal("IdVal Throwable e: "+ e.getMessage());
		}
			
			
		return custJsessionId;
	}
	
	


	@SuppressWarnings("rawtypes")
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		if (request instanceof HttpServletRequest) {
			HttpServletRequest httpRequest = (HttpServletRequest) request;
			HttpServletResponse httpResponse = (HttpServletResponse) response;
			
			httpResponse.setHeader("Cache-Control", "no-cache");
			httpResponse.setHeader("Cache-Control", "no-store");
			httpResponse.setDateHeader("Expires", 0);
			httpResponse.setHeader("Pragma", "no-cache");

			HttpSession httpsession = httpRequest.getSession();
			LOGGER.fatal(" FirstFilter-ours : httpsession " + (httpsession == null ? "" : httpsession.getId()));
			
			
			//get the User Redis Key from Session object
			Object objUserRedisKey = httpsession==null?null : httpsession.getAttribute("userRedisKey");
			String userRedisKey = "";
			if(objUserRedisKey != null && objUserRedisKey.toString().length()>0){
				userRedisKey = objUserRedisKey.toString();
				LOGGER.fatal("if block userRedisKey:"+ userRedisKey);
			}else{
				LOGGER.fatal("else block userRedisKey:"+ userRedisKey);
				if(httpsession!=null){
					userRedisKey = httpsession.getId()+System.currentTimeMillis();			
					httpsession.setAttribute("userRedisKey", userRedisKey);
				}
			}
			
			httpRequest.setAttribute("IdVal", userRedisKey);
			
			//check the Auth Type - SAML Login 
			String loginHostName = httpRequest.getHeader(Constant.REQUEST_HEADER_KEY_HOST);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("FirstFilter : Login using Host Name :"+ loginHostName);
			
			boolean isSAMLLoginEnabled = isSAMLLoginEnabled(loginHostName);
			boolean isEYLoginEnabled = isEYLoginEnabled(isEyLogin);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("FirstFilter : isSAMLLoginEnabled :"+ isSAMLLoginEnabled +" : isEYLoginEnabled : "+isEYLoginEnabled);
			
			boolean isSetSelectedDomainToRedis = isSetSelectedDomainToRedis(isEYLoginEnabled, isSAMLLoginEnabled);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("FirstFilter : isSetSelectedDomainToRedis :"+ isSetSelectedDomainToRedis);	
			
			//Execute the logic and set the selected domain to REDIS when flag is TRUE
			if (isSetSelectedDomainToRedis) {
				Object obj = redisOp.getValueFromRedis("SelectedDomain", httpRequest);
				GroupAzureAdConfigDto grpADdto = (obj == null ? null : (GroupAzureAdConfigDto) obj);
				if (grpADdto == null) {
					String HostValue = httpRequest.getHeader(Constant.REQUEST_HEADER_KEY_HOST);
					List<GroupAzureAdConfigDto> grpAzureAdList = redisOp.getValueFromRedisGrpAzAdConfigList();
					for (GroupAzureAdConfigDto grpADDto : grpAzureAdList) {
						if (HostValue.equalsIgnoreCase(grpADDto.getDomainHost())) {
							redisOp.setValueToRedis("SelectedDomain", grpADDto, httpRequest);
						}
					}
				}
			}

			if ("true".equalsIgnoreCase(isHeaderLoggingIson)) {
				Enumeration headerNames = httpRequest.getHeaderNames();
				while (headerNames.hasMoreElements()) {
					String key = (String) headerNames.nextElement();
					String value = httpRequest.getHeader(key);
					LOGGER.fatal(" FirstFilter : key " + key);
					LOGGER.fatal(" FirstFilter : value " + value);
				}
			}
		}
		chain.doFilter(request, response);
		return;

	}
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}
	

	/**
	 * 
	 * @param isEYLoginEnabled
	 * @param isSAMLLoginEnabled
	 * @return TRUE if both are false
	 */
	private boolean isSetSelectedDomainToRedis(boolean isEYLoginEnabled, boolean isSAMLLoginEnabled) {
		
		if(!isEYLoginEnabled && !isSAMLLoginEnabled) return true;
		return false;
	}

	/**
	 * 
	 * @param hostName
	 * @return FALSE if SAML is not configured for host in Group Config table
	 */
	private boolean isSAMLLoginEnabled(String hostName) {
		
		if(StringUtils.isEmpty(hostName))  return false;
		String groupCode = redisOp.getValueFromRedisGrpDomainName(hostName);
		if(StringUtils.isEmpty(groupCode)) return false;
		
		return true;
	}

	
	/**
	 * 
	 * @param eyLogin
	 * @return TRUE if EYLogin flag is enabled in Adfilter.properties file
	 */
	private boolean isEYLoginEnabled(String eyLogin){
		
		if(Constant.TRUE.equalsIgnoreCase(eyLogin)) return true;
		return false;
	}

}
