package com.ey.advisory.asp.security.owasp;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Controllers implements Serializable {

	@SerializedName("controller")
	@Expose
	private List<Controller> controller;

	public List<Controller> getController() {
		return controller;
	}

	public void setController(List<Controller> controller) {
		this.controller = controller;
	}

	private final static long serialVersionUID = -815232384821037657L;

}