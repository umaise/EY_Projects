package com.ey.advisory.asp.util;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.EncodingException;

public class ESAPIEncodingUtil {

	static {
		ESAPI.initialize("org.owasp.esapi.reference.DefaultSecurityConfiguration");
	}
	
	public static String encodeHTML(String input) {
		input = ESAPI.encoder().canonicalize(input);
		return ESAPI.encoder().encodeForHTML(input);
	}

	public static String encodeForHTMLAttribute(String input) {
		input = ESAPI.encoder().canonicalize(input);
		return ESAPI.encoder().encodeForHTMLAttribute(input);
	}

	public static String encodeForJavaScript(String input) {
		input = ESAPI.encoder().canonicalize(input);
		return ESAPI.encoder().encodeForJavaScript(input);
	}

	public static String encodeForURL(String input) throws EncodingException {
		input = ESAPI.encoder().canonicalize(input);
		return ESAPI.encoder().encodeForURL(input);
	}
}