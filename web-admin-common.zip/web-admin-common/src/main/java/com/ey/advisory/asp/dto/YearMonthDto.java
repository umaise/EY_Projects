package com.ey.advisory.asp.dto;


public class YearMonthDto {
	
	private String gstinId;
	private String month;
	private String year;
	private String userEmailId;
	private boolean dbFlag;
	private String fromDate;
	private String toDate;
	private String rtPeriod;
	private String liabilityType;
	private String returnType;
	private String groupCode;
	
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	public String getGstinId() {
		return gstinId;
	}
	public void setGstinId(String gstinId) {
		this.gstinId = gstinId;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public boolean isDbFlag() {
		return dbFlag;
	}
	public void setDbFlag(boolean dbFlag) {
		this.dbFlag = dbFlag;
	}
	@Override
	public String toString() {
		return "YearMonthDto [gstinId=" + gstinId + ", month=" + month + ", year=" + year + ", userEmailId=" + userEmailId
				+ ", dbFlag=" + dbFlag + "]";
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getRtPeriod() {
		return rtPeriod;
	}
	public void setRtPeriod(String rtPeriod) {
		this.rtPeriod = rtPeriod;
	}
	public String getLiabilityType() {
		return liabilityType;
	}
	public void setLiabilityType(String liabilityType) {
		this.liabilityType = liabilityType;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	
	
	

}
