package com.ey.advisory.asp.domain;


import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Created by abhinavp on 13/11/16.
 */

public class UploadRawAndGetSignRequest {

	
    String signer;
    String content ;
    RawContentFormat format = RawContentFormat.TEXT;
    int expireInDays = 10;
    String callback;
    String comment;
    Boolean notifySigners = false;

    public String getSigner() {
        return signer;
    }

    public void setSigner(String signer) {
        this.signer = signer;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public RawContentFormat getFormat() {
        return format;
    }

    public void setFormat(RawContentFormat format) {
        this.format = format;
    }

   
    @JsonProperty("expire_in_days")
    public int getExpireInDays() {
        return expireInDays;
    }

    public void setExpireInDays(int expireInDays) {
        this.expireInDays = expireInDays;
    }

    public String getCallback() {
        return callback;
    }

    public void setCallback(String callback) {
        this.callback = callback;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    @JsonProperty("notify_signers")
    public Boolean getNotifySigners() {
        return notifySigners;
    }

    public void setNotifySigners(Boolean notifySigners) {
        this.notifySigners = notifySigners;
    }

    public enum RawContentFormat {
        JSON,
        TEXT;

        @Override
        @JsonValue
        public String toString() {
            return this.name().toLowerCase();
        }

        @JsonCreator
        public static RawContentFormat valueOfIgnoreCase(String value) {
            return RawContentFormat.valueOf(value.toUpperCase());
        }

    }

}
