package com.ey.advisory.asp.security.owasp;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Url {

@SerializedName("relativeurl")
@Expose
private String relativeurl;
@SerializedName("errorpage")
@Expose
private String errorpage;
@SerializedName("returntype")
@Expose
private String returntype;
@SerializedName("params")
@Expose
private Params params;

public String getRelativeurl() {
return relativeurl;
}

public void setRelativeurl(String relativeurl) {
this.relativeurl = relativeurl;
}

public String getErrorpage() {
return errorpage;
}

public void setErrorpage(String errorpage) {
this.errorpage = errorpage;
}

public String getReturntype() {
return returntype;
}

public void setReturntype(String returntype) {
this.returntype = returntype;
}

public Params getParams() {
return params;
}

public void setParams(Params params) {
this.params = params;
}

}