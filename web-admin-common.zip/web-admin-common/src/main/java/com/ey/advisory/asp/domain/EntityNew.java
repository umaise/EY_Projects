package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.google.gson.annotations.SerializedName;


public class EntityNew implements Serializable{

    private static final long serialVersionUID = 1L;
    
    @SerializedName("EntityID")
    private Integer entityId;
    
    @SerializedName("EntityName")
	private String entityName;
    
    @SerializedName("EntityCode")
	private String entityCode;
    
    @SerializedName("PAN")
	private String pan;
    
    @SerializedName("GrossTurnover")
	private BigDecimal grossTurnOver;
    
    @SerializedName("EntityType")
	private String entityType;
    
    @SerializedName("CompanyHQ")
	private String companyHQ;
    
    @SerializedName("GroupID")
	private Integer groupId;
    
    @SerializedName("IsActive")
	private Boolean isActive;
    
    @SerializedName("CreatedBy")
	private String createdBy;
    
    @SerializedName("CreatedDate")
	private Date createdDate;
    
    @SerializedName("UpdatedBy")
	private String updatedBy;
    
    @SerializedName("UpdatedDate")
	private Date updatedDate;
	
	public Integer getEntityId() {
		return entityId;
	}
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public String getEntityCode() {
		return entityCode;
	}
	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public BigDecimal getGrossTurnOver() {
		return grossTurnOver;
	}
	public void setGrossTurnOver(BigDecimal grossTurnOver) {
		this.grossTurnOver = grossTurnOver;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getCompanyHQ() {
		return companyHQ;
	}
	public void setCompanyHQ(String companyHQ) {
		this.companyHQ = companyHQ;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	
}
