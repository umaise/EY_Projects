package com.ey.advisory.asp.domain;

public class ClientUserDetails implements MasterTables {

    private Long serialNum;
    private String firstName;
    private String lastName;
    private String email;
    private Long mobileNum;
    private String role;
    private String dataAccess;
    private String dataAccessValue;
    
    public Long getSerialNum() {
        return serialNum;
    }
    public void setSerialNum(Long serialNum) {
        this.serialNum = serialNum;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public Long getMobileNum() {
        return mobileNum;
    }
    public void setMobileNum(Long mobileNum) {
        this.mobileNum = mobileNum;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public String getDataAccess() {
        return dataAccess;
    }
    public void setDataAccess(String dataAccess) {
        this.dataAccess = dataAccess;
    }
    public String getDataAccessValue() {
        return dataAccessValue;
    }
    public void setDataAccessValue(String dataAccessValue) {
        this.dataAccessValue = dataAccessValue;
    }
    
    @Override
    public String toString() {
        return "UserDetails [serialNum=" + serialNum + ", firstName=" + firstName + ", lastName=" + lastName
            + ", email=" + email + ", mobileNum=" + mobileNum + ", role=" + role + ", dataAccess=" + dataAccess
            + ", dataAccessValue=" + dataAccessValue + "]";
    }
}
