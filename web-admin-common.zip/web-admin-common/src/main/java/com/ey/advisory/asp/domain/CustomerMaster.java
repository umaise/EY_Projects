package com.ey.advisory.asp.domain;

import java.math.BigDecimal;
import java.util.Date;

import com.ey.advisory.asp.domain.MasterTables;

public class CustomerMaster implements MasterTables {
	
	private String sgstin;
	private String cgstin;
	private String custCode;
	private String custName;
	private String custAddress;
	private String custCategory;
	private String custLocationCode;
	private String categoryOfService;
	private String hsnsac;
	private String pos;
	private String info;
	private String primaryContactName;
	private String primaryeMailId;
	private Long primaryMobNum;
	private String secondaryContactName;
	private String secondaryeMailId;
	private Long secondaryMobNum;
	private String isExempt;
	private String notificationNum;
	private Date notificationDate;
	private String serialNum;
	private BigDecimal igstrt;
	private BigDecimal cgstrt;
	private BigDecimal sgstrt;
	private BigDecimal cessrt;
	private String isTds;


	public String getSgstin() {
		return sgstin;
	}
	public void setSgstin(String sgstin) {
		this.sgstin = sgstin;
	}
	public String getCgstin() {
		return cgstin;
	}
	public void setCgstin(String cgstin) {
		this.cgstin = cgstin;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public String getCustCategory() {
		return custCategory;
	}
	public void setCustCategory(String custCategory) {
		this.custCategory = custCategory;
	}
	public String getCustLocationCode() {
		return custLocationCode;
	}
	public void setCustLocationCode(String custLocationCode) {
		this.custLocationCode = custLocationCode;
	}
	public String getCategoryOfService() {
		return categoryOfService;
	}
	public void setCategoryOfService(String categoryOfService) {
		this.categoryOfService = categoryOfService;
	}
	public String getHsnsac() {
		return hsnsac;
	}
	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getPrimaryContactName() {
		return primaryContactName;
	}
	public void setPrimaryContactName(String primaryContactName) {
		this.primaryContactName = primaryContactName;
	}
	public String getPrimaryeMailId() {
		return primaryeMailId;
	}
	public void setPrimaryeMailId(String primaryeMailId) {
		this.primaryeMailId = primaryeMailId;
	}
	public Long getPrimaryMobNum() {
		return primaryMobNum;
	}
	public void setPrimaryMobNum(Long primaryMobNum) {
		this.primaryMobNum = primaryMobNum;
	}
	public String getSecondaryContactName() {
		return secondaryContactName;
	}
	public void setSecondaryContactName(String secondaryContactName) {
		this.secondaryContactName = secondaryContactName;
	}
	public String getSecondaryeMailId() {
		return secondaryeMailId;
	}
	public void setSecondaryeMailId(String secondaryeMailId) {
		this.secondaryeMailId = secondaryeMailId;
	}
	public Long getSecondaryMobNum() {
		return secondaryMobNum;
	}
	public void setSecondaryMobNum(Long secondaryMobNum) {
		this.secondaryMobNum = secondaryMobNum;
	}
	public String getIsExempt() {
		return isExempt;
	}
	public void setIsExempt(String isExempt) {
		this.isExempt = isExempt;
	}
	public String getNotificationNum() {
		return notificationNum;
	}
	public void setNotificationNum(String notificationNum) {
		this.notificationNum = notificationNum;
	}
	public Date getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	public String getSerialNum() {
		return serialNum;
	}
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}
	public BigDecimal getIgstrt() {
		return igstrt;
	}
	public void setIgstrt(BigDecimal igstrt) {
		this.igstrt = igstrt;
	}
	public BigDecimal getCgstrt() {
		return cgstrt;
	}
	public void setCgstrt(BigDecimal cgstrt) {
		this.cgstrt = cgstrt;
	}
	public BigDecimal getSgstrt() {
		return sgstrt;
	}
	public void setSgstrt(BigDecimal sgstrt) {
		this.sgstrt = sgstrt;
	}
	public BigDecimal getCessrt() {
		return cessrt;
	}
	public void setCessrt(BigDecimal cessrt) {
		this.cessrt = cessrt;
	}

	
	public String getIsTds() {
		return isTds;
	}
	public void setIsTds(String isTds) {
		this.isTds = isTds;
	}
	@Override
    public String toString() {
        return "CustomerMaster [sgstin="+sgstin+ ", cgstin=" + cgstin + ", custCode=" + custCode
                + ", custName=" + custName + ", custAddress=" + custAddress+ ", custCategory=" + custCategory+ ", serialNum=" + serialNum
                + ", custLocationCode=" + custLocationCode + ", categoryOfService=" + categoryOfService
                + ", hsnsac=" + hsnsac + ", pos=" + pos + ", info=" + info
                + ", primaryContactName=" + primaryContactName + ", primaryeMailId=" + primaryeMailId+ ", primaryMobNum=" + primaryMobNum
                + ", secondaryContactName=" + secondaryContactName + ", secondaryeMailId=" + secondaryeMailId+ ", secondaryMobNum=" + secondaryMobNum
                + ", isExempt=" + isExempt + ", notificationNum=" + notificationNum
                + ", notificationDate=" + notificationDate + ", igstrt=" + igstrt + ", cgstrt=" + cgstrt
                + ", sgstrt=" + sgstrt + ", isTds=" + isTds + ", cessrt=" + cessrt
                + "]";
    }
}
