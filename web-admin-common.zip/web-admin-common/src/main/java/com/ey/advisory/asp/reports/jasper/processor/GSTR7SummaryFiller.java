package com.ey.advisory.asp.reports.jasper.processor;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.reports.jasper.entity.GSTR7SummaryData;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class GSTR7SummaryFiller extends AbstractReportFiller{
	
	private static final Logger logger = Logger.getLogger(GSTR7SummaryFiller.class);

	@Override
	public byte[] getJasperReport(Object reportData, String reportPath) {

		byte[] pdfReport = null;
		JsonObject section;
		
		String jasperRSec;
		try {
			logger.debug("--------------generate GSTR7Summery PDF report----------");

			GSTR7SummaryData data = (GSTR7SummaryData) reportData;
			
			// Map to hold Jasper report Parameters
			Map<String, Object> parameters = new HashMap<>();
			parameters.put("reportName", data.getReportName()== null ? "" :data.getReportName() );
			parameters.put("gstin", data.getGstnId() == null ? "" :data.getGstnId());
			parameters.put("businessName", data.getBusinessName()== null ? "" :data.getBusinessName());
			parameters.put("fy", data.getfYear()== null ? "" : data.getfYear());
			parameters.put("returnPeriod", data.getReturnPeriod()== null ? "" :data.getReturnPeriod());
			parameters.put("dueDate", data.getDueDate()== null ? "" : data.getDueDate());

			
			if( null != data.getGstr7Sum()){
				JsonParser parser = new JsonParser();
				JsonObject reportJSON = parser.parse(data.getGstr7Sum()).getAsJsonObject();
				JsonArray ja = reportJSON.getAsJsonArray("gstr7");
				JsonObject mainObj = ja.get(0).getAsJsonObject();
				JsonArray sectionSummery = mainObj.getAsJsonArray("sec_sum");

			
			for (int index = 0; index < sectionSummery.size(); index++) {
				section = sectionSummery.get(index).getAsJsonObject();
				jasperRSec = section.get("section_name").getAsString().trim();

				if (jasperRSec != null) {
				
					parameters.put("checkSum_"+jasperRSec, (section.get("checksum"))== null?"-":section.get("checksum").getAsString());
					parameters.put("ttlTDSTaxValue_"+jasperRSec, (section.get("ttl_value").getAsString())== null?0.0:Double.parseDouble(section.get("ttl_value").getAsString()));
					parameters.put("ttlTDSValue_"+jasperRSec, (section.get("tax_pd").getAsString()) == null?0.0:Double.parseDouble(section.get("tax_pd").getAsString()));

				
				}

			}
			}

			JasperPrint jasperPrint = GSTR7SummaryFiller.getReport(parameters, reportPath);

			pdfReport = JasperExportManager.exportReportToPdf(jasperPrint);
			

		} catch (Exception e) {
			logger.error("Exception occured in GSTR7SummaryFiller.getGSTR7SummeryReport report :  ", e);
			
		}
		return pdfReport;

	}
	
	private static JasperPrint getReport(Map<String, Object> parameters, String masterReportPath) {
		JasperPrint jasperPrint = null;
		try {
			jasperPrint = JasperFillManager.fillReport(masterReportPath, parameters, new JREmptyDataSource());
		} catch (JRException e) {
			logger.error("Exception occured in GSTR7SummaryFiller.getReport report :  ", e);
			
		}
		return jasperPrint;
	}	

}
