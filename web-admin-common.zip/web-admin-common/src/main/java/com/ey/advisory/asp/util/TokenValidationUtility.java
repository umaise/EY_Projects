package com.ey.advisory.asp.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;


@Service
@PropertySource("classpath:ASPRestConfig.properties")
public class TokenValidationUtility {
	private static final Logger LOGGER = Logger.getLogger(TokenValidationUtility.class);
	
	@Autowired
	private Environment env;
	
	@Autowired
	private RedisOperationForSessionObj redisSessionUtility;

	public HashMap<String, String> validateGspGstnAuthTokens(String groupCode, String gstin) throws ParseException {
		
			String dateModifiedForGSP = redisSessionUtility.getDateModifiedFromRedisforGspAuthDetails(groupCode);
			String gspValidation = env.getProperty("isGSPValReq");
			HashMap<String, String> statusMap = new HashMap<String, String>();
			statusMap.put("GSP", "InActive");
			statusMap.put("GSTN", "InActive");
			
			if(null !=dateModifiedForGSP && !dateModifiedForGSP.isEmpty()){
				Date gspDateMod = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateModifiedForGSP);
				
				Calendar cal = Calendar.getInstance();
				cal.setTime(gspDateMod); 
				cal.add(Calendar.HOUR_OF_DAY, Integer.parseInt(env.getProperty("expiryTimeGSP")));
				Date gspDateModExpiry = cal.getTime();
				Date currentDate = new Date();
				if("true".equalsIgnoreCase(gspValidation) && (gspDateModExpiry.compareTo(currentDate) <= 0) ){
					statusMap.put("GSP", "InActive");
				}else{
					statusMap.put("GSP", "Active");
					String dateModifiedForGSTN = redisSessionUtility.getDateModifiedFromRedisfortheGstin(gstin);
					
					if(null !=dateModifiedForGSTN && !dateModifiedForGSTN.isEmpty()){
						Date gstnDateMod = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateModifiedForGSTN);
						
						Calendar calGstn = Calendar.getInstance();
						calGstn.setTime(gstnDateMod); 
						calGstn.add(Calendar.HOUR_OF_DAY, Integer.parseInt(env.getProperty("expiryTimeGSTIN")));
						Date gstnDateModExpiry = calGstn.getTime();
						Date currentDateGstn = new Date();
						if(gstnDateModExpiry.compareTo(currentDateGstn) <= 0 ){
							statusMap.put("GSTN", "InActive");
						}else{
							statusMap.put("GSTN", "Active");
						}
					}else{
						statusMap.put("GSTN", "InActive");
					}
				}
			}else{
				statusMap.put("GSP", "InActive");
			}
			LOGGER.debug("Inside Method : validateGspGstnAuthTokens: Tokens status: GSP: "+statusMap.get("GSP")+ " GSTN: "+statusMap.get("GSTN"));
		return statusMap;
		
	}
}
