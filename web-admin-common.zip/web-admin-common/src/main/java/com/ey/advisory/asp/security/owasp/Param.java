package com.ey.advisory.asp.security.owasp;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Param {

@SerializedName("paramname")
@Expose
private String paramname;
@SerializedName("esapitype")
@Expose
private String esapitype;
@SerializedName("encoding")
@Expose
private String encoding;
@SerializedName("validate")
@Expose
private String validate;
@SerializedName("escapetype")
@Expose
private String encodetype;

@SerializedName("errormessage")
@Expose
private String errormessage;
@SerializedName("maxlength")
@Expose
private int maxlength;

public String getParamname() {
return paramname;
}

public void setParamname(String paramname) {
this.paramname = paramname;
}

public String getEsapitype() {
return esapitype;
}

public void setEsapitype(String esapitype) {
this.esapitype = esapitype;
}

public String getEncoding() {
return encoding;
}

public void setEncoding(String encoding) {
this.encoding = encoding;
}

public String getValidate() {
return validate;
}

public void setValidate(String validate) {
this.validate = validate;
}

public String getEscapetype() {
return encodetype;
}

public void setEscapetype(String escapetype) {
this.encodetype = escapetype;
}



public String getErrormessage() {
return errormessage;
}

public void setErrormessage(String errormessage) {
this.errormessage = errormessage;
}

public int getMaxlength() {
return maxlength;
}

public void setMaxlength(int maxlength) {
this.maxlength = maxlength;
}

}