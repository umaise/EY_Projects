package com.ey.advisory.asp.dashboard.conf;

import javax.annotation.PreDestroy;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;

import com.ey.advisory.asp.dashboard.sub.RedisProcessedSubscriber;

import redis.clients.jedis.JedisPoolConfig;

//@Configuration
//@EnableWebSocketMessageBroker
@PropertySource("classpath:redis.properties")
public class WebSocketConfig { // extends AbstractWebSocketMessageBrokerConfigurer {

	@Value("${redis.hostName}")
	private String redisHost;
	@Value("${redis.port}")
	private Integer redisPort;
	@Value("${redis.channel}")
	private String channel;
	@Value("${redis.pool.testOnBorrow}")
	private boolean testOnBorrow;
	@Value("${redis.pool.testOnReturn}")
	private boolean testOnReturn;
	@Value("${redis.pool.maxcon}")
	private int maxcon;
	/*@Value("${redis.password}")
	private String password;*/

/*	@Autowired
	private RedisProcessedSubscriber subscriber;

	@Autowired
	RedisMessageListenerContainer  container;
	
	private static final Logger LOGGER = Logger.getLogger(WebSocketConfig.class);
	
	@Override
	public void configureMessageBroker(MessageBrokerRegistry config) {
		config.enableSimpleBroker("/topic");
		config.setApplicationDestinationPrefixes("/app");
		LOGGER.info("config.enableSimpleBroker(/topic)");
		LOGGER.info("config.setApplicationDestinationPrefixes(/app);");
	}

	@Override
	public void registerStompEndpoints(StompEndpointRegistry registry) {
		registry.addEndpoint("/dashboard").withSockJS();
		LOGGER.info("registry.addEndpoint(/dashboard).withSockJS();");
	}

	@Bean
	public RedisConnectionFactory jedisConnectionFactory() {
		JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxTotal(maxcon);
		poolConfig.setTestOnBorrow(testOnBorrow);
		poolConfig.setTestOnReturn(testOnReturn);
		JedisConnectionFactory factory = new JedisConnectionFactory(poolConfig);
		factory.setUsePool(true);
		factory.setHostName(redisHost);
		factory.setPort(redisPort);
		
		if(null != password && !"".equalsIgnoreCase(password))
			factory.setPassword(password);
		return factory;
	}

	@Bean
	MessageListenerAdapter messageListener(String type) {
		return new MessageListenerAdapter(subscriber);
	}

	@Bean
	ChannelTopic topic(String channelName) {
		return new ChannelTopic(channelName);
	}

	@Bean
	RedisMessageListenerContainer redisContainer() {
		final RedisMessageListenerContainer container = new RedisMessageListenerContainer();
		container.setConnectionFactory(jedisConnectionFactory());
		container.addMessageListener(messageListener(channel), topic(channel));
		return container;
	}
	
	@PreDestroy
	public void cleanUp(){
		if(container != null){
			//System.out.println("####### Stopping  RedisMessageListenerContainer #########");
			LOGGER.info("####### Stopping  RedisMessageListenerContainer #########");
			container.stop();
		}
	}*/
}