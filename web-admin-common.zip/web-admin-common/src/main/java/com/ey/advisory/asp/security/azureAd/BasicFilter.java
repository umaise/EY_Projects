/*******************************************************************************
 * Copyright © Microsoft Open Technologies, Inc.
 * 
 * All Rights Reserved
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * THIS CODE IS PROVIDED *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS
 * OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION
 * ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A
 * PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 * 
 * See the Apache License, Version 2.0 for the specific language
 * governing permissions and limitations under the License.
 ******************************************************************************/
package com.ey.advisory.asp.security.azureAd;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.naming.ServiceUnavailableException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.GroupAzureAdConfigDto;
import com.ey.advisory.asp.service.SecurityLogsService;
import com.ey.advisory.asp.util.CommonUtility;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;
import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.nimbusds.oauth2.sdk.AuthorizationCode;
import com.nimbusds.openid.connect.sdk.AuthenticationErrorResponse;
import com.nimbusds.openid.connect.sdk.AuthenticationResponse;
import com.nimbusds.openid.connect.sdk.AuthenticationResponseParser;
import com.nimbusds.openid.connect.sdk.AuthenticationSuccessResponse;

@Component("myBasicFilter")
@PropertySource("classpath:AdFileter.properties")
public class BasicFilter implements Filter {

	private static final Logger LOGGER = Logger.getLogger(BasicFilter.class);

	@Value("${clientId}")
	private String clientId = "";

	@Value("${clientSecret}")
	private String clientSecret = "";

	@Value("${tenant}")
	private String tenant = "";

	@Value("${authority}")
	private String authority;

	@Value("${redirectHost}")
	private String redirectHost;

	@Value("${isAzure}")
	private String isAzure;

	private static Set<String> excluded;

	@Value("${graphAPI}")
	private String graphAPI;

	@Value("${graphAPIVersion}")
	private String graphAPIVersion;

	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	@Value("${isEyLogin}")
	private String isEyLogin;
	
	@Value("${protocol}")
	private String protocol;
	
	@Autowired
	WebApplicationContext springContext;

	/**
	 * @return the graphAPI
	 */
	public String getGraphAPI() {
		return graphAPI;
	}

	/**
	 * @param graphAPI
	 *            the graphAPI to set
	 */
	public void setGraphAPI(String graphAPI) {
		this.graphAPI = graphAPI;
	}

	/**
	 * @return the graphAPIVersion
	 */
	public String getGraphAPIVersion() {
		return graphAPIVersion;
	}

	/**
	 * @param graphAPIVersion
	 *            the graphAPIVersion to set
	 */
	public void setGraphAPIVersion(String graphAPIVersion) {
		this.graphAPIVersion = graphAPIVersion;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId(HttpServletRequest request) {
		
		if ("false".equalsIgnoreCase(isEyLogin)) {
			
			Object obj = redisOp.getValueFromRedis("SelectedDomain", request);
			GroupAzureAdConfigDto grpADdto = (obj == null ? new GroupAzureAdConfigDto() : (GroupAzureAdConfigDto) obj);
			return grpADdto.getClientId();
			
		}else{
			
			return clientId;
		}
		
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the clientSecret
	 */
	public String getClientSecret(HttpServletRequest request) {
       if ("false".equalsIgnoreCase(isEyLogin)) {
			
			Object obj = redisOp.getValueFromRedis("SelectedDomain", request);
			GroupAzureAdConfigDto grpADdto = (obj == null ? new GroupAzureAdConfigDto() : (GroupAzureAdConfigDto) obj);
			return grpADdto.getClientSecret();
			
		}else{			
			return clientSecret;
		}
	}

	/**
	 * @param clientSecret
	 *            the clientSecret to set
	 */
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	/**
	 * @return the tenant
	 */
	public String getTenant(HttpServletRequest request) {
      if ("false".equalsIgnoreCase(isEyLogin)) {
			
			Object obj = redisOp.getValueFromRedis("SelectedDomain", request);
			GroupAzureAdConfigDto grpADdto = (obj == null ? new GroupAzureAdConfigDto() : (GroupAzureAdConfigDto) obj);
			return grpADdto.getaDTennet();
			
		}else{
			
			return tenant;
		}
	}

	/**
	 * @param tenant
	 *            the tenant to set
	 */
	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	/**
	 * @return the authority
	 */
	public String getAuthority() {
		return authority;
	}

	/**
	 * @param authority
	 *            the authority to set
	 */
	public void setAuthority(String authority) {
		this.authority = authority;
	}

	/**
	 * @return the redirectHost
	 */
	public String getRedirectHost(HttpServletRequest request) {
		
		//check the Auth Type - SAML Login 
		String domainHost = request.getHeader(Constant.REQUEST_HEADER_KEY_HOST);
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("BasicFilter : Login using Host Name :"+ domainHost);
		
		boolean isSAMLLoginEnabled = isSAMLLoginEnabled(domainHost);
		boolean isEYLoginEnabled = isEYLoginEnabled(isEyLogin);
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("BasicFilter : isSAMLLoginEnabled :"+ isSAMLLoginEnabled +" : isEYLoginEnabled : "+isEYLoginEnabled);
		
		boolean isSelectedDomainFromRedis = isSelectedDomainFromRedis(isEYLoginEnabled, isSAMLLoginEnabled);
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("BasicFilter : isSelectedDomainFromRedis :"+ isSelectedDomainFromRedis);
		
       if (isSelectedDomainFromRedis) {
			
			Object obj = redisOp.getValueFromRedis("SelectedDomain", request);
			GroupAzureAdConfigDto grpADdto = (obj == null ? new GroupAzureAdConfigDto() : (GroupAzureAdConfigDto) obj);
			return protocol+"://"+grpADdto.getDomainHost();
			
		}else if(isSAMLLoginEnabled){
			
		    return protocol+"://"+domainHost;
		    
		}else{
			
		    return redirectHost;
		}
	}
	
	

	/**
	 * @param redirectHost
	 *            the redirectHost to set
	 */
	public void setRedirectHost(String redirectHost) {
		this.redirectHost = redirectHost;
	}

	/**
	 * @return the excluded
	 */
	public static Set<String> getExcluded() {
		return excluded;
	}

	/**
	 * @param excluded
	 *            the excluded to set
	 */
	public static void setExcluded(Set<String> excluded) {
		BasicFilter.excluded = excluded;
	}

	/**
	 * @return the logger
	 */
	public static Logger getLogger() {
		return LOGGER;
	}

	@Override
	public void destroy() {
		LOGGER.info("destroy");
	}
	
	@Autowired
	private SecurityLogsService securityLogsService;
	
	

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
			if (request instanceof HttpServletRequest) {
				HttpServletRequest httpRequest = (HttpServletRequest) request;
				HttpServletResponse httpResponse = (HttpServletResponse) response;
				
				String requestURL = httpRequest.getRequestURL().toString();
				
				// Excluded the pages which is pre-configured in web.xml
				if (CommonUtility.isExcluded(httpRequest)) {
					LOGGER.info("BasicFilter : Excluded - getRequestURI :" + httpRequest.getRequestURL());
					chain.doFilter(request, response);
					return;
				}
				
				// Logout SAML/AZURE - start 
				if (requestURL.contains("/adlogout")) {
					LOGGER.info("BasicFilter.doFilter requestURL.contains(logout) passed");
					String confirmLogout = httpRequest.getParameter("confirmLogout");
					
					LOGGER.info("BasicFilter.doFilter Logout : confirmLogout: "+confirmLogout);
					if (confirmLogout != null && confirmLogout.equalsIgnoreCase(Constant.TRUE)) {
						
						LOGGER.info("BasicFilter.doFilter Logout executed");
						String url = "";
						
						url = getRedirectUrlLogout(redirectHost + httpRequest.getContextPath() + Constant.LOGIN_URL, httpRequest);
						LOGGER.info("BasicFilter.doFilter Logout " + url);
						
						try {
							deleteSessionPrincipal(httpRequest, httpResponse, null);
						} catch (Exception e) {
							LOGGER.info("BasicFilter.doFilter Logout exception ",e);

						}
						httpResponse.sendRedirect(url);
						
						return;
					}
					
				}
				
				// Logout SAML/AZURE - stop
				
				//Check SAML OR AZURE login is authenticated
				Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
				
				if (!isAzure.equalsIgnoreCase(Constant.TRUE)) {
						chain.doFilter(request, response);
						return;
				} else if (authentication != null && authentication.isAuthenticated()) {
					boolean anonymous = authentication.getAuthorities().contains( new SimpleGrantedAuthority(Constant.SAML_ROLE_ANONYMOUS));

					LOGGER.info("BasicFilter- SAML -  anonymous: "+anonymous +" : Prinic- "+authentication.getPrincipal());
					if (!anonymous) {
		    			
						chain.doFilter(httpRequest, httpResponse);
		    			return;
					}
				} 
				
				
				LOGGER.info("BasicFilter.doFilter executed : RequestURL : "+ httpRequest.getRequestURL());

				String currentUri = getRedirectHost(httpRequest) + httpRequest.getRequestURI();
				String fullUrl = currentUri + (httpRequest.getQueryString() != null ? "?" + httpRequest.getQueryString() : "");
				
				LOGGER.info("BasicFilter : RequestURL : "+ currentUri +" : fullUrl : "+fullUrl);
				

				try {

					// check if user has a session
					if (!isAuthenticated(httpRequest)) {
						LOGGER.info("BasicFilter.doFilter !AuthHelper.isAuthenticated(httpRequest) passed");
						if (AuthHelper.containsAuthenticationData(httpRequest)) {
							LOGGER.info(
									"BasicFilter.doFilter AuthHelper.containsAuthenticationData(httpRequest) passed");
							Map<String, String> params = new HashMap<>();
							for (Object key : request.getParameterMap().keySet()) {
								String[] strArr = (String[]) request.getParameterMap().get(key);
								params.put((String) key, strArr[0]);
							}
							AuthenticationResponse authResponse = AuthenticationResponseParser.parse(new URI(fullUrl),
									params);
							LOGGER.info("fullUrl :" + fullUrl);
							if (AuthHelper.isAuthenticationSuccessful(authResponse)) {
								
								//Start - Code added for Session Fixation issue
								HttpSession session = httpRequest.getSession(false);
								Object userRedisKey = session==null?null : session.getAttribute("userRedisKey");
							
								if(session!=null ){
									LOGGER.info("Before Invalidate - HttpSession ID: ours "+session.getId());
									session.invalidate();

									session = httpRequest.getSession(true);
									
									LOGGER.info("After Invalidate - HttpSession ID: "+session.getId() +" Session RedisKey : "+userRedisKey);
									
									if(userRedisKey!=null && !userRedisKey.toString().isEmpty())
										session.setAttribute("userRedisKey", userRedisKey);
																	
									
									
								}
								//End - Code added for Session Fixation issue
								
								AuthenticationSuccessResponse oidcResponse = (AuthenticationSuccessResponse) authResponse;
								AuthenticationResult result = getAccessToken(oidcResponse.getAuthorizationCode(),
										currentUri,httpRequest);

								createSessionPrincipal(httpRequest, result);
							} else {
								AuthenticationErrorResponse oidcResponse = (AuthenticationErrorResponse) authResponse;
								LOGGER.info("BasicFilter.doFilter error :"
										+ oidcResponse.getErrorObject().getDescription());
								throw new Exception(String.format("Request for auth code failed: %s - %s",
										oidcResponse.getErrorObject().getCode(),
										oidcResponse.getErrorObject().getDescription()));

							}
						} else {
							// not authenticated
							LOGGER.info("BasicFilter.doFilter error :not authenticated");
							httpResponse.setStatus(302);
							String url1 = currentUri;
							Object obj = redisOp.getValueFromRedis("Client",  httpRequest);
							String tempUrl = (String) ((obj == null)?"":obj);
							if( tempUrl.length()>0){
							url1 = currentUri.replace("/asp/", "/asp/"+tempUrl+"/");
							}
							httpResponse.sendRedirect(getRedirectUrl(url1,httpRequest));
							return;
						}
					} else {
						// if authenticated, how to check for valid session?
						AuthenticationResult result = getAuthSessionObject(httpRequest);

						if (httpRequest.getParameter("refresh") != null) {
							result = getAccessTokenFromRefreshToken(result.getRefreshToken(),httpRequest);
						} else {
							if (httpRequest.getParameter("cc") != null) {
								result = getAccessTokenFromClientCredentials(httpRequest);
							} else {
								if (result.getExpiresOnDate().before(new Date())) {
									result = getAccessTokenFromRefreshToken(result.getRefreshToken(),httpRequest);
								}
							}
						}
						createSessionPrincipal(httpRequest, result);
					}
				} catch (Throwable exc) {
					LOGGER.error(exc.fillInStackTrace());
					LOGGER.info("BasicFilter.doFilter error :not authenticated Error :-" + exc);
					
					httpResponse.setStatus(302);
					httpResponse.sendRedirect(getRedirectUrl(currentUri,httpRequest));
					
					return;
				}
			}
		
		chain.doFilter(request, response);
		return;
	}
	
	private AuthenticationResult getAccessTokenFromClientCredentials(HttpServletRequest request) throws Throwable {

		LOGGER.info("getAccessTokenFromClientCredentials");
		AuthenticationContext context = null;
		AuthenticationResult result = null;
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(1);
			context = new AuthenticationContext(authority + getTenant(request) + "/", true, service);
			Future<AuthenticationResult> future = context.acquireToken("https://graph.windows.net",
					new ClientCredential(getClientId(request), getClientSecret(request)), null);
			result = future.get();
		} catch (ExecutionException e) {

			LOGGER.error(e);
			throw e.getCause();
		} finally {
			if(service!=null){
			service.shutdown();
			}
		}

		if (result == null) {
			throw new ServiceUnavailableException("authentication result was null");
		}
		return result;
	}

	private AuthenticationResult getAccessTokenFromRefreshToken(String refreshToken, HttpServletRequest request)
			throws Throwable {
		LOGGER.info("getAccessTokenFromRefreshToken   AuthorizationCode authorizationCode, String currentUri");
		AuthenticationContext context = null;
		AuthenticationResult result = null;
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(1);
			context = new AuthenticationContext(authority + getTenant(request) + "/", true, service);
			Future<AuthenticationResult> future = context.acquireTokenByRefreshToken(refreshToken,
					new ClientCredential(getClientId(request), getClientSecret(request)), null, null);
			result = future.get();
		} catch (ExecutionException e) {
			LOGGER.error(e);
			throw e.getCause();
		} finally {
			if(service!=null){
			service.shutdown();
			}
		}

		if (result == null) {
			throw new ServiceUnavailableException("authentication result was null");
		}
		return result;

	}

	private AuthenticationResult getAccessToken(AuthorizationCode authorizationCode, String currentUri, HttpServletRequest request)
			throws Throwable {
		LOGGER.info("getAccessToken   AuthorizationCode authorizationCode, String currentUri");
		String authCode = authorizationCode.getValue();
		ClientCredential credential = new ClientCredential(getClientId(request), getClientSecret(request));
		AuthenticationContext context = null;
		AuthenticationResult result = null;
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(1);
			context = new AuthenticationContext(authority + getTenant(request) + "/", true, service);
			Future<AuthenticationResult> future = context.acquireTokenByAuthorizationCode(authCode, new URI(currentUri),
					credential, null);
			result = future.get();
			//String message = result.
			securityLogsService.loginDetails(request,"");
		} catch (ExecutionException e) {
			LOGGER.error(e);
			throw e.getCause();
		} finally {
			if(service!=null){
			service.shutdown();
			}
		}

		if (result == null) {
			throw new ServiceUnavailableException("authentication result was null");
		}
		return result;
	}

	private void createSessionPrincipal(HttpServletRequest httpRequest, AuthenticationResult result) {
		LOGGER.info("createSessionPrincipal :" + result.toString());

		redisOp.setValueToRedis(AuthHelper.PRINCIPAL_SESSION_NAME, result, httpRequest);

		redisOp.setValueToRedis("AccessToken", result.getAccessToken(), httpRequest);

	}

	private void deleteSessionPrincipal(HttpServletRequest httpRequest, HttpServletResponse response, AuthenticationResult result) {
		//LOGGER.info("deleteSessionPrincipal :" + result.toString());
		
		HttpSession session = httpRequest.getSession(false);
		session.setAttribute(AuthHelper.PRINCIPAL_SESSION_NAME, null);
		session.setAttribute(Constant.CURRENTUSER, null);
		session.setAttribute("User", null);
		session.setAttribute("AdUserInfo", null);
		securityLogsService.logMessage(httpRequest,"Logout Performed");
		redisOp.deleteSession(httpRequest);
		
		if (session != null) {
			session.invalidate();
		}

		Cookie[] cookiesToClear = httpRequest.getCookies();
		for (Cookie cookie : cookiesToClear) {

			cookie.setPath(null);
			cookie.setMaxAge(0);
			cookie.setValue(null);
			response.addCookie(cookie);

		}


	}

	private String getRedirectUrl(String currentUri, HttpServletRequest request) throws UnsupportedEncodingException {
		String redirectUrl = authority + this.getTenant(request)
				+ "/oauth2/authorize?response_type=code%20id_token&scope=openid&response_mode=form_post&redirect_uri="
				+ URLEncoder.encode(currentUri, "UTF-8") + "&client_id=" + getClientId(request) + "&resource="
				+ getFormattedGraphAPI() + "&nonce=" + UUID.randomUUID() + "&site_id=500879";
		LOGGER.info("redirectUrl :" + redirectUrl);
		return redirectUrl;
	}

	private String getRedirectUrlLogout(String currentUri, HttpServletRequest request) throws UnsupportedEncodingException {
		String redirectUrl = authority + this.getTenant(request) + "/oauth2/logout?post_logout_redirect_uri="
				+ URLEncoder.encode(currentUri, "UTF-8");
		LOGGER.info("redirectUrl :" + redirectUrl);
		return redirectUrl;
	}
	
	@Override
	public void init(FilterConfig config) throws ServletException {
		
		 String excludedString = config.getInitParameter("excludedExt");
		 
	        if (excludedString != null) {
	            excluded = Collections.unmodifiableSet(
	                new HashSet<>(Arrays.asList(excludedString.split(" ", 0))));
	        } else {
	            excluded = Collections.<String>emptySet();
	        }

	}

	private String getFormattedGraphAPI() {
		String[] str = graphAPI.split("/");
		StringBuffer strBuf = new StringBuffer();
		int itr = 0;
		for (String strTmp : str) {
			if (itr > 0) {
				strBuf.append("%2f" + strTmp);
			} else {
				strBuf.append(strTmp);
			}
			itr++;
		}

		String graphAPITmp = strBuf.toString();

		graphAPITmp = graphAPITmp.replace(":", "%3a");

		return graphAPITmp;
	}

	public boolean isAuthenticated(HttpServletRequest request) {

		LOGGER.info(" in isAuthenticated(HttpServletRequest request)");

		Object obj= redisOp.getValueFromRedis(AuthHelper.PRINCIPAL_SESSION_NAME,request);	
		AuthenticationResult auth = (obj != null )? (AuthenticationResult) obj:null;		
				
		LOGGER.info(" in isAuthenticated(HttpServletRequest request) :auth = " + auth);

		return auth != null;
	}

	public AuthenticationResult getAuthSessionObject(HttpServletRequest request) {

		LOGGER.info(" in getAuthSessionObject(HttpServletRequest request)");

		Object obj = redisOp.getValueFromRedis(AuthHelper.PRINCIPAL_SESSION_NAME,request);
		AuthenticationResult auth =  (obj != null )? (AuthenticationResult) obj:null;
	
		LOGGER.info(" in getAuthSessionObject(HttpServletRequest request) :auth = " + auth);

		return auth;

	}
	
	/**
	 * 
	 * @param isEYLoginEnabled
	 * @param isSAMLLoginEnabled
	 * @return TRUE if both are false
	 */
	private boolean isSelectedDomainFromRedis(boolean isEYLoginEnabled, boolean isSAMLLoginEnabled) {
		
		if(!isEYLoginEnabled && !isSAMLLoginEnabled) return true;
		return false;
	}

	/**
	 * 
	 * @param hostName
	 * @return FALSE if SAML is not configured for host in Group Config table
	 */
	private boolean isSAMLLoginEnabled(String hostName) {
		
		if(StringUtils.isEmpty(hostName))  return false;
		String groupCode = redisOp.getValueFromRedisGrpDomainName(hostName);
		if(StringUtils.isEmpty(groupCode)) return false;
		
		return true;
	}

	
	/**
	 * 
	 * @param eyLogin
	 * @return TRUE if EYLogin flag is enabled in Adfilter.properties file
	 */
	private boolean isEYLoginEnabled(String eyLogin){
		
		if(Constant.TRUE.equalsIgnoreCase(eyLogin)) return true;
		return false;
	}


	/**
	 * @return True if SAML is authenticated
	 */
	private boolean isSAMLAuthenticated() {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		
		if (authentication != null && authentication.isAuthenticated()) {
			boolean anonymous = authentication.getAuthorities().contains( new SimpleGrantedAuthority(Constant.SAML_ROLE_ANONYMOUS));
			
			if (!anonymous ) return true;
		}
		
		return false;
	}
	
}
