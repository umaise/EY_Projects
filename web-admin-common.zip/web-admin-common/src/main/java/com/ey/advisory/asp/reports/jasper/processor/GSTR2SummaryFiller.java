package com.ey.advisory.asp.reports.jasper.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.reports.jasper.entity.GSTR2SummaryData;
import com.ey.advisory.asp.reports.jasper.entity.GSTR2Summary_row;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class GSTR2SummaryFiller extends AbstractReportFiller {

	private static final Logger logger = Logger
			.getLogger(GSTR2SummaryFiller.class);

	@Override
	public byte[] getJasperReport(Object reportData, String reportPath) {

		byte[] pdfReport = null;
		Map<String, Object> parameters = new HashMap<>();
		try {
			logger.debug("--------------generate GSTR2Summery PDF report----------");

			GSTR2SummaryData data = (GSTR2SummaryData) reportData;

			// Map to hold Jasper report Parameters
			parameters.put("reportName", data.getReportName());
			parameters.put("gstin", data.getGstnId());
			parameters.put("businessName", data.getBusinessName());
			parameters.put("returnPeriod", data.getReturnPeriod());
			parameters.put("totalTaxable", data.getTotalTaxableValue());
			parameters.put("totalIGST", data.getTotalIgst());
			parameters.put("totalCGST", data.getTotalCgst());
			parameters.put("totalSGST", data.getTotalSgst());
			parameters.put("totalCess", data.getTotalCess());
			parameters.put("totalItcIgst", data.getTotalItcIgstAvailed());
			parameters.put("totalItcCgst", data.getTotalItcCgstAvailed());
			parameters.put("totalItcSgst", data.getTotalItcSgstAvailed());
			parameters.put("totalItcCess", data.getTotalItcCessAvailed());
			parameters.put("totalItcAvailed", data.getTotalItcAvailed());
			parameters.put("totalTaxPay", data.getTotalTaxPay());

			JsonParser parser = new JsonParser();
			JsonObject jo = parser.parse(data.getGstr2Sum()).getAsJsonObject();
			if (jo.get("section_summary") != null) {
				JsonArray ja = jo.get("section_summary").getAsJsonArray();

				JsonObject section;
				JRBeanCollectionDataSource itemsJRBean;
				String jasperRSec; 
				GSTR2Summary_row oneRow;
				for (int index = 0; index < ja.size(); index++) {
					section = ja.get(index).getAsJsonObject();
					jasperRSec = section.get("sec_nm").getAsString();

					if (jasperRSec != null) {
						oneRow = new GSTR2Summary_row();
						List<GSTR2Summary_row> listItems;
						Double taxPayable=0.00;
						if(section.get("rc")!=null)
							parameters.put(section.get("sec_nm").getAsString().toUpperCase()+"rec", section.get("rc").getAsString());
						if (!section.get("sec_nm").getAsString().equalsIgnoreCase("NIL")){
							
							if(section.get("ttl_val") != null)
								oneRow.setTaxableValue(Double.parseDouble(section.get("ttl_val").getAsString()));
							if(section.get("ttl_txpd_igst") != null){
								oneRow.setIgst(Double.parseDouble(section.get("ttl_txpd_igst").getAsString()));
								taxPayable = taxPayable+Double.parseDouble(section.get("ttl_txpd_igst").getAsString());
							}
							if(section.get("ttl_txpd_cgst") != null){
								oneRow.setCgst(Double.parseDouble(section.get("ttl_txpd_cgst").getAsString()));
								taxPayable = taxPayable+Double.parseDouble(section.get("ttl_txpd_cgst").getAsString());
							}
							if(section.get("ttl_txpd_sgst") != null){
								oneRow.setSgst(Double.parseDouble(section.get("ttl_txpd_sgst").getAsString()));
								taxPayable = taxPayable+Double.parseDouble(section.get("ttl_txpd_sgst").getAsString());
							}
							if(section.get("ttl_txpd_cess") != null){
								oneRow.setCess(Double.parseDouble(section.get("ttl_txpd_cess").getAsString()));
								taxPayable = taxPayable+Double.parseDouble(section.get("ttl_txpd_cess").getAsString());
							}
							if(section.get("ttl_itcavld_igst") != null)
								oneRow.setItcigst(Double.parseDouble(section.get("ttl_itcavld_igst").getAsString()));
							if(section.get("ttl_itcavld_cgst") != null)
								oneRow.setItccgst(Double.parseDouble(section.get("ttl_itcavld_cgst").getAsString()));
							if(section.get("ttl_itcavld_sgst") != null)
								oneRow.setItcsgst(Double.parseDouble(section.get("ttl_itcavld_sgst").getAsString()));
							if(section.get("ttl_itcavld_cess") != null)
								oneRow.setItccess(Double.parseDouble(section.get("ttl_itcavld_cess").getAsString()));
							
							oneRow.setTaxPayable(taxPayable);
						}
						else{
							if(section.get("ttl_nilsply") != null)
								oneRow.setNilRated(Double.parseDouble(section.get("ttl_nilsply").getAsString()));
							if(section.get("ttl_cppdr") != null)
								oneRow.setNilComp(Double.parseDouble(section.get("ttl_cppdr").getAsString()));
							if(section.get("ttl_expdsply") != null)
								oneRow.setNilExempt(Double.parseDouble(section.get("ttl_expdsply").getAsString()));
							if(section.get("ttl_ngsply") != null)
								oneRow.setNilNonGst(Double.parseDouble(section.get("ttl_ngsply").getAsString()));
						}
						
						listItems = new ArrayList<>();
						listItems.add(oneRow);
						itemsJRBean = new JRBeanCollectionDataSource(listItems);
						parameters.put(jasperRSec, itemsJRBean);
					}
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception occured in GSTR1SummaryFiller.getGSTR2SummeryReport parameters :  ",
					e);
		}
		JasperPrint jasperPrint = GSTR2SummaryFiller.getReport(parameters,
				reportPath);

		try {
			pdfReport = JasperExportManager.exportReportToPdf(jasperPrint);
		} catch (JRException e) {
			logger.error(
					"Exception occured in GSTR1SummaryFiller.getGSTR2SummeryReport report :  ",
					e);
		}

		return pdfReport;
	}

	private static JasperPrint getReport(Map<String, Object> parameters,
			String masterReportPath) {
		JasperPrint jasperPrint = null;
		try {
			jasperPrint = JasperFillManager.fillReport(masterReportPath,
					parameters, new JREmptyDataSource());
		} catch (JRException e) {
			logger.error(
					"Exception occured in GSTR2SummaryFiller.getReport report :  ",
					e);
		}
		return jasperPrint;
	}

}
