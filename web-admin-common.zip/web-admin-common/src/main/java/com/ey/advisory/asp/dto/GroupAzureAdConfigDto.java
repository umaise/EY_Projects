package com.ey.advisory.asp.dto;

import java.io.Serializable;

public class GroupAzureAdConfigDto  implements Serializable {
	
private static final long serialVersionUID = 1L;
	
	private Long groupADConfID;
	
	
	private String domainHost;
	
	
	private String aDTennet;
	
	
	private String clientId;
	
	
	private String clientSecret;
	
	private String protocol;
	
	private String userDomains;
	
	
	private Long groupID;
	/**
	 * @return the groupADConfID
	 */
	public Long getGroupADConfID() {
		return groupADConfID;
	}
	/**
	 * @param groupADConfID the groupADConfID to set
	 */
	public void setGroupADConfID(Long groupADConfID) {
		this.groupADConfID = groupADConfID;
	}
	/**
	 * @return the domainHost
	 */
	public String getDomainHost() {
		return domainHost;
	}
	/**
	 * @param domainHost the domainHost to set
	 */
	public void setDomainHost(String domainHost) {
		this.domainHost = domainHost;
	}
	/**
	 * @return the aDTennet
	 */
	public String getaDTennet() {
		return aDTennet;
	}
	/**
	 * @param aDTennet the aDTennet to set
	 */
	public void setaDTennet(String aDTennet) {
		this.aDTennet = aDTennet;
	}
	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	/**
	 * @return the clientSecret
	 */
	public String getClientSecret() {
		return clientSecret;
	}
	/**
	 * @param clientSecret the clientSecret to set
	 */
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}
	/**
	 * @return the groupID
	 */
	public Long getGroupID() {
		return groupID;
	}
	/**
	 * @param groupID the groupID to set
	 */
	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	public String getUserDomains() {
		return userDomains;
	}
	public void setUserDomains(String userDomains) {
		this.userDomains = userDomains;
	}
	
	
	

}
