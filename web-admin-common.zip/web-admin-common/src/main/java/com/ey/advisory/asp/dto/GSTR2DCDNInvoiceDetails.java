package com.ey.advisory.asp.dto;


import java.io.Serializable;
import java.sql.Date;

public class GSTR2DCDNInvoiceDetails implements Serializable{ 

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

private long id;

private String custGSTIN;

private String invTyp;

private String custName;

private Character flag;

private String chksum;

private String noteTyp;

private int noteNum;

private Date noteDate;

private String reason;

private String invNum;

private Date invDate;
	
private Float diffValue;

private Float igstRt;

private Float igstAmt;

private Float cgstRt;

private Float cgstAmt;

private Float sgstRt;

private Float sgstAmt;

private String itcEligiblity;

private Float itcIGSTAmt;

private Float itcCGSTAmt;

private Float itcSGSTAmt;

private Float tcIGSTAmt;

private Float tcCGSTAmt;

private Float tcSGSTAmt;

private long taxPayerID;

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getCustGSTIN() {
	return custGSTIN;
}

public void setCustGSTIN(String custGSTIN) {
	this.custGSTIN = custGSTIN;
}

public String getInvTyp() {
	return invTyp;
}

public void setInvTyp(String invTyp) {
	this.invTyp = invTyp;
}

public String getCustName() {
	return custName;
}

public void setCustName(String custName) {
	this.custName = custName;
}

public Character getFlag() {
	return flag;
}

public void setFlag(Character flag) {
	this.flag = flag;
}

public String getChksum() {
	return chksum;
}

public void setChksum(String chksum) {
	this.chksum = chksum;
}

public String getNoteTyp() {
	return noteTyp;
}

public void setNoteTyp(String noteTyp) {
	this.noteTyp = noteTyp;
}

public int getNoteNum() {
	return noteNum;
}

public void setNoteNum(int noteNum) {
	this.noteNum = noteNum;
}

public Date getNoteDate() {
	return noteDate;
}

public void setNoteDate(Date noteDate) {
	this.noteDate = noteDate;
}

public String getReason() {
	return reason;
}

public void setReason(String reason) {
	this.reason = reason;
}

public String getInvNum() {
	return invNum;
}

public void setInvNum(String invNum) {
	this.invNum = invNum;
}

public Date getInvDate() {
	return invDate;
}

public void setInvDate(Date invDate) {
	this.invDate = invDate;
}

public Float getDiffValue() {
	return diffValue;
}

public void setDiffValue(Float diffValue) {
	this.diffValue = diffValue;
}

public Float getIgstRt() {
	return igstRt;
}

public void setIgstRt(Float igstRt) {
	this.igstRt = igstRt;
}

public Float getIgstAmt() {
	return igstAmt;
}

public void setIgstAmt(Float igstAmt) {
	this.igstAmt = igstAmt;
}

public Float getCgstRt() {
	return cgstRt;
}

public void setCgstRt(Float cgstRt) {
	this.cgstRt = cgstRt;
}

public Float getCgstAmt() {
	return cgstAmt;
}

public void setCgstAmt(Float cgstAmt) {
	this.cgstAmt = cgstAmt;
}

public Float getSgstRt() {
	return sgstRt;
}

public void setSgstRt(Float sgstRt) {
	this.sgstRt = sgstRt;
}

public Float getSgstAmt() {
	return sgstAmt;
}

public void setSgstAmt(Float sgstAmt) {
	this.sgstAmt = sgstAmt;
}

public String getItcEligiblity() {
	return itcEligiblity;
}

public void setItcEligiblity(String itcEligiblity) {
	this.itcEligiblity = itcEligiblity;
}

public Float getItcIGSTAmt() {
	return itcIGSTAmt;
}

public void setItcIGSTAmt(Float itcIGSTAmt) {
	this.itcIGSTAmt = itcIGSTAmt;
}

public Float getItcCGSTAmt() {
	return itcCGSTAmt;
}

public void setItcCGSTAmt(Float itcCGSTAmt) {
	this.itcCGSTAmt = itcCGSTAmt;
}

public Float getItcSGSTAmt() {
	return itcSGSTAmt;
}

public void setItcSGSTAmt(Float itcSGSTAmt) {
	this.itcSGSTAmt = itcSGSTAmt;
}

public Float getTcIGSTAmt() {
	return tcIGSTAmt;
}

public void setTcIGSTAmt(Float tcIGSTAmt) {
	this.tcIGSTAmt = tcIGSTAmt;
}

public Float getTcCGSTAmt() {
	return tcCGSTAmt;
}

public void setTcCGSTAmt(Float tcCGSTAmt) {
	this.tcCGSTAmt = tcCGSTAmt;
}

public Float getTcSGSTAmt() {
	return tcSGSTAmt;
}

public void setTcSGSTAmt(Float tcSGSTAmt) {
	this.tcSGSTAmt = tcSGSTAmt;
}

public long getTaxPayerID() {
	return taxPayerID;
}

public void setTaxPayerID(long taxPayerID) {
	this.taxPayerID = taxPayerID;
}



}
