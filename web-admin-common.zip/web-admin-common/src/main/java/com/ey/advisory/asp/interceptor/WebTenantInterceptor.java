package com.ey.advisory.asp.interceptor;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.GroupDto;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;

/**
 * @author Yamini.Priya
 * intercepts the rest calls and sets the request header- XtenantId
 * 
 * TODO: Place the loggers
 */
public class WebTenantInterceptor implements ClientHttpRequestInterceptor {

	private static final String TENANT_HEADER = "X-TENANT-ID";

	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {
		HttpHeaders headers = request.getHeaders();
		HttpServletRequest httpServletRequest = ((ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes()).getRequest();
		
		GroupDto group = (GroupDto)redisOp.getValueFromRedis(Constant.USER_GROUP,  httpServletRequest);
		String tenant;

		if(null !=group && null!=headers){
			tenant = group.getGroupCode();
			// TODO: If group not present invalidate the session
			if (!headers.containsKey(TENANT_HEADER)) {
				headers.add(TENANT_HEADER, tenant);
			} else {
					headers.remove(TENANT_HEADER);
				
			}
		}
		return execution.execute(request, body);

	}
}
