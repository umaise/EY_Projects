/**
 * 
 */
package com.ey.advisory.asp.service;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

/**
 * @author Nitesh.Tripathi
 *
 */
@Service
public class SecurityLogsServiceImpl implements SecurityLogsService{
	
	private static final Logger LOGGER = Logger.getLogger(SecurityLogsServiceImpl.class);
	
	@Override
	public void loginDetails(HttpServletRequest request, String message ){
		
		String clientIp = request.getRemoteAddr();
		String sessionIdForcurrentUser = (String) request.getAttribute("IdVal");
		
		LOGGER.info("Id="+sessionIdForcurrentUser+" Login performed from "+clientIp+" "+message);
		
	}
	
	@Override
	public void loggedInUser(HttpServletRequest request, String message ){
		
		//String clientIp = request.getRemoteAddr();
		String sessionIdForcurrentUser = (String) request.getAttribute("IdVal");
		
		LOGGER.info("Id="+sessionIdForcurrentUser+message);
		
	}
	
	@Override
	public void logMessage(HttpServletRequest request, String message ){
		
        String sessionIdForcurrentUser = (String) request.getAttribute("IdVal");
		
		LOGGER.info("Id="+sessionIdForcurrentUser+message);
		
	}

}
