package com.ey.advisory.asp.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ClientRegistrationDTO {

	private Long groupId;
	
	private String gstinId;
	private String  gSTNUserName;
	private Integer entityID;
	private Double turnOverAmount;
	private String typeOfReg;

	private Date regdt;
	private String bankAccountNumber;
	private Double quarterTurnOvrAmt;
	private Integer pAuthUserId;
	private Integer sAuthUserId;
	private Integer pContactUserId;
	private Integer sContactUserId;
	
	private String primaryAuthUserName;
	private String secondaryAuthUserName;
	private String primaryContact;
	private String secondaryContact;
	
	private String updatedBy;
    private Date updatedDate;
    private String createdBy;
    private Date createdDate;
    public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	private String updateDateFormatted;
	private String registrationDateFormatted;
	
	public String getRegistrationDateFormatted() {
		return registrationDateFormatted;
	}
	public void setRegistrationDateFormatted(String registrationDateFormatted) {
		this.registrationDateFormatted = registrationDateFormatted;
	}
	public String getUpdateDateFormatted() {
		return updateDateFormatted;
	}
	public void setUpdateDateFormatted(String updateDateFormatted) {
		this.updateDateFormatted = updateDateFormatted;
	}
	
	private Boolean isActive;
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public String getPrimaryAuthUserName() {
		return primaryAuthUserName;
	}
	public void setPrimaryAuthUserName(String primaryAuthUserName) {
		this.primaryAuthUserName = primaryAuthUserName;
	}
	public String getSecondaryAuthUserName() {
		return secondaryAuthUserName;
	}
	public void setSecondaryAuthUserName(String secondaryAuthUserName) {
		this.secondaryAuthUserName = secondaryAuthUserName;
	}
	public String getPrimaryContact() {
		return primaryContact;
	}
	public void setPrimaryContact(String primaryContact) {
		this.primaryContact = primaryContact;
	}
	public String getSecondaryContact() {
		return secondaryContact;
	}
	public void setSecondaryContact(String secondaryContact) {
		this.secondaryContact = secondaryContact;
	}
	
	public String getGstinId() {
		return gstinId;
	}
	public void setGstinId(String gstinId) {
		this.gstinId = gstinId;
	}
	public String getgSTNUserName() {
		return gSTNUserName;
	}
	public void setgSTNUserName(String gSTNUserName) {
		this.gSTNUserName = gSTNUserName;
	}
	public Integer getEntityID() {
		return entityID;
	}
	public void setEntityID(Integer entityID) {
		this.entityID = entityID;
	}
	public Double getTurnOverAmount() {
		return turnOverAmount;
	}
	public void setTurnOverAmount(Double turnOverAmount) {
		this.turnOverAmount = turnOverAmount;
	}
	public String getTypeOfReg() {
		return typeOfReg;
	}
	public void setTypeOfReg(String typeOfReg) {
		this.typeOfReg = typeOfReg;
	}
	public Date getRegdt() {
		return regdt;
	}
	public void setRegdt(Date regdt) {
		this.regdt = regdt;
	}
	public String getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	public Double getQuarterTurnOvrAmt() {
		return quarterTurnOvrAmt;
	}
	public void setQuarterTurnOvrAmt(Double quarterTurnOvrAmt) {
		this.quarterTurnOvrAmt = quarterTurnOvrAmt;
	}
	public Integer getpAuthUserId() {
		return pAuthUserId;
	}
	public void setpAuthUserId(Integer pAuthUserId) {
		this.pAuthUserId = pAuthUserId;
	}
	public Integer getsAuthUserId() {
		return sAuthUserId;
	}
	public void setsAuthUserId(Integer sAuthUserId) {
		this.sAuthUserId = sAuthUserId;
	}
	public Integer getpContactUserId() {
		return pContactUserId;
	}
	public void setpContactUserId(Integer pContactUserId) {
		this.pContactUserId = pContactUserId;
	}
	public Integer getsContactUserId() {
		return sContactUserId;
	}
	public void setsContactUserId(Integer sContactUserId) {
		this.sContactUserId = sContactUserId;
	}
	
}
