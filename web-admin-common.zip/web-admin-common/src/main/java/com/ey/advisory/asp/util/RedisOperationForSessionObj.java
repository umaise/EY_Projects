package com.ey.advisory.asp.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.domain.EntityHierarchyDto;
import com.ey.advisory.asp.domain.MasterHierarchyConfig;
import com.ey.advisory.asp.domain.Role;
import com.ey.advisory.asp.domain.RoleAccessHierarchyMap;
import com.ey.advisory.asp.domain.UserAccessMapping_dto;
import com.ey.advisory.asp.dto.DueDateMasterDto;
import com.ey.advisory.asp.dto.GSTINDetailsDto;
import com.ey.advisory.asp.dto.GroupAzureAdConfigDto;
import com.ey.advisory.asp.dto.GroupDto;
import com.ey.advisory.asp.dto.RoleDto;
import com.ey.advisory.asp.dto.RoleDtoTemp;
import com.ey.advisory.asp.dto.StatesDto;
import com.ey.advisory.asp.dto.TblReturnTypeRecordTypeMappingDto;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Service
public class RedisOperationForSessionObj {

	@Autowired
	private RedisSessionUtility util;

	/**
	 * @param util
	 *            the util to set
	 */
	public void setUtil(RedisSessionUtility util) {
		this.util = util;
	}

	public void deleteSession(HttpServletRequest request) {
		util.deleteSession(request);
	}

	public void setValueToRedis(String key, Object value, HttpServletRequest request) {
		util.updateCache(key, value, request);
	}

	/**
	 * Values : GroupName, userName, ReturnPeriod,monthYear,Group, return
	 * period,
	 * 
	 * @param key
	 * @param request
	 * @return
	 */
	public Object getValueFromRedis(String key, HttpServletRequest request) {

		Object value = util.retrieveFromCache(key, request);
		return value;
	}

	public void setStringListToRedis(String key, List<String> stringList, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(stringList);
		util.updateCache(key, outString, request);

	}

	/**
	 * RoleFunctionList
	 * 
	 * @param key
	 * @param request
	 * @return
	 */
	public List<String> getStringListFromRedis(String key, HttpServletRequest request) {
		String stringListJson = (String) util.retrieveFromCache(key, request);
		Gson gson = new Gson();
		List<String> stringList = gson.fromJson(stringListJson, new TypeToken<List<String>>() {
		}.getType());
		return stringList;
	}

	public void setStateListToRedis(List<StatesDto> stateList, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(stateList);
		util.updateCache(Constant.STATES_LIST, outString, request);

	}

	public List<StatesDto> getStateListFromRedis(HttpServletRequest request) {
		String stateListJson = (String) util.retrieveFromCache(Constant.STATES_LIST, request);
		Gson gson = new Gson();
		List<StatesDto> stateList = gson.fromJson(stateListJson, new TypeToken<List<StatesDto>>() {
		}.getType());
		return stateList;
	}

	public void setDueDateToRedis(List<DueDateMasterDto> dueDateList, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(dueDateList);
		util.updateCache(Constant.DUE_DATE_LIST, outString, request);
	}

	public List<DueDateMasterDto> getDueDateFromRedis(HttpServletRequest request) {
		String stateListJson = (String) util.retrieveFromCache(Constant.DUE_DATE_LIST, request);
		Gson gson = new Gson();
		List<DueDateMasterDto> dueDateMasterDtoList = gson.fromJson(stateListJson,
				new TypeToken<List<DueDateMasterDto>>() {
				}.getType());
		return dueDateMasterDtoList;
	}

	public void setGSTINToRedis(List<GSTINDetailsDto> GSTIN_LIST, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(GSTIN_LIST);
		util.updateCache(Constant.GSTIN_LIST, outString, request);
	}

	public List<GSTINDetailsDto> getGSTINDetailsFromRedis(HttpServletRequest request) {
		String GSTIN_LIST = (String) util.retrieveFromCache(Constant.GSTIN_LIST, request);
		Gson gson = new Gson();
		List<GSTINDetailsDto> gSTINDetailsDtoList = gson.fromJson(GSTIN_LIST, new TypeToken<List<GSTINDetailsDto>>() {
		}.getType());
		return gSTINDetailsDtoList;
	}

	public void setGroupSetToRedis(Set<GroupDto> groupDto, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(groupDto);
		util.updateCache(Constant.USER_GROUP_SET, outString, request);
	}

	public Set<GroupDto> getGroupSetFromRedis(HttpServletRequest request) {
		String groupSet = (String) util.retrieveFromCache(Constant.USER_GROUP_SET, request);
		Gson gson = new Gson();
		Set<GroupDto> groupDto = gson.fromJson(groupSet, new TypeToken<Set<GroupDto>>() {
		}.getType());
		return groupDto;
	}

	public void setUserAccessMapping(List<UserAccessMapping_dto> userAccMapDTOList, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(userAccMapDTOList);
		util.updateCache("UserAccessMapping", outString, request);
	}

	public List<UserAccessMapping_dto> getUserAccessMapping(HttpServletRequest request) {
		String userAccMap = (String) util.retrieveFromCache("UserAccessMapping", request);
		Gson gson = new Gson();
		List<UserAccessMapping_dto> userAccessMapping_dto = gson.fromJson(userAccMap,
				new TypeToken<List<UserAccessMapping_dto>>() {
				}.getType());
		return userAccessMapping_dto;

	}

	public void setUserEntityHierarchy(List<EntityHierarchyDto> entityHierarchyDtoList, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(entityHierarchyDtoList);
		util.updateCache("EntityHierarchy", outString, request);
	}

	public List<EntityHierarchyDto> getUserEntityHierarchy(HttpServletRequest request) {
		String entityHier = (String) util.retrieveFromCache("EntityHierarchy", request);
		Gson gson = new Gson();
		List<EntityHierarchyDto> userEntityHierarchy = gson.fromJson(entityHier,
				new TypeToken<List<EntityHierarchyDto>>() {
				}.getType());
		return userEntityHierarchy;

	}

	/** not for user session use ******/
	public void setListRole(List<RoleDtoTemp> roleDtoList, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(roleDtoList);
		util.updateCache("AllRoleListDto", outString, request);
	}

	/** not for user session use ******/
	public List<RoleDtoTemp> getListRole(HttpServletRequest request) {
		String entityHier = (String) util.retrieveFromCache("AllRoleListDto", request);
		Gson gson = new Gson();
		List<RoleDtoTemp> roleList = gson.fromJson(entityHier, new TypeToken<List<RoleDtoTemp>>() {
		}.getType());
		return roleList;

	}

	/** not for user session use ******/
	public void setGroupListToRedisAll(List<GroupDto> groupDtoList, String json, HttpServletRequest request) {

		String outString = "";
		if (json != null && json.trim().length() > 0) {
			outString = json;
		} else {
			Gson gson = new Gson();
			outString = gson.toJson(groupDtoList);

		}
		util.updateCache("AllGroupList", outString, request);
	}

	/** not for user session use ******/
	public List<GroupDto> getGroupListFromRedisAll(HttpServletRequest request) {
		String groupSet = (String) util.retrieveFromCache("AllGroupList", request);
		Gson gson = new Gson();
		List<GroupDto> groupDto = gson.fromJson(groupSet, new TypeToken<List<GroupDto>>() {
		}.getType());
		return groupDto;
	}

	public void setMasterHierarchyConfigList(List<MasterHierarchyConfig> MasterHierarchyConfigList,
			HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(MasterHierarchyConfigList);
		util.updateCache("MasterHierarchyConfig", outString, request);
	}

	public List<MasterHierarchyConfig> getMasterHierarchyConfigList(HttpServletRequest request) {
		String masterHier = (String) util.retrieveFromCache("MasterHierarchyConfig", request);
		Gson gson = new Gson();
		List<MasterHierarchyConfig> userEntityHierarchy = gson.fromJson(masterHier,
				new TypeToken<List<MasterHierarchyConfig>>() {
				}.getType());

		return userEntityHierarchy;

	}

	public void setRoleSetToRedis(Set<RoleDto> roleDto, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(roleDto);
		util.updateCache("AssigendRoleSet", outString, request);
	}

	public Set<RoleDto> getRoleSetFromRedis(HttpServletRequest request) {
		String roleDtoSet = (String) util.retrieveFromCache("AssigendRoleSet", request);
		Gson gson = new Gson();
		Set<RoleDto> RoleDto = gson.fromJson(roleDtoSet, new TypeToken<Set<RoleDto>>() {
		}.getType());
		return RoleDto;
	}

	public void setAllGSTINToRedis(List<GSTINDetailsDto> GSTIN_LIST, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(GSTIN_LIST);
		util.updateCache(Constant.ALL_GSTIN_LIST, outString, request);
	}

	public List<GSTINDetailsDto> getAllGSTINDetailsFromRedis(HttpServletRequest request) {
		String GSTIN_LIST = (String) util.retrieveFromCache(Constant.ALL_GSTIN_LIST, request);
		Gson gson = new Gson();
		List<GSTINDetailsDto> gSTINDetailsDtoList = gson.fromJson(GSTIN_LIST, new TypeToken<List<GSTINDetailsDto>>() {
		}.getType());
		return gSTINDetailsDtoList;
	}

	public String getStatusFromRedisfortheGstin(String gstinId) {
		String status = util.getStatusFromRedisCache(gstinId);
		return status;
	}

	public void setAllUserEntityHierarchy(List<EntityHierarchyDto> entityHierarchyDtoList, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(entityHierarchyDtoList);
		util.updateCache("AllEntityHierarchy", outString, request);
	}

	public List<EntityHierarchyDto> getAllUserEntityHierarchy(HttpServletRequest request) {
		String entityHier = (String) util.retrieveFromCache("AllEntityHierarchy", request);
		Gson gson = new Gson();
		List<EntityHierarchyDto> userEntityHierarchy = gson.fromJson(entityHier,
				new TypeToken<List<EntityHierarchyDto>>() {
				}.getType());
		return userEntityHierarchy;

	}

	public List<GroupAzureAdConfigDto> getValueFromRedisGrpAzAdConfigList() {

		Gson gson = new Gson();
		String value = (String) util.retrieveFromCache("GroupADConfigList");
		List<GroupAzureAdConfigDto> groupAzureAdConfig = gson.fromJson(value,
				new TypeToken<List<GroupAzureAdConfigDto>>() {
				}.getType());
		return groupAzureAdConfig;
	}
	
	public List<TblReturnTypeRecordTypeMappingDto> getTblReturnTypeRecordTypeMappingToRedis() {

		Gson gson = new Gson();
		String value = (String) util.retrieveFromCache(Constant.TBLRETURNTYPE_RECORDTYPEMAPPING);
		List<TblReturnTypeRecordTypeMappingDto> recordReturnType = gson.fromJson(value,
				new TypeToken<List<TblReturnTypeRecordTypeMappingDto>>() {
				}.getType());
		return recordReturnType;
	}	
	

	public List<RoleAccessHierarchyMap> getRoleAccessLevelMapList() {

		Gson gson = new Gson();
		String value = (String) util.retrieveFromCache("RoleLevelMap");
		List<RoleAccessHierarchyMap> roleAccessHierarchyMap = gson.fromJson(value,
				new TypeToken<List<RoleAccessHierarchyMap>>() {
				}.getType());

		return roleAccessHierarchyMap;
	}
	
	public Map<Object, Object> getGSPAuthTokenFromRedisCache(String groupIndicator){
		return util.getGSPAuthTokenFromRedisCache(groupIndicator);
	}
	
	public String getValueFromRedisGrpDomainName(String hostName) {

		String value = (String) util.retrieveFromCache(Constant.GROUP_DOMAIN_KEY+hostName);
		
		return value;
	}
	
	
	@SuppressWarnings("unchecked")
	public HashMap<String, String> getValueFromRedisGrpConfigs(String groupCode) {

		HashMap<String, String> configForGroupValue = (HashMap<String, String>) util.retrieveFromCache(Constant.GROUP_CONFIG_KEY+groupCode);
		
		return configForGroupValue;
	}
	
	
	public void setAuthSignGstins(Set<String> gstins, HttpServletRequest request) {

		Gson gson = new Gson();
		String outString = gson.toJson(gstins);
		util.updateCache(Constant.AUTH_SIGN_GSTIN_SET, outString, request);
	}
	
	
	public Set<String> getAuthSignGstinsFromRedis(HttpServletRequest request) {
		String gstins = (String) util.retrieveFromCache(Constant.AUTH_SIGN_GSTIN_SET, request);
		Gson gson = new Gson();
		Set<String> gstinsSet = gson.fromJson(gstins, new TypeToken<Set<String>>() {
		}.getType());
		return gstinsSet;
	}
	

	public List<Role> getAllRoles(HttpServletRequest request) {

		Gson gson = new Gson();
		String value = (String) util.retrieveFromCache(Constant.ROLE_LIST);
		
		List<Role> roleList = gson.fromJson(value, new TypeToken<List<Role>>() {}.getType());

		return roleList;
		
	}
	
	public String getDateModifiedFromRedisfortheGstin(String gstinId) {
        String dateModified = util.getDateModifiedFromRedisCache(gstinId);
        return dateModified;
  }

	public String getDateModifiedFromRedisforGspAuthDetails(String groupCode) {
        String dateModified = util.getDateModifiedFromRedisCacheForGsp(groupCode);
        return dateModified;
  }
	
}
