package com.ey.advisory.asp.reports.jasper.entity;

public class GSTR1SummaryRowHsn {

	Integer recCount;

	public Integer getRecCount() {
		return recCount;
	}

	public void setRecCount(Integer recCount) {
		this.recCount = recCount;
	}
	
	
}
