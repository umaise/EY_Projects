package com.ey.advisory.asp.dto;

import java.util.Date;

public class ItemMaster {

	private int itemId;
	private String receiverGSTIN;
	private String itemCode;
	private String desc;
	private String category;
	private String hsn;
	private String nonCreditable;
	private String reverseChange;
	private String tds;
	private String exempt;
	private Integer circularNumber;
	private Date circularDate;
	private Integer serialNumber;
	private Double igst;
	private Double cgst;
	private Double sgst;
	private Double utgst;
	private Double cess;
	
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	
	public String getReceiverGSTIN() {
		return receiverGSTIN;
	}
	public void setReceiverGSTIN(String receiverGSTIN) {
		this.receiverGSTIN = receiverGSTIN;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getHsn() {
		return hsn;
	}
	public void setHsn(String hsn) {
		this.hsn = hsn;
	}
	public String getNonCreditable() {
		return nonCreditable;
	}
	public void setNonCreditable(String nonCreditable) {
		this.nonCreditable = nonCreditable;
	}
	public String getReverseChange() {
		return reverseChange;
	}
	public void setReverseChange(String reverseChange) {
		this.reverseChange = reverseChange;
	}
	public String getTds() {
		return tds;
	}
	public void setTds(String tds) {
		this.tds = tds;
	}
	public String getExempt() {
		return exempt;
	}
	public void setExempt(String exempt) {
		this.exempt = exempt;
	}
	public Integer getCircularNumber() {
		return circularNumber;
	}
	public void setCircularNumber(Integer circularNumber) {
		this.circularNumber = circularNumber;
	}
	
	
	
	
	public Date getCircularDate() {
		return circularDate;
	}
	public void setCircularDate(Date circularDate) {
		this.circularDate = circularDate;
	}
	public Integer getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(Integer serialNumber) {
		this.serialNumber = serialNumber;
	}
	public Double getIgst() {
		return igst;
	}
	public void setIgst(Double igst) {
		this.igst = igst;
	}
	public Double getCgst() {
		return cgst;
	}
	public void setCgst(Double cgst) {
		this.cgst = cgst;
	}
	public Double getSgst() {
		return sgst;
	}
	public void setSgst(Double sgst) {
		this.sgst = sgst;
	}
	public Double getUtgst() {
		return utgst;
	}
	public void setUtgst(Double utgst) {
		this.utgst = utgst;
	}
	public Double getCess() {
		return cess;
	}
	public void setCess(Double cess) {
		this.cess = cess;
	}

}
