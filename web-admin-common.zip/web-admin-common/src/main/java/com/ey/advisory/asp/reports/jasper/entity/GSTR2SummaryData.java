package com.ey.advisory.asp.reports.jasper.entity;

import javax.validation.constraints.Pattern;

public class GSTR2SummaryData {
	
	@Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String reportName;
	
	 @Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	 String gstnId;
	
	 //@Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String businessName;
	
	 String gstr2Sum;
	
	 @Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String fYear;
	
	 @Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String returnPeriod;
	
	 Double totalTaxableValue;
	 
	 Double totalIgst;
	 
	 Double totalCgst;
	 
	 Double totalSgst;
	 
	 Double totalCess;
	 
	 Double totalItcAvailed;
	 
	 Double totalItcIgstAvailed;
	 
	 Double totalItcCgstAvailed;
	 
	 Double totalItcSgstAvailed;
	 
	 Double totalItcCessAvailed;
	 
	 Double totalTaxPay;
	 
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public String getGstnId() {
		return gstnId;
	}
	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getGstr2Sum() {
		return gstr2Sum;
	}
	public void setGstr2Sum(String gstr2Sum) {
		this.gstr2Sum = gstr2Sum;
	}
	public String getfYear() {
		return fYear;
	}
	public void setfYear(String fYear) {
		this.fYear = fYear;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public Double getTotalItcAvailed() {
		return totalItcAvailed;
	}
	public void setTotalItcAvailed(Double totalItcAvailed) {
		this.totalItcAvailed = totalItcAvailed;
	}
	public Double getTotalTaxableValue() {
		return totalTaxableValue;
	}
	public void setTotalTaxableValue(Double totalTaxableValue) {
		this.totalTaxableValue = totalTaxableValue;
	}
	public Double getTotalIgst() {
		return totalIgst;
	}
	public void setTotalIgst(Double totalIgst) {
		this.totalIgst = totalIgst;
	}
	public Double getTotalCgst() {
		return totalCgst;
	}
	public void setTotalCgst(Double totalCgst) {
		this.totalCgst = totalCgst;
	}
	public Double getTotalSgst() {
		return totalSgst;
	}
	public void setTotalSgst(Double totalSgst) {
		this.totalSgst = totalSgst;
	}
	public Double getTotalCess() {
		return totalCess;
	}
	public void setTotalCess(Double totalCess) {
		this.totalCess = totalCess;
	}
	public Double getTotalItcIgstAvailed() {
		return totalItcIgstAvailed;
	}
	public void setTotalItcIgstAvailed(Double totalItcIgstAvailed) {
		this.totalItcIgstAvailed = totalItcIgstAvailed;
	}
	public Double getTotalItcCgstAvailed() {
		return totalItcCgstAvailed;
	}
	public void setTotalItcCgstAvailed(Double totalItcCgstAvailed) {
		this.totalItcCgstAvailed = totalItcCgstAvailed;
	}
	public Double getTotalItcSgstAvailed() {
		return totalItcSgstAvailed;
	}
	public void setTotalItcSgstAvailed(Double totalItcSgstAvailed) {
		this.totalItcSgstAvailed = totalItcSgstAvailed;
	}
	public Double getTotalItcCessAvailed() {
		return totalItcCessAvailed;
	}
	public void setTotalItcCessAvailed(Double totalItcCessAvailed) {
		this.totalItcCessAvailed = totalItcCessAvailed;
	}
	public Double getTotalTaxPay() {
		return totalTaxPay;
	}
	public void setTotalTaxPay(Double totalTaxPay) {
		this.totalTaxPay = totalTaxPay;
	}
}
