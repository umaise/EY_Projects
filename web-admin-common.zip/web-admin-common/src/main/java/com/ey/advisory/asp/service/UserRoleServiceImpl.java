/**
 * 
 */
package com.ey.advisory.asp.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.ey.advisory.asp.domain.User;
import com.ey.advisory.asp.util.CommonRestClientUtility;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Nitesh.Tripathi
 *
 */
@Service
@PropertySource("classpath:ASPRestConfig.properties")
public class UserRoleServiceImpl implements UserRoleService {

	@Autowired
	private Environment env;

	@Value("${asp-restapi.host}")
	private String restHost;

	@Autowired
	private CommonRestClientUtility commonRestClientUtility;

	private static final Logger LOGGER = Logger.getLogger(UserRoleServiceImpl.class);
	@Override
	public User getUserDetails(String username) {

		User userObj = new User();
		userObj.setUserName(username);
		userObj.setEyLogin(env.getProperty("isEyLogin"));
		User user;
		ObjectMapper mapper = new ObjectMapper();

		ResponseEntity<Object> userEntity = null;
		try {
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("UserRoleServiceImpl.getUserDetails");
				LOGGER.info("asp-userRolePOST :- " + env.getProperty("asp-userRolePOST"));
				LOGGER.info("restHost :- " + restHost);
				LOGGER.info("commonRestClientUtility :- " + commonRestClientUtility);
				LOGGER.info("username :- " + username);
			}
			
			userEntity = commonRestClientUtility.executeRestApiCall(restHost + env.getProperty("asp-userRolePOST"),
					userObj, HttpMethod.POST, Object.class);	
			
		} catch (Exception ex) {
			LOGGER.error(ex);

		}

		if (userEntity == null || userEntity.getBody() == null) {
			user = null;
		} else {
			user = mapper.convertValue(userEntity.getBody(), User.class);

		}

		return user;

	}
	
	@Override
	public User getUserClientDetails(long userid, String group_id) {
		User user;
		ObjectMapper mapper = new ObjectMapper();

		ResponseEntity<Object> userEntity = null;
		try {
			LOGGER.info("UserRoleServiceImpl.getUserClientDetails");
			LOGGER.info("asp-userClientPOST :- " + env.getProperty("asp-userClientPOST"));
			LOGGER.info("restHost :- " + restHost);
			LOGGER.info("commonRestClientUtility :- " + commonRestClientUtility);
	
			userEntity = commonRestClientUtility.executeRestApiCall(restHost + env.getProperty("asp-userClientPOST"),
					userid+"#"+group_id, HttpMethod.POST, Object.class);
			LOGGER.info(userEntity);
		} catch (Exception ex) {
			LOGGER.error(ex);

		}

		if (userEntity == null || userEntity.getBody() == null) {
			user = null;
		} else {
			user = mapper.convertValue(userEntity.getBody(), User.class);

		}

		return user;

	}

}
