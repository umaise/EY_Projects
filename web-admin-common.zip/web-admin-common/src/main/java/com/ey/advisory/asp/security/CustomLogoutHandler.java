package com.ey.advisory.asp.security;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.web.context.ServletContextAware;

public class CustomLogoutHandler implements 
		LogoutHandler, ApplicationContextAware, ServletContextAware {
	
	private Log log = LogFactory.getLog(CustomLogoutHandler.class);
	private static final String CLASS_NAME = CustomLogoutHandler.class.getName();
	
	private ApplicationContext applicationContext;
	
	private ServletContext servletContext;

	public CustomLogoutHandler() {
		super();
	}

	/* (non-Javadoc)
	 * @see org.acegisecurity.ui.logout.LogoutHandler#logout(javax.servlet.http.HttpServletRequest, 
	 * javax.servlet.http.HttpServletResponse, org.acegisecurity.Authentication)
	 */
	@Override
	public void logout(HttpServletRequest arg0, HttpServletResponse arg1, Authentication auth) {
		if(log.isDebugEnabled()){
		log.debug("Entering "+CLASS_NAME+" logout");
		}
		if(auth != null) {
			
			LogoutEvent event = new LogoutEvent(auth);			
			applicationContext.publishEvent(event);
			HttpSession session =   arg0.getSession(false);
	        if(session!=null){
	            session.invalidate();
	        }
			Cookie[] cookiesToClear=arg0.getCookies();
			for (Cookie cookie : cookiesToClear) {
	     
	            cookie.setPath(null);
	            cookie.setMaxAge(0);
	            cookie.setValue(null);
	            arg1.addCookie(cookie);
	        }
		}if(log.isDebugEnabled())
		log.debug("Exiting "+CLASS_NAME+" logout");
	}

	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware
	 * #setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) 
			throws BeansException {
		
		this.applicationContext = applicationContext;
	}

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;	
	}
}
