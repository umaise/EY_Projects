package com.ey.advisory.asp.security;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class AddableHttpRequest extends HttpServletRequestWrapper {

	private HashMap<String, String> params = new HashMap<String, String>();
	StringBuffer bufferurl = new StringBuffer();
	StringBuffer bufferpath = new StringBuffer();
	String bufferuri = "";

	public AddableHttpRequest(HttpServletRequest request) {
		super(request);
		// TODO Auto-generated constructor stub
	}

	public String getParameter(String name) {
		// if we added one, return that one
		if (params.get(name) != null) {
			return params.get(name);
		}
		// otherwise return what's in the original request
		HttpServletRequest req = (HttpServletRequest) super.getRequest();
		return req.getParameter(name);
	}

	public void addParameter(String name, String value) {
		params.put(name, value);
	}

	public void setRequestURL(StringBuffer buffer2) {
		this.bufferurl = buffer2;
	}

	public StringBuffer getRequestURL() {
		if (bufferurl.length() == 0) {
			return super.getRequestURL();
		} else {
			return bufferurl;
		}
	}
	public void setRequestURI(String buffer2) {
		this.bufferuri = buffer2;
	}

	public void setRequestPath(String buffer2) {
		this.bufferpath = new StringBuffer(buffer2);
	}
	
	public String getServletPath() {
		if (bufferpath.length() == 0) {
			return super.getServletPath();
		} else {
			return bufferpath.toString();
		}
	}
	
	public String getRequestURI() {
		if (bufferuri.length() == 0) {
			return super.getRequestURI();
		} else {
			return bufferuri;
		}
	}
}