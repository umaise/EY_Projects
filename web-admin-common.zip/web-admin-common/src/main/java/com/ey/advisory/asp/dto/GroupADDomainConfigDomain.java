/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.io.Serializable;



import com.ey.advisory.asp.common.Constant;

/**
 * @author Nitesh.Tripathi
 *
 */
public class GroupADDomainConfigDomain implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private Long groupADDomainConfigID;
	

	private Long groupId;
	
	
	private String userDomains;

	/**
	 * @return the groupADDomainConfigID
	 */
	public Long getGroupADDomainConfigID() {
		return groupADDomainConfigID;
	}

	/**
	 * @param groupADDomainConfigID the groupADDomainConfigID to set
	 */
	public void setGroupADDomainConfigID(Long groupADDomainConfigID) {
		this.groupADDomainConfigID = groupADDomainConfigID;
	}

	/**
	 * @return the groupId
	 */
	public Long getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the userDomains
	 */
	public String getUserDomains() {
		return userDomains;
	}

	/**
	 * @param userDomains the userDomains to set
	 */
	public void setUserDomains(String userDomains) {
		this.userDomains = userDomains;
	}

}
