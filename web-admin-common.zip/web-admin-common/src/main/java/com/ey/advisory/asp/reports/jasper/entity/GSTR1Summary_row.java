package com.ey.advisory.asp.reports.jasper.entity;

public class GSTR1Summary_row {

	Double taxableValue;
	Double taxPayable;
	Double invoiceValue;
	Double igst;
	Double cgst;
	Double sgst;
	Double cess;
	Double totalNil;
	Double totalexempt;
	Double nonGst;
	Double totalDoc;
	Double netDoc;
	Double totalCancel;
	
	public Double getTaxableValue() {
		return taxableValue;
	}
	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}
	public Double getTaxPayable() {
		return taxPayable;
	}
	public void setTaxPayable(Double taxPayable) {
		this.taxPayable = taxPayable;
	}
	public Double getInvoiceValue() {
		return invoiceValue;
	}
	public void setInvoiceValue(Double invoiceValue) {
		this.invoiceValue = invoiceValue;
	}
	public Double getIgst() {
		return igst;
	}
	public void setIgst(Double igst) {
		this.igst = igst;
	}
	public Double getCgst() {
		return cgst;
	}
	public void setCgst(Double cgst) {
		this.cgst = cgst;
	}
	public Double getSgst() {
		return sgst;
	}
	public void setSgst(Double sgst) {
		this.sgst = sgst;
	}
	public Double getCess() {
		return cess;
	}
	public void setCess(Double cess) {
		this.cess = cess;
	}
	public Double getTotalNil() {
		return totalNil;
	}
	public void setTotalNil(Double totalNil) {
		this.totalNil = totalNil;
	}
	public Double getTotalexempt() {
		return totalexempt;
	}
	public void setTotalexempt(Double totalexempt) {
		this.totalexempt = totalexempt;
	}
	public Double getNonGst() {
		return nonGst;
	}
	public void setNonGst(Double nonGst) {
		this.nonGst = nonGst;
	}
	public Double getTotalDoc() {
		return totalDoc;
	}
	public void setTotalDoc(Double totalDoc) {
		this.totalDoc = totalDoc;
	}
	public Double getNetDoc() {
		return netDoc;
	}
	public void setNetDoc(Double netDoc) {
		this.netDoc = netDoc;
	}
	public Double getTotalCancel() {
		return totalCancel;
	}
	public void setTotalCancel(Double totalCancel) {
		this.totalCancel = totalCancel;
	}

}
