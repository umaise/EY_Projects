package com.ey.advisory.asp.domain;

public class EntityEscalation {

	private Integer matrixId;
	private String accessType;
	private String contactPersonUserName;
	private String userLevel;
	private Integer entityId;
	private Integer contactPersonId;
	
	public Integer getMatrixId() {
		return matrixId;
	}
	public void setMatrixId(Integer matrixId) {
		this.matrixId = matrixId;
	}
	public String getAccessType() {
		return accessType;
	}
	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
	public String getContactPersonUserName() {
		return contactPersonUserName;
	}
	public void setContactPersonUserName(String contactPersonUserName) {
		this.contactPersonUserName = contactPersonUserName;
	}
	public String getUserLevel() {
		return userLevel;
	}
	public void setUserLevel(String userLevel) {
		this.userLevel = userLevel;
	}
	public Integer getEntityId() {
		return entityId;
	}
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
	public Integer getContactPersonId() {
		return contactPersonId;
	}
	public void setContactPersonId(Integer contactPersonId) {
		this.contactPersonId = contactPersonId;
	}
	
	
	
	
}
