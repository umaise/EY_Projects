package com.ey.advisory.asp.exception;

import java.io.IOException;
import java.sql.SQLException;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.ey.advisory.asp.common.Constant;
import com.google.gson.Gson;

/**
 * @author Uma.Chandranaik
 *
 */

@ControllerAdvice
public class GlobalExceptionHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@ExceptionHandler(SQLException.class)
	public ModelAndView handleSQLException(HttpServletRequest request) {
		
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("SQLException Occured:: URL=" + request.getRequestURL());
		}
		return new ModelAndView(new RedirectView("/error", true));
		
	}

	@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "IOException occured")
	@ExceptionHandler(IOException.class)
	public void handleIOException() {
		LOGGER.error("IOException handler executed");
		// returning 404 error code
	}
	
	@ExceptionHandler(AuthenticationException.class)
	public ModelAndView handleAuthExceptrion(){
		return new ModelAndView(new RedirectView("/error", true));
	}
	
	@ExceptionHandler(javax.naming.AuthenticationException.class)
	public ModelAndView handleNamingAuthExceptrion(){
		return new ModelAndView(new RedirectView("/error", true));
	}
	
	
	@ExceptionHandler(BadCredentialsException.class)
	public ModelAndView handleBadCredentialExceptrion(){
		return new ModelAndView(new RedirectView("/error", true));
	}
	
	@ExceptionHandler(com.ey.advisory.asp.exception.ASPInputValidationException.class)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public Object handleASPInputValidationException(com.ey.advisory.asp.exception.ASPInputValidationException e){
		return e.getMessage();
	}
	
	@ExceptionHandler(java.lang.RuntimeException.class)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public Object handleRuntimeException(RuntimeException e){
		return e.getMessage();
	}
	
		
	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public Object exception(Exception exception) {
		if(exception.getMessage().contains(Constant.ASP_INPUT_VALIDATION_EXCEPTION))
			return new Gson().toJson(exception.getMessage());
		else{
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("errorPage");
			String errorMsg = exception.getMessage();
			modelAndView.addObject("errorMsg", errorMsg);
			return modelAndView;
		}
	}
}
