package com.ey.advisory.asp.util;

import java.util.stream.Stream;

public enum GstrEnum {

		GSTR1,GSTR2, GSTR3B, GSTR6;/*,GSTR2A,GSTR3,GSTR4,GSTR5,GSTR6,GSTR6,GSTR7,GSTR8;*/

	public static String[] names() {
	    return Stream.of(GstrEnum.values()).map(GstrEnum::name).toArray(String[]::new);
	}
	
}
