package com.ey.advisory.asp.dto;

import java.math.BigDecimal;
import java.util.Date;


public class ProductMaster {
	private Long productId;
    private String sgstin;
    private String itemCode;
    private String description;
    private String hsnsac;
    private String unitOfMeasurement;
    private String reverseCharge;
    private Boolean isTDS;
    private Boolean isExempt;
    private String notificationNum;
    private Date notificationDate;
    private String serialNumber;
    private BigDecimal igstrt;
    private BigDecimal cgstrt;
    private BigDecimal sgstrt;
    private BigDecimal utgst;
    private BigDecimal cessrt;
    private BigDecimal cessrtvalerom;
      
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getSgstin() {
		return sgstin;
	}
	public void setSgstin(String sgstin) {
		this.sgstin = sgstin;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHsnsac() {
		return hsnsac;
	}
	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}
	public String getUnitOfMeasurement() {
		return unitOfMeasurement;
	}
	public void setUnitOfMeasurement(String unitOfMeasurement) {
		this.unitOfMeasurement = unitOfMeasurement;
	}
	public String getReverseCharge() {
		return reverseCharge;
	}
	public void setReverseCharge(String reverseCharge) {
		this.reverseCharge = reverseCharge;
	}
	public Boolean getIsTDS() {
		return isTDS;
	}
	public void setIsTDS(Boolean isTDS) {
		this.isTDS = isTDS;
	}
	public Boolean getIsExempt() {
		return isExempt;
	}
	public void setIsExempt(Boolean isExempt) {
		this.isExempt = isExempt;
	}
	public String getNotificationNum() {
		return notificationNum;
	}
	public void setNotificationNum(String notificationNum) {
		this.notificationNum = notificationNum;
	}
	public Date getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public BigDecimal getIgstrt() {
		return igstrt;
	}
	public void setIgstrt(BigDecimal igstrt) {
		this.igstrt = igstrt;
	}
	public BigDecimal getCgstrt() {
		return cgstrt;
	}
	public void setCgstrt(BigDecimal cgstrt) {
		this.cgstrt = cgstrt;
	}
	public BigDecimal getSgstrt() {
		return sgstrt;
	}
	public void setSgstrt(BigDecimal sgstrt) {
		this.sgstrt = sgstrt;
	}
	public BigDecimal getUtgst() {
		return utgst;
	}
	public void setUtgst(BigDecimal utgst) {
		this.utgst = utgst;
	}
	public BigDecimal getCessrt() {
		return cessrt;
	}
	public void setCessrt(BigDecimal cessrt) {
		this.cessrt = cessrt;
	}
	public BigDecimal getCessrtvalerom() {
		return cessrtvalerom;
	}
	public void setCessrtvalerom(BigDecimal cessrtvalerom) {
		this.cessrtvalerom = cessrtvalerom;
	}
	
    
   
	
	
	

}
