package com.ey.advisory.asp.domain;

import java.math.BigDecimal;
import java.util.Date;

import com.ey.advisory.asp.domain.MasterTables;

public class VendorMaster implements MasterTables  {

	private String receiverGSTIN;
	private String vendorGSTIN;
	private String vendorCode;
	private String vendorName;
	private String vendorAddress;
	private String vendorLocationCode;
	private String vendorCategory;
	private String co_LLP_P_Individual ;
	private String category;
	private String aHSNOrSAC;
	private String aPOS;
	private String illustrativeExample;
	private String vendorPrimaryContactPerson;
	private String primaryEmailId;
	private Long primaryMobileNumber;
	private String vendorSecondaryContactPerson;
	private String secondaryEmailId;
	private Long secondaryMobileNumber;
	private String isExemptOrconcessionalYorN;
	private String circularOrNotificationNumber;
	private Date circularOrNotificationDate;
	private String serialNumberOfCircular;
	private BigDecimal aIGSTRate;
	private BigDecimal aCGSTRate;
	private BigDecimal aSGSTRate;
	private BigDecimal aUTGSTRate;
	private BigDecimal aCessRate;
	private String isTDS;


	public String getReceiverGSTIN() {
		return receiverGSTIN;
	}

	public void setReceiverGSTIN(String receiverGSTIN) {
		this.receiverGSTIN = receiverGSTIN;
	}

	public String getVendorGSTIN() {
		return vendorGSTIN;
	}

	public void setVendorGSTIN(String vendorGSTIN) {
		this.vendorGSTIN = vendorGSTIN;
	}

	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}

	public String getVendorLocationCode() {
		return vendorLocationCode;
	}

	public void setVendorLocationCode(String vendorLocationCode) {
		this.vendorLocationCode = vendorLocationCode;
	}

	public String getVendorCategory() {
		return vendorCategory;
	}

	public void setVendorCategory(String vendorCategory) {
		this.vendorCategory = vendorCategory;
	}

	public String getCo_LLP_P_Individual() {
		return co_LLP_P_Individual;
	}

	public void setCo_LLP_P_Individual(String co_LLP_P_Individual) {
		this.co_LLP_P_Individual = co_LLP_P_Individual;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getaHSNOrSAC() {
		return aHSNOrSAC;
	}

	public void setaHSNOrSAC(String aHSNOrSAC) {
		this.aHSNOrSAC = aHSNOrSAC;
	}

	public String getaPOS() {
		return aPOS;
	}

	public void setaPOS(String aPOS) {
		this.aPOS = aPOS;
	}

	public String getIllustrativeExample() {
		return illustrativeExample;
	}

	public void setIllustrativeExample(String illustrativeExample) {
		this.illustrativeExample = illustrativeExample;
	}

	public String getVendorPrimaryContactPerson() {
		return vendorPrimaryContactPerson;
	}

	public void setVendorPrimaryContactPerson(String vendorPrimaryContactPerson) {
		this.vendorPrimaryContactPerson = vendorPrimaryContactPerson;
	}

	public String getPrimaryEmailId() {
		return primaryEmailId;
	}

	public void setPrimaryEmailId(String primaryEmailId) {
		this.primaryEmailId = primaryEmailId;
	}

	public Long getPrimaryMobileNumber() {
		return primaryMobileNumber;
	}

	public void setPrimaryMobileNumber(Long primaryMobileNumber) {
		this.primaryMobileNumber = primaryMobileNumber;
	}

	public String getVendorSecondaryContactPerson() {
		return vendorSecondaryContactPerson;
	}

	public void setVendorSecondaryContactPerson(String vendorSecondaryContactPerson) {
		this.vendorSecondaryContactPerson = vendorSecondaryContactPerson;
	}

	public String getSecondaryEmailId() {
		return secondaryEmailId;
	}

	public void setSecondaryEmailId(String secondaryEmailId) {
		this.secondaryEmailId = secondaryEmailId;
	}

	public Long getSecondaryMobileNumber() {
		return secondaryMobileNumber;
	}

	public void setSecondaryMobileNumber(Long secondaryMobileNumber) {
		this.secondaryMobileNumber = secondaryMobileNumber;
	}

	public String getIsExemptOrconcessionalYorN() {
		return isExemptOrconcessionalYorN;
	}

	public void setIsExemptOrconcessionalYorN(String isExemptOrconcessionalYorN) {
		this.isExemptOrconcessionalYorN = isExemptOrconcessionalYorN;
	}

	public String getCircularOrNotificationNumber() {
		return circularOrNotificationNumber;
	}

	public void setCircularOrNotificationNumber(String circularOrNotificationNumber) {
		this.circularOrNotificationNumber = circularOrNotificationNumber;
	}

	public java.util.Date getCircularOrNotificationDate() {
		return circularOrNotificationDate;
	}

	public void setCircularOrNotificationDate(
			java.util.Date circularOrNotificationDate) {
		this.circularOrNotificationDate = circularOrNotificationDate;
	}

	public String getSerialNumberOfCircular() {
		return serialNumberOfCircular;
	}

	public void setSerialNumberOfCircular(String serialNumberOfCircular) {
		this.serialNumberOfCircular = serialNumberOfCircular;
	}

	public BigDecimal getaIGSTRate() {
		return aIGSTRate;
	}

	public void setaIGSTRate(BigDecimal aIGSTRate) {
		this.aIGSTRate = aIGSTRate;
	}

	public BigDecimal getaCGSTRate() {
		return aCGSTRate;
	}

	public void setaCGSTRate(BigDecimal aCGSTRate) {
		this.aCGSTRate = aCGSTRate;
	}

	public BigDecimal getaSGSTRate() {
		return aSGSTRate;
	}

	public void setaSGSTRate(BigDecimal aSGSTRate) {
		this.aSGSTRate = aSGSTRate;
	}

	public BigDecimal getaUTGSTRate() {
		return aUTGSTRate;
	}

	public void setaUTGSTRate(BigDecimal aUTGSTRate) {
		this.aUTGSTRate = aUTGSTRate;
	}

	public BigDecimal getaCessRate() {
		return aCessRate;
	}

	public void setaCessRate(BigDecimal aCessRate) {
		this.aCessRate = aCessRate;
	}

	public String getIsTDS() {
		return isTDS;
	}

	public void setIsTDS(String isTDS) {
		this.isTDS = isTDS;
	}

	@Override
	public String toString() {
		return "VendorMaster [receiverGSTIN=" + receiverGSTIN
				+ ", vendorGSTIN=" + vendorGSTIN + ", vendorCode=" + vendorCode
				+ ", vendorName=" + vendorName + ", vendorAddress="
				+ vendorAddress + ", vendorLocationCode=" + vendorLocationCode
				+ ", vendorCategory=" + vendorCategory
				+ ", co_LLP_P_Individual=" + co_LLP_P_Individual
				+ ", category=" + category + ", aHSNOrSAC=" + aHSNOrSAC
				+ ", aPOS=" + aPOS + ", illustrativeExample="
				+ illustrativeExample + ", vendorPrimaryContactPerson="
				+ vendorPrimaryContactPerson + ", primaryEmailId="
				+ primaryEmailId + ", primaryMobileNumber="
				+ primaryMobileNumber + ", vendorSecondaryContactPerson="
				+ vendorSecondaryContactPerson + ", secondaryEmailId="
				+ secondaryEmailId + ", secondaryMobileNumber="
				+ secondaryMobileNumber + ", isExemptOrconcessionalYorN="
				+ isExemptOrconcessionalYorN
				+ ", circularOrNotificationNumber="
				+ circularOrNotificationNumber
				+ ", circularOrNotificationDate=" + circularOrNotificationDate
				+ ", serialNumberOfCircular=" + serialNumberOfCircular
				+ ", aIGSTRate=" + aIGSTRate + ", aCGSTRate=" + aCGSTRate
				+ ", aSGSTRate=" + aSGSTRate + ", aUTGSTRate=" + aUTGSTRate
				+ ", aCessRate=" + aCessRate + ", isTDS=" + isTDS + "]";
	}


}
