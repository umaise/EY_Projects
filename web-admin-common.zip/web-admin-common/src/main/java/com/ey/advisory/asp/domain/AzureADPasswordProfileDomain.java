package com.ey.advisory.asp.domain;

import javax.validation.constraints.Pattern;

public class AzureADPasswordProfileDomain {
	@Pattern(regexp = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}")
	private String password;
	@Pattern(regexp = "^[a-zA-Z]+$")
	private boolean forceChangePasswordNextLogin;

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the forceChangePasswordNextLogin
	 */
	public boolean isForceChangePasswordNextLogin() {
		return forceChangePasswordNextLogin;
	}

	

	/**
	 * @param forceChangePasswordNextLogin the forceChangePasswordNextLogin to set
	 */
	public void setForceChangePasswordNextLogin(boolean forceChangePasswordNextLogin) {
		this.forceChangePasswordNextLogin = forceChangePasswordNextLogin;
	}
	
	

}
