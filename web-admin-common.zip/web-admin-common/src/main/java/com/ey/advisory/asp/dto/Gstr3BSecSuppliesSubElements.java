package com.ey.advisory.asp.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class Gstr3BSecSuppliesSubElements {
	@XmlElement(defaultValue = "00.0")
	private List<Gstr3BRecords> Record = new ArrayList<Gstr3BRecords>();
	
	@XmlElement
	public List<Gstr3BRecords> getRecord() {
		return Record;
	}

	public void setRecord(List<Gstr3BRecords> record) {
		Record = record;
	}

	@Override
	public String toString() {
		return "Gstr3BSecSuppliesSubElements [Record=" + Record + "]";
	}

}
