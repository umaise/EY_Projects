package com.ey.advisory.asp.domain;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.dto.GroupDto;

public class OnBoard {

	private Integer draftId;
	private Long userID;
	private GroupDto clientGroup;
	private EntityNew clientEntity;
	private List<String> gstinList;
	private List<String> emailList;
	private List<ClientGstin> clientGstinList;
	private List<EntityHierarchy> hierarchyList;
	private List<UserClient> clientUser;
	private List<ClientCommunication> communicationList;
	private List<EntityEscalation> escalationList;
	private List<ProductMaster> productMasterList;
	private List<ItemMaster> itemMasterList;
	private List<CustomerMaster> customerMasterList;
	private List<VendorMaster> vendorMasterList;
	private List<QuestionAnswerModule> questionAnswerList;
    private Map<String,Long> userIdL1Map;
	
	
	public Map<String, Long> getUserIdL1Map() {
		return userIdL1Map;
	}
	public void setUserIdL1Map(Map<String, Long> userIdL1Map) {
		this.userIdL1Map = userIdL1Map;
	}
	public Integer getDraftId() {
		return draftId;
	}
	public void setDraftId(Integer draftId) {
		this.draftId = draftId;
	}
	public Long getUserID() {
		return userID;
	}
	public void setUserID(Long userID) {
		this.userID = userID;
	}
	public List<ProductMaster> getProductMasterList() {
		return productMasterList;
	}
	public void setProductMasterList(List<ProductMaster> productMasterList) {
		this.productMasterList = productMasterList;
	}
	public List<ItemMaster> getItemMasterList() {
		return itemMasterList;
	}
	public void setItemMasterList(List<ItemMaster> itemMasterList) {
		this.itemMasterList = itemMasterList;
	}
	public List<CustomerMaster> getCustomerMasterList() {
		return customerMasterList;
	}
	public void setCustomerMasterList(List<CustomerMaster> customerMasterList) {
		this.customerMasterList = customerMasterList;
	}
	public List<VendorMaster> getVendorMasterList() {
		return vendorMasterList;
	}
	public void setVendorMasterList(List<VendorMaster> vendorMasterList) {
		this.vendorMasterList = vendorMasterList;
	}
	public List<QuestionAnswerModule> getQuestionAnswerList() {
		return questionAnswerList;
	}
	public void setQuestionAnswerList(List<QuestionAnswerModule> questionAnswerList) {
		this.questionAnswerList = questionAnswerList;
	}
	public List<UserClient> getClientUser() {
		return clientUser;
	}
	public void setClientUser(List<UserClient> clientUser) {
		this.clientUser = clientUser;
	}
	
	public List<ClientCommunication> getCommunicationList() {
		return communicationList;
	}
	public void setCommunicationList(List<ClientCommunication> communicationList) {
		this.communicationList = communicationList;
	}
	public EntityNew getClientEntity() {
		return clientEntity;
	}
	public void setClientEntity(EntityNew clientEntity) {
		this.clientEntity = clientEntity;
	}
	public List<ClientGstin> getClientGstinList() {
		return clientGstinList;
	}
	public void setClientGstinList(List<ClientGstin> clientGstinList) {
		this.clientGstinList = clientGstinList;
	}
	public List<EntityHierarchy> getHierarchyList() {
		return hierarchyList;
	}
	public void setHierarchyList(List<EntityHierarchy> hierarchyList) {
		this.hierarchyList = hierarchyList;
	}
	public GroupDto getClientGroup() {
		return clientGroup;
	}
	public void setClientGroup(GroupDto clientGroup) {
		if(clientGroup!=null)
		{
			clientGroup.setCreatedBy(null);
			clientGroup.setCreatedDate(null);
			clientGroup.setIsActive(null);
			clientGroup.setIsDivParent(null);
			clientGroup.setUpdatedBy(null);
			clientGroup.setUpdatedDate(null);
		}
		this.clientGroup = clientGroup;
	}
	public List<EntityEscalation> getEscalationList() {
		return escalationList;
	}
	public void setEscalationList(List<EntityEscalation> escalationList) {
		this.escalationList = escalationList;
	}
	public List<String> getGstinList() {
		return gstinList;
	}
	public void setGstinList(List<String> gstinList) {
		this.gstinList = gstinList;
	}
	public List<String> getEmailList() {
		return emailList;
	}
	public void setEmailList(List<String> emailList) {
		this.emailList = emailList;
	}
	
	
	
	
	
	
	
	
}
