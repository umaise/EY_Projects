package com.ey.advisory.asp.domain;

import java.math.BigDecimal;
import java.util.Date;

import com.ey.advisory.asp.domain.MasterTables;

public class ProductMaster implements MasterTables{
	
    private String sgstin;
    private String itemCode;
    private String description;
    private String category;
    private String hsnsac;
    private String unitOfMeasurement;
    private String reverseCharge;
    private String isTDS;
    private String isExempt;
    private String notificationNum;
    private Date notificationDate;
    private Date dateOfCircular;
    private BigDecimal igstrt;
    private BigDecimal cgstrt;
    private BigDecimal sgstrt;
    private BigDecimal utgst;
    private BigDecimal cessrt;
    private BigDecimal cessrtvalerom;
    private BigDecimal cessrtAdvalerom;

    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    
	public String getSgstin() {
		return sgstin;
	}
	public void setSgstin(String sgstin) {
		this.sgstin = sgstin;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHsnsac() {
		return hsnsac;
	}
	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}
	public String getUnitOfMeasurement() {
		return unitOfMeasurement;
	}
	public void setUnitOfMeasurement(String unitOfMeasurement) {
		this.unitOfMeasurement = unitOfMeasurement;
	}
	public String getReverseCharge() {
		return reverseCharge;
	}
	public void setReverseCharge(String reverseCharge) {
		this.reverseCharge = reverseCharge;
	}
	public String getIsTDS() {
		return isTDS;
	}
	public void setIsTDS(String isTDS) {
		this.isTDS = isTDS;
	}
	public String getIsExempt() {
		return isExempt;
	}
	public void setIsExempt(String isExempt) {
		this.isExempt = isExempt;
	}
	public String getNotificationNum() {
		return notificationNum;
	}
	public void setNotificationNum(String notificationNum) {
		this.notificationNum = notificationNum;
	}
	public Date getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	public Date getDateOfCircular() {
		return dateOfCircular;
	}
	public void setDateOfCircular(Date dateOfCircular) {
		this.dateOfCircular = dateOfCircular;
	}
	public BigDecimal getIgstrt() {
		return igstrt;
	}
	public void setIgstrt(BigDecimal igstrt) {
		this.igstrt = igstrt;
	}
	public BigDecimal getCgstrt() {
		return cgstrt;
	}
	public void setCgstrt(BigDecimal cgstrt) {
		this.cgstrt = cgstrt;
	}
	public BigDecimal getSgstrt() {
		return sgstrt;
	}
	public void setSgstrt(BigDecimal sgstrt) {
		this.sgstrt = sgstrt;
	}
	public BigDecimal getUtgst() {
		return utgst;
	}
	public void setUtgst(BigDecimal utgst) {
		this.utgst = utgst;
	}
	public BigDecimal getCessrt() {
		return cessrt;
	}
	public void setCessrt(BigDecimal cessrt) {
		this.cessrt = cessrt;
	}
	public BigDecimal getCessrtvalerom() {
		return cessrtvalerom;
	}
	public void setCessrtvalerom(BigDecimal cessrtvalerom) {
		this.cessrtvalerom = cessrtvalerom;
	}
	public BigDecimal getCessrtAdvalerom() {
        return cessrtAdvalerom;
    }
    public void setCessrtAdvalerom(BigDecimal cessrtAdvalerom) {
        this.cessrtAdvalerom = cessrtAdvalerom;
    }
	
    @Override
	public String toString() {
		return "ProductMaster [sgstin=" + sgstin + ", itemCode=" + itemCode
				+ ", description=" + description + ", category=" + category
				+ ", hsnsac=" + hsnsac + ", unitOfMeasurement="
				+ unitOfMeasurement + ", reverseCharge=" + reverseCharge
				+ ", isTDS=" + isTDS + ", isExempt=" + isExempt
				+ ", notificationNum=" + notificationNum
				+ ", notificationDate=" + notificationDate
				+ ", dateOfCircular=" + dateOfCircular + ", igstrt=" + igstrt
				+ ", cgstrt=" + cgstrt + ", sgstrt=" + sgstrt + ", utgst="
				+ utgst + ", cessrt=" + cessrt + ", cessrtvalerom="
				+ cessrtvalerom + ", cessrtAdvalerom=" + cessrtAdvalerom + "]";
	}
	
    
}
