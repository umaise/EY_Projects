/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author Uma.Chandranaik
 *
 */

public class CashLedgerDetails  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long cashID;
	
	private CashITCLedgerMaster masterId;
	
	private Gstr3AccountHead accHeadId;
	
	private BigDecimal tax;
	
	private BigDecimal interest;
	
	private BigDecimal penalty;
	
	private BigDecimal fee;
	
	private BigDecimal others;
	
	private BigDecimal total;

	public Long getCashID() {
		return cashID;
	}

	public void setCashID(Long cashID) {
		this.cashID = cashID;
	}

	public CashITCLedgerMaster getMasterId() {
		return masterId;
	}

	public void setMasterId(CashITCLedgerMaster masterId) {
		this.masterId = masterId;
	}

	public Gstr3AccountHead getAccHeadId() {
		return accHeadId;
	}

	public void setAccHeadId(Gstr3AccountHead accHeadId) {
		this.accHeadId = accHeadId;
	}

	public BigDecimal getTax() {
		return tax;
	}

	public void setTax(BigDecimal tax) {
		this.tax = tax;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public BigDecimal getPenalty() {
		return penalty;
	}

	public void setPenalty(BigDecimal penalty) {
		this.penalty = penalty;
	}

	public BigDecimal getFee() {
		return fee;
	}

	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}

	public BigDecimal getOthers() {
		return others;
	}

	public void setOthers(BigDecimal others) {
		this.others = others;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	
	

}
