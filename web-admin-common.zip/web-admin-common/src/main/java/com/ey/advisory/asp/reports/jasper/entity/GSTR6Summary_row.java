package com.ey.advisory.asp.reports.jasper.entity;

public class GSTR6Summary_row {


	Integer recCount;
	Double taxablevalue;
	/*Double igst;
	Double cgst;
	Double sgstutgst;
	Double cess;
	Double itcigst;
	Double itccgst;
	Double itcsgstutgst;
	Double itccess;*/
	Double ttlValue;
	Double taxPd;
	Double itcAv;
	String checksum;
	
	Double cptTtlValue;
	Double cptTaxPd;
	Double cptItcAv;
	
	public Integer getRecCount() {
		return recCount;
	}
	public void setRecCount(Integer recCount) {
		this.recCount = recCount;
	}
	public Double getTaxablevalue() {
		return taxablevalue;
	}
	public void setTaxablevalue(Double taxablevalue) {
		this.taxablevalue = taxablevalue;
	}
	/*public Double getIgst() {
		return igst;
	}
	public void setIgst(Double igst) {
		this.igst = igst;
	}
	public Double getCgst() {
		return cgst;
	}
	public void setCgst(Double cgst) {
		this.cgst = cgst;
	}
	public Double getSgstutgst() {
		return sgstutgst;
	}
	public void setSgstutgst(Double sgstutgst) {
		this.sgstutgst = sgstutgst;
	}
	public Double getCess() {
		return cess;
	}
	public void setCess(Double cess) {
		this.cess = cess;
	}
	public Double getItcigst() {
		return itcigst;
	}
	public void setItcigst(Double itcigst) {
		this.itcigst = itcigst;
	}
	public Double getItccgst() {
		return itccgst;
	}
	public void setItccgst(Double itccgst) {
		this.itccgst = itccgst;
	}
	public Double getItcsgstutgst() {
		return itcsgstutgst;
	}
	public void setItcsgstutgst(Double itcsgstutgst) {
		this.itcsgstutgst = itcsgstutgst;
	}
	public Double getItccess() {
		return itccess;
	}
	public void setItccess(Double itccess) {
		this.itccess = itccess;
	}*/
	public Double getTtlValue() {
		return ttlValue;
	}
	public void setTtlValue(Double ttlValue) {
		this.ttlValue = ttlValue;
	}
	public Double getTaxPd() {
		return taxPd;
	}
	public void setTaxPd(Double taxPd) {
		this.taxPd = taxPd;
	}
	public Double getItcAv() {
		return itcAv;
	}
	public void setItcAv(Double itcAv) {
		this.itcAv = itcAv;
	}
	public Double getCptTtlValue() {
		return cptTtlValue;
	}
	public void setCptTtlValue(Double cptTtlValue) {
		this.cptTtlValue = cptTtlValue;
	}
	public Double getCptTaxPd() {
		return cptTaxPd;
	}
	public void setCptTaxPd(Double cptTaxPd) {
		this.cptTaxPd = cptTaxPd;
	}
	public Double getCptItcAv() {
		return cptItcAv;
	}
	public void setCptItcAv(Double cptItcAv) {
		this.cptItcAv = cptItcAv;
	}
	public String getChecksum() {
		return checksum;
	}
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}
	
	
	


}
