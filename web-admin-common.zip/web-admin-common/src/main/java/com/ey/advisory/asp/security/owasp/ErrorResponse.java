package com.ey.advisory.asp.security.owasp;

public class ErrorResponse {
	
	private String fieldName;
	private String errordesc;
	
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getErrordesc() {
		return errordesc;
	}
	public void setErrordesc(String errordesc) {
		this.errordesc = errordesc;
	}
	

}
