package com.ey.advisory.asp.reports.jasper.processor;

import java.net.URL;

import org.apache.log4j.Logger;
import org.springframework.core.env.Environment;

import com.ey.advisory.asp.common.Constant;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;


public abstract class AbstractReportFiller implements JasperReportFiller {

	private static final Logger logger = Logger.getLogger(AbstractReportFiller.class);
	static ClassLoader classLoader = AbstractReportFiller.class.getClassLoader();

	@Override
	public String getJasperReportPath(JasperReportTypes type, Environment env) {

		try {
			ClassLoader classLoader = getClass().getClassLoader();
			URL jasperDir = classLoader.getResource(env.getProperty(Constant.JASPER_DIR));
			logger.info("getJasperReportPath jasperdir"+jasperDir);
			if (jasperDir != null) {
				URL reportBinaryPath = classLoader
						.getResource(env.getProperty(Constant.JASPER_DIR) + env.getProperty(type.toString()) + Constant.JASPER_DOTJASPER);
				logger.info("getJasperReportPath reportBinaryPath"+reportBinaryPath);
				if (reportBinaryPath != null) { // .jasper not exists
					return reportBinaryPath.getPath();
				} else {
					
					URL reportSourcePath = classLoader
							.getResource(env.getProperty(Constant.JASPER_DIR) + env.getProperty(type.toString()) + Constant.JASPER_JRXML);
					logger.info("else getJasperReportPath reportSourcePath"+reportSourcePath);
					if (reportSourcePath != null) { // .jrxml not exists
						JasperCompileManager.compileReportToFile(reportSourcePath.getPath(),
								jasperDir.getPath() + env.getProperty(type.toString()) + Constant.JASPER_DOTJASPER);
						reportBinaryPath = classLoader.getResource(
								env.getProperty(Constant.JASPER_DIR) + env.getProperty(type.toString()) + Constant.JASPER_DOTJASPER);
						logger.info("else getJasperReportPath reportBinaryPath"+reportBinaryPath);
						return reportBinaryPath.getPath();
					}
				}
			}
		} catch (JRException e) {
			logger.error("Exception occured in AbstractReportFiller.getJasperReportPath report :  " + e);
		} catch (Exception e){
			logger.error("Exception occured in AbstractReportFiller.getJasperReportPath report :  " + e);
		}

		return null;
	}

}
