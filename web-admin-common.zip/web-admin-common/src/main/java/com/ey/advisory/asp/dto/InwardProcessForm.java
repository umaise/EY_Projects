/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.util.List;
import java.util.Map;

/**
 * @author Uma.Chandranaik
 *
 */
public class InwardProcessForm {
	
	private List<Table4Form>  table4Form;
	private List<Table4Form>  table4AForm;
	private List<GSTR2CDNInvoiceDetails>  processCDNList;
	private List<GSTR2CDNAInvoiceDetails>  processCDNAList;
	
	private Map<String,List<Table4Form>> t4b2bMap;
	private Map<String,List<Table4Form>> t4Ab2bMap;
	private Map<String,List<GSTR2CDNInvoiceDetails>> cdnInvMap;
	private Map<Integer,List<GSTR2CDNAInvoiceDetails>> cdnaInvMap;
	private Map<String,List<Table4Form>> impgMap;
	private Map<String,List<Table4Form>> impgaMap;
	private GSTR2IMPGInvoiceDetails gstr2impgInvoiceDetails;
	private GSTR2IMPGAInvoiceDetails gstr2impgaInvoiceDetails;
	
	
	
	private List<GSTR2Nil> gstr2Nils;
	
	private Map<String,List<GSTR2ISD>> isdMap;
	
	private GSTR2ISD gstr2isd;
	
	private Map<String,List<GSTR2TDS>> tdsMap;
	
	private GSTR2TDS gstr2tds;
	
	private Map<String,List<GSTR2ITC>> itcMap;
	
	private GSTR2ITC gstr2itc;
	
	private List<GSTR2TCS> tcsDetails;
	
	private GSTR2TCS gstr2tcs;
	
	private List<Table4Form>  table6Form;
    private List<Table4Form>  table6AForm;

    private Map<String,List<Table4Form>> t6impsMap;
    private Map<String,List<Table4Form>> t6AimpsMap;
    
    private Map<String,List<Table4Form>> atMap;
    
    private GSTR2AT gstr2at;
    
    private Map<String, List<Table4Form>> ataMap;
    
    private GSTR2ATA gstr2ata;
    
    private List<GSTR2ITCRVSL> gstr2itcrvsls ;
    
    private GSTR2ITCRVSL gstr2itcrvsl;
    
    private Map<String, List<GSTR2TXPD>> txpdMap;
    
    private GSTR2TXPD gstr2txpd;
	
	public Map<String, List<Table4Form>> getT4b2bMap() {
		return t4b2bMap;
	}
	public void setT4b2bMap(Map<String, List<Table4Form>> t4b2bMap) {
		this.t4b2bMap = t4b2bMap;
	}
	
	
	public Map<String, List<Table4Form>> getT4Ab2bMap() {
		return t4Ab2bMap;
	}
	public void setT4Ab2bMap(Map<String, List<Table4Form>> t4Ab2bMap) {
		this.t4Ab2bMap = t4Ab2bMap;
	}
	
	
	public Map<String, List<GSTR2CDNInvoiceDetails>> getCdnInvMap() {
		return cdnInvMap;
	}
	public void setCdnInvMap(Map<String, List<GSTR2CDNInvoiceDetails>> cdnInvMap) {
		this.cdnInvMap = cdnInvMap;
	}
	
	
	public Map<Integer, List<GSTR2CDNAInvoiceDetails>> getCdnaInvMap() {
		return cdnaInvMap;
	}
	public void setCdnaInvMap(Map<Integer, List<GSTR2CDNAInvoiceDetails>> cdnaInvMap) {
		this.cdnaInvMap = cdnaInvMap;
	}
	public List<Table4Form> getTable4Form() {
		return table4Form;
	}
	public void setTable4Form(List<Table4Form> table4Form) {
		this.table4Form = table4Form;
	}
	
	
	
	public List<Table4Form> getTable4AForm() {
		return table4AForm;
	}
	public void setTable4AForm(List<Table4Form> table4aForm) {
		table4AForm = table4aForm;
	}
	public List<GSTR2CDNInvoiceDetails> getProcessCDNList() {
		return processCDNList;
	}
	public void setProcessCDNList(List<GSTR2CDNInvoiceDetails> processCDNList) {
		this.processCDNList = processCDNList;
	}
	public List<GSTR2CDNAInvoiceDetails> getProcessCDNAList() {
		return processCDNAList;
	}
	public void setProcessCDNAList(List<GSTR2CDNAInvoiceDetails> processCDNAList) {
		this.processCDNAList = processCDNAList;
	}
	public Map<String, List<Table4Form>> getImpgMap() {
		return impgMap;
	}
	public void setImpgMap(Map<String, List<Table4Form>> impgMap) {
		this.impgMap = impgMap;
	}
	public GSTR2IMPGInvoiceDetails getGstr2impgInvoiceDetails() {
		return gstr2impgInvoiceDetails;
	}
	public void setGstr2impgInvoiceDetails(GSTR2IMPGInvoiceDetails gstr2impgInvoiceDetails) {
		this.gstr2impgInvoiceDetails = gstr2impgInvoiceDetails;
	}
	public GSTR2IMPGAInvoiceDetails getGstr2impgaInvoiceDetails() {
		return gstr2impgaInvoiceDetails;
	}
	public void setGstr2impgaInvoiceDetails(GSTR2IMPGAInvoiceDetails gstr2impgaInvoiceDetails) {
		this.gstr2impgaInvoiceDetails = gstr2impgaInvoiceDetails;
	}
	public Map<String, List<Table4Form>> getImpgaMap() {
		return impgaMap;
	}
	public void setImpgaMap(Map<String, List<Table4Form>> impgaMap) {
		this.impgaMap = impgaMap;
	}
	public List<GSTR2Nil> getGstr2Nils() {
		return gstr2Nils;
	}
	public void setGstr2Nils(List<GSTR2Nil> gstr2Nils) {
		this.gstr2Nils = gstr2Nils;
	}
	public Map<String, List<GSTR2ISD>> getIsdMap() {
		return isdMap;
	}
	public void setIsdMap(Map<String, List<GSTR2ISD>> isdMap) {
		this.isdMap = isdMap;
	}
	public GSTR2ISD getGstr2isd() {
		return gstr2isd;
	}
	public void setGstr2isd(GSTR2ISD gstr2isd) {
		this.gstr2isd = gstr2isd;
	}
	public Map<String, List<GSTR2TDS>> getTdsMap() {
		return tdsMap;
	}
	public void setTdsMap(Map<String, List<GSTR2TDS>> tdsMap) {
		this.tdsMap = tdsMap;
	}
	public GSTR2TDS getGstr2tds() {
		return gstr2tds;
	}
	public void setGstr2tds(GSTR2TDS gstr2tds) {
		this.gstr2tds = gstr2tds;
	}
	public Map<String, List<GSTR2ITC>> getItcMap() {
		return itcMap;
	}
	public void setItcMap(Map<String, List<GSTR2ITC>> itcMap) {
		this.itcMap = itcMap;
	}
	public GSTR2ITC getGstr2itc() {
		return gstr2itc;
	}
	public void setGstr2itc(GSTR2ITC gstr2itc) {
		this.gstr2itc = gstr2itc;
	}
	public List<GSTR2TCS> getTcsDetails() {
		return tcsDetails;
	}
	public void setTcsDetails(List<GSTR2TCS> tcsDetails) {
		this.tcsDetails = tcsDetails;
	}
	public GSTR2TCS getGstr2tcs() {
		return gstr2tcs;
	}
	public void setGstr2tcs(GSTR2TCS gstr2tcs) {
		this.gstr2tcs = gstr2tcs;
	}
	public List<Table4Form> getTable6Form() {
		return table6Form;
	}
	public void setTable6Form(List<Table4Form> table6Form) {
		this.table6Form = table6Form;
	}
	public List<Table4Form> getTable6AForm() {
		return table6AForm;
	}
	public void setTable6AForm(List<Table4Form> table6aForm) {
		table6AForm = table6aForm;
	}
	public Map<String, List<Table4Form>> getT6impsMap() {
		return t6impsMap;
	}
	public void setT6impsMap(Map<String, List<Table4Form>> t6impsMap) {
		this.t6impsMap = t6impsMap;
	}
	public Map<String, List<Table4Form>> getT6AimpsMap() {
		return t6AimpsMap;
	}
	public void setT6AimpsMap(Map<String, List<Table4Form>> t6AimpsMap) {
		this.t6AimpsMap = t6AimpsMap;
	}
	
	public GSTR2AT getGstr2at() {
		return gstr2at;
	}
	public void setGstr2at(GSTR2AT gstr2at) {
		this.gstr2at = gstr2at;
	}
	public Map<String, List<Table4Form>> getAtMap() {
		return atMap;
	}
	public void setAtMap(Map<String, List<Table4Form>> atMap) {
		this.atMap = atMap;
	}
	public Map<String, List<Table4Form>> getAtaMap() {
		return ataMap;
	}
	public void setAtaMap(Map<String, List<Table4Form>> ataMap) {
		this.ataMap = ataMap;
	}
	public GSTR2ATA getGstr2ata() {
		return gstr2ata;
	}
	public void setGstr2ata(GSTR2ATA gstr2ata) {
		this.gstr2ata = gstr2ata;
	}
	public List<GSTR2ITCRVSL> getGstr2itcrvsls() {
		return gstr2itcrvsls;
	}
	public void setGstr2itcrvsls(List<GSTR2ITCRVSL> gstr2itcrvsls) {
		this.gstr2itcrvsls = gstr2itcrvsls;
	}
	public GSTR2ITCRVSL getGstr2itcrvsl() {
		return gstr2itcrvsl;
	}
	public void setGstr2itcrvsl(GSTR2ITCRVSL gstr2itcrvsl) {
		this.gstr2itcrvsl = gstr2itcrvsl;
	}
	public Map<String, List<GSTR2TXPD>> getTxpdMap() {
		return txpdMap;
	}
	public void setTxpdMap(Map<String, List<GSTR2TXPD>> txpdMap) {
		this.txpdMap = txpdMap;
	}
	public GSTR2TXPD getGstr2txpd() {
		return gstr2txpd;
	}
	public void setGstr2txpd(GSTR2TXPD gstr2txpd) {
		this.gstr2txpd = gstr2txpd;
	}
	

	
	
}
