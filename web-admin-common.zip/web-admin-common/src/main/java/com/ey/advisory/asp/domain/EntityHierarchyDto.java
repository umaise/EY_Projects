package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonFormat;


public class EntityHierarchyDto implements Serializable,Cloneable{

	private static final Logger LOGGER = Logger.getLogger(EntityHierarchyDto.class);
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	@Digits(fraction = 0, integer =20)
	private Integer hierarchyId;
	@Digits(fraction = 0, integer =20)
	private Integer groupID;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String groupCode;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String groupName;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String circleCode;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String circleName;
	@Digits(fraction = 0, integer =20)
	private Integer entityID;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String entityCode;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String entityName;
	@Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	private String gSTIN;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String subDivCode;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String subDivName;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String profitCenterCode;
	@Pattern(regexp = "^[a-zA-Z]*$")
    private String profitCenterName;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
    private String businessUnitCode;
    @Pattern(regexp = "^[a-zA-Z]*$")
    private String businessUnitName;
    @Pattern(regexp = "^[A-Za-z0-9]*$")
    private String plantCode;
    @Pattern(regexp = "^[a-zA-Z]*$")
    private String isActive;
    @Pattern(regexp = "^[a-zA-Z]*$")
    private String createdBy;
	
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss")
    private Date createdDate;
    @Pattern(regexp = "^[a-zA-Z]*$")
    private String updatedBy;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss")
    private Date updatedDate;
    
    private String updateDateFormatted;
    
    private String accessLevel;
	
	public String getAccessLevel() {
		return accessLevel;
	}
	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}
	
	private Integer accessLevelId;
	
	public Integer getAccessLevelId() {
		return accessLevelId;
	}
	public void setAccessLevelId(Integer accessLevelId) {
		this.accessLevelId = accessLevelId;
	}

	
	/**
	 * @return the hierarchyId
	 */
	public Integer getHierarchyId() {
		return hierarchyId;
	}
	/**
	 * @return the goupID
	 */
	public Integer getGroupID() {
		return groupID;
	}
	/**
	 * @return the groupCode
	 */
	public String getGroupCode() {
		return groupCode;
	}
	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}
	/**
	 * @return the circleCode
	 */
	public String getCircleCode() {
		return circleCode;
	}
	/**
	 * @return the circleName
	 */
	public String getCircleName() {
		return circleName;
	}
	/**
	 * @return the entityID
	 */
	public Integer getEntityID() {
		return entityID;
	}
	/**
	 * @return the entityCode
	 */
	public String getEntityCode() {
		return entityCode;
	}
	/**
	 * @return the etityName
	 */
	public String getEntityName() {
		return entityName;
	}
	/**
	 * @return the gSTIN
	 */
	public String getgSTIN() {
		return gSTIN;
	}
	/**
	 * @return the subDivCode
	 */
	public String getSubDivCode() {
		return subDivCode;
	}
	/**
	 * @return the subDivName
	 */
	public String getSubDivName() {
		return subDivName;
	}
	/**
	 * @return the profitCenterCode
	 */
	public String getProfitCenterCode() {
		return profitCenterCode;
	}
	/**
	 * @return the profitCenterName
	 */
	public String getProfitCenterName() {
		return profitCenterName;
	}
	/**
	 * @return the businessUnitCode
	 */
	public String getBusinessUnitCode() {
		return businessUnitCode;
	}
	/**
	 * @return the businessUnitName
	 */
	public String getBusinessUnitName() {
		return businessUnitName;
	}
	/**
	 * @return the plantCode
	 */
	public String getPlantCode() {
		return plantCode;
	}
	/**
	 * @return the isActive
	 */
	public String getIsActive() {
		return isActive;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}
	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}
	/**
	 * @param hierarchyId the hierarchyId to set
	 */
	public void setHierarchyId(Integer hierarchyId) {
		this.hierarchyId = hierarchyId;
	}
	/**
	 * @param goupID the goupID to set
	 */
	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}
	/**
	 * @param groupCode the groupCode to set
	 */
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	/**
	 * @param circleCode the circleCode to set
	 */
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	/**
	 * @param circleName the circleName to set
	 */
	public void setCircleName(String circleName) {
		this.circleName = circleName;
	}
	/**
	 * @param entityID the entityID to set
	 */
	public void setEntityID(Integer entityID) {
		this.entityID = entityID;
	}
	/**
	 * @param entityCode the entityCode to set
	 */
	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}
	/**
	 * @param etityName the etityName to set
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	/**
	 * @param gSTIN the gSTIN to set
	 */
	public void setgSTIN(String gSTIN) {
		this.gSTIN = gSTIN;
	}
	/**
	 * @param subDivCode the subDivCode to set
	 */
	public void setSubDivCode(String subDivCode) {
		this.subDivCode = subDivCode;
	}
	/**
	 * @param subDivName the subDivName to set
	 */
	public void setSubDivName(String subDivName) {
		this.subDivName = subDivName;
	}
	/**
	 * @param profitCenterCode the profitCenterCode to set
	 */
	public void setProfitCenterCode(String profitCenterCode) {
		this.profitCenterCode = profitCenterCode;
	}
	/**
	 * @param profitCenterName the profitCenterName to set
	 */
	public void setProfitCenterName(String profitCenterName) {
		this.profitCenterName = profitCenterName;
	}
	/**
	 * @param businessUnitCode the businessUnitCode to set
	 */
	public void setBusinessUnitCode(String businessUnitCode) {
		this.businessUnitCode = businessUnitCode;
	}
	/**
	 * @param businessUnitName the businessUnitName to set
	 */
	public void setBusinessUnitName(String businessUnitName) {
		this.businessUnitName = businessUnitName;
	}
	/**
	 * @param plantCode the plantCode to set
	 */
	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((businessUnitCode == null) ? 0 : businessUnitCode.hashCode());
		result = prime * result + ((businessUnitName == null) ? 0 : businessUnitName.hashCode());
		result = prime * result + ((circleCode == null) ? 0 : circleCode.hashCode());
		result = prime * result + ((circleName == null) ? 0 : circleName.hashCode());
		result = prime * result + ((entityCode == null) ? 0 : entityCode.hashCode());
		result = prime * result + ((entityID == null) ? 0 : entityID.hashCode());
		result = prime * result + ((entityName == null) ? 0 : entityName.hashCode());
		result = prime * result + ((gSTIN == null) ? 0 : gSTIN.hashCode());
		result = prime * result + ((groupID == null) ? 0 : groupID.hashCode());
		result = prime * result + ((groupCode == null) ? 0 : groupCode.hashCode());
		result = prime * result + ((groupName == null) ? 0 : groupName.hashCode());
		result = prime * result + ((hierarchyId == null) ? 0 : hierarchyId.hashCode());
		result = prime * result + ((plantCode == null) ? 0 : plantCode.hashCode());
		result = prime * result + ((profitCenterCode == null) ? 0 : profitCenterCode.hashCode());
		result = prime * result + ((profitCenterName == null) ? 0 : profitCenterName.hashCode());
		result = prime * result + ((subDivCode == null) ? 0 : subDivCode.hashCode());
		result = prime * result + ((subDivName == null) ? 0 : subDivName.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EntityHierarchyDto other = (EntityHierarchyDto) obj;
		if (businessUnitCode == null) {
			if (other.businessUnitCode != null)
				return false;
		} else if (!businessUnitCode.equals(other.businessUnitCode))
			return false;
		if (businessUnitName == null) {
			if (other.businessUnitName != null)
				return false;
		} else if (!businessUnitName.equals(other.businessUnitName))
			return false;
		if (circleCode == null) {
			if (other.circleCode != null)
				return false;
		} else if (!circleCode.equals(other.circleCode))
			return false;
		if (circleName == null) {
			if (other.circleName != null)
				return false;
		} else if (!circleName.equals(other.circleName))
			return false;
		if (entityCode == null) {
			if (other.entityCode != null)
				return false;
		} else if (!entityCode.equals(other.entityCode))
			return false;
		if (entityID == null) {
			if (other.entityID != null)
				return false;
		} else if (!entityID.equals(other.entityID))
			return false;
		if (entityName == null) {
			if (other.entityName != null)
				return false;
		} else if (!entityName.equals(other.entityName))
			return false;
		if (gSTIN == null) {
			if (other.gSTIN != null)
				return false;
		} else if (!gSTIN.equals(other.gSTIN))
			return false;
		if (groupID == null) {
			if (other.groupID != null)
				return false;
		} else if (!groupID.equals(other.groupID))
			return false;
		if (groupCode == null) {
			if (other.groupCode != null)
				return false;
		} else if (!groupCode.equals(other.groupCode))
			return false;
		if (groupName == null) {
			if (other.groupName != null)
				return false;
		} else if (!groupName.equals(other.groupName))
			return false;
		if (hierarchyId == null) {
			if (other.hierarchyId != null)
				return false;
		} else if (!hierarchyId.equals(other.hierarchyId))
			return false;
		if (plantCode == null) {
			if (other.plantCode != null)
				return false;
		} else if (!plantCode.equals(other.plantCode))
			return false;
		if (profitCenterCode == null) {
			if (other.profitCenterCode != null)
				return false;
		} else if (!profitCenterCode.equals(other.profitCenterCode))
			return false;
		if (profitCenterName == null) {
			if (other.profitCenterName != null)
				return false;
		} else if (!profitCenterName.equals(other.profitCenterName))
			return false;
		if (subDivCode == null) {
			if (other.subDivCode != null)
				return false;
		} else if (!subDivCode.equals(other.subDivCode))
			return false;
		if (subDivName == null) {
			if (other.subDivName != null)
				return false;
		} else if (!subDivName.equals(other.subDivName))
			return false;
		return true;
	}
    
	@Override
	public Object clone() {
		//shallow copy
		try {
		  return super.clone();
		} catch (CloneNotSupportedException e) {
			LOGGER.error(e);
		  return null;
		}
	  }
	public String getUpdateDateFormatted() {
		return updateDateFormatted;
	}
	public void setUpdateDateFormatted(String updateDateFormatted) {
		this.updateDateFormatted = updateDateFormatted;
	}
	
	
	
}
