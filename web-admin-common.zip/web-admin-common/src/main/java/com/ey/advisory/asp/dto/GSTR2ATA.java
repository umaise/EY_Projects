/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.sql.Date;
import java.util.List;

/**
 * @author Uma.Chandranaik
 *
 */

public class GSTR2ATA {
	
	
	private Long id;
	

	private Character flag;
	

	private String chkSum;
	
	
	private String oGSTIN;
	
	
	private String orgRecpName;
	
	private String orgSuppDocNo;
	
	private Date orgSuppDate;
	
	private String rtin;
	
	private String custName;
	
	private String stateCode;
	
	private String docNum;
	
	private Date docDate;
	
	private Long taxPayerId;
	
	private Float taxableVal;
	
	private int invoiceCnt;
	
	private Float igstTotal;
	
	private Float cgstTotal;

	private Float sgstTotal;
	
	private List<GSTR2ATAItems> ataItems;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Character getFlag() {
		return flag;
	}

	public void setFlag(Character flag) {
		this.flag = flag;
	}

	public String getChkSum() {
		return chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getOGSTIN() {
		return oGSTIN;
	}

	public void setOGSTIN(String oGSTIN) {
		this.oGSTIN = oGSTIN;
	}


	public String getOrgSuppDocNo() {
		return orgSuppDocNo;
	}

	public void setOrgSuppDocNo(String orgSuppDocNo) {
		this.orgSuppDocNo = orgSuppDocNo;
	}

	public Date getOrgSuppDate() {
		return orgSuppDate;
	}

	public void setOrgSuppDate(Date orgSuppDate) {
		this.orgSuppDate = orgSuppDate;
	}

	public String getRtin() {
		return rtin;
	}

	public void setRtin(String rtin) {
		this.rtin = rtin;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getDocNum() {
		return docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	public Date getDocDate() {
		return docDate;
	}

	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}

	public Long getTaxPayerId() {
		return taxPayerId;
	}

	public void setTaxPayerId(Long taxPayerId) {
		this.taxPayerId = taxPayerId;
	}

	public Float getTaxableVal() {
		return taxableVal;
	}

	public void setTaxableVal(Float taxableVal) {
		this.taxableVal = taxableVal;
	}


	public String getOrgRecpName() {
		return orgRecpName;
	}

	public void setOrgRecpName(String orgRecpName) {
		this.orgRecpName = orgRecpName;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}

	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}

	public Float getCgstTotal() {
		return cgstTotal;
	}

	public void setCgstTotal(Float cgstTotal) {
		this.cgstTotal = cgstTotal;
	}

	public Float getSgstTotal() {
		return sgstTotal;
	}

	public void setSgstTotal(Float sgstTotal) {
		this.sgstTotal = sgstTotal;
	}

	public List<GSTR2ATAItems> getAtaItems() {
		return ataItems;
	}

	public void setAtaItems(List<GSTR2ATAItems> ataItems) {
		this.ataItems = ataItems;
	}
	
	
	

}
