/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.io.Serializable;

/**
 * @author Uma.Chandranaik
 *
 */

public class GSTR2IMPGItemDetails implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int lineNo;
	
	private String hsnSC;
	
	private Float itemTxval;

	private Float igstRt;
	
	private Float igstAmt;
	
	private String itcEligiblity;
	
	private Float itcIGSTAmt;
	
	private Float tcIGSTAmt;
	
	private Long invoiceDetailId;
	
	private Float taxableValue;

	public int getLineNo() {
		return lineNo;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}

	public String getHsnSC() {
		return hsnSC;
	}

	public void setHsnSC(String hsnSC) {
		this.hsnSC = hsnSC;
	}

	public Float getItemTxval() {
		return itemTxval;
	}

	public void setItemTxval(Float itemTxval) {
		this.itemTxval = itemTxval;
	}

	public Float getIgstRt() {
		return igstRt;
	}

	public void setIgstRt(Float igstRt) {
		this.igstRt = igstRt;
	}

	public Float getIgstAmt() {
		return igstAmt;
	}

	public void setIgstAmt(Float igstAmt) {
		this.igstAmt = igstAmt;
	}

	public String getItcEligiblity() {
		return itcEligiblity;
	}

	public void setItcEligiblity(String itcEligiblity) {
		this.itcEligiblity = itcEligiblity;
	}

	public Float getItcIGSTAmt() {
		return itcIGSTAmt;
	}

	public void setItcIGSTAmt(Float itcIGSTAmt) {
		this.itcIGSTAmt = itcIGSTAmt;
	}

	public Float getTcIGSTAmt() {
		return tcIGSTAmt;
	}

	public void setTcIGSTAmt(Float tcIGSTAmt) {
		this.tcIGSTAmt = tcIGSTAmt;
	}

	public Long getInvoiceDetailId() {
		return invoiceDetailId;
	}

	public void setInvoiceDetailId(Long invoiceDetailId) {
		this.invoiceDetailId = invoiceDetailId;
	}

	public Float getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(Float taxableValue) {
		this.taxableValue = taxableValue;
	}
	
	
	

}
