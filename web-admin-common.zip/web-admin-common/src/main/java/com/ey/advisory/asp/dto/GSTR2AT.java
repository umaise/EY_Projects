package com.ey.advisory.asp.dto;

import java.sql.Date;
import java.util.List;


public class GSTR2AT {
	
	
	private Long id;
	

	private String rtin;
	
	
	private String suppName;
	
	
	private String stcd;
	
	
	private String docNum;
	

	private Date docDate;
	

	private Long taxPayerId;
	
	
	private Float txValue;
	
	private int invoiceCnt;
	
	
	private Float igstTotal;
	
	
	private Float cgstTotal;

	
	private Float sgstTotal;

	private  List<GSTR2ATItem> atItemDetails;
	
	/**
	 * @return the rtin
	 */
	public String getRtin() {
		return rtin;
	}

	/**
	 * @param rtin the rtin to set
	 */
	public void setRtin(String rtin) {
		this.rtin = rtin;
	}

	/**
	 * @return the suppName
	 */
	public String getSuppName() {
		return suppName;
	}

	/**
	 * @param suppName the suppName to set
	 */
	public void setSuppName(String suppName) {
		this.suppName = suppName;
	}

	/**
	 * @return the stcd
	 */
	public String getStcd() {
		return stcd;
	}

	/**
	 * @param stcd the stcd to set
	 */
	public void setStcd(String stcd) {
		this.stcd = stcd;
	}

	/**
	 * @return the docNum
	 */
	public String getDocNum() {
		return docNum;
	}

	/**
	 * @param docNum the docNum to set
	 */
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	/**
	 * @return the docDate
	 */
	public Date getDocDate() {
		return docDate;
	}

	/**
	 * @param docDate the docDate to set
	 */
	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}

	

	/**
	 * @return the txValue
	 */
	public Float getTxValue() {
		return txValue;
	}

	/**
	 * @param txValue the txValue to set
	 */
	public void setTxValue(Float txValue) {
		this.txValue = txValue;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTaxPayerId() {
		return taxPayerId;
	}

	public void setTaxPayerId(Long taxPayerId) {
		this.taxPayerId = taxPayerId;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}

	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}

	public Float getCgstTotal() {
		return cgstTotal;
	}

	public void setCgstTotal(Float cgstTotal) {
		this.cgstTotal = cgstTotal;
	}

	public Float getSgstTotal() {
		return sgstTotal;
	}

	public void setSgstTotal(Float sgstTotal) {
		this.sgstTotal = sgstTotal;
	}

	public List<GSTR2ATItem> getAtItemDetails() {
		return atItemDetails;
	}

	public void setAtItemDetails(List<GSTR2ATItem> atItemDetails) {
		this.atItemDetails = atItemDetails;
	}
	
	
}
