package com.ey.advisory.asp.dto;

import java.util.Set;

public class CounterPartydetailsDto {
	
	Set<String> gstins;
	Set<String> names;
	public Set<String> getGstins() {
		return gstins;
	}
	public void setGstins(Set<String> gstins) {
		this.gstins = gstins;
	}
	public Set<String> getNames() {
		return names;
	}
	public void setNames(Set<String> names) {
		this.names = names;
	}

}
