package com.ey.advisory.asp.dto;


public class StateCodeMasterDTO {
	int serialNumber; 
	String stateName;
	String firstTwoDigitsOfGSTIN;
	String stateCode;

	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getFirstTwoDigitsOfGSTIN() {
		return firstTwoDigitsOfGSTIN;
	}
	public void setFirstTwoDigitsOfGSTIN(String firstTwoDigitsOfGSTIN) {
		this.firstTwoDigitsOfGSTIN = firstTwoDigitsOfGSTIN;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	
}
