package com.ey.advisory.asp.dashboard.sub;


import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;

public class RedisProcessedSubscriber implements MessageListener {
	
	SimpMessagingTemplate  template; 		
	
	@Override
    public void onMessage(final Message message, final byte[] pattern) {
        try{
        	JSONParser parser = new JSONParser();
        	JSONObject json = (JSONObject) parser.parse(new String(message.getBody()));
        	this.template.convertAndSend("/topic/stats",json);
        }catch(Exception e){
        	System.err.println("Error while converting the recieved message RedisProcessedSubscriber "+e);
        }
    }
	
	public void setTemplate(SimpMessagingTemplate template) {
		this.template = template;
	}

}