package com.ey.advisory.asp.dto;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

public class UserSearchDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String userName;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String firstName;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String lastName;
	@Pattern(regexp = "^[a-zA-Z 0-9]*$")
	private String group;
	@Digits(fraction = 0, integer =3)
	private Integer rows;
	@Digits(fraction = 0, integer =20)
	private Integer page;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public Integer getRows() {
		return rows;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	
	
}
