package com.ey.advisory.asp.dto;


public class GSTR2TCS{
	
	
	private Long id;
	

	private String custGSTIN;
	
	private Character flag;
	
	private String checksum;
	
	private String merchantId;
		
	private Float supplyVal;
	
	private Float taxVal;

	private Float igstRt;

	private Float igstAmt;

	private Float cgstRt;

	private Float cgstAmt;

	private Float sgstRt;

	private Float sgstAmt;
	
	private Float taxableValue;
	
	private Long taxPayerId;
	
	private int invoiceCnt;
	
	private Float igstTotal;
	
	private Float cgstTotal;

	private Float sgstTotal;
	
	
	public String getCustGSTIN() {
		return custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public Character getFlag() {
		return flag;
	}

	public void setFlag(Character flag) {
		this.flag = flag;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public Float getSupplyVal() {
		return supplyVal;
	}

	public void setSupplyVal(Float supplyVal) {
		this.supplyVal = supplyVal;
	}

	public Float getTaxVal() {
		return taxVal;
	}

	public void setTaxVal(Float taxVal) {
		this.taxVal = taxVal;
	}

	public Float getIgstRt() {
		return igstRt;
	}

	public void setIgstRt(Float igstRt) {
		this.igstRt = igstRt;
	}

	public Float getIgstAmt() {
		return igstAmt;
	}

	public void setIgstAmt(Float igstAmt) {
		this.igstAmt = igstAmt;
	}

	public Float getCgstRt() {
		return cgstRt;
	}

	public void setCgstRt(Float cgstRt) {
		this.cgstRt = cgstRt;
	}

	public Float getCgstAmt() {
		return cgstAmt;
	}

	public void setCgstAmt(Float cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	public Float getSgstRt() {
		return sgstRt;
	}

	public void setSgstRt(Float sgstRt) {
		this.sgstRt = sgstRt;
	}

	public Float getSgstAmt() {
		return sgstAmt;
	}

	public void setSgstAmt(Float sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	public Float getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(Float taxableValue) {
		this.taxableValue = taxableValue;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTaxPayerId() {
		return taxPayerId;
	}

	public void setTaxPayerId(Long taxPayerId) {
		this.taxPayerId = taxPayerId;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}

	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}

	public Float getCgstTotal() {
		return cgstTotal;
	}

	public void setCgstTotal(Float cgstTotal) {
		this.cgstTotal = cgstTotal;
	}

	public Float getSgstTotal() {
		return sgstTotal;
	}

	public void setSgstTotal(Float sgstTotal) {
		this.sgstTotal = sgstTotal;
	}


	
	
	

}
