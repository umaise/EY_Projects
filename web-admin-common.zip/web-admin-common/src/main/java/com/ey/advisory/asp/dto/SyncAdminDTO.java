package com.ey.advisory.asp.dto;

import java.util.Map;

public class SyncAdminDTO {

	private String inputString;
	
	private Map<String,String> inputMap;

	public String getInputString() {
		return inputString;
	}

	public void setInputString(String inputString) {
		this.inputString = inputString;
	}

	public Map<String, String> getInputMap() {
		return inputMap;
	}

	public void setInputMap(Map<String, String> inputMap) {
		this.inputMap = inputMap;
	}
	
}
