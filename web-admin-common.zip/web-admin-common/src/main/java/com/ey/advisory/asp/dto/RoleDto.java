package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

public class RoleDto implements Serializable {

	@Digits(fraction = 0, integer =10)
	private Long roleID;
	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String roleName;
	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String roleDescription;
	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String roleType;
	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String defaultRole;
	@Digits(fraction = 0, integer =10)
	private Long parentId;
	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String category;
	
	private List<FunctionDto> function;
	
	public Long getRoleID() {
		return roleID;
	}
	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getRoleDescription() {
		return roleDescription;
	}
	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}
	public List<FunctionDto> getFunction() {
		return function;
	}
	public void setFunction(List<FunctionDto> function) {
		this.function = function;
	}
	/**
	 * @return the roleType
	 */
	public String getRoleType() {
		return roleType;
	}
	/**
	 * @param roleType the roleType to set
	 */
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
	public String getDefaultRole() {
		return defaultRole;
	}
	public void setDefaultRole(String defaultRole) {
		this.defaultRole = defaultRole;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
}
