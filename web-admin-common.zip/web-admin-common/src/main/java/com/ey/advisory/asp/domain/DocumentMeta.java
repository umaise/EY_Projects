package com.ey.advisory.asp.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import java.sql.Timestamp;
import java.util.List;

public class DocumentMeta {

    String id;
    @JsonProperty("is_agreement")
    Boolean isAgreement;
    @JsonProperty("agreement_type")
    AgreementType agreementType; // inbound, outbound
    
    @JsonProperty("agreement_status")
    AgreementStatus agreementStatus; // Pending, Completed
    
    
    @JsonProperty("file_name")
    String fileName;
    Timestamp updatedAt;
    
    private String createdAtSt;
    
 
    Timestamp createdAt; //Upload time
    
    
    @JsonProperty("self_signed")
    Boolean selfSigned = false;
    
    
    @JsonProperty("no_of_pages")
    int noOfPages;
    @JsonProperty("signing_parties")
    List<SigningPartyDetails> signingParties;
    @JsonProperty("sign_request_details")
    RequestDetails signRequestDetails;

    //
    String code;
    String message;
    String details;

    //
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Boolean getAgreement() {
        return isAgreement;
    }

    public void setAgreement(Boolean agreement) {
        isAgreement = agreement;
    }

    public AgreementType getAgreementType() {
        return agreementType;
    }

    public void setAgreementType(AgreementType agreementType) {
        this.agreementType = agreementType;
    }

    public AgreementStatus getAgreementStatus() {
        return agreementStatus;
    }

    public void setAgreementStatus(AgreementStatus agreementStatus) {
        this.agreementStatus = agreementStatus;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getSelfSigned() {
        return selfSigned;
    }

    public void setSelfSigned(Boolean selfSigned) {
        this.selfSigned = selfSigned;
    }

    public int getNoOfPages() {
        return noOfPages;
    }

    public void setNoOfPages(int noOfPages) {
        this.noOfPages = noOfPages;
    }

    public List<SigningPartyDetails> getSigningParties() {
        return signingParties;
    }

    public void setSigningParties(List<SigningPartyDetails> signingParties) {
        this.signingParties = signingParties;
    }

    public RequestDetails getSignRequestDetails() {
        return signRequestDetails;
    }

    public void setSignRequestDetails(RequestDetails signRequestDetails) {
        this.signRequestDetails = signRequestDetails;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getCreatedAtSt() {
		return createdAtSt;
	}

	public void setCreatedAtSt(String createdAtSt) {
		this.createdAtSt = createdAtSt;
	}

	public static class SigningPartyDetails {
        String name;
        String email;
        String status;
        SigningPartyType type;
        Timestamp updatedAt;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public SigningPartyType getType() {
            return type;
        }

        public void setType(SigningPartyType type) {
            this.type = type;
        }

        public Timestamp getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(Timestamp updatedAt) {
            this.updatedAt = updatedAt;
        }
    }

    public static enum SigningPartyType {
        SELF,
        ORG,
        SIGNATORY;

        @Override
        @JsonValue
        public String toString() {
            return this.name().toLowerCase();
        }
        @JsonCreator
        public static SigningPartyType valueOfIgnoreCase(String value) {
            return SigningPartyType.valueOf(value.toUpperCase());
        }
    };

    public static class RequestDetails {
        String name;
        String email;
        
        Timestamp requestedOn;
        
        Timestamp expireOn;

        
        private String requestedOnSt;
        private String expireOnSt;
        
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public Timestamp getRequestedOn() {
            return requestedOn;
        }

        public void setRequestedOn(Timestamp requestedOn) {
            this.requestedOn = requestedOn;
        }

        public Timestamp getExpireOn() {
            return expireOn;
        }

        public void setExpireOn(Timestamp expireOn) {
            this.expireOn = expireOn;
        }

		public String getExpireOnSt() {
			return expireOnSt;
		}

		public void setExpireOnSt(String expireOnSt) {
			this.expireOnSt = expireOnSt;
		}

		public String getRequestedOnSt() {
			return requestedOnSt;
		}

		public void setRequestedOnSt(String requestedOnSt) {
			this.requestedOnSt = requestedOnSt;
		}
    }

    public static enum  AgreementType {
        INBOUND,
        OUTBOUND;

        @Override
        @JsonValue
        public String toString() {
            return this.name().toLowerCase();
        }

        @JsonCreator
        public static AgreementType valueOfIgnoreCase(String value) {
            return AgreementType.valueOf(value.toUpperCase());
        }
    }

    public enum  AgreementStatus {

        DRAFT,
        REQUESTED,
        COMPLETED,
        EXPIRED;

        @Override
        @JsonValue
        public String toString() {
            return this.name().toLowerCase();
        }

        @JsonCreator
        public static AgreementStatus valueOfIgnoreCase(String value) {
            return AgreementStatus.valueOf(value.toUpperCase());
        }

    }
}
