package com.ey.advisory.asp.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;



public class ReturnSubmissionStatus {
	
	private BigInteger returnSubmissionStatusUID;
	private String gstin ;
	private String rtPeriod;
	private String debitNum ;
	private Date createdOn ;
	private boolean ledgerFlag;
	private String description;
	private BigDecimal payable;
	private BigDecimal igst;
	private BigDecimal cgst;
	private BigDecimal sgst;
	private BigDecimal cess;
	private BigDecimal utgst;
	
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getRtPeriod() {
		return rtPeriod;
	}
	public void setRtPeriod(String rtPeriod) {
		this.rtPeriod = rtPeriod;
	}
	public String getDebitNum() {
		return debitNum;
	}
	public void setDebitNum(String debitNum) {
		this.debitNum = debitNum;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public boolean isLedgerFlag() {
		return ledgerFlag;
	}
	public void setLedgerFlag(boolean ledgerFlag) {
		this.ledgerFlag = ledgerFlag;
	}
	public BigInteger getReturnSubmissionStatusUID() {
		return returnSubmissionStatusUID;
	}
	public void setReturnSubmissionStatusUID(BigInteger returnSubmissionStatusUID) {
		this.returnSubmissionStatusUID = returnSubmissionStatusUID;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public BigDecimal getPayable() {
		return payable;
	}
	public void setPayable(BigDecimal payable) {
		this.payable = payable;
	}
	public BigDecimal getIgst() {
		return igst;
	}
	public void setIgst(BigDecimal igst) {
		this.igst = igst;
	}
	public BigDecimal getCgst() {
		return cgst;
	}
	public void setCgst(BigDecimal cgst) {
		this.cgst = cgst;
	}
	public BigDecimal getSgst() {
		return sgst;
	}
	public void setSgst(BigDecimal sgst) {
		this.sgst = sgst;
	}
	public BigDecimal getCess() {
		return cess;
	}
	public void setCess(BigDecimal cess) {
		this.cess = cess;
	}
	public BigDecimal getUtgst() {
		return utgst;
	}
	public void setUtgst(BigDecimal utgst) {
		this.utgst = utgst;
	}
	
	
	

}
