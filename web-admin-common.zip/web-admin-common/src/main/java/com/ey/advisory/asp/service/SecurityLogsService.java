/**
 * 
 */
package com.ey.advisory.asp.service;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface SecurityLogsService {
	
	public void loginDetails(HttpServletRequest request, String message );
	public void loggedInUser(HttpServletRequest request, String message );
	public void logMessage(HttpServletRequest request, String message );

}
