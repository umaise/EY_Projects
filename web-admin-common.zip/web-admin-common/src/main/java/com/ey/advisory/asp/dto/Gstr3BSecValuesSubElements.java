package com.ey.advisory.asp.dto;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

public class Gstr3BSecValuesSubElements {

	@XmlElement
	private BigDecimal InterState;
	@XmlElement
	private BigDecimal IntraState;
	@XmlElement
	public BigDecimal getInterState() {
		return InterState;
	}
	public void setInterState(BigDecimal interState) {
		InterState = interState;
	}
	@XmlElement
	public BigDecimal getIntraState() {
		return IntraState;
	}
	public void setIntraState(BigDecimal intraState) {
		IntraState = intraState;
	}
	@Override
	public String toString() {
		return "Gstr3BSecValuesSubElements [InterState=" + InterState + ", IntraState=" + IntraState + "]";
	}
	
	
}
