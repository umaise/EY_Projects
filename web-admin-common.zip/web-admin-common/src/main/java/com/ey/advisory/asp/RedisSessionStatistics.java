/*package com.ey.advisory.asp;

import java.util.Date;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.session.Session;
import org.springframework.session.SessionRepository;
import org.springframework.stereotype.Component;
	

@Component
public class RedisSessionStatistics {
	
	
	private static final Logger LOG = LoggerFactory.getLogger(RedisSessionStatistics.class);
	 
	private static final String REDIS_KEY_PREFIX = "spring-security-sessions:";
	
	@Autowired
	private RedisOperations<String, Object> redisOps;
	
	@Autowired
	private SessionRepository sessionRepo;
	
	@Scheduled ( fixedRate = 2000 )
	public void logActiveSessions () {
		Set<String> keys = redisOps.keys ( REDIS_KEY_PREFIX + "*" );
		LOG.info("Number of active sessions: " + keys.size());

		for ( String key : keys ) {
			String id = key.substring(REDIS_KEY_PREFIX.length());
			
			Session session = sessionRepo.getSession(id);
			
			if ( session != null ) {
				Date date = new Date (((HttpSession)session).getLastAccessedTime());
				LOG.info("Session " + id + " last accessed: " + date.toString() );
			}
		}
	}
}*/