package com.ey.advisory.asp.domain;

import java.io.Serializable;


public class Questionairre  implements Serializable {

    private static final long serialVersionUID = 1L;

    private long questionModuleID;
   
    private String questionID;
    
    private String questionValue;
    
    private int orderNo;
    
    private String tooltip;
    
    private Character isManadatory;

    public Character getIsManadatory() {
        return isManadatory;
    }

    public void setIsManadatory(Character isManadatory) {
        this.isManadatory = isManadatory;
    }

    public long getQuestionModuleID() {
        return questionModuleID;
    }

    public void setQuestionModuleID(long questionModuleID) {
        this.questionModuleID = questionModuleID;
    }

    public String getQuestionID() {
        return questionID;
    }

    public void setQuestionID(String questionID) {
        this.questionID = questionID;
    }

    public String getQuestionValue() {
        return questionValue;
    }

    public void setQuestionValue(String questionValue) {
        this.questionValue = questionValue;
    }

    public int getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(int orderNo) {
        this.orderNo = orderNo;
    }

    public String getTooltip() {
        return tooltip;
    }

    public void setTooltip(String tooltip) {
        this.tooltip = tooltip;
    }
}
