package com.ey.advisory.asp.dto;


import java.io.Serializable;
import java.sql.Date;

public class GSTR2DB2BAInvoiceDetails implements Serializable{ 

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

private long id;

private String custGSTIN;

private String invNum;

private Date invDate;
	
private Float invValue;

private String orgInvNum;

private Date orgInvDate;

private Character pos;

private Character itemType;

private String hsnSC;

private Float itemTxval;


private Float igstRt;

private Float igstAmt;

private Float cgstRt;

private Float cgstAmt;

private Float sgstRt;

private Float sgstAmt;

private String itcEligiblity;

private Float itcIGSTAmt;

private Float itcCGSTAmt;

private Float itcSGSTAmt;

private Float tcIGSTAmt;

private Float tcCGSTAmt;

private Float tcSGSTAmt;

private long taxPayerID;

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getCustGSTIN() {
	return custGSTIN;
}

public void setCustGSTIN(String custGSTIN) {
	this.custGSTIN = custGSTIN;
}

public String getInvNum() {
	return invNum;
}

public void setInvNum(String invNum) {
	this.invNum = invNum;
}

public Date getInvDate() {
	return invDate;
}

public void setInvDate(Date invDate) {
	this.invDate = invDate;
}

public Float getInvValue() {
	return invValue;
}

public void setInvValue(Float invValue) {
	this.invValue = invValue;
}

public String getOrgInvNum() {
	return orgInvNum;
}

public void setOrgInvNum(String orgInvNum) {
	this.orgInvNum = orgInvNum;
}

public Date getOrgInvDate() {
	return orgInvDate;
}

public void setOrgInvDate(Date orgInvDate) {
	this.orgInvDate = orgInvDate;
}

public Character getPos() {
	return pos;
}

public void setPos(Character pos) {
	this.pos = pos;
}

public Character getItemType() {
	return itemType;
}

public void setItemType(Character itemType) {
	this.itemType = itemType;
}

public String getHsnSC() {
	return hsnSC;
}

public void setHsnSC(String hsnSC) {
	this.hsnSC = hsnSC;
}

public Float getItemTxval() {
	return itemTxval;
}

public void setItemTxval(Float itemTxval) {
	this.itemTxval = itemTxval;
}

public Float getIgstRt() {
	return igstRt;
}

public void setIgstRt(Float igstRt) {
	this.igstRt = igstRt;
}

public Float getIgstAmt() {
	return igstAmt;
}

public void setIgstAmt(Float igstAmt) {
	this.igstAmt = igstAmt;
}

public Float getCgstRt() {
	return cgstRt;
}

public void setCgstRt(Float cgstRt) {
	this.cgstRt = cgstRt;
}

public Float getCgstAmt() {
	return cgstAmt;
}

public void setCgstAmt(Float cgstAmt) {
	this.cgstAmt = cgstAmt;
}

public Float getSgstRt() {
	return sgstRt;
}

public void setSgstRt(Float sgstRt) {
	this.sgstRt = sgstRt;
}

public Float getSgstAmt() {
	return sgstAmt;
}

public void setSgstAmt(Float sgstAmt) {
	this.sgstAmt = sgstAmt;
}

public String getItcEligiblity() {
	return itcEligiblity;
}

public void setItcEligiblity(String itcEligiblity) {
	this.itcEligiblity = itcEligiblity;
}

public Float getItcIGSTAmt() {
	return itcIGSTAmt;
}

public void setItcIGSTAmt(Float itcIGSTAmt) {
	this.itcIGSTAmt = itcIGSTAmt;
}

public Float getItcCGSTAmt() {
	return itcCGSTAmt;
}

public void setItcCGSTAmt(Float itcCGSTAmt) {
	this.itcCGSTAmt = itcCGSTAmt;
}

public Float getItcSGSTAmt() {
	return itcSGSTAmt;
}

public void setItcSGSTAmt(Float itcSGSTAmt) {
	this.itcSGSTAmt = itcSGSTAmt;
}

public Float getTcIGSTAmt() {
	return tcIGSTAmt;
}

public void setTcIGSTAmt(Float tcIGSTAmt) {
	this.tcIGSTAmt = tcIGSTAmt;
}

public Float getTcCGSTAmt() {
	return tcCGSTAmt;
}

public void setTcCGSTAmt(Float tcCGSTAmt) {
	this.tcCGSTAmt = tcCGSTAmt;
}

public Float getTcSGSTAmt() {
	return tcSGSTAmt;
}

public void setTcSGSTAmt(Float tcSGSTAmt) {
	this.tcSGSTAmt = tcSGSTAmt;
}

public long getTaxPayerID() {
	return taxPayerID;
}

public void setTaxPayerID(long taxPayerID) {
	this.taxPayerID = taxPayerID;
}

	
}
