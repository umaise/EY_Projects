package com.ey.advisory.asp.dto;

import java.util.List;
import java.util.Map;

public class GSTTurnoverWrapper {
	

		private List<Map<String,String>> tabRows;

		public List<Map<String,String>> getDataRows() {
			return tabRows;
		}

		public void setDataRows(List<Map<String,String>> dataRows) {
			this.tabRows = dataRows;
		}
		
}
