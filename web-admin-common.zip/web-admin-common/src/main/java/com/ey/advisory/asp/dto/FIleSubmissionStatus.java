package com.ey.advisory.asp.dto;

import java.math.BigInteger;

import com.google.api.client.util.DateTime;

public class FIleSubmissionStatus {
	
	private BigInteger fIleSubmissionStatusUID ;
	private String refNo;
	private String gstin;
	private String returnPeriod;
	private DateTime createdOn;
	public BigInteger getfIleSubmissionStatusUID() {
		return fIleSubmissionStatusUID;
	}
	public void setfIleSubmissionStatusUID(BigInteger fIleSubmissionStatusUID) {
		this.fIleSubmissionStatusUID = fIleSubmissionStatusUID;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public DateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(DateTime createdOn) {
		this.createdOn = createdOn;
	}
	
	
	

}
