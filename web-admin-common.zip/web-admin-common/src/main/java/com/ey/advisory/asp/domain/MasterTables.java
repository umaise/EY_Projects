package com.ey.advisory.asp.domain;

public interface MasterTables {

}
