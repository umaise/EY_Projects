package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.Date;

public class RoleDtoTemp implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long  roleId;
	private String rolename;
	private String roleDescription;
	private String createdBy;
	private String createdDate;
	private String defaultRole;
	private String roleType;
	private String category;
    
	
	
	public RoleDtoTemp getClonnedObject(){
		
		RoleDtoTemp role = new RoleDtoTemp();
		role.setRoleId(this.roleId);
		role.setCategory(this.category);
		role.setRolename(this.rolename);
		role.setRoleType(this.roleType);
		return role;
	}
	
	public RoleDtoTemp(Long roleId) {
		this.roleId = roleId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = null;
	}

	public String getDefaultRole() {
		return defaultRole;
	}

	public void setDefaultRole(String defaultRole) {
		this.defaultRole = defaultRole;
	}

	/**
	 * @return the roleType
	 */
	public String getRoleType() {
		return roleType;
	}

	/**
	 * @param roleType the roleType to set
	 */
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
	
	public RoleDtoTemp() {
		super();
	}

	

	public RoleDtoTemp(Long roleId, String rolename, String roleDescription, String createdBy, String createdDate,
			String defaultRole, String roleType,String category) {
		super();
		this.roleId = roleId;
		this.rolename = rolename;
		this.roleDescription = roleDescription;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.defaultRole = defaultRole;
		this.roleType = roleType;
		this.category=category;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	
	

}
