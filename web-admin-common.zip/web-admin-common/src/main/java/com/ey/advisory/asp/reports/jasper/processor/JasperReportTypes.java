package com.ey.advisory.asp.reports.jasper.processor;

public enum JasperReportTypes {

	GSTR1Summary,GSTR2Summary,GSTR6Summary,GSTR7Summary
}
