package com.ey.advisory.asp.dto;


public class GSTR2Nil {
	
	private Long id;
	
	private Character flag;
	
	private String checksum;
	
	private String suppType;
	
	private String hsnSC;
	
	private Float cmdSupAmt;
	
	private Float unRegSupAmt;
	
	private Float emptSupAmt;
	
	private Float nonGstSupAmt;
	
	private Float nilAmt;
	
	private Float txValue;
	
	private Long taxPayerId;

	private int invoiceCnt;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTaxPayerId() {
		return taxPayerId;
	}

	public void setTaxPayerId(Long taxPayerId) {
		this.taxPayerId = taxPayerId;
	}

	/**
	 * @return the flag
	 */
	public Character getFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(Character flag) {
		this.flag = flag;
	}

	/**
	 * @return the checksum
	 */
	public String getChecksum() {
		return checksum;
	}

	/**
	 * @param checksum the checksum to set
	 */
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	/**
	 * @return the suppType
	 */
	public String getSuppType() {
		return suppType;
	}

	/**
	 * @param suppType the suppType to set
	 */
	public void setSuppType(String suppType) {
		this.suppType = suppType;
	}

	/**
	 * @return the hsnSC
	 */
	public String getHsnSC() {
		return hsnSC;
	}

	/**
	 * @param hsnSC the hsnSC to set
	 */
	public void setHsnSC(String hsnSC) {
		this.hsnSC = hsnSC;
	}

	/**
	 * @return the cmdSupAmt
	 */
	public Float getCmdSupAmt() {
		return cmdSupAmt;
	}

	/**
	 * @param cmdSupAmt the cmdSupAmt to set
	 */
	public void setCmdSupAmt(Float cmdSupAmt) {
		this.cmdSupAmt = cmdSupAmt;
	}

	/**
	 * @return the unRegSupAmt
	 */
	public Float getUnRegSupAmt() {
		return unRegSupAmt;
	}

	/**
	 * @param unRegSupAmt the unRegSupAmt to set
	 */
	public void setUnRegSupAmt(Float unRegSupAmt) {
		this.unRegSupAmt = unRegSupAmt;
	}

	/**
	 * @return the emptSupAmt
	 */
	public Float getEmptSupAmt() {
		return emptSupAmt;
	}

	/**
	 * @param emptSupAmt the emptSupAmt to set
	 */
	public void setEmptSupAmt(Float emptSupAmt) {
		this.emptSupAmt = emptSupAmt;
	}

	/**
	 * @return the nonGstSupAmt
	 */
	public Float getNonGstSupAmt() {
		return nonGstSupAmt;
	}

	/**
	 * @param nonGstSupAmt the nonGstSupAmt to set
	 */
	public void setNonGstSupAmt(Float nonGstSupAmt) {
		this.nonGstSupAmt = nonGstSupAmt;
	}

	/**
	 * @return the nilAmt
	 */
	public Float getNilAmt() {
		return nilAmt;
	}

	/**
	 * @param nilAmt the nilAmt to set
	 */
	public void setNilAmt(Float nilAmt) {
		this.nilAmt = nilAmt;
	}

	/**
	 * @return the txValue
	 */
	public Float getTxValue() {
		return txValue;
	}

	/**
	 * @param txValue the txValue to set
	 */
	public void setTxValue(Float txValue) {
		this.txValue = txValue;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	

	
}
