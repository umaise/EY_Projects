package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

public class Role implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Digits(fraction = 0, integer =3)
	private Long  roleId;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String rolename;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String roleDescription;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String createdBy;
	private Date createdDate;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String defaultRole;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String roleType;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String category;
	private List<UserGSTNRoleMapping>  userGSTNRoleMapings = new ArrayList<>();
    
	
	
	public Role getClonnedObject(){
		
		Role role = new Role();
		role.setRoleId(this.roleId);
		role.setCategory(this.category);
		role.setRolename(this.rolename);
		role.setRoleType(this.roleType);
		return role;
	}
	
	public Role(Long roleId) {
		this.roleId = roleId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDefaultRole() {
		return defaultRole;
	}

	public void setDefaultRole(String defaultRole) {
		this.defaultRole = defaultRole;
	}

	public List<UserGSTNRoleMapping> getUserGSTNRoleMapings() {
		return userGSTNRoleMapings;
	}

	public void setUserGSTNRoleMapings(List<UserGSTNRoleMapping> userGSTNRoleMapings) {
		this.userGSTNRoleMapings = userGSTNRoleMapings;
	}

	/**
	 * @return the roleType
	 */
	public String getRoleType() {
		return roleType;
	}

	/**
	 * @param roleType the roleType to set
	 */
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
	
	public Role() {
		super();
	}

	

	public Role(Long roleId, String rolename, String roleDescription, String createdBy, Date createdDate,
			String defaultRole, String roleType,String category) {
		super();
		this.roleId = roleId;
		this.rolename = rolename;
		this.roleDescription = roleDescription;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.defaultRole = defaultRole;
		this.roleType = roleType;
		this.category=category;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	
	

}
