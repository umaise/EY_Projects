package com.ey.advisory.asp.dto;

import java.sql.Date;

public class GSTR2ITC {

	private Long id;

	private Character flag;

	private String checksum;

	private String invNum;

	private Date invDate;

	private Float emIgst;

	private Float tmIgst;

	private Float emCgst;

	private Float tmCgst;

	private Float emSgst;

	private Float tmSgst;

	private Long taxPayerId;

	private Float txValue;

	private int invoiceCnt;

	private Float igstTotal;

	private Float cgstTotal;

	private Float sgstTotal;

	/**
	 * @return the flag
	 */
	public Character getFlag() {
		return flag;
	}

	/**
	 * @param flag
	 *            the flag to set
	 */
	public void setFlag(Character flag) {
		this.flag = flag;
	}

	/**
	 * @return the checksum
	 */
	public String getChecksum() {
		return checksum;
	}

	/**
	 * @param checksum
	 *            the checksum to set
	 */
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	/**
	 * @return the invNum
	 */
	public String getInvNum() {
		return invNum;
	}

	/**
	 * @param invNum
	 *            the invNum to set
	 */
	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	/**
	 * @return the invDate
	 */
	public Date getInvDate() {
		return invDate;
	}

	/**
	 * @param invDate
	 *            the invDate to set
	 */
	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	/**
	 * @return the emIgst
	 */
	public Float getEmIgst() {
		return emIgst;
	}

	/**
	 * @param emIgst
	 *            the emIgst to set
	 */
	public void setEmIgst(Float emIgst) {
		this.emIgst = emIgst;
	}

	/**
	 * @return the tmIgst
	 */
	public Float getTmIgst() {
		return tmIgst;
	}

	/**
	 * @param tmIgst
	 *            the tmIgst to set
	 */
	public void setTmIgst(Float tmIgst) {
		this.tmIgst = tmIgst;
	}

	/**
	 * @return the emCgst
	 */
	public Float getEmCgst() {
		return emCgst;
	}

	/**
	 * @param emCgst
	 *            the emCgst to set
	 */
	public void setEmCgst(Float emCgst) {
		this.emCgst = emCgst;
	}

	/**
	 * @return the tmCgst
	 */
	public Float getTmCgst() {
		return tmCgst;
	}

	/**
	 * @param tmCgst
	 *            the tmCgst to set
	 */
	public void setTmCgst(Float tmCgst) {
		this.tmCgst = tmCgst;
	}

	/**
	 * @return the emSgst
	 */
	public Float getEmSgst() {
		return emSgst;
	}

	/**
	 * @param emSgst
	 *            the emSgst to set
	 */
	public void setEmSgst(Float emSgst) {
		this.emSgst = emSgst;
	}

	/**
	 * @return the tmSgst
	 */
	public Float getTmSgst() {
		return tmSgst;
	}

	/**
	 * @param tmSgst
	 *            the tmSgst to set
	 */
	public void setTmSgst(Float tmSgst) {
		this.tmSgst = tmSgst;
	}

	/**
	 * @return the txValue
	 */
	public Float getTxValue() {
		return txValue;
	}

	/**
	 * @param txValue
	 *            the txValue to set
	 */
	public void setTxValue(Float txValue) {
		this.txValue = txValue;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTaxPayerId() {
		return taxPayerId;
	}

	public void setTaxPayerId(Long taxPayerId) {
		this.taxPayerId = taxPayerId;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}

	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}

	public Float getCgstTotal() {
		return cgstTotal;
	}

	public void setCgstTotal(Float cgstTotal) {
		this.cgstTotal = cgstTotal;
	}

	public Float getSgstTotal() {
		return sgstTotal;
	}

	public void setSgstTotal(Float sgstTotal) {
		this.sgstTotal = sgstTotal;
	}

}
