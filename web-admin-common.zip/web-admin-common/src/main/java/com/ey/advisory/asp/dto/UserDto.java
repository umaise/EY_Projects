package com.ey.advisory.asp.dto;

import java.io.Serializable;

public class UserDto implements Serializable{
 
	private static final long serialVersionUID = 1L;
	
	private Long userId;
	private String userName;
	private String firstName;
	private String lastName;
	private Long mobileNo;
	private String eMailID;
	private Long roleId;
	private Boolean isAddUser;
	private String isActive;
	
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public Boolean getIsAddUser() {
		return isAddUser;
	}
	public void setIsAddUser(Boolean isAddUser) {
		this.isAddUser = isAddUser;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String geteMailID() {
		return eMailID;
	}
	public void seteMailID(String eMailID) {
		this.eMailID = eMailID;
	}
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	
	
}
