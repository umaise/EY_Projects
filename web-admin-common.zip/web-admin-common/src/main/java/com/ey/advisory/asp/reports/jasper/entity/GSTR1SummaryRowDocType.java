package com.ey.advisory.asp.reports.jasper.entity;

public class GSTR1SummaryRowDocType {

	String docNature;
	String to;
	String from;
	Integer ttlnum;
	public String getDocNature() {
		return docNature;
	}
	public void setDocNature(String docNature) {
		this.docNature = docNature;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public Integer getTtlnum() {
		return ttlnum;
	}
	public void setTtlnum(Integer ttlnum) {
		this.ttlnum = ttlnum;
	}

	
}
