package com.ey.advisory.asp.reports.jasper.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.reports.jasper.entity.GSTR1SummaryData;
import com.ey.advisory.asp.reports.jasper.entity.GSTR1Summary_row;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class GSTR1SummaryFiller extends AbstractReportFiller {

	private static final Logger logger = Logger.getLogger(GSTR1SummaryFiller.class);

	@Override
	public byte[] getJasperReport(Object reportData, String reportPath) {

		byte[] pdfReport = null;

		// Map to hold Jasper report Parameters
		Map<String, Object> parameters = new HashMap<>();	
		try {
			logger.debug("--------------generate GSTR1Summery PDF report----------");

			GSTR1SummaryData data = (GSTR1SummaryData) reportData;

			parameters.put("reportName", data.getReportName());
			parameters.put("gstin", data.getGstnId());
			parameters.put("businessName", data.getBusinessName());
			parameters.put("fy", data.getfYear());
			parameters.put("returnPeriod", data.getReturnPeriod());
			parameters.put("totalTaxPayable", data.getTotalTaxPayable());
			parameters.put("totalTaxable", data.getTotalTaxable());
			parameters.put("totalIgst", data.getTotalIgst());
			parameters.put("totalCgst", data.getTotalCgst());
			parameters.put("totalSgst", data.getTotalSgst());
			parameters.put("totalCess", data.getTotalCess());
			parameters.put("outwardSupplies", data.getOutwardSupplies());
			parameters.put("exemptSupplies", data.getExemptSupplies());
			parameters.put("fyTurnOver", data.getFyTurnOver());
			parameters.put("qyTurnOver", data.getQyTurnOver());

			JsonParser parser = new JsonParser();
			JsonObject jo= parser.parse(data.getGstr1Sum()).getAsJsonObject();
			if(jo.get("sec_sum")!=null){
			JsonArray ja = jo.get("sec_sum").getAsJsonArray();
			
			JsonObject section;
			List<GSTR1Summary_row> listItems;
			JRBeanCollectionDataSource itemsJRBean;
			GSTR1Summary_row oneRow;
			String jasperRSec;
			for (int index = 0; index < ja.size(); index++) {
				try{
					section = ja.get(index).getAsJsonObject();
					oneRow = new GSTR1Summary_row();
					Double taxPayable=0.00;
					jasperRSec = section.get("sec_nm").getAsString().toUpperCase();
					if(section.get("ttl_rec")!=null)
						parameters.put(section.get("sec_nm").getAsString().toUpperCase()+"rec", section.get("ttl_rec").getAsString());
					if (!section.get("sec_nm").getAsString().equalsIgnoreCase("NIL") && !(section.get("sec_nm").getAsString().
							equalsIgnoreCase("DOC_ISSUE"))) {
							if(section.get("ttl_tax") != null)
							oneRow.setTaxableValue(Double.parseDouble(section.get("ttl_tax").getAsString()));
							if(section.get("ttl_val") != null)
							oneRow.setInvoiceValue(Double.parseDouble(section.get("ttl_val").getAsString()));
							if(section.get("ttl_igst") != null){
								oneRow.setIgst(Double.parseDouble(section.get("ttl_igst").getAsString()));
								taxPayable = taxPayable+Double.parseDouble(section.get("ttl_igst").getAsString());
							}
							if(section.get("ttl_cgst") != null){
								oneRow.setCgst(Double.parseDouble(section.get("ttl_cgst").getAsString()));
								taxPayable = taxPayable+Double.parseDouble(section.get("ttl_cgst").getAsString());
							}
							if(section.get("ttl_sgst") != null){
								oneRow.setSgst(Double.parseDouble(section.get("ttl_sgst").getAsString()));
								taxPayable = taxPayable+Double.parseDouble(section.get("ttl_sgst").getAsString());
							}
							if(section.get("ttl_cess") != null){
								oneRow.setCess(Double.parseDouble(section.get("ttl_cess").getAsString()));
								taxPayable = taxPayable+Double.parseDouble(section.get("ttl_cess").getAsString());
							}
							
							oneRow.setTaxPayable(taxPayable);
	
					}
					else if(section.get("sec_nm").getAsString().equalsIgnoreCase("NIL")){
						if(section.get("ttl_nilsup_amt") != null)
						oneRow.setTotalNil(Double.parseDouble(section.get("ttl_nilsup_amt").getAsString()));
						if(section.get("ttl_expt_amt") != null)
						oneRow.setTotalexempt(Double.parseDouble(section.get("ttl_expt_amt").getAsString()));
						if(section.get("ttl_ngsup_amt") != null)
						oneRow.setNonGst(Double.parseDouble(section.get("ttl_ngsup_amt").getAsString()));
					}
					else{
						if(section.get("ttl_doc_issued") != null)
						oneRow.setTotalDoc(Double.parseDouble(section.get("ttl_doc_issued").getAsString()));
						if(section.get("net_doc_issued") != null)
						oneRow.setNetDoc(Double.parseDouble(section.get("net_doc_issued").getAsString()));
						if(section.get("ttl_doc_cancelled") != null)
						oneRow.setTotalCancel(Double.parseDouble(section.get("ttl_doc_cancelled").getAsString()));
					}
					listItems = new ArrayList<>();
					listItems.add(oneRow);
					itemsJRBean = new JRBeanCollectionDataSource(listItems);
					parameters.put(jasperRSec, itemsJRBean);
			}catch(Exception e){
				logger.error("Exception occured in GSTR1SummaryFiller.getGSTR1SummeryReport sections :  ", e);
			}
		}
		}
		} catch (Exception e) {
			logger.error("Exception occured in GSTR1SummaryFiller.getGSTR1SummeryReport parameters :  ", e);
		}
		JasperPrint jasperPrint = GSTR1SummaryFiller.getReport(parameters, reportPath);

		try {
			pdfReport = JasperExportManager.exportReportToPdf(jasperPrint);
		} catch (JRException e) {
			logger.error("Exception occured in GSTR1SummaryFiller.getGSTR1SummeryReport pdfReport :  ", e);
		}
		return pdfReport;

	}

	private static JasperPrint getReport(Map<String, Object> parameters, String masterReportPath) {
		JasperPrint jasperPrint = null;
		try {
			jasperPrint = JasperFillManager.fillReport(masterReportPath, parameters, new JREmptyDataSource());
		} catch (JRException e) {
			logger.error("Exception occured in GSTR1SummaryFiller.getReport report :  ", e);
		}
		return jasperPrint;
	}

}
