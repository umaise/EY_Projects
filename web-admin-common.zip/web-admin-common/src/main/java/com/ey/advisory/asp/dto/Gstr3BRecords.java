package com.ey.advisory.asp.dto;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

public class Gstr3BRecords {
	@XmlElement(defaultValue = "00.0")
	String PlaceOfSupply;
	BigDecimal TTV;
	@XmlElement(defaultValue = "00.0")
	BigDecimal Integrated;
	@XmlElement
	public String getPlaceOfSupply() {
		return PlaceOfSupply;
	}
	public void setPlaceOfSupply(String placeOfSupply) {
		PlaceOfSupply = placeOfSupply;
	}
	@XmlElement
	public BigDecimal getTTV() {
		return TTV;
	}
	public void setTTV(BigDecimal tTV) {
		TTV = tTV;
	}
	@XmlElement
	public BigDecimal getIntegrated() {
		return Integrated;
	}
	public void setIntegrated(BigDecimal integrated) {
		Integrated = integrated;
	}
	@Override
	public String toString() {
		return "Gstr3BRecords [PlaceOfSupply=" + PlaceOfSupply + ", TTV=" + TTV + ", Integrated=" + Integrated + "]";
	}
	
	
	
}
