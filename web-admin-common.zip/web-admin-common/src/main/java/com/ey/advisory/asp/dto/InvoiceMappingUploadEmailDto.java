package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.HashMap;

public class InvoiceMappingUploadEmailDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String gstin;
	private HashMap<String,Integer> invoiceCountsInEmail;
	private boolean isInvMapping;

	public boolean isInvMapping() {
		return isInvMapping;
	}
	public void setInvMapping(boolean isInvMapping) {
		this.isInvMapping = isInvMapping;
	}
	
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public HashMap<String, Integer> getInvoiceCountsInEmail() {
		return invoiceCountsInEmail;
	}
	public void setInvoiceCountsInEmail(HashMap<String, Integer> invoiceCountsInEmail) {
		this.invoiceCountsInEmail = invoiceCountsInEmail;
	}
}
