/**
 * 
 */
package com.ey.advisory.asp.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

/**
 * @author Nitesh.Tripathi
 *
 */
public class CustomLogoutSuccessHandler implements LogoutSuccessHandler {

	/* (non-Javadoc)
	 * @see org.springframework.security.web.authentication.logout.LogoutSuccessHandler#onLogoutSuccess(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, org.springframework.security.core.Authentication)
	 */
	
	private String adminLoginPage;
	
	private String memberLoginPage;
	
	public String getAdminLoginPage() {
		return adminLoginPage;
	}

	public void setAdminLoginPage(String adminLoginPage) {
		this.adminLoginPage = adminLoginPage;
	}

	public String getMemberLoginPage() {
		return memberLoginPage;
	}

	public void setMemberLoginPage(String memberLoginPage) {
		this.memberLoginPage = memberLoginPage;
	}

	@Override
	public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication auth)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		String refererUrl = request.getHeader("Referer");
		if(refererUrl != null && refererUrl.contains("admin")){
			response.sendRedirect(request.getContextPath()+adminLoginPage);
		}else{
			response.sendRedirect(request.getContextPath()+memberLoginPage);
		}
	}

}
