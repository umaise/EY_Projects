/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.Comparator;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

/**
 * @author Nitesh.Tripathi
 *
 */
public class GroupDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Digits(fraction = 0, integer = 20)
	private Long groupId;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String groupName;

	private Boolean isDivParent;

	private Boolean isActive;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String createdBy;

	private String createdDate;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String updatedBy;

	private String updatedDate;

	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String groupCode;

	/**
	 * @return the groupId
	 */
	public Long getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId
	 *            the groupId to set
	 */
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName
	 *            the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * @return the isDivParent
	 */
	public Boolean getIsDivParent() {
		return isDivParent;
	}

	/**
	 * @param isDivParent
	 *            the isDivParent to set
	 */
	public void setIsDivParent(Boolean isDivParent) {
		this.isDivParent = isDivParent;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive
	 *            the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy
	 *            the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the updatedDate
	 */
	public String getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate
	 *            the updatedDate to set
	 */
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the groupCode
	 */
	public String getGroupCode() {
		return groupCode;
	}

	/**
	 * @param groupCode
	 *            the groupCode to set
	 */
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((groupId == null) ? 0 : groupId.hashCode());
		result = prime * result + ((groupName == null) ? 0 : groupName.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GroupDto other = (GroupDto) obj;
		if (groupId == null) {
			if (other.groupId != null)
				return false;
		} else if (!groupId.equals(other.groupId))
			return false;
		if (groupName == null) {
			if (other.groupName != null)
				return false;
		} else if (!groupName.equals(other.groupName))
			return false;
		return true;
	}

	public static Comparator<GroupDto> GrpNameComparator = new Comparator<GroupDto>() {

		public int compare(GroupDto grp1, GroupDto grp2) {

			String grp1Name = grp1.getGroupName();
			String grp2Name = grp2.getGroupName();

			// ascending order
			return grp1Name.toLowerCase().compareTo(grp2Name.toLowerCase());

			// descending order
			// return fruitName2.compareTo(fruitName1);
		}

	};

}
