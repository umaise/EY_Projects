package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.Date;


public class ClientDraftData implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer onBoardingID;
	private Long userID;
	private Long groupID;
	private String entityName;
	private String onBoardJson;
	private Date lastModifiedDate;
	private String groupName;
	private String userName;
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public Integer getOnBoardingID() {
		return onBoardingID;
	}
	public void setOnBoardingID(Integer onBoardingID) {
		this.onBoardingID = onBoardingID;
	}
	public Long getUserID() {
		return userID;
	}
	public void setUserID(Long userID) {
		this.userID = userID;
	}
	public Long getGroupID() {
		return groupID;
	}
	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public String getOnBoardJson() {
		return onBoardJson;
	}
	public void setOnBoardJson(String onBoardJson) {
		this.onBoardJson = onBoardJson;
	}
	@Override
	public String toString() {
		return "ClientDraftData [onBoardingID=" + onBoardingID + ", userID="
				+ userID + ", groupID=" + groupID + ", entityName="
				+ entityName + ", onBoardJson=" + onBoardJson + "]";
	}
	
	
}
