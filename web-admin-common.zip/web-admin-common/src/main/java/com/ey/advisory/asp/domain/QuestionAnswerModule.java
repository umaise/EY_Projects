package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;


public class QuestionAnswerModule implements Serializable{

    private static final long serialVersionUID = 1L;
    private long questionAnsMapID;
    private String questionID;
    private String answerID;
    private int entityID;
    private String description;
    private Boolean isDeleted;
    
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
    private Date createdDate;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
    private Date updatedDate;
    public long getQuestionAnsMapID() {
        return questionAnsMapID;
    }
    public void setQuestionAnsMapID(long questionAnsMapID) {
        this.questionAnsMapID = questionAnsMapID;
    }
    public String getQuestionID() {
        return questionID;
    }
    public void setQuestionID(String questionID) {
        this.questionID = questionID;
    }
    public String getAnswerID() {
        return answerID;
    }
    public void setAnswerID(String answerID) {
        this.answerID = answerID;
    }
    public int getEntityID() {
        return entityID;
    }
    public void setEntityID(int entityID) {
        this.entityID = entityID;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Boolean getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }
    public Date getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
    public Date getUpdatedDate() {
        return updatedDate;
    }
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }
    @Override
    public String toString() {
        return "QuestionAnswerModule [questionAnsMapID=" + questionAnsMapID + ", questionID=" + questionID
            + ", answerID=" + answerID + ", entityID=" + entityID + ", description=" + description + ", isDeleted="
            + isDeleted + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + "]";
    }
    

}
