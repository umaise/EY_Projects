package com.ey.advisory.asp.dto;

public class ReturnSummaryDto {

	private String gstrName;
	private String dueDate;
	private String gstrType;
	
	public String getGstrName() {
		return gstrName;
	}
	public void setGstrName(String gstrName) {
		this.gstrName = gstrName;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getGstrType() {
		return gstrType;
	}
	public void setGstrType(String gstrType) {
		this.gstrType = gstrType;
	}
	
}
