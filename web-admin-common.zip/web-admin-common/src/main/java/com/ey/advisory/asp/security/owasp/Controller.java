package com.ey.advisory.asp.security.owasp;

import java.io.Serializable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Controller implements Serializable
{

@SerializedName("controllername")
@Expose
private String controllername;
@SerializedName("urls")
@Expose
private Urls urls;
private final static long serialVersionUID = 2007040491757989464L;

public String getControllername() {
return controllername;
}

public void setControllername(String controllername) {
this.controllername = controllername;
}

public Urls getUrls() {
return urls;
}

public void setUrls(Urls urls) {
this.urls = urls;
}

}