package com.ey.advisory.asp.domain;

import java.util.List;

public class UserClient {
	
	private Integer userId;
	private String firstName;
	private String lastName;
	private String userName;
	private String email;
	private String mobileNo;
	private String role;
	private String accessLevel;
	private Integer groupId;
	private List<String> accessValues;
	private Long roleId;

	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public String getAccessLevel() {
		return accessLevel;
	}
	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}
	public List<String> getAccessValues() {
		return accessValues;
	}
	public void setAccessValues(List<String> accessValues) {
		this.accessValues = accessValues;
	}
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	@Override
	public String toString() {
		return "UserClient [userId=" + userId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", userName=" + userName
				+ ", email=" + email + ", mobileNo=" + mobileNo + ", role="
				+ role + ", accessLevel=" + accessLevel + ", groupId="
				+ groupId + ", accessValues=" + accessValues + ", roleId="
				+ roleId + "]";
	}
	
	

}
