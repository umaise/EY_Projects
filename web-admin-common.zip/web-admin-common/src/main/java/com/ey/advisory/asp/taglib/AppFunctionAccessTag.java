package com.ey.advisory.asp.taglib;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.tagext.Tag;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.web.servlet.tags.RequestContextAwareTag;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.RoleDto;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;
import com.ey.advisory.asp.util.RedisSessionUtility;

@Configurable
public class AppFunctionAccessTag  extends RequestContextAwareTag  {
	/**
	 * 
	 * 
	 */

	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	private static final long serialVersionUID = 1L;

	protected static final Logger LOGGER = Logger
			.getLogger(AppFunctionAccessTag.class);
	
	private String appFunName;

	/* *public int doStartTag() throws JspException {
		
		HttpSession session=pageContext.getSession();
		
		List<String> appFunctions=null;
		
		if(session != null){
			appFunctions=(List<String>) session.getAttribute(Constant.USER_ROLE_FUNS);
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug(appFunctions.toString());
				LOGGER.debug("appFunName :- "+appFunName);
			}
		}else{
			LOGGER.error("Session is null");
		}
		
		if(appFunctions!= null && appFunctions.contains(appFunName)){
			return Tag.EVAL_BODY_INCLUDE;
		}else{
			
			if(LOGGER.isDebugEnabled()){
				
				LOGGER.debug("appFunName :- "+appFunName+" Not available for user");
			}
		}
				
		return Tag.SKIP_BODY;
	}*/
	
	public String getAppFunName() {
		return appFunName;
	}

	public void setAppFunName(String appFunName) {
		this.appFunName = appFunName;
	}

	@Override
	protected int doStartTagInternal() throws Exception {
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		RedisOperationForSessionObj obj = getRequestContext().getWebApplicationContext()
				.getBean(RedisOperationForSessionObj.class);
		RedisSessionUtility util = getRequestContext().getWebApplicationContext().getBean(RedisSessionUtility.class);
		obj.setUtil(util);
		List<String> appFunctions= obj.getStringListFromRedis(Constant.USER_ROLE_FUNS, request);
		Set<RoleDto> roleDtoSet =  obj.getRoleSetFromRedis(request);
		String category = "";
		if(roleDtoSet != null){
			for(RoleDto rdto:roleDtoSet){
				if(Constant.INTERNAL_CATEGORY.equalsIgnoreCase(rdto.getCategory())){
					category = "Internal";
				}
			}
		}
		
		if(Constant.INTERNAL_CATEGORY.equalsIgnoreCase(category)){
			
			return Tag.EVAL_BODY_INCLUDE;
			
		}else if(appFunName.contains("authSignFunc")){
			
			return Tag.EVAL_BODY_INCLUDE;
			
		}else if(appFunctions!= null && appFunctions.contains(appFunName)){
			
		
		
			return Tag.EVAL_BODY_INCLUDE;
		}else{
			
			if(LOGGER.isDebugEnabled()){
				
				LOGGER.debug("appFunName :- "+appFunName+" Not available for user");
			}
		}
		
		return Tag.SKIP_BODY;
	}
	
}
