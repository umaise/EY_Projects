package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

public class GSTR1SummaryAdvanceAdjusted implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer advanceAdjustedID;
	private String columnName;
	private String columnCode;
	private String dataType;
	private Integer columnOrderNo;
	public Integer getAdvanceAdjustedID() {
		return advanceAdjustedID;
	}
	public void setAdvanceAdjustedID(Integer advanceAdjustedID) {
		this.advanceAdjustedID = advanceAdjustedID;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getColumnCode() {
		return columnCode;
	}
	public void setColumnCode(String columnCode) {
		this.columnCode = columnCode;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public Integer getColumnOrderNo() {
		return columnOrderNo;
	}
	public void setColumnOrderNo(Integer columnOrderNo) {
		this.columnOrderNo = columnOrderNo;
	}
	
	

}
