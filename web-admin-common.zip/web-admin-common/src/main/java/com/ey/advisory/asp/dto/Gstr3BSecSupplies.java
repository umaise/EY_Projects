package com.ey.advisory.asp.dto;

import javax.xml.bind.annotation.XmlElement;

public class Gstr3BSecSupplies {

	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecSuppliesSubElements SuppUnregPersons = new Gstr3BSecSuppliesSubElements();
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecSuppliesSubElements SuppComPersons = new Gstr3BSecSuppliesSubElements();
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecSuppliesSubElements SuppUINHolders = new Gstr3BSecSuppliesSubElements();

	@XmlElement
	public Gstr3BSecSuppliesSubElements getSuppUnregPersons() {
		return SuppUnregPersons;
	}

	public void setSuppUnregPersons(Gstr3BSecSuppliesSubElements suppUnregPersons) {
		SuppUnregPersons = suppUnregPersons;
	}

	@XmlElement
	public Gstr3BSecSuppliesSubElements getSuppComPersons() {
		return SuppComPersons;
	}

	public void setSuppComPersons(Gstr3BSecSuppliesSubElements suppComPersons) {
		SuppComPersons = suppComPersons;
	}

	@XmlElement
	public Gstr3BSecSuppliesSubElements getSuppUINHolders() {
		return SuppUINHolders;
	}

	public void setSuppUINHolders(Gstr3BSecSuppliesSubElements suppUINHolders) {
		SuppUINHolders = suppUINHolders;
	}

	@Override
	public String toString() {
		return "Gstr3BSecSupplies [SuppUnregPersons=" + SuppUnregPersons + ", SuppComPersons=" + SuppComPersons
				+ ", SuppUINHolders=" + SuppUINHolders + "]";
	}
	
	
}
