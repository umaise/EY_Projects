package com.ey.advisory.asp.util;

import java.math.BigDecimal;
import java.math.MathContext;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.Gstr3Dto;

@Component
@PropertySource("classpath:ASPRestConfig.properties")
public class Gstr3BusinessRules {

	@Value("${asp-restapi.host}")
	private String restHost;

	private  final Logger LOGGER = Logger.getLogger(Gstr3BusinessRules.class);
	private static final String CLASS_NAME = Gstr3BusinessRules.class.getName();

	public BigDecimal getLateFee(int days)  {
		LOGGER.info(Constant.ENTER + CLASS_NAME + " Method : getLateFee");
		BigDecimal lateFee = null;
		try {

			// Get late fee charge from DB
			if (days > 0) {
				// calculate the total late fee
				lateFee = Constant.LATE_FEE.multiply(new BigDecimal(days));
			}

		} catch (Exception e) {
			LOGGER.info(Constant.ERROR + CLASS_NAME + " Method : getLateFee " + e.getMessage());
			throw e;
		}
		LOGGER.info(Constant.EXIT + CLASS_NAME + " Method : getLateFee");
		return lateFee;

	}

	public Gstr3Dto isGStr3FileEndDate(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.ENTER + CLASS_NAME + " Method : getLateFee");
		try {
			Calendar calendar = Calendar.getInstance();
			Date currentDate = calendar.getTime();

			// get current tax period
			String taxPeriod = gstr3Dto.getRtPeriod();
			String gstr3FileEndDate = Constant.GSTR3FILE_ENDDATE + taxPeriod;
			SimpleDateFormat sdf = new SimpleDateFormat(Constant.DATE_FORMAT_DDMMYYYY);
			calendar.setTime(sdf.parse(gstr3FileEndDate));
			Date fileEndDate = calendar.getTime();

			// Calculate the number of day
			int days = (int) ChronoUnit.DAYS.between(fileEndDate.toInstant(), currentDate.toInstant());
			if (days > 0) {
				gstr3Dto = new Gstr3Dto();
				gstr3Dto.setFileEndDate(Constant.BOOLEAN_TRUE);
				gstr3Dto.setDays(days);
			} else {
				gstr3Dto = new Gstr3Dto();
				gstr3Dto.setFileEndDate(Constant.BOOLEAN_FALSE);
			}
		} catch (ParseException e) {
			LOGGER.info(Constant.ERROR + CLASS_NAME + " Method : isFileDateMissed ",e);
		}
		return gstr3Dto;
	}
	
}
