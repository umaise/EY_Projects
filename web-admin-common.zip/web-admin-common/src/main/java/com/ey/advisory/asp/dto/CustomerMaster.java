package com.ey.advisory.asp.dto;

import java.math.BigDecimal;
import java.util.Date;

public class CustomerMaster {

	  private Long customerId;
      private String sgstin;
      private String cgstin;
      private String custCode;
      private String custName;
      private String custAddress;
      private String custCategory;
      private String custLocationCode;
      private String categoryOfService;
      private String hsnsac;
      private String pos;
      private String info;
      private String primaryContactName;
      private String primaryeMailId;
      private String primaryMobNum;
      private String secondaryContactName;
      private String secondaryeMailId;
      private String secondaryMobNum;
      private Boolean isExempt;
      private String notificationNum;
      private Date notificationDate;
      private String serialNum;
      private BigDecimal igstrt;
      private BigDecimal cgstrt; 
      private BigDecimal sgstrt;
      private BigDecimal cessrt;
      private String isTds;
      
      public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getSgstin() {
		return sgstin;
	}
	public void setSgstin(String sgstin) {
		this.sgstin = sgstin;
	}
	public String getCgstin() {
		return cgstin;
	}
	public void setCgstin(String cgstin) {
		this.cgstin = cgstin;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public String getCustCategory() {
		return custCategory;
	}
	public void setCustCategory(String custCategory) {
		this.custCategory = custCategory;
	}
	public String getCustLocationCode() {
		return custLocationCode;
	}
	public void setCustLocationCode(String custLocationCode) {
		this.custLocationCode = custLocationCode;
	}
	public String getCategoryOfService() {
		return categoryOfService;
	}
	public void setCategoryOfService(String categoryOfService) {
		this.categoryOfService = categoryOfService;
	}
	public String getHsnsac() {
		return hsnsac;
	}
	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getPrimaryContactName() {
		return primaryContactName;
	}
	public void setPrimaryContactName(String primaryContactName) {
		this.primaryContactName = primaryContactName;
	}
	public String getPrimaryeMailId() {
		return primaryeMailId;
	}
	public void setPrimaryeMailId(String primaryeMailId) {
		this.primaryeMailId = primaryeMailId;
	}
	public String getPrimaryMobNum() {
		return primaryMobNum;
	}
	public void setPrimaryMobNum(String primaryMobNum) {
		this.primaryMobNum = primaryMobNum;
	}
	public String getSecondaryContactName() {
		return secondaryContactName;
	}
	public void setSecondaryContactName(String secondaryContactName) {
		this.secondaryContactName = secondaryContactName;
	}
	public String getSecondaryeMailId() {
		return secondaryeMailId;
	}
	public void setSecondaryeMailId(String secondaryeMailId) {
		this.secondaryeMailId = secondaryeMailId;
	}
	public String getSecondaryMobNum() {
		return secondaryMobNum;
	}
	public void setSecondaryMobNum(String secondaryMobNum) {
		this.secondaryMobNum = secondaryMobNum;
	}
	public Boolean getIsExempt() {
		return isExempt;
	}
	public void setIsExempt(Boolean isExempt) {
		this.isExempt = isExempt;
	}
	public String getNotificationNum() {
		return notificationNum;
	}
	public void setNotificationNum(String notificationNum) {
		this.notificationNum = notificationNum;
	}
	public Date getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	public String getSerialNum() {
		return serialNum;
	}
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}
	public BigDecimal getIgstrt() {
		return igstrt;
	}
	public void setIgstrt(BigDecimal igstrt) {
		this.igstrt = igstrt;
	}
	public BigDecimal getCgstrt() {
		return cgstrt;
	}
	public void setCgstrt(BigDecimal cgstrt) {
		this.cgstrt = cgstrt;
	}
	public BigDecimal getSgstrt() {
		return sgstrt;
	}
	public void setSgstrt(BigDecimal sgstrt) {
		this.sgstrt = sgstrt;
	}
	public BigDecimal getCessrt() {
		return cessrt;
	}
	public void setCessrt(BigDecimal cessrt) {
		this.cessrt = cessrt;
	}
	public String getIsTds() {
		return isTds;
	}
	public void setIsTds(String isTds) {
		this.isTds = isTds;
	}

}
