/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Shreya.Mukund
 *
 */
public class UserAccessMappingDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String gstnId;
	private String userId;
	private String divisionId;
	private String entityId;
	private String isGroupLevel;
	private String groupId;
	public String getGstnId() {
		return gstnId;
	}
	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDivisionId() {
		return divisionId;
	}
	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getIsGroupLevel() {
		return isGroupLevel;
	}
	public void setIsGroupLevel(String isGroupLevel) {
		this.isGroupLevel = isGroupLevel;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
	

}
