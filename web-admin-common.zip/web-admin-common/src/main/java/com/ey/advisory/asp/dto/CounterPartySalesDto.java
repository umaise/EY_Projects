package com.ey.advisory.asp.dto;

import java.io.Serializable;

public class CounterPartySalesDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long recCount;
	private Double taxableValue;
	private Double invoiceValue;
	private Double igstAmount;
	private Double cgstAmount;
	private Double sgstAmount;
	private Double cessAmountAdvalorem;
	private Double cessAmountSpecific;
	public Long getRecCount() {
		return recCount;
	}
	public void setRecCount(Long recCount) {
		this.recCount = recCount;
	}
	public Double getTaxableValue() {
		return taxableValue;
	}
	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}
	public Double getInvoiceValue() {
		return invoiceValue;
	}
	public void setInvoiceValue(Double invoiceValue) {
		this.invoiceValue = invoiceValue;
	}
	public Double getIgstAmount() {
		return igstAmount;
	}
	public void setIgstAmount(Double igstAmount) {
		this.igstAmount = igstAmount;
	}
	public Double getCgstAmount() {
		return cgstAmount;
	}
	public void setCgstAmount(Double cgstAmount) {
		this.cgstAmount = cgstAmount;
	}
	public Double getSgstAmount() {
		return sgstAmount;
	}
	public void setSgstAmount(Double sgstAmount) {
		this.sgstAmount = sgstAmount;
	}
	public Double getCessAmountAdvalorem() {
		return cessAmountAdvalorem;
	}
	public void setCessAmountAdvalorem(Double cessAmountAdvalorem) {
		this.cessAmountAdvalorem = cessAmountAdvalorem;
	}
	public Double getCessAmountSpecific() {
		return cessAmountSpecific;
	}
	public void setCessAmountSpecific(Double cessAmountSpecific) {
		this.cessAmountSpecific = cessAmountSpecific;
	}
}
