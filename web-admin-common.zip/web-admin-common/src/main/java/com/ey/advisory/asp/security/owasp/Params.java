package com.ey.advisory.asp.security.owasp;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Params implements Serializable
{

@SerializedName("param")
@Expose
private List<Param> param = null;
private final static long serialVersionUID = -4762573775012398872L;

public List<Param> getParam() {
return param;
}

public void setParam(List<Param> param) {
this.param = param;
}

}