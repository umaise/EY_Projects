package com.ey.advisory.asp.security.owasp;

import java.io.Serializable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Application implements Serializable
{

@SerializedName("applicationname")
@Expose
private String applicationname;
@SerializedName("controllers")
@Expose
private Controllers controllers;

private final static long serialVersionUID = 8866105418914203183L;

public String getApplicationname() {
return applicationname;
}

public void setApplicationname(String applicationname) {
this.applicationname = applicationname;
}

public Controllers getControllers() {
return controllers;
}

public void setControllers(Controllers controllers) {
this.controllers = controllers;
}

}