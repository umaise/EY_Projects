package com.ey.advisory.asp.service;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.GroupAzureAdConfigDto;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;

@Service
@PropertySource("classpath:AdFileter.properties")
public class RedirectUrlServiceImpl implements RedirectUrlService {
	
	protected static final Logger LOGGER = Logger
			.getLogger(RedirectUrlServiceImpl.class);
	
	@Value("${redirectHost}")
    private String redirectHost;
	
	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	@Value("${isEyLogin}")
	private String isEyLogin;
	
	
	@Value("${protocol}")
	private String protocol;
	
	@Value("${isAzure}")
	private String isAzure;
	
	
	public String getRedirectHost(HttpServletRequest request) {
		
			//check the Auth Type - SAML Login 
			String domainHost = request.getHeader(Constant.REQUEST_HEADER_KEY_HOST);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("RedirectUrlServiceImpl : Login using Host Name :"+ domainHost);
			
			boolean isSAMLLoginEnabled = isSAMLLoginEnabled(domainHost);
			boolean isEYLoginEnabled = isEYLoginEnabled(isEyLogin);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("RedirectUrlServiceImpl : isSAMLLoginEnabled :"+ isSAMLLoginEnabled +" : isEYLoginEnabled : "+isEYLoginEnabled);
			
			boolean isSelectedDomainFromRedis = isSelectedDomainFromRedis(isEYLoginEnabled, isSAMLLoginEnabled);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("RedirectUrlServiceImpl : isSelectedDomainFromRedis :"+ isSelectedDomainFromRedis);	
		
		   if(isAzure != null && isAzure.trim().equalsIgnoreCase("false")){
			   return redirectHost;
		   }
		   
	       if (isSelectedDomainFromRedis) {
	    	  
				Object obj = redisOp.getValueFromRedis("SelectedDomain", request);
				GroupAzureAdConfigDto grpADdto = (obj == null ? new GroupAzureAdConfigDto() : (GroupAzureAdConfigDto) obj);
				return protocol+"://"+grpADdto.getDomainHost();
				
			}else if(isSAMLLoginEnabled){
				
			    return protocol+"://"+domainHost;
			    
			}else {
				return redirectHost;
			}
	}

	@Override
	public String getRedirectUrl(String action, HttpServletRequest request) {
	
		String url = getRedirectHost(request)+request.getContextPath()+ "/"+action;
		
		return url;
	}
	
	/**
	 * 
	 * @param isEYLoginEnabled
	 * @param isSAMLLoginEnabled
	 * @return TRUE if both are false
	 */
	private boolean isSelectedDomainFromRedis(boolean isEYLoginEnabled, boolean isSAMLLoginEnabled) {
		
		if(!isEYLoginEnabled && !isSAMLLoginEnabled) return true;
		return false;
	}

	/**
	 * 
	 * @param hostName
	 * @return FALSE if SAML is not configured for host in Group Config table
	 */
	private boolean isSAMLLoginEnabled(String hostName) {
		
		if(StringUtils.isEmpty(hostName))  return false;
		String groupCode = redisOp.getValueFromRedisGrpDomainName(hostName);
		if(StringUtils.isEmpty(groupCode)) return false;
		
		return true;
	}

	
	/**
	 * 
	 * @param eyLogin
	 * @return TRUE if EYLogin flag is enabled in Adfilter.properties file
	 */
	private boolean isEYLoginEnabled(String eyLogin){
		
		if(Constant.TRUE.equalsIgnoreCase(eyLogin)) return true;
		return false;
	}
	
}
