package com.ey.advisory.asp.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ApplicationContextEvent;
import org.springframework.context.event.ApplicationListenerMethodAdapter;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.common.Constant;

@Component
public class CustomSAMLAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler{
	//implements ApplicationListener<AuthenticationSuccessEvent>{

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request,
			HttpServletResponse response, Authentication authentication)
			throws ServletException, IOException {
		
			// invalidate session
				boolean anonymous = authentication.getAuthorities().contains( new SimpleGrantedAuthority(Constant.SAML_ROLE_ANONYMOUS));
				
				
				logger.info("CustomSAMLAuthenticationSuccessHandler- SAML -  anonymous: "+anonymous +" : Prinic- "+authentication.getPrincipal());
				if (!anonymous  && ( authentication.getPrincipal()!=null &&  !authentication.getPrincipal().equals("") )) {
	    			//Invalidate the session and create the new one
					//Start - Code added for Session Fixation issue
					HttpSession session = request.getSession(false);
					Object userRedisKey = session==null?null : session.getAttribute("userRedisKey");
				
					if(session!=null ){
						logger.info("SAML - Before Invalidate - HttpSession ID: "+session.getId());
						session.invalidate();
						
						session = request.getSession(true);
						logger.info("SAML - After Invalidate - HttpSession ID: "+session.getId() +" Session RedisKey : "+userRedisKey);
						if(userRedisKey!=null && !userRedisKey.toString().isEmpty())
							session.setAttribute("userRedisKey", userRedisKey);

					}
					//End - Code added for Session Fixation issue
				}
	
				super.onAuthenticationSuccess(request, response, authentication);
			
		
	}

	/*@Override
	public void onApplicationEvent(AuthenticationSuccessEvent authSuccessEvent) {
		
		
		Authentication authentication = authSuccessEvent.getAuthentication();
		boolean anonymous = authentication.getAuthorities().contains( new SimpleGrantedAuthority(Constant.SAML_ROLE_ANONYMOUS));
		
		
		logger.info("CustomSAMLAuthenticationSuccessHandler- SAML -  anonymous: "+anonymous +" : Prinic- "+authentication.getPrincipal());
		if (!anonymous  && ( authentication.getPrincipal()!=null &&  !authentication.getPrincipal().equals("") )) {
			//Invalidate the session and create the new one
			//Start - Code added for Session Fixation issue
			HttpSession session = request.getSession(false);
			Object userRedisKey = session==null?null : session.getAttribute("userRedisKey");
		
			if(session!=null ){
				logger.info("SAML - Before Invalidate - HttpSession ID: "+session.getId());
				session.invalidate();
				
				session = request.getSession(true);
				logger.info("SAML - After Invalidate - HttpSession ID: "+session.getId() +" Session RedisKey : "+userRedisKey);
				if(userRedisKey!=null && !userRedisKey.toString().isEmpty())
					session.setAttribute("userRedisKey", userRedisKey);

			}
			//End - Code added for Session Fixation issue
		}
		
	}*/
}
