package com.ey.advisory.asp.security.azureAd;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserInfoAd implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String passwordProfile;
	
	private String country;
	
	private String sipProxyAddress;
	
	private String preferredLanguage;
	
	private String telephoneNumber;
	
	private String mail;
	
	private String city;
	
	private String dirSyncEnabled;	
	
	private String displayName;	
	
	private String companyName;	
	
	private String jobTitle;	
	
	private String postalCode;
	
	private List provisioningErrors;
	
	private String accountEnabled;
	
	private String objectType;
	
	private String deletionTimestamp;
	
	private String lastDirSyncTime;
	
	private List assignedPlans;
	
	@JsonProperty("odata.type")
	@SerializedName("odata.type")
	private String odataType;
	
	private String surname;
	
	private String passwordPolicies;
	
	private List provisionedPlans;
	
	private String state;
	
	private String department;
	
	private String objectId;
	
	private String userPrincipalName;
	
	private String mailNickname;
	
	private List assignedLicenses;
	
	private String physicalDeliveryOfficeName;
	
	private String givenName;
	
	private String mobile;
	
	private String facsimileTelephoneNumber;
	
	private String onPremisesSecurityIdentifier;
	
	private List proxyAddresses;
	
	private String creationType;
	
	private List otherMails;
	
	@JsonProperty("odata.metadata")
	@SerializedName("odata.metadata")
	private String odataMetadata;
	
	private String immutableId;
	
	private String streetAddress;
	
	private String usageLocation;
	
	private String userType;

	/**
	 * @return the passwordProfile
	 */
	public String getPasswordProfile() {
		return passwordProfile;
	}

	/**
	 * @param passwordProfile the passwordProfile to set
	 */
	public void setPasswordProfile(String passwordProfile) {
		this.passwordProfile = passwordProfile;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the sipProxyAddress
	 */
	public String getSipProxyAddress() {
		return sipProxyAddress;
	}

	/**
	 * @param sipProxyAddress the sipProxyAddress to set
	 */
	public void setSipProxyAddress(String sipProxyAddress) {
		this.sipProxyAddress = sipProxyAddress;
	}

	/**
	 * @return the preferredLanguage
	 */
	public String getPreferredLanguage() {
		return preferredLanguage;
	}

	/**
	 * @param preferredLanguage the preferredLanguage to set
	 */
	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}

	/**
	 * @return the telephoneNumber
	 */
	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	/**
	 * @param telephoneNumber the telephoneNumber to set
	 */
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	/**
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * @param mail the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the dirSyncEnabled
	 */
	public String getDirSyncEnabled() {
		return dirSyncEnabled;
	}

	/**
	 * @param dirSyncEnabled the dirSyncEnabled to set
	 */
	public void setDirSyncEnabled(String dirSyncEnabled) {
		this.dirSyncEnabled = dirSyncEnabled;
	}

	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * @return the jobTitle
	 */
	public String getJobTitle() {
		return jobTitle;
	}

	/**
	 * @param jobTitle the jobTitle to set
	 */
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return the provisioningErrors
	 */
	public List getProvisioningErrors() {
		return provisioningErrors;
	}

	/**
	 * @param provisioningErrors the provisioningErrors to set
	 */
	public void setProvisioningErrors(List provisioningErrors) {
		this.provisioningErrors = provisioningErrors;
	}

	/**
	 * @return the accountEnabled
	 */
	public String getAccountEnabled() {
		return accountEnabled;
	}

	/**
	 * @param accountEnabled the accountEnabled to set
	 */
	public void setAccountEnabled(String accountEnabled) {
		this.accountEnabled = accountEnabled;
	}

	/**
	 * @return the objectType
	 */
	public String getObjectType() {
		return objectType;
	}

	/**
	 * @param objectType the objectType to set
	 */
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	/**
	 * @return the deletionTimestamp
	 */
	public String getDeletionTimestamp() {
		return deletionTimestamp;
	}

	/**
	 * @param deletionTimestamp the deletionTimestamp to set
	 */
	public void setDeletionTimestamp(String deletionTimestamp) {
		this.deletionTimestamp = deletionTimestamp;
	}

	/**
	 * @return the lastDirSyncTime
	 */
	public String getLastDirSyncTime() {
		return lastDirSyncTime;
	}

	/**
	 * @param lastDirSyncTime the lastDirSyncTime to set
	 */
	public void setLastDirSyncTime(String lastDirSyncTime) {
		this.lastDirSyncTime = lastDirSyncTime;
	}

	/**
	 * @return the assignedPlans
	 */
	public List getAssignedPlans() {
		return assignedPlans;
	}

	/**
	 * @param assignedPlans the assignedPlans to set
	 */
	public void setAssignedPlans(List assignedPlans) {
		this.assignedPlans = assignedPlans;
	}

	/**
	 * @return the odataType
	 */
	public String getOdataType() {
		return odataType;
	}

	/**
	 * @param odataType the odataType to set
	 */
	public void setOdataType(String odataType) {
		this.odataType = odataType;
	}

	/**
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * @return the passwordPolicies
	 */
	public String getPasswordPolicies() {
		return passwordPolicies;
	}

	/**
	 * @param passwordPolicies the passwordPolicies to set
	 */
	public void setPasswordPolicies(String passwordPolicies) {
		this.passwordPolicies = passwordPolicies;
	}

	/**
	 * @return the provisionedPlans
	 */
	public List getProvisionedPlans() {
		return provisionedPlans;
	}

	/**
	 * @param provisionedPlans the provisionedPlans to set
	 */
	public void setProvisionedPlans(List provisionedPlans) {
		this.provisionedPlans = provisionedPlans;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return the objectId
	 */
	public String getObjectId() {
		return objectId;
	}

	/**
	 * @param objectId the objectId to set
	 */
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	/**
	 * @return the userPrincipalName
	 */
	public String getUserPrincipalName() {
		return userPrincipalName;
	}

	/**
	 * @param userPrincipalName the userPrincipalName to set
	 */
	public void setUserPrincipalName(String userPrincipalName) {
		this.userPrincipalName = userPrincipalName;
	}

	/**
	 * @return the mailNickname
	 */
	public String getMailNickname() {
		return mailNickname;
	}

	/**
	 * @param mailNickname the mailNickname to set
	 */
	public void setMailNickname(String mailNickname) {
		this.mailNickname = mailNickname;
	}

	/**
	 * @return the assignedLicenses
	 */
	public List getAssignedLicenses() {
		return assignedLicenses;
	}

	/**
	 * @param assignedLicenses the assignedLicenses to set
	 */
	public void setAssignedLicenses(List assignedLicenses) {
		this.assignedLicenses = assignedLicenses;
	}

	/**
	 * @return the physicalDeliveryOfficeName
	 */
	public String getPhysicalDeliveryOfficeName() {
		return physicalDeliveryOfficeName;
	}

	/**
	 * @param physicalDeliveryOfficeName the physicalDeliveryOfficeName to set
	 */
	public void setPhysicalDeliveryOfficeName(String physicalDeliveryOfficeName) {
		this.physicalDeliveryOfficeName = physicalDeliveryOfficeName;
	}

	/**
	 * @return the givenName
	 */
	public String getGivenName() {
		return givenName;
	}

	/**
	 * @param givenName the givenName to set
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the facsimileTelephoneNumber
	 */
	public String getFacsimileTelephoneNumber() {
		return facsimileTelephoneNumber;
	}

	/**
	 * @param facsimileTelephoneNumber the facsimileTelephoneNumber to set
	 */
	public void setFacsimileTelephoneNumber(String facsimileTelephoneNumber) {
		this.facsimileTelephoneNumber = facsimileTelephoneNumber;
	}

	/**
	 * @return the onPremisesSecurityIdentifier
	 */
	public String getOnPremisesSecurityIdentifier() {
		return onPremisesSecurityIdentifier;
	}

	/**
	 * @param onPremisesSecurityIdentifier the onPremisesSecurityIdentifier to set
	 */
	public void setOnPremisesSecurityIdentifier(String onPremisesSecurityIdentifier) {
		this.onPremisesSecurityIdentifier = onPremisesSecurityIdentifier;
	}

	/**
	 * @return the proxyAddresses
	 */
	public List getProxyAddresses() {
		return proxyAddresses;
	}

	/**
	 * @param proxyAddresses the proxyAddresses to set
	 */
	public void setProxyAddresses(List proxyAddresses) {
		this.proxyAddresses = proxyAddresses;
	}

	/**
	 * @return the creationType
	 */
	public String getCreationType() {
		return creationType;
	}

	/**
	 * @param creationType the creationType to set
	 */
	public void setCreationType(String creationType) {
		this.creationType = creationType;
	}

	/**
	 * @return the otherMails
	 */
	public List getOtherMails() {
		return otherMails;
	}

	/**
	 * @param otherMails the otherMails to set
	 */
	public void setOtherMails(List otherMails) {
		this.otherMails = otherMails;
	}

	/**
	 * @return the odataMetadata
	 */
	public String getOdataMetadata() {
		return odataMetadata;
	}

	/**
	 * @param odataMetadata the odataMetadata to set
	 */
	public void setOdataMetadata(String odataMetadata) {
		this.odataMetadata = odataMetadata;
	}

	/**
	 * @return the immutableId
	 */
	public String getImmutableId() {
		return immutableId;
	}

	/**
	 * @param immutableId the immutableId to set
	 */
	public void setImmutableId(String immutableId) {
		this.immutableId = immutableId;
	}

	/**
	 * @return the streetAddress
	 */
	public String getStreetAddress() {
		return streetAddress;
	}

	/**
	 * @param streetAddress the streetAddress to set
	 */
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	/**
	 * @return the usageLocation
	 */
	public String getUsageLocation() {
		return usageLocation;
	}

	/**
	 * @param usageLocation the usageLocation to set
	 */
	public void setUsageLocation(String usageLocation) {
		this.usageLocation = usageLocation;
	}

	/**
	 * @return the userType
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * @param userType the userType to set
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserInfoAd [passwordProfile=" + passwordProfile + ", country=" + country + ", sipProxyAddress="
				+ sipProxyAddress + ", preferredLanguage=" + preferredLanguage + ", telephoneNumber=" + telephoneNumber
				+ ", mail=" + mail + ", city=" + city + ", dirSyncEnabled=" + dirSyncEnabled + ", displayName="
				+ displayName + ", companyName=" + companyName + ", jobTitle=" + jobTitle + ", postalCode=" + postalCode
				+ ", provisioningErrors=" + provisioningErrors + ", accountEnabled=" + accountEnabled + ", objectType="
				+ objectType + ", deletionTimestamp=" + deletionTimestamp + ", lastDirSyncTime=" + lastDirSyncTime
				+ ", assignedPlans=" + assignedPlans + ", odataType=" + odataType + ", surname=" + surname
				+ ", passwordPolicies=" + passwordPolicies + ", provisionedPlans=" + provisionedPlans + ", state="
				+ state + ", department=" + department + ", objectId=" + objectId + ", userPrincipalName="
				+ userPrincipalName + ", mailNickname=" + mailNickname + ", assignedLicenses=" + assignedLicenses
				+ ", physicalDeliveryOfficeName=" + physicalDeliveryOfficeName + ", givenName=" + givenName
				+ ", mobile=" + mobile + ", facsimileTelephoneNumber=" + facsimileTelephoneNumber
				+ ", onPremisesSecurityIdentifier=" + onPremisesSecurityIdentifier + ", proxyAddresses="
				+ proxyAddresses + ", creationType=" + creationType + ", otherMails=" + otherMails + ", odataMetadata="
				+ odataMetadata + ", immutableId=" + immutableId + ", streetAddress=" + streetAddress
				+ ", usageLocation=" + usageLocation + ", userType=" + userType + "]";
	}
	
	
	
	
	

}
