package com.ey.advisory.asp.dto;

public class DueDateMasterTable {
	
	private Long returnId;
	private String gstnId;
	private String applicableReturn; 
	private java.util.Date dueDates;
	private java.util.Date gstnMandatedDate;
	
	
	//Column 'GstnMandatedDate' is for anticipated future use. When such a field will be asked to be added, this column mapping will be created here as well
	
	
	public java.util.Date getGstnMandatedDate() {
		return gstnMandatedDate;
	}
	public void setGstnMandatedDate(java.util.Date gstnMandatedDate) {
		this.gstnMandatedDate = gstnMandatedDate;
	}

	public String getApplicableReturn() {
		return applicableReturn;
	}
	
	public Long getReturnId() {
		return returnId;
	}
	public void setReturnId(Long returnId) {
		this.returnId = returnId;
	}
	public String getGstnId() {
		return gstnId;
	}
	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}
	public void setApplicableReturn(String applicableReturn) {
		this.applicableReturn = applicableReturn;
	}
	public java.util.Date getDueDates() {
		return dueDates;
	}
	public void setDueDates(java.util.Date dueDates) {
		this.dueDates = dueDates;
	}
	

}
