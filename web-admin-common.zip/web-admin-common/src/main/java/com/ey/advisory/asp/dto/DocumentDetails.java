/**
 * 
 */
package com.ey.advisory.asp.dto;



/**
 * @author Uma.Chandranaik
 *
 */
public class DocumentDetails {
	
	private String docId;
	private YearMonthDto  yearMonthDto;
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public YearMonthDto getYearMonthDto() {
		return yearMonthDto;
	}
	public void setYearMonthDto(YearMonthDto yearMonthDto) {
		this.yearMonthDto = yearMonthDto;
	}
	@Override
	public String toString() {
		return "DocumentDetails [docId=" + docId + ", yearMonthDto=" + yearMonthDto + "]";
	}
	
	

}
