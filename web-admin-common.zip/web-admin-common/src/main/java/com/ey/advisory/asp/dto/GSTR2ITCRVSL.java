package com.ey.advisory.asp.dto;

public class GSTR2ITCRVSL {

	private Long id;
	
	private Character flag;
	
	private String checksum;
	
	private String reason;
	
	private Float igstRt;

	private Float igstAmt;

	private Float cgstRt;

	private Float cgstAmt;

	private Float sgstRt;

	private Float sgstAmt;
	
	private Long taxPayerID;
	
	private Float txbleValue;

	private int invoiceCnt;
	
	private Float igstTotal;
	
	private Float cgstTotal;

	private Float sgstTotal;
	
	/**
	 * @return the flag
	 */
	public Character getFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(Character flag) {
		this.flag = flag;
	}

	/**
	 * @return the checksum
	 */
	public String getChecksum() {
		return checksum;
	}

	/**
	 * @param checksum the checksum to set
	 */
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	/**
	 * @return the igstRt
	 */
	public Float getIgstRt() {
		return igstRt;
	}

	/**
	 * @param igstRt the igstRt to set
	 */
	public void setIgstRt(Float igstRt) {
		this.igstRt = igstRt;
	}

	/**
	 * @return the igstAmt
	 */
	public Float getIgstAmt() {
		return igstAmt;
	}

	/**
	 * @param igstAmt the igstAmt to set
	 */
	public void setIgstAmt(Float igstAmt) {
		this.igstAmt = igstAmt;
	}

	/**
	 * @return the cgstRt
	 */
	public Float getCgstRt() {
		return cgstRt;
	}

	/**
	 * @param cgstRt the cgstRt to set
	 */
	public void setCgstRt(Float cgstRt) {
		this.cgstRt = cgstRt;
	}

	/**
	 * @return the cgstAmt
	 */
	public Float getCgstAmt() {
		return cgstAmt;
	}

	/**
	 * @param cgstAmt the cgstAmt to set
	 */
	public void setCgstAmt(Float cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	/**
	 * @return the sgstRt
	 */
	public Float getSgstRt() {
		return sgstRt;
	}

	/**
	 * @param sgstRt the sgstRt to set
	 */
	public void setSgstRt(Float sgstRt) {
		this.sgstRt = sgstRt;
	}

	/**
	 * @return the sgstAmt
	 */
	public Float getSgstAmt() {
		return sgstAmt;
	}

	/**
	 * @param sgstAmt the sgstAmt to set
	 */
	public void setSgstAmt(Float sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	/**
	 * @return the taxPayerID
	 */
	public long getTaxPayerID() {
		return taxPayerID;
	}

	/**
	 * @param taxPayerID the taxPayerID to set
	 */
	public void setTaxPayerID(long taxPayerID) {
		this.taxPayerID = taxPayerID;
	}

	/**
	 * @return the txbleValue
	 */
	public Float getTxbleValue() {
		return txbleValue;
	}

	/**
	 * @param txbleValue the txbleValue to set
	 */
	public void setTxbleValue(Float txbleValue) {
		this.txbleValue = txbleValue;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setTaxPayerID(Long taxPayerID) {
		this.taxPayerID = taxPayerID;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}

	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}

	public Float getCgstTotal() {
		return cgstTotal;
	}

	public void setCgstTotal(Float cgstTotal) {
		this.cgstTotal = cgstTotal;
	}

	public Float getSgstTotal() {
		return sgstTotal;
	}

	public void setSgstTotal(Float sgstTotal) {
		this.sgstTotal = sgstTotal;
	}
	
	
	
}
