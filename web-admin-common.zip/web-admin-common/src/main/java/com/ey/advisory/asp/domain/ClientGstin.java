package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ClientGstin implements Serializable{

	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String gstinId;
	private String stateCode;
	private String gSTNUserName;
	private Double turnOverAmount;
	private String typeOfReg;
	private Boolean isActive;
	private Boolean isRegCertificate;
	private Integer entityID;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
	private Date createdDate;
	private String createdBy;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
	private Date updatedDate;
	private String updatedBy;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	private Date regdt;
	private String regMobileNumber;
	private Double quarterTurnOvrAmt;
	private String bankAccountNumber;
    public String getGstinId() {
        return gstinId;
    }
    public void setGstinId(String gstinId) {
        this.gstinId = gstinId;
    }
    public String getStateCode() {
        return stateCode;
    }
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }
    public String getgSTNUserName() {
        return gSTNUserName;
    }
    public void setgSTNUserName(String gSTNUserName) {
        this.gSTNUserName = gSTNUserName;
    }
    public Double getTurnOverAmount() {
        return turnOverAmount;
    }
    public void setTurnOverAmount(Double turnOverAmount) {
        this.turnOverAmount = turnOverAmount;
    }
    public String getTypeOfReg() {
        return typeOfReg;
    }
    public void setTypeOfReg(String typeOfReg) {
        this.typeOfReg = typeOfReg;
    }
    public Boolean getIsActive() {
        return isActive;
    }
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public Boolean getIsRegCertificate() {
        return isRegCertificate;
    }
    public void setIsRegCertificate(Boolean isRegCertificate) {
        this.isRegCertificate = isRegCertificate;
    }
    public Integer getEntityID() {
        return entityID;
    }
    public void setEntityID(Integer entityID) {
        this.entityID = entityID;
    }
    public Date getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
    public String getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    public Date getUpdatedDate() {
        return updatedDate;
    }
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }
    public String getUpdatedBy() {
        return updatedBy;
    }
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
    public Date getRegdt() {
        return regdt;
    }
    public void setRegdt(Date regdt) {
        this.regdt = regdt;
    }
    public String getRegMobileNumber() {
        return regMobileNumber;
    }
    public void setRegMobileNumber(String regMobileNumber) {
        this.regMobileNumber = regMobileNumber;
    }
    public Double getQuarterTurnOvrAmt() {
		return quarterTurnOvrAmt;
	}
	public void setQuarterTurnOvrAmt(Double quarterTurnOvrAmt) {
		this.quarterTurnOvrAmt = quarterTurnOvrAmt;
	}
	public String getBankAccountNumber() {
        return bankAccountNumber;
    }
    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    } 
	
	
	
}
