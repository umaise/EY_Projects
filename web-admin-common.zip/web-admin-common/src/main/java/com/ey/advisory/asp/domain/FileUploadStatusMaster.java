package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.Date;


public class FileUploadStatusMaster implements Serializable{
	
	public FileUploadStatusMaster(){
		super();
	}
	
	private static final long serialVersionUID = 1L;
		
		private Integer fileId;
		private long userId;
		private String fName;
		private String fileType;
		private	String filePath;
		private	String dataType;
		private Integer entityId;
		private	String gstin;
		private	Integer mapId;
		private String status;
		private String stage;
		private	Date uploadDt;
		private	Date updatedDt;
		private	String errorDesc;
		private Integer totalErrorInvoices;
		private Integer totalInvoices;
		private Boolean isMagic;
		private String uiDate;
		
		public Integer getFileId() {
			return fileId;
		}
		public void setFileId(Integer fileId) {
			this.fileId = fileId;
		}
		public long getUserId() {
			return userId;
		}
		public void setUserId(long userId) {
			this.userId = userId;
		}
		public String getfName() {
			return fName;
		}
		public void setfName(String fName) {
			this.fName = fName;
		}
		public String getFileType() {
			return fileType;
		}
		public void setFileType(String fileType) {
			this.fileType = fileType;
		}
		public String getFilePath() {
			return filePath;
		}
		public void setFilePath(String filePath) {
			this.filePath = filePath;
		}
		public String getDataType() {
			return dataType;
		}
		public void setDataType(String dataType) {
			this.dataType = dataType;
		}
		public Integer getEntityId() {
			return entityId;
		}
		public void setEntityId(Integer entityId) {
			this.entityId = entityId;
		}
		public String getGstin() {
			return gstin;
		}
		public void setGstin(String gstin) {
			this.gstin = gstin;
		}
		public Integer getMapId() {
			return mapId;
		}
		public void setMapId(Integer mapId) {
			this.mapId = mapId;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getStage() {
			return stage;
		}
		public void setStage(String stage) {
			this.stage = stage;
		}
		public Date getUploadDt() {
			return uploadDt;
		}
		public void setUploadDt(Date uploadDt) {
			this.uploadDt = uploadDt;
		}
		public Date getUpdatedDt() {
			return updatedDt;
		}
		public void setUpdatedDt(Date updatedDt) {
			this.updatedDt = updatedDt;
		}
		public String getErrorDesc() {
			return errorDesc;
		}
		public void setErrorDesc(String errorDesc) {
			this.errorDesc = errorDesc;
		}
		public Integer getTotalErrorInvoices() {
			return totalErrorInvoices;
		}
		public void setTotalErrorInvoices(Integer totalErrorInvoices) {
			this.totalErrorInvoices = totalErrorInvoices;
		}
		public Integer getTotalInvoices() {
			return totalInvoices;
		}
		public void setTotalInvoices(Integer totalInvoices) {
			this.totalInvoices = totalInvoices;
		}
		public Boolean getIsMagic() {
			return isMagic;
		}
		public void setIsMagic(Boolean isMagic) {
			this.isMagic = isMagic;
		}
		public String getUiDate() {
			return uiDate;
		}
		public void setUiDate(String uiDate) {
			this.uiDate = uiDate;
		}
		@Override
		public String toString() {
			return "FileUploadStatusMaster [fileId=" + fileId + ", userId="
					+ userId + ", fName=" + fName + ", fileType=" + fileType
					+ ", filePath=" + filePath + ", dataType=" + dataType
					+ ", entityId=" + entityId + ", gstin=" + gstin
					+ ", mapId=" + mapId + ", status=" + status + ", stage="
					+ stage + ", uploadDt=" + uploadDt + ", updatedDt="
					+ updatedDt + ", errorDesc=" + errorDesc
					+ ", totalErrorInvoices=" + totalErrorInvoices
					+ ", totalInvoices=" + totalInvoices + ", isMagic="
					+ isMagic + ", uiDate=" + uiDate + "]";
		}
	
		
	
	
}
