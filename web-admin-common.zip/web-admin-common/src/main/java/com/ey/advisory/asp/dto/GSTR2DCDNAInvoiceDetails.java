package com.ey.advisory.asp.dto;


import java.io.Serializable;
import java.sql.Date;

public class GSTR2DCDNAInvoiceDetails implements Serializable{ 

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

private long id;

private String custGSTIN;

private String invTyp;

private String custName;

private Character flag;

private String chksum;

private String noteTyp;

private String ctin;

private String noteNum;

private Date noteDate;


private String orgNoteNum;

private Date orgNoteDate;


private String reason;

private Float diffValue;

private Float igstRate;

private Float igstAmt;

private Float cgstRate;

private Float cgstAmt;

private Float sgstRate;

private Float sgstAmt;

private String itcEligiblity;

private Float itcIGSTAmt;

private Float itcCGSTAmt;

private Float itcSGSTAmt;

private Float tcIGSTAmt;

private Float tcCGSTAmt;

private Float tcSGSTAmt;

private long taxPayerID;

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getCustGSTIN() {
	return custGSTIN;
}

public void setCustGSTIN(String custGSTIN) {
	this.custGSTIN = custGSTIN;
}

public String getInvTyp() {
	return invTyp;
}

public void setInvTyp(String invTyp) {
	this.invTyp = invTyp;
}

public String getCustName() {
	return custName;
}

public void setCustName(String custName) {
	this.custName = custName;
}

public Character getFlag() {
	return flag;
}

public void setFlag(Character flag) {
	this.flag = flag;
}

public String getChksum() {
	return chksum;
}

public void setChksum(String chksum) {
	this.chksum = chksum;
}

public String getNoteTyp() {
	return noteTyp;
}

public void setNoteTyp(String noteTyp) {
	this.noteTyp = noteTyp;
}

public String getCtin() {
	return ctin;
}

public void setCtin(String ctin) {
	this.ctin = ctin;
}


public Date getNoteDate() {
	return noteDate;
}

public void setNoteDate(Date noteDate) {
	this.noteDate = noteDate;
}

public String getOrgNoteNum() {
	return orgNoteNum;
}

public void setOrgNoteNum(String orgNoteNum) {
	this.orgNoteNum = orgNoteNum;
}

public Date getOrgNoteDate() {
	return orgNoteDate;
}

public void setOrgNoteDate(Date orgNoteDate) {
	this.orgNoteDate = orgNoteDate;
}

public String getReason() {
	return reason;
}

public void setReason(String reason) {
	this.reason = reason;
}

public Float getDiffValue() {
	return diffValue;
}

public void setDiffValue(Float diffValue) {
	this.diffValue = diffValue;
}

public Float getIgstRate() {
	return igstRate;
}

public void setIgstRate(Float igstRate) {
	this.igstRate = igstRate;
}

public Float getIgstAmt() {
	return igstAmt;
}

public void setIgstAmt(Float igstAmt) {
	this.igstAmt = igstAmt;
}

public Float getCgstRate() {
	return cgstRate;
}

public void setCgstRate(Float cgstRate) {
	this.cgstRate = cgstRate;
}

public Float getCgstAmt() {
	return cgstAmt;
}

public void setCgstAmt(Float cgstAmt) {
	this.cgstAmt = cgstAmt;
}

public Float getSgstRate() {
	return sgstRate;
}

public void setSgstRate(Float sgstRate) {
	this.sgstRate = sgstRate;
}

public Float getSgstAmt() {
	return sgstAmt;
}

public void setSgstAmt(Float sgstAmt) {
	this.sgstAmt = sgstAmt;
}

public String getItcEligiblity() {
	return itcEligiblity;
}

public void setItcEligiblity(String itcEligiblity) {
	this.itcEligiblity = itcEligiblity;
}

public Float getItcIGSTAmt() {
	return itcIGSTAmt;
}

public void setItcIGSTAmt(Float itcIGSTAmt) {
	this.itcIGSTAmt = itcIGSTAmt;
}

public Float getItcCGSTAmt() {
	return itcCGSTAmt;
}

public void setItcCGSTAmt(Float itcCGSTAmt) {
	this.itcCGSTAmt = itcCGSTAmt;
}

public Float getItcSGSTAmt() {
	return itcSGSTAmt;
}

public void setItcSGSTAmt(Float itcSGSTAmt) {
	this.itcSGSTAmt = itcSGSTAmt;
}

public Float getTcIGSTAmt() {
	return tcIGSTAmt;
}

public void setTcIGSTAmt(Float tcIGSTAmt) {
	this.tcIGSTAmt = tcIGSTAmt;
}

public Float getTcCGSTAmt() {
	return tcCGSTAmt;
}

public void setTcCGSTAmt(Float tcCGSTAmt) {
	this.tcCGSTAmt = tcCGSTAmt;
}

public Float getTcSGSTAmt() {
	return tcSGSTAmt;
}

public void setTcSGSTAmt(Float tcSGSTAmt) {
	this.tcSGSTAmt = tcSGSTAmt;
}

public long getTaxPayerID() {
	return taxPayerID;
}

public void setTaxPayerID(long taxPayerID) {
	this.taxPayerID = taxPayerID;
}

public String getNoteNum() {
	return noteNum;
}

public void setNoteNum(String noteNum) {
	this.noteNum = noteNum;
}



}
