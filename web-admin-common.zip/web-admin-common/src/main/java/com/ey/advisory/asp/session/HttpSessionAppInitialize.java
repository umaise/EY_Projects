package com.ey.advisory.asp.session;

import org.springframework.session.web.context.AbstractHttpSessionApplicationInitializer;

public class HttpSessionAppInitialize{ /*extends AbstractHttpSessionApplicationInitializer {
	public HttpSessionAppInitialize() {
		super();
	}*/
}