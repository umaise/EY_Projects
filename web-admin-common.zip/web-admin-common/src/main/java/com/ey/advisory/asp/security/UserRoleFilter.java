/**
 * 
 */
package com.ey.advisory.asp.security;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.domain.User;
import com.ey.advisory.asp.dto.GroupAzureAdConfigDto;
import com.ey.advisory.asp.dto.GroupDto;
import com.ey.advisory.asp.dto.RoleDto;
import com.ey.advisory.asp.security.azureAd.AuthHelper;
import com.ey.advisory.asp.security.azureAd.HttpClientHelper;
import com.ey.advisory.asp.security.azureAd.UserInfoAd;
import com.ey.advisory.asp.service.SecurityLogsService;
import com.ey.advisory.asp.service.UserRoleService;
import com.ey.advisory.asp.util.CommonUtility;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;
import com.google.gson.Gson;
import com.microsoft.aad.adal4j.AuthenticationResult;

/**
 * @author Nitesh.Tripathi
 *
 */
@Component("myRolesFilter")
@PropertySource("classpath:AdFileter.properties")
public class UserRoleFilter implements Filter {
	
	@Value("${isAzure}")
    private String isAzure;
	
	@Value("${graphAPI}")
    private String graphAPI;
	
	@Value("${graphAPIVersion}")
    private String graphAPIVersion;
	
	@Value("${tenant}")
    private String tenant;
	
	@Value("${authority}")
    private String authority;
	
	@Value("${admin.rolename}")
    private String adminRolename;
	
	
	@Value("${adminLogin}")
    private String adminLogin;
	
	@Value("${isEyLogin}")
	private String isEyLogin;
	
	
	
	/**
	 * @return the graphAPI
	 */
	public String getGraphAPI() {
		return graphAPI;
	}

	/**
	 * @param graphAPI the graphAPI to set
	 */
	public void setGraphAPI(String graphAPI) {
		this.graphAPI = graphAPI;
	}

	/**
	 * @return the graphAPIVersion
	 */
	public String getGraphAPIVersion() {
		return graphAPIVersion;
	}

	/**
	 * @param graphAPIVersion the graphAPIVersion to set
	 */
	public void setGraphAPIVersion(String graphAPIVersion) {
		this.graphAPIVersion = graphAPIVersion;
	}

	/**
	 * @return the tenant
	 */
	public String getTenant(HttpServletRequest request) {
		 if ("false".equalsIgnoreCase(isEyLogin)) {
				
				Object obj = redisOp.getValueFromRedis("SelectedDomain", request);
				GroupAzureAdConfigDto grpADdto = (obj == null ? new GroupAzureAdConfigDto() : (GroupAzureAdConfigDto) obj);
				return grpADdto.getaDTennet();
				
			}else{
				
				return tenant;
			}
	}

	/**
	 * @param tenant the tenant to set
	 */
	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	/**
	 * @return the redirectHost
	 */
	public String getRedirectHost(HttpServletRequest request) {
		 if ("false".equalsIgnoreCase(isEyLogin)) {
				
				Object obj = redisOp.getValueFromRedis("SelectedDomain", request);
				GroupAzureAdConfigDto grpADdto = (obj == null ? new GroupAzureAdConfigDto() : (GroupAzureAdConfigDto) obj);
				return "https://"+grpADdto.getDomainHost();
				
			}else{
				
			    return redirectHost;
			}
	}
	
	public String getRedirectUrl(String url, HttpServletRequest request){
	     return getRedirectHost(request)+request.getContextPath()+ url;
	}
	

	/**
	 * @param redirectHost the redirectHost to set
	 */
	public void setRedirectHost(String redirectHost) {
		this.redirectHost = redirectHost;
	}

	@Value("${redirectHost}")
    private String redirectHost;

	private static final Logger LOGGER = Logger.getLogger(UserRoleFilter.class);
	
	@Autowired
	private UserRoleService userRoleService;
	

	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	@Autowired
	private SecurityLogsService securityLogsService;
			
	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		try {
			if (!isAzure.equalsIgnoreCase(Constant.TRUE)) {

				chain.doFilter(request, response);
				return;
			}

			if (request instanceof HttpServletRequest) {

				HttpSession session = httpRequest.getSession(false);

				User user1 = null;
				Object userObj = redisOp.getValueFromRedis(Constant.CURRENTUSER, (HttpServletRequest) request);
				if (userObj != null) {
					user1 = (User) userObj;
				}

				LOGGER.info("excluded getRequestURI :" + httpRequest.getRequestURL());
				if (user1 != null || CommonUtility.isExcluded(httpRequest)) {
					if(user1 != null){
						if(user1.getUserName()!=null){
							MDC.put(Constant.USER_PRINCIPAL, user1.getUserName());
						}
						MDC.put(Constant.CLIENT_IP, getClientIp(request));
					}
					
					if (user1 != null && adminLogin.equalsIgnoreCase(Constant.TRUE)) {
						boolean isAdmin = false;
						Set<RoleDto> rDtoSet = user1.getRoleSet();
						for (RoleDto rDto : rDtoSet) {
							if (rDto.getRoleName().equalsIgnoreCase(adminRolename)) {
								isAdmin = true;
								break;
							}
						}

						if (!isAdmin) {
							LOGGER.error("Not an Admin:");
							httpResponse.setStatus(500);
							request.setAttribute("error", "Not an Admin");
							String url = getRedirectUrl("/error.jsp", (HttpServletRequest) request);
							httpResponse.sendRedirect(url);
							return;
						}

					}
					chain.doFilter(request, response);
					return;
				}

				AuthenticationResult result = (AuthenticationResult) redisOp
						.getValueFromRedis(AuthHelper.PRINCIPAL_SESSION_NAME, (HttpServletRequest) request);
				LOGGER.info("in UserRoleFilter.doFilter " + result);
				String userPrincipalName = null;
				UserInfoAd data = null;

				Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

				if (authentication != null && authentication.isAuthenticated()) {
					boolean anonymous = authentication.getAuthorities()
							.contains(new SimpleGrantedAuthority(Constant.SAML_ROLE_ANONYMOUS));
					if (!anonymous) {

						userPrincipalName = authentication.getPrincipal().toString();
					} else if (result.getAccessToken() != null) {

						data = this.getUsernamesFromGraph(result.getAccessToken(),
								getTenant((HttpServletRequest) request), (HttpServletRequest) request);
						userPrincipalName = data.getUserPrincipalName();

						boolean isValidUser = validateDomain(userPrincipalName, (HttpServletRequest) request);
						if (!isValidUser) {
							LOGGER.info("userPrincipalName is not Valid for this group/client :-" + userPrincipalName);
							String url = getRedirectUrl("/logout", (HttpServletRequest) request);
							httpResponse.sendRedirect(url);
							return;
						}
					}
				} else {
					data = this.getUsernamesFromGraph(result.getAccessToken(), getTenant((HttpServletRequest) request),
							(HttpServletRequest) request);
					userPrincipalName = data.getUserPrincipalName();

					boolean isValidUser = validateDomain(userPrincipalName, (HttpServletRequest) request);
					if (!isValidUser) {
						LOGGER.info("userPrincipalName is not Valid for this group/client :-" + userPrincipalName);
						String url = getRedirectUrl("/logout", (HttpServletRequest) request);
						httpResponse.sendRedirect(url);
						return;
					}

				}
				
				if (userPrincipalName != null && !"".equals(userPrincipalName)) {
					MDC.put(Constant.USER_PRINCIPAL, userPrincipalName);
				} else {
					MDC.put(Constant.USER_PRINCIPAL, Constant.UNKNOWN_USER);
				}
				// Get Client IP
				MDC.put(Constant.CLIENT_IP, getClientIp(request));

				LOGGER.info("userPrincipalName :-" + userPrincipalName);

				com.ey.advisory.asp.domain.User user = userRoleService.getUserDetails(userPrincipalName);

				if (user != null) {

					redisOp.setValueToRedis(Constant.CURRENTUSER, user, httpRequest);

					Set<GroupDto> groupDto = user.getGroupDto();
					redisOp.setValueToRedis(Constant.USER_GROUP, getGroupDto(groupDto), httpRequest);

					session.setAttribute("AdUserInfo", data);
					redisOp.setGroupSetToRedis(groupDto, httpRequest);
					
					GroupDto gdto = getGroupDto(user.getGroupDto());
					redisOp.setValueToRedis(Constant.GROUP_NAME, gdto.getGroupName(), httpRequest);


					if (adminLogin.equalsIgnoreCase(Constant.TRUE)) {
						boolean isAdmin = false;
						Set<RoleDto> rDtoSet = user.getRoleSet();
						for (RoleDto rDto : rDtoSet) {
							if (rDto.getRoleName().equalsIgnoreCase(adminRolename)) {
								isAdmin = true;
								break;
							}
						}

						if (!isAdmin) {
							LOGGER.error("Not an Admin:");
							httpResponse.setStatus(500);
							request.setAttribute("error", "Not an Admin");
							String url = getRedirectUrl("/error.jsp", (HttpServletRequest) request);
							httpResponse.sendRedirect(url);
							return;
						}

					}

					LOGGER.debug("groupDto.size() :- " + groupDto.size());
					// LOGGER.debug("groupDto :- "+groupDto);
					if (groupDto.size() > 1 && "true".equalsIgnoreCase(isEyLogin)) {

						LOGGER.debug("inside : - groupDto.size()>1");

						String fullUrl = getRedirectHost(httpRequest) + httpRequest.getRequestURI()
								+ (httpRequest.getQueryString() != null ? "?" + httpRequest.getQueryString() : "");

						// LOGGER.debug("LOGGER.debug(fullUrl); "+fullUrl);

						RequestDispatcher rd = httpRequest.getServletContext().getRequestDispatcher("/selectGroupAsso");
						LOGGER.debug(fullUrl);

						rd.forward(httpRequest, httpResponse);
						return;

					}
				}

			}

			chain.doFilter(request, response);

			return;
		} catch (Exception e) {
			LOGGER.error("UserRoleFilter.doFilter error :not authenticated Error :-" + e, e);
			httpResponse.setStatus(500);
			request.setAttribute("error", e.getMessage());
			String url = getRedirectUrl("/error.jsp", (HttpServletRequest) request);
			httpResponse.sendRedirect(url);
			return;
		} finally {
			//LOGGER.info("Invoked UserRoleFilter ending @ "+System.currentTimeMillis());
			if(MDC.getContext().containsKey(Constant.USER_PRINCIPAL)){
				//LOGGER.info("Removing principle name from MDC context.");
				MDC.remove(Constant.USER_PRINCIPAL);
			}
			if(MDC.getContext().containsKey(Constant.CLIENT_IP)){
				//LOGGER.info("Removing client ip name from MDC context.");
				MDC.remove(Constant.CLIENT_IP);
			}
		}

	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
	}
	
	 private UserInfoAd getUsernamesFromGraph(String accessToken, String tenant,HttpServletRequest request) throws IOException {
	    	
	    	LOGGER.error( "in AadController.getUsernamesFromGraph ");//+accessToken);
	   
	    	URL url = new URL(graphAPI+"/"+tenant+"/me?api-version="+graphAPIVersion);
	     	LOGGER.error( url.toString());
	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	        // Set the appropriate header fields in the request header.
	        conn.setRequestProperty("api-version", graphAPIVersion);
	        conn.setRequestProperty("Authorization", "Bearer "+accessToken);
	        conn.setRequestProperty("Accept", "application/json;odata=minimalmetadata");
	        String goodRespStr = HttpClientHelper.getResponseStringFromConn(conn, true);
	        int responseCode = conn.getResponseCode();
	        LOGGER.error(goodRespStr);
	        LOGGER.error(responseCode+"responseCode");
	        Gson gson=new Gson();
	        UserInfoAd user = gson.fromJson(goodRespStr, UserInfoAd.class);
	        
	        securityLogsService.loginDetails(request,"Logged in User "+user.getUserPrincipalName());
	        
	        return user;
	        
	        
	    }
	 
	 public boolean isAuthenticated(HttpServletRequest request) {

			LOGGER.info(" in isAuthenticated(HttpServletRequest request)");

			AuthenticationResult auth = (AuthenticationResult) redisOp.getValueFromRedis(AuthHelper.PRINCIPAL_SESSION_NAME,
					request);
			LOGGER.info(" in isAuthenticated(HttpServletRequest request) :auth = " + auth);

			return auth != null;
		}

		public AuthenticationResult getAuthSessionObject(HttpServletRequest request) {

			LOGGER.info(" in getAuthSessionObject(HttpServletRequest request)");

			AuthenticationResult auth = (AuthenticationResult) redisOp.getValueFromRedis(AuthHelper.PRINCIPAL_SESSION_NAME,
					request);
			LOGGER.info(" in getAuthSessionObject(HttpServletRequest request) :auth = " + auth);

			return auth;

		}
	 
	 /*public static void main(String args[]){
	    String str = "\\asp\\index\\home";
	    String str1 = str.substring(str.lastIndexOf("\\"));
	 }*/
			 
	 private GroupDto getGroupDto(Set<GroupDto> groupDto) {
			GroupDto grpDto = new GroupDto();

			for (GroupDto groupDtoTmp : groupDto) {

				if (groupDtoTmp != null) {
					grpDto = groupDtoTmp;
					break;
				}

			}

			return grpDto;

		}
	 
	 private boolean validateDomain(String username,HttpServletRequest request){
		 
		String userdomain =  username.substring(username.indexOf("@")+1);
		boolean isValid = false;
		 if ("false".equalsIgnoreCase(isEyLogin)) {
				
				Object obj = redisOp.getValueFromRedis("SelectedDomain", request);
				GroupAzureAdConfigDto grpADdto = (obj == null ? new GroupAzureAdConfigDto() : (GroupAzureAdConfigDto) obj);
				String grpuserdomain = grpADdto.getUserDomains();
				if(grpuserdomain.contains(userdomain)){
				
					isValid = true;
					
				}
				
				
			}else{
				
				isValid = true;
			}
		 
		 
		 return isValid;
	 }
	 
	 private boolean isAzureLoginEnabled(String eyLogin){
			
			if(Constant.FALSE.equalsIgnoreCase(isEyLogin)) return true;
			
			return false;
		}
		
	 
	private String getClientIp(ServletRequest request){
		String clientIp="";
		try{
			if(request instanceof HttpServletRequest){
				HttpServletRequest httpRequest=(HttpServletRequest) request;
				clientIp=httpRequest.getHeader("X-FORWARDED-FOR");
			}
			if (clientIp == null || "".equals(clientIp)){
				clientIp = request.getRemoteAddr();
			}
		}catch (Exception e) {
      	  
     	   LOGGER.error("Exception in getClientIp : ",e);
			
		}
		return clientIp;
	}	
}
