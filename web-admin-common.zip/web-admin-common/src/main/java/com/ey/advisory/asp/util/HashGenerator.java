/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ey.advisory.asp.util;

import java.security.MessageDigest;
import org.apache.log4j.Logger;

public class HashGenerator {
	
	private static final Logger LOGGER = Logger.getLogger(HashGenerator.class);
	private static final String CLASS_NAME = HashGenerator.class.getName();
	
	public byte[] generateSha256Hash(byte[] message) {
		String algorithm = "SHA-256";
		String securityProvider = "BC";

		byte[] hash = null;

		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance(algorithm, securityProvider);
			digest.reset();
			hash = digest.digest(message);
		} catch (Exception e) {
			LOGGER.info("Exception in " + CLASS_NAME+ " Method : generateSha256Hash",e);
		}

		return hash;
	}

}
