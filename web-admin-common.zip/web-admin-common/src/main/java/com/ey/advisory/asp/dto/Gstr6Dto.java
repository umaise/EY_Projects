package com.ey.advisory.asp.dto;

import java.util.Date;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author Nilanjan.Karmakar
 *
 */
public class Gstr6Dto {

	@NotNull
	@Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	private String gstin;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String fromDate;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String toDate;
	@NotNull
	@Pattern(regexp = "^[0-9]+$")
	private String rtPeriod;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String liabType;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String provisionalDetails;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String finalDetails;
	private String jsonData;
	
	private Object[] isFiled;
	
	private Date currentDate;
	private boolean isPrevMonth;
	private Date dtFromDate;
	private Date dtToDate;
	
	private boolean isFileEndDate;
	@Digits(fraction = 0, integer =10)
	private int days;
	
	private String prevJsonData;
	private String currJsonData;

	public Date getDtFromDate() {
		return dtFromDate;
	}
	public void setDtFromDate(Date dtFromDate) {
		this.dtFromDate = dtFromDate;
	}
	public Date getDtToDate() {
		return dtToDate;
	}
	public void setDtToDate(Date dtToDate) {
		this.dtToDate = dtToDate;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getRtPeriod() {
		return rtPeriod;
	}
	public void setRtPeriod(String rtPeriod) {
		this.rtPeriod = rtPeriod;
	}
	public String getProvisionalDetails() {
		return provisionalDetails;
	}
	public void setProvisionalDetails(String provisionalDetails) {
		this.provisionalDetails = provisionalDetails;
	}
	public String getFinalDetails() {
		return finalDetails;
	}
	public void setFinalDetails(String finalDetails) {
		this.finalDetails = finalDetails;
	}
	public String getLiabType() {
		return liabType;
	}
	public void setLiabType(String liabType) {
		this.liabType = liabType;
	}
	public String getJsonData() {
		return jsonData;
	}
	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}
	
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	public boolean isPrevMonth() {
		return isPrevMonth;
	}
	public void setPrevMonth(boolean isPrevMonth) {
		this.isPrevMonth = isPrevMonth;
	}
	public String getPrevJsonData() {
		return prevJsonData;
	}
	public void setPrevJsonData(String prevJsonData) {
		this.prevJsonData = prevJsonData;
	}
	public String getCurrJsonData() {
		return currJsonData;
	}
	public void setCurrJsonData(String currJsonData) {
		this.currJsonData = currJsonData;
	}
	public Object[] getIsFiled() {
		return isFiled;
	}
	public void setIsFiled(Object[] isFiled) {
		this.isFiled = isFiled;
	}
	public boolean isFileEndDate() {
		return isFileEndDate;
	}
	public void setFileEndDate(boolean isFileEndDate) {
		this.isFileEndDate = isFileEndDate;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	
	
}
