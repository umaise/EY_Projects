package com.ey.advisory.asp.domain;

public class DigitalSigSubmit {
	
	String status, acknowledmentId;

	public DigitalSigSubmit() {
		// TODO Auto-generated constructor stub
	}
	public DigitalSigSubmit(String status, String acknowledmentId) {
		super();
		this.status = status;
		this.acknowledmentId = acknowledmentId;
	}



	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAcknowledmentId() {
		return acknowledmentId;
	}

	public void setAcknowledmentId(String acknowledmentId) {
		this.acknowledmentId = acknowledmentId;
	}
	
}
