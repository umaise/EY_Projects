package com.ey.advisory.asp.domain;

import java.io.Serializable;

public class SmartReportAttributes  implements Serializable {

    private static final long serialVersionUID = 1L;

    private long attributeID;
    
    private String description;
    
    private String property;
    
    private String header;
    
    private String fileCategory;
    
    private String mandatory;

	public String getMandatory() {
		return mandatory;
	}

	public void setMandatory(String mandatory) {
		this.mandatory = mandatory;
	}

	public long getAttributeID() {
		return attributeID;
	}

	public void setAttributeID(long attributeID) {
		this.attributeID = attributeID;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getFileCategory() {
		return fileCategory;
	}

	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}

	@Override
	public String toString() {
		return "SmartReportAttributes [attributeID=" + attributeID + ", description=" + description + ", property="
				+ property + ", header=" + header + ", fileCategory=" + fileCategory + "]";
	}
    
    
}
