/**
 * 
 */
package com.ey.advisory.asp.dto;

/**
 * @author Nitesh.Tripathi
 *
 */
public class ClientGroupDto {
	
	private String groupCode;
	
	private long groupId;

	/**
	 * @return the groupCode
	 */
	public String getGroupCode() {
		return groupCode;
	}

	/**
	 * @param groupCode the groupCode to set
	 */
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	/**
	 * @return the groupId
	 */
	public long getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

}
