package com.ey.advisory.asp.dto;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.client.domain.ReturnType;


public class UploadRestDto {
	
	private Map<String, Integer> dropDownList;
	
	public Map<String, Integer> getDropDownList() {
		return dropDownList;
	}

	public void setDropDownList(Map<String, Integer> dropDownList) {
		this.dropDownList = dropDownList;
	}

	public Map<Integer, List<ReturnType>> getReturnradioTypes() {
		return returnradioTypes;
	}

	public void setReturnradioTypes(Map<Integer, List<ReturnType>> returnradioTypes) {
		this.returnradioTypes = returnradioTypes;
	}

	private Map<Integer, List<ReturnType>> returnradioTypes;

}
