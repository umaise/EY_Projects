package com.ey.advisory.asp.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.URI;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.exception.AzureStorageException;
import com.google.api.client.util.IOUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.microsoft.azure.storage.StorageCredentialsAccountAndKey;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.core.Base64;
import com.microsoft.azure.storage.file.CloudFile;
import com.microsoft.azure.storage.file.CloudFileClient;
import com.microsoft.azure.storage.file.CloudFileDirectory;
import com.microsoft.azure.storage.file.CloudFileShare;
import com.microsoft.azure.storage.file.FileInputStream;

@Component
@PropertySource("classpath:ASPRestConfig.properties")
public class AzureFileStoreUtil {

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	@Autowired
	CommonRestClientUtility commonRestClientUtility;

	@Autowired
	private Environment env;

	@Value("${asp-restapi.host}")
	private String restHost;

	public static final String STORE_ACC_NAME = "STORE_ACC_NAME";
	public static final String STORE_ACC_KEY = "STORE_ACC_KEY";

	private static final Logger LOGGER = Logger.getLogger(AzureFileStoreUtil.class);

	// Fetch the Azure Storage account details from Redis if exists else call
	// the rest api
	public Map<String, String> fetchGroupStorageDtlsFromRedis(String groupCode) {

		Map<String, Map<String, String>> azureStore = fetchAzureStoreInfoRedis();

		if (azureStore != null && azureStore.containsKey(groupCode)) {
			LOGGER.info("Azure Storage details exists for the group " + groupCode);
			return azureStore.get(groupCode);
		} else {
			LOGGER.info("Azure Storage details does not exists in redis, Reloading the azure store in  redis  ");
			String resp = commonRestClientUtility.getForEntity(restHost + env.getProperty("asp-azureStoreConfig"));
			if (resp.equals("success")) {
				azureStore = fetchAzureStoreInfoRedis();
				if (azureStore != null && azureStore.containsKey(groupCode))
					return azureStore.get(groupCode);
				else {
					LOGGER.error("Azure Store Credentials doesn't exists ");
					throw new AzureStorageException("Credentials not found");
				}
			}
		}
		LOGGER.info("Exiting from the fetchGroupStorageDtlsFromRedis method");
		return null;
	}

	// Fetch the Azure Storage account details from Redis
	private Map<String, Map<String, String>> fetchAzureStoreInfoRedis() {
		Gson gson = new Gson();
		String jsonAzure = (String) redisTemplate.opsForHash().get(Constant.REDIS_CACHE, "AzureStoreDetailsMap");

		Map<String, Map<String, String>> azureStore = gson.fromJson(jsonAzure,
				new TypeToken<HashMap<String, HashMap<String, String>>>() {
				}.getType());
		return azureStore;
	}

	// Get File Reference - absolute file path
	private CloudFile getExistingFileRef(String groupCode, String filePath, String fileName)
			throws AzureStorageException {

		LOGGER.info("Entering to Upload File in getFileRef with group " + groupCode);
		return getExistingFileRef(groupCode, filePath + "/" + fileName);

	}

	// Get File Reference - absolute file path
	private CloudFile getExistingFileRef(String groupCode, String filePath) {
		LOGGER.info("Entering to Upload File in getFileRef with group " + groupCode);

		Map<String, String> azureStoreConfig = fetchGroupStorageDtlsFromRedis(groupCode);
		if (azureStoreConfig != null && azureStoreConfig.containsKey(STORE_ACC_NAME)
				&& azureStoreConfig.containsKey(STORE_ACC_KEY)) {

			LOGGER.info("getFileRef - Azure Store details are available in  DB for the group " + groupCode);
			StorageCredentialsAccountAndKey credentials = new StorageCredentialsAccountAndKey(
					azureStoreConfig.get(STORE_ACC_NAME), azureStoreConfig.get(STORE_ACC_KEY));
			CloudFile cloudFile = null;

			try {

				URI testUri = new URI(
						"https://?.file.core.windows.net".replace("?", azureStoreConfig.get(STORE_ACC_NAME)));
				CloudFileClient fileClient = new CloudFileClient(testUri, credentials);
				CloudFileShare share = fileClient.getShareReference(groupCode);

				cloudFile = share.getRootDirectoryReference().getFileReference(filePath);

				LOGGER.info("Exiting to Upload File in getFileRef with group " + groupCode);
				return cloudFile;

			} catch (StorageException s) {

				if (s.getCause() instanceof java.net.ConnectException) {
					LOGGER.error(
							"Caught connection exception from the client. If running with the default configuration please make sure you have started the storage emulator.");
				}
				LOGGER.error("Error while getting azure connectivity " + s);
				throw new AzureStorageException("Error while getting azure connectivity - " + s.getMessage());
			} catch (Exception e) {
				LOGGER.error("Error while getting azure connectivity " + e);
				throw new AzureStorageException("Error while getting azure connectivity - " + e.getMessage());
			}
		} else {
			throw new AzureStorageException("Azure Store Credentials are not proper");
		}

	}

	// Upload the file to azure storage in a streamed manner
	public String uploadFileWithMD5Hash(String groupCode, MultipartFile file, String fileName, String filePath,
			Integer chunk, int totalChunks, int bufferSize, HttpServletRequest request) throws Exception {

		LOGGER.info("Entering to Upload File in AzureFileStoreUtil with group " + groupCode);
		Map<String, String> azureStoreConfig = fetchGroupStorageDtlsFromRedis(groupCode);

		if (azureStoreConfig != null && azureStoreConfig.containsKey(STORE_ACC_NAME)
				&& azureStoreConfig.containsKey(STORE_ACC_KEY)) {
			LOGGER.info("Azure Store details are available in  DB for the group " + groupCode);
			StorageCredentialsAccountAndKey credentials = new StorageCredentialsAccountAndKey(
					azureStoreConfig.get(STORE_ACC_NAME), azureStoreConfig.get(STORE_ACC_KEY));
			CloudFile cloudFile = null;
			ByteArrayInputStream inputStream = null;
			try {
				URI testUri = new URI(
						"https://?.file.core.windows.net".replace("?", azureStoreConfig.get(STORE_ACC_NAME)));
				CloudFileClient fileClient = new CloudFileClient(testUri, credentials);
				CloudFileShare share = fileClient.getShareReference(groupCode);

				// Connecting to share takes time so initial check of chunk is
				// done
				if (chunk == 0 && !share.exists())
					share.create();

				// Get a reference to the root directory for the share.
				CloudFileDirectory dirRef = share.getRootDirectoryReference().getDirectoryReference(filePath);

				if (chunk == 0 && !dirRef.exists()) {
					StringTokenizer pathSplit = new StringTokenizer(filePath, "\\/");
					int i = 0;
					while (pathSplit.hasMoreTokens()) {
						if (i == 0)
							dirRef = share.getRootDirectoryReference().getDirectoryReference(pathSplit.nextToken());
						else
							dirRef = dirRef.getDirectoryReference(pathSplit.nextToken());
						dirRef.create();
						i++;
					}
				}

				cloudFile = dirRef.getFileReference(fileName);
				int bytesAmount = 0;
				if (chunk == 0) {
					cloudFile.create(bufferSize * totalChunks);
				}

				LOGGER.info("Start writing to Azure store ");
				bytesAmount = file.getBytes().length;
				inputStream = new ByteArrayInputStream(file.getBytes());
				MessageDigest digest = (MessageDigest) request.getSession(false).getAttribute("MessageDigest");

				if (bytesAmount < bufferSize) {
					cloudFile.uploadRange(inputStream, (chunk * bufferSize), bytesAmount);
				} else {
					cloudFile.uploadRange(inputStream, (chunk * bufferSize), bufferSize);
				}
				LOGGER.info("End writing to Azure store ");

				cloudFile.getProperties().setContentMD5(Base64.encode(DigestUtils.md5(inputStream))); // ensures
																										// integrity

				digest.update(file.getBytes(), 0, bytesAmount);
				request.getSession(false).setAttribute("MessageDigest", digest);
				LOGGER.info("---Hash1--" + Base64.decode(cloudFile.getProperties().getContentMD5()));

				String hashString = (new BigInteger(1, digest.digest()).toString(16));
				LOGGER.info("---Hash2--" + hashString);
				return hashString;
			} catch (Exception e) {
				LOGGER.error("Error while getting azure connectivity " + e);
				throw new AzureStorageException("Error while getting azure connectivity - " + e.getMessage());
			} finally {
				if(inputStream!=null)
					inputStream.close();
			}
		} else {
			throw new AzureStorageException("Azure Store Credentials are not proper");
		}
	}

	// Get MD5 Hash for the azure storage file reference
	// Assuming that the file already exists
	public String getAzureFileMD5Hash(String groupCode, String fileName, String filePath) throws AzureStorageException {

		LOGGER.info("Entering to getAzureFileMD5Hash: " + filePath + "/" + fileName);
		String hashString = getAzureFileMD5Hash(groupCode, filePath + "/" + fileName);
		LOGGER.info("Exiting to getAzureFileMD5Hash ");
		return hashString;
	}

	// Get MD5 Hash for the azure storage file reference
	// Assuming that the file already exists
	public String getAzureFileMD5Hash(String groupCode, String filePath) {

		LOGGER.info("Entering to getAzureFileMD5Hash: " + filePath);

		CloudFile cloudFile = getExistingFileRef(groupCode, filePath);
		long bufferSize = 1048576; // bytes - 1MB - TODO: Pick from properties
		MessageDigest digest;
		FileInputStream inputStream = null;
		String hashString = null;
		if (cloudFile != null) {
			try {

				digest = MessageDigest.getInstance("MD5");
				byte[] buffer = new byte[(int) bufferSize];
				int bytesRead = -1;
				inputStream = cloudFile.openRead();
				while ((bytesRead = inputStream.read(buffer)) != -1) {
					digest.update(buffer, 0, bytesRead);
				}
				hashString = new BigInteger(1, digest.digest()).toString(16);
			} catch (Exception e) {
				LOGGER.error("exception in getAzureFileMD5Hash -- " + e);
				throw new AzureStorageException("Azure Storage Exception -" + e);
			} finally {
				try {
					if(inputStream!=null)
						inputStream.close();
				} catch (IOException e) {

					LOGGER.error("exception in getAzureFileMD5Hash -- " + e);
				}
			}
		} else {
			throw new AzureStorageException("File doesn't exists in Azure store");
		}

		LOGGER.info("Exiting to getAzureFileMD5Hash ");
		return hashString;

	}

	// Download file from Azure store in a streamed manner
	public void azureFileStreamDownload(String groupCode, String fileName, String filePath, OutputStream outputStream) {

		LOGGER.info("Entering to azureFileStreamDownload: " + filePath + "/" + fileName);

		CloudFile cloudFile = getExistingFileRef(groupCode, filePath, fileName);
		long bufferSize = 1048576; // bytes - 1MB - TODO: Pick from properties

		FileInputStream inputStream = null;

		if (cloudFile != null) {
			try {
				byte[] buffer = new byte[(int) bufferSize];
				int bytesRead = -1;
				inputStream = cloudFile.openRead();
				while ((bytesRead = inputStream.read(buffer)) != -1) {
					IOUtils.copy(inputStream, outputStream);
				}

			} catch (Exception e) {
				LOGGER.error("exception in getAzureFileMD5Hash -- " + e);
				throw new AzureStorageException("Azure Storage Exception -" + e);
			} finally {
				try {
					if(inputStream!=null)
						inputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					LOGGER.error("exception in getAzureFileMD5Hash -- " + e);
				}
			}
		} else {
			throw new AzureStorageException("File doesn't exists in Azure store");
		}

		LOGGER.info("Exiting to azureFileStreamDownload ");

	}
}