package com.ey.advisory.asp.security;

import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.web.client.RestTemplate;

import com.ey.advisory.asp.domain.User;
import com.ey.advisory.asp.dto.RoleDto;
import com.ey.advisory.asp.util.CommonRestClientUtility;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@PropertySource("classpath:ASPRestConfig.properties")
public class CustomAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	private Environment env;

	@Value("${asp-restapi.host}")
	private String restHost;

	@Autowired
	private CommonRestClientUtility commonRestClientUtility;
	
	protected static final Logger LOGGER = Logger
			.getLogger(CustomAuthenticationProvider.class);

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String username = authentication.getName();
		String password = (String) authentication.getCredentials();
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		ObjectMapper mapper = new ObjectMapper();
		User userObj = new User();
		userObj.setUserName(username);
		userObj.setPassword(password);
		userObj.setEyLogin(env.getProperty("isEyLogin"));
		User user;
		ResponseEntity<Object> userEntity;
		Set<GrantedAuthority> grantedAuthorities = new HashSet<>(); 
		try {
			userEntity = commonRestClientUtility.executeRestApiCall(
					restHost + env.getProperty("asp-authenticateUserPOST"), userObj, HttpMethod.POST, Object.class);
           
		} catch (AuthenticationException ex) {
			throw new BadCredentialsException("Bad Credentials", ex);
		} catch (Exception ex) {
			throw new BadCredentialsException("Bad Credentials", ex);
		}
		if (userEntity == null || userEntity.getBody() == null) {
			user = null;
		} else {
			user = mapper.convertValue(userEntity.getBody(), User.class);
			
			LOGGER.error("user data :- "+user.toString());
			Set<RoleDto> roleDtoSet = user.getRoleSet();
			
			 GrantedAuthority authority;
			 for(RoleDto roleDto:roleDtoSet){
		      
		        authority = new SimpleGrantedAuthority(roleDto.getRoleType());
		        grantedAuthorities.add(authority);

		      }
		}
		if (user == null) {
			throw new BadCredentialsException("Bad Credentials");
		}
		return new UsernamePasswordAuthenticationToken(user, password, grantedAuthorities);
	}

	@Override
	public boolean supports(Class<?> arg0) {
		return arg0.equals(UsernamePasswordAuthenticationToken.class);
	}
}
