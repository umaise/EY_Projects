package com.ey.advisory.asp.dto;

import java.io.Serializable;

public class MonthValueDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String month;
	String monthVal;
	Integer year;
	
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getMonthVal() {
		return monthVal;
	}
	public void setMonthVal(String monthVal) {
		this.monthVal = monthVal;
	}
	public MonthValueDto(Integer year,String month, String monthVal) {
		super();
		this.year=year;
		this.month = month;
		this.monthVal = monthVal;
	}
	@Override
	public String toString() {
		return "MonthValueDto [month=" + month + ", monthVal=" + monthVal
				+ ", year=" + year + "]";
	}
	
	
	
	
	
}
