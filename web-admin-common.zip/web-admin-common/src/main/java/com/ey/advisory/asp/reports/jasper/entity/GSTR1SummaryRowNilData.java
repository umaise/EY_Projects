package com.ey.advisory.asp.reports.jasper.entity;

public class GSTR1SummaryRowNilData {

	Double totalNil;
	Double totalExempted;
	Double totalNonGst;
	public Double getTotalNil() {
		return totalNil;
	}
	public void setTotalNil(Double totalNil) {
		this.totalNil = totalNil;
	}
	public Double getTotalExempted() {
		return totalExempted;
	}
	public void setTotalExempted(Double totalExempted) {
		this.totalExempted = totalExempted;
	}
	public Double getTotalNonGst() {
		return totalNonGst;
	}
	public void setTotalNonGst(Double totalNonGst) {
		this.totalNonGst = totalNonGst;
	}
	
}
