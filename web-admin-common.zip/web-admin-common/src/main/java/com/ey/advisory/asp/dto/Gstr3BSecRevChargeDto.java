package com.ey.advisory.asp.dto;

import javax.xml.bind.annotation.XmlElement;

public class Gstr3BSecRevChargeDto {
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecRevChargeSubElements OutwardOthers = new Gstr3BSecRevChargeSubElements();
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecRevChargeSubElements OutwardZeroRated = new Gstr3BSecRevChargeSubElements();
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecRevChargeSubElements OutwardNillRated = new Gstr3BSecRevChargeSubElements();
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecRevChargeSubElements InwardRevCharge = new Gstr3BSecRevChargeSubElements();
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecRevChargeSubElements NonGst = new Gstr3BSecRevChargeSubElements();

	@XmlElement
	public Gstr3BSecRevChargeSubElements getOutwardOthers() {
		return OutwardOthers;
	}

	public void setOutwardOthers(Gstr3BSecRevChargeSubElements outwardOthers) {
		OutwardOthers = outwardOthers;
	}

	@XmlElement
	public Gstr3BSecRevChargeSubElements getOutwardZeroRated() {
		return OutwardZeroRated;
	}

	public void setOutwardZeroRated(Gstr3BSecRevChargeSubElements outwardZeroRated) {
		OutwardZeroRated = outwardZeroRated;
	}

	@XmlElement
	public Gstr3BSecRevChargeSubElements getOutwardNillRated() {
		return OutwardNillRated;
	}

	public void setOutwardNillRated(Gstr3BSecRevChargeSubElements outwardNillRated) {
		OutwardNillRated = outwardNillRated;
	}

	@XmlElement
	public Gstr3BSecRevChargeSubElements getInwardRevCharge() {
		return InwardRevCharge;
	}

	public void setInwardRevCharge(Gstr3BSecRevChargeSubElements inwardRevCharge) {
		InwardRevCharge = inwardRevCharge;
	}

	@XmlElement
	public Gstr3BSecRevChargeSubElements getNonGst() {
		return NonGst;
	}

	public void setNonGst(Gstr3BSecRevChargeSubElements nonGst) {
		NonGst = nonGst;
	}

	@Override
	public String toString() {
		return "Gstr3BSecRevChargeDto [OutwardOthers=" + OutwardOthers + ", OutwardZeroRated=" + OutwardZeroRated
				+ ", OutwardNillRated=" + OutwardNillRated + ", InwardRevCharge=" + InwardRevCharge + ", NonGst="
				+ NonGst + "]";
	}
	
	
	
}
