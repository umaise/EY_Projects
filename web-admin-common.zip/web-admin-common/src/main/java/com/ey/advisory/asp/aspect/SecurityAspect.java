package com.ey.advisory.asp.aspect;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Validator;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.exception.ASPInputValidationException;
import com.ey.advisory.asp.security.owasp.Param;
import com.ey.advisory.asp.security.owasp.SecurityUtil;
import com.google.gson.Gson;

@Aspect
@Component
@EnableAspectJAutoProxy
@PropertySource("classpath:AdFileter.properties")
public class SecurityAspect {

	static {
		ESAPI.initialize("org.owasp.esapi.reference.DefaultSecurityConfiguration");
	}
	
	@Autowired
	private SecurityUtil securityService;

	@Value("${isEsapi}")
	private String isEsapi;

	private static final Logger LOGGER = Logger.getLogger(SecurityAspect.class);

	@Pointcut("within(@org.springframework.stereotype.Controller *) && " + "@annotation(requestMapping) && "
			+ "execution(* com.ey.advisory.asp.controller..*(..))")
	public void controller(RequestMapping requestMapping) {
		LOGGER.info("controller");		
	}

	@Around("controller(requestMapping)")
	public Object advice(ProceedingJoinPoint joinPoint, RequestMapping requestMapping) throws Throwable {
		if (isEsapi.equalsIgnoreCase(Constant.TRUE)) {
			HttpServletRequest request;
			Map<Object, String> errorList = new HashMap<>();
			Signature signature = joinPoint.getSignature();
			Class<?> returnType = ((MethodSignature) signature).getReturnType();
			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("Return Type   " + returnType.getSimpleName());
			}
			
			Object[] params = joinPoint.getArgs();
			for (Object object : params) {
				if (null != object && object instanceof HttpServletRequest) {
						request = (HttpServletRequest) object;
						Map<?, ?> mapParams = request.getParameterMap();
						Iterator<?> i = mapParams.keySet().iterator();
						while (i.hasNext()) {							
							Validator instance = ESAPI.validator();
							String key = (String) i.next();
							String value = ((String[]) mapParams.get(key))[0];
							Object value1=mapParams.get(key);
							String[] listOfItems=null;
							boolean listItem=false;
							if(value1!=null && value1 instanceof String[]  ){
								listOfItems=value.split(",");
								if(listOfItems.length>1)
									listItem=true;
							}
							if (LOGGER.isDebugEnabled()){
								LOGGER.debug("joinPoint.getSignature() name " + joinPoint.getTarget().getClass().getName());
								LOGGER.debug("requestMapping.value()[0] " + requestMapping.value()[0]);
							}
						//	System.out.println("first "+joinPoint.getTarget().getClass().getName());
							//System.out.println("second "+requestMapping.value()[0]);
							//System.out.println("third "+key +" value "+value);
							boolean result = (securityService
									.isControllerAvailable(joinPoint.getTarget().getClass().getName())
									&& (securityService.isUrlAvailable(joinPoint.getTarget().getClass().getName(),
											requestMapping.value()[0])
											&& (securityService.isParamAvailable(
													joinPoint.getTarget().getClass().getName(),
													requestMapping.value()[0], key)))) ? true : false;
							//System.out.println("Result from service " +result);
							
							if (result) {
							//	System.out.println("Inside validations");
								Param param = securityService.paramDetails(joinPoint.getTarget().getClass().getName(),
										requestMapping.value()[0], key);
								if (null != param && !listItem) {
									try {
										if(!key.equals("OWASP_CSRFTOKEN")){
										instance.getValidInput(key, value, param.getEsapitype(), param.getMaxlength(),
												true);
										}
									} catch (IntrusionException e) {
										LOGGER.error("IntrusionException",e);
										errorList.put(key, "Intrusion");
									} catch (ValidationException e) {
										LOGGER.error("ValidationException",e);
										errorList.put(key, param.getErrormessage());
									}
									LOGGER.debug(" Security Key pair" + key + " value " + value);
								}else if(listItem){
									try {
										
										if (null != param && listOfItems!=null) {
											LOGGER.debug("Length " + param.getMaxlength());
											for (int index = 0; index < listOfItems.length; index++) {
												instance.getValidInput(key, listOfItems[index], param.getEsapitype(),
														param.getMaxlength(), true);
											}

										}
										
									} catch (IntrusionException e) {
										LOGGER.error("IntrusionException"+e);
										errorList.put(key,"Intrusion");
									} catch (ValidationException e) {
										LOGGER.error("ValidationException"+e);
										if (null != param) {
										errorList.put(key, param.getErrormessage());
										}
									}
									LOGGER.debug("Key " + key + " value " + value);
								}
							} else {
								if (LOGGER.isDebugEnabled()){
								LOGGER.debug("Not Configured.. for " + joinPoint.getTarget().getClass().getName()
										+ " mapping " + requestMapping.value()[0]);
								}
								errorList.put("NOT CONFIGURED", "CONTROLLER NOT CONFIGURED");
								return joinPoint.proceed();
							}
						}
					}	
			}
			if (errorList.isEmpty()) {
				return joinPoint.proceed();
			} else {
				if (LOGGER.isDebugEnabled()){
					LOGGER.debug(" errorlist length "+errorList.size());
					for(Object key :errorList.keySet()){
						LOGGER.debug(Constant.INPUT_VALIDATION_ERROR_LOG+key+" "+errorList.get(key));
					}
				}
				if (returnType.getSimpleName().equals(Constant.MODELANDVIEW)) {
					
					//return createModelAndView(errorList);
					return createModelAndView(null);
				} else {
					String errorString = "ASP SECURITY OWASP VALIDATION " + new Gson().toJson(errorList);
					
					String errorKeys="[";
					for(Object key :errorList.keySet())
						errorKeys+=key+" ";
					errorKeys+="]";
					throw new ASPInputValidationException(Constant.ASP_INPUT_VALIDATION_EXCEPTION_MESSAGE);
				}

			}
		} else {
			return joinPoint.proceed();
		}

	}

	private ModelAndView createModelAndView(Map<Object, String> ls) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("errorList", ls);
		modelAndView.setViewName("securityError");
		return modelAndView;
	}

}
