package com.ey.advisory.asp.security.azureAd;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.util.RedisOperationForSessionObj;


@Component("urlRewritingFilter")
@PropertySource("classpath:AdFileter.properties")
public class UrlRewritingFilter implements Filter {

	@Value("${redirectHost}")
	private String redirectHost;
	
	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	private static final Logger LOGGER = Logger.getLogger(UrlRewritingFilter.class);
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		
	}
	

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest request1 = (HttpServletRequest) request;
		String path = request1.getRequestURI();
		String currentUri = redirectHost + request1.getRequestURI();
		String fullUrl = path
				+ (request1.getQueryString() != null ? "?" + request1.getQueryString() : "");
		LOGGER.error(" path :"+path);
		LOGGER.error(" currentUri "+currentUri);
		LOGGER.error("fullUrl "+fullUrl);
		
		String str1;
		String cxt = request1.getContextPath();
		if (path.contains("\\ey_client\\")||path.contains("/ey_client/")) {
			int i = fullUrl.lastIndexOf("\\");
			if(i<=0){
				str1 = fullUrl.substring(fullUrl.lastIndexOf("/"));
			}else{
				str1 = fullUrl.substring(fullUrl.lastIndexOf("\\"));
			
			}
			if(request1.getSession(false) == null)
				request1.getSession(true);
			request1.getSession(true);
			String str = fullUrl.replace("\\ey_client","");
			str = str.replace("/ey_client","");
			str = str.replace(cxt, "/");
			request1.setAttribute("Client", "ey_client");
			LOGGER.error("str++ "+str);
			redisOp.setValueToRedis("Client", "ey_client", request1);
			RequestDispatcher rd = request1.getServletContext().getRequestDispatcher(str1);
			
			rd.forward(request1, response);
			
            return;
		} else if(path.contains("\\ey_client1\\")||path.contains("/ey_client1/")){
			
			if(request1.getSession(false) == null){
			request1.getSession(true);
			}
			
			int i = fullUrl.lastIndexOf("\\");
			if(i<=0){
				str1 = fullUrl.substring(fullUrl.lastIndexOf("/"));
			}else{

				str1 = fullUrl.substring(fullUrl.lastIndexOf("\\"));
			}
			
			String str = fullUrl.replace("\\ey_client1","");
			str = str.replace("/ey_client1","");
			request1.setAttribute("Client", "ey_client1");
			LOGGER.error("str++ "+str);
			RequestDispatcher rd = request1.getServletContext().getRequestDispatcher(str1);
			
			rd.forward(request1, response);
			
            return;
			
		}
		
		chain.doFilter(request, response);
        return;
		
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

}
