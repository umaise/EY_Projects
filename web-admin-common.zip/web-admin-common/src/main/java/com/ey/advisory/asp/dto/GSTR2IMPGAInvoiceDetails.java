package com.ey.advisory.asp.dto;

import java.sql.Date;
import java.util.List;


public class GSTR2IMPGAInvoiceDetails {

	private long id;
	
	private Character flag;
	
	private String checksum;
	
	private String invNum;

	private Date invDate;
		
	private Float invValue;
	
	private String orgInvNum;
	
	private Date orgInvDate;
	
	private Long taxPayerId;
	
	private Float txValue;
	
	private int invoiceCnt;
	
	private Float igstTotal;
	
	private List<GSTR2IMPGAItemDetails> gstr2IMPGADetails;
	
	
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the flag
	 */
	public Character getFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(Character flag) {
		this.flag = flag;
	}

	/**
	 * @return the checksum
	 */
	public String getChecksum() {
		return checksum;
	}

	/**
	 * @param checksum the checksum to set
	 */
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	/**
	 * @return the invNum
	 */
	public String getInvNum() {
		return invNum;
	}

	/**
	 * @param invNum the invNum to set
	 */
	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	/**
	 * @return the invDate
	 */
	public Date getInvDate() {
		return invDate;
	}

	/**
	 * @param invDate the invDate to set
	 */
	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	/**
	 * @return the invValue
	 */
	public Float getInvValue() {
		return invValue;
	}

	/**
	 * @param invValue the invValue to set
	 */
	public void setInvValue(Float invValue) {
		this.invValue = invValue;
	}

	/**
	 * @return the orgInvNum
	 */
	public String getOrgInvNum() {
		return orgInvNum;
	}

	/**
	 * @param orgInvNum the orgInvNum to set
	 */
	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	/**
	 * @return the orgInvDate
	 */
	public Date getOrgInvDate() {
		return orgInvDate;
	}

	/**
	 * @param orgInvDate the orgInvDate to set
	 */
	public void setOrgInvDate(Date orgInvDate) {
		this.orgInvDate = orgInvDate;
	}

	

	/**
	 * @return the txValue
	 */
	public Float getTxValue() {
		return txValue;
	}

	/**
	 * @param txValue the txValue to set
	 */
	public void setTxValue(Float txValue) {
		this.txValue = txValue;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}

	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}


	public Long getTaxPayerId() {
		return taxPayerId;
	}

	public void setTaxPayerId(Long taxPayerId) {
		this.taxPayerId = taxPayerId;
	}

	public List<GSTR2IMPGAItemDetails> getGstr2IMPGADetails() {
		return gstr2IMPGADetails;
	}

	public void setGstr2IMPGADetails(List<GSTR2IMPGAItemDetails> gstr2impgaDetails) {
		gstr2IMPGADetails = gstr2impgaDetails;
	}
	
	
	
}
