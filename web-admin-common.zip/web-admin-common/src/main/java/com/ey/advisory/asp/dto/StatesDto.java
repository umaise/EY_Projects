/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

/**
 * @author Nitesh.Tripathi
 *
 */
public class StatesDto implements Serializable {
	private static final long serialVersionUID = 1L;

	@Digits(fraction = 0, integer =20)
	private long stateID;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String stateName;

	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String stateIdentifier;

	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String statecode;


	private boolean isUT;

	/**
	 * @return the stateID
	 */
	public long getStateID() {
		return stateID;
	}

	/**
	 * @param stateID the stateID to set
	 */
	public void setStateID(long stateID) {
		this.stateID = stateID;
	}

	/**
	 * @return the stateName
	 */
	public String getStateName() {
		return stateName;
	}

	/**
	 * @param stateName the stateName to set
	 */
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((statecode == null) ? 0 : statecode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StatesDto other = (StatesDto) obj;
		if (statecode == null) {
			if (other.statecode != null)
				return false;
		} else if (!statecode.equals(other.statecode))
			return false;
		return true;
	}

	public String getStateIdentifier() {
		return stateIdentifier;
	}

	public void setStateIdentifier(String stateIdentifier) {
		this.stateIdentifier = stateIdentifier;
	}

	/**
	 * @return the statecode
	 */
	public String getStatecode() {
		return statecode;
	}

	/**
	 * @param statecode the statecode to set
	 */
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}

	/**
	 * @return the isUT
	 */
	public boolean isUT() {
		return isUT;
	}

	/**
	 * @param isUT the isUT to set
	 */
	public void setUT(boolean isUT) {
		this.isUT = isUT;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "States [stateID=" + stateID + ", stateName=" + stateName + ", stateIdentifier=" + stateIdentifier + ", statecode=" + statecode
				+ ", isUT=" + isUT + "]";
	}
}
