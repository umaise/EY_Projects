package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Pattern;

public class GSTIN implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String gstinId;
	@Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	private String gstin;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String otp;
	private Date otpExpiryDate;
	
	private Boolean ssActive;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String createdBy;
	private Date createdDate;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String updatedBy;
	private Date updatedDate;
	private GroupEntity groupEntity;

	
	
	public GSTIN(String gstinId) {
		this.gstinId = gstinId;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Date getOtpExpiryDate() {
		return otpExpiryDate;
	}

	public void setOtpExpiryDate(Date otpExpiryDate) {
		this.otpExpiryDate = otpExpiryDate;
	}

	public Boolean getSsActive() {
		return ssActive;
	}

	public void setSsActive(Boolean ssActive) {
		this.ssActive = ssActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public GroupEntity getGroupEntity() {
		return groupEntity;
	}

	public void setGroupEntity(GroupEntity groupEntity) {
		this.groupEntity = groupEntity;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getGstinId() {
		return gstinId;
	}

	public void setGstinId(String gstinId) {
		this.gstinId = gstinId;
	}
	
	
	
	
}
