/**
 * 
 */
package com.ey.advisory.asp.taglib;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.tagext.Tag;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.web.servlet.tags.RequestContextAwareTag;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.RoleDto;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;
import com.ey.advisory.asp.util.RedisSessionUtility;

/**
 * @author Nitesh.Tripathi
 *
 */
@Configurable
public class AuthSignAccessTag  extends RequestContextAwareTag {
	
	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	private static final long serialVersionUID = 1L;

	protected static final Logger LOGGER = Logger
			.getLogger(AuthSignAccessTag.class);
	


	@Override
	protected int doStartTagInternal() throws Exception {
		
		//LOGGER.info("check AuthSignAccess for:"+gstin);
		
		HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
		RedisOperationForSessionObj obj = getRequestContext().getWebApplicationContext()
				.getBean(RedisOperationForSessionObj.class);
		RedisSessionUtility util = getRequestContext().getWebApplicationContext().getBean(RedisSessionUtility.class);
		obj.setUtil(util);
		
		Set<String> gstinsSet  = obj.getAuthSignGstinsFromRedis(request);
		Set<RoleDto> roleDtoSet =  obj.getRoleSetFromRedis(request);
		String category = "";
		if(roleDtoSet != null){
			for(RoleDto rdto:roleDtoSet){
				if(Constant.INTERNAL_CATEGORY.equalsIgnoreCase(rdto.getCategory())){
					category = "Internal";
				}
			}
		}
		
		if(Constant.INTERNAL_CATEGORY.equalsIgnoreCase(category)){
			
			return Tag.EVAL_BODY_INCLUDE;
			
		}else if(gstinsSet!= null && gstinsSet.contains(gstin)) {
			
			return Tag.EVAL_BODY_INCLUDE;
		}else{
                if(LOGGER.isDebugEnabled()){
				
				LOGGER.debug("No AuthSignAccess for:"+gstin);
			}
		}
		
		return Tag.SKIP_BODY;
		
	}

	private String gstin;
	
	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

}
