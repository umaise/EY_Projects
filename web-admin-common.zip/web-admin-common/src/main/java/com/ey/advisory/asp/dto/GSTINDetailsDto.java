/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.apache.log4j.Logger;

/**
 * @author Nitesh.Tripathi
 *
 */
public class GSTINDetailsDto implements Serializable,Cloneable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(GSTINDetailsDto.class);
	
	@Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	private String GstinId;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String GSTNUserName;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String EntityID;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String StateCode;
	/**
	 * @return the gstinId
	 */
	public String getGstinId() {
		return GstinId;
	}
	/**
	 * @param gstinId the gstinId to set
	 */
	public void setGstinId(String gstinId) {
		GstinId = gstinId;
	}
	/**
	 * @return the gSTNUserName
	 */
	public String getGSTNUserName() {
		return GSTNUserName;
	}
	/**
	 * @param gSTNUserName the gSTNUserName to set
	 */
	public void setGSTNUserName(String gSTNUserName) {
		GSTNUserName = gSTNUserName;
	}
	/**
	 * @return the entityID
	 */
	public String getEntityID() {
		return EntityID;
	}
	/**
	 * @param entityID the entityID to set
	 */
	public void setEntityID(String entityID) {
		EntityID = entityID;
	}
	/**
	 * @return the stateCode
	 */
	public String getStateCode() {
		return StateCode;
	}
	/**
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(String stateCode) {
		StateCode = stateCode;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GSTINDetailsDto [GstinId=" + GstinId + ", GSTNUserName=" + GSTNUserName + ", EntityID=" + EntityID
				+ ", StateCode=" + StateCode + "]";
	}
	
	@Override
	public Object clone() {
		//shallow copy
		try {
		  return super.clone();
		} catch (CloneNotSupportedException e) {
			LOGGER.error(e);
		  return null;
		}
	  }
	
	
}
