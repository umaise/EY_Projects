package com.ey.advisory.asp.domain;

import java.io.Serializable;

public class DocAndSupplyTypeMetadata  implements Serializable {

    private static final long serialVersionUID = 1L;

    private long docandSupplyTypeID;
    
    private String description;
    
    private String code;
    
    private String value;
    
    private Integer orderId;
    
    private String typeofDoc;
    
    private String fileCategory;

	public long getDocandSupplyTypeID() {
		return docandSupplyTypeID;
	}

	public void setDocandSupplyTypeID(long docandSupplyTypeID) {
		this.docandSupplyTypeID = docandSupplyTypeID;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getTypeofDoc() {
		return typeofDoc;
	}

	public void setTypeofDoc(String typeofDoc) {
		this.typeofDoc = typeofDoc;
	}

	public String getFileCategory() {
		return fileCategory;
	}

	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}

	@Override
	public String toString() {
		return "DocAndSupplyTypeMetadata [docandSupplyTypeID=" + docandSupplyTypeID + ", description=" + description
				+ ", code=" + code + ", value=" + value + ", orderId=" + orderId + ", typeofDoc=" + typeofDoc
				+ ", fileCategory=" + fileCategory + "]";
	}	
    
    
}
