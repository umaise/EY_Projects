package com.ey.advisory.asp.dto;

public class UserAccessLevelDTO {
	
	private Long userId;
	private String email;
	private String accesLevel;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAccesLevel() {
		return accesLevel;
	}
	public void setAccesLevel(String accesLevel) {
		this.accesLevel = accesLevel;
	}


}
