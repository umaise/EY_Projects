package com.ey.advisory.asp.taglib;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.servlet.jsp.JspWriter;

import org.apache.log4j.Logger;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.servlet.tags.RequestContextAwareTag;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.domain.AnswerDTO;
import com.ey.advisory.asp.domain.Questionairre;
import com.ey.advisory.asp.util.RedisSessionUtility;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class QuestionAnswerTag  extends RequestContextAwareTag {

    protected static final Logger LOGGER = Logger.getLogger(QuestionAnswerTag.class);

    private static final long serialVersionUID = 1L;
    
    
    private String questionID;
    private String questionType;
    private String answerType;
    private String descriptiveAnswerType;
    private String validation;
    
    public String getDescriptiveAnswerType() {
		return descriptiveAnswerType;
	}

	public void setDescriptiveAnswerType(String descriptiveAnswerType) {
		this.descriptiveAnswerType = descriptiveAnswerType;
	}

    public String getAnswerType() {
        return answerType;
    }

    public void setAnswerType(String answerType) {
        this.answerType = answerType;
    }

    public String getValidation() {
        return validation;
    }

    public void setValidation(String validation) {
        this.validation = validation;
    }

    public String getQuestionID() {
        return questionID;
    }

    public void setQuestionID(String questionID) {
        this.questionID = questionID;
    }

    public String getQuestionType() {
        return questionType;
    }

    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }

    @Override
    protected int doStartTagInternal() throws Exception {
        JspWriter out = pageContext.getOut();

        RedisSessionUtility util = getRequestContext().getWebApplicationContext().getBean(RedisSessionUtility.class);
        RedisTemplate<String, Object> redisTemplate =  util.getRedisTemplate();
        
        String questionListJson = (String) redisTemplate.opsForHash().get(Constant.REDIS_CACHE, Constant.QUESTIONS_LIST);
         Gson gson = new Gson();
         Map<String,Questionairre> questionListMap = gson.fromJson(questionListJson, new TypeToken<Map<String,Questionairre>>() {
                }.getType());
         
         Questionairre questionairre = questionListMap.get(questionID);
         
         String answerListJson = (String) redisTemplate.opsForHash().get(Constant.REDIS_CACHE, Constant.ANSWERS_LIST);
         Map<String,List<AnswerDTO>> answerListMap = gson.fromJson(answerListJson, new TypeToken<Map<String,List<AnswerDTO>>>() {
                }.getType());
         
         List<AnswerDTO> answers = answerListMap.get(questionID);
         if(answers!=null && !answers.isEmpty()){
        	 Collections.sort(answers, (o1, o2) -> o1.getOrderNo() - o2.getOrderNo());
         }
         out.println("<div class='row' style='margin-bottom:10px;'>");
         out.println("<form role='form'>");
         out.println("<div class='col-lg-12'>");
         out.println("<div class='form-group'><label>");
         out.println(questionType);
         if(questionairre.getIsManadatory()!=null && questionairre.getIsManadatory()=='Y'){
             out.println("<span class='star-label'>*</span>");
          }
         out.println(questionairre.getQuestionValue());
         out.println("</label>");
         if(questionairre.getTooltip()!=null  && !"".equals(questionairre.getTooltip())){
             out.println("<label style='position: relative;'><span class='glyphicon glyphicon-question-sign'></span><div class='help-popup'>");
             out.println(questionairre.getTooltip());                                                                                                       
             out.println("</div><div class='arrow'></div></label>");                                                                                 
         }
             out.println("<div>");
             int i=0;
             
             
            if(answerType!=null && "text".equals(answerType)){
                    if(validation!=null && "number".equals(validation)){
                        out.println("<label class='radio-inline'><input type='text' onkeypress='return isNumericKey(event,this)' style='height:30px;' maxlength='20' placeholder='Type here...' required class='form-control text-field' name='"+questionID+"' id='"+questionID+"' value=''/></label>");
                    }else if(validation!=null && "amount".equals(validation)){
                    	out.println("<label class='radio-inline'><input type='text' onkeypress='return isNumberKey(event,this)' required style='height:30px;' maxlength='20' class='form-control text-field' name='"+questionID+"' id='"+questionID+"' value='' placeholder='Amount'/></label>");
                    }else{
                        out.println("<label class='radio-inline'><input type='text' style='height:30px;' maxlength='255' class='form-control text-field' placeholder='Characters' required name='"+questionID+"' id='"+questionID+"' value=''/></label>");
                    }
            }else if ("checkbox".equals(answerType)) {

    			for (AnswerDTO answer : answers) {
    					out.println("<label class='checkbox-inline'>");
    					out.println("<input type='checkbox' name='" + questionID
    							+ "' id='" + questionID + "_"
    							+ answer.getAnswerId() + "' value='" + questionID
    							+ "_" + answer.getAnswerId() + "'/>");
    					out.println(answer.getAnswerValue());
    					out.println("</label>");
    				i++;
    			}

    		}else if("U)".equals(questionType)){
                 out.println("<label class='radio-inline'>");
                 out.println("<input type='radio' name='"+questionID+"' id='"+questionID+"_"+answers.get(0).getAnswerId()+"' value='"+questionID+"_"+answers.get(0).getAnswerId()+"'/>");
                 out.println(answers.get(0).getAnswerValue());
                 out.println("</label>");
                 out.println("<label class='radio-inline'>");
                 out.println("<input type='radio' name='"+questionID+"' id='otherValues' value='others' checked='checked'/>");
                 out.println("Other Levels");
                 out.println("</label>");
                 if(answers.get(0).getTooltip()!=null){
                     out.println("<label style='position: relative;'><span class='glyphicon glyphicon-question-sign'></span><div class='help-popup'>");
                     out.println(answers.get(0).getTooltip());                                                                                                       
                     out.println("</div><div class='arrow'></div></label>");                                                                                 
                 }
                 out.println("<div id='otherLevelDiv' class='col-lg-2'><div class='form-group'>");
                 out.println("<select class='form-control match-content' id='levelheirarchy'>");
                 for(AnswerDTO answer : answers){
                         if(i==0){
                             i++;continue;
                         }
                         out.println("<option id='"+questionID+"_"+answer.getAnswerId()+"' value='"+questionID+"_"+answer.getAnswerId()+"'>"+answer.getAnswerValue()+"</option>");
                 }
                 out.println("</select></div></div>");
             }else{
              if(answers!=null){
                     for(AnswerDTO answer : answers){
                         out.println("<label class='radio-inline'>");
                             if(i==0 && (questionairre.getIsManadatory()!=null && questionairre.getIsManadatory()=='Y')){
                            		 out.println("<input type='radio' name='"+questionID+"' id='"+questionID+"_"+answer.getAnswerId()+"' value='"+questionID+"_"+answer.getAnswerId()+"' checked='checked'/>");
                             }else{
                                 out.println("<input type='radio' name='"+questionID+"' id='"+questionID+"_"+answer.getAnswerId()+"' value='"+questionID+"_"+answer.getAnswerId()+"'/>");
                             }
                         out.println(answer.getAnswerValue());
                         out.println("</label>");
                         if(answer.getTooltip()!=null && !"".equals(answer.getTooltip())){
                             out.println("<label style='position: relative;'><span class='glyphicon glyphicon-question-sign'></span><div class='help-popup'>");
                             out.println(answer.getTooltip());                                                                                                       
                             out.println("</div><div class='arrow'></div></label>");                                                                                 
                         }
                         if(answer.getIsDescriptive()!=null && answer.getIsDescriptive()=='Y'){
                        	 
                        	 if(descriptiveAnswerType!=null && "text".equals(descriptiveAnswerType)){
                        		 out.println("<label class='radio-inline'><input type='text' style='height:30px;' maxlength='255' class='form-control text-field' name='"+answer.getDescription()+"' id='"+questionID+"_desc' value='' placeholder='"+answer.getDescription()+"'/></label>");
                        	 }else if(descriptiveAnswerType!=null && "number".equals(descriptiveAnswerType)){
                        		 out.println("<label class='radio-inline'><input type='text' onkeypress='return isNumericKey(event,this)' style='height:30px;'  maxlength='20' class='form-control' name='"+answer.getDescription()+"' id='"+questionID+"_desc' value='' placeholder='"+answer.getDescription()+"'/></label>");
                        	 }else{
                                 out.println("<label class='radio-inline'><input type='text' onkeypress='return isNumberKey(event,this)' style='height:30px;' maxlength='20' class='form-control' name='"+answer.getDescription()+"' id='"+questionID+"_desc' value='' placeholder='"+answer.getDescription()+"'/></label>");
                        	 }
                        	}
                         i++;
                        }
                 }
             }
             out.println("</div>");
         out.println("</div></div></form></div>");
        return 0;
    }

}
