package com.ey.advisory.asp.dto;

import java.util.List;
import java.util.Map;

public class SaveDistributionTurnOverDto {

	private List<Map<String,String>> tabRows;

	public List<Map<String, String>> getTabRows() {
		return tabRows;
	}

	public void setTabRows(List<Map<String, String>> tabRows) {
		this.tabRows = tabRows;
	}
	
	
	
}
