package com.ey.advisory.asp.domain;

import java.math.BigDecimal;
import java.util.Date;

public class ClientEntity {
	
	private Integer EntityID;
	private String entityName;
	private String isActive;
	private String pan;
	private BigDecimal grossTurnOver;
	private String groupId;
	private String createdBy; 	
	private Date createdDate;
	private String updatedBy; 	
	private Date updatedDate;
	
	public Integer getEntityID() {
		return EntityID;
	}
	public void setEntityID(Integer EntityID) {
		this.EntityID = EntityID;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public BigDecimal getGrossTurnOver() {
		return grossTurnOver;
	}
	public void setGrossTurnOver(BigDecimal grossTurnOver) {
		this.grossTurnOver = grossTurnOver;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getEntityCode() {
		return entityCode;
	}
	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}
	private String entityCode;
	
	

	

}
