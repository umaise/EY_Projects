package com.ey.advisory.asp.dto;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

public class FunctionDto implements Serializable {

	@Digits(fraction = 0, integer =20)
	private Long funcID;
	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String func;
	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String funcDesc;
	
	public Long getFuncID() {
		return funcID;
	}
	public void setFuncID(Long funcID) {
		this.funcID = funcID;
	}
	public String getFunc() {
		return func;
	}
	public void setFunc(String func) {
		this.func = func;
	}
	public String getFuncDesc() {
		return funcDesc;
	}
	public void setFuncDesc(String funcDesc) {
		this.funcDesc = funcDesc;
	}
	
	
}
