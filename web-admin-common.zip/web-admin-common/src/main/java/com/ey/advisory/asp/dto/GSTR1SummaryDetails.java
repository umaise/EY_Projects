package com.ey.advisory.asp.dto;

public class GSTR1SummaryDetails {
	
	String gstnId;
	String taxPeriod;
	String summeryJson;
	String turnover;
	String taxablePerson;
	public String getGstnId() {
		return gstnId;
	}
	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	public String getSummeryJson() {
		return summeryJson;
	}
	public void setSummeryJson(String summeryJson) {
		this.summeryJson = summeryJson;
	}
	public String getTurnover() {
		return turnover;
	}
	public void setTurnover(String turnover) {
		this.turnover = turnover;
	}
	public String getTaxablePerson() {
		return taxablePerson;
	}
	public void setTaxablePerson(String taxablePerson) {
		this.taxablePerson = taxablePerson;
	}

}
