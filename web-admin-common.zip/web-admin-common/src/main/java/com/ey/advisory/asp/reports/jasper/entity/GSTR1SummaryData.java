package com.ey.advisory.asp.reports.jasper.entity;

import javax.validation.constraints.Pattern;

public class GSTR1SummaryData {
	
	 @Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String reportName;
	
	 @Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	 String gstnId;
	
	 //@Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String businessName;
	
	 String gstr1Sum;
	
	 @Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String fYear;
	
	 @Pattern(regexp = "^[a-zA-Z 0-9._-]+$")
	 String returnPeriod;
	
	 Double totalTaxPayable;
	 
	 Double totalTaxable;
	 
	 Double totalIgst;
	 
	 Double totalCgst;
	 
	 Double totalSgst;
	 
	 Double totalCess;
	 
	 Double outwardSupplies;
	 
	 Double exemptSupplies;
	 
	 Double fyTurnOver;
	 
	 Double qyTurnOver;
	 
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public String getGstnId() {
		return gstnId;
	}
	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getGstr1Sum() {
		return gstr1Sum;
	}
	public void setGstr1Sum(String gstr1Sum) {
		this.gstr1Sum = gstr1Sum;
	}
	public String getfYear() {
		return fYear;
	}
	public void setfYear(String fYear) {
		this.fYear = fYear;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public Double getTotalTaxPayable() {
		return totalTaxPayable;
	}
	public void setTotalTaxPayable(Double totalTaxPayable) {
		this.totalTaxPayable = totalTaxPayable;
	}
	public Double getTotalTaxable() {
		return totalTaxable;
	}
	public void setTotalTaxable(Double totalTaxable) {
		this.totalTaxable = totalTaxable;
	}
	public Double getTotalIgst() {
		return totalIgst;
	}
	public void setTotalIgst(Double totalIgst) {
		this.totalIgst = totalIgst;
	}
	public Double getTotalCgst() {
		return totalCgst;
	}
	public void setTotalCgst(Double totalCgst) {
		this.totalCgst = totalCgst;
	}
	public Double getTotalSgst() {
		return totalSgst;
	}
	public void setTotalSgst(Double totalSgst) {
		this.totalSgst = totalSgst;
	}
	public Double getTotalCess() {
		return totalCess;
	}
	public void setTotalCess(Double totalCess) {
		this.totalCess = totalCess;
	}
	public Double getOutwardSupplies() {
		return outwardSupplies;
	}
	public void setOutwardSupplies(Double outwardSupplies) {
		this.outwardSupplies = outwardSupplies;
	}
	public Double getExemptSupplies() {
		return exemptSupplies;
	}
	public void setExemptSupplies(Double exemptSupplies) {
		this.exemptSupplies = exemptSupplies;
	}
	public Double getFyTurnOver() {
		return fyTurnOver;
	}
	public void setFyTurnOver(Double fyTurnOver) {
		this.fyTurnOver = fyTurnOver;
	}
	public Double getQyTurnOver() {
		return qyTurnOver;
	}
	public void setQyTurnOver(Double qyTurnOver) {
		this.qyTurnOver = qyTurnOver;
	}
	
	
}
