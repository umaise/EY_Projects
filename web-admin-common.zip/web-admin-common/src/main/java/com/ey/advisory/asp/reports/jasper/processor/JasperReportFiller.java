package com.ey.advisory.asp.reports.jasper.processor;

import org.springframework.core.env.Environment;

public interface JasperReportFiller {

	byte[] getJasperReport(Object reportData,String reportPath);
	String getJasperReportPath(JasperReportTypes type,Environment env);
}
