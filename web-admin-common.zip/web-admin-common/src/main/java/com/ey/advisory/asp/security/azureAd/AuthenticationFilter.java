/*******************************************************************************
 * Copyright © Microsoft Open Technologies, Inc.
 * 
 * All Rights Reserved
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * THIS CODE IS PROVIDED *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS
 * OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION
 * ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A
 * PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 * 
 * See the Apache License, Version 2.0 for the specific language
 * governing permissions and limitations under the License.
 ******************************************************************************/
package com.ey.advisory.asp.security.azureAd;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.SAMLEntryPoint;
import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.security.AddableHttpRequest;
import com.ey.advisory.asp.util.CommonUtility;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;


public class AuthenticationFilter implements Filter {
	
	private static final Logger LOGGER = Logger.getLogger(AuthenticationFilter.class);
	
	private RedisOperationForSessionObj redisOp;
	
	WebApplicationContext springContext = null;
	
	@SuppressWarnings("unused")
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		
		LOGGER.info("AuthenticationFilter : doFilter executed ...");
		
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpSession session = httpServletRequest.getSession(false);
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;
		String requestURL = httpServletRequest.getRequestURL().toString();
		try {
			// Exclude the few pages 
			if (CommonUtility.isExcluded(httpServletRequest)) {
				LOGGER.info("AuthenticationFilter : Excluded - getRequestURI :" + httpServletRequest.getRequestURL());
				chain.doFilter(request, response);
				return;
			}
			
			LOGGER.info("AuthenticationFilter: RequestURL : "+httpServletRequest.getRequestURL() +" : RequestURI:"+httpServletRequest.getRequestURI());
			
			AddableHttpRequest addableHttpRequest = new AddableHttpRequest(httpServletRequest);
			
			String HostValue = httpServletRequest.getHeader(Constant.REQUEST_HEADER_KEY_HOST);
			String groupCode = redisOp.getValueFromRedisGrpDomainName(HostValue);
			
			if(StringUtils.isEmpty(groupCode)){
				
				LOGGER.info("AuthenticationFilter :" +groupCode +" is not configured for SAML Authentication.");
				chain.doFilter(request, response);
				return;
			}

			LOGGER.info("AuthenticationFilter : Host Value : "+HostValue +" : Group Code:"+groupCode);
			
			HashMap<String, String> grpConfigMap = redisOp.getValueFromRedisGrpConfigs(groupCode);
			String authType = grpConfigMap.get(Constant.AUTH_TYPE);
			
			LOGGER.info("AuthenticationFilter : grpConfigMap : "+grpConfigMap+" : Auth Type : "+authType);
			
			if (Constant.AUTH_TYE_SAML.equalsIgnoreCase(authType)) {
				
				// get access the group configs details form redis
				String samlEndPointURL = grpConfigMap.get(Constant.SAML_ENDPOINT_URL);
				
				LOGGER.info("AuthenticationFilter : samlEndPointURL : "+samlEndPointURL);
				
				if(StringUtils.isEmpty(samlEndPointURL))  
					throw new Exception(" SAML End point is not configured for group code : "+groupCode +" ,host Name : "+HostValue);
				
				Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
				
				if (authentication != null && authentication.isAuthenticated()) {
					boolean anonymous = authentication.getAuthorities().contains( new SimpleGrantedAuthority(Constant.SAML_ROLE_ANONYMOUS));
					if (anonymous) {
						addableHttpRequest.addParameter(Constant.SAML_IDP_KEY, samlEndPointURL);
						addableHttpRequest.setRequestURI(httpServletRequest.getContextPath() + Constant.SAML_LOGIN_URL);
						SAMLEntryPoint filter = (SAMLEntryPoint) springContext.getBean(Constant.SAML_END_POINT_ENTRY_BEAN);
						filter.doFilter(addableHttpRequest, httpServletResponse, chain);
					} 
					else {
						chain.doFilter(httpServletRequest, httpServletResponse);
					}
				} else {
					
					chain.doFilter(httpServletRequest, httpServletResponse);
				}
				
			} else {
				// redirect to other filter if SAML is not configured
				chain.doFilter(httpServletRequest, httpServletResponse);
			}
		} catch (Exception e) {
			
			LOGGER.error(" ERROR : AuthenticationFilter :"+e,e);
			request.getRequestDispatcher("/error.jsp" + httpServletRequest.getContextPath()).forward(httpServletRequest, httpServletResponse);
			
			return;
		}
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		springContext = WebApplicationContextUtils
				.getWebApplicationContext(filterConfig.getServletContext());
		redisOp = springContext.getBean(RedisOperationForSessionObj.class);
		
		 String excludedString = filterConfig.getInitParameter("excludedExt");
		 CommonUtility.setExcludedURLString(excludedString);
	}
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}
	
}
