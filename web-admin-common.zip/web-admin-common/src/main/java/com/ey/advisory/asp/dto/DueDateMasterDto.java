package com.ey.advisory.asp.dto;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

public class DueDateMasterDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Digits(fraction = 0, integer =20)
	private Long returnId;
	@Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	private String gstnId;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String applicableReturn;
	@Digits(fraction = 0, integer =20)
	private Long dueDates;
	@Digits(fraction = 0, integer =20)
	private Long gstnMandatedDate;

	public Long getGstnMandatedDate() {
		return gstnMandatedDate;
	}

	public void setGstnMandatedDate(Long gstnMandatedDate) {
		this.gstnMandatedDate = gstnMandatedDate;
	}

	public String getApplicableReturn() {
		return applicableReturn;
	}

	public Long getReturnId() {
		return returnId;
	}

	public void setReturnId(Long returnId) {
		this.returnId = returnId;
	}

	public String getGstnId() {
		return gstnId;
	}

	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}

	public void setApplicableReturn(String applicableReturn) {
		this.applicableReturn = applicableReturn;
	}

	public Long getDueDates() {
		return dueDates;
	}

	public void setDueDates(Long dueDates) {
		this.dueDates = dueDates;
	}

}
