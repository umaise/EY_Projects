/**
 * 
 */
package com.ey.advisory.asp.dto;

/**
 * @author Uma.Chandranaik
 *
 */
public class GSTR2ATItem {

	private Character itemType;
	
	private String hsnSc;
	
	private Float taxVal;
	
	private Float igstRate;
	
	private Float igstAmt;
	
	private Float cgstRate;
	
	private Float cgstAmt;
	
	private Float sgstRate;
	
	private Float sgstAmt;
	
	private Long taxLiabilityId;
	
	private Float taxableVal;
	

	public String getHsnSc() {
		return hsnSc;
	}
	public void setHsnSc(String hsnSc) {
		this.hsnSc = hsnSc;
	}
	public Float getTaxVal() {
		return taxVal;
	}
	public void setTaxVal(Float taxVal) {
		this.taxVal = taxVal;
	}
	public Float getIgstRate() {
		return igstRate;
	}
	public void setIgstRate(Float igstRate) {
		this.igstRate = igstRate;
	}
	public Float getIgstAmt() {
		return igstAmt;
	}
	public void setIgstAmt(Float igstAmt) {
		this.igstAmt = igstAmt;
	}
	public Float getCgstRate() {
		return cgstRate;
	}
	public void setCgstRate(Float cgstRate) {
		this.cgstRate = cgstRate;
	}
	public Float getCgstAmt() {
		return cgstAmt;
	}
	public void setCgstAmt(Float cgstAmt) {
		this.cgstAmt = cgstAmt;
	}
	public Float getSgstRate() {
		return sgstRate;
	}
	public void setSgstRate(Float sgstRate) {
		this.sgstRate = sgstRate;
	}
	public Float getSgstAmt() {
		return sgstAmt;
	}
	public void setSgstAmt(Float sgstAmt) {
		this.sgstAmt = sgstAmt;
	}
	public Long getTaxLiabilityId() {
		return taxLiabilityId;
	}
	public void setTaxLiabilityId(Long taxLiabilityId) {
		this.taxLiabilityId = taxLiabilityId;
	}
	public Float getTaxableVal() {
		return taxableVal;
	}
	public void setTaxableVal(Float taxableVal) {
		this.taxableVal = taxableVal;
	}
	public Character getItemType() {
		return itemType;
	}
	public void setItemType(Character itemType) {
		this.itemType = itemType;
	}
	
	
	

}
