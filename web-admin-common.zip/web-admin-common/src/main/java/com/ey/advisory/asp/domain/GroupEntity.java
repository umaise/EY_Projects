package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

public class GroupEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Digits(fraction = 0, integer =20)
	private Long  groupEntityId;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String  legalName;
	
	private Boolean isActive;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String  createdBy;
	private Date  createdDate;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String  updatedBy;
	private Date  updatedDate;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String  parentGroupEntityID;

	
	public GroupEntity(Long groupEntityId) {
		this.groupEntityId = groupEntityId;
	}

	public Long getGroupEntityId() {
		return groupEntityId;
	}

	public void setGroupEntityId(Long groupEntityId) {
		this.groupEntityId = groupEntityId;
	}

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getParentGroupEntityID() {
		return parentGroupEntityID;
	}

	public void setParentGroupEntityID(String parentGroupEntityID) {
		this.parentGroupEntityID = parentGroupEntityID;
	}
	
	

}

