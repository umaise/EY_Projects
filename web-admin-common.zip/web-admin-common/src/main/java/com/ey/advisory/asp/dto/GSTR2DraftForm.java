package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class GSTR2DraftForm implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<GSTR2DB2BInvoiceDetails>  b2bList;
	private List<GSTR2DB2BAInvoiceDetails>  b2bAList;
	private List<GSTR2DCDNInvoiceDetails>  cdnList;
	private List<GSTR2DCDNAInvoiceDetails>  cdnaList;
	private Map<String,List<GSTR2DB2BInvoiceDetails>>  b2bMap;
	private Map<String,List<GSTR2DB2BAInvoiceDetails>>   b2bAMap;
	private Double b2bigstTotal;
	private Double b2bcgstTotal;
	private Double b2bsgstTotal;
	private Double b2baigstTotal;
	private Double b2bacgstTotal;
	private Double b2basgstTotal;
	private Double cdnigstTotal;
	private Double cdncgstTotal;
	private Double cdnsgstTotal;
	private Double cdnaigstTotal;
	private Double cdnacgstTotal;
	private Double cdnasgstTotal;
	private Map<String, String> gstnData;
	
	public List<GSTR2DB2BInvoiceDetails> getB2bList() {
		return b2bList;
	}
	public void setB2bList(List<GSTR2DB2BInvoiceDetails> b2bList) {
		this.b2bList = b2bList;
	}
	public List<GSTR2DB2BAInvoiceDetails> getB2bAList() {
		return b2bAList;
	}
	public void setB2bAList(List<GSTR2DB2BAInvoiceDetails> b2bAList) {
		this.b2bAList = b2bAList;
	}
	public List<GSTR2DCDNInvoiceDetails> getCdnList() {
		return cdnList;
	}
	public void setCdnList(List<GSTR2DCDNInvoiceDetails> cdnList) {
		this.cdnList = cdnList;
	}
	public List<GSTR2DCDNAInvoiceDetails> getCdnaList() {
		return cdnaList;
	}
	public void setCdnaList(List<GSTR2DCDNAInvoiceDetails> cdnaList) {
		this.cdnaList = cdnaList;
	}
	public Double getB2bigstTotal() {
		return b2bigstTotal;
	}
	public void setB2bigstTotal(Double b2bigstTotal) {
		this.b2bigstTotal = b2bigstTotal;
	}
	public Double getB2bcgstTotal() {
		return b2bcgstTotal;
	}
	public void setB2bcgstTotal(Double b2bcgstTotal) {
		this.b2bcgstTotal = b2bcgstTotal;
	}
	public Double getB2bsgstTotal() {
		return b2bsgstTotal;
	}
	public void setB2bsgstTotal(Double b2bsgstTotal) {
		this.b2bsgstTotal = b2bsgstTotal;
	}
	public Double getB2baigstTotal() {
		return b2baigstTotal;
	}
	public void setB2baigstTotal(Double b2baigstTotal) {
		this.b2baigstTotal = b2baigstTotal;
	}
	public Double getB2bacgstTotal() {
		return b2bacgstTotal;
	}
	public void setB2bacgstTotal(Double b2bacgstTotal) {
		this.b2bacgstTotal = b2bacgstTotal;
	}
	public Double getB2basgstTotal() {
		return b2basgstTotal;
	}
	public void setB2basgstTotal(Double b2basgstTotal) {
		this.b2basgstTotal = b2basgstTotal;
	}
	public Double getCdnigstTotal() {
		return cdnigstTotal;
	}
	public void setCdnigstTotal(Double cdnigstTotal) {
		this.cdnigstTotal = cdnigstTotal;
	}
	public Double getCdncgstTotal() {
		return cdncgstTotal;
	}
	public void setCdncgstTotal(Double cdncgstTotal) {
		this.cdncgstTotal = cdncgstTotal;
	}
	public Double getCdnsgstTotal() {
		return cdnsgstTotal;
	}
	public void setCdnsgstTotal(Double cdnsgstTotal) {
		this.cdnsgstTotal = cdnsgstTotal;
	}
	public Double getCdnaigstTotal() {
		return cdnaigstTotal;
	}
	public void setCdnaigstTotal(Double cdnaigstTotal) {
		this.cdnaigstTotal = cdnaigstTotal;
	}
	public Double getCdnacgstTotal() {
		return cdnacgstTotal;
	}
	public void setCdnacgstTotal(Double cdnacgstTotal) {
		this.cdnacgstTotal = cdnacgstTotal;
	}
	public Double getCdnasgstTotal() {
		return cdnasgstTotal;
	}
	public void setCdnasgstTotal(Double cdnasgstTotal) {
		this.cdnasgstTotal = cdnasgstTotal;
	}
	
	public Map<String, List<GSTR2DB2BInvoiceDetails>> getB2bMap() {
		return b2bMap;
	}
	public void setB2bMap(Map<String, List<GSTR2DB2BInvoiceDetails>> b2bMap) {
		this.b2bMap = b2bMap;
	}
	public Map<String, List<GSTR2DB2BAInvoiceDetails>> getB2bAMap() {
		return b2bAMap;
	}
	public void setB2bAMap(Map<String, List<GSTR2DB2BAInvoiceDetails>> b2bAMap) {
		this.b2bAMap = b2bAMap;
	}
	public Map<String, String> getGstnData() {
		return gstnData;
	}
	public void setGstnData(Map<String, String> gstnData) {
		this.gstnData = gstnData;
	}
	
	
	}
