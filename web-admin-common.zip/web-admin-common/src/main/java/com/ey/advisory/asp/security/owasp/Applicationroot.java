package com.ey.advisory.asp.security.owasp;

import java.io.Serializable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Applicationroot implements Serializable
{

@SerializedName("application")
@Expose
private Application application;
private final static long serialVersionUID = -2280066754500631963L;

public Application getApplication() {
return application;
}

public void setApplication(Application application) {
this.application = application;
}

}