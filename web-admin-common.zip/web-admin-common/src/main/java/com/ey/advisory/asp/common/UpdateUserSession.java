package com.ey.advisory.asp.common;

import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.stereotype.Service;
import com.ey.advisory.asp.domain.User;
import com.ey.advisory.asp.dto.FunctionDto;
import com.ey.advisory.asp.dto.GroupDto;
import com.ey.advisory.asp.security.azureAd.AuthHelper;
import com.ey.advisory.asp.service.SecurityLogsService;
import com.ey.advisory.asp.service.UserRoleService;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;
import com.ey.advisory.asp.util.RedisSessionUtility;

@Service
@PropertySource("classpath:AdFileter.properties")
public class UpdateUserSession {

	@Value("${isAzure}")
	private String isAzure;

	@Autowired
	private RedisSessionUtility util;
	
	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	private SecurityLogsService securityLogsService;

	protected static final Logger LOGGER = Logger.getLogger(UpdateUserSession.class);

	public HttpServletRequest updateUserSession(HttpServletRequest request) {
		LOGGER.error("UpdateUserSession.updateUserSession");

		User user;
		Object obj = redisOp.getValueFromRedis(Constant.UPDATED_USER_SESSION, request);
		String updateStatus = (String)( obj==null?"":obj);
		if(updateStatus.equalsIgnoreCase(Constant.TRUE)){
			return request;
		}
		if (!isAzure.equalsIgnoreCase(Constant.TRUE)) {
			HttpSession session = request.getSession(false);
			SecurityContext ctx = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
			Authentication auth = ctx.getAuthentication();
			user = (User) auth.getPrincipal();

			/* Using Redis to store and retrieve session data -start */
			HashMap<String, Object> map = new HashMap<>();
			map.put(Constant.CURRENTUSEREMAILID, user.getEmailId());
			map.put(Constant.USERID, user.getUserId());
			util.updateCache(map, request);

			List<String> keys = new ArrayList<>();
			keys.add(Constant.CURRENTUSEREMAILID);
			keys.add(Constant.USERID);
		
			/* Using Redis to store and retrieve session data - end */
			request.getSession(false).setAttribute(Constant.CURRENTUSEREMAILID, user.getEmailId());

		} else {
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("in updateUserSession ");
			HttpSession session = request.getSession(false);
			session
					.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME);
				
			user = (User)redisOp.getValueFromRedis(Constant.CURRENTUSER, (HttpServletRequest) request);
			
		}
		
		if (LOGGER.isInfoEnabled())
			LOGGER.info(user.getStatesList());
		GroupDto gdto = getGroupDto(user.getGroupDto());
		
	//	redisOp.setValueToRedis(Constant.GROUP_NAME, gdto.getGroupName(), request);
		
		//securityLogsService.logMessage(request, "Selected group "+gdto.getGroupName()+"("+gdto.getGroupCode()+")");
		
		User user1 = (User)redisOp.getValueFromRedis(Constant.CURRENTUSER, (HttpServletRequest) request);
		
		User tempUser = userRoleService.getUserClientDetails(user.getUserId(), gdto.getGroupId().toString());
		
		if (LOGGER.isInfoEnabled()){
			LOGGER.info(tempUser.getReturnPeriod());
			LOGGER.info(tempUser.getDueDateMasterDtoList());
			LOGGER.info(tempUser.getGstindtoList());
		}	
		String taxPeriod = tempUser.getReturnPeriod().getTaxPeriodMMYYYY();
		String month = Month.of(Integer.valueOf(taxPeriod.substring(0, 2))).name();
		String year = taxPeriod.substring(2, 6);

		Set<FunctionDto> appFuncSet = user.getAppFuncSet();
		List<String> functions = new ArrayList<>();
		for (FunctionDto funcDto : appFuncSet) {
			functions.add(funcDto.getFunc());
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(user.getUserName() + " is logged-in ");
			LOGGER.debug("Functions are :-" + functions);
		}

				
		redisOp.setStateListToRedis(user.getStatesList(), request);
		redisOp.setDueDateToRedis(tempUser.getDueDateMasterDtoList(), request);
		
		redisOp.setGSTINToRedis(tempUser.getGstindtoList(), request);
		redisOp.setAllGSTINToRedis(tempUser.getGstindtoList(), request);
		
		redisOp.setGroupSetToRedis(user.getGroupDto(), request);
		redisOp.setValueToRedis(Constant.MONTH_YEAR, month + " " + year, request);
		//redisOp.setValueToRedis(Constant.USER_GROUP, getGroupDto(user.getGroupDto()), request);
		redisOp.setStringListToRedis(Constant.USER_ROLE_FUNS, functions, request);
		redisOp.setValueToRedis(Constant.RETURN_PERIOD, tempUser.getReturnPeriod(), request);
	
		redisOp.setValueToRedis(Constant.CURRENTUSER, user, request);
		redisOp.setValueToRedis(Constant.USER_NAME, user.getUserName(), request);
		redisOp.setValueToRedis(Constant.UPDATED_USER_SESSION, Constant.TRUE, request);
		
		redisOp.setUserAccessMapping(tempUser.getUserAccMapDTOList(), request);
		
		redisOp.setUserEntityHierarchy(tempUser.getEntityHierarchyDtoList(), request);
		
		redisOp.setAllUserEntityHierarchy(tempUser.getEntityHierarchyDtoList(), request);
		
		redisOp.setMasterHierarchyConfigList(user.getMasterHierarchyConfigList(), request);
		
		redisOp.setRoleSetToRedis(user.getRoleSet(), request);
		
		redisOp.setValueToRedis(Constant.SELECTED_ENTITY_REDIS, "0", request);
		redisOp.setValueToRedis(Constant.SELECTED_GSTIN_REDIS, "0", request);
		
		redisOp.setAuthSignGstins(tempUser.getAuthSignGstins(),request);
		
		
		return request;
	}
	
	
	public HttpServletRequest updateUserSessionAdmin(HttpServletRequest request) {
		LOGGER.error("UpdateUserSession.updateUserSession");

		try{
		User user;
		Object obj = redisOp.getValueFromRedis(Constant.UPDATED_USER_SESSION, request);
		String updateStatus = (String)( obj==null?"":obj);
		if(updateStatus.equalsIgnoreCase(Constant.TRUE)){
			return request;
		}
		if (!isAzure.equalsIgnoreCase(Constant.TRUE)) {
			HttpSession session = request.getSession(false);
			SecurityContext ctx = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
			Authentication auth = ctx.getAuthentication();
			user = (User) auth.getPrincipal();

			/* Using Redis to store and retrieve session data -start */
			HashMap<String, Object> map = new HashMap<>();
			map.put(Constant.CURRENTUSEREMAILID, user.getEmailId());
			map.put(Constant.USERID, user.getUserId());
			util.updateCache(map, request);

			List<String> keys = new ArrayList<>();
			keys.add(Constant.CURRENTUSEREMAILID);
			keys.add(Constant.USERID);
		
			/* Using Redis to store and retrieve session data - end */
			request.getSession(false).setAttribute(Constant.CURRENTUSEREMAILID, user.getEmailId());

		} else {
			if (LOGGER.isDebugEnabled())
				LOGGER.debug("in updateUserSession ");
			HttpSession session = request.getSession(false);
			session
					.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME);
		
			user = (User)redisOp.getValueFromRedis(Constant.CURRENTUSER, (HttpServletRequest) request);
			
		}
		
		if (LOGGER.isDebugEnabled())
			LOGGER.info(user.getStatesList());
		GroupDto gdto = getGroupDto(user.getGroupDto());
		//redisOp.setValueToRedis(Constant.GROUP_NAME, gdto.getGroupName(), request);


		Set<FunctionDto> appFuncSet = user.getAppFuncSet();
		List<String> functions = new ArrayList<>();
		for (FunctionDto funcDto : appFuncSet) {
			functions.add(funcDto.getFunc());
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(user.getUserName() + " is logged-in ");
			LOGGER.debug("Functions are :-" + functions);
		}

				
		redisOp.setStateListToRedis(user.getStatesList(), request);
		
		redisOp.setGroupSetToRedis(user.getGroupDto(), request);
		
		//redisOp.setValueToRedis(Constant.USER_GROUP, getGroupDto(user.getGroupDto()), request);
		redisOp.setStringListToRedis(Constant.USER_ROLE_FUNS, functions, request);

	
		redisOp.setValueToRedis(Constant.CURRENTUSER, user, request);
		redisOp.setValueToRedis(Constant.USER_NAME, user.getUserName(), request);
		redisOp.setValueToRedis(Constant.UPDATED_USER_SESSION, Constant.TRUE, request);
		}catch(Exception e){
			LOGGER.error(e.fillInStackTrace());
			LOGGER.error(e.getMessage());
		}

		return request;
	}

	private GroupDto getGroupDto(Set<GroupDto> groupDto) {
		GroupDto grpDto = new GroupDto();

		for (GroupDto groupDtoTmp : groupDto) {

			if (groupDtoTmp != null) {
				grpDto = groupDtoTmp;
				break;
			}

		}

		return grpDto;

	}
	
	

}
