package com.ey.advisory.asp.security.owasp;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;

@Service
public class SecurityUtil {

	@Autowired
	private ResourceLoader resourceLoader;

	private Applicationroot application;

	public Applicationroot getApplication() {
		return application;
	}

	public void setApplication(Applicationroot application) {
		this.application = application;
	}

	@PostConstruct
	public void init() throws IOException {
		Gson gson = new Gson();
		Resource resource = resourceLoader.getResource("classpath:/security/securityconfig.json");
		String json = IOUtils.toString(resource.getInputStream());
		Applicationroot application = gson.fromJson(json, Applicationroot.class);
		this.setApplication(application);
	}

	public Param paramDetails(String controllerName, String relativeUrl, String paramName) {
		return this.getApplication().getApplication().getControllers().getController().stream()
				.filter(controlname -> controlname.getControllername().equals(controllerName)).findFirst().orElse(null)
				.getUrls().getUrl().stream().filter(url -> url.getRelativeurl().equals(relativeUrl)).findFirst()
				.orElse(null).getParams().getParam().stream().filter(params -> params.getParamname().equals(paramName))
				.findFirst().orElse(null);

	}

	public boolean isControllerAvailable(String controllername) {
		return this.getApplication().getApplication().getControllers().getController().stream()
				.filter(controlname -> controlname.getControllername().equals(controllername)).findFirst().isPresent();
	}

	public boolean isUrlAvailable(String controllername, String relativeUrl) {
		return this.getApplication().getApplication().getControllers().getController().stream()
				.filter(controlname -> controlname.getControllername().equals(controllername)).findFirst().orElse(null)
				.getUrls().getUrl().stream().filter(url -> url.getRelativeurl().equals(relativeUrl)).findFirst()
				.isPresent();
	}

	public boolean isParamAvailable(String controllername, String relativeUrl, String paramName) {
		return this.getApplication().getApplication().getControllers().getController().stream()
				.filter(controlname -> controlname.getControllername().equals(controllername)).findFirst().orElse(null)
				.getUrls().getUrl().stream().filter(url -> url.getRelativeurl().equals(relativeUrl)).findFirst()
				.orElse(null).getParams().getParam().stream().filter(params -> params.getParamname().equals(paramName))
				.findFirst().isPresent();
	}

}
