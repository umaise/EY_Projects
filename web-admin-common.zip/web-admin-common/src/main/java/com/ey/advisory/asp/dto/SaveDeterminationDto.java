package com.ey.advisory.asp.dto;

import java.util.List;
import java.util.Map;

public class SaveDeterminationDto {

	private String financialYear;
	private String month;
	private String isdGSTIN;
	private String tabId;
	private String recordType;
	private List<Map<String,String>> tabRows;
	private List<Map<String,String>> treeTabRows;
	
	
	public String getFinancialYear() {
		return financialYear;
	}
	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getIsdGSTIN() {
		return isdGSTIN;
	}
	public void setIsdGSTIN(String isdGSTIN) {
		this.isdGSTIN = isdGSTIN;
	}
	public String getTabId() {
		return tabId;
	}
	public void setTabId(String tabId) {
		this.tabId = tabId;
	}
	public List<Map<String, String>> getTabRows() {
		return tabRows;
	}
	public void setTabRows(List<Map<String, String>> tabRows) {
		this.tabRows = tabRows;
	}
	public List<Map<String, String>> getTreeTabRows() {
		return treeTabRows;
	}
	public void setTreeTabRows(List<Map<String, String>> treeTabRows) {
		this.treeTabRows = treeTabRows;
	}
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
}
