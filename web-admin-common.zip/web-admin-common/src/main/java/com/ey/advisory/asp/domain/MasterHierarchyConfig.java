/**
 * 
 */
package com.ey.advisory.asp.domain;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

/**
 * @author Nitesh.Tripathi
 *
 */
public class MasterHierarchyConfig implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Digits(fraction = 0, integer =20)
	private Integer hierarchyConfigID;

	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String orgLevel;

	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String orgLevelValue;

	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String homePageRef;

	/**
	 * @return the hierarchyConfigID
	 */
	public Integer getHierarchyConfigID() {
		return hierarchyConfigID;
	}

	/**
	 * @return the orgLevel
	 */
	public String getOrgLevel() {
		return orgLevel;
	}

	/**
	 * @return the orgLevelValue
	 */
	public String getOrgLevelValue() {
		return orgLevelValue;
	}

	/**
	 * @return the homePageRef
	 */
	public String getHomePageRef() {
		return homePageRef;
	}

	/**
	 * @param hierarchyConfigID
	 *            the hierarchyConfigID to set
	 */
	public void setHierarchyConfigID(Integer hierarchyConfigID) {
		this.hierarchyConfigID = hierarchyConfigID;
	}

	/**
	 * @param orgLevel
	 *            the orgLevel to set
	 */
	public void setOrgLevel(String orgLevel) {
		this.orgLevel = orgLevel;
	}

	/**
	 * @param orgLevelValue
	 *            the orgLevelValue to set
	 */
	public void setOrgLevelValue(String orgLevelValue) {
		this.orgLevelValue = orgLevelValue;
	}

	/**
	 * @param homePageRef
	 *            the homePageRef to set
	 */
	public void setHomePageRef(String homePageRef) {
		this.homePageRef = homePageRef;
	}

}
