package com.ey.advisory.asp.dto;

import javax.xml.bind.annotation.XmlElement;

public class Gstr3BSecEligibleItc {
	
	@XmlElement
	private Gstr3BSecEligibleItcSubElements ImportGoods = new Gstr3BSecEligibleItcSubElements();
	
	@XmlElement
	private Gstr3BSecEligibleItcSubElements ImportServices = new Gstr3BSecEligibleItcSubElements();
	
	@XmlElement
	private Gstr3BSecEligibleItcSubElements InwardRevCharge = new Gstr3BSecEligibleItcSubElements();
	
	@XmlElement
	private Gstr3BSecEligibleItcSubElements InwardISD = new Gstr3BSecEligibleItcSubElements();
	
	@XmlElement
	private Gstr3BSecEligibleItcSubElements OtherITC = new Gstr3BSecEligibleItcSubElements();
	
	
	private Gstr3BSecEligibleItcSubElements CGSTRules = new Gstr3BSecEligibleItcSubElements();
	
	@XmlElement
	private Gstr3BSecEligibleItcSubElements Others = new Gstr3BSecEligibleItcSubElements();
	
	@XmlElement
	private Gstr3BSecEligibleItcSubElements Section17 = new Gstr3BSecEligibleItcSubElements();
	
	@XmlElement
	private Gstr3BSecEligibleItcSubElements Sec4Others = new Gstr3BSecEligibleItcSubElements();

	@XmlElement
	public Gstr3BSecEligibleItcSubElements getImportGoods() {
		return ImportGoods;
	}

	public void setImportGoods(Gstr3BSecEligibleItcSubElements importGoods) {
		ImportGoods = importGoods;
	}

	@XmlElement
	public Gstr3BSecEligibleItcSubElements getImportServices() {
		return ImportServices;
	}

	public void setImportServices(Gstr3BSecEligibleItcSubElements importServices) {
		ImportServices = importServices;
	}

	@XmlElement
	public Gstr3BSecEligibleItcSubElements getInwardRevCharge() {
		return InwardRevCharge;
	}

	public void setInwardRevCharge(Gstr3BSecEligibleItcSubElements inwardRevCharge) {
		InwardRevCharge = inwardRevCharge;
	}

	@XmlElement
	public Gstr3BSecEligibleItcSubElements getInwardISD() {
		return InwardISD;
	}

	public void setInwardISD(Gstr3BSecEligibleItcSubElements inwardISD) {
		InwardISD = inwardISD;
	}

	@XmlElement
	public Gstr3BSecEligibleItcSubElements getOtherITC() {
		return OtherITC;
	}

	public void setOtherITC(Gstr3BSecEligibleItcSubElements otherITC) {
		OtherITC = otherITC;
	}

	@XmlElement
	public Gstr3BSecEligibleItcSubElements getCGSTRules() {
		return CGSTRules;
	}

	public void setCGSTRules(Gstr3BSecEligibleItcSubElements cGSTRules) {
		CGSTRules = cGSTRules;
	}

	@XmlElement
	public Gstr3BSecEligibleItcSubElements getOthers() {
		return Others;
	}

	public void setOthers(Gstr3BSecEligibleItcSubElements others) {
		Others = others;
	}

	@XmlElement
	public Gstr3BSecEligibleItcSubElements getSection17() {
		return Section17;
	}

	public void setSection17(Gstr3BSecEligibleItcSubElements section17) {
		Section17 = section17;
	}

	@XmlElement
	public Gstr3BSecEligibleItcSubElements getSec4Others() {
		return Sec4Others;
	}

	public void setSec4Others(Gstr3BSecEligibleItcSubElements sec4Others) {
		Sec4Others = sec4Others;
	}

	@Override
	public String toString() {
		return "Gstr3BSecEligibleItc [ImportGoods=" + ImportGoods + ", ImportServices=" + ImportServices
				+ ", InwardRevCharge=" + InwardRevCharge + ", InwardISD=" + InwardISD + ", OtherITC=" + OtherITC
				+ ", CGSTRules=" + CGSTRules + ", Others=" + Others + ", Section17=" + Section17 + ", Sec4Others="
				+ Sec4Others + "]";
	}
	
	
	

}
