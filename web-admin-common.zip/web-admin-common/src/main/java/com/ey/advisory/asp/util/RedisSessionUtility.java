package com.ey.advisory.asp.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.google.gson.Gson;

/**
 * @author Shreya.Mukund
 *
 */

@Service
@PropertySource("classpath:AdFileter.properties")
public class RedisSessionUtility {
	
	@Value("${isAzure}")
	private String isAzure;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	public RedisTemplate<String, Object> getRedisTemplate() {
        return redisTemplate;
    }

    private static final Logger LOGGER = Logger.getLogger(RedisSessionUtility.class);

	public void updateCache(Map<String, Object> map, HttpServletRequest request) {

		for (Map.Entry<String, Object> entry : map.entrySet()) {
			try {

				updateCache(entry.getKey(), entry.getValue(), request);

			} catch (Exception e) {
				LOGGER.error("Exception in redis cache update method", e);
			}
		}

	}

	public void updateCacheList(String key, List<Object> value, HttpServletRequest request) {

		String sessionId = getFetchId(request);//request.getSession(false).getId();
		String redisKey = sessionId + "_" + key;
		redisTemplate.opsForList().rightPushAll(redisKey, value);

	}
	
	public List<Object> getCacheList(String key, HttpServletRequest request) {

		String sessionId = getFetchId(request);//request.getSession(false).getId();
		String redisKey = sessionId + "_" + key;
		List<Object> redisList = (List<Object>) redisTemplate.opsForHash().get(sessionId, redisKey);
		return redisList;
	}
	
	public void updateCache(String key, Object value, HttpServletRequest request) {

		String sessionId = getFetchId(request);//request.getSession(false).getId();
		String redisKey = sessionId + "_" + key;
		redisTemplate.opsForHash().put(sessionId, redisKey, value);

	}
	
	public void updateCache(String key, List<Object> value, HttpServletRequest request) {

		String sessionId = getFetchId(request);//request.getSession(false).getId();
		String redisKey = sessionId + "_" + key;
		String val = convertToJson(value);
		redisTemplate.opsForHash().put(sessionId, redisKey, val);

	}
	
	public Map<String, Object> retrieveFromCache(List<String> keys, HttpServletRequest request) {
		HashMap<String, Object> map = new HashMap<>();
		try {

			for (String key : keys) {
				if(LOGGER.isDebugEnabled()){
				LOGGER.debug("Cache Data retrieved: " + key);
				}
				map.put(key, retrieveFromCache(key, request));
			}
		} catch (Exception e) {
			LOGGER.error("Exception in redis cache fetch method", e);
		}
		return map;

	}

	public Object retrieveFromCache(String key, HttpServletRequest request) {

		String sessionId = getFetchId(request);//request.getSession(false).getId();
		return redisTemplate.opsForHash().get(sessionId, sessionId + "_" + key);
	}
	
	public Object retrieveFromCache(String key) {
		
		//Constant.REDIS_CACHE
		return redisTemplate.opsForHash().get(Constant.REDIS_CACHE, key);
	}
	
	public String convertToJson(List<Object> objList){
		
		 Gson gson=new Gson();
		 return gson.toJson(objList);
	}

	public void deleteSession(HttpServletRequest request) {

		String sessionId = getFetchId(request);// request.getSession(false).getId();
		redisTemplate.delete(sessionId);

	}
	public String getStatusFromRedisCache(String gstinId) {
		String status=null;
		try
		{
		RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<String, String>();
        RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
        redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.afterPropertiesSet();
		Map<Object, Object> entries = redisIntegertemplate.opsForHash().entries(gstinId);
        status=(String) entries.get("status");
        }catch(Exception ex)
		{
        	LOGGER.error("Exception in redis cache fetch method", ex);
		}
				
		return status;
	}
		
	private String getFetchId(HttpServletRequest request){
		String id = "";//id=getCookieValue(request,"IdVal");
		//System.out.println("getFetchId IdVal:-"+ id);
		//System.out.println("getCookieValue :-"+getCookieValue(request,"IdVal"));
		
		if (!isAzure.equalsIgnoreCase(Constant.TRUE)) {
			id = request.getSession(false).getId();
		}else{
			id=(String) request.getAttribute("IdVal");
		}
		
		return  id;
	}
	
	public Map<Object, Object> getGSPAuthTokenFromRedisCache(String groupIndicator) {
		try {
			RedisTemplateUtils<String, String> redisIntegertemplateUtil = new RedisTemplateUtils<String, String>();
			RedisTemplate<String, String> redisIntegertemplate = redisIntegertemplateUtil.getRedisTemplate();
			redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
			redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
			redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
			redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
			redisIntegertemplate.afterPropertiesSet();
			return redisIntegertemplate.opsForHash().entries(groupIndicator);
		} catch (Exception ex) {
			LOGGER.error("Exception in redis cache fetch method", ex);
		}

		return null;
	}
	
	public String getDateModifiedFromRedisCache(String gstinId) {
        String dateModified=null;
        try
        {
        RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<String, String>();
   RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
   redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
   redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
   redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
   redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
   redisIntegertemplate.afterPropertiesSet();
        Map<Object, Object> entries = redisIntegertemplate.opsForHash().entries(gstinId);
        if(null!= entries){
        dateModified=(String) entries.get("dateModified");
        }
   }catch(Exception ex)
        {
        LOGGER.error("Exception in redis cache fetch method", ex);
        }
                     
        return dateModified;
  }

	public String getDateModifiedFromRedisCacheForGsp(String groupCode) {
        String dateModified=null;
        try
        {
           RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<String, String>();
		   RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
		   redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
		   redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
		   redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
		   redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
		   redisIntegertemplate.afterPropertiesSet();
           Map<Object, Object> entries = redisIntegertemplate.opsForHash().entries(groupCode.toLowerCase()+"_"+Constant.GSP_USERDETAILS);
	       if(null != entries){
	    	   dateModified=(String) entries.get("dateModified");
	       }   
           
	   }catch(Exception ex)
	        {
	        LOGGER.error("Exception in redis cache fetch method", ex);
	        }
                     
        return dateModified;
  }
}
