/*package com.ey.advisory.asp.common;

import java.util.HashMap;
import java.util.Map;

public class DigitalSignMap {

	private static Map<String, Long> cache = new HashMap<String, Long>();
	
	private static Map<String, String> cacheFiled = new HashMap<String, String>();

	public static Long getCacheValue(String key) {
		return cache.get(key);
	}

	public static void setCacheValue(String key, Long value) {
		DigitalSignMap.cache.put(key, value);
	}

	public static void deleteEntry(String key) {
		DigitalSignMap.cache.remove(key);
	}
	
	public static String getCacheFiledValue(String key) {
		return cacheFiled.get(key);
	}

	public static void setCacheFiledValue(String key, String value) {
		DigitalSignMap.cacheFiled.put(key, value);
	}

	public static void deleteCacheFiledEntry(String key) {
		DigitalSignMap.cacheFiled.remove(key);
	}

}
*/