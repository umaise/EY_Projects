package com.ey.advisory.asp.reports.jasper.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.reports.jasper.entity.GSTR6SummaryData;
import com.ey.advisory.asp.reports.jasper.entity.GSTR6Summary_row;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class GSTR6SummaryFiller extends AbstractReportFiller{
	
	private static final Logger logger = Logger.getLogger(GSTR6SummaryFiller.class);

	@Override
	public byte[] getJasperReport(Object reportData, String reportPath) {

		byte[] pdfReport = null;

		try {
			logger.debug("--------------generate GSTR6Summary PDF report----------");

			GSTR6SummaryData data = (GSTR6SummaryData) reportData;

			JsonParser parser = new JsonParser();
			if(data.getGstr6Sum()!=null){
					
				
				JsonObject reportJSON = parser.parse(data.getGstr6Sum()).getAsJsonObject();
				JsonArray ja = reportJSON.getAsJsonArray(Constant.GSTR6_JSON);
				JsonObject mainObj = ja.get(0).getAsJsonObject();
				JsonArray sectionSummery = mainObj.getAsJsonArray(Constant.SECTION_SUMMARY);
	
				// Map to hold Jasper report Parameters
				Map<String, Object> parameters = new HashMap<>();
				parameters.put(Constant.REPORT_NAME, data.getReportName()!=null?data.getReportName():"");
				parameters.put(Constant.GSTIN_JSON, data.getGstnId()!=null?data.getGstnId():"");
				parameters.put(Constant.BUSINESS_NAME, data.getBusinessName()!=null?data.getBusinessName():"");
				parameters.put(Constant.FINANCIAL_YEAR, data.getfYear()!=null?data.getfYear():"");
				parameters.put(Constant.RETURNPERIOD, data.getReturnPeriod()!=null?data.getReturnPeriod():"");
				parameters.put(Constant.DUE_DATE, data.getDueDate()!=null?data.getDueDate():"");
	
				// @@@@ Below logic will change
				JsonObject section;
				List<GSTR6Summary_row> listItems;
				JRBeanCollectionDataSource itemsJRBean;
				GSTR6Summary_row oneRow;
				String jasperRSec;
				for (int index = 0; index < sectionSummery.size(); index++) {
					section = sectionSummery.get(index).getAsJsonObject();
					jasperRSec = section.get(Constant.SECTION_NAME).getAsString().trim();
	
					if (jasperRSec != null) {
						oneRow = new GSTR6Summary_row();
						oneRow.setTtlValue(section.get(Constant.TOTAL_TAXABLE_VALUE)!=null?section.get(Constant.TOTAL_TAXABLE_VALUE).getAsDouble():new Double(0));
						oneRow.setTaxPd(section.get(Constant.TAX_PAID)!=null?section.get(Constant.TAX_PAID).getAsDouble():new Double(0));
						oneRow.setItcAv(section.get(Constant.ITC_AVAILED)!=null?section.get(Constant.ITC_AVAILED).getAsDouble():new Double(0));
						oneRow.setChecksum(section.get(Constant.CHECKSUM)!=null?section.get(Constant.CHECKSUM).getAsString():"");
						JsonArray cptSection =section.get(Constant.COUNTER_PARTY_SUMMARY).getAsJsonArray();
						JsonObject cptObject= cptSection.get(0).getAsJsonObject();
						oneRow.setCptItcAv(cptObject.get(Constant.ITC_AVAILED)!=null?cptObject.get(Constant.ITC_AVAILED).getAsDouble():new Double(0));	
						oneRow.setCptTaxPd(cptObject.get(Constant.TAX_PAID)!=null?cptObject.get(Constant.TAX_PAID).getAsDouble():new Double(0));
						
						oneRow.setCptTtlValue(cptObject.get(Constant.TOTAL_TAXABLE_VALUE)!=null?cptObject.get(Constant.TOTAL_TAXABLE_VALUE).getAsDouble():new Double(0));
													
						listItems = new ArrayList<>();
						listItems.add(oneRow);
						itemsJRBean = new JRBeanCollectionDataSource(listItems);
						parameters.put(jasperRSec, itemsJRBean);
					}
	
				}
	
				JasperPrint jasperPrint = GSTR6SummaryFiller.getReport(parameters, reportPath);
	
				pdfReport = JasperExportManager.exportReportToPdf(jasperPrint);
			}else{
					throw new NullPointerException("Json Response is null");
			}
		} catch (Exception e) {
			logger.error("Exception occured in GSTR1SummaryFiller.getGSTR6SummeryReport report :  ", e);
		}
		return pdfReport;

	}
	
	private static JasperPrint getReport(Map<String, Object> parameters, String masterReportPath) {
		JasperPrint jasperPrint = null;
		try {
			jasperPrint = JasperFillManager.fillReport(masterReportPath, parameters, new JREmptyDataSource());
		} catch (JRException e) {
			logger.error("Exception occured in GSTR6SummaryFiller.getReport report :  ", e);
		}
		return jasperPrint;
	}	

}
