/**
 * 
 */
package com.ey.advisory.asp.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.domain.RoleAccessHierarchyMap;
import com.ey.advisory.asp.util.RedisOperationForSessionObj;

/**
 * @author Nitesh.Tripathi
 *
 */
@Service
public class OnBoardValidationServiceImpl implements OnBoardValidationService {
	
	
	private static final Logger LOGGER = Logger
			.getLogger(OnBoardValidationServiceImpl.class);
	
	@Autowired
	private RedisOperationForSessionObj redisOp;
	
	@Override
	public boolean isValidRoleAccessLevelMap(String accessLevel, long roleId){
		
		LOGGER.info("OnBoardValidationServiceImpl.isValidRoleAccessLevelMap - "+accessLevel+"--"+roleId);
		
		boolean isvalid = Constant.BOOLEAN_FALSE;
		
		List<RoleAccessHierarchyMap> roleAccessHierarchyMap = redisOp.getRoleAccessLevelMapList();
		
		for(RoleAccessHierarchyMap roleAccLvl:roleAccessHierarchyMap){
			
			if(roleAccLvl.getRoleID() == roleId){
				if(roleAccLvl.getMasterHierarchyConfig().getOrgLevel().equalsIgnoreCase(accessLevel)){
					isvalid = Constant.BOOLEAN_TRUE;
					break;
				}
			}
			
		}
		LOGGER.info(isvalid+" --> OnBoardValidationServiceImpl.isValidRoleAccessLevelMap - "+accessLevel+"--"+roleId);
		return isvalid;
		
		
	}

}
