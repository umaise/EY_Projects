package com.ey.advisory.asp.dto;

import java.io.Serializable;



public class LegalEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long legalEntityId;
	private String legalEntityName;
	
	
	public Long getLegalEntityId() {
		return legalEntityId;
	}
	public void setLegalEntityId(Long legalEntityId) {
		this.legalEntityId = legalEntityId;
	}
	

	public String getLegalEntityName() {
		return legalEntityName;
	}
	public void setLegalEntityName(String legalEntityName) {
		this.legalEntityName = legalEntityName;
	}
	
	

}
