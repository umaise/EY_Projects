package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;


/**
 * The persistent class for the tblReturnPeriod database table.
 * 
 */

public class ReturnPeriod implements Serializable {
	private static final long serialVersionUID = 1L;
	@Digits(fraction = 0, integer =20)
	private Integer periodId;

	
	private Date endDt;
	
	private boolean isCurrentPeriod;


	private Date startDt;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String taxPeriod;
	
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String taxPeriodMMYYYY;

	public ReturnPeriod() {
	}

	public Integer getPeriodId() {
		return this.periodId;
	}

	public void setPeriodId(Integer periodId) {
		this.periodId = periodId;
	}

	public Date getEndDt() {
		return this.endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public boolean getIsCurrentPeriod() {
		return this.isCurrentPeriod;
	}

	public void setIsCurrentPeriod(boolean isCurrentPeriod) {
		this.isCurrentPeriod = isCurrentPeriod;
	}

	public Date getStartDt() {
		return this.startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	/**
	 * @return the taxPeriod
	 */
	public String getTaxPeriod() {
		return taxPeriod;
	}

	/**
	 * @param taxPeriod the taxPeriod to set
	 */
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	/**
	 * @return the taxPeriodMMYYYY
	 */
	public String getTaxPeriodMMYYYY() {
		return taxPeriodMMYYYY;
	}

	/**
	 * @param taxPeriodMMYYYY the taxPeriodMMYYYY to set
	 */
	public void setTaxPeriodMMYYYY(String taxPeriodMMYYYY) {
		this.taxPeriodMMYYYY = taxPeriodMMYYYY;
	}

	/**
	 * @param isCurrentPeriod the isCurrentPeriod to set
	 */
	public void setCurrentPeriod(boolean isCurrentPeriod) {
		this.isCurrentPeriod = isCurrentPeriod;
	}

}