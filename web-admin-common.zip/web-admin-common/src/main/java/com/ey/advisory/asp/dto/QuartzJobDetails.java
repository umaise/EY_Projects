package com.ey.advisory.asp.dto;

import java.io.Serializable;


public class QuartzJobDetails implements Serializable {

    private static final long serialVersionUID = 1L;
	private QuartzJobDetailsPK quartzJobDetailsPK;
    
	private String description;
	
	private String jobClassName;
	
	private boolean isDurable;
	
	private boolean isNonConcurrent;
	
	private boolean isUpdateData;
	
	private boolean requestsRecovery;
	
	private String  jobData;


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getJobClassName() {
		return jobClassName;
	}

	public void setJobClassName(String jobClassName) {
		this.jobClassName = jobClassName;
	}

	public boolean isDurable() {
		return isDurable;
	}

	public void setDurable(boolean isDurable) {
		this.isDurable = isDurable;
	}

	public boolean isNonConcurrent() {
		return isNonConcurrent;
	}

	public void setNonConcurrent(boolean isNonConcurrent) {
		this.isNonConcurrent = isNonConcurrent;
	}

	public boolean isUpdateData() {
		return isUpdateData;
	}

	public void setUpdateData(boolean isUpdateData) {
		this.isUpdateData = isUpdateData;
	}

	public boolean isRequestsRecovery() {
		return requestsRecovery;
	}

	public void setRequestsRecovery(boolean requestsRecovery) {
		this.requestsRecovery = requestsRecovery;
	}

	public String getJobData() {
		return jobData;
	}

	public void setJobData(String jobData) {
		this.jobData = jobData;
	}
	
	

	public QuartzJobDetailsPK getQuartzJobDetailsPK() {
		return quartzJobDetailsPK;
	}

	public void setQuartzJobDetailsPK(QuartzJobDetailsPK quartzJobDetailsPK) {
		this.quartzJobDetailsPK = quartzJobDetailsPK;
	}

	@Override
	public String toString() {
		return "QuartzJobDetails [description=" + description
				+ ", jobClassName=" + jobClassName + ", isDurable=" + isDurable
				+ ", isNonConcurrent=" + isNonConcurrent + ", isUpdateData="
				+ isUpdateData + ", requestsRecovery=" + requestsRecovery
				+ ", jobData=" + jobData + "]";
	}

	
	
	
}
