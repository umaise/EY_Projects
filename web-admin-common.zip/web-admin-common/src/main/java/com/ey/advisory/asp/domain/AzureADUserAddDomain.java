package com.ey.advisory.asp.domain;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

public class AzureADUserAddDomain {

	
	private boolean accountEnabled = true;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String displayName;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String mailNickname;
	@Pattern(regexp = "^[0-9]+$")
	private String mobile;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String userPrincipalName;
	
	@JsonProperty("passwordProfile")
	@SerializedName("passwordProfile")
	private AzureADPasswordProfileDomain azureADPasswordProfileDomain;

	/**
	 * @return the accountEnabled
	 */
	public boolean isAccountEnabled() {
		return accountEnabled;
	}

	/**
	 * @param accountEnabled the accountEnabled to set
	 */
	public void setAccountEnabled(boolean accountEnabled) {
		this.accountEnabled = accountEnabled;
	}

	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @return the mailNickname
	 */
	public String getMailNickname() {
		return mailNickname;
	}

	/**
	 * @param mailNickname the mailNickname to set
	 */
	public void setMailNickname(String mailNickname) {
		this.mailNickname = mailNickname;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the userPrincipalName
	 */
	public String getUserPrincipalName() {
		return userPrincipalName;
	}

	/**
	 * @param userPrincipalName the userPrincipalName to set
	 */
	public void setUserPrincipalName(String userPrincipalName) {
		this.userPrincipalName = userPrincipalName;
	}

	/**
	 * @return the azureADPasswordProfileDomain
	 */
	public AzureADPasswordProfileDomain getAzureADPasswordProfileDomain() {
		return azureADPasswordProfileDomain;
	}

	/**
	 * @param azureADPasswordProfileDomain the azureADPasswordProfileDomain to set
	 */
	public void setAzureADPasswordProfileDomain(AzureADPasswordProfileDomain azureADPasswordProfileDomain) {
		this.azureADPasswordProfileDomain = azureADPasswordProfileDomain;
	}


	
}
