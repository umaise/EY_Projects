/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.io.Serializable;


import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Uma.Chandranaik
 *
 */
public class CashITCLedgerMaster  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long cashItcMasterId;

	private String GSTIN;
	
	private String taxPeriod;
	
	private boolean isActive;
	
	private String createdOn;
	
	private String modifiedOn;

	public Long getCashItcMasterId() {
		return cashItcMasterId;
	}

	public void setCashItcMasterId(Long cashItcMasterId) {
		this.cashItcMasterId = cashItcMasterId;
	}

	public String getGSTIN() {
		return GSTIN;
	}

	public void setGSTIN(String gSTIN) {
		GSTIN = gSTIN;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
	
	
}
