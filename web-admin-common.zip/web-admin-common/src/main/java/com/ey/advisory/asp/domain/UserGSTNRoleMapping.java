package com.ey.advisory.asp.domain;

import java.io.Serializable;

import javax.validation.constraints.Digits;

public class UserGSTNRoleMapping implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Digits(fraction = 0, integer =10)
	private Long  userMappingId;
	
	private User userId;
	
	private GSTIN gstnId;
	
	private Role roleId;
	
	private GroupEntity groupEntity;

	
	
	public UserGSTNRoleMapping() {
	}

	public UserGSTNRoleMapping(GSTIN gstnId, Role roleId, GroupEntity groupEntity) {
		this.gstnId = gstnId;
		this.roleId = roleId;
		this.groupEntity = groupEntity;
	}

	public UserGSTNRoleMapping(Long userMappingId, GSTIN gstnId, Role roleId, GroupEntity groupEntity) {
		super();
		this.userMappingId = userMappingId;
		this.gstnId = gstnId;
		this.roleId = roleId;
		this.groupEntity = groupEntity;
	}

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	public Long getUserMappingId() {
		return userMappingId;
	}

	public void setUserMappingId(Long userMappingId) {
		this.userMappingId = userMappingId;
	}

	public GSTIN getGstnId() {
		return gstnId;
	}

	public void setGstnId(GSTIN gstnId) {
		this.gstnId = gstnId;
	}

	public Role getRoleId() {
		return roleId;
	}

	public void setRoleId(Role roleId) {
		this.roleId = roleId;
	}

	public GroupEntity getGroupEntity() {
		return groupEntity;
	}

	public void setGroupEntity(GroupEntity groupEntity) {
		this.groupEntity = groupEntity;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((groupEntity == null) ? 0 : groupEntity.hashCode());
		result = prime * result + ((gstnId == null) ? 0 : gstnId.hashCode());
		result = prime * result + ((roleId == null) ? 0 : roleId.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((userMappingId == null) ? 0 : userMappingId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserGSTNRoleMapping other = (UserGSTNRoleMapping) obj;
		if (groupEntity == null) {
			if (other.groupEntity != null)
				return false;
		} else if (!groupEntity.equals(other.groupEntity))
			return false;
		if (gstnId == null) {
			if (other.gstnId != null)
				return false;
		} else if (!gstnId.equals(other.gstnId))
			return false;
		if (roleId == null) {
			if (other.roleId != null)
				return false;
		} else if (!roleId.equals(other.roleId))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		if (userMappingId == null) {
			if (other.userMappingId != null)
				return false;
		} else if (!userMappingId.equals(other.userMappingId))
			return false;
		return true;
	}
	
	


	

}
