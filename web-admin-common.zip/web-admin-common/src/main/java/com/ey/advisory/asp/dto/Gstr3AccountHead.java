package com.ey.advisory.asp.dto;

import java.io.Serializable;
import java.math.BigInteger;

import org.apache.log4j.Logger;


public class Gstr3AccountHead implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(Gstr3AccountHead.class);

	private BigInteger taxHeadId;
	
	private String taxHead ;
	
	private int displayOrder;

	public BigInteger getTaxHeadId() {
		return taxHeadId;
	}

	public void setTaxHeadId(BigInteger taxHeadId) {
		this.taxHeadId = taxHeadId;
	}

	public String getTaxHead() {
		return taxHead;
	}

	public void setTaxHead(String taxHead) {
		this.taxHead = taxHead;
	}

	public int getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}
	
	public Gstr3AccountHead(){
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in Gstr3AccountHead ");
			}
		
	}
	
	
}
