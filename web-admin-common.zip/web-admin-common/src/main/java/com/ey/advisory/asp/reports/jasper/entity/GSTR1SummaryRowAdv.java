package com.ey.advisory.asp.reports.jasper.entity;

public class GSTR1SummaryRowAdv {

	Double taxadjusted;
	Double igst;
	Double cgst;
	Double sgstutgst;
	Double cess;
	
	public Double getTaxadjusted() {
		return taxadjusted;
	}
	public void setTaxadjusted(Double taxadjusted) {
		this.taxadjusted = taxadjusted;
	}
	public Double getIgst() {
		return igst;
	}
	public void setIgst(Double igst) {
		this.igst = igst;
	}
	public Double getCgst() {
		return cgst;
	}
	public void setCgst(Double cgst) {
		this.cgst = cgst;
	}
	public Double getSgstutgst() {
		return sgstutgst;
	}
	public void setSgstutgst(Double sgstutgst) {
		this.sgstutgst = sgstutgst;
	}
	public Double getCess() {
		return cess;
	}
	public void setCess(Double cess) {
		this.cess = cess;
	}
	
	
}
