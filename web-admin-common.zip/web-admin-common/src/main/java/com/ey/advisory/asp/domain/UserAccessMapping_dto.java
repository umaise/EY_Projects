/**
 * 
 */
package com.ey.advisory.asp.domain;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

/**
 * @author Nitesh.Tripathi
 *
 */

public class UserAccessMapping_dto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 */
	@Digits(fraction = 0, integer =20)
	private Integer userAccessID;
	
	@Digits(fraction = 0, integer =20)
    private Integer userID;
	
	@Pattern(regexp = "^[A-Za-z0-9]*$")
    private String accessLevel;
	
	@Pattern(regexp = "^[A-Za-z0-9]*$")
    private String accessValue;
	@Pattern(regexp = "^[a-zA-Z]+$")
    private String accessName;
    
	public String getAccessName() {
		return accessName;
	}
	public void setAccessName(String accessName) {
		this.accessName = accessName;
	}
	/**
	 * @return the userAccessID
	 */
	public Integer getUserAccessID() {
		return userAccessID;
	}
	/**
	 * @return the userID
	 */
	public Integer getUserID() {
		return userID;
	}
	/**
	 * @return the accessLevel
	 */
	public String getAccessLevel() {
		return accessLevel;
	}
	/**
	 * @return the accessValue
	 */
	public String getAccessValue() {
		return accessValue;
	}
	/**
	 * @param userAccessID the userAccessID to set
	 */
	public void setUserAccessID(Integer userAccessID) {
		this.userAccessID = userAccessID;
	}
	/**
	 * @param userID the userID to set
	 */
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	/**
	 * @param accessLevel the accessLevel to set
	 */
	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}
	/**
	 * @param accessValue the accessValue to set
	 */
	public void setAccessValue(String accessValue) {
		this.accessValue = accessValue;
	}
	
}
