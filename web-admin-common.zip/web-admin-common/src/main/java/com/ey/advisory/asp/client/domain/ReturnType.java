package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

public class ReturnType implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Integer returnTypeID;
	
	String returnValue;
	
	String returnCode;
	
	String returnType;
	
	String dataTransType;
	
	Integer returnRelationShip;
	
	public Integer getReturnRelationShip() {
		return returnRelationShip;
	}
	public void setReturnRelationShip(Integer returnRelationShip) {
		this.returnRelationShip = returnRelationShip;
	}

	public Integer getReturnTypeID() {
		return returnTypeID;
	}
	public void setReturnTypeID(Integer returnTypeID) {
		this.returnTypeID = returnTypeID;
	}
	public String getReturnValue() {
		return returnValue;
	}
	public void setReturnValue(String returnValue) {
		this.returnValue = returnValue;
	}
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public String getDataTransType() {
		return dataTransType;
	}
	public void setDataTransType(String dataTransType) {
		this.dataTransType = dataTransType;
	}


}
