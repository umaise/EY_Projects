package com.ey.advisory.asp.dto;

import java.sql.Date;

public class GSTR2TXPD {

	
	private Long id;
	
	private String checksum;
	
	private String invNum;

	private Date invDate;
	
	private String docNum;

	private Date docDate;
	
	private Float igstRt;

	private Float igstAmt;

	private Float cgstRt;

	private Float cgstAmt;

	private Float sgstRt;

	private Float sgstAmt;
	
	private Long taxPayerID;
	
	private Float txbleValue;

	private int invoiceCnt;
	
	private Float igstTotal;
	
	private Float cgstTotal;

	private Float sgstTotal;

	/**
	 * @return the checksum
	 */
	public String getChecksum() {
		return checksum;
	}

	/**
	 * @param checksum the checksum to set
	 */
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	/**
	 * @return the invNum
	 */
	public String getInvNum() {
		return invNum;
	}

	/**
	 * @param invNum the invNum to set
	 */
	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	/**
	 * @return the invDate
	 */
	public Date getInvDate() {
		return invDate;
	}

	/**
	 * @param invDate the invDate to set
	 */
	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	/**
	 * @return the docNum
	 */
	public String getDocNum() {
		return docNum;
	}

	/**
	 * @param docNum the docNum to set
	 */
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	/**
	 * @return the docDate
	 */
	public Date getDocDate() {
		return docDate;
	}

	/**
	 * @param docDate the docDate to set
	 */
	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}

	/**
	 * @return the igstRt
	 */
	public Float getIgstRt() {
		return igstRt;
	}

	/**
	 * @param igstRt the igstRt to set
	 */
	public void setIgstRt(Float igstRt) {
		this.igstRt = igstRt;
	}

	/**
	 * @return the igstAmt
	 */
	public Float getIgstAmt() {
		return igstAmt;
	}

	/**
	 * @param igstAmt the igstAmt to set
	 */
	public void setIgstAmt(Float igstAmt) {
		this.igstAmt = igstAmt;
	}

	/**
	 * @return the cgstRt
	 */
	public Float getCgstRt() {
		return cgstRt;
	}

	/**
	 * @param cgstRt the cgstRt to set
	 */
	public void setCgstRt(Float cgstRt) {
		this.cgstRt = cgstRt;
	}

	/**
	 * @return the cgstAmt
	 */
	public Float getCgstAmt() {
		return cgstAmt;
	}

	/**
	 * @param cgstAmt the cgstAmt to set
	 */
	public void setCgstAmt(Float cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	/**
	 * @return the sgstRt
	 */
	public Float getSgstRt() {
		return sgstRt;
	}

	/**
	 * @param sgstRt the sgstRt to set
	 */
	public void setSgstRt(Float sgstRt) {
		this.sgstRt = sgstRt;
	}

	/**
	 * @return the sgstAmt
	 */
	public Float getSgstAmt() {
		return sgstAmt;
	}

	/**
	 * @param sgstAmt the sgstAmt to set
	 */
	public void setSgstAmt(Float sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTaxPayerID() {
		return taxPayerID;
	}

	public void setTaxPayerID(Long taxPayerID) {
		this.taxPayerID = taxPayerID;
	}

	public Float getTxbleValue() {
		return txbleValue;
	}

	public void setTxbleValue(Float txbleValue) {
		this.txbleValue = txbleValue;
	}

	public int getInvoiceCnt() {
		return invoiceCnt;
	}

	public void setInvoiceCnt(int invoiceCnt) {
		this.invoiceCnt = invoiceCnt;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}

	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}

	public Float getCgstTotal() {
		return cgstTotal;
	}

	public void setCgstTotal(Float cgstTotal) {
		this.cgstTotal = cgstTotal;
	}

	public Float getSgstTotal() {
		return sgstTotal;
	}

	public void setSgstTotal(Float sgstTotal) {
		this.sgstTotal = sgstTotal;
	}

	

	
	
	
}
