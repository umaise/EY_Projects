package com.ey.advisory.asp.dto;

public class InwardDashboardDto {
	
	String mtdInward;
	String ytdInward;
	public String getMtdInward() {
		return mtdInward;
	}
	public void setMtdInward(String mtdInward) {
		this.mtdInward = mtdInward;
	}
	public String getYtdInward() {
		return ytdInward;
	}
	public void setYtdInward(String ytdInward) {
		this.ytdInward = ytdInward;
	}

}
