package com.ey.advisory.asp.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Gstr3bSummary")
@XmlAccessorType(XmlAccessType.FIELD)
public class Gstr3BDto {

	private String Gstr3bSummary;
	@XmlElement
	private String month;
	@XmlElement
	private String year;
	private String LegalName;
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecRevChargeDto Sec31 =new Gstr3BSecRevChargeDto();
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecSupplies Sec32 =new Gstr3BSecSupplies();
	@XmlElement(defaultValue = "00.0")
	private Gstr3BSecEligibleItc Sec4 =new Gstr3BSecEligibleItc();
	@XmlElement
	private Gstr3BSecValues Sec5 =new Gstr3BSecValues();
	public String getGstr3bSummary() {
		return Gstr3bSummary;
	}
	public void setGstr3bSummary(String gstr3bSummary) {
		Gstr3bSummary = gstr3bSummary;
	}
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	@XmlElement
	public String getLegalName() {
		return LegalName;
	}
	public void setLegalName(String legalName) {
		LegalName = legalName;
	}
	@XmlElement
	public Gstr3BSecRevChargeDto getSec31() {
		return Sec31;
	}
	public void setSec31(Gstr3BSecRevChargeDto sec31) {
		Sec31 = sec31;
	}
	@XmlElement
	public Gstr3BSecSupplies getSec32() {
		return Sec32;
	}
	public void setSec32(Gstr3BSecSupplies sec32) {
		Sec32 = sec32;
	}
	@XmlElement
	public Gstr3BSecEligibleItc getSec4() {
		return Sec4;
	}
	public void setSec4(Gstr3BSecEligibleItc sec4) {
		Sec4 = sec4;
	}
	@XmlElement
	public Gstr3BSecValues getSec5() {
		return Sec5;
	}
	public void setSec5(Gstr3BSecValues sec5) {
		Sec5 = sec5;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	@Override
	public String toString() {
		return "Gstr3BDto [Gstr3bSummary=" + Gstr3bSummary + ", month=" + month + ", year=" + year + ", LegalName="
				+ LegalName + ", Sec31=" + Sec31 + ", Sec32=" + Sec32 + ", Sec4=" + Sec4 + ", Sec5=" + Sec5 + "]";
	}
	
	
	
	
	
}
