package com.ey.advisory.asp.dto;

import java.math.BigDecimal;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class Gstr3RefundDto {

	/*private String refTaxIgstAmt;
	private String refTaxCgstAmt;
	private String refTaxSgstAmt;
	private String refInterestIgstAmt;
	private String refInterestCgstAmt;
	private String refInterestSgstAmt;
	private String refPenaltyIgstAmt;
	private String refPenaltyCgstAmt;
	private String refPenaltySgstAmt;
	private String refFeeIgstAmt;
	private String refFeeCgstAmt;
	private String refFeeSgstAmt;
	private String refOthersIgstAmt;
	private String refOthersCgstAmt;
	private String refOthersSgstAmt;
	private String refDebitNo;

	
	
	
	public String getRefDebitNo() {
		return refDebitNo;
	}
	public void setRefDebitNo(String refDebitNo) {
		this.refDebitNo = refDebitNo;
	}
	public String getRefTaxIgstAmt() {
		return refTaxIgstAmt;
	}
	public void setRefTaxIgstAmt(String refTaxIgstAmt) {
		this.refTaxIgstAmt = refTaxIgstAmt;
	}
	public String getRefTaxCgstAmt() {
		return refTaxCgstAmt;
	}
	public void setRefTaxCgstAmt(String refTaxCgstAmt) {
		this.refTaxCgstAmt = refTaxCgstAmt;
	}
	public String getRefTaxSgstAmt() {
		return refTaxSgstAmt;
	}
	public void setRefTaxSgstAmt(String refTaxSgstAmt) {
		this.refTaxSgstAmt = refTaxSgstAmt;
	}
	public String getRefInterestIgstAmt() {
		return refInterestIgstAmt;
	}
	public void setRefInterestIgstAmt(String refInterestIgstAmt) {
		this.refInterestIgstAmt = refInterestIgstAmt;
	}
	public String getRefInterestCgstAmt() {
		return refInterestCgstAmt;
	}
	public void setRefInterestCgstAmt(String refInterestCgstAmt) {
		this.refInterestCgstAmt = refInterestCgstAmt;
	}
	public String getRefInterestSgstAmt() {
		return refInterestSgstAmt;
	}
	public void setRefInterestSgstAmt(String refInterestSgstAmt) {
		this.refInterestSgstAmt = refInterestSgstAmt;
	}
	public String getRefPenaltyIgstAmt() {
		return refPenaltyIgstAmt;
	}
	public void setRefPenaltyIgstAmt(String refPenaltyIgstAmt) {
		this.refPenaltyIgstAmt = refPenaltyIgstAmt;
	}
	public String getRefPenaltyCgstAmt() {
		return refPenaltyCgstAmt;
	}
	public void setRefPenaltyCgstAmt(String refPenaltyCgstAmt) {
		this.refPenaltyCgstAmt = refPenaltyCgstAmt;
	}
	public String getRefPenaltySgstAmt() {
		return refPenaltySgstAmt;
	}
	public void setRefPenaltySgstAmt(String refPenaltySgstAmt) {
		this.refPenaltySgstAmt = refPenaltySgstAmt;
	}
	public String getRefFeeIgstAmt() {
		return refFeeIgstAmt;
	}
	public void setRefFeeIgstAmt(String refFeeIgstAmt) {
		this.refFeeIgstAmt = refFeeIgstAmt;
	}
	public String getRefFeeCgstAmt() {
		return refFeeCgstAmt;
	}
	public void setRefFeeCgstAmt(String refFeeCgstAmt) {
		this.refFeeCgstAmt = refFeeCgstAmt;
	}
	public String getRefFeeSgstAmt() {
		return refFeeSgstAmt;
	}
	public void setRefFeeSgstAmt(String refFeeSgstAmt) {
		this.refFeeSgstAmt = refFeeSgstAmt;
	}
	public String getRefOthersIgstAmt() {
		return refOthersIgstAmt;
	}
	public void setRefOthersIgstAmt(String refOthersIgstAmt) {
		this.refOthersIgstAmt = refOthersIgstAmt;
	}
	public String getRefOthersCgstAmt() {
		return refOthersCgstAmt;
	}
	public void setRefOthersCgstAmt(String refOthersCgstAmt) {
		this.refOthersCgstAmt = refOthersCgstAmt;
	}
	public String getRefOthersSgstAmt() {
		return refOthersSgstAmt;
	}
	public void setRefOthersSgstAmt(String refOthersSgstAmt) {
		this.refOthersSgstAmt = refOthersSgstAmt;
	}
*/	
	
	/*private long refTaxIgstAmt;
	private long refTaxCgstAmt;
	private long refTaxSgstAmt;
	private long refInterestIgstAmt;
	private long refInterestCgstAmt;
	private long refInterestSgstAmt;
	private long refPenaltyIgstAmt;
	private long refPenaltyCgstAmt;
	private long refPenaltySgstAmt;
	private long refFeeIgstAmt;
	private long refFeeCgstAmt;
	private long refFeeSgstAmt;
	private long refOthersIgstAmt;
	private long refOthersCgstAmt;
	private long refOthersSgstAmt;
	private String refDebitNo;
	
	
	public long getRefInterestIgstAmt() {
		return refInterestIgstAmt;
	}
	public void setRefInterestIgstAmt(long refInterestIgstAmt) {
		this.refInterestIgstAmt = refInterestIgstAmt;
	}
	public long getRefInterestCgstAmt() {
		return refInterestCgstAmt;
	}
	public void setRefInterestCgstAmt(long refInterestCgstAmt) {
		this.refInterestCgstAmt = refInterestCgstAmt;
	}
	public long getRefInterestSgstAmt() {
		return refInterestSgstAmt;
	}
	public void setRefInterestSgstAmt(long refInterestSgstAmt) {
		this.refInterestSgstAmt = refInterestSgstAmt;
	}
	public long getRefPenaltyIgstAmt() {
		return refPenaltyIgstAmt;
	}
	public void setRefPenaltyIgstAmt(long refPenaltyIgstAmt) {
		this.refPenaltyIgstAmt = refPenaltyIgstAmt;
	}
	public long getRefPenaltyCgstAmt() {
		return refPenaltyCgstAmt;
	}
	public void setRefPenaltyCgstAmt(long refPenaltyCgstAmt) {
		this.refPenaltyCgstAmt = refPenaltyCgstAmt;
	}
	public long getRefPenaltySgstAmt() {
		return refPenaltySgstAmt;
	}
	public void setRefPenaltySgstAmt(long refPenaltySgstAmt) {
		this.refPenaltySgstAmt = refPenaltySgstAmt;
	}
	public long getRefFeeIgstAmt() {
		return refFeeIgstAmt;
	}
	public void setRefFeeIgstAmt(long refFeeIgstAmt) {
		this.refFeeIgstAmt = refFeeIgstAmt;
	}
	public long getRefFeeCgstAmt() {
		return refFeeCgstAmt;
	}
	public void setRefFeeCgstAmt(long refFeeCgstAmt) {
		this.refFeeCgstAmt = refFeeCgstAmt;
	}
	public long getRefFeeSgstAmt() {
		return refFeeSgstAmt;
	}
	public void setRefFeeSgstAmt(long refFeeSgstAmt) {
		this.refFeeSgstAmt = refFeeSgstAmt;
	}
	public long getRefOthersIgstAmt() {
		return refOthersIgstAmt;
	}
	public void setRefOthersIgstAmt(long refOthersIgstAmt) {
		this.refOthersIgstAmt = refOthersIgstAmt;
	}
	public long getRefOthersCgstAmt() {
		return refOthersCgstAmt;
	}
	public void setRefOthersCgstAmt(long refOthersCgstAmt) {
		this.refOthersCgstAmt = refOthersCgstAmt;
	}
	public long getRefOthersSgstAmt() {
		return refOthersSgstAmt;
	}
	public void setRefOthersSgstAmt(long refOthersSgstAmt) {
		this.refOthersSgstAmt = refOthersSgstAmt;
	}
	public long getRefTaxIgstAmt() {
		return refTaxIgstAmt;
	}
	public void setRefTaxIgstAmt(long refTaxIgstAmt) {
		this.refTaxIgstAmt = refTaxIgstAmt;
	}
	public long getRefTaxCgstAmt() {
		return refTaxCgstAmt;
	}
	public void setRefTaxCgstAmt(long refTaxCgstAmt) {
		this.refTaxCgstAmt = refTaxCgstAmt;
	}
	public long getRefTaxSgstAmt() {
		return refTaxSgstAmt;
	}
	public void setRefTaxSgstAmt(long refTaxSgstAmt) {
		this.refTaxSgstAmt = refTaxSgstAmt;
	}
	public String getRefDebitNo() {
		return refDebitNo;
	}
	public void setRefDebitNo(String refDebitNo) {
		this.refDebitNo = refDebitNo;
	}*/
	@NotNull
	@Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	private String gstin;
	@NotNull
	@Pattern(regexp = "^[a-zA-Z 0-9]+$")
	private String returnPeriod;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTaxIgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTaxCgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTaxSgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTaxCessAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTaxUtgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refInterestIgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refInterestCgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refInterestSgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refInterestCessAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refInterestUtgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refPenaltyIgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refPenaltyCgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refPenaltySgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refPenaltyCessAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refPenaltyUtgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refFeeIgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refFeeCgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refFeeSgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refFeeCessAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refFeeUtgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refOthersIgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refOthersCgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refOthersSgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refOthersCessAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refOthersUtgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTotalIgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTotalCgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTotalSgstAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTotalCessAmt;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private BigDecimal refTotalUtgstAmt;
	@Pattern(regexp = "^\\d{9,18}$")
	private String bankAccNo;	
	@Pattern(regexp = "^[0-9]+$")
	private String refDebitNo;
	
	
	public BigDecimal getRefTotalIgstAmt() {
		return refTotalIgstAmt;
	}
	public void setRefTotalIgstAmt(BigDecimal refTotalIgstAmt) {
		this.refTotalIgstAmt = refTotalIgstAmt;
	}
	public BigDecimal getRefTotalCgstAmt() {
		return refTotalCgstAmt;
	}
	public void setRefTotalCgstAmt(BigDecimal refTotalCgstAmt) {
		this.refTotalCgstAmt = refTotalCgstAmt;
	}
	public BigDecimal getRefTotalSgstAmt() {
		return refTotalSgstAmt;
	}
	public void setRefTotalSgstAmt(BigDecimal refTotalSgstAmt) {
		this.refTotalSgstAmt = refTotalSgstAmt;
	}
	public BigDecimal getRefTotalCessAmt() {
		return refTotalCessAmt;
	}
	public void setRefTotalCessAmt(BigDecimal refTotalCessAmt) {
		this.refTotalCessAmt = refTotalCessAmt;
	}
	public BigDecimal getRefTotalUtgstAmt() {
		return refTotalUtgstAmt;
	}
	public void setRefTotalUtgstAmt(BigDecimal refTotalUtgstAmt) {
		this.refTotalUtgstAmt = refTotalUtgstAmt;
	}
	public String getBankAccNo() {
		return bankAccNo;
	}
	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}
	public BigDecimal getRefTaxCessAmt() {
		return refTaxCessAmt;
	}
	public void setRefTaxCessAmt(BigDecimal refTaxCessAmt) {
		this.refTaxCessAmt = refTaxCessAmt;
	}
	public BigDecimal getRefTaxUtgstAmt() {
		return refTaxUtgstAmt;
	}
	public void setRefTaxUtgstAmt(BigDecimal refTaxUtgstAmt) {
		this.refTaxUtgstAmt = refTaxUtgstAmt;
	}
	public BigDecimal getRefInterestCessAmt() {
		return refInterestCessAmt;
	}
	public void setRefInterestCessAmt(BigDecimal refInterestCessAmt) {
		this.refInterestCessAmt = refInterestCessAmt;
	}
	public BigDecimal getRefInterestUtgstAmt() {
		return refInterestUtgstAmt;
	}
	public void setRefInterestUtgstAmt(BigDecimal refInterestUtgstAmt) {
		this.refInterestUtgstAmt = refInterestUtgstAmt;
	}
	public BigDecimal getRefPenaltyCessAmt() {
		return refPenaltyCessAmt;
	}
	public void setRefPenaltyCessAmt(BigDecimal refPenaltyCessAmt) {
		this.refPenaltyCessAmt = refPenaltyCessAmt;
	}
	public BigDecimal getRefPenaltyUtgstAmt() {
		return refPenaltyUtgstAmt;
	}
	public void setRefPenaltyUtgstAmt(BigDecimal refPenaltyUtgstAmt) {
		this.refPenaltyUtgstAmt = refPenaltyUtgstAmt;
	}
	public BigDecimal getRefFeeCessAmt() {
		return refFeeCessAmt;
	}
	public void setRefFeeCessAmt(BigDecimal refFeeCessAmt) {
		this.refFeeCessAmt = refFeeCessAmt;
	}
	public BigDecimal getRefFeeUtgstAmt() {
		return refFeeUtgstAmt;
	}
	public void setRefFeeUtgstAmt(BigDecimal refFeeUtgstAmt) {
		this.refFeeUtgstAmt = refFeeUtgstAmt;
	}
	public BigDecimal getRefOthersCessAmt() {
		return refOthersCessAmt;
	}
	public void setRefOthersCessAmt(BigDecimal refOthersCessAmt) {
		this.refOthersCessAmt = refOthersCessAmt;
	}
	public BigDecimal getRefOthersUtgstAmt() {
		return refOthersUtgstAmt;
	}
	public void setRefOthersUtgstAmt(BigDecimal refOthersUtgstAmt) {
		this.refOthersUtgstAmt = refOthersUtgstAmt;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public BigDecimal getRefTaxIgstAmt() {
		return refTaxIgstAmt;
	}
	public void setRefTaxIgstAmt(BigDecimal refTaxIgstAmt) {
		this.refTaxIgstAmt = refTaxIgstAmt;
	}
	public BigDecimal getRefTaxCgstAmt() {
		return refTaxCgstAmt;
	}
	public void setRefTaxCgstAmt(BigDecimal refTaxCgstAmt) {
		this.refTaxCgstAmt = refTaxCgstAmt;
	}
	public BigDecimal getRefTaxSgstAmt() {
		return refTaxSgstAmt;
	}
	public void setRefTaxSgstAmt(BigDecimal refTaxSgstAmt) {
		this.refTaxSgstAmt = refTaxSgstAmt;
	}
	public BigDecimal getRefInterestIgstAmt() {
		return refInterestIgstAmt;
	}
	public void setRefInterestIgstAmt(BigDecimal refInterestIgstAmt) {
		this.refInterestIgstAmt = refInterestIgstAmt;
	}
	public BigDecimal getRefInterestCgstAmt() {
		return refInterestCgstAmt;
	}
	public void setRefInterestCgstAmt(BigDecimal refInterestCgstAmt) {
		this.refInterestCgstAmt = refInterestCgstAmt;
	}
	public BigDecimal getRefInterestSgstAmt() {
		return refInterestSgstAmt;
	}
	public void setRefInterestSgstAmt(BigDecimal refInterestSgstAmt) {
		this.refInterestSgstAmt = refInterestSgstAmt;
	}
	public BigDecimal getRefPenaltyIgstAmt() {
		return refPenaltyIgstAmt;
	}
	public void setRefPenaltyIgstAmt(BigDecimal refPenaltyIgstAmt) {
		this.refPenaltyIgstAmt = refPenaltyIgstAmt;
	}
	public BigDecimal getRefPenaltyCgstAmt() {
		return refPenaltyCgstAmt;
	}
	public void setRefPenaltyCgstAmt(BigDecimal refPenaltyCgstAmt) {
		this.refPenaltyCgstAmt = refPenaltyCgstAmt;
	}
	public BigDecimal getRefPenaltySgstAmt() {
		return refPenaltySgstAmt;
	}
	public void setRefPenaltySgstAmt(BigDecimal refPenaltySgstAmt) {
		this.refPenaltySgstAmt = refPenaltySgstAmt;
	}
	public BigDecimal getRefFeeIgstAmt() {
		return refFeeIgstAmt;
	}
	public void setRefFeeIgstAmt(BigDecimal refFeeIgstAmt) {
		this.refFeeIgstAmt = refFeeIgstAmt;
	}
	public BigDecimal getRefFeeCgstAmt() {
		return refFeeCgstAmt;
	}
	public void setRefFeeCgstAmt(BigDecimal refFeeCgstAmt) {
		this.refFeeCgstAmt = refFeeCgstAmt;
	}
	public BigDecimal getRefFeeSgstAmt() {
		return refFeeSgstAmt;
	}
	public void setRefFeeSgstAmt(BigDecimal refFeeSgstAmt) {
		this.refFeeSgstAmt = refFeeSgstAmt;
	}
	public BigDecimal getRefOthersIgstAmt() {
		return refOthersIgstAmt;
	}
	public void setRefOthersIgstAmt(BigDecimal refOthersIgstAmt) {
		this.refOthersIgstAmt = refOthersIgstAmt;
	}
	public BigDecimal getRefOthersCgstAmt() {
		return refOthersCgstAmt;
	}
	public void setRefOthersCgstAmt(BigDecimal refOthersCgstAmt) {
		this.refOthersCgstAmt = refOthersCgstAmt;
	}
	public BigDecimal getRefOthersSgstAmt() {
		return refOthersSgstAmt;
	}
	public void setRefOthersSgstAmt(BigDecimal refOthersSgstAmt) {
		this.refOthersSgstAmt = refOthersSgstAmt;
	}
	public String getRefDebitNo() {
		return refDebitNo;
	}
	public void setRefDebitNo(String refDebitNo) {
		this.refDebitNo = refDebitNo;
	}
	
	
	
	
	
}
