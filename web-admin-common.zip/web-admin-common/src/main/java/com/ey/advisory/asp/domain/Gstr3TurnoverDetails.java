package com.ey.advisory.asp.domain;

import java.util.Date;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class Gstr3TurnoverDetails{

	/**
	 * 
	 */
	@Digits(fraction = 0, integer =20)
	private int grossturnoverId;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private double grossTurnover;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private double exportTurnover;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private double nillRatedAndExemptedTurnover;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private double nonGstTurnover;
	@DecimalMax(value = "9999999999999999.9999")
	@DecimalMin(value = "0.00")
	private double taxableTurnover;
	@NotNull
	@Pattern(regexp = "^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z0-9]{2}+[A-Za-z]{1}+[A-Za-z0-9]{1}$")
	private String gstin;
	@NotNull
	@Pattern(regexp = "^[a-zA-Z 0-9]*$")
	private String financialYear;
	
	private boolean isActive;
	
	private boolean isFiled;
	private Date createdOn;	
	@Pattern(regexp = "^[a-zA-Z 0-9]*$")
	private String createdBy;	
	private Date updatedOn;	
	@Pattern(regexp = "^[a-zA-Z 0-9]*$")
	private String updatedBy;
	public double getGrossTurnover() {
		return grossTurnover;
	}
	public void setGrossTurnover(double grossTurnover) {
		this.grossTurnover = grossTurnover;
	}
	public double getExportTurnover() {
		return exportTurnover;
	}
	public void setExportTurnover(double exportTurnover) {
		this.exportTurnover = exportTurnover;
	}
	public double getNillRatedAndExemptedTurnover() {
		return nillRatedAndExemptedTurnover;
	}
	public void setNillRatedAndExemptedTurnover(double nillRatedAndExemptedTurnover) {
		this.nillRatedAndExemptedTurnover = nillRatedAndExemptedTurnover;
	}
	public double getNonGstTurnover() {
		return nonGstTurnover;
	}
	public void setNonGstTurnover(double nonGstTurnover) {
		this.nonGstTurnover = nonGstTurnover;
	}
	public double getTaxableTurnover() {
		return taxableTurnover;
	}
	public void setTaxableTurnover(double taxableTurnover) {
		this.taxableTurnover = taxableTurnover;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getFinancialYear() {
		return financialYear;
	}
	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public boolean isFiled() {
		return isFiled;
	}
	public void setFiled(boolean isFiled) {
		this.isFiled = isFiled;
	}
	public int getGrossturnoverId() {
		return grossturnoverId;
	}
	public void setGrossturnoverId(int grossturnoverId) {
		this.grossturnoverId = grossturnoverId;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
