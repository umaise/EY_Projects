package com.ey.advisory.asp.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.captcha.botdetect.web.servlet.Captcha;
import com.ey.advisory.asp.common.Constant;

public class CaptchaFilter extends UsernamePasswordAuthenticationFilter {

	
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		final HttpServletRequest request = (HttpServletRequest) req;
		final HttpServletResponse response = (HttpServletResponse) res;
		
	    HttpSession httpSession = request.getSession(false);
	    
		Captcha captcha = Captcha.load(request, "ActualCaptchaValue");

		String captchaCodeText = request.getParameter("captchaCode");
		httpSession.setAttribute("adminPageRequest", "0");
		if (captchaCodeText != null) {
			boolean isHuman = captcha.validate(captchaCodeText);
			if (isHuman) {
				httpSession.setAttribute("INVALID_CAPTCHA_ERROR","");
				
				 String isAdminLoginPage = request.getParameter("isAdminLoginPage");
				 if(isAdminLoginPage != null && isAdminLoginPage.equalsIgnoreCase(Constant.ONE)){
			      	httpSession.setAttribute("adminPageRequest", "1");
				 }
				 else{
					 httpSession.setAttribute("adminPageRequest", "0");
				 }
				 
				 
				super.doFilter(request, response, chain);
			} else {
				httpSession.setAttribute("INVALID_CAPTCHA_ERROR", Constant.INVALID_CAPTCHA);
				response.sendRedirect( request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath());
			}
		} else {
			super.doFilter(request, response, chain);
		}
	}
}
