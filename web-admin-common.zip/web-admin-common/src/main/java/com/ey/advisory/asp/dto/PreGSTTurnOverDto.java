package com.ey.advisory.asp.dto;



public class PreGSTTurnOverDto {

	private String id;
	private String financialYear;
	private String turnOverAmount;
	private String masterId;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFinancialYear() {
		return financialYear;
	}
	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}
	public String getTurnOverAmount() {
		return turnOverAmount;
	}
	public void setTurnOverAmount(String turnOverAmount) {
		this.turnOverAmount = turnOverAmount;
	}
	public String getMasterId() {
		return masterId;
	}
	public void setMasterId(String masterId) {
		this.masterId = masterId;
	}
}
