package com.ey.advisory.asp.dto;

public class MapGstinDto {

	private String gstin;
	private String stateCode;
	private String fileDate;
	private String returnType;
	private String outwardSupply;
	private String inwardSupply;
	private String netLiability;
	private String taxPeriod;
	private String t_outward;
	private String t_inward;
	private String t_liability;
	
	private String taxableAmt;
	private String itcValue;
	private String t_taxableAmt;
	private String t_itcValue;
	private String typeOfReg;
	
	public MapGstinDto(String gstin, String stateCode, String fileDate,
			String returnType) {
		super();
		this.gstin = gstin;
		this.stateCode = stateCode;
		this.fileDate = fileDate;
		this.returnType = returnType;
	}
	
	public MapGstinDto(String gstin, String stateCode,String taxPeriod) {
		super();
		this.gstin = gstin;
		this.stateCode = stateCode;
		this.taxPeriod=taxPeriod;
	}
	
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getFileDate() {
		return fileDate;
	}
	public String getTaxableAmt() {
		return taxableAmt;
	}

	public void setTaxableAmt(String taxableAmt) {
		this.taxableAmt = taxableAmt;
	}

	public String getItcValue() {
		return itcValue;
	}

	public void setItcValue(String itcValue) {
		this.itcValue = itcValue;
	}

	public String getT_taxableAmt() {
		return t_taxableAmt;
	}

	public void setT_taxableAmt(String t_taxableAmt) {
		this.t_taxableAmt = t_taxableAmt;
	}

	public String getT_itcValue() {
		return t_itcValue;
	}

	public void setT_itcValue(String t_itcValue) {
		this.t_itcValue = t_itcValue;
	}

	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	

	public String getOutwardSupply() {
		return outwardSupply;
	}

	public void setOutwardSupply(String outwardSupply) {
		this.outwardSupply = outwardSupply;
	}

	public String getInwardSupply() {
		return inwardSupply;
	}

	public void setInwardSupply(String inwardSupply) {
		this.inwardSupply = inwardSupply;
	}

	public String getNetLiability() {
		return netLiability;
	}

	public void setNetLiability(String netLiability) {
		this.netLiability = netLiability;
	}

	
	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	
	public String getT_outward() {
		return t_outward;
	}

	public void setT_outward(String t_outward) {
		this.t_outward = t_outward;
	}

	public String getT_inward() {
		return t_inward;
	}

	public void setT_inward(String t_inward) {
		this.t_inward = t_inward;
	}

	public String getT_liability() {
		return t_liability;
	}

	public void setT_liability(String t_liability) {
		this.t_liability = t_liability;
	}

	public String gstinReturnString()
	{
		return this.gstin+this.returnType;
	}
	
	public String getTypeOfReg() {
		return typeOfReg;
	}

	public void setTypeOfReg(String typeOfReg) {
		this.typeOfReg = typeOfReg;
	}

	@Override
	public String toString() {
		return "MapGstinDto [gstin=" + gstin + ", stateCode=" + stateCode
				+ ", fileDate=" + fileDate + ", returnType=" + returnType
				+ ", outwardSupply=" + outwardSupply + ", inwardSupply="
				+ inwardSupply + ", netLiability=" + netLiability
				+ ", taxPeriod=" + taxPeriod + ", t_outward=" + t_outward
				+ ", t_inward=" + t_inward + ", t_liability=" + t_liability
				+ ", taxableAmt=" + taxableAmt + ", itcValue=" + itcValue
				+ ", t_taxableAmt=" + t_taxableAmt + ", t_itcValue="
				+ t_itcValue + ", typeOfReg=" + typeOfReg + "]";
	}
	
	
}
