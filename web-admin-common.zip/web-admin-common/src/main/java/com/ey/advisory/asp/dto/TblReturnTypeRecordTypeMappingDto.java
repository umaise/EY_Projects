package com.ey.advisory.asp.dto;

import java.io.Serializable;

/**
 * @author Sailendar.Bongani
 *
 */
public class TblReturnTypeRecordTypeMappingDto implements Serializable {
	
	/**
	 * 
	 */

	
	private static final long serialVersionUID = 1L;
	
	private Long returnTypeRecordTypeId;
	
	private String returnType;

	private String recordType;
	
	private Boolean isActive;

	/**
	 * @return the IsActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}

	/**
	 * @param IsActive
	 *            the IsActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the returnTypeRecordTypeId
	 */

	public Long getReturnTypeRecordTypeId() {
		return returnTypeRecordTypeId;
	}

	/**
	 * @param returnTypeRecordTypeId
	 *            the returnTypeRecordTypeId to set
	 */
	public void setReturnTypeRecordTypeId(Long returnTypeRecordTypeId) {
		this.returnTypeRecordTypeId = returnTypeRecordTypeId;
	}

	
	/**
	 * @return the returnType
	 */
	public String getReturnType() {
		return returnType;
	}

	/**
	 * @param returnType
	 *            the returnType to set
	 */
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	/**
	 * @return the recordType
	 */
	public String getRecordType() {
		return recordType;
	}

	/**
	 * @param recordType
	 *            the recordType to set
	 */
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	
}
