/**
 * 
 */
package com.ey.advisory.asp.dto;

import java.sql.Date;

/**
 * @author Uma.Chandranaik
 *
 */
public class Table4Form {
	

	private Long id;
	
	private String custGSTIN;
	
	private Character flag;
	
	private String checksum;
	
	private String invNum;
	
	private Date invDate;
		
	private Float invValue;
	
	private String pos;
	
	private String revCharge;
	
	private Long taxPayerId;
	
	private int lineNo;
	
	
	private Character itemStatus;
	
	private Character itemType;
	
	private String hsnSC;

	
	private Float itemTxval;

	
	private Float igstRt;

	
	private Float igstAmt;

	
	private Float cgstRt;

	
	private Float cgstAmt;

	
	private Float sgstRt;


	private Float sgstAmt;
	
	
	private Long invDetailsId;
	
	
	private String itcEligiblity;
	
	
	private Float itcIGSTAmt;

	private Float itcCGSTAmt;

	
	private Float itcSGSTAmt;

	
	private Float tcIGSTAmt;

	
	private Float tcCGSTAmt;

	
	private Float tcSGSTAmt;
	
	private String taxUnrProvAss;
	
	private String ecomGSTIN;
	
	private int row;
	
	private Float igstTotal;
	
	private Float cgstTotal;
	
	private Float sgstTotal;
	
	private String orgInvNum;
	
	private Date orgInvDate;
	
	private Float taxableValue;


	public int getRow() {
		return row;
	}


	public void setRow(int row) {
		this.row = row;
	}

	public Float getIgstTotal() {
		return igstTotal;
	}


	public void setIgstTotal(Float igstTotal) {
		this.igstTotal = igstTotal;
	}


	public Float getCgstTotal() {
		return cgstTotal;
	}


	public void setCgstTotal(Float cgstTotal) {
		this.cgstTotal = cgstTotal;
	}


	public Float getSgstTotal() {
		return sgstTotal;
	}


	public void setSgstTotal(Float sgstTotal) {
		this.sgstTotal = sgstTotal;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getCustGSTIN() {
		return custGSTIN;
	}


	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}


	public Character getFlag() {
		return flag;
	}


	public void setFlag(Character flag) {
		this.flag = flag;
	}


	public String getChecksum() {
		return checksum;
	}


	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}


	public String getInvNum() {
		return invNum;
	}


	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}


	public Date getInvDate() {
		return invDate;
	}


	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}


	public Float getInvValue() {
		return invValue;
	}


	public void setInvValue(Float invValue) {
		this.invValue = invValue;
	}


	public String getPos() {
		return pos;
	}


	public void setPos(String pos) {
		this.pos = pos;
	}


	public String getRevCharge() {
		return revCharge;
	}


	public void setRevCharge(String revCharge) {
		this.revCharge = revCharge;
	}


	public Long getTaxPayerId() {
		return taxPayerId;
	}


	public void setTaxPayerId(Long taxPayerId) {
		this.taxPayerId = taxPayerId;
	}


	public int getLineNo() {
		return lineNo;
	}


	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}


	public Character getItemStatus() {
		return itemStatus;
	}


	public void setItemStatus(Character itemStatus) {
		this.itemStatus = itemStatus;
	}


	public Character getItemType() {
		return itemType;
	}


	public void setItemType(Character itemType) {
		this.itemType = itemType;
	}


	public String getHsnSC() {
		return hsnSC;
	}


	public void setHsnSC(String hsnSC) {
		this.hsnSC = hsnSC;
	}


	public Float getItemTxval() {
		return itemTxval;
	}


	public void setItemTxval(Float itemTxval) {
		this.itemTxval = itemTxval;
	}


	public Float getIgstRt() {
		return igstRt;
	}


	public void setIgstRt(Float igstRt) {
		this.igstRt = igstRt;
	}


	public Float getIgstAmt() {
		return igstAmt;
	}


	public void setIgstAmt(Float igstAmt) {
		this.igstAmt = igstAmt;
	}


	public Float getCgstRt() {
		return cgstRt;
	}


	public void setCgstRt(Float cgstRt) {
		this.cgstRt = cgstRt;
	}


	public Float getCgstAmt() {
		return cgstAmt;
	}


	public void setCgstAmt(Float cgstAmt) {
		this.cgstAmt = cgstAmt;
	}


	public Float getSgstRt() {
		return sgstRt;
	}


	public void setSgstRt(Float sgstRt) {
		this.sgstRt = sgstRt;
	}


	public Float getSgstAmt() {
		return sgstAmt;
	}


	public void setSgstAmt(Float sgstAmt) {
		this.sgstAmt = sgstAmt;
	}


	public Long getInvDetailsId() {
		return invDetailsId;
	}


	public void setInvDetailsId(Long invDetailsId) {
		this.invDetailsId = invDetailsId;
	}


	public String getItcEligiblity() {
		return itcEligiblity;
	}


	public void setItcEligiblity(String itcEligiblity) {
		this.itcEligiblity = itcEligiblity;
	}


	public Float getItcIGSTAmt() {
		return itcIGSTAmt;
	}


	public void setItcIGSTAmt(Float itcIGSTAmt) {
		this.itcIGSTAmt = itcIGSTAmt;
	}


	public Float getItcCGSTAmt() {
		return itcCGSTAmt;
	}


	public void setItcCGSTAmt(Float itcCGSTAmt) {
		this.itcCGSTAmt = itcCGSTAmt;
	}


	public Float getItcSGSTAmt() {
		return itcSGSTAmt;
	}


	public void setItcSGSTAmt(Float itcSGSTAmt) {
		this.itcSGSTAmt = itcSGSTAmt;
	}


	public Float getTcIGSTAmt() {
		return tcIGSTAmt;
	}


	public void setTcIGSTAmt(Float tcIGSTAmt) {
		this.tcIGSTAmt = tcIGSTAmt;
	}


	public Float getTcCGSTAmt() {
		return tcCGSTAmt;
	}


	public void setTcCGSTAmt(Float tcCGSTAmt) {
		this.tcCGSTAmt = tcCGSTAmt;
	}


	public Float getTcSGSTAmt() {
		return tcSGSTAmt;
	}


	public void setTcSGSTAmt(Float tcSGSTAmt) {
		this.tcSGSTAmt = tcSGSTAmt;
	}


	public String getTaxUnrProvAss() {
		return taxUnrProvAss;
	}


	public void setTaxUnrProvAss(String taxUnrProvAss) {
		this.taxUnrProvAss = taxUnrProvAss;
	}


	public String getEcomGSTIN() {
		return ecomGSTIN;
	}


	public void setEcomGSTIN(String ecomGSTIN) {
		this.ecomGSTIN = ecomGSTIN;
	}


	public String getOrgInvNum() {
		return orgInvNum;
	}


	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}


	public Date getOrgInvDate() {
		return orgInvDate;
	}


	public void setOrgInvDate(Date orgInvDate) {
		this.orgInvDate = orgInvDate;
	}


	public Float getTaxableValue() {
		return taxableValue;
	}


	public void setTaxableValue(Float taxableValue) {
		this.taxableValue = taxableValue;
	}


	
	
	
}
