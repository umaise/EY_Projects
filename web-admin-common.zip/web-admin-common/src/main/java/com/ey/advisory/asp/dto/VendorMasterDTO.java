package com.ey.advisory.asp.dto;

public class VendorMasterDTO {
	
	private Long  vendorID;
	private String receiverGSTIN;
	private String vendorGSTIN;
	private String vendorCode;
	private String vendorName;
	private StringBuffer vendorAddress;
	private String vendorLocationCode;
	private String vendorCategory;
	private String co_LLP_P_Individual ;
	private String category;
	private String aHSNOrSAC;
	private String aPOS;
	private StringBuffer illustrativeExample;
	private String vendorPrimaryContactPerson;
	private String primaryEmailId;
	private long primaryMobileNumber;
	private String vendorSecondaryContactPerson;
	private String secondaryEmailId;
	private long secondaryMobileNumber;
	private String isExemptOrconcessionalYorN;
	private String circularOrNotificationNumber;
	private String circularOrNotificationDate;
	private String serialNumberOfCircular;
	private double aIGSTRate;
	private double aCGSTRate;
	private double aSGSTRate;
	private double aUTGSTRate;
	private double aCessRate;
	private String isTDS;
	
	public Long getVendorID() {
		return vendorID;
	}
	public void setVendorID(Long vendorID) {
		this.vendorID = vendorID;
	}

	public String getReceiverGSTIN() {
		return receiverGSTIN;
	}
	public void setReceiverGSTIN(String receiverGSTIN) {
		this.receiverGSTIN = receiverGSTIN;
	}
	public String getVendorGSTIN() {
		return vendorGSTIN;
	}
	public void setVendorGSTIN(String vendorGSTIN) {
		this.vendorGSTIN = vendorGSTIN;
	}
	public String getVendorCode() {
		return vendorCode;
	}
	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public StringBuffer getVendorAddress() {
		return vendorAddress;
	}
	public void setVendorAddress(StringBuffer vendorAddress) {
		this.vendorAddress = vendorAddress;
	}
	public String getVendorLocationCode() {
		return vendorLocationCode;
	}
	public void setVendorLocationCode(String vendorLocationCode) {
		this.vendorLocationCode = vendorLocationCode;
	}
	public String getVendorCategory() {
		return vendorCategory;
	}
	public void setVendorCategory(String vendorCategory) {
		this.vendorCategory = vendorCategory;
	}
	public String getCo_LLP_P_Individual() {
		return co_LLP_P_Individual;
	}
	public void setCo_LLP_P_Individual(String co_LLP_P_Individual) {
		this.co_LLP_P_Individual = co_LLP_P_Individual;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getaHSNOrSAC() {
		return aHSNOrSAC;
	}
	public void setaHSNOrSAC(String aHSNOrSAC) {
		this.aHSNOrSAC = aHSNOrSAC;
	}
	public String getaPOS() {
		return aPOS;
	}
	public void setaPOS(String aPOS) {
		this.aPOS = aPOS;
	}
	public StringBuffer getIllustrativeExample() {
		return illustrativeExample;
	}
	public void setIllustrativeExample(StringBuffer illustrativeExample) {
		this.illustrativeExample = illustrativeExample;
	}
	public String getVendorPrimaryContactPerson() {
		return vendorPrimaryContactPerson;
	}
	public void setVendorPrimaryContactPerson(String vendorPrimaryContactPerson) {
		this.vendorPrimaryContactPerson = vendorPrimaryContactPerson;
	}
	public String getPrimaryEmailId() {
		return primaryEmailId;
	}
	public void setPrimaryEmailId(String primaryEmailId) {
		this.primaryEmailId = primaryEmailId;
	}
	public long getPrimaryMobileNumber() {
		return primaryMobileNumber;
	}
	public void setPrimaryMobileNumber(long primaryMobileNumber) {
		this.primaryMobileNumber = primaryMobileNumber;
	}
	public String getVendorSecondaryContactPerson() {
		return vendorSecondaryContactPerson;
	}
	public void setVendorSecondaryContactPerson(String vendorSecondaryContactPerson) {
		this.vendorSecondaryContactPerson = vendorSecondaryContactPerson;
	}
	public String getSecondaryEmailId() {
		return secondaryEmailId;
	}
	public void setSecondaryEmailId(String secondaryEmailId) {
		this.secondaryEmailId = secondaryEmailId;
	}
	public long getSecondaryMobileNumber() {
		return secondaryMobileNumber;
	}
	public void setSecondaryMobileNumber(long secondaryMobileNumber) {
		this.secondaryMobileNumber = secondaryMobileNumber;
	}
	public String getIsExemptOrconcessionalYorN() {
		return isExemptOrconcessionalYorN;
	}
	public void setIsExemptOrconcessionalYorN(String isExemptOrconcessionalYorN) {
		this.isExemptOrconcessionalYorN = isExemptOrconcessionalYorN;
	}
	public String getCircularOrNotificationNumber() {
		return circularOrNotificationNumber;
	}
	public void setCircularOrNotificationNumber(String circularOrNotificationNumber) {
		this.circularOrNotificationNumber = circularOrNotificationNumber;
	}
	public String getCircularOrNotificationDate() {
		return circularOrNotificationDate;
	}
	public void setCircularOrNotificationDate(String circularOrNotificationDate) {
		this.circularOrNotificationDate = circularOrNotificationDate;
	}
	public String getSerialNumberOfCircular() {
		return serialNumberOfCircular;
	}
	public void setSerialNumberOfCircular(String serialNumberOfCircular) {
		this.serialNumberOfCircular = serialNumberOfCircular;
	}
	public double getaIGSTRate() {
		return aIGSTRate;
	}
	public void setaIGSTRate(double aIGSTRate) {
		this.aIGSTRate = aIGSTRate;
	}
	public double getaCGSTRate() {
		return aCGSTRate;
	}
	public void setaCGSTRate(double aCGSTRate) {
		this.aCGSTRate = aCGSTRate;
	}
	public double getaSGSTRate() {
		return aSGSTRate;
	}
	public void setaSGSTRate(double aSGSTRate) {
		this.aSGSTRate = aSGSTRate;
	}
	public double getaUTGSTRate() {
		return aUTGSTRate;
	}
	public void setaUTGSTRate(double aUTGSTRate) {
		this.aUTGSTRate = aUTGSTRate;
	}
	public double getaCessRate() {
		return aCessRate;
	}
	public void setaCessRate(double aCessRate) {
		this.aCessRate = aCessRate;
	}
	public String getIsTDS() {
		return isTDS;
	}
	public void setIsTDS(String isTDS) {
		this.isTDS = isTDS;
	}
	
}
