package com.ey.advisory.asp.dto;

public class TransactionRefDto {
	
	public String getrefId() {
		return refId;
	}
	public void setrefId(String refId) {
		this.refId = refId;
	}
	public String gettxnId() {
		return txnId;
	}
	public void settxnId(String txnId) {
		this.txnId = txnId;
	}
	String refId;
	String txnId;

}
