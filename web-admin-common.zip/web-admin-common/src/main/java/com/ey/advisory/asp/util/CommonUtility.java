package com.ey.advisory.asp.util;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.domain.EntityHierarchyDto;
import com.ey.advisory.asp.domain.QuestionAnswerModule;
import com.ey.advisory.asp.domain.UploadFileStatus;
import com.ey.advisory.asp.dto.DocumentDetails;
import com.ey.advisory.asp.dto.MonthValueDto;
import com.ey.advisory.asp.dto.SummaryDto;
import com.ey.advisory.asp.dto.YearMonthDto;
import com.google.gson.Gson;

@Component
@PropertySource("classpath:application.properties")
public class CommonUtility {
	@Autowired
	private Environment env;
	private static final Logger LOGGER = Logger.getLogger(CommonUtility.class);
	private static final String CLASS_NAME = CommonUtility.class.getName();
	
	private static Set<String> excludedUrls;
	
	public static YearMonthDto setYearMonth(HttpServletRequest request,
			boolean dbFlag) {
		YearMonthDto ymObj = new YearMonthDto();
		String gstin = (String) request.getSession(false).getAttribute(
				Constant.GSTIN_ID);
		String month = (String) request.getSession(false).getAttribute(
				Constant.MONTH);
		String year = request.getSession(false).getAttribute(Constant.YEAR)
				.toString();
		String user = (String) request.getSession(false).getAttribute(
				Constant.CURRENTUSEREMAILID);
		ymObj.setUserEmailId(user);
		ymObj.setMonth(month);
		ymObj.setYear(year);
		ymObj.setGstinId(gstin);
		ymObj.setDbFlag(dbFlag);

		return ymObj;
	}

	public static YearMonthDto setYearMonth(HttpServletRequest request,
			boolean dbFlag, String taxPeriod, String gstin) {
		YearMonthDto ymObj = new YearMonthDto();
		String user = (String) request.getSession(false).getAttribute(
				Constant.CURRENTUSEREMAILID);
		ymObj.setUserEmailId(user);
		ymObj.setGstinId(gstin);
		ymObj.setRtPeriod(taxPeriod);
		ymObj.setDbFlag(dbFlag);

		return ymObj;
	}
	
	public static YearMonthDto setYearMonth(HttpServletRequest request,
			boolean dbFlag, String taxPeriod, String gstin,String groupCode) {
		YearMonthDto ymObj = new YearMonthDto();
		String user = (String) request.getSession(false).getAttribute(
				Constant.CURRENTUSEREMAILID);
		ymObj.setUserEmailId(user);
		ymObj.setGstinId(gstin);
		ymObj.setRtPeriod(taxPeriod);
		ymObj.setDbFlag(dbFlag);
		ymObj.setGroupCode(groupCode);

		return ymObj;
	}

	@SuppressWarnings("unchecked")
	public static String setInputApi(YearMonthDto dtoObj) {
		JSONObject obj = new JSONObject();
		StringWriter out = new StringWriter();
		obj.put(Constant.MONTH, dtoObj.getMonth());
		obj.put(Constant.YEAR, dtoObj.getYear());
		obj.put(Constant.RT_PERIOD, dtoObj.getRtPeriod());
		obj.put(Constant.GSTIN_ID, dtoObj.getGstinId());
		obj.put(Constant.GROUP_CODE, dtoObj.getGroupCode());
		obj.put("dbFlag", dtoObj.isDbFlag());
		try {
			obj.writeJSONString(out);
		} catch (IOException e) {
			LOGGER.error(e);
		}
		return out.toString();
	}

	@SuppressWarnings("unchecked")
	public static String setInputApi(SummaryDto summaryDto) {
		JSONObject obj = new JSONObject();
		StringWriter out = new StringWriter();
		obj.put(Constant.GSTIN_ID, summaryDto.getGstinId());
		obj.put(Constant.TAX_PERIOD, summaryDto.getTaxPeriod());
		obj.put(Constant.PAYLOAD, summaryDto.getPayLoad());
		obj.put(Constant.SIGNED_DATA, summaryDto.getSigneddata());
		obj.put(Constant.SIGNATURE_TYPE, summaryDto.getSignatureType());
		obj.put(Constant.SID, summaryDto.getSid());
		try {
			obj.writeJSONString(out);
		} catch (IOException e) {
			LOGGER.error(e);
		}
		return out.toString();
	}

	@SuppressWarnings("unchecked")
	public static String setSignAndFileInputs(YearMonthDto dtoObj, boolean flag) {
		JSONObject obj = new JSONObject();
		StringWriter out = new StringWriter();
		obj.put("month", dtoObj.getMonth());
		obj.put("year", dtoObj.getYear());
		obj.put("gstinId", dtoObj.getGstinId());
		obj.put("dbFlag", flag);

		try {
			obj.writeJSONString(out);
		} catch (IOException e) {
			LOGGER.error(e);
		}
		return out.toString();
	}

	@SuppressWarnings("unchecked")
	public static String setYMUserInputs(YearMonthDto dtoObj) {

		JSONObject obj = new JSONObject();
		StringWriter out = new StringWriter();
		obj.put("month", dtoObj.getMonth());
		obj.put("year", dtoObj.getYear());
		obj.put("gstinId", dtoObj.getGstinId());
		obj.put("userEmailId", dtoObj.getUserEmailId());

		try {
			obj.writeJSONString(out);
		} catch (IOException e) {
			LOGGER.error(e);
		}
		return out.toString();
	}

	public String getMonthName(String month) {
		String monthName = "";
		SimpleDateFormat monthParse = new SimpleDateFormat("MM");
		SimpleDateFormat monthDisplay = new SimpleDateFormat("MMMM");
		try {
			monthName = monthDisplay.format(monthParse.parse(month));
		} catch (ParseException e) {
			LOGGER.error(e);
		}
		return monthName;
	}

	public static boolean isEmpty(String value) {
		return value == null || "".equals(value);
	}

	/**
	 * Convert String to long
	 * 
	 * @param value
	 * @param def
	 *            default value
	 * @return
	 */
	public static long toLong(String value, long def) {
		if (isEmpty(value)) {
			return def;
		}

		try {
			return Long.valueOf(value);
		} catch (NumberFormatException e) {
			LOGGER.error(e);
			return def;
		}
	}

	/**
	 * Convert String to int
	 * 
	 * @param value
	 * @param def
	 *            default value
	 * @return
	 */
	public static int toInt(String value, int def) {
		if (isEmpty(value)) {
			return def;
		}
		try {
			return Integer.valueOf(value);
		} catch (NumberFormatException e) {
			LOGGER.error(e);
			return def;
		}
	}

	public static DocumentDetails setYearMonthDocId(HttpServletRequest request,
			String docId) {
		DocumentDetails docDetails = new DocumentDetails();
		YearMonthDto ymObj = new YearMonthDto();
		String gstin = (String) request.getSession(false).getAttribute(
				Constant.GSTIN_ID);
		String month = (String) request.getSession(false).getAttribute(
				Constant.MONTH);
		String year = request.getSession(false).getAttribute(Constant.YEAR)
				.toString();
		String user = (String) request.getSession(false).getAttribute(
				Constant.CURRENTUSEREMAILID);
		ymObj.setUserEmailId(user);
		ymObj.setMonth(month);
		ymObj.setYear(year);
		ymObj.setGstinId(gstin);
		docDetails.setDocId(docId);
		docDetails.setYearMonthDto(ymObj);
		return docDetails;
	}

	public static DocumentDetails setYearMonth(HttpServletRequest request,
			String gstin, String taxPeriod, String docId) {
		String user = (String) request.getSession(false).getAttribute(
				Constant.CURRENTUSEREMAILID);
		DocumentDetails docDetails = new DocumentDetails();
		YearMonthDto ymObj = new YearMonthDto();
		ymObj.setUserEmailId(user);
		ymObj.setRtPeriod(taxPeriod);
		ymObj.setGstinId(gstin);
		docDetails.setDocId(docId);
		docDetails.setYearMonthDto(ymObj);
		return docDetails;
	}

	public static List<String> writeZipFile(MultipartFile file, File folder,
			Integer chunk, int BUFFER_SIZE) {
		List<String> fileList = null;
		byte[] buffer = new byte[BUFFER_SIZE];

		ZipInputStream zipInputStream;
		try {
			zipInputStream = new ZipInputStream(file.getInputStream());

			ZipEntry zipEntry = zipInputStream.getNextEntry();
			fileList = new ArrayList<>();
			while (zipEntry != null) {

				String eachFile = zipEntry.getName();
				File destFile = new File(folder, eachFile);

				if (chunk == 0 && destFile.exists()) {
					destFile.delete();
					destFile = new File(folder, eachFile);
				}
				new File(destFile.getParent()).mkdirs();

				FileOutputStream fos = new FileOutputStream(destFile);
				int len;
				while ((len = zipInputStream.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				fos.close();
				zipEntry = zipInputStream.getNextEntry();

				fileList.add(eachFile);
			}
			zipInputStream.closeEntry();
			zipInputStream.close();

		} catch (IOException e) {
			LOGGER.error(e);
		}
		return fileList;
	}
	
	public static List<String> unzipAndwriteFiles(String currtime,File file, File folder,
			Integer chunk, int BUFFER_SIZE) {
		List<String> fileList = null;
		byte[] buffer = new byte[BUFFER_SIZE];

		ZipInputStream zipInputStream;
		try {
			zipInputStream = new ZipInputStream(new FileInputStream(file));

			ZipEntry zipEntry = zipInputStream.getNextEntry();
			fileList = new ArrayList<>();
			while (zipEntry != null) {				
				String eachFile = currtime+"_"+zipEntry.getName();
				File destFile = new File(folder, eachFile);

				if (chunk == 0 && destFile.exists()) {
					destFile.delete();
					destFile = new File(folder, eachFile);
				}
				new File(destFile.getParent()).mkdirs();

				FileOutputStream fos = new FileOutputStream(destFile);
				int len;
				while ((len = zipInputStream.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				fos.close();
				zipEntry = zipInputStream.getNextEntry();

				fileList.add(eachFile);
			}
			zipInputStream.closeEntry();
			zipInputStream.close();

		} catch (IOException e) {
			LOGGER.error(e);
		}
		return fileList;
	}


	public static List<String> writeSingleFile(MultipartFile file,
			String fileName, File folder, Integer chunk, int BUFFER_SIZE) {
		List<String> fileList = null;
		try {
			File destFile = new File(folder, fileName);
			if (chunk == 0 && destFile.exists()) {
				destFile.delete();
				destFile = new File(folder, fileName);
			}
			appendFile(file.getInputStream(), destFile, BUFFER_SIZE);
			fileList = new ArrayList<>();
			fileList.add(fileName);

		} catch (IOException e) {
			LOGGER.error("CommonUtilty"+"writeSingleFile()",e);
		} catch (Exception e) {
			LOGGER.error("CommonUtilty"+"writeSingleFile()",e);
		}
		
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("return file list from writeSingleFile() are.."+ fileList);
			}
		return fileList;
	}

	public static void appendFile(InputStream in, File destFile, int BUFFER_SIZE)
			throws IOException, Exception {
		OutputStream out = null;
		
		try {
			
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("dest file for appendFile()"+ destFile);
				}
			//
			if (destFile.exists()) {
				out = new BufferedOutputStream(new FileOutputStream(destFile,
						true), BUFFER_SIZE);
			} else {
				out = new BufferedOutputStream(new FileOutputStream(destFile),
						BUFFER_SIZE);
			}
			in = new BufferedInputStream(in, BUFFER_SIZE);

			int len = 0;
			byte[] buffer = new byte[BUFFER_SIZE];
			while ((len = in.read(buffer)) > 0) {
				out.write(buffer, 0, len);
			}
		} catch (Exception ex) {
			LOGGER.error("CommonUtilty"+"appendFile()",ex);
		} finally {
			try {
				if (null != in) {
					in.close();
				}
				if (null != out) {
					out.close();
				}
			} catch (Exception ex) {
				LOGGER.error("CommonUtilty"+"appendFile() finaly",ex);
			}
		}
	}

	public static UploadFileStatus getfileObject(Long userId, String fileName,
			String usergstin, String fileMode, String filefolder, String extn,
			String legalName, String group, String entity,boolean isMagicFile) {
		UploadFileStatus fileStatus = new UploadFileStatus();
		fileStatus.setUserId(userId);
		fileStatus.setfName(fileName);
		fileStatus.setGstin(usergstin);
		fileStatus.setFileData(fileMode);
		fileStatus.setMapId(isMagicFile?Constant.MAP_ID:0);//move to constant
		fileStatus.setFilePath(filefolder);
		fileStatus.setFileType(extn);
		fileStatus.setLegalName(legalName);
		fileStatus.setGroupName(group);
		fileStatus.setEntityName(entity);
		return fileStatus;
	}
	
	//getfileObject with hashString as extra parameter
	public static UploadFileStatus getfileObject(Long userId, String fileName,
			String usergstin, String fileMode, String filefolder, String extn,
			String legalName, String group, String entity,boolean isMagicFile,String hashString, String updatedBy) {
		UploadFileStatus fileStatus = new UploadFileStatus();
		fileStatus.setUserId(userId);
		fileStatus.setfName(fileName);
		fileStatus.setGstin(usergstin);
		fileStatus.setFileData(fileMode);
		fileStatus.setMapId(isMagicFile?Constant.MAP_ID:0);//move to constant
		fileStatus.setFilePath(filefolder);
		fileStatus.setFileType(extn);
		fileStatus.setLegalName(legalName);
		fileStatus.setGroupName(group);
		fileStatus.setEntityName(entity);
		fileStatus.setFileHash(hashString);
		fileStatus.setUpdatedBy(updatedBy);
		
		return fileStatus;
	}
	
	

	public static String getTaxPeriod(){ 
		int currentMonth = Calendar.getInstance().get(Calendar.MONTH);
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		StringBuilder taxPeriod = new StringBuilder();
		if (currentMonth < 10) {
			taxPeriod.append("0");
		}
		taxPeriod.append(currentMonth);
		taxPeriod.append(currentYear);
		return taxPeriod.toString();
	}

	public static StringBuilder getFromAndToDate() {
		int currentMonth = Calendar.getInstance().get(Calendar.MONTH);
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		String fromDate;
		if (currentMonth < 4) {
			fromDate = "01-04-" + (currentYear - 1);
		} else {
			fromDate = "01-04-" + currentYear;
		}
		StringBuilder dates = new StringBuilder();
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		Date today = Calendar.getInstance().getTime();
		String todayString = df.format(today);
		if ((currentMonth < 10) && (currentMonth >= 4)) {
			dates.append(fromDate);
			dates.append(";");
			dates.append(todayString);
		} else {
			dates.append(fromDate);
			dates.append(";");
			dates.append("31-09-" + (currentYear - 1));
			dates.append(";");
			dates.append("01-10-" + (currentYear - 1));
			dates.append(";");
			dates.append(todayString);
		}
		return dates;
	}

	public static void returnFinanceDate(String date) {
		Calendar now = Calendar.getInstance();
		String[] ymd = date.split("-");
		int yr = Integer.parseInt(ymd[2]);
		int month = Integer.parseInt(ymd[1]);
		now.set(Calendar.YEAR, yr);
		now.set(Calendar.MONTH, month);
		int year = now.get(Calendar.YEAR)
				- (now.get(Calendar.MONTH) < 4 ? 1 : 0);
		LOGGER.info("Finance year Start Date" + "  " + "01-04-" + year);
		LOGGER.info("Finance year End Date" + " " + "31-03-"
				+ (year + 1));
		LOGGER.info("--------------------------------------------------------");
	}

	public static void finalDate(String date) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat(
				"EE MMM dd hh:mm:ss z yyyy");
		Calendar now = Calendar.getInstance();
		String[] ymd = date.split("-");
		int yr = Integer.parseInt(ymd[2]);
		int month = Integer.parseInt(ymd[1]);
		now.set(Calendar.YEAR, yr);
		now.set(Calendar.MONTH, month);
		int year = now.get(Calendar.YEAR)
				- (now.get(Calendar.MONTH) < 4 ? 1 : 0);
		LOGGER.info("Final Start Date" + "  " + "01-04-" + year);
		Date date1 = getLastDateOfMonth(yr, month - 2);
		Date theDate = format.parse(date1.toString());
		now.setTime(theDate);
		LOGGER.info("Final Last Date" + "  "
				+ now.get(Calendar.DAY_OF_MONTH) + "-"
				+ (now.get(Calendar.MONTH) + 1) + "-" + now.get(Calendar.YEAR));
		LOGGER.info("--------------------------------------------------------");
	}

	public static void provisionalDate(String date) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat(
				"EE MMM dd hh:mm:ss z yyyy");
		Calendar now = Calendar.getInstance();
		String[] ymd = date.split("-");
		int yr = Integer.parseInt(ymd[2]);
		int month = Integer.parseInt(ymd[1]);
		now.set(Calendar.DAY_OF_MONTH,
				now.getActualMinimum(Calendar.DAY_OF_MONTH));
		Date theDate = format.parse(now.getTime().toString());
		now.setTime(theDate);
		LOGGER.info("Provisional Start Date" + "  "
				+ now.get(Calendar.DAY_OF_MONTH) + "-" + month + "-" + yr);
		LOGGER.info("Provisional Last Date" + "  " + date);
	}

	private static Date getLastDateOfMonth(int year, int month) {
		Calendar calendar = new GregorianCalendar(year, month,
				Calendar.DAY_OF_MONTH);
		calendar.set(Calendar.DAY_OF_MONTH,
				calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		return calendar.getTime();
	}

	// Object null check
	public static boolean isEmpty(Object obj) {
		if (obj == null) {
			return true;
		}
		return false;
	}

	// Collection null check
	public static boolean isEmpty(Collection<?> value) {
		if (value == null || value.isEmpty()) {
			return true;
		}
		return false;
	}

	private static void createNumericCell(Row row, Double val, int col, CellStyle styleRowNumber) {
		DecimalFormat df = new DecimalFormat("0.00");
		Cell cell = row.createCell(col);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellStyle(styleRowNumber);
		cell.setCellValue(df.format(val));
	}

	private static void createStringCell(Row row, String val, int col) {
		Cell cell = row.createCell(col);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue(val);

	}

	public static Workbook ledgerDetailsToExcelSheet(String ledgerDetails)
			throws IOException {

		Workbook workbook = new SXSSFWorkbook();
		int rowValue = 0;
		int col = 0;
		
		Sheet ledgerDetailSheet = workbook
				.createSheet("Ledger Balance Details");
		ledgerDetailSheet.setDefaultColumnWidth(20);
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = null;
		try {
			if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Parsing the JSON for ledger details.");
			}
			jsonObject = (JSONObject) jsonParser.parse(ledgerDetails);
		} catch (org.json.simple.parser.ParseException e) {
			LOGGER.error("Failed to parse JSON for ledger details.",e);
			 return workbook;
			
		}
         //add headers
         CellStyle style = workbook.createCellStyle();
         Font font = workbook.createFont();
         font.setFontHeightInPoints((short) 10);
         font.setFontName("Arial");
         font.setColor(IndexedColors.WHITE.getIndex());
         font.setBoldweight(Font.BOLDWEIGHT_BOLD);
         style.setAlignment(CellStyle.ALIGN_CENTER);
         style.setFont(font);
         style.setFillForegroundColor(IndexedColors.BLACK.getIndex());
         style.setFillPattern(CellStyle.SOLID_FOREGROUND);
         
         Row rowMainHeader = ledgerDetailSheet.createRow(rowValue);
         Cell cell = rowMainHeader.createCell(col);
         cell.setCellValue("Ledger Balance (In Lakhs):"+getFormattedDate()+ " \t GSTIN:" +  (String) jsonObject.get("gstin"));
         cell.setCellStyle(style);
         ledgerDetailSheet.addMergedRegion(new CellRangeAddress( 0, 0, 0, 4  ));
         rowValue++;
         
         CellStyle styleHeader = workbook.createCellStyle();
         styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
         styleHeader.setFont(font);
         styleHeader.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.getIndex());
         styleHeader.setFillPattern(CellStyle.SOLID_FOREGROUND);
        
         Row rowHeaders = ledgerDetailSheet.createRow(rowValue);
         for (String header : Constant.LEDGER_HEADERS) {
                Cell cell1 = rowHeaders.createCell(col);
                cell1.setCellValue(header);
                cell1.setCellStyle(styleHeader);
                col++;
         }
         rowValue++;
         CellStyle styleColumns = workbook.createCellStyle();
         Font fontCol = workbook.createFont();
         fontCol.setFontHeightInPoints((short) 10);
         fontCol.setFontName("Arial");
         fontCol.setColor(IndexedColors.BLACK.getIndex());
      
         styleColumns.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
         styleColumns.setFillPattern(CellStyle.SOLID_FOREGROUND);
         styleColumns.setAlignment(CellStyle.ALIGN_CENTER);
         styleColumns.setFont(fontCol);
         String[] aliasArray = new String[4];
         JSONObject[] JSONArray = new JSONObject[4];
         JSONArray ledgerBalance = (JSONArray) jsonObject.get("ledgerBal");
         if(null != ledgerBalance){
        	 for(int i=0; i<ledgerBalance.size();i++){
        		 JSONObject ledgerBalDetails = (JSONObject) ledgerBalance.get(i);
        		 String alias= (String) ledgerBalDetails.get("alias");
        		 aliasArray[i]=alias;
        		 JSONArray[i]=ledgerBalDetails;
        	 }
	         Row row = ledgerDetailSheet.createRow(2);
	         if(ArrayUtils.contains(aliasArray,"ITC")){
	        	 int index = Arrays.asList(aliasArray).indexOf("ITC");
	        	 JSONObject ledgerBalDetailsObject = JSONArray[index];
	        	 insertRowValues(row, "ITC", styleColumns,ledgerBalDetailsObject);
	         }else{
	        	 insertRowValuesAsNull(row, "ITC", styleColumns);
	         }
	         
	          row = ledgerDetailSheet.createRow(3);
	         if(ArrayUtils.contains(aliasArray,"CSL")){
	        	 int index = Arrays.asList(aliasArray).indexOf("CSL");
	        	 JSONObject ledgerBalDetailsObject = JSONArray[index];
	        	 insertRowValues(row, "CSL", styleColumns,ledgerBalDetailsObject);
	         }else{
	        	 insertRowValuesAsNull(row, "CSL", styleColumns);
	         }
	         
	          row = ledgerDetailSheet.createRow(4);
	         if(ArrayUtils.contains(aliasArray,"LLD")){
	        	 int index = Arrays.asList(aliasArray).indexOf("LLD");
	        	 JSONObject ledgerBalDetailsObject = JSONArray[index];
	        	 insertRowValues(row, "LLD", styleColumns,ledgerBalDetailsObject);
	         }else{
	        	 insertRowValuesAsNull(row, "LLD", styleColumns);
	         }
	         
	          row = ledgerDetailSheet.createRow(5);
	         if(ArrayUtils.contains(aliasArray,"net")){
	        	 int index = Arrays.asList(aliasArray).indexOf("net");
	        	 JSONObject ledgerBalDetailsObject = JSONArray[index];
	        	 insertRowValues(row, "net", styleColumns,ledgerBalDetailsObject);
	         }else{
	        	 insertRowValuesAsNull(row, "net", styleColumns);
	         }
         }
         return workbook;
         
  }
	
	private static String getColHeaderAlias(String alias) {
		String colHeader=null;
		if(alias.equalsIgnoreCase(Constant.ITC)){
			colHeader=Constant.LEDGER_COL_HEADERS[0];
		}else if(alias.equalsIgnoreCase(Constant.CSL)){
			colHeader=Constant.LEDGER_COL_HEADERS[1];
		}else if(alias.equalsIgnoreCase(Constant.LLD)){
			colHeader=Constant.LEDGER_COL_HEADERS[2];
		}else if(alias.equalsIgnoreCase(Constant.NET)){
			colHeader=Constant.LEDGER_COL_HEADERS[3];
		}
		return colHeader;
	}
	
	private static void insertRowValues(Row row,String alias,  CellStyle styleColumns,JSONObject ledgerBalDetails){
		stringCellCreation(row,getColHeaderAlias(alias) ,0,styleColumns);
		numericIntCellCreation(row, ledgerBalDetails.get("cgst")== null ? 0.00:convertToLakhs((Double) ledgerBalDetails.get("cgst")), 1, styleColumns);
		numericIntCellCreation(row, ledgerBalDetails.get("sgst")== null ? 0.00:convertToLakhs((Double) ledgerBalDetails.get("sgst")), 2, styleColumns);
        numericIntCellCreation(row, ledgerBalDetails.get("igst")== null ? 0.00:convertToLakhs((Double) ledgerBalDetails.get("igst")), 3, styleColumns );
        numericIntCellCreation(row, ledgerBalDetails.get("cess")== null ? 0.00:convertToLakhs((Double) ledgerBalDetails.get("cess")), 4, styleColumns);
	}
	
	private static void insertRowValuesAsNull(Row row,String alias,  CellStyle styleColumns){
		stringCellCreation(row,getColHeaderAlias(alias) ,0,styleColumns);
		numericIntCellCreation(row, 0.00, 1, styleColumns);
		numericIntCellCreation(row, 0.00, 2, styleColumns);
		numericIntCellCreation(row, 0.00, 3, styleColumns );
		numericIntCellCreation(row, 0.00, 4, styleColumns);
	}
  
  private static void numericIntCellCreation(Row row, Double val, int col, CellStyle style) {
         Cell cell = row.createCell(col);
         cell.setCellType(Cell.CELL_TYPE_NUMERIC);
         cell.setCellValue(val);
         cell.setCellStyle(style);
  }

	private static void stringCellCreation(Row row, String val, int col,
			CellStyle style) {

		Cell cell = row.createCell(col);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue(val);
		cell.setCellStyle(style);

	}
	
	private static Double convertToLakhs(Double num){
		Double divideBy = 100000.00;
		Double result = (num/divideBy);
		DecimalFormat df = new DecimalFormat("#.00");     
		return Double.valueOf(df.format(result));
		
	}
	
	public static String getFormattedDate(){
		Date date=new Date();
        Calendar cal=Calendar.getInstance();
        cal.setTime(date);
        //2nd of march 2015
        int day=cal.get(Calendar.DATE);

        if(!((day>10) && (day<19)))
        switch (day % 10) {
        case 1:  
            return new SimpleDateFormat("d'st' MMMM yyyy").format(date);
        case 2:  
            return new SimpleDateFormat("d'nd' MMMM yyyy").format(date);
        case 3:  
            return new SimpleDateFormat("d'rd' MMMM yyyy").format(date);
        default: 
            return new SimpleDateFormat("d'th' MMMM yyyy").format(date);
    }
    return new SimpleDateFormat("d'th' MMMM yyyy").format(date);
}
	
	
	public static String getMD5HashValueFromFile(File file){
		byte[] uploadBytes;
		MessageDigest md5;
		String hashString = null;
		try {
			uploadBytes = Files.readAllBytes(file.toPath());
			md5 = MessageDigest.getInstance("MD5");
			byte[] digest = md5.digest(uploadBytes);
			hashString = new BigInteger(1, digest).toString(16);
		} catch (IOException | NoSuchAlgorithmException e) {
			LOGGER.error("Error inside MD5 Hash value generate",e);
		}
		return hashString;		
	}
	
	public String getMD5HashValueFromFile1(String filePath) throws IOException{
        MessageDigest digest;
        String hashString = null;
        String bufferSizeString = env.getProperty("fileUploadHashBufferSize");
        int bufferSize=1024;
        bufferSize=bufferSizeString==null?bufferSize:Integer.valueOf(bufferSizeString);//10MB
        try {
        	
        	   FileInputStream ins=new FileInputStream(filePath);  
               BufferedInputStream in =new BufferedInputStream(ins);
               digest = MessageDigest.getInstance("MD5");
               byte[] buffer = new byte[bufferSize];
               int sizeRead;
               while ((sizeRead = in.read(buffer)) != -1) {
                     digest.update(buffer, 0, sizeRead);
                    
               }
               in.close();
               ins.close();
               
               hashString = new BigInteger(1, digest.digest()).toString(16);
        } catch (IOException | NoSuchAlgorithmException e) {
               LOGGER.error("Error inside MD5 Hash value generate", e);
               throw new IOException();
        }catch (Exception e) {
            LOGGER.error("Error inside MD5 Hash value generate", e);
            throw new IOException();
     }
        return hashString;
 }

	public static Workbook writeSummaryToFile(String ledgerDetails)
			throws IOException {

		Workbook workbook = new SXSSFWorkbook();
		/*int rowValue = 0;
		int col = 0;
		
		Sheet ledgerDetailSheet = workbook
				.createSheet("Ledger Balance Details");
		ledgerDetailSheet.setDefaultColumnWidth(20);
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = null;
		try {
			LOGGER.debug("Parsing the JSON for ledger details.");
			jsonObject = (JSONObject) jsonParser.parse(ledgerDetails);
		} catch (org.json.simple.parser.ParseException e) {
			LOGGER.debug("Failed to parse JSON for ledger details.");
			 return workbook;
			
		}
         //add headers
         CellStyle style = workbook.createCellStyle();
         Font font = workbook.createFont();
         font.setFontHeightInPoints((short) 10);
         font.setFontName("Arial");
         font.setColor(IndexedColors.WHITE.getIndex());
         font.setBoldweight(Font.BOLDWEIGHT_BOLD);
         style.setAlignment(CellStyle.ALIGN_CENTER);
         style.setFont(font);
         style.setFillForegroundColor(IndexedColors.BLACK.getIndex());
         style.setFillPattern(CellStyle.SOLID_FOREGROUND);
         
         Row rowMainHeader = ledgerDetailSheet.createRow(rowValue);
         Cell cell = rowMainHeader.createCell(col);
         cell.setCellValue("Ledger Balance (In Lakhs):"+getFormattedDate()+ " \t GSTIN:" +  (String) jsonObject.get("gstin"));
         cell.setCellStyle(style);
         ledgerDetailSheet.addMergedRegion(new CellRangeAddress( 0, 0, 0, 4  ));
         rowValue++;
         
         CellStyle styleHeader = workbook.createCellStyle();
         styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
         styleHeader.setFont(font);
         styleHeader.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.getIndex());
         styleHeader.setFillPattern(CellStyle.SOLID_FOREGROUND);
        
         Row rowHeaders = ledgerDetailSheet.createRow(rowValue);
         for (String header : Constant.LEDGER_HEADERS) {
                Cell cell1 = rowHeaders.createCell(col);
                cell1.setCellValue(header);
                cell1.setCellStyle(styleHeader);
                col++;
         }
         rowValue++;
         CellStyle styleColumns = workbook.createCellStyle();
         Font fontCol = workbook.createFont();
         fontCol.setFontHeightInPoints((short) 10);
         fontCol.setFontName("Arial");
         fontCol.setColor(IndexedColors.BLACK.getIndex());
      
         styleColumns.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
         styleColumns.setFillPattern(CellStyle.SOLID_FOREGROUND);
         styleColumns.setAlignment(CellStyle.ALIGN_CENTER);
         styleColumns.setFont(fontCol);
        // String[] aliasArray = {"ITC","CSL","LLD","net"};
         String[] aliasArray = new String[4];
         JSONObject[] JSONArray = new JSONObject[4];
         JSONArray ledgerBalance = (JSONArray) jsonObject.get("ledgerBal");
         if(null != ledgerBalance){
        	 for(int i=0; i<ledgerBalance.size();i++){
        		 JSONObject ledgerBalDetails = (JSONObject) ledgerBalance.get(i);
        		 String alias= (String) ledgerBalDetails.get("alias");
        		 aliasArray[i]=alias;
        		 JSONArray[i]=ledgerBalDetails;
        	 }
	         Row row = ledgerDetailSheet.createRow(2);
	         if(ArrayUtils.contains(aliasArray,"ITC")){
	        	 int index = Arrays.asList(aliasArray).indexOf("ITC");
	        	 JSONObject ledgerBalDetailsObject = JSONArray[index];
	        	 insertRowValues(row, "ITC", styleColumns,ledgerBalDetailsObject);
	         }else{
	        	 insertRowValuesAsNull(row, "ITC", styleColumns);
	         }
	         
	          row = ledgerDetailSheet.createRow(3);
	         if(ArrayUtils.contains(aliasArray,"CSL")){
	        	 int index = Arrays.asList(aliasArray).indexOf("CSL");
	        	 JSONObject ledgerBalDetailsObject = JSONArray[index];
	        	 insertRowValues(row, "CSL", styleColumns,ledgerBalDetailsObject);
	         }else{
	        	 insertRowValuesAsNull(row, "CSL", styleColumns);
	         }
	         
	          row = ledgerDetailSheet.createRow(4);
	         if(ArrayUtils.contains(aliasArray,"LLD")){
	        	 int index = Arrays.asList(aliasArray).indexOf("LLD");
	        	 JSONObject ledgerBalDetailsObject = JSONArray[index];
	        	 insertRowValues(row, "LLD", styleColumns,ledgerBalDetailsObject);
	         }else{
	        	 insertRowValuesAsNull(row, "LLD", styleColumns);
	         }
	         
	          row = ledgerDetailSheet.createRow(5);
	         if(ArrayUtils.contains(aliasArray,"net")){
	        	 int index = Arrays.asList(aliasArray).indexOf("net");
	        	 JSONObject ledgerBalDetailsObject = JSONArray[index];
	        	 insertRowValues(row, "net", styleColumns,ledgerBalDetailsObject);
	         }else{
	        	 insertRowValuesAsNull(row, "net", styleColumns);
	         }
         }*/
         return workbook;
         
  }
	
	public static String getDueMonthYear(String retPeriod) {

		String[] monthYear = retPeriod.split("\\s+");
		String month = monthYear[0];
		String year = monthYear[1];

		if (Month.valueOf(month.toUpperCase()).getValue() < 12) {
			month = String.valueOf(Month.of(Month.valueOf(month.toUpperCase())
					.getValue() + 1));
			return month + " " + year;
		} else {
			month = String.valueOf(Month.of(Month.valueOf(
					Month.JANUARY.toString()).getValue()));
			int newYear = Integer.parseInt(year) + 1;
			return month + " " + newYear;
		}

	}
	
	public static String getJsonFromObject(Object obj)
	{
		if(obj!=null)
		{
			Gson gson=new Gson();
			return gson.toJson(obj);
		}
		return "";
	}
	
	public static <T> T getObjectFromJson(String json,Class<T> clazz)
	{
		if(json!=null && json.length()>0)
		{
			Gson gson=new Gson();
			return gson.fromJson(json, clazz);
		}
		return null;
	}
	
	public static byte[] transformXmlToExcel(HttpServletRequest request,String inputXml,String templatePath) {
		byte[] content ;
		StringReader reader = new StringReader(inputXml);
		Source sourceXml=new StreamSource(reader);
		Source sourceXslt=new StreamSource(new File(request.getSession(false).getServletContext().getRealPath("")+ templatePath));
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	    Result Output = new StreamResult(outputStream);
	    TransformerFactory transformerFactory = new net.sf.saxon.TransformerFactoryImpl();
	    //s89 - green, s57/s51 - red,s91 - yellow
        try {
        	Transformer transformer = transformerFactory.newTransformer(sourceXslt);
			transformer.transform(sourceXml, Output);
			content = outputStream.toByteArray();
		} catch (TransformerException e) {
			String errorMessage = Constant.ERROR_MESSAGE;
			content = errorMessage.getBytes();
			LOGGER.error("Exception while transformation "+e);
		}

	return content;
	}
	
	public static Date getSpecificDatePastNow(int months)
    {
           Calendar c = Calendar.getInstance();
           c.setTime(new Date());
           c.add(Calendar.MONTH,-months);
           return c.getTime();
    }
	
	public static String getStringDate(Date date,String format)
    {
           SimpleDateFormat sdf=new SimpleDateFormat(format);
           return sdf.format(date);
    }
	
	@SuppressWarnings("unchecked")
	public static org.json.simple.JSONObject getHierarchy(String level,List<EntityHierarchyDto> userEntityHierarchyList){
		StringBuffer stringBuffer = new StringBuffer();
		org.json.simple.JSONObject jsonObject = new org.json.simple.JSONObject();
		jsonObject.put(Constant.ENTITY, "NULL");
		jsonObject.put(Constant.CIRCLE, "NULL");
		jsonObject.put(Constant.GSTIN_CODE, "NULL");
		jsonObject.put(Constant.SUB_DIVISION, "NULL");
		jsonObject.put(Constant.PROFIT_CENTER, "NULL");
		jsonObject.put(Constant.BUSINESS_UNIT, "NULL");
		jsonObject.put(Constant.PLANT_CODE, "NULL");
		String hierarchy = "";
		Iterator<EntityHierarchyDto> it = userEntityHierarchyList.iterator();
		while(it.hasNext()){
			EntityHierarchyDto entityHierarchyDto = it.next();
			switch (level.toUpperCase()) {
			case "ENTITY":
				hierarchy = entityHierarchyDto.getEntityCode();
				break;
			case "CIRCLE":
				hierarchy = entityHierarchyDto.getCircleCode();
				break;
			case "GSTIN":
				hierarchy = entityHierarchyDto.getgSTIN();
				break;
			case "SUBDIVISION":
				hierarchy = entityHierarchyDto.getSubDivCode();
				break;
			case "PROFITCENTER":
				hierarchy = entityHierarchyDto.getProfitCenterCode();
				break;
			case "BUSINESSUNIT":
				hierarchy = entityHierarchyDto.getBusinessUnitCode();
				break;
			case "PLANTCODE":
				hierarchy = entityHierarchyDto.getPlantCode();
				break;
			default:
				break;
			}
			stringBuffer.append(hierarchy).append(",");
		}
		String entireHierarchy = stringBuffer.deleteCharAt(stringBuffer.length()-1).toString();
		jsonObject.put(level, entireHierarchy);
		return jsonObject;
	}
	
	public static void generateReport(HttpServletRequest request,HttpServletResponse response,String errorXml,String xsltTemplate,String outputXlsName){
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering " + CLASS_NAME+ " Method : generateErrorReport");
		}
		byte[] file ;
		try {
		file = transformXmlToExcel(request,errorXml, xsltTemplate);
		response.setContentType(Constant.CONTENT_TYPE);
		response.setHeader("Content-Disposition",String.format("attachment; filename="+ outputXlsName+ ".xls"));
		response.getOutputStream().write(file);
		response.getOutputStream().flush();
		response.getOutputStream().close();
		} catch (IOException e) {
			if(LOGGER.isInfoEnabled())
			LOGGER.info("Exception in " + CLASS_NAME+ " Method : generateErrorReport"+ e);
		}
		
	}
	/**
	 * method to check  Client Response Upload Option from 11 to 15 in every month
	 * @return
	 */
	public Boolean checkValidTimePeriod()
	{
		Boolean checkFlag=false;
		Date date=new Date();
        Calendar cal=Calendar.getInstance();
        cal.setTime(date);
        //2nd of march 2015
        int day=cal.get(Calendar.DATE);

        if(((day>Integer.parseInt(env.getProperty("gstr.reconStartDate"))) && (day<Integer.parseInt(env.getProperty("gstr.reconEndDate")))))
            return checkFlag=true;
        else
        	return checkFlag;
	}
	
	@SuppressWarnings("unchecked")
	public static org.json.simple.JSONObject populateEntityHierarchy(String level,List<EntityHierarchyDto> userEntityHierarchyList){
		org.json.simple.JSONObject jsonObject = new org.json.simple.JSONObject();
		EntityHierarchyDto entityHierarchyDto = userEntityHierarchyList.get(0);
			jsonObject.put(Constant.ENTITY, entityHierarchyDto.getEntityID());
			jsonObject.put(Constant.CIRCLE, entityHierarchyDto.getCircleCode());
			jsonObject.put(Constant.GSTIN_CODE, entityHierarchyDto.getgSTIN());
			jsonObject.put(Constant.SUB_DIVISION, entityHierarchyDto.getSubDivCode());
			jsonObject.put(Constant.PROFIT_CENTER, entityHierarchyDto.getProfitCenterCode());
			jsonObject.put(Constant.BUSINESS_UNIT,entityHierarchyDto.getBusinessUnitCode());
			jsonObject.put(Constant.PLANT_CODE,entityHierarchyDto.getPlantCode());
			return jsonObject;
	}
	
	public static Object convertXmlToDto(String xml){
		//String xml = "<Gstr3bSummary><year>12</year><LegalName /></Gstr3bSummary>";
		Object dto = null;
		try {
		JAXBContext jaxbContext = JAXBContext.newInstance(Object.class);
		InputStream stream = new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8));
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		dto = (Object) jaxbUnmarshaller.unmarshal(stream);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dto;
	}
	
	public static String getActiveTaxPeriod(String currTaxPeriod)
	{
		int month=Integer.parseInt(currTaxPeriod.substring(0,2));
		int year=Integer.parseInt(currTaxPeriod.substring(2,currTaxPeriod.length()));
			
		Calendar cal=Calendar.getInstance();
		cal.set(year, month-1,1);
		cal.add(Calendar.MONTH, -1);
		month=cal.get(Calendar.MONTH);
		year=cal.get(Calendar.YEAR);
		
		return String.format("%02d", month+1)+year;
	}
	
	public static List<Integer> getYears(int months)
	{
		List<Integer> yearList=new LinkedList<Integer>();
		Calendar cal=Calendar.getInstance();
		int currentYear=cal.get(Calendar.YEAR);
		cal.add(Calendar.MONTH, -months);
		int startYear=cal.get(Calendar.YEAR);
		if(startYear<2017){
			startYear=currentYear;
		}
		for(int i=currentYear;i>=startYear;i--){
			yearList.add(i);
		}
		return yearList;
		
	} 
	
	public static Boolean getDateVisibility(int minDate){
		
		Calendar cal=Calendar.getInstance();
		int currDate=cal.get(Calendar.DAY_OF_MONTH);
		return currDate<=minDate;
	} 

	public static String getTaxPeriodFormattedAsMMMYY(String taxperiod){
		String formattedDate="";
		if(taxperiod!=null && taxperiod.length()>0){
			String month="";
			if(taxperiod.length()>5){
				//format 102017
				month=taxperiod.substring(0,2);
			}else{
				//format 12017
				month=taxperiod.substring(0,1);
			}
			String lastTwoDigitsYear = taxperiod.substring(taxperiod.length()-2, taxperiod.length());
			formattedDate=new DateFormatSymbols().getMonths()[Integer.parseInt(month)-1].substring(0, 3)+lastTwoDigitsYear;
			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("Tax Period in MMMYY format is "+formattedDate );
			}
			
		}
		return formattedDate;
	}
	
	public static void setAsposeLicense(){
		InputStream stream=CommonUtility.class.getClassLoader().getResourceAsStream("licenses/Aspose.Cells.lic");
		com.aspose.cells.License license = new com.aspose.cells.License();
		license.setLicense(stream);
	}
	
	
	public static Map<Integer,List<MonthValueDto>> generateTaxPeriod(String currTaxPeriod,int cutOffDate){
		int latestMonth=Integer.parseInt(currTaxPeriod.substring(0,2));
		int latestYear=Integer.parseInt(currTaxPeriod.substring(2,currTaxPeriod.length()));
		
		Calendar cal=Calendar.getInstance();
		int currDate=cal.get(Calendar.DAY_OF_MONTH);
		
		if(currDate<cutOffDate){
			latestMonth-=1;
			if(latestMonth==12){
				latestYear-=1;
			}
		}
		cal.set(latestYear, latestMonth-1,1);
		cal.add(Calendar.MONTH, -17);
		
		int startMonth=cal.get(Calendar.MONTH) + 1;
		int startYear=cal.get(Calendar.YEAR)+1;
	
		List<MonthValueDto> monthList=null;
		Map<Integer,List<MonthValueDto>> yearMonthMap=new LinkedHashMap<Integer, List<MonthValueDto>>();
		for(int year=latestYear;year<=startYear;year++){
			
			if(year==latestYear){
				monthList=getMonthsList(year,1, latestMonth);
			}else if(year==startYear){
				monthList=getMonthsList(year,startMonth, 12);
			}else{
				monthList=getMonthsList(year,1, 12);
			}
			yearMonthMap.put(year, monthList);
		}
		return yearMonthMap;
	}
	
	private static List<MonthValueDto> getMonthsList(int year,int startMonth,int endMonth)
	{
		DateFormatSymbols dfs=new DateFormatSymbols();
		List<MonthValueDto> monthList=new LinkedList<MonthValueDto>();
		for(int month=startMonth;month<=endMonth;month++){
			monthList.add(new MonthValueDto(year,dfs.getMonths()[month-1],String.format("%02d", month)));
		}
		return monthList;
	}
	
	public static void  setExcludedURLString(String excludedString){
		 
	        if (excludedString != null) {
	            excludedUrls = Collections.unmodifiableSet(
	                new HashSet<>(Arrays.asList(excludedString.split(" ", 0))));
	        } else {
	        	excludedUrls = Collections.<String>emptySet();
	        }
	        
	}
	
	public static boolean isExcluded(HttpServletRequest request) {
        String path = request.getRequestURI();
        
        /*String extension = path.substring(path.indexOf('.', path.lastIndexOf('/')) + 1).toLowerCase();
        return excluded.contains(extension);*/
        
        for (String str : excludedUrls) {
			if (path.contains(str)) {
				return true;
			}
		}

		return false;
    }
	
	public static String getSDFFormattedDate(Date date,String pattern){
		
		String formattedDate = "";
		if(date != null && pattern!= null){
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		 formattedDate = simpleDateFormat.format(date);
		}
		
		return formattedDate;
		
	}
	
	public static String getMonth(String month){
		int monthInInt = Month.valueOf(month.toUpperCase()).getValue();
		if(monthInInt <=9){
			month = "0" + monthInInt;
		}else{
			month = "" + monthInInt;
		}
		return month;
	}
	public static String curentFiscalYear()
	{
	int year = Calendar.getInstance().get(Calendar.YEAR);

    int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
     String financialYear=null;
    if (month < 3) {
    	financialYear=(year - 1) + "-" +String.valueOf(year).substring(2);
        
    } else {
    	financialYear=year + "-" +  String.valueOf((year + 1)).substring(2);
    }
    return financialYear;
	}
	 public static String getMonthName(int intMonth) {
     	
     	String monthName = "";
     	if (intMonth == 1) {
     		monthName = "January";
     	} else if (intMonth == 2) {
     		monthName = "Febuary";
     	} else if (intMonth == 3) {
     		monthName = "March";
     	} else if (intMonth == 4) {
     		monthName = "April";
     	} else if (intMonth == 5) {
     		monthName = "May";
     	} else if (intMonth == 6) {
     		monthName = "June";
     	} else if (intMonth == 7) {
     		monthName = "July";
     	} else if (intMonth == 8) {
     		monthName = "August";
     	} else if (intMonth == 9) {
     		monthName = "September";
     	} else if (intMonth == 10) {
     		monthName = "October";
     	} else if (intMonth == 11) {
     		monthName = "November";
     	} else if (intMonth == 12) {
     		monthName = "December";
     	}
     	return monthName;
     }
	 
	 
	 public static String getJsonFromList(List<QuestionAnswerModule> questionAnswerList){
		 
		 String stringList = null;
		 if(questionAnswerList != null){
			 	stringList = new Gson().toJson(questionAnswerList);
		 }
		 
		 return stringList;
		 
	 }
	 
	 public static LinkedHashMap<String, String> getMonthsOnFinancialYear(String financialYear, String taxPeriod){
		 LinkedHashMap<String,String> map = new LinkedHashMap<String,String>();
		 String[] arr;
		 try{
			if(financialYear.equalsIgnoreCase("2017-18")){				
				arr = new String[]{"07","08","09","10","11","12","01","02","03"};
			}
			else{
				arr = new String[]{"04","05","06","07","08","09","10","11","12","01","02","03"};
			}
			for(int i=0;i<arr.length-1;i++)
			{
				if(arr[i].equalsIgnoreCase(taxPeriod.substring(0,2)))
				{
				    map.put(arr[i], CommonUtility.getMonthName(Integer.parseInt(arr[i])));
			   break;
				}
				else
				{
					map.put(arr[i], CommonUtility.getMonthName(Integer.parseInt(arr[i])));
				}
			}
	 }catch(Exception e){
		 LOGGER.error("Exception in " + CLASS_NAME + " Method : getMonthsOnFinancialYear" + e);
	 }
		 return map;
	 }
	 
	 
}