/**
 * 
 */
package com.ey.advisory.asp.service;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface OnBoardValidationService {
	
	public boolean isValidRoleAccessLevelMap(String accessLevel, long roleId);
	
}
