/**
 * 
 */
package com.ey.advisory.asp.service;

import com.ey.advisory.asp.domain.User;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface UserRoleService {
	
	public User getUserDetails(String username);
	
	public User getUserClientDetails(long userid, String group_id);

}
