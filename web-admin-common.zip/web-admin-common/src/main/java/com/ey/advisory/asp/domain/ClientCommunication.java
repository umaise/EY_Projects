package com.ey.advisory.asp.domain;

public class ClientCommunication {
	
	private Integer gstinUserMappingId;
	private String gstin;
	private String primaryAuthUserName;
	private String secondaryAuthUserName;
	private String primaryContact;
	private String secondaryContact;
	
	private Integer pAuthUserId;
	private Integer sAuthUserId;
	private Integer pContactUserId;
	private Integer sContactUserId;
	
	public Integer getGstinUserMappingId() {
		return gstinUserMappingId;
	}
	public void setGstinUserMappingId(Integer gstinUserMappingId) {
		this.gstinUserMappingId = gstinUserMappingId;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getPrimaryAuthUserName() {
		return primaryAuthUserName;
	}
	public void setPrimaryAuthUserName(String primaryAuthUserName) {
		this.primaryAuthUserName = primaryAuthUserName;
	}
	public String getSecondaryAuthUserName() {
		return secondaryAuthUserName;
	}
	public void setSecondaryAuthUserName(String secondaryAuthUserName) {
		this.secondaryAuthUserName = secondaryAuthUserName;
	}
	public String getPrimaryContact() {
		return primaryContact;
	}
	public void setPrimaryContact(String primaryContact) {
		this.primaryContact = primaryContact;
	}
	public String getSecondaryContact() {
		return secondaryContact;
	}
	public void setSecondaryContact(String secondaryContact) {
		this.secondaryContact = secondaryContact;
	}
	public Integer getpAuthUserId() {
		return pAuthUserId;
	}
	public void setpAuthUserId(Integer pAuthUserId) {
		this.pAuthUserId = pAuthUserId;
	}
	public Integer getsAuthUserId() {
		return sAuthUserId;
	}
	public void setsAuthUserId(Integer sAuthUserId) {
		this.sAuthUserId = sAuthUserId;
	}
	public Integer getpContactUserId() {
		return pContactUserId;
	}
	public void setpContactUserId(Integer pContactUserId) {
		this.pContactUserId = pContactUserId;
	}
	public Integer getsContactUserId() {
		return sContactUserId;
	}
	public void setsContactUserId(Integer sContactUserId) {
		this.sContactUserId = sContactUserId;
	}
	
	@Override
	public String toString() {
		return "ClientCommunication [gstin=" + gstin + ", primaryAuthUserName="
				+ primaryAuthUserName + ", secondaryAuthUserName="
				+ secondaryAuthUserName + ", primaryContact=" + primaryContact
				+ ", secondaryContact=" + secondaryContact + ", pAuthUserId="
				+ pAuthUserId + ", sAuthUserId=" + sAuthUserId
				+ ", pContactUserId=" + pContactUserId + ", sContactUserId="
				+ sContactUserId + "]";
	}
	
	

}
