package com.ey.advisory.asp.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.json.simple.JSONObject;

import com.ey.advisory.asp.dto.DueDateMasterDto;
import com.ey.advisory.asp.dto.FunctionDto;
import com.ey.advisory.asp.dto.GSTINDetailsDto;
import com.ey.advisory.asp.dto.GroupDto;
import com.ey.advisory.asp.dto.RoleDto;
import com.ey.advisory.asp.dto.StatesDto;
import com.ey.advisory.asp.domain.MasterHierarchyConfig;
import com.ey.advisory.asp.domain.ReturnPeriod;

public class User implements Serializable {

	private static final long serialVersionUID = 1L;
	@Digits(fraction = 0, integer = 20)
	private Long userId;

	private String userName;
	@Pattern(regexp = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}")
	private String password;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String prefix;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String firstName;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String middleName;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String lastName;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String gender;
	@Email
	private String emailId;
	@Pattern(regexp = "^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$")
	private String pan;

	private Boolean isActive;

	private Boolean accountExpired;

	private Boolean locked;

	private Boolean forcePasswordChange;
	private Date lastLogin;
	@Digits(fraction = 0, integer = 3)
	private Integer countUnsucessful;
	private Date pwdCreationDate;

	private Boolean pwdExpired;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String createdBy;

	private Date createdDate;
	@Pattern(regexp = "^[.\\p{Alnum}\\p{Space}]{0,1024}$")
	private String lastModifiedBy;
	private Date lastModifieddDate;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String gpnNumber;
	@Pattern(regexp = "^[A-Za-z0-9]*$")
	private String engagementId;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String typeOfUser;
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String gstUserName;
	@Pattern(regexp = "^[0-9]+$")
	private String mobileNo;
	@Pattern(regexp = "^[0-9]*$")
	private String officeNo;

	private Boolean isApproved;
	@Digits(fraction = 0, integer = 20)
	private Long categoryId;

	
	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	private List<UserGSTNRoleMapping> userGSTNRoleMapings;
	@Digits(fraction = 0, integer = 3)
	private Long roleId;

	private List<String> groupEntities = new ArrayList<>();

	private List<Long> userMappingIds = new ArrayList<>();

	public List<Long> getUserMappingIds() {
		return userMappingIds;
	}

	public void setUserMappingIds(List<Long> userMappingIds) {
		this.userMappingIds = userMappingIds;
	}

	private Set<RoleDto> roleSet;

	private Set<FunctionDto> appFuncSet;

	private Set<GroupDto> groupDto;

	private List<StatesDto> statesList;

	private List<DueDateMasterDto> dueDateMasterDtoList;

	private List<GSTINDetailsDto> gstindtoList;

	private ReturnPeriod returnPeriod;

	private JSONObject groupEntityDivInfo;

	private List<UserAccessMapping_dto> userAccMapDTOList;

	private List<EntityHierarchyDto> entityHierarchyDtoList;

	private List<MasterHierarchyConfig> masterHierarchyConfigList;

	private Set<String> authSignGstins;
	
	private String groupId;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
	private String isEyLogin;

	public String isEyLogin() {
		return isEyLogin;
	}

	public void setEyLogin(String isEyLogin) {
		this.isEyLogin = isEyLogin;
	}

	/**
	 * @return the authSignGstins
	 */
	public Set<String> getAuthSignGstins() {
		return authSignGstins;
	}

	/**
	 * @param authSignGstins
	 *            the authSignGstins to set
	 */
	public void setAuthSignGstins(Set<String> authSignGstins) {
		this.authSignGstins = authSignGstins;
	}

	/**
	 * @return the masterHierarchyConfigList
	 */
	public List<MasterHierarchyConfig> getMasterHierarchyConfigList() {
		return masterHierarchyConfigList;
	}

	/**
	 * @param masterHierarchyConfigList
	 *            the masterHierarchyConfigList to set
	 */
	public void setMasterHierarchyConfigList(List<MasterHierarchyConfig> masterHierarchyConfigList) {
		this.masterHierarchyConfigList = masterHierarchyConfigList;
	}

	/**
	 * @return the userAccMapDTOList
	 */
	public List<UserAccessMapping_dto> getUserAccMapDTOList() {
		return userAccMapDTOList;
	}

	/**
	 * @return the entityHierarchyDtoList
	 */
	public List<EntityHierarchyDto> getEntityHierarchyDtoList() {
		return entityHierarchyDtoList;
	}

	/**
	 * @param userAccMapDTOList
	 *            the userAccMapDTOList to set
	 */
	public void setUserAccMapDTOList(List<UserAccessMapping_dto> userAccMapDTOList) {
		this.userAccMapDTOList = userAccMapDTOList;
	}

	/**
	 * @param entityHierarchyDtoList
	 *            the entityHierarchyDtoList to set
	 */
	public void setEntityHierarchyDtoList(List<EntityHierarchyDto> entityHierarchyDtoList) {
		this.entityHierarchyDtoList = entityHierarchyDtoList;
	}

	public JSONObject getGroupEntityDivInfo() {
		return groupEntityDivInfo;
	}

	public void setGroupEntityDivInfo(JSONObject groupEntityDivInfo) {
		this.groupEntityDivInfo = groupEntityDivInfo;
	}

	public Set<RoleDto> getRoleSet() {
		return roleSet;
	}

	public void setRoleSet(Set<RoleDto> roleSet) {
		this.roleSet = roleSet;
	}

	public Set<FunctionDto> getAppFuncSet() {
		return appFuncSet;
	}

	public void setAppFuncSet(Set<FunctionDto> appFuncSet) {
		this.appFuncSet = appFuncSet;
	}

	/**
	 * @return the statesList
	 */
	public List<StatesDto> getStatesList() {
		return statesList;
	}

	/**
	 * @param statesList
	 *            the statesList to set
	 */
	public void setStatesList(List<StatesDto> statesList) {
		this.statesList = statesList;
	}

	/**
	 * @return the dueDateMasterDtoList
	 */
	public List<DueDateMasterDto> getDueDateMasterDtoList() {
		return dueDateMasterDtoList;
	}

	/**
	 * @param dueDateMasterDtoList
	 *            the dueDateMasterDtoList to set
	 */
	public void setDueDateMasterDtoList(List<DueDateMasterDto> dueDateMasterDtoList) {
		this.dueDateMasterDtoList = dueDateMasterDtoList;
	}

	/**
	 * @return the gstindtoList
	 */
	public List<GSTINDetailsDto> getGstindtoList() {
		return gstindtoList;
	}

	/**
	 * @param gstindtoList
	 *            the gstindtoList to set
	 */
	public void setGstindtoList(List<GSTINDetailsDto> gstindtoList) {
		this.gstindtoList = gstindtoList;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean isAccountExpired() {
		return accountExpired;
	}

	/**
	 * @return the groupDto
	 */
	public Set<GroupDto> getGroupDto() {
		return groupDto;
	}

	/**
	 * @param groupDto
	 *            the groupDto to set
	 */
	public void setGroupDto(Set<GroupDto> groupDto) {
		this.groupDto = groupDto;
	}

	public void setAccountExpired(Boolean accountExpired) {
		this.accountExpired = accountExpired;
	}

	public Boolean isLocked() {
		return this.locked;
	}

	public void setLocked(Boolean locked) {
		this.locked = locked;
	}

	public Boolean isForcePasswordChange() {
		return this.forcePasswordChange;
	}

	public void setForcePasswordChange(Boolean forcePasswordChange) {
		this.forcePasswordChange = forcePasswordChange;
	}

	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Integer getCountUnsucessful() {
		return countUnsucessful;
	}

	public void setCountUnsucessful(Integer countUnsucessful) {
		this.countUnsucessful = countUnsucessful;
	}

	public Date getPwdCreationDate() {
		return pwdCreationDate;
	}

	public void setPwdCreationDate(Date pwdCreationDate) {
		this.pwdCreationDate = pwdCreationDate;
	}

	public Boolean isPwdExpired() {
		return pwdExpired;
	}

	public void setPwdExpired(Boolean pwdExpired) {
		this.pwdExpired = pwdExpired;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifieddDate() {
		return lastModifieddDate;
	}

	public void setLastModifieddDate(Date lastModifieddDate) {
		this.lastModifieddDate = lastModifieddDate;
	}

	public String getGpnNumber() {
		return gpnNumber;
	}

	public void setGpnNumber(String gpnNumber) {
		this.gpnNumber = gpnNumber;
	}

	public String getEngagementId() {
		return engagementId;
	}

	public void setEngagementId(String engagementId) {
		this.engagementId = engagementId;
	}

	public String getTypeOfUser() {
		return typeOfUser;
	}

	public void setTypeOfUser(String typeOfUser) {
		this.typeOfUser = typeOfUser;
	}

	public String getGstUserName() {
		return gstUserName;
	}

	public void setGstUserName(String gstUserName) {
		this.gstUserName = gstUserName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getOfficeNo() {
		return officeNo;
	}

	public void setOfficeNo(String officeNo) {
		this.officeNo = officeNo;
	}

	public List<UserGSTNRoleMapping> getUserGSTNRoleMapings() {
		return userGSTNRoleMapings;
	}

	public void setUserGSTNRoleMapings(List<UserGSTNRoleMapping> userGSTNRoleMapings) {
		this.userGSTNRoleMapings = userGSTNRoleMapings;
	}

	public Boolean getAccountExpired() {
		return accountExpired;
	}

	public Boolean getLocked() {
		return locked;
	}

	public Boolean getForcePasswordChange() {
		return forcePasswordChange;
	}

	public Boolean getPwdExpired() {
		return pwdExpired;
	}

	public List<String> getGroupEntities() {
		return groupEntities;
	}

	public void setGroupEntities(List<String> groupEntities) {
		this.groupEntities = groupEntities;
	}

	public User() {
		super();
	}

	public User(long userId, String userName) {
		this.userId = userId;
		this.userName = userName;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public User(Long userId, String userName, Boolean pwdExpired, Boolean accountExpired, Boolean locked,
			Boolean forcePasswordChange, Integer countUnsucessful) {
		super();
		this.userId = userId;
		this.userId = userId;
		this.userName = userName;
		this.pwdExpired = pwdExpired;
		this.accountExpired = accountExpired;
		this.locked = locked;
		this.forcePasswordChange = forcePasswordChange;
		this.countUnsucessful = countUnsucessful;
	}

	@Override
	public int hashCode() {
		int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof User)) {
			return false;
		}
		User other = (User) obj;
		if (userId == null) {
			if (other.userId != null) {
				return false;
			}
		} else if (!userId.equals(other.userId)) {
			return false;
		}
		return true;
	}


	

	/**
	 * @return the returnPeriod
	 */
	public ReturnPeriod getReturnPeriod() {
		return returnPeriod;
	}

	/**
	 * @param returnPeriod
	 *            the returnPeriod to set
	 */
	public void setReturnPeriod(ReturnPeriod returnPeriod) {
		this.returnPeriod = returnPeriod;
	}

}
