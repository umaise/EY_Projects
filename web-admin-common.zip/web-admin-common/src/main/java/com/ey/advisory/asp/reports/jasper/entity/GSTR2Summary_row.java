package com.ey.advisory.asp.reports.jasper.entity;

public class GSTR2Summary_row {

	Double taxableValue;
	Double igst;
	Double cgst;
	Double sgst;
	Double cess;
	Double itcigst;
	Double itccgst;
	Double itcsgst;
	Double itccess;
	Double taxPayable;
	Double nilComp;
	Double nilRated;
	Double nilExempt;
	Double nilNonGst;
	
	public Double getTaxableValue() {
		return taxableValue;
	}
	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}
	public Double getIgst() {
		return igst;
	}
	public void setIgst(Double igst) {
		this.igst = igst;
	}
	public Double getCgst() {
		return cgst;
	}
	public void setCgst(Double cgst) {
		this.cgst = cgst;
	}
	public Double getSgst() {
		return sgst;
	}
	public void setSgst(Double sgst) {
		this.sgst = sgst;
	}
	public Double getCess() {
		return cess;
	}
	public void setCess(Double cess) {
		this.cess = cess;
	}
	public Double getItcigst() {
		return itcigst;
	}
	public void setItcigst(Double itcigst) {
		this.itcigst = itcigst;
	}
	public Double getItccgst() {
		return itccgst;
	}
	public void setItccgst(Double itccgst) {
		this.itccgst = itccgst;
	}
	public Double getItcsgst() {
		return itcsgst;
	}
	public void setItcsgst(Double itcsgst) {
		this.itcsgst = itcsgst;
	}
	public Double getItccess() {
		return itccess;
	}
	public void setItccess(Double itccess) {
		this.itccess = itccess;
	}
	public Double getTaxPayable() {
		return taxPayable;
	}
	public void setTaxPayable(Double taxPayable) {
		this.taxPayable = taxPayable;
	}
	public Double getNilComp() {
		return nilComp;
	}
	public void setNilComp(Double nilComp) {
		this.nilComp = nilComp;
	}
	public Double getNilRated() {
		return nilRated;
	}
	public void setNilRated(Double nilRated) {
		this.nilRated = nilRated;
	}
	public Double getNilExempt() {
		return nilExempt;
	}
	public void setNilExempt(Double nilExempt) {
		this.nilExempt = nilExempt;
	}
	public Double getNilNonGst() {
		return nilNonGst;
	}
	public void setNilNonGst(Double nilNonGst) {
		this.nilNonGst = nilNonGst;
	}
	
}
