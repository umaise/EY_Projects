package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.ey.advisory.asp.client.util.CommonUtillity;

@Entity
@Table(name = "tblPurchasePreStaging", schema = "etl")
@NamedQuery(name = "TblPurchasePreStaging.findAll", query = "SELECT t FROM TblPurchasePreStaging t")
public class TblPurchasePreStaging implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "Id")
	private int id;
	
	@Column(name = "FileID")
	private Long fileID;
	
	@Column(name = "SourceIdentifier")
	private String sourceIdentifier;
	
	@Column(name = "SourceFileName")
	private String sourceFileName;
	
	@Column(name = "GLAccountCode")
	private String gLAccountCode;
	
	@Column(name = "Division")
	private String division;
	
	@Column(name = "SubDivision")
	private String subDivision;
	
	@Column(name = "ProfitCentre1")
	private String profitCentre1;

	@Column(name = "ProfitCentre2")
	private String profitCentre2;
	
	@Column(name = "PlantCode")
	private String plantCode;
	
	@Column(name = "TaxPeriod")
	private String taxPeriod;
	
	@Column(name = "CGSTIN")
	private String cgstin;
	
	@Column(name = "DocumentType")
	private String documentType;
	
	@Column(name = "SupplyType")
	private String supplyType;
	
	@Column(name = "DocumentNo")
	private String documentNo;

	@Column(name = "DocumentDate")
	private String documentDate;
	
	@Column(name = "OriginalDocumentNo")
	private String originalDocumentNo;

	@Column(name = "OriginalDocumentDate")
	private String originalDocumentDate;

	@Column(name = "CRDRPreGST")
	private String cRDRPreGST;
	
	@Column(name = "LineNumber")
	private String lineNumber;
	
	@Column(name = "SGSTIN")
	private String sGSTIN;
	
	@Column(name = "OriginalSGSTIN")
	private String originalSGSTIN;
	
	@Column(name = "SupplierName")
	private String supplierName;
	
	@Column(name = "SupplierCode")
	private String supplierCode;
	
	@Column(name = "POS")
	private String pos;
	
	@Column(name = "PortCode")
	private String portCode;

	@Column(name = "BillOfEntry")
	private String billOfEntry;
	
	@Column(name = "BillOfEntryDate")
	private String billOfEntryDate;
	
	@Column(name = "CIFValue")
	private String cIFValue;
	
	@Column(name = "CustomDuty")
	private String customDuty;
	
	
	@Column(name = "HSNorSAC")
	private String hSNorSAC;
	
	@Column(name = "ItemCode")
	private String itemCode;

	@Column(name = "ItemDescription")
	private String itemDescription;

	@Column(name = "ItemCategory")
	private String itemCategory;
	
	@Column(name = "UnitofMeasurement")
	private String unitofMeasurement;
	
	@Column(name = "Quantity")
	private String quantity;
	
	@Column(name = "TaxableValue")
	private String taxableValue;
	
	@Column(name = "IGSTRate")
	private String iGSTRate;
	
	@Column(name = "IGSTAmount")
	private String iGSTAmount;

	@Column(name = "CGSTRate")
	private String cGSTRate;
	
	@Column(name = "CGSTAmount")
	private String cGSTAmount;
	
	@Column(name = "SGSTRate")
	private String sGSTRate;
	
	@Column(name = "SGSTAmount")
	private String sGSTAmount;
	
	@Column(name = "CessRateAdvalorem")
	private String cessRateAdvalorem;
	
	@Column(name = "CessAmountAdvalorem")
	private String cessAmountAdvalorem;
	
	@Column(name = "CessRateSpecific")
	private String cessRateSpecific;

	@Column(name = "CessAmountSpecific")
	private String cessAmountSpecific;
	
	@Column(name = "InvoiceValue")
	private String invoiceValue;
	
	@Column(name = "ReverseCharge")
	private String reverseCharge;
	
	@Column(name = "EligibilityIndicator")
	private String eligibilityIndicator;
	
	@Column(name = "CommonSupplyIndicator")
	private String commonSupplyIndicator;
	
	@Column(name = "AvailableIGST")
	private String availableIGST;
	
	@Column(name = "AvailableCGST")
	private String availableCGST;
	
	@Column(name = "AvailableSGST")
	private String availableSGST;
	
	@Column(name = "AvailableCESS")
	private String availableCESS;
	
	@Column(name = "ITCReversalIdentifier")
	private String iTCReversalIdentifier;
	
	@Column(name = "ReasonForCreditDebitNote")
	private String reasonForCreditDebitNote;
	
	@Column(name = "PurchaseVoucherNumber")
	private String purchaseVoucherNumber;
	
	@Column(name = "PurchaseVoucherDate")
	private String purchaseVoucherDate;
	
	@Column(name = "PaymentVoucherNumber")
	private String paymentVoucherNumber;
	
	@Column(name = "DateofPayment")
	private String dateofPayment;
	
	@Column(name = "ContractNumber")
	private String contractNumber;
	
	@Column(name = "Contractdate")
	private String contractdate;
	
	@Column(name = "ContractValue")
	private String contractValue;
	
	@Column(name = "Userdefinedfield1")
	private String userdefinedfield1;

	@Column(name = "Userdefinedfield2")
	private String userdefinedfield2;

	@Column(name = "Userdefinedfield3")
	private String userdefinedfield3;
	
	@Column(name = "IsError")
	private String isError;
	
	@Column(name = "DupRnk")
	private Long dupRnk;

	@Column(name = "ErrorMsg")
	private String errorMsg;
	
	@Column(name = "InvoiceKey")
	private String invoiceKey;
	
	@Column(name = "ChkSum")
	private String chkSum;

	@Column(name = "DuplicateStatus")
	private String duplicateStatus;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Long getFileID() {
		return fileID;
	}

	public void setFileID(Long fileID) {
		this.fileID = fileID;
	}

	public String getSourceIdentifier() {
		return sourceIdentifier;
	}

	public void setSourceIdentifier(String sourceIdentifier) {
		this.sourceIdentifier = sourceIdentifier;
	}

	public String getSourceFileName() {
		return sourceFileName;
	}

	public void setSourceFileName(String sourceFileName) {
		this.sourceFileName = sourceFileName;
	}

	public String getgLAccountCode() {
		return gLAccountCode;
	}

	public void setgLAccountCode(String gLAccountCode) {
		this.gLAccountCode = gLAccountCode;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getSubDivision() {
		return subDivision;
	}

	public void setSubDivision(String subDivision) {
		this.subDivision = subDivision;
	}

	public String getProfitCentre1() {
		return profitCentre1;
	}

	public void setProfitCentre1(String profitCentre1) {
		this.profitCentre1 = profitCentre1;
	}

	public String getProfitCentre2() {
		return profitCentre2;
	}

	public void setProfitCentre2(String profitCentre2) {
		this.profitCentre2 = profitCentre2;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getCgstin() {
		return cgstin;
	}

	public void setCgstin(String cgstin) {
		this.cgstin = cgstin;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getSupplyType() {
		return supplyType;
	}

	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}

	public String getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public String getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(String documentDate) {
		this.documentDate = documentDate;
	}

	public String getOriginalDocumentNo() {
		return originalDocumentNo;
	}

	public void setOriginalDocumentNo(String originalDocumentNo) {
		this.originalDocumentNo = originalDocumentNo;
	}

	public String getOriginalDocumentDate() {
		return originalDocumentDate;
	}

	public void setOriginalDocumentDate(String originalDocumentDate) {
		this.originalDocumentDate = originalDocumentDate;
	}

	public String getcRDRPreGST() {
		return cRDRPreGST;
	}

	public void setcRDRPreGST(String cRDRPreGST) {
		this.cRDRPreGST = cRDRPreGST;
	}

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getsGSTIN() {
		return sGSTIN;
	}

	public void setsGSTIN(String sGSTIN) {
		this.sGSTIN = sGSTIN;
	}

	public String getOriginalSGSTIN() {
		return originalSGSTIN;
	}

	public void setOriginalSGSTIN(String originalSGSTIN) {
		this.originalSGSTIN = originalSGSTIN;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getPortCode() {
		return portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getBillOfEntry() {
		return billOfEntry;
	}

	public void setBillOfEntry(String billOfEntry) {
		this.billOfEntry = billOfEntry;
	}

	public String getBillOfEntryDate() {
		return billOfEntryDate;
	}

	public void setBillOfEntryDate(String billOfEntryDate) {
		this.billOfEntryDate = billOfEntryDate;
	}

	public String getcIFValue() {
		return cIFValue;
	}

	public void setcIFValue(String cIFValue) {
		this.cIFValue = cIFValue;
	}

	public String getCustomDuty() {
		return customDuty;
	}

	public void setCustomDuty(String customDuty) {
		this.customDuty = customDuty;
	}

	public String gethSNorSAC() {
		return hSNorSAC;
	}

	public void sethSNorSAC(String hSNorSAC) {
		this.hSNorSAC = hSNorSAC;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getItemCategory() {
		return itemCategory;
	}

	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}

	public String getUnitofMeasurement() {
		return unitofMeasurement;
	}

	public void setUnitofMeasurement(String unitofMeasurement) {
		this.unitofMeasurement = unitofMeasurement;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(String taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getiGSTRate() {
		return iGSTRate;
	}

	public void setiGSTRate(String iGSTRate) {
		this.iGSTRate = iGSTRate;
	}

	public String getiGSTAmount() {
		return iGSTAmount;
	}

	public void setiGSTAmount(String iGSTAmount) {
		this.iGSTAmount = iGSTAmount;
	}

	public String getcGSTRate() {
		return cGSTRate;
	}

	public void setcGSTRate(String cGSTRate) {
		this.cGSTRate = cGSTRate;
	}

	public String getcGSTAmount() {
		return cGSTAmount;
	}

	public void setcGSTAmount(String cGSTAmount) {
		this.cGSTAmount = cGSTAmount;
	}

	public String getsGSTRate() {
		return sGSTRate;
	}

	public void setsGSTRate(String sGSTRate) {
		this.sGSTRate = sGSTRate;
	}

	public String getsGSTAmount() {
		return sGSTAmount;
	}

	public void setsGSTAmount(String sGSTAmount) {
		this.sGSTAmount = sGSTAmount;
	}

	public String getCessRateAdvalorem() {
		return cessRateAdvalorem;
	}

	public void setCessRateAdvalorem(String cessRateAdvalorem) {
		this.cessRateAdvalorem = cessRateAdvalorem;
	}

	public String getCessAmountAdvalorem() {
		return cessAmountAdvalorem;
	}

	public void setCessAmountAdvalorem(String cessAmountAdvalorem) {
		this.cessAmountAdvalorem = cessAmountAdvalorem;
	}

	public String getCessRateSpecific() {
		return cessRateSpecific;
	}

	public void setCessRateSpecific(String cessRateSpecific) {
		this.cessRateSpecific = cessRateSpecific;
	}

	public String getCessAmountSpecific() {
		return cessAmountSpecific;
	}

	public void setCessAmountSpecific(String cessAmountSpecific) {
		this.cessAmountSpecific = cessAmountSpecific;
	}

	public String getInvoiceValue() {
		return invoiceValue;
	}

	public void setInvoiceValue(String invoiceValue) {
		this.invoiceValue = invoiceValue;
	}

	public String getReverseCharge() {
		return reverseCharge;
	}

	public void setReverseCharge(String reverseCharge) {
		this.reverseCharge = reverseCharge;
	}

	public String getEligibilityIndicator() {
		return eligibilityIndicator;
	}

	public void setEligibilityIndicator(String eligibilityIndicator) {
		this.eligibilityIndicator = eligibilityIndicator;
	}

	public String getCommonSupplyIndicator() {
		return commonSupplyIndicator;
	}

	public void setCommonSupplyIndicator(String commonSupplyIndicator) {
		this.commonSupplyIndicator = commonSupplyIndicator;
	}

	public String getAvailableIGST() {
		return availableIGST;
	}

	public void setAvailableIGST(String availableIGST) {
		this.availableIGST = availableIGST;
	}

	public String getAvailableCGST() {
		return availableCGST;
	}

	public void setAvailableCGST(String availableCGST) {
		this.availableCGST = availableCGST;
	}

	public String getAvailableSGST() {
		return availableSGST;
	}

	public void setAvailableSGST(String availableSGST) {
		this.availableSGST = availableSGST;
	}

	public String getAvailableCESS() {
		return availableCESS;
	}

	public void setAvailableCESS(String availableCESS) {
		this.availableCESS = availableCESS;
	}

	public String getiTCReversalIdentifier() {
		return iTCReversalIdentifier;
	}

	public void setiTCReversalIdentifier(String iTCReversalIdentifier) {
		this.iTCReversalIdentifier = iTCReversalIdentifier;
	}

	public String getReasonForCreditDebitNote() {
		return reasonForCreditDebitNote;
	}

	public void setReasonForCreditDebitNote(String reasonForCreditDebitNote) {
		this.reasonForCreditDebitNote = reasonForCreditDebitNote;
	}

	public String getPurchaseVoucherNumber() {
		return purchaseVoucherNumber;
	}

	public void setPurchaseVoucherNumber(String purchaseVoucherNumber) {
		this.purchaseVoucherNumber = purchaseVoucherNumber;
	}

	public String getPurchaseVoucherDate() {
		return purchaseVoucherDate;
	}

	public void setPurchaseVoucherDate(String purchaseVoucherDate) {
		this.purchaseVoucherDate = purchaseVoucherDate;
	}

	public String getPaymentVoucherNumber() {
		return paymentVoucherNumber;
	}

	public void setPaymentVoucherNumber(String paymentVoucherNumber) {
		this.paymentVoucherNumber = paymentVoucherNumber;
	}

	public String getDateofPayment() {
		return dateofPayment;
	}

	public void setDateofPayment(String dateofPayment) {
		this.dateofPayment = dateofPayment;
	}

	public String getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	public String getContractdate() {
		return contractdate;
	}

	public void setContractdate(String contractdate) {
		this.contractdate = contractdate;
	}

	public String getContractValue() {
		return contractValue;
	}

	public void setContractValue(String contractValue) {
		this.contractValue = contractValue;
	}

	public String getUserdefinedfield1() {
		return userdefinedfield1;
	}

	public void setUserdefinedfield1(String userdefinedfield1) {
		this.userdefinedfield1 = userdefinedfield1;
	}

	public String getUserdefinedfield2() {
		return userdefinedfield2;
	}

	public void setUserdefinedfield2(String userdefinedfield2) {
		this.userdefinedfield2 = userdefinedfield2;
	}

	public String getUserdefinedfield3() {
		return userdefinedfield3;
	}

	public void setUserdefinedfield3(String userdefinedfield3) {
		this.userdefinedfield3 = userdefinedfield3;
	}

	public String getIsError() {
		return isError;
	}

	public void setIsError(String isError) {
		this.isError = isError;
	}

	public Long getDupRnk() {
		return dupRnk;
	}

	public void setDupRnk(Long dupRnk) {
		this.dupRnk = dupRnk;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public String getChkSum() {
		return chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getDuplicateStatus() {
		return duplicateStatus;
	}

	public void setDuplicateStatus(String duplicateStatus) {
		this.duplicateStatus = duplicateStatus;
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TblPurchasePreStaging other = (TblPurchasePreStaging) obj;
		if (id != other.id)
			return false;
		return true;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public String toString() {
		return (sourceIdentifier != null ? CommonUtillity.formatCommasWithSpaces(sourceIdentifier) : "") + "," + (sourceFileName != null ? CommonUtillity.formatCommasWithSpaces(sourceFileName) : "") + ","
				+ (gLAccountCode != null ? gLAccountCode : "") + "," + (division != null ? CommonUtillity.formatCommasWithSpaces(division) : "") + ","
				+ (subDivision != null ? CommonUtillity.formatCommasWithSpaces(subDivision) : "") + "," + (profitCentre1 != null ? profitCentre1 : "") + ","
				+ (profitCentre2 != null ? profitCentre2 : "") + "," + (plantCode != null ? plantCode : "") + "," 
				+ (taxPeriod != null ? taxPeriod : "") + "," + (cgstin != null ? cgstin : "") + ","
				+ (documentType != null ? documentType : "") + "," + (supplyType != null ? supplyType : "") + ","
				+ (documentNo != null ? documentNo : "") + "," + (documentDate != null ? documentDate : "") + ","
				+ (originalDocumentNo != null ? originalDocumentNo : "") + "," + (originalDocumentDate != null ? originalDocumentDate : "") + ","
				+ (cRDRPreGST != null ? cRDRPreGST : "") + "," + (lineNumber != null ? lineNumber : "") + "," 
				+ (sGSTIN != null ? sGSTIN : "") + "," + (originalSGSTIN != null ? originalSGSTIN : "") + "," 
				+ (supplierName != null ? supplierName : "") + "," + (supplierCode != null ? supplierCode : "") + ","
				+ (pos != null ? pos : "") + "," + (portCode != null ? portCode : "") + ","  
				+ (billOfEntry != null ? billOfEntry : "") + "," + (billOfEntryDate != null ? billOfEntryDate : "") + ","
				+ (cIFValue != null ? cIFValue : "") + "," + (customDuty != null ? customDuty : "") + ","
				+ (hSNorSAC != null ? hSNorSAC : "") + ","	+ (itemCode != null ? CommonUtillity.formatCommasWithSpaces(itemCode) : "") + "," 
				+ (itemDescription != null ? CommonUtillity.formatCommasWithSpaces(itemDescription) : "") + "," + (itemCategory != null ? CommonUtillity.formatCommasWithSpaces(itemCategory) : "") + "," 
				+ (unitofMeasurement != null ? unitofMeasurement : "") + ","+ (quantity != null ? quantity : "") + "," 
				+ (taxableValue != null ? taxableValue : "") + "," + (iGSTRate != null ? iGSTRate : "") + "," 
				+ (iGSTAmount != null ? iGSTAmount : "") + "," + (cGSTRate != null ? cGSTRate : "") + "," 
				+ (cGSTAmount != null ? cGSTAmount : "") + "," + (sGSTRate != null ? sGSTRate : "") + ","
				+ (sGSTAmount != null ? sGSTAmount : "") + "," + (cessRateAdvalorem != null ? cessRateAdvalorem : "") + "," 
				+ (cessAmountAdvalorem != null ? cessAmountAdvalorem : "") + "," + (cessRateSpecific != null ? cessRateSpecific : "") + "," 
				+ (cessAmountSpecific != null ? cessAmountSpecific : "") + "," + (invoiceValue != null ? invoiceValue : "") + "," 
				+ (reverseCharge != null ? reverseCharge : "") + "," + (eligibilityIndicator != null ? eligibilityIndicator : "") + "," 
				+ (commonSupplyIndicator != null ? commonSupplyIndicator : "") + "," + (availableIGST != null ? availableIGST : "") + "," 
				+ (availableCGST != null ? availableCGST : "") + "," + (availableSGST != null ? availableSGST : "") + "," 
				+ (availableCESS != null ? availableCESS : "") + "," + (iTCReversalIdentifier != null ? iTCReversalIdentifier : "") + ","
				+ (reasonForCreditDebitNote != null ? CommonUtillity.formatCommasWithSpaces(reasonForCreditDebitNote) : "") + "," + (purchaseVoucherNumber != null ? purchaseVoucherNumber : "") + ","
				+ (purchaseVoucherDate != null ? purchaseVoucherDate : "") + ","+ (paymentVoucherNumber != null ? paymentVoucherNumber : "") + "," 
				+ (dateofPayment != null ? dateofPayment : "") + "," + (contractNumber != null ? contractNumber : "") + "," 
				+ (contractdate != null ? contractdate : "") + "," + (contractValue != null ? contractValue : "") + "," 
				+ (userdefinedfield1 != null ? userdefinedfield1 : "") + "," + (userdefinedfield2 != null ? userdefinedfield2 : "") + "," 
				+ (userdefinedfield3 != null ? userdefinedfield3 : "");
	}
	
	
	
	/*@Override
	public String toString() {
		return sourceIdentifier + "," + sourceFileName + "," + gLAccountCode + "," + division + "," + subDivision
				+ "," + profitCentre1 + "," + profitCentre2 + "," + plantCode + "," + taxPeriod + "," + cgstin
				+ "," + documentType + "," + supplyType + "," + documentNo + "," + documentDate + ","
				+ originalDocumentNo + "," + originalDocumentDate + "," + cRDRPreGST + "," + lineNumber + ","
				+ sGSTIN + "," + originalSGSTIN + "," + supplierName + "," + supplierCode + "," + pos + ","
				+ portCode + "," + billOfEntry + "," + billOfEntryDate + "," + cIFValue + "," + customDuty + ","
				+ hSNorSAC + "," + itemCode + "," + itemDescription + "," + itemCategory + "," + unitofMeasurement
				+ "," + quantity + "," + taxableValue + "," + iGSTRate + "," + iGSTAmount + "," + cGSTRate + ","
				+ cGSTAmount + "," + sGSTRate + "," + sGSTAmount + "," + cessRateAdvalorem + ","
				+ cessAmountAdvalorem + "," + cessRateSpecific + "," + cessAmountSpecific + "," + invoiceValue + ","
				+ reverseCharge + "," + eligibilityIndicator + "," + commonSupplyIndicator + "," + availableIGST
				+ "," + availableCGST + "," + availableSGST + "," + availableCESS + "," + iTCReversalIdentifier
				+ "," + reasonForCreditDebitNote + "," + purchaseVoucherNumber + "," + purchaseVoucherDate + ","
				+ paymentVoucherNumber + "," + dateofPayment + "," + contractNumber + "," + contractdate + ","
				+ contractValue + "," + userdefinedfield1 + "," + userdefinedfield2 + "," + userdefinedfield3;
	}*/

	
	
	

	

	

	

}
