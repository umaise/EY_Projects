package com.ey.advisory.asp.client.service;

import org.json.simple.JSONObject;

public interface ResetChunksService {

	String resetChunks(JSONObject jsonObject);

}
