package com.ey.advisory.asp.client.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the tblB2CLEAInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2BCLEAInvoiceDetails", schema="gstr1")
public class GSTR1B2CLEA_InvoiceDetails {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) 
	@Column(name="ID")
	private int id;
	
	@Column(name="OrgCustGSTIN")
	private String orgCustGSTIN;
	
	@Column(name="Flag")
	private String flag;
	
	@Column(name="Chksum")
	private String chksum;
	
	@Column(name="OrgInvNum")
	private String orgInvNum;
	
	@Column(name="OrgInvDate")
	private Date orgInvDate;
	
	@Column(name="CustGSTIN")
	private String custGSTIN;
	
	@Column(name="InvNum")
	private String invNum;
	
	@Column(name="InvDate")
	private Date invDate;
	
	@Column(name="ExpBillNo")
	private String expBillNo;
	
	@Column(name="ExpBillDate")
	private Date expBillDate;
	
	@Column(name="InvValue")
	private BigDecimal invValue;
	
	@Column(name="Taxablevalue")
	private BigDecimal taxableValue;
	
	@Column(name="POS")
	private String pos;
	
	@Column(name="Etin")
	private String etin;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="FileID")
	private long fileID;
	
	@Column(name="Category")
	private String category;
	
	@Column(name="SubCategory")
	private String subCategory;
	
	@Column(name="IsDelete")
	private boolean isDelete;
	
	@Column(name="InvoiceKey")
	private String invoiceKey;
	
	@Column(name="OrgTaxableValue")
	private BigDecimal orgTaxableValue;
	
	@Column(name="SupplyType")
	private String supplyType;
	
	@Column(name="DocumentType")
	private String documentType;
	
	@Column(name="revChrg")
	private String RevChrg;
	
	@Column(name="CreatedDt")
	private Date createdDt;
	
	@Column(name="CreatedBy")
	private String createdBy;
	
	@Column(name="UpdatedDt")
	private Date updatedDt;
	
	@Column(name="UpdatedBy")
	private String updatedBy;
	
	@Column(name="PortCode")
	private String portCode;
	
	@Column(name="invType")
	private String InvType;
	
	@Column(name="ReasonCrDr")
	private String reasonCrDr;

	public int getID() {
		return this.id;
	}

	public void setID(int iD) {
		this.id = iD;
	}

	public String getOrgCustGSTIN() {
		return orgCustGSTIN;
	}

	public void setOrgCustGSTIN(String orgCustGSTIN) {
		this.orgCustGSTIN = orgCustGSTIN;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getChksum() {
		return chksum;
	}

	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	public String getOrgInvNum() {
		return orgInvNum;
	}

	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	public Date getOrgInvDate() {
		return orgInvDate;
	}

	public void setOrgInvDate(Date orgInvDate) {
		this.orgInvDate = orgInvDate;
	}

	public String getCustGSTIN() {
		return custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getInvNum() {
		return invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public Date getInvDate() {
		return invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getExpBillNo() {
		return expBillNo;
	}

	public void setExpBillNo(String expBillNo) {
		this.expBillNo = expBillNo;
	}

	public Date getExpBillDate() {
		return expBillDate;
	}

	public void setExpBillDate(Date expBillDate) {
		this.expBillDate = expBillDate;
	}

	public BigDecimal getInvValue() {
		return invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public BigDecimal getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(BigDecimal taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getEtin() {
		return etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public long getFileID() {
		return fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public boolean isDelete() {
		return isDelete;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public BigDecimal getOrgTaxableValue() {
		return orgTaxableValue;
	}

	public void setOrgTaxableValue(BigDecimal orgTaxableValue) {
		this.orgTaxableValue = orgTaxableValue;
	}

	public String getSupplyType() {
		return supplyType;
	}

	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getRevChrg() {
		return RevChrg;
	}

	public void setRevChrg(String revChrg) {
		RevChrg = revChrg;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getPortCode() {
		return portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getInvType() {
		return InvType;
	}

	public void setInvType(String invType) {
		InvType = invType;
	}

	public String getReasonCrDr() {
		return reasonCrDr;
	}

	public void setReasonCrDr(String reasonCrDr) {
		this.reasonCrDr = reasonCrDr;
	}

}
