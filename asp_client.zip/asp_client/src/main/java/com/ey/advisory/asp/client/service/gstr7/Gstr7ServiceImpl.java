package com.ey.advisory.asp.client.service.gstr7;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GSTR7Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.InvoiceDao;
import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.client.dto.AuthDetailsDto;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.client.util.AuthenticationUtility;
import com.ey.advisory.asp.client.util.GSTNRestClientUtility;
import com.ey.advisory.asp.client.util.GSTNRestUtility;
import com.ey.advisory.asp.client.util.StubUtility;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.InvoiceProcessDto;

@Service
@PropertySource("classpath:GSTNConfig.properties") 
public class Gstr7ServiceImpl implements Gstr7Service{

	@Autowired
    HibernateDao hibernateDao;
	
	 @Autowired
	 private InvoiceDao invoiceDao;

    @Autowired
    AuthenticationUtility authenticationUtility;

    @Autowired(required = false)
    private RedisTemplate<String, Object> redisTemplate;
    
    @Autowired
	private Environment env;
    
    @Autowired
    StubUtility stubUtility;
    
    @Autowired
    GSTNRestClientUtility gstnRestClientUtility;
    
    @Autowired
    private ReturnFilingDao returnFilingDao;
    
    @Autowired(required=false)
    private GSTR7Dao gstr7Dao;
    
    @Autowired
    GSTNRestUtility gstnrestutility;
    
    
    
    private JSONObject jsonObject;
	JSONParser jsonParser = new JSONParser();
    HttpHeaders httpHeaders = new HttpHeaders();

    private static final Logger logger = Logger .getLogger(Gstr7ServiceImpl.class);
    private static final String CLASS_NAME = Gstr7ServiceImpl.class.getName();
    
	@Override
	public String getGSTR7SummaryfromStub(String gstn, String taxPeriod) {
		  logger.info("Entering " + CLASS_NAME + " Method : getGSTR7SummaryfromStub");
		  String finalJsonData = getResultFromAPI(gstn, taxPeriod);
		  if ( null == finalJsonData) {
			  
			  int currTaxPeriod = Integer.parseInt(taxPeriod.substring(0, 2))-1;
			  StringBuilder taxstr = new StringBuilder();
			  if(currTaxPeriod <10){
					taxstr.append("0");
			  }
			  taxstr.append(String.valueOf(currTaxPeriod));
			  taxstr.append(taxPeriod.substring(2, taxPeriod.length()));
			  finalJsonData = getResultFromAPI(gstn, taxstr.toString());
			 
		  }
		return finalJsonData;
	}

	@Override
	public TblGstinRetutnFilingStatus getGStrReturnFilingDetails(String gstinId, String taxPeriod, String gstrType) {
		// TODO Auto-generated method stub
		return returnFilingDao.fetchGstrReturnDetails(gstinId, taxPeriod,gstrType);
	}

	@Override
	public TblGstinRetutnFilingStatus getGstr7ReturnFilingDetails(String gstinId, String taxPeriod, String gstrType) {
		// TODO Auto-generated method stub
		return returnFilingDao.gstr7FilingReturnDetails(gstinId, taxPeriod, gstrType);
	}

	@Override
	public String getReturnFilingSuccess(String gstinId, String taxPeriod) {
		// TODO Auto-generated method stub
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+" getReturnFilingSuccess");
   	 	String isFilingAllowed = returnFilingDao.getReturnFilingSuccess(gstinId, Constant.GSTR_7, taxPeriod);
   	 	logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getReturnFilingSuccess");
   	 	return isFilingAllowed;
	}
	
	private String getResultFromAPI(String gstn, String taxPeriod ){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+" getResultFromAPI");
		  String finalJsonData=null;
		  String result=null;
		  try{
			  StringBuilder uri = new StringBuilder("?action=" + Constant.RETSUM + "&ret_period=" + taxPeriod + "&gstin=" +gstn + "&action_required=" + "Y");
			  String resource = env.getProperty("restapi.host-stub") + env.getProperty("restapi.gstr7return")+ uri.toString();
			  logger.info("Calling RETSUM API:" + resource);
			  result = gstnRestClientUtility.executeRestCallTest(resource, httpHeaders, HttpMethod.GET);
			  jsonObject = (JSONObject) jsonParser.parse(result);
			  logger.info("Before Starting stubs" + jsonObject);
			  if (jsonObject.containsKey(Constant.REK) && jsonObject.containsKey(Constant.DATA) && jsonObject.containsKey(Constant.STATUS_CD)) {
				  logger.error("Starting stubs");
				  String rek = (String) jsonObject.get(Constant.REK);
				  String data= (String) jsonObject.get(Constant.DATA);
				  String status_cd = (String) jsonObject.get(Constant.STATUS_CD);
				  if ("1".equals(status_cd)) {
					  String apiKey = authenticationUtility.getBusinessTypeDetailsFromGSTN(rek,Constant.SESSION_KEY.getBytes());
					 finalJsonData = authenticationUtility.getBusinessTypeDetailsFromGSTN(data,apiKey.getBytes());
				  } 
			  }
		  }catch (Exception e) {
				logger.error("Failed due to Reason",e);
		  } 	
		  logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getResultFromAPI");
		  return finalJsonData;
	}

	@Override
	public boolean getDupInvoice(InwardInvoiceModel inwardInvoiceModel){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+" getDupInvoice");
		List<InwardInvoiceModel> inv = gstr7Dao.getDupInvoice(Constant.ENTITY_INWARD_MODEL, inwardInvoiceModel.getSGSTIN(), inwardInvoiceModel.getContractNumber(), inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getDocumentDate());
		if(inv.size()>1)
			return false;
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getDupInvoice");
		return true;
	}
	
	@Override
	public boolean getTaxableVal(InwardInvoiceModel inwardInvoiceModel) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+" getTaxableVal");
		List<InwardInvoiceModel> inv = gstr7Dao.getTaxableVal(Constant.ENTITY_INWARD_MODEL,inwardInvoiceModel.getSGSTIN(), inwardInvoiceModel.getContractNumber(), inwardInvoiceModel.getContractdate());
		BigDecimal totalTaxVal = new BigDecimal(0);
		for(InwardInvoiceModel invoice: inv){
			totalTaxVal = totalTaxVal.add(invoice.getTaxableValue());
		}
		if(totalTaxVal.compareTo(inwardInvoiceModel.getContractValue()) <= 0)
			return false;
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getTaxableVal");
		return true;
	}

	@Override
	public boolean saveGstr7InvoiceStatus(Set<InvoiceProcessDto> invoice,
			Integer fileId) {
		 return invoiceDao.saveGstr7InvoiceStatus(invoice,fileId);
	}

	@Override
	public boolean saveTdsErrorInfo(Set<TblTdsErrorInfo> errorInfo) {
		 return saveMailStatusDetailsInfo(errorInfo) && invoiceDao.saveTdsErrorInfo(errorInfo);
	}
	        private boolean saveMailStatusDetailsInfo(Set<TblTdsErrorInfo> errorList) {

	               Set<String> gstinList = new HashSet<>();
	               for (TblTdsErrorInfo tblIsdErrorInfo : errorList) {
	                   gstinList.add(tblIsdErrorInfo.getGstin());
	               }
	               return invoiceDao.saveMailStatusDetailsInfo(gstinList, Constant.MAILSTATUS_RETURNTYPE_GSTR6);
	         }
	        
	  
	        @Override
	        public String fileGSTR7(SummaryDto summarydto) {
	            logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
	                + " Method : fileGSTR7");
	            String acknowledge = "";
	            try {

	                AuthDetailsDto authDetails = authenticationUtility
	                    .validateAuthToken("");
	                SummaryDto finalDto = authenticationUtility.encryptPayloadData(
	                    summarydto, authDetails);
	                String jsonDataValue = authenticationUtility
	                    .executeRestCallGSTNPost(authenticationUtility
	                        .fileGstrReqPayload(finalDto, Constant.RETSUBMIT),
	                        Constant.RETURNS, true, Constant.GSTR_7);
	                authDetails = authenticationUtility.getRek(jsonDataValue,
	                    authDetails);
	                acknowledge = authenticationUtility.getPayloadForGSTN(
	                    jsonDataValue, authDetails);
	                returnFilingDao.insertReturnFilingData(summarydto.getGstinId(),
	                    Constant.GSTR7_Filing, summarydto.getTaxPeriod(),
	                    acknowledge);
	            } catch (Exception ex) {
	                logger.error(Constant.LOGGER_ERROR + CLASS_NAME
	                    + " Method : fileGSTR7",ex);
	            }
	            logger.info(Constant.LOGGER_EXITING + CLASS_NAME
	                + " Method : fileGSTR7");
	            return acknowledge;
	        }        
	        
	        /**
	    	 * this method is used to update the Invoice status to TECH_ERROR
	    	 * 
	    	 * @param InvoiceList
	    	 * @param fileId
	    	 * 
	    	 * @return save status
	    	 */
	    	@Override
	    	public boolean timeoutAndMarkInvoiceStatusTechError(Integer fileId) throws Exception{

	    		return invoiceDao.markTechErrorInvoiceStatus(fileId);
	    	}      
	        
	        
}
