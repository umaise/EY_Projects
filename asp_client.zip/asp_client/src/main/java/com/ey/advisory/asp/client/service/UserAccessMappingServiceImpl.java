package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.UserAccessMappingDao;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.UserAccessMapping;

@Service
public class UserAccessMappingServiceImpl implements UserAccessMappingService{
	
	private static final Logger LOGGER = Logger.getLogger(UserAccessMapHierarchyImpl.class);
	
	@Autowired
	private UserAccessMappingDao userAccessMappingDao;
	
	@Autowired
	EntityHeirarchyService entityHeirarchyService;

	/**
	 * This method is required as there is a change in the way AccessValue is stored in the tbalUserAccessMapping
	 * table. Earlier the actual value (like group code for L1 user, entity code for L2 user etc) were stored.
	 * But now, the full path starting from the group is stored for all users. (For eg. L3B user will have 
	 * an access value like groupcode->entityCode->circleCode->GSTIN). So, there is a mix of the old format
	 * and new format in the DB. In order to accomodate this, we check if the access level has a '->' string
	 * in it. If so, we assume it to be in the new format and extract the final part of the string. This will
	 * the actual access value.
	 * 
	 * @param dbAccessValue
	 * @return
	 */
	private String extractActualAccessValue(String dbAccessValue) {
		if(!dbAccessValue.contains("->")) {
			return dbAccessValue;
		}
		int idx = dbAccessValue.lastIndexOf("->");
		String retVal = dbAccessValue.substring(idx + 2);
		return retVal;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> getGstinByLevel(Integer userId, Integer entityID) {
		// Changes made to the method. (by Nethra).
		
		List<UserAccessMapping> mappings = userAccessMappingDao.getMappingsByUserId(userId);
		
		// If there are no mappings, throw an exception.
		if(mappings == null || mappings.size() == 0) {
			throw new RuntimeException("No mapping defined/could not be loaded"
					+ " for the user " + userId + " in tblUserAccessMapping table.");
		}
		
		// Get the first element of the mappings. If execution reaches here, we can
		// assume that there is at least one element in the list.
		Iterator<UserAccessMapping> it = mappings.iterator();
		UserAccessMapping first = mappings.get(0);
		
		
		// Currently, only L1, L2, L3A and L3B users are supported by smart reports.
		String accessLevel = first.getAccessLevel();
		if(!"L1".equalsIgnoreCase(accessLevel) && 
				!"L2".equalsIgnoreCase(accessLevel) && 
				!"L3A".equalsIgnoreCase(accessLevel) && 
				!"L3B".equalsIgnoreCase(accessLevel)) {
			throw new RuntimeException("Currently, only L1, L2, L3A and L3B "
					+ "level users are supported by Smart Reports.");			
		}
		
		// Final return set.
		Set<String> retSet = new TreeSet<String>(); 
	
		while(it.hasNext()) {
			UserAccessMapping mapping = it.next();
			
			// First process L1 user access.
			// For L1 user, the first element in the UserAccessMapping will be mapped to
			// a group. We skip any subsequent elements in the array (assuming that
			// the same user cannot be a part of multiple groups)
			if(mapping.getAccessLevel().equalsIgnoreCase("L1")){
				// For L1 users, we get the list of GSTINs associated with the entity
				// that is selected in the dashboard page. (Changed by Nethra)
				
				// Using a set to eliminate the duplicates returned from the DB. The
				// EntityHierarchy table can repeat the same GSTINs multiple times for
				// the same entity. (Later we can add a fix at the DAO level to return
				// distinct GSTIN Ids)
				Set<String> gstinSet = getGstinForL1UserForEntity(userId, entityID);
				retSet.addAll(gstinSet);
			}
			
			// Secondly, process the L2 access level.
			// If multiple entities
			// are associated with the L2 user, all the GSTINs will be loaded from
			// the UserAccessMapping table (for all the entities)
			if(mapping.getAccessLevel().equalsIgnoreCase("L2")){
				
				String accessVal = extractActualAccessValue(mapping.getAccessValue());
				List<String> gstins = getGstinsByEntityId(accessVal);
				retSet.addAll(gstins);
					
			}

			// Thirdly, process the L3A level.
			// For L3A users, we get the list of GSTINs associated with the
			// CircleCode. Only the GSTINs associated with the circle of user will
			// be displayed in the SmartReports page. 		
			if(mapping.getAccessLevel().equalsIgnoreCase("L3A")) {									
	 				String circleCode = extractActualAccessValue(mapping.getAccessValue());
	 				// Get the gstins for the current circle code, and add it
	 				// to the final set.
					Set set = getGstinForL3AUserForCircleCode(userId, circleCode);
					retSet.addAll(set); 
			}
			

			// Finally, process the L3B level.
			// At L3B level, we get the level to GSTIN mappings directly
			// from the UserAccessMapping table. Unlike other leves, we 
			// can use this directly, to return the list of GSTINs.		
			if(mapping.getAccessLevel().equalsIgnoreCase("L3B")){
				// A set is not really required (unless a duplicate mapping
				// is made in the UserAccessMapping table). Once it is
				// confirmed that the DB has a unique constraint for each
				// UserId, Level, AccessValue combination, we can remove the
				// set and use a list directly.
				String accessVal = extractActualAccessValue(mapping.getAccessValue());				
				retSet.add(accessVal);				
			}			
		}
		
		return new ArrayList<String>(retSet);
	}
	
	/**
	 * This method returns the GSTINs for an L1 user, for the specified entity. If the user
	 * belongs to any other level, the method throws an exception. There is supposed to be
	 * only one mapping for an L1 user in the UserAccessMapping table. If we encounter
	 * multiple mappings, this method picks the first mapping and ignores the rest.
	 * (assuming that this might be an error in the DB). 
	 * 
	 * @param userId
	 * @param entityId
	 * @return
	 */
	public Set<String> getGstinForL1UserForEntity(Integer userId, Integer entityId) {
		List<UserAccessMapping> mappings = userAccessMappingDao.getMappingsByUserId(userId);
		Set<String> gstins = new TreeSet<String>();
		
		LOGGER.info("In getGstinForL1UserForEntity to get "
				+ "GSTINS for L1 User for an Entity Selected" + userId + "And" + entityId);
		if(mappings != null){
			Iterator<UserAccessMapping> it = mappings.iterator();
			// Choose only the first mapping from the UserAccessMapping table. Ignore the rest.
			if(it.hasNext()){
				UserAccessMapping mapping = (UserAccessMapping) it.next();
				if(mapping.getAccessLevel().equalsIgnoreCase("L1")){
					// Get the entity hierarchy objects for the specified entity id.
					List<EntityHierarchy> entityHierarchy = 
							entityHeirarchyService.getEntityHierarchyByEntityID(entityId);					
					// Get the GSTINs by specified entity.	
					for(EntityHierarchy entity: entityHierarchy) {
						gstins.add(entity.getgSTIN());
					}
				}else {
					throw new RuntimeException(
							"getGstinForL1UserForEntity should be called only for L1 users");
				}
			} else {
				throw new RuntimeException("No Access Mappings found for the user " + userId);
			}
		}
		return gstins;		
	}
	
	public Set<String> getGstins(List<UserAccessMapping> mappings){
		Set<String> gstins = new TreeSet<String>();
		Iterator<UserAccessMapping> it = mappings.iterator();
		while(it.hasNext()){
			UserAccessMapping mapping = (UserAccessMapping) it.next();
			gstins.add(mapping.getAccessValue());
		}
		return gstins;
	}
	
	/**
	 * This method returns the GSTINs for an L3A user. If the user
	 * belongs to any other level, the method throws an exception. 
	 * Getting the GSTINS for the Users for the CircleCode
	 * 
	 * @param userId
	 * @param circleCode
	 * @return
	 */
	public Set<String> getGstinForL3AUserForCircleCode(Integer userId, String circleCode) {
		List<UserAccessMapping> mappings = userAccessMappingDao.getMappingsByUserId(userId);
		Set<String> gstins = new TreeSet<String>();
		
		LOGGER.info("Get the GSTINS for the User based on Circle Code" + 
					userId + "AND" + circleCode);
		
		if(mappings != null){
			Iterator<UserAccessMapping> it = mappings.iterator();
			// Choose only the first mapping from the UserAccessMapping table. Ignore the rest.
			if(it.hasNext()){
				UserAccessMapping mapping = (UserAccessMapping) it.next();
				if(mapping.getAccessLevel().equalsIgnoreCase("L3A")){
					// Get the entity hierarchy objects for the specified CircleCode
					List<EntityHierarchy> entityHierarchy = 
							entityHeirarchyService.getEntityHierarchyByCircleCode(circleCode);					
					// Get the GSTINs by specified CircleCode
					for(EntityHierarchy entity: entityHierarchy) {
						gstins.add(entity.getgSTIN());
					}
				}else {
					throw new RuntimeException(
							"getGstinForL1UserForEntity should be called only for L3A users");
				}
			} else {
				throw new RuntimeException("No Access Mappings found for the user " + userId);
			}
		}
		return gstins;		
	}


	public List<String> getGstinsByGroupCode(String groupCode){
		List<String> gstins = new ArrayList<String>();
		List<EntityHierarchy> entityHierarchyDetails = entityHeirarchyService.getGstinsByGroupCode(groupCode);
		if(entityHierarchyDetails != null){
			Iterator<EntityHierarchy> it = entityHierarchyDetails.iterator();
			while(it.hasNext()){
				EntityHierarchy domain = (EntityHierarchy) it.next();
				gstins.add(domain.getgSTIN());
			}
		}
		return gstins;
		
	}
	
	public List<String> getGstinsByEntityId(String entityCode){
		List<String> gstins = new ArrayList<String>();
		List<EntityHierarchy> entityHierarchyDetails = entityHeirarchyService.getGstinsByEntityId(entityCode);
		if(entityHierarchyDetails != null){
			Iterator<EntityHierarchy> it = entityHierarchyDetails.iterator();
			while(it.hasNext()){
				EntityHierarchy domain = (EntityHierarchy) it.next();
				gstins.add(domain.getgSTIN());
			}
		}
		return gstins;
		
	}
	
}
