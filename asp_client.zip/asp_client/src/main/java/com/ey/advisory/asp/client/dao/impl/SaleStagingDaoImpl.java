package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.SaleStagingDao;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblSalesPreStaging;
import com.ey.advisory.asp.common.Constant;
@Repository
public class SaleStagingDaoImpl implements SaleStagingDao{
	@Autowired
	HibernateDao hibernateDao;
	private static final Logger logger = Logger.getLogger(SaleStagingDaoImpl.class);
	private static final String CLASS_NAME = SaleStagingDaoImpl.class.getName();
	
	/* * @see com.ey.advisory.asp.client.service.ClientSpCallService#getLineItemList()
	 * This method is used to retrieve the GSTR1 lineItem values for data pipeline2
	 */
	@Override
	public List<String> getLineItemList(String applicableState,String returnType,String fileId,String recordType,String datalevel) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getLineItemList()");
		}
		List<String> listItem=null;
		String strQuery=null;
	    try {
	    	
	    	if(datalevel.equalsIgnoreCase(Constant.INVOICE))
	    	{
	    	strQuery="select TOP 100 PERCENT  concat('{\"uk\":\"gstr1_',FILEID,'_BRStg2\",\"gstr1\":',invList,'}')  from " 
	    			+"(select TOP 100 PERCENT (select tbl1.* from  "
	    					+"etl.tblSalesStaging tbl1 where tbl.DocumentNo = tbl1.DocumentNo and "
	    						+"tbl1.Status = ? and tbl1.RecordType  =  ? and tbl1.FILEID= ? FOR JSON AUTO ,INCLUDE_NULL_VALUES) as 'invList' ,tbl.FILEID as 'FILEID'"
	    						+"from etl.tblSalesStaging tbl  where  tbl.Status= ? and tbl.RecordType = ? and tbl.FILEID= ? order by DocumentNo asc   ) " 
	    						+"	AS TotalInvList  group by invList,FILEID ORDER BY invList ASC ";
	    		}
	    	if(datalevel.equalsIgnoreCase(Constant.ITEM))
	    	{
	    		strQuery="select TOP 100 PERCENT  concat('{\"uk\":\"gstr1_',FILEID,'_BRStg2\",\"gstr1\":',invList,'}')  from " 
	    			+"(select TOP 100 PERCENT (select tbl1.* from  "
	    					+"etl.tblSalesStaging tbl1 where tbl.DocumentNo = tbl1.DocumentNo and "
	    						+"tbl1.Status = ? and tbl1.RecordType  = ? and tbl1.FILEID= ? FOR JSON AUTO ,INCLUDE_NULL_VALUES) as 'invList'  ,tbl.FILEID as 'FILEID'"
	    						+"from etl.tblSalesStaging tbl  where  tbl.Status= ? and tbl.RecordType = ? and tbl.FILEID= ? order by DocumentNo asc   ) " 
	    						+"	AS TotalInvList  ";
	    	}
	    	
	     listItem = (List<String>) hibernateDao.executeNativeSql(strQuery,new Object[]{applicableState,recordType,fileId,applicableState,recordType,fileId});
	
	    } catch (Exception e) {
	    	if(logger.isInfoEnabled()){
	    	logger.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getLineItemList()"+e);
	    	}
	    }
	    if(logger.isInfoEnabled()){
	    logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getLineItemList()");
	    }
		return listItem;
	}
	/*(non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#getDataCount(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 * Used to get Invoice Count from database
	 */
	@Override
	public List<String> getDataCount(String applicableState, String returnType,String fileData,String isProccessed,String jobStatus,List<String> fileIds,String recordType, String groupCode) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getDataCount()");
		}
		String strQuery ;
		String files;
		List<String> listInvCount=new ArrayList<>();
		if(fileIds!=null && !fileIds.isEmpty())
		{
		 files = fileIds.toString().substring(1, fileIds.toString().length()-1);
		}
		else
		{
		files="''";
		}
		
	    try {
			strQuery = "select * from (SELECT concat('gstr1_',FILEID,'_BRStg2') as 'uk',COUNT(DISTINCT DocumentNo) as 'invoiceCount','"
					+ groupCode
					+ "' as 'groupCode' "
					+ "FROM etl.tblSalesStaging tbl "
					+ "WHERE  tbl.Status= ? and tbl.RecordType = ? and fileid in( ? ) GROUP BY FILEID) as tb1 FOR JSON AUTO ";
	   
	    	listInvCount =(List<String>) hibernateDao.executeNativeSql(strQuery,new Object[]{applicableState,recordType,files});
	      
	    } catch (Exception e) {
	    	if(logger.isInfoEnabled()){
	    	logger.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getDataCount()"+e);
	    	
	    	}
	    }
	    if(logger.isInfoEnabled()){
	    logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getDataCount()");
	    }
		return listInvCount;
	}
	
	@Override
	public List<OutwardInvoiceModel> fetchProcessedRecords(Long fileId,int firstResult, int pageSize) {
		List<OutwardInvoiceModel> salesProcessedList = null;
        Criteria criteria = hibernateDao.createNormalCriteria(OutwardInvoiceModel.class);
		criteria.add(Restrictions.eq("fileID", fileId.intValue()));
		criteria.add(Restrictions.eq("isError", false));
		criteria.add(Restrictions.eq("isDuplicate", false));
       
        criteria.setFirstResult(firstResult);
        criteria.setMaxResults(pageSize);
        criteria.addOrder(Order.asc("id"));
        salesProcessedList = criteria.list();
		return salesProcessedList;
		
	}
	
	@Override
	public Long getTotalProcessedCount(Long fileId) {
		Long count = null;
		Criteria criteriaCount = hibernateDao.createNormalCriteria(OutwardInvoiceModel.class);
		criteriaCount.add(Restrictions.eq("fileID", fileId.intValue()));
		criteriaCount.add(Restrictions.eq("isError", false));
		criteriaCount.add(Restrictions.eq("isDuplicate", false));
		criteriaCount.setProjection(Projections.rowCount());
		count = (Long) (criteriaCount).uniqueResult();
		return count;
	}

	
	@Override
	public List<OutwardInvoiceModel> fetchTotalRecords(Long fileId, int firstResult,int pageSize) {
		List<OutwardInvoiceModel> salesTotalList = null;
		Criteria criteria = hibernateDao.createNormalCriteria(TblSalesPreStaging.class);
        criteria.add(Restrictions.eq("fileID", fileId));
        criteria.setFirstResult(firstResult);
        criteria.setMaxResults(pageSize);
        criteria.addOrder(Order.asc("id"));
        salesTotalList = criteria.list();
        return salesTotalList;
	}
	
	@Override
	public Long getTotalCount(Long fileId) {
		Long count = null;
		Criteria criteriaCount = hibernateDao.createNormalCriteria(TblSalesPreStaging.class);
        criteriaCount.add(Restrictions.eq("fileID", fileId));
        criteriaCount.add(Restrictions.eq("isDuplicate", true));
        criteriaCount.setProjection(Projections.rowCount());
        count = (Long) (criteriaCount).uniqueResult();
		return count;
	}

	@Override
	public List<OutwardInvoiceModel> fetchDupRecords(Long fileId,int firstResult, int pageSize) {
		List<OutwardInvoiceModel> salesDupList;
        Criteria criteria = hibernateDao.createNormalCriteria(OutwardInvoiceModel.class);
        criteria.add(Restrictions.eq("fileID", fileId.intValue()));
        criteria.add(Restrictions.eq("isDuplicate", Boolean.TRUE));
        criteria.setFirstResult(firstResult);
        criteria.setMaxResults(pageSize);
        criteria.addOrder(Order.asc("id"));
        salesDupList = criteria.list();
		return salesDupList;
		
	}
	
	@Override
	public Long getTotalDupCount(Long fileId) {
		Long count = null;
		Criteria criteriaCount = hibernateDao.createNormalCriteria(OutwardInvoiceModel.class);
		criteriaCount.add(Restrictions.eq("fileID", fileId.intValue()));
		criteriaCount.add(Restrictions.eq("isDuplicate", true));
		criteriaCount.setProjection(Projections.rowCount());
		count = (Long) (criteriaCount).uniqueResult();
		return count;
	}
	
	@Override
	public List<OutwardInvoiceModel> fetchErrorRecords(Long fileId,int firstResult, int pageSize) {
		List<OutwardInvoiceModel> salesDupList;
        Criteria criteria = hibernateDao.createNormalCriteria(OutwardInvoiceModel.class);
        criteria.add(Restrictions.eq("fileID", fileId.intValue()));
        criteria.add(Restrictions.eq("isError", Boolean.TRUE));
        criteria.setFirstResult(firstResult);
        criteria.setMaxResults(pageSize);
        criteria.addOrder(Order.asc("id"));
        salesDupList = criteria.list();
		return salesDupList;
		
	}
	
	@Override
	public Long getTotalErrorCount(Long fileId) {
		Long count = null;
		Criteria criteriaCount = hibernateDao.createNormalCriteria(OutwardInvoiceModel.class);
		criteriaCount.add(Restrictions.eq("fileID", fileId.intValue()));
		criteriaCount.add(Restrictions.eq("isError", Boolean.TRUE));
		criteriaCount.setProjection(Projections.rowCount());
		count = (Long) (criteriaCount).uniqueResult();
		return count;
	}
	

}
