package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import javax.persistence.*;

import com.ey.advisory.asp.client.util.CommonUtillity;

/**
 * The persistent class for the tblSalesPreStaging database table.
 * 
 */
@Entity
@Table(name = "tblSalesPreStaging", schema = "etl")
@NamedQuery(name = "TblSalesPreStaging.findAll", query = "SELECT t FROM TblSalesPreStaging t")
public class TblSalesPreStaging implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "Id")
	private long id;
	
	@Column(name = "SourceIdentifier")
	private String sourceIdentifier;
	
	@Column(name = "SourceFileName")
	private String sourceFileName;
	
	@Column(name = "GLAccountCode")
	private String gLAccountCode;
	
	@Column(name = "Division")
	private String division;
	
	@Column(name = "SubDivision")
	private String subDivision;
	
	@Column(name = "ProfitCentre1")
	private String profitCentre1;

	@Column(name = "ProfitCentre2")
	private String profitCentre2;
	
	@Column(name = "PlantCode")
	private String plantCode;
	
	@Column(name = "TaxPeriod")
	private String taxPeriod;
	
	@Column(name = "SGSTIN")
	private String sgstin;
	
	@Column(name = "DocumentType")
	private String documentType;
	
	@Column(name = "SupplyType")
	private String supplyType;
	
	@Column(name = "DocumentNo")
	private String documentNo;

	@Column(name = "DocumentDate")
	private String documentDate;
	
	@Column(name = "OriginalDocumentNo")
	private String originalDocumentNo;

	@Column(name = "OriginalDocumentDate")
	private String originalDocumentDate;

	@Column(name = "CRDRPreGST")
	private String cRDRPreGST;
	
	@Column(name = "LineNumber")
	private String lineNumber;
	
	@Column(name = "CGSTIN")
	private String cgstin;
	
	@Column(name = "UINorComposition")
	private String uINorComposition;
	
	@Column(name = "OriginalCGSTIN")
	private String originalCGSTIN;
	
	@Column(name = "CustomerName")
	private String customerName;

	@Column(name = "CustomerCode")
	private String customerCode;
	
	@Column(name = "BillToState")
	private String billToState;
	
	@Column(name = "ShipToState")
	private String shipToState;
	
	@Column(name = "POS")
	private String pos;

	@Column(name = "PortCode")
	private String portCode;

	@Column(name = "ShippingBillNo")
	private String shippingBillNo;

	@Column(name = "ShippingBillDate")
	private String shippingBillDate;

	@Column(name = "FOB")
	private String fob;
	
	@Column(name = "ExportDuty")
	private String exportDuty;
	
	@Column(name = "HSNSAC")
	private String hsnsac;
	
	@Column(name = "ItemCode")
	private String itemCode;

	@Column(name = "ItemDescription")
	private String itemDescription;

	@Column(name = "ItemCategory")
	private String itemCategory;
	
	@Column(name = "UnitofMeasurement")
	private String unitofMeasurement;
	
	@Column(name = "QtySupplied")
	private String qtySupplied;
	
	@Column(name = "TaxableValue")
	private String taxableValue;
	
	@Column(name = "IGSTRate")
	private String iGSTRate;
	
	@Column(name = "IGSTAmount")
	private String iGSTAmount;

	@Column(name = "CGSTRate")
	private String cGSTRate;
	
	@Column(name = "CGSTAmount")
	private String cGSTAmount;
	
	@Column(name = "SGSTRate")
	private String sGSTRate;
	
	@Column(name = "SGSTAmount")
	private String sGSTAmount;
	
	@Column(name = "CessRateAdvalorem")
	private String cessRateAdvalorem;
	
	@Column(name = "CessAmountAdvalorem")
	private String cessAmountAdvalorem;
	
	@Column(name = "CessRateSpecific")
	private String cessRateSpecific;

	@Column(name = "CessAmountSpecific")
	private String cessAmountSpecific;
	
	@Column(name = "InvoiceValue")
	private String invoiceValue;

	@Column(name = "ReverseCharge")
	private String reverseCharge;
	
	@Column(name = "TCSFlag")
	private String tCSFlag;
	
	@Column(name = "EGSTIN")
	private String egstin;
	
	@Column(name = "ITCFlag")
	private String iTCFlag;

	@Column(name = "ReasonForCreditDebitNote")
	private String reasonForCreditDebitNote;
	
	@Column(name = "AccountingVoucherNumber")
	private String accountingVoucherNumber;

	@Column(name = "AccountingVoucherDate")
	private String accountingVoucherDate;
	
	@Column(name = "Userdefinedfield1")
	private String userdefinedfield1;

	@Column(name = "Userdefinedfield2")
	private String userdefinedfield2;

	@Column(name = "Userdefinedfield3")
	private String userdefinedfield3;
	
	@Column(name = "ChkSum")
	private String chkSum;

	@Column(name = "DuplicateStatus")
	private String duplicateStatus;

	@Column(name = "DupRnk")
	private Long dupRnk;

	@Column(name = "ErrorMsg")
	private String errorMsg;

	@Column(name = "FileID")
	private Long fileID;

	@Column(name = "IsError")
	private String isError;


	public TblSalesPreStaging() {
	}

	
	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getAccountingVoucherDate() {
		return accountingVoucherDate;
	}


	public void setAccountingVoucherDate(String accountingVoucherDate) {
		this.accountingVoucherDate = accountingVoucherDate;
	}


	public String getAccountingVoucherNumber() {
		return accountingVoucherNumber;
	}


	public void setAccountingVoucherNumber(String accountingVoucherNumber) {
		this.accountingVoucherNumber = accountingVoucherNumber;
	}


	public String getBillToState() {
		return billToState;
	}


	public void setBillToState(String billToState) {
		this.billToState = billToState;
	}


	public String getCessAmountAdvalorem() {
		return cessAmountAdvalorem;
	}


	public void setCessAmountAdvalorem(String cessAmountAdvalorem) {
		this.cessAmountAdvalorem = cessAmountAdvalorem;
	}


	public String getCessAmountSpecific() {
		return cessAmountSpecific;
	}


	public void setCessAmountSpecific(String cessAmountSpecific) {
		this.cessAmountSpecific = cessAmountSpecific;
	}


	public String getCessRateAdvalorem() {
		return cessRateAdvalorem;
	}


	public void setCessRateAdvalorem(String cessRateAdvalorem) {
		this.cessRateAdvalorem = cessRateAdvalorem;
	}


	public String getCessRateSpecific() {
		return cessRateSpecific;
	}


	public void setCessRateSpecific(String cessRateSpecific) {
		this.cessRateSpecific = cessRateSpecific;
	}


	public String getcGSTAmount() {
		return cGSTAmount;
	}


	public void setcGSTAmount(String cGSTAmount) {
		this.cGSTAmount = cGSTAmount;
	}


	public String getCgstin() {
		return cgstin;
	}


	public void setCgstin(String cgstin) {
		this.cgstin = cgstin;
	}


	public String getcGSTRate() {
		return cGSTRate;
	}


	public void setcGSTRate(String cGSTRate) {
		this.cGSTRate = cGSTRate;
	}


	public String getChkSum() {
		return chkSum;
	}


	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}


	public String getcRDRPreGST() {
		return cRDRPreGST;
	}


	public void setcRDRPreGST(String cRDRPreGST) {
		this.cRDRPreGST = cRDRPreGST;
	}


	public String getCustomerCode() {
		return customerCode;
	}


	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getDivision() {
		return division;
	}


	public void setDivision(String division) {
		this.division = division;
	}


	public String getDocumentDate() {
		return documentDate;
	}


	public void setDocumentDate(String documentDate) {
		this.documentDate = documentDate;
	}


	public String getDocumentNo() {
		return documentNo;
	}


	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}


	public String getDocumentType() {
		return documentType;
	}


	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}


	public String getDuplicateStatus() {
		return duplicateStatus;
	}


	public void setDuplicateStatus(String duplicateStatus) {
		this.duplicateStatus = duplicateStatus;
	}


	public Long getDupRnk() {
		return dupRnk;
	}


	public void setDupRnk(Long dupRnk) {
		this.dupRnk = dupRnk;
	}


	public String getEgstin() {
		return egstin;
	}


	public void setEgstin(String egstin) {
		this.egstin = egstin;
	}


	public String getErrorMsg() {
		return errorMsg;
	}


	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}


	public String getExportDuty() {
		return exportDuty;
	}


	public void setExportDuty(String exportDuty) {
		this.exportDuty = exportDuty;
	}


	public Long getFileID() {
		return fileID;
	}


	public void setFileID(Long fileID) {
		this.fileID = fileID;
	}


	public String getFob() {
		return fob;
	}


	public void setFob(String fob) {
		this.fob = fob;
	}


	public String getgLAccountCode() {
		return gLAccountCode;
	}


	public void setgLAccountCode(String gLAccountCode) {
		this.gLAccountCode = gLAccountCode;
	}


	public String getHsnsac() {
		return hsnsac;
	}


	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}


	public String getiGSTAmount() {
		return iGSTAmount;
	}


	public void setiGSTAmount(String iGSTAmount) {
		this.iGSTAmount = iGSTAmount;
	}


	public String getiGSTRate() {
		return iGSTRate;
	}


	public void setiGSTRate(String iGSTRate) {
		this.iGSTRate = iGSTRate;
	}


	public String getInvoiceValue() {
		return invoiceValue;
	}


	public void setInvoiceValue(String invoiceValue) {
		this.invoiceValue = invoiceValue;
	}


	public String getIsError() {
		return isError;
	}


	public void setIsError(String isError) {
		this.isError = isError;
	}


	public String getiTCFlag() {
		return iTCFlag;
	}


	public void setiTCFlag(String iTCFlag) {
		this.iTCFlag = iTCFlag;
	}


	public String getItemCategory() {
		return itemCategory;
	}


	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}


	public String getItemCode() {
		return itemCode;
	}


	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public String getLineNumber() {
		return lineNumber;
	}


	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}


	public String getOriginalCGSTIN() {
		return originalCGSTIN;
	}


	public void setOriginalCGSTIN(String originalCGSTIN) {
		this.originalCGSTIN = originalCGSTIN;
	}


	public String getOriginalDocumentDate() {
		return originalDocumentDate;
	}


	public void setOriginalDocumentDate(String originalDocumentDate) {
		this.originalDocumentDate = originalDocumentDate;
	}


	public String getOriginalDocumentNo() {
		return originalDocumentNo;
	}


	public void setOriginalDocumentNo(String originalDocumentNo) {
		this.originalDocumentNo = originalDocumentNo;
	}


	public String getPlantCode() {
		return plantCode;
	}


	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}


	public String getPortCode() {
		return portCode;
	}


	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}


	public String getPos() {
		return pos;
	}


	public void setPos(String pos) {
		this.pos = pos;
	}


	public String getProfitCentre1() {
		return profitCentre1;
	}


	public void setProfitCentre1(String profitCentre1) {
		this.profitCentre1 = profitCentre1;
	}


	public String getProfitCentre2() {
		return profitCentre2;
	}


	public void setProfitCentre2(String profitCentre2) {
		this.profitCentre2 = profitCentre2;
	}


	public String getQtySupplied() {
		return qtySupplied;
	}


	public void setQtySupplied(String qtySupplied) {
		this.qtySupplied = qtySupplied;
	}


	public String getReasonForCreditDebitNote() {
		return reasonForCreditDebitNote;
	}


	public void setReasonForCreditDebitNote(String reasonForCreditDebitNote) {
		this.reasonForCreditDebitNote = reasonForCreditDebitNote;
	}


	public String getReverseCharge() {
		return reverseCharge;
	}


	public void setReverseCharge(String reverseCharge) {
		this.reverseCharge = reverseCharge;
	}


	public String getsGSTAmount() {
		return sGSTAmount;
	}


	public void setsGSTAmount(String sGSTAmount) {
		this.sGSTAmount = sGSTAmount;
	}


	public String getSgstin() {
		return sgstin;
	}


	public void setSgstin(String sgstin) {
		this.sgstin = sgstin;
	}


	public String getsGSTRate() {
		return sGSTRate;
	}


	public void setsGSTRate(String sGSTRate) {
		this.sGSTRate = sGSTRate;
	}


	public String getShippingBillDate() {
		return shippingBillDate;
	}


	public void setShippingBillDate(String shippingBillDate) {
		this.shippingBillDate = shippingBillDate;
	}


	public String getShippingBillNo() {
		return shippingBillNo;
	}


	public void setShippingBillNo(String shippingBillNo) {
		this.shippingBillNo = shippingBillNo;
	}


	public String getShipToState() {
		return shipToState;
	}


	public void setShipToState(String shipToState) {
		this.shipToState = shipToState;
	}


	public String getSourceFileName() {
		return sourceFileName;
	}


	public void setSourceFileName(String sourceFileName) {
		this.sourceFileName = sourceFileName;
	}


	public String getSourceIdentifier() {
		return sourceIdentifier;
	}


	public void setSourceIdentifier(String sourceIdentifier) {
		this.sourceIdentifier = sourceIdentifier;
	}


	public String getSubDivision() {
		return subDivision;
	}


	public void setSubDivision(String subDivision) {
		this.subDivision = subDivision;
	}


	public String getSupplyType() {
		return supplyType;
	}


	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}


	public String getTaxableValue() {
		return taxableValue;
	}


	public void setTaxableValue(String taxableValue) {
		this.taxableValue = taxableValue;
	}


	public String getTaxPeriod() {
		return taxPeriod;
	}


	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}


	public String gettCSFlag() {
		return tCSFlag;
	}


	public void settCSFlag(String tCSFlag) {
		this.tCSFlag = tCSFlag;
	}


	public String getuINorComposition() {
		return uINorComposition;
	}


	public void setuINorComposition(String uINorComposition) {
		this.uINorComposition = uINorComposition;
	}


	public String getUnitofMeasurement() {
		return unitofMeasurement;
	}


	public void setUnitofMeasurement(String unitofMeasurement) {
		this.unitofMeasurement = unitofMeasurement;
	}


	public String getUserdefinedfield1() {
		return userdefinedfield1;
	}


	public void setUserdefinedfield1(String userdefinedfield1) {
		this.userdefinedfield1 = userdefinedfield1;
	}


	public String getUserdefinedfield2() {
		return userdefinedfield2;
	}


	public void setUserdefinedfield2(String userdefinedfield2) {
		this.userdefinedfield2 = userdefinedfield2;
	}


	public String getUserdefinedfield3() {
		return userdefinedfield3;
	}


	public void setUserdefinedfield3(String userdefinedfield3) {
		this.userdefinedfield3 = userdefinedfield3;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TblSalesPreStaging other = (TblSalesPreStaging) obj;
		if (id != other.id)
			return false;
		return true;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public String toString() {
		return (sourceIdentifier != null ? CommonUtillity.formatCommasWithSpaces(sourceIdentifier) : "") + "," + (sourceFileName != null ? CommonUtillity.formatCommasWithSpaces(sourceFileName) : "") + ","
				+ (gLAccountCode != null ? gLAccountCode : "") + "," + (division != null ? CommonUtillity.formatCommasWithSpaces(division) : "") + ","
				+ (subDivision != null ? CommonUtillity.formatCommasWithSpaces(subDivision) : "") + "," + (profitCentre1 != null ? profitCentre1 : "") + ","
				+ (profitCentre2 != null ? profitCentre2 : "") + "," + (plantCode != null ? plantCode : "") + "," 
				+ (taxPeriod != null ? taxPeriod : "") + "," + (sgstin != null ? sgstin : "") + ","
				+ (documentType != null ? documentType : "") + "," + (supplyType != null ? supplyType : "") + ","
				+ (documentNo != null ? documentNo : "") + "," + (documentDate != null ? documentDate : "") + ","
				+ (originalDocumentNo != null ? originalDocumentNo : "") + "," + (originalDocumentDate != null ? originalDocumentDate : "") + ","
				+ (cRDRPreGST != null ? cRDRPreGST : "") + "," + (lineNumber != null ? lineNumber : "") + "," 
				+ (cgstin != null ? cgstin : "") + "," + (uINorComposition != null ? uINorComposition : "") + "," 
				+ (originalCGSTIN != null ? originalCGSTIN : "") + "," + (customerName != null ? CommonUtillity.formatCommasWithSpaces(customerName) : "") + ","
				+ (customerCode != null ? customerCode : "") + "," + (billToState != null ? billToState : "") + "," 
				+ (shipToState != null ? shipToState : "") + "," + (pos != null ? pos : "") + ","
				+ (portCode != null ? portCode : "") + "," + (shippingBillNo != null ? shippingBillNo : "") + ","
				+ (shippingBillDate != null ? shippingBillDate : "") + "," + (fob != null ? fob : "") + ","
				+ (exportDuty != null ? exportDuty : "") + "," + (hsnsac != null ? hsnsac : "") + ","
				+ (itemCode != null ? CommonUtillity.formatCommasWithSpaces(itemCode) : "") + "," + (itemDescription != null ? CommonUtillity.formatCommasWithSpaces(itemDescription) : "") + ","
				+ (itemCategory != null ? CommonUtillity.formatCommasWithSpaces(itemCategory) : "") + "," + (unitofMeasurement != null ? unitofMeasurement : "") + ","
				+ (qtySupplied != null ? qtySupplied : "") + "," + (taxableValue != null ? taxableValue : "") + ","
				+ (iGSTRate != null ? iGSTRate : "") + "," + (iGSTAmount != null ? iGSTAmount : "") + "," 
				+ (cGSTRate != null ? cGSTRate : "") + "," + (cGSTAmount != null ? cGSTAmount : "") + "," 
				+ (sGSTRate != null ? sGSTRate : "") + "," + (sGSTAmount != null ? sGSTAmount : "") + "," 
				+ (cessRateAdvalorem != null ? cessRateAdvalorem : "") + "," + (cessAmountAdvalorem != null ? cessAmountAdvalorem : "") + ","
				+ (cessRateSpecific != null ? cessRateSpecific : "") + "," + (cessAmountSpecific != null ? cessAmountSpecific : "") + ","
				+ (invoiceValue != null ? invoiceValue : "") + "," + (reverseCharge != null ? reverseCharge : "") + "," 
				+ (tCSFlag != null ? tCSFlag : "") + "," + (egstin != null ? egstin : "") + ","
				+ (iTCFlag != null ? iTCFlag : "") + "," + (reasonForCreditDebitNote != null ? CommonUtillity.formatCommasWithSpaces(reasonForCreditDebitNote) : "") + ","
				+ (accountingVoucherNumber != null ? accountingVoucherNumber : "") + "," + (accountingVoucherDate != null ? accountingVoucherDate : "") + ","
				+ (userdefinedfield1 != null ? userdefinedfield1 : "") + "," + (userdefinedfield2 != null ? userdefinedfield2 : "") + ","
				+ (userdefinedfield3 != null ? userdefinedfield3 : "");
	}
	
	/*@Override
	public String toString() {
		return  sourceIdentifier + "," + sourceFileName + ","
				+ gLAccountCode + "," + division + "," + subDivision + ","
				+ profitCentre1 + "," + profitCentre2 + "," + plantCode + ","
				+ taxPeriod + "," + sgstin + "," + documentType + ","
				+ supplyType + "," + documentNo + "," + documentDate + ","
				+ originalDocumentNo + "," + originalDocumentDate + ","
				+ cRDRPreGST + "," + lineNumber + "," + cgstin + ","
				+ uINorComposition + "," + originalCGSTIN + "," + customerName
				+ "," + customerCode + "," + billToState + "," + shipToState
				+ "," + pos + "," + portCode + "," + shippingBillNo + ","
				+ shippingBillDate + "," + fob + "," + exportDuty + ","
				+ hsnsac + "," + itemCode + "," + itemDescription + ","
				+ itemCategory + "," + unitofMeasurement + "," + qtySupplied
				+ "," + taxableValue + "," + iGSTRate + "," + iGSTAmount + ","
				+ cGSTRate + "," + cGSTAmount + "," + sGSTRate + ","
				+ sGSTAmount + "," + cessRateAdvalorem + ","
				+ cessAmountAdvalorem + "," + cessRateSpecific + ","
				+ cessAmountSpecific + "," + invoiceValue + "," + reverseCharge
				+ "," + tCSFlag + "," + egstin + "," + iTCFlag + ","
				+ reasonForCreditDebitNote + "," + accountingVoucherNumber
				+ "," + accountingVoucherDate + "," + userdefinedfield1 + ","
				+ userdefinedfield2 + "," + userdefinedfield3 ;
	}*/

}