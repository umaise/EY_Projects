package com.ey.advisory.asp.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
@XmlAccessorType(XmlAccessType.FIELD)
public class SmartReportConditions {
	
	@XmlElement(name="reportType")
	private String reportType;
	
	@XmlElement(name="financialYear")
	private String financialYear;
	
	@XmlElement(name="returnPeriod")
	private String returnPeriod;
	
	@XmlElement(name="startDate")
	private String startDate;
	
	@XmlElement(name="endDate")
	private String endDate;
	
	@XmlElement(name="docType")
	private String docType;
	
	@XmlElement(name="supType")
	private String supType;
	
	@XmlElement(name="recpGstin")
	private String recpGstin;
	
	@XmlElement(name="revChgCategory")
	private String revChgCategory;
	
	@XmlElement(name="eligibilityIndtr")
	private String eligibilityIndtr;
	
	@XmlElement(name="reconResponse")
	private String reconResponse;
	
	@XmlElement(name="typeOfReport")
	private String typeOfReport;
	
	@XmlElement(name="typeOfSubmitReport")
	private String typeOfSubmitReport;

	public String getTypeOfReport() {
		return typeOfReport;
	}


	public void setTypeOfReport(String typeOfReport) {
		this.typeOfReport = typeOfReport;
	}


	public void setReportType(String reportType) {
		this.reportType = reportType;
	}


	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}


	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}


	public void setDocType(String docType) {
		this.docType = docType;
	}


	public void setSupType(String supType) {
		this.supType = supType;
	}

	public String getReportType() {
		return reportType;
	}


	public String getFinancialYear() {
		return financialYear;
	}


	public String getReturnPeriod() {
		return returnPeriod;
	}


	public String getStartDate() {
		return startDate;
	}


	public String getEndDate() {
		return endDate;
	}


	public String getDocType() {
		return docType;
	}


	public String getSupType() {
		return supType;
	}


	public String getRecpGstin() {
		return recpGstin;
	}


	public void setRecpGstin(String recpGstin) {
		this.recpGstin = recpGstin;
	}


	public String getRevChgCategory() {
		return revChgCategory;
	}


	public void setRevChgCategory(String revChgCategory) {
		this.revChgCategory = revChgCategory;
	}


	public String getEligibilityIndtr() {
		return eligibilityIndtr;
	}


	public void setEligibilityIndtr(String eligibilityIndtr) {
		this.eligibilityIndtr = eligibilityIndtr;
	}


	public String getReconResponse() {
		return reconResponse;
	}


	public void setReconResponse(String reconResponse) {
		this.reconResponse = reconResponse;
	}


	public String getTypeOfSubmitReport() {
		return typeOfSubmitReport;
	}


	public void setTypeOfSubmitReport(String typeOfSubmitReport) {
		this.typeOfSubmitReport = typeOfSubmitReport;
	}

}