package com.ey.advisory.asp.client.dao;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatusPK;
import com.ey.advisory.asp.client.gstr1ff.dto.GSTR1FFB2BDto;
import com.ey.advisory.asp.client.gstr1ff.dto.GSTR1FFB2B_InvoiceDetails;
import com.ey.advisory.asp.client.gstr1ff.dto.GSTR1FFRootDto;
import com.ey.advisory.asp.common.Constant;
@Repository
public class GSTR1FFDaoImpl implements GSTR1FFDao {
	
	private static final Logger logger = Logger.getLogger(GSTR1FFDaoImpl.class);
	private static final String CLASS_NAME = GSTR1FFDaoImpl.class.getName();


	@Autowired
	HibernateDao hibernateDao;

	@Override
	public String saveB2B(String jsonStr, String gstin, String retPeriod, Integer chunkId) {
        String response = "";
        ObjectMapper mapper = new ObjectMapper();

        GSTR1FFRootDto root  = new GSTR1FFRootDto();
        try {
            root = mapper.readValue(jsonStr, GSTR1FFRootDto.class);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        List<GSTR1FFB2BDto> gstr1ab2b_InvoiceDetailsList = root.getB2b();
        Session session = hibernateDao.getSession();
        Transaction tx = session.beginTransaction();
        
        try{

             gstr1ab2b_InvoiceDetailsList.parallelStream().forEach(b2b -> {
                 String ctin = b2b.getCtin();
                 String cfs = b2b.getCfs();
                 List<GSTR1FFB2B_InvoiceDetails> list = new ArrayList<GSTR1FFB2B_InvoiceDetails>();
                 list = b2b.getInv();
                 //int count=0;
                 AtomicInteger ordinal = new AtomicInteger();
                 list.forEach(gstr1ab2binvoice -> {
                      DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy"); 
                     Date date;
                      try {
                           date = (Date)formatter.parse(gstr1ab2binvoice.getI_dt());
                          SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
                          String finalString = newFormat.format(date);
                          gstr1ab2binvoice.setInv_Date(newFormat.parse(finalString));
                      } catch (Exception e) {
                         e.printStackTrace();
                      }
                      gstr1ab2binvoice.setCustGSTIN(ctin);
                      gstr1ab2binvoice.setCntrPrtyFilingStatus(cfs);
                      gstr1ab2binvoice.setGstin(gstin);
                      gstr1ab2binvoice.setTaxPeriod(retPeriod);
                      session.save(gstr1ab2binvoice);
                      if(ordinal.getAndIncrement() %20 == 0) {
                           session.flush();
                           session.clear();
                      }
                 });
                 tx.commit();
                 session.close();        
            });
            response = Constant.SUCCESS;
        }catch(Exception e){
            e.printStackTrace();
            tx.rollback();
            session.close();
            response = Constant.FAILED;
        }
        return response;
}

	@Override
	public String insertGSTR1FFStatus(String gstin, String retPeriod, String status) throws Exception {

		List<String> inputParams = new ArrayList<>();
		String updateResp = "";
		try {
			
			inputParams.add(retPeriod);
			inputParams.add(gstin);
			inputParams.add(status);
			updateResp = insertGstr1FFEntry(inputParams);

		} catch (Exception e) {
			//LOGGER.error("Exception in GSTR2AServiceImpl.updateGSTR2AStatus() : " + e);
			throw new Exception("Exception in GSTR2AServiceImpl.updateGSTR2AStatus() : " + e);
		}
		return updateResp;
	}
	
	@Override
    public String insertGSTR1FFStatus(List<String> outputParamList) {
		
		if(logger.isInfoEnabled()){
         logger.info("*********** entering Job insertGstr2AStatus() :  " + outputParamList.get(0));
		}
         
         try{
        	 Date now = new Date(); 
        	 Timestamp ts = new Timestamp(now.getTime());
           TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
         
         TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
         tblGstinRetutnFilingStatusPK.setGstinId(outputParamList.get(1));
         tblGstinRetutnFilingStatusPK.setReturnType(Constant.GSTR1FF);
         tblGstinRetutnFilingStatusPK.setTaxPeriod(outputParamList.get(0));            
         tblGstinRetutnFilingStatus.setStatus(outputParamList.get(2));
         tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
         tblGstinRetutnFilingStatus.setIsSuccess(Boolean.TRUE);
         tblGstinRetutnFilingStatus.setUpdatedDate(ts);
         hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
        
		} catch (Exception e) {
			 logger.error("*********** ERROR in insertGstr2AStatus() : "+ e);
		} 
         return "Success";
    }
	
	@SuppressWarnings({ "unchecked" })
	@Override
	public TblGstinRetutnFilingStatus getGSTR1FFEntry (List<String> outputParamList) {
		DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
		detachedCriteria.add(Restrictions.eq("id.gstinId", outputParamList.get(1)));
		detachedCriteria.add(Restrictions.eq("id.taxPeriod", outputParamList.get(0)));
		detachedCriteria.add(Restrictions.eq("id.returnType", outputParamList.get(0)));
		List<TblGstinRetutnFilingStatus> gstinRetutnFiling = null;
		try{
			gstinRetutnFiling = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
			if(gstinRetutnFiling!=null && !gstinRetutnFiling.isEmpty()){
				return gstinRetutnFiling.get(0);
			}
		}
		catch(Exception ex){
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getStatusFor1FF" +ex);
		}
		return null;
	}
	
	@SuppressWarnings({ "unchecked" })
	@Override
	public TblGstinRetutnFilingStatus checkGSTR1FFEntry (String gstinId, String taxPeriod) {
		
		DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
		detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
		detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
		detachedCriteria.add(Restrictions.eq("id.returnType", "GSTR1FF"));
		List<TblGstinRetutnFilingStatus> gstinRetutnFiling = null;
		try{
			gstinRetutnFiling = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
			if(gstinRetutnFiling!=null && !gstinRetutnFiling.isEmpty()){
				return gstinRetutnFiling.get(0);
			}
		}
		catch(Exception ex){
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getStatusFor1FF" +ex);
		}
		return null;
	}
	
	public String insertGstr1FFEntry(List<String> outputParamList) {
		if(logger.isInfoEnabled()){
		logger.info("*********** entering Job insertGstr2AFilingStatus " +outputParamList.get(0));
		}
		TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
		
		TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
		tblGstinRetutnFilingStatusPK.setGstinId(outputParamList.get(0));
		tblGstinRetutnFilingStatusPK.setReturnType(Constant.FILING_RECORD_TYPE_GSTR2A);
		tblGstinRetutnFilingStatusPK.setTaxPeriod(outputParamList.get(1));
		tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
		tblGstinRetutnFilingStatus.setStatus(Constant.FILING_RECORD_TYPE_GSTR2A_DONE);
		hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
		if(logger.isInfoEnabled()){
		logger.info("*********** exiting Job insertGstr2AFilingStatus " +outputParamList.get(0));
		}
		return "success";
	}
}
