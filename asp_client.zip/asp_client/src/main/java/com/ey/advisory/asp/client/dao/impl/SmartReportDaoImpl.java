package com.ey.advisory.asp.client.dao.impl;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.SmartReportDao;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.SmartReport;
import com.ey.advisory.asp.client.dto.SmartReportDto;
import com.ey.advisory.asp.common.Constant;
@Repository
public class SmartReportDaoImpl implements SmartReportDao{
	
	@Autowired
	private HibernateDao hibernateDao;
	
	private static final Logger LOGGER = Logger.getLogger(SmartReportDaoImpl.class);
	private static final String CLASS_NAME = SmartReportDaoImpl.class.getName();
	public static final String[] purchaseStagingCols = {"id","fileID","sourceIdentifier","sourceFileName","gLAccountCode","division","subDivision","profitCentre1","profitCentre2","plantCode","taxPeriod","CGSTIN","documentType","supplyType","documentNo","documentDate","originalDocumentNo","originalDocumentDate","CRDRPreGST","lineNumber","SGSTIN","originalSGSTIN","supplierName","supplierCode","pos","portCode","billOfEntry","billOfEntryDate","CIFValue","customDuty","HSNorSAC","itemCode","itemDescription","itemCategory","unitofMeasurement","quantity","taxableValue","IGSTRate","IGSTAmount","CGSTRate","CGSTAmount","SGSTRate","SGSTAmount","cessRateAdvalorem","cessAmountAdvalorem","cessRateSpecific","cessAmountSpecific","invoiceValue","reverseCharge","eligibilityIndicator","commonSupplyIndicator","availableIGST","availableCGST","availableSGST","availableCESS","ITCReversalIdentifier","reasonForCreditDebitNote","purchaseVoucherNumber","purchaseVoucherDate","paymentVoucherNumber","dateofPayment","contractdate","contractValue","userdefinedfield1","userdefinedfield2","userdefinedfield3","eySuggestedResponse","clientResponse"};
    public static final String[] salesStagingCols = {"id","fileID","sourceIdentifier","sourceFileName","glAccountCode","division","subDivision","ProfitCentre1","ProfitCentre2","plantCode","taxperiod","sGSTIN","documentType","supplyType","documentNo","documentDate","originalDocumentNo","originalDocumentDate","cRDRPreGST","lineNumber","cGSTIN","uinORComposition","OriginalCGSTIN","customerName","customerCode","billToState","shipToState","pos","portCode","shippingBillNo","shippingBillDate","fob","exportDuty","hsnsac","itemCode","itemDescription","itemCategory","unitofMeasurement","qtySupplied","taxableValue","igstRate","igstAmount","cgstRate","cgstAmount","sgstRate","sgstAmount","cessRateAdvalorem","cessAmountAdvalorem","cessRateSpecific","cessAmountSpecific","invoiceValue","reverseCharge","tcsFlag","eGSTIN","itcFlag","reasonForCreditDebitNote","accountingVoucherNumber","accountingVoucherDate","userdefinedfield1","userdefinedfield2","userdefinedfield3","subCategory","tableType"};

	@SuppressWarnings("unchecked")
	@Override
	public String saveSmartReportDetails(SmartReportDto smartReportDto) {
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " saveSmartReportDetails : Report Params : "+smartReportDto);
		}
		String smartReportId = "";
		try{
		Criteria criteria = hibernateDao.createNormalCriteria(SmartReport.class);
		criteria.add(Restrictions.eq("userId", smartReportDto.getUserid()));
		criteria.add(Restrictions.eq("fileCategory", smartReportDto.getReportType()));  
		criteria.add(Restrictions.eq("status", Constant.SUBMITTED_SMARTREPORT));  
		List<SmartReport> tblSmartReportDetails = criteria.list();
		if(tblSmartReportDetails.size()>25){
			return Constant.ERROR_MSG;
		}
		String smartReportXml = "";
		String reportRype = smartReportDto.getReportType();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("<query>");
		stringBuilder.append("<whereCondition>");
		stringBuilder.append("<reportType>").append(reportRype).append("</reportType>");
		stringBuilder.append("<financialYear>").append(smartReportDto.getFy()).append("</financialYear>");
		stringBuilder.append("<returnPeriod>").append(smartReportDto.getReturnPeriod()).append("</returnPeriod>");
		stringBuilder.append("<startDate>").append(smartReportDto.getStartDate()).append("</startDate>");
		stringBuilder.append("<endDate>").append(smartReportDto.getEndDate()).append("</endDate>");
		stringBuilder.append("<typeOfReport>").append(smartReportDto.getTypeOfReport()).append("</typeOfReport>");
		
		if(reportRype.equalsIgnoreCase("outwardsupplies")){
			stringBuilder.append("<summaryType>").append(String.join(",", smartReportDto.getSummaryType())).append("</summaryType>");
			stringBuilder.append("<typeOfSubmitReport>").append(String.join(",", smartReportDto.getSummaryType())).append("</typeOfSubmitReport>");
			stringBuilder.append("<docType>").append(String.join(",", smartReportDto.getDocType())).append("</docType>");
			stringBuilder.append("<supType>").append(String.join(",",smartReportDto.getSupplyType())).append("</supType>");
			stringBuilder.append("<recpGstin>").append(String.join(",",smartReportDto.getRecpGstin())).append("</recpGstin>");
		}else if(reportRype.equalsIgnoreCase("inwardsupplies")){
			stringBuilder.append("<docType>").append(String.join(",",smartReportDto.getDocType())).append("</docType>");
			stringBuilder.append("<supType>").append(String.join(",",smartReportDto.getSupplyType())).append("</supType>");
			stringBuilder.append("<eligibilityIndtr>").append(String.join(",",smartReportDto.getEligibilityIndicator())).append("</eligibilityIndtr>");
			if(smartReportDto.getReconResponse().size() > 0){
				stringBuilder.append("<reconResponse>").append(String.join(",",smartReportDto.getReconResponse())).append("</reconResponse>");
			}
			stringBuilder.append("<recpGstin>").append(String.join(",",smartReportDto.getRecpGstin())).append("</recpGstin>");
		}else if(reportRype.equalsIgnoreCase("stocktransfer")){
			stringBuilder.append("<recpGstin>").append(String.join(",",smartReportDto.getRecpGstin())).append("</recpGstin>");
		}else if(reportRype.equalsIgnoreCase("reversecharge")){
			stringBuilder.append("<revChgCategory>").append((String.join(",",smartReportDto.getRevChgCategory()))).append("</revChgCategory>");
			stringBuilder.append("<recpGstin>").append(String.join(",",smartReportDto.getRecpGstin())).append("</recpGstin>");
		}
		stringBuilder.append("</whereCondition>");		
		stringBuilder.append("<selectedCols>").append(getSelectedAttribs(smartReportDto.getAttribs(), reportRype)).append("</selectedCols>");
		stringBuilder.append("</query>");
		smartReportXml = String.valueOf(stringBuilder);
		SmartReport smartReport = new SmartReport();
		smartReport.setTaxPeriod(smartReportDto.getFy().substring(2).concat(smartReportDto.getReturnPeriod()));
		smartReport.setParams(smartReportXml);
		smartReport.setFileCategory(smartReportDto.getReportType());
		smartReport.setStatus("Submitted");
		Date now = new Date(); 
    	Timestamp ts = new Timestamp(now.getTime());
		smartReport.setCreatedDate(ts);
		smartReport.setUserId(smartReportDto.getUserid());
		hibernateDao.save(smartReport);
		smartReportId = smartReport.getReportId();
		//smartReportId = "Thanks for the request! You can download the report after 24 Hours. Report id : "+smartReport.getReportId()+	"\n. You can check the status of the report in smart report status page.";
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " saveSmartReportDetails");
			}
		}catch(Exception e){
			smartReportId = "Error occurred while requesting. Please contact admin.";
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " saveSmartReportDetails ", e);
		}
		return smartReportId;
}
		
	
	
	public String getSelectedAttribs(List<String> attribs, String reportType){
		List<String> orderedattribs = new LinkedList<String>();
		if(reportType.equalsIgnoreCase("inwardsupplies") || reportType.equalsIgnoreCase("reversecharge")){
			String[] purrchseStagingCols = purchaseStagingCols;
			for (String col : purrchseStagingCols){
				if(attribs.stream().anyMatch(col::equalsIgnoreCase)){
					orderedattribs.add(col);
				}
			}
		}
		if(reportType.equalsIgnoreCase("outwardsupplies") || reportType.equalsIgnoreCase("stocktransfer")){
			for (String col : salesStagingCols){
				if(attribs.stream().anyMatch(col::equalsIgnoreCase)){
					orderedattribs.add(col);
				}
			}
		}
		StringBuilder stringBuilder = new StringBuilder();
		if(null != orderedattribs || orderedattribs != null){
		Iterator<String> it = orderedattribs.iterator();
		while(it.hasNext()){
			stringBuilder.append("<Column>").append(it.next()).append("</Column>");
		}
		}
		return String.valueOf(stringBuilder);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SmartReport> getSmartReportDetails(String status) {
		List<SmartReport> requestSubmittedList = null;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getSmartReportDetails : Params : status " + status);
		}
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(SmartReport.class);
			detachedCriteria.add(Restrictions.eq("status", status));
			requestSubmittedList = (List<SmartReport>) hibernateDao.find(detachedCriteria);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getSmartReportDetails : SmartReport size "+requestSubmittedList.size());
			}
		} catch (Exception e) {
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getSmartReportDetails ",e);
		}
		return requestSubmittedList;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public SmartReport getSmartReportDetailsByReportId(String reportId) {
		List<SmartReport> requestSubmittedList = null;
		SmartReport smartReport=null;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getSmartReportDetails : Params : status " + reportId);
		}
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(SmartReport.class);
			detachedCriteria.add(Restrictions.eq("reportId", reportId.trim()));
			requestSubmittedList = (List<SmartReport>) hibernateDao.find(detachedCriteria);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getSmartReportDetails : SmartReport size "+requestSubmittedList.toString());
			}
		} catch (Exception e) {
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getSmartReportDetails ",e);
		}
		if(requestSubmittedList!=null && requestSubmittedList.size()>0){
			
			 smartReport = requestSubmittedList.get(0);
		}
		return smartReport;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean updateSmartReportPathAndFileName(String reportId, String filePath, String fileName) {
		boolean result = true;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD
					+ " updateSmartReportPathAndFileName : Report Params : reportId " + reportId + " filePath "
					+ filePath + " fileName " + fileName);
		}
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(SmartReport.class);
			detachedCriteria.add(Restrictions.eq("reportId", reportId));
			List<SmartReport> requestSubmittedList = (List<SmartReport>) hibernateDao.find(detachedCriteria);
			if (requestSubmittedList != null && !requestSubmittedList.isEmpty()) {
				SmartReport reportDetails = requestSubmittedList.get(0);
				reportDetails.setFilePath(filePath);
				reportDetails.setFileName(fileName);
				Date now = new Date(); 
		    	Timestamp ts = new Timestamp(now.getTime());
				reportDetails.setUpdatedDate(ts);
				reportDetails.setStatus(Constant.GENERATE_SMARTREPORT);
				hibernateDao.update(reportDetails);
			}
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " updateSmartReportPathAndFileName");
			}
		} catch (Exception ex) {
			result = false;
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " updateSmartReportPathAndFileName ",ex);
		}
		return result;
	}



	@SuppressWarnings("unchecked")
	@Override
	public boolean updateSmartReportStatus(String reportId, String status) {
		boolean result = true;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " updateSmartReportStatus : Report Params : reportId " + reportId + " status " + status);
		}
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(SmartReport.class);
			detachedCriteria.add(Restrictions.eq("reportId", reportId));
			List<SmartReport> requestSubmittedList = (List<SmartReport>) hibernateDao.find(detachedCriteria);
			if (requestSubmittedList != null && !requestSubmittedList.isEmpty()) {
				SmartReport reportDetails = requestSubmittedList.get(0);
				reportDetails.setUpdatedDate(new Date());
				reportDetails.setStatus(status);
				hibernateDao.update(reportDetails);
			}
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " updateSmartReportStatus");
			}
		} catch (Exception ex) {
			result = false;
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " updateSmartReportStatus ",ex);
		}
		return result;
	}
	
	public boolean findByApi(String gstin, String retPeriod, String api){
		boolean present = false;

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " findByApi");
		}
		Session session = hibernateDao.getSession();
		try {
			StringBuilder queryStr = new StringBuilder();
			queryStr.append("SELECT t FROM ");
			queryStr.append(getTableName(api));
			queryStr.append("WHERE t.Gstin = :Gstin ");
			queryStr.append("AND ");
			queryStr.append("WHERE t.TaxPeriod = :TaxPeriod");
			
			Query query =session.createQuery(queryStr.toString());
			query.setParameter("Gstin", gstin);
			query.setParameter("TaxPeriod",retPeriod);
			if(query.list().size() > 0)	
				present = true;
			
		} catch (Exception e) {
			//logger.error("Exception in fetchHierarchyList" + e);
		}
		finally{
            if(session !=null && session.isOpen()){
                   session.close();
            }
      }  
	
		
		
		return present;
	}
	
	private String getTableName(String strConstant){
		switch (strConstant) {
		case Constant.GSTR1FF_B2B:
			return "tblB2BInvoiceDetails";
			
			default :
				return null;

		 
		}
	}



	@Override
	public String saveGSTR1FFB2B(String jsonStr, String gstin,
			String retPeriod, Integer chunkId) {
		// TODO Auto-generated method stub
		return null;
	}

}
