package com.ey.advisory.asp.client.service;

public interface InvoiceService {
	boolean markTechErrorInvoiceStatus(Integer fileId) throws Exception;
}
