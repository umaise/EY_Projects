package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the GSTR1B2B_InvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2BAInvoiceDetails",schema="gstr1")
public class GSTR1B2BA_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID", unique=true, nullable=false)
	private long id;

	@Column(name="Chksum")
	private String chksum;

	@Column(name="CustGSTIN")
	private String custGSTIN;

	@Column(name="Etin")
	private String etin;

	@Column(name="FileID")
	private long fileID;

	@Column(name="Flag")
	private String flag;

	@Column(name="Gstin")
	private String gstin;

	@Column(name="InvDate")
	private Date invDate;

	@Column(name="InvNum")
	private String invNum;

	@Column(name="InvValue")
	private BigDecimal invValue;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="OrderDt")
	private Date orderDt;

	@Column(name="OrderNo")
	private String orderNo;

	@Column(name="OrgInvDate")
	private Date orgInvDate;

	@Column(name="OrgInvNum")
	private String orgInvNum;

	@Column(name="POS")
	private String pos;

	@Column(name="ProvAsses")
	private String provAsses;

	@Column(name="RChrg")
	private String RChrg;

	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;

	@Column(name="TaxPeriod")
	private String taxPeriod;

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getChksum() {
		return this.chksum;
	}

	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	public String getCustGSTIN() {
		return this.custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getEtin() {
		return this.etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Date getInvDate() {
		return this.invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getInvNum() {
		return this.invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public BigDecimal getInvValue() {
		return this.invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public Date getOrderDt() {
		return this.orderDt;
	}

	public void setOrderDt(Date orderDt) {
		this.orderDt = orderDt;
	}

	public String getOrderNo() {
		return this.orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Date getOrgInvDate() {
		return this.orgInvDate;
	}

	public void setOrgInvDate(Date orgInvDate) {
		this.orgInvDate = orgInvDate;
	}

	public String getOrgInvNum() {
		return this.orgInvNum;
	}

	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	public String getPos() {
		return this.pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getProvAsses() {
		return this.provAsses;
	}

	public void setProvAsses(String provAsses) {
		this.provAsses = provAsses;
	}

	public String getRChrg() {
		return this.RChrg;
	}

	public void setRChrg(String RChrg) {
		this.RChrg = RChrg;
	}

	public BigDecimal getTaxablevalue() {
		return this.taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	
}