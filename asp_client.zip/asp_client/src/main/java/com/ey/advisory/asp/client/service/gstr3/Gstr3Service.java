package com.ey.advisory.asp.client.service.gstr3;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.client.domain.CashITCUtilization;
import com.ey.advisory.asp.client.domain.CashUtilizationTransaction;
import com.ey.advisory.asp.client.domain.FIleSubmissionStatusDetails;
import com.ey.advisory.asp.client.domain.Gstr3RefundDetails;
import com.ey.advisory.asp.client.domain.Gstr3TurnoverDetails;
import com.ey.advisory.asp.client.domain.ReturnSubmissionStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.dto.DashBoardMapDto;
import com.ey.advisory.asp.client.dto.GSTR3RootDTO;
import com.ey.advisory.asp.client.dto.Gstr3Dto;
import com.ey.advisory.asp.client.dto.MapGstinDto;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.dto.GSTR3InterestLiablityDto;
import com.ey.advisory.asp.exception.DataException;
import com.ey.advisory.asp.exception.ServiceLayerException;

/**
 * Service contains all the methods related to GSTR1 form
 *
 */
public interface Gstr3Service {

	public String sendGSTR3Data(int fileId, String jsonGstr1Data);

	String gstr3Summary(String gstn, String month, String year);

	String signfileGstr3(String gstn, String month, String year);

	String generateReturns(int fileId, String jsonGstr3Data);

	public String gstr3RetStatus(String gstin, String month, String year);

	public String getCashLedgerSummary(Gstr3Dto gstr3Dto) throws Exception;

	public String getItcLedgerSummary(Gstr3Dto gstr3Dto) throws Exception;

	public String getGstr3Summary(Gstr3Dto gstr3Dto);

	public String getLiabilityLedgerDetail(String gstn, String rtPeriod,
			String liabilityType) throws Exception;

	public String utilizeCash(String cashUtilJson) throws Exception;

	public String utilizeItc(String cashUtilJson) throws Exception;

	public String saveTurnoverDetials(Gstr3TurnoverDetails gstr3TurnoverDetails);

	public boolean fetchRecordfromDB(Gstr3Dto gstr3Dto) throws ServiceLayerException;

	TblGstinRetutnFilingStatus getGStrReturnFilingDetails(String gstnID,
			String taxPeriod, String returnType);

	public String saveGstr3CashLegderDetails(String gstn,
			String jsonCashGstr3Data, String rtPeriod);

	public String saveGstr3ITCLegderDetails(String gstn,
			String jsonITCGstr3Data, String rtPeriod);

	public String saveGstr3LiabilityLedgerDetail(String gstn, String rtPeriod,
			String jsonGstr3Data);

	public Gstr3TurnoverDetails getTurnoverDetials(Gstr3Dto gstr3Dto);

	public String getDebitNo(Gstr3RefundDetails gstr3RefundDetails);

	public List<String> getCashAutoFill(String gstn, String rtDate);

	String fileGSTR3(SummaryDto summarydto);

	public String saveCashUtilizationTransaction(Gstr3Dto gstr3Dto)
			throws Exception;

	public String saveReturnSubmissionStatus(
			ReturnSubmissionStatus rtSubmissionStatus) throws Exception;

	public DashBoardMapDto getDashBoardMapDto(
			List<MapGstinDto> sessionInputGstinList);

	Object[] getFileGstr3Status(Gstr3Dto gstr3Dto);

	public List<CashUtilizationTransaction> getCashUtilizationTransaction(
			Gstr3Dto gstr3Dto);

	String saveGstr3FileSubmStatus(
			FIleSubmissionStatusDetails fIleSubmissionStatusDetails);

	List<ReturnSubmissionStatus> getITCCashDetials(Gstr3Dto gstr3Dto);

	public String saveRefundDetails(Gstr3RefundDetails gstr3RefundDetails);

	public String getLiabilityPosition(Gstr3Dto gstr3Dto);

	public String getCashPosition(Gstr3Dto gstr3Dto);

	public String getITCPosition(Gstr3Dto gstr3Dto);

	public boolean isPreviousTaxPeriodFiled(Gstr3Dto gstr3Dto);

	public String getConsCashTransaction(Gstr3Dto gstr3Dto);

	public String autoFillItc(Gstr3Dto gstr3Dto);

	public String saveItc(Gstr3Dto gstr3Dto);

	public String submitItc(Gstr3Dto gstr3Dto);

	public String getItcBalance(Gstr3Dto gstr3Dto);

	Gstr3RefundDetails getRefundDetail(Gstr3RefundDetails gstr3RefundDetails);

	public String getInterestLiabilitySaved(Gstr3Dto gstr3Dto);

	public String saveGstr3Details(int masterId,GSTR3RootDTO dto) throws ServiceLayerException;

	public String getSummaryJSON(Gstr3Dto gstr3Dto) throws ServiceLayerException;
    public String getLiabilityDetails(Gstr3Dto gstr3Dto);
	public int findMasterDetails(Gstr3Dto gstr3Dto) throws ServiceLayerException;
	
	public String saveInterestLiability(GSTR3InterestLiablityDto dto);

	public boolean updateInterestLiabilitySubmit(String refId,Gstr3Dto gstr3Dto); 
	public String saveCashItcBalance(String cashITCJson, String gstin, String taxPeriod);
	public String saveEditedCashItcDetails(String cashITCJson);
	public List<CashITCUtilization> getEditedCashItcDetails(String gstinId, String taxPeriod);
	public String updateActiveStatus(Gstr3Dto gstr3dto);
	public Map<String, String> isSubmitGSTR3FormSection(Gstr3Dto gstr3Dto) throws ServiceLayerException; 
	
	public boolean updateSetoffLiabilitySubmit(String refId, Gstr3Dto gstr3dto);
	public boolean updateGstr3Submit(String gstin, String taxperiod);
	
	String getSetoffLiabilityJsonSaved(Gstr3Dto gstr3Dto); 
	public String getsubmitGstr3toGstnJson(Gstr3Dto gstr3dto); 
	
	public boolean insertGstr3GenerateData(String refId, Gstr3Dto gstr3dto);
	public Map<String, Boolean> isGtsr1AndGstr2Filed(Gstr3Dto gstr3dto); 
	
	public boolean isGSTR3Generated(Gstr3Dto gstr3Dto);
}
