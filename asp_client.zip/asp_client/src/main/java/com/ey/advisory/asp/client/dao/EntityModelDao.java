package com.ey.advisory.asp.client.dao;


import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.TblDivision;
import com.ey.advisory.asp.client.dto.GroupDto;


public interface EntityModelDao {
	
	public List<EntityModel> fetchEntityDetails();
	public EntityModel getEntityDetails(String entityId);
	public List<EntityModel> fetchEntitiesByGroupId(String groupId);
	public List<TblDivision> fetchDivisionByEntityId(Integer entityId);
	public List<String> fetchGSTINIdByEntity(Integer entityID);
	public JSONArray fetchDivAndGSTIn(String id, boolean flag);
	public void saveUserInClientTables(JSONObject groupJson, int userId);
	public JSONObject fetchClientSideUserTablesAsJson(int userId,List<GroupDto> groupIds);
	public void updateUserInClientTables(JSONObject groupJson,int userID);
	public void deleteObject(JSONObject json);
	public List<EntityModel> getEntityDetails(List<Integer> entityId);
	public String fetchEntityNameById(Integer entityID);
	public String isEntityExitsWithName(String entityName);
	public String saveEntityData(EntityModel entity) throws Exception;
}
