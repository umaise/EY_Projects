package com.ey.advisory.asp.client.service;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.client.dto.AuthDetailsDto;
import com.ey.advisory.asp.client.dto.Gstr3Dto;
import com.ey.advisory.asp.client.util.AuthenticationUtility;
import com.ey.advisory.asp.client.util.GSPRestUtility;
import com.ey.advisory.asp.client.util.GSTNRestUtility;
import com.ey.advisory.asp.common.Constant;

@Component(value="GSP")
@PropertySource("classpath:GSPConfig.properties")
public class GSPApiServiceImpl implements CommonApiService{

	@Autowired
	private Environment env;
	
	@Autowired
	private GSPRestUtility gspRestUtility;
	@Autowired
	AuthenticationUtility authenticationUtility;
	
	@Autowired
	private GSTNRestUtility gstnRestUtility;
	
	private static final Logger LOGGER = Logger.getLogger(GSPApiServiceImpl.class);
	private static final String CLASS_NAME = GSPApiServiceImpl.class.getName();

	@Override
	public String gstr1Summary(String gstinId, String month, String year) {
		HttpHeaders httpHeaders = new HttpHeaders();
		
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr1Summary")+"?action="+Constant.RETSUM+
				"&ret_period="+month+year+"&gstin="+gstinId;
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
		
	}
	@Override
	public String sendGSTR1Data(AuthDetailsDto authDetails) {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING+ CLASS_NAME + " Method : sendGSTR1Data");
		}
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		try {
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr1Summary");
		
			String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.RETSAVE);
			return 	gspRestUtility.executeRestCall(httpHeaders, inputData,resource, HttpMethod.PUT);
		} catch (IOException e) {
			if(LOGGER.isInfoEnabled()){
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : sendGSTR1Data"
					+e);
			}
			return e.getMessage();
		}
	}

	@Override
	public String gstr3Summary(String gstinId, String month, String year) {
		HttpHeaders httpHeaders = new HttpHeaders();
		
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr3Summary")+"?action="+Constant.RETDET+
				"&ret_period="+month+year+"&gstin="+gstinId;
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
		
	}
	

	@Override
	public String sendGSTR3Data(AuthDetailsDto authDetails) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		try {
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr3Summary");
		
			String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.RETSAVE);
			return 	gspRestUtility.executeRestCall(httpHeaders, inputData,resource, HttpMethod.PUT);
		} catch (IOException e) {
			
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : sendGSTR3Data"
					+e);
			// TODO Auto-generated catch block
			return e.getMessage();
		}
	}
	
	@Override
	public String signfileGstr3(String gstinId, String month, String year) {
		HttpHeaders httpHeaders = new HttpHeaders();
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr3Summary")+"?action="+Constant.RETDET+
				"&ret_period="+month+year+"&gstin="+gstinId;
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}

	@Override
	public String gstr3RetStatus(String gstinId, String month, String year) {
		HttpHeaders httpHeaders = new HttpHeaders();
		
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr3Summary")+"?action="+Constant.RETSTATUS+
				"&ret_period="+month+year+"&gstin="+gstinId;
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}

	@Override
	public String generateReturns(AuthDetailsDto authDetails) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		try {
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr3Summary");
		
			String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.GENERATE);
			return 	gspRestUtility.executeRestCall(httpHeaders, inputData,resource, HttpMethod.POST);
		} catch (IOException e) {
			

			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : generateReturns"
					+e);
			// TODO Auto-generated catch block
			return e.getMessage();
		}
	}
	@Override
	public String getCashLedgerSummary(Gstr3Dto gstr3Dto) {
		HttpHeaders httpHeaders = new HttpHeaders();
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-getCashLedgerSummary")+"?action="+Constant.CASHSUM+
				"&gstin="+gstr3Dto.getGstin()+"&fr_dt="+gstr3Dto.getFromDate()+"&to_dt="+gstr3Dto.getToDate();
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}
	@Override
	public String getItcLedgerSummary(Gstr3Dto gstr3Dto) {
		HttpHeaders httpHeaders = new HttpHeaders();
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-getItcLedgerSummary")+"?action="+Constant.ITCSUM+
				"&gstin="+gstr3Dto.getGstin()+"&fr_dt="+gstr3Dto.getFromDate()+"&to_dt="+gstr3Dto.getToDate();
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}
	@Override
	public String getGstr3Summary(Gstr3Dto gstr3Dto) {
		HttpHeaders httpHeaders = new HttpHeaders();
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-getGstr3Summary")+"?action="+Constant.RETDET+
				"&gstin="+gstr3Dto.getGstin()+"&ret_period="+gstr3Dto.getRtPeriod();
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}
	

	/**
	 * 
	 */
	@Override
	public String getLiabilityLedgerDetail(String gstn, String rtPeriod, String liabilityType) throws Exception{
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering " + CLASS_NAME + " Method : getLiabilityLedgerDetail");
		}
		String liabilityLedgerJson="";
		StringBuilder uri = new StringBuilder("?action="+ Constant.TAX + "&gstin=" + gstn + "&rt_period=" + rtPeriod + "&liab_typ=" + liabilityType);
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			String resource = env.getProperty("gsp-restapi.host") + env.getProperty("gsp-getLiabilityLedgerDetail") +uri.toString() ;
			liabilityLedgerJson = gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
		} catch (Exception exception) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getLiabilityLedgerDetail" ,exception);
			throw exception;
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Exiting " + CLASS_NAME + " Method : getLiabilityLedgerDetail");
		}
		return liabilityLedgerJson;
	}
	
	/**
	 * 
	 */
	@Override
	public String utilizeCash(AuthDetailsDto authDetails) throws Exception{
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering " + CLASS_NAME + " Method : utilizeCash");
		}
		String cashUtilJson="";
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
			String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-utilizeCash");
				String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.UTLCSH);
				cashUtilJson =	gspRestUtility.executeRestCall(httpHeaders, inputData,resource, HttpMethod.POST);
		} catch (Exception exception) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : utilizeCash" ,exception);
			throw exception;
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Exiting " + CLASS_NAME + " Method : utilizeCash");
		}
		return cashUtilJson;
	}
	
	/**
	 * 
	 */
	@Override
	public String utilizeItc(AuthDetailsDto authDetails) throws Exception{
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering " + CLASS_NAME + " Method : utilizeITC");
		}
		String itcUtilJson="";
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
			String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-utilizeItc");
				String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.UTLITC);
				itcUtilJson =	gspRestUtility.executeRestCall(httpHeaders, inputData,resource, HttpMethod.POST);
		} catch (Exception exception) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : utilizeItc" ,exception);
			throw exception;
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Exiting " + CLASS_NAME + " Method : utilizeITC");
		}
		return itcUtilJson;
	}
	
	/*********************GSTR2 related method *****************************************************/
	
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.gstr1.CommonApiService#sendGSTR2Data(com.ey.advisory.asp.client.dto.AuthDetailsDto)
	 * To call GSP for saving gstr2 data and get response of transaction Id
	 */
	@Override
	public String sendGSTR2Data(AuthDetailsDto authDetails) {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING+ CLASS_NAME + " Method : sendGSTR2Data");
		}
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		try {
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr2Summary");
		
			String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.RETSAVE);
			return 	gspRestUtility.executeRestCall(httpHeaders, inputData,resource, HttpMethod.PUT);
		} catch (IOException e) {
			if(LOGGER.isInfoEnabled()){
			LOGGER.info(Constant.LOGGER_ERROR+ CLASS_NAME + " Method : sendGSTR2Data"+e);
			}
			return e.getMessage();
		}
	}
	@Override
	public String gstr2Summary(String gstinId, String month, String year) {
		HttpHeaders httpHeaders = new HttpHeaders();
		
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr2Summary")+"?action="+Constant.RETSUM+
				"&ret_period="+month+year+"&gstin="+gstinId;
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
		
	}
	@Override
	public String signfileGstr6(String gstinId, String month, String year) {
		HttpHeaders httpHeaders = new HttpHeaders();
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr3Summary")+"?action="+Constant.RETDET+
				"&ret_period="+month+year+"&gstin="+gstinId;
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}
	
	@Override
	public String gstr6Summary(String sectionSumm,String gstinId, String month, String year) {
		HttpHeaders httpHeaders = new HttpHeaders();
		
		String resource = env.getProperty("gsp-restapi.host")+env.getProperty("gsp-gstr6Summary")+"?action="+Constant.RETSUM+
				"&ret_period="+month+year+"&gstin="+gstinId;
		return 	gspRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
		
	}

}
