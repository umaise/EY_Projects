package com.ey.advisory.asp.client.service;

import com.ey.advisory.asp.client.dto.AuthDetailsDto;
import com.ey.advisory.asp.client.dto.Gstr3Dto;

public interface CommonApiService {

	public String gstr1Summary(String gstinId, String month, String year);
	public String sendGSTR1Data(AuthDetailsDto authDetails);
	public String gstr2Summary(String gstinId, String month, String year);
	
	public String gstr3Summary(String gstinId, String month, String year);
	public String signfileGstr3(String gstinId, String month, String year);
	
	public String sendGSTR3Data(AuthDetailsDto authDetails);
	public String gstr3RetStatus(String gstinId, String month, String year);
	public String generateReturns(AuthDetailsDto authDetails);
	public String getCashLedgerSummary(Gstr3Dto gstr3Dto) throws Exception;
	public String getItcLedgerSummary(Gstr3Dto gstr3Dto) throws Exception;
	public String getGstr3Summary(Gstr3Dto gstr3Dto);
	public String getLiabilityLedgerDetail(String gstn, String rtPeriod, String liabilityType) throws Exception;
	public String utilizeCash(AuthDetailsDto authDetails) throws Exception;
	public String utilizeItc(AuthDetailsDto authDetails) throws Exception;
	
	/*GSTR2 related methods*/
	public String sendGSTR2Data(AuthDetailsDto authDetails);
	
	public String signfileGstr6(String gstinId, String month, String year);
	public String gstr6Summary(String sectionSumm,String gstinId, String month, String year);
	
}
