package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@SuppressWarnings("serial")
@Embeddable
public class Gstr2B2BItemDetailsPK implements Serializable{
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "InvoiceDetailsId" , referencedColumnName="ID")
    private Gstr2B2BInvoiceDetailsModel invoiceDetails;
    
    @Column(name="[LineNo]")
    private Integer lineNo;

    public Gstr2B2BInvoiceDetailsModel getInvoiceDetails() {
        return invoiceDetails;
    }

    public void setInvoiceDetails(Gstr2B2BInvoiceDetailsModel invoiceDetails) {
        this.invoiceDetails = invoiceDetails;
    }

    public Integer getLineNo() {
        return lineNo;
    }

    public void setLineNo(Integer lineNo) {
        this.lineNo = lineNo;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((lineNo == null) ? 0 : lineNo.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Gstr2B2BItemDetailsPK other = (Gstr2B2BItemDetailsPK) obj;
        if (lineNo == null) {
            if (other.lineNo != null)
                return false;
        }
        else if (!lineNo.equals(other.lineNo))
            return false;
        return true;
    }
    
    

}
