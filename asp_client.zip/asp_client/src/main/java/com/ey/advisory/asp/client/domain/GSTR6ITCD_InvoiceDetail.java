package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the GSTR6ITCD_InvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblITCDInvoiceDetails",schema="gstr6")
public class GSTR6ITCD_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR6ITCD_InvoiceDetail.class);

	@Id
	@Column(name="ID")
	private long GSTR6ITCD_InvoiceDetails_ID;

    @Column(name="Division")
    private String Division; 	    		  
    	    		  
	  @Column(name="SourceIdentifier")
	  private String SourceIdentifier; 
	  
	  @Column(name="SourceFileName")
	  private String SourceFileName; 
	  
	  @Column(name="GLAccountCode")
	  private String GLAccountCode; 
	  
	  @Column(name="Category")
	  private String Category; 
	  
  @Column(name="SubCategory")
  private String SubCategory; 
    	      
	@Column(name="GSTIN")
	private String gstin;

	@Column(name="PlantCode")
	private String plantCode;

	@Column(name="FileID")
	private long fileID;


	@Column(name="DocumentDate")
	private Date documentDate;

	@Column(name="DocumentNo")
	private String documentNo;

	@Column(name="InvoiceValue")
	private BigDecimal invValue;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="POS")
	private String pos;

	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;

	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="InvoiceKey")
	private String invoiceKey;


	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	//bi-directional many-to-one association to GSTR6ITCD_ItemDetail
	@OneToMany(mappedBy="gstr6itcdInvoiceDetail")
	private List<GSTR6ITCD_ItemDetail> gstr6itcdItemDetails;
	

	public GSTR6ITCD_InvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR6ITCD_InvoiceDetail ");
			}
	}

	public long getGSTR6ITCD_InvoiceDetails_ID() {
		return this.GSTR6ITCD_InvoiceDetails_ID;
	}

	public void setGSTR6ITCD_InvoiceDetails_ID(long GSTR6ITCD_InvoiceDetails_ID) {
		this.GSTR6ITCD_InvoiceDetails_ID = GSTR6ITCD_InvoiceDetails_ID;
	}	

	
	public List<GSTR6ITCD_ItemDetail> getGstr6itcdItemDetails() {
		return this.gstr6itcdItemDetails;
	}

	public void setGstr6itcdItemDetails(List<GSTR6ITCD_ItemDetail> gstr6itcdItemDetails) {
		this.gstr6itcdItemDetails = gstr6itcdItemDetails;
	}

	public GSTR6ITCD_ItemDetail addGstr6itcdItemDetail(GSTR6ITCD_ItemDetail gstr6itcdItemDetail) {
		getGstr6itcdItemDetails().add(gstr6itcdItemDetail);
		gstr6itcdItemDetail.setGstr6itcdInvoiceDetail(this);

		return gstr6itcdItemDetail;
	}

	public GSTR6ITCD_ItemDetail removeGstr6itcdItemDetail(GSTR6ITCD_ItemDetail gstr6itcdItemDetail) {
		getGstr6itcdItemDetails().remove(gstr6itcdItemDetail);
		gstr6itcdItemDetail.setGstr6itcdInvoiceDetail(null);

		return gstr6itcdItemDetail;
	}	
	

	public long getFileID() {
		return fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public BigDecimal getInvValue() {
		return invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public boolean isDelete() {
		return isDelete;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getDivision() {
		return Division;
	}

	public void setDivision(String division) {
		Division = division;
	}

	public String getSourceIdentifier() {
		return SourceIdentifier;
	}

	public void setSourceIdentifier(String sourceIdentifier) {
		SourceIdentifier = sourceIdentifier;
	}

	public String getSourceFileName() {
		return SourceFileName;
	}

	public void setSourceFileName(String sourceFileName) {
		SourceFileName = sourceFileName;
	}

	public String getGLAccountCode() {
		return GLAccountCode;
	}

	public void setGLAccountCode(String gLAccountCode) {
		GLAccountCode = gLAccountCode;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getSubCategory() {
		return SubCategory;
	}

	public void setSubCategory(String subCategory) {
		SubCategory = subCategory;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public Date getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public String getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public BigDecimal getTaxablevalue() {
		return taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	
}