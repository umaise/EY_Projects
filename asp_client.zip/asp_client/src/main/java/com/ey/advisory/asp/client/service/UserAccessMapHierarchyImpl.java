/**
 * 
 */
package com.ey.advisory.asp.client.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.UserAccessMapping;
import com.ey.advisory.asp.client.domain.UserClient;
import com.ey.advisory.asp.client.dto.EntityHierarchyDTO;
import com.ey.advisory.asp.common.Constant;

/**
 * @author Nitesh.Tripathi
 *
 */
@Service
public class UserAccessMapHierarchyImpl implements UserAccessMapHierarchy  {
	
	@Autowired
	private HibernateDao  hibernateDao;
	
	private static final Logger LOGGER = Logger.getLogger(UserAccessMapHierarchyImpl.class);
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<EntityHierarchy> fetchUserHierarchy(String accessLevel,String property, Object Value){
		DetachedCriteria detachedCriteria =hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq(property, Value));
		List<EntityHierarchy> response=(List<EntityHierarchy>)hibernateDao.find(detachedCriteria);
		return response;
	}
	
	
	@Override
	public void saveUserAccessMapping(UserClient userClient){
		for(String accessValue : userClient.getAccessValues()){
			UserAccessMapping userAccessMapping = new UserAccessMapping();
			userAccessMapping.setUserID(userClient.getUserId());
			userAccessMapping.setAccessLevel(userClient.getAccessLevel());
			userAccessMapping.setAccessValue(accessValue);
			hibernateDao.save(userAccessMapping);
		}
	}
	
	/**
	 * 
	 * @param oldEntityHier
	 * @param newEntityHier
	 */
	@Override
	public void updateUserAccessMappingbyEH(EntityHierarchy oldEntityHier, EntityHierarchy newEntityHier){
		
		
		
		if(oldEntityHier.getCircleCode() != null && newEntityHier.getCircleCode() != null){
			if(!oldEntityHier.getCircleCode().trim().equals(newEntityHier.getCircleCode().trim())){
				//update user access
				StringBuffer hqlForUpdate = new StringBuffer("UPDATE UserAccessMapping U ");
				hqlForUpdate.append(" set accessValue = '").append(newEntityHier.getCircleCode().trim()).append("'");
				hqlForUpdate.append(" where accessValue = '").append(oldEntityHier.getCircleCode().trim()).append("'");
				hibernateDao.bulkUpdate(hqlForUpdate.toString());
			}
		}
		
		if(oldEntityHier.getPlantCode() != null && newEntityHier.getPlantCode() != null){
			if(!oldEntityHier.getPlantCode().trim().equals(newEntityHier.getPlantCode().trim())){
				//update user access
				StringBuffer hqlForUpdate = new StringBuffer("UPDATE UserAccessMapping U ");
				hqlForUpdate.append(" set accessValue = '").append(newEntityHier.getPlantCode().trim()).append("'");
				hqlForUpdate.append(" where accessValue = '").append(oldEntityHier.getPlantCode().trim()).append("'");
				hibernateDao.bulkUpdate(hqlForUpdate.toString());
			}
		}
		
		if(oldEntityHier.getProfitCenterCode() != null && newEntityHier.getProfitCenterCode() != null){
			if(!oldEntityHier.getProfitCenterCode().trim().equals(newEntityHier.getProfitCenterCode().trim())){
				//update user access
				StringBuffer hqlForUpdate = new StringBuffer("UPDATE UserAccessMapping U ");
				hqlForUpdate.append(" set accessValue = '").append(newEntityHier.getProfitCenterCode().trim()).append("'");
				hqlForUpdate.append(" where accessValue = '").append(oldEntityHier.getProfitCenterCode().trim()).append("'");
				hibernateDao.bulkUpdate(hqlForUpdate.toString());
			}
		}
		

		if(oldEntityHier.getSubDivCode() != null && newEntityHier.getSubDivCode() != null){
			if(!oldEntityHier.getSubDivCode().trim().equals(newEntityHier.getSubDivCode().trim())){
				//update user access
				StringBuffer hqlForUpdate = new StringBuffer("UPDATE UserAccessMapping U ");
				hqlForUpdate.append(" set accessValue = '").append(newEntityHier.getSubDivCode().trim()).append("'");
				hqlForUpdate.append(" where accessValue = '").append(oldEntityHier.getSubDivCode().trim()).append("'");
				hibernateDao.bulkUpdate(hqlForUpdate.toString());
			}
		}
		
		if(oldEntityHier.getBusinessUnitCode() != null && newEntityHier.getBusinessUnitCode() != null){
			if(!oldEntityHier.getBusinessUnitCode().trim().equals(newEntityHier.getBusinessUnitCode().trim())){
				//update user access
				StringBuffer hqlForUpdate = new StringBuffer("UPDATE UserAccessMapping U ");
				hqlForUpdate.append(" set accessValue = '").append(newEntityHier.getBusinessUnitCode().trim()).append("'");
				hqlForUpdate.append(" where accessValue = '").append(oldEntityHier.getBusinessUnitCode().trim()).append("'");
				hibernateDao.bulkUpdate(hqlForUpdate.toString());
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<Long,String> fetchUserAccessMap(EntityHierarchyDTO entityHierarchyDTO) {
		Session session = hibernateDao.getSession();
		Map<Long,String> userIdLevelMap = new HashMap<Long,String>();
		try{
			String queryStr = "select a.userID, a.accessLevel FROM UserAccessMapping a where (a.accessLevel = :l3aAccessLevel and a.accessValue in (:l3aAccessList)) or "+
					"(a.accessLevel = :l3bAccessLevel and a.accessValue = :l3bAccessValue) or (a.accessLevel = :l4aAccessLevel and a.accessValue in (:l4aAccessList)) or "+
					"(a.accessLevel = :l4bAccessLevel and a.accessValue = :l4bAccessList) or (a.accessLevel = :l4cAccessLevel and a.accessValue in (:l4cAccessList)) or "+
					"(a.accessLevel = :l5AccessLevel and a.accessValue = :l5AccessList) order by a.gstinId desc ";
			
			Query query =session.createQuery(queryStr);
			query.setParameter("l3aAccessLevel", Constant.L3A_ACCESS_LEVEL);
			query.setParameter("l3aAccessList", entityHierarchyDTO.getCircleCodeList());
			query.setParameter("l3bAccessLevel", Constant.L3B_ACCESS_LEVEL);
			query.setParameter("l3bAccessValue", entityHierarchyDTO.getGstin());
			query.setParameter("l4aAccessLevel", Constant.L4A_ACCESS_LEVEL);
			query.setParameter("l4aAccessList", entityHierarchyDTO.getSubDivCodeList());
			query.setParameter("l4bAccessLevel", Constant.L4B_ACCESS_LEVEL);
			query.setParameter("l4bAccessList", entityHierarchyDTO.getProfitCenterList());
			query.setParameter("l4cAccessLevel", Constant.L4C_ACCESS_LEVEL);
			query.setParameter("l4cAccessList", entityHierarchyDTO.getBusinessCodeList());
			query.setParameter("l5AccessLevel", Constant.L5_ACCESS_LEVEL);
			query.setParameter("l5AccessList", entityHierarchyDTO.getPlantCodeList());
			List<Object[]> usersIdLevelList = (List<Object[]>)query.list();
			
			if(usersIdLevelList!=null && usersIdLevelList.size()>0){
				for(Object[] userIdLevel: usersIdLevelList){
					userIdLevelMap.put(((Integer)userIdLevel[0]).longValue(), (String)userIdLevel[1]);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in fetchUserAccessMap" + e);
		}
		finally{
            if(session !=null && session.isOpen()){
                   session.close();
            }
      }      
		return userIdLevelMap;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void deleteUserAccessMapping(UserClient userClient) throws Exception {
		
		UserAccessMapping userAccMap = hibernateDao.load(UserAccessMapping.class, userClient.getAccessLevelId());
		
		hibernateDao.delete(userAccMap);
		
		/*if(LOGGER.isInfoEnabled()){
			LOGGER.info("deleteUserAccessMapping for userid->"+userClient.getUserId());
			}
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(UserAccessMapping.class);
			detachedCriteria.add(Restrictions.eq("userID", userClient.getUserId()));
			detachedCriteria.add(Restrictions.eq("accessLevel", userClient.getAccessLevel()));
			detachedCriteria.add(Restrictions.eq("accessValue", userClient.getAccessValues().get(0)));
			List<UserAccessMapping> userMappingList=null;
			try{
				userMappingList = (List<UserAccessMapping>)hibernateDao.find(detachedCriteria);
				
				if(userMappingList==null || userMappingList.size()<=0){
					detachedCriteria =hibernateDao.createCriteria(UserAccessMapping.class);
					detachedCriteria.add(Restrictions.eq("userID", userClient.getUserId()));
					detachedCriteria.add(Restrictions.eq("accessLevel", userClient.getAccessLevel()));
					detachedCriteria.add(Restrictions.eq("accessValue", userClient.getAccessValues().get(1)));
					userMappingList = (List<UserAccessMapping>)hibernateDao.find(detachedCriteria);
				}
				hibernateDao.deleteAll(userMappingList);
			}catch(Exception e){
				LOGGER.error("deleteUserAccessMapping for userid->",e);
				throw new Exception (e);
			}*/
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserAccessMapping> fetchUserAccessMap(int userId, String searchText) throws Exception {
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("fetchUserAccessMap for userid->"+userId);
			}
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(UserAccessMapping.class);
			detachedCriteria.add(Restrictions.eq("userID", userId));
			if (searchText != null && searchText.trim().length() > 0) {
				searchText = searchText.trim();
				detachedCriteria.add(Restrictions.disjunction().add(Restrictions.ilike("accessLevel", searchText, MatchMode.ANYWHERE))
						.add(Restrictions.ilike("accessValue", searchText, MatchMode.ANYWHERE)));
			}
			List<UserAccessMapping> userMappingList=null;
			try{
				userMappingList = (List<UserAccessMapping>)hibernateDao.find(detachedCriteria);
			}catch(Exception e){
				LOGGER.error("fetchUserAccessMap for userid->",e);
				throw new Exception (e);
			}
		return userMappingList;
	}


	@Override
	public List<String> fetchAccessLevelByUserId(Integer userId) throws Exception {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("fetchUserAccessMap for userid->"+userId);
		}
		List<String> userMappingList=null;
		DetachedCriteria detachedCriteria =hibernateDao.createCriteria(UserAccessMapping.class);
		detachedCriteria.add(Restrictions.eq("userID", userId));
		detachedCriteria.setProjection(Projections.distinct(Projections.projectionList()
		        .add(Projections.property("accessLevel"))));
		try{
			userMappingList = (List<String>)hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			LOGGER.error("fetchUserAccessMap for userid->",e);
			throw new Exception (e);
		}
	return userMappingList;
	}
	
	
	@Override
	public List<UserAccessMapping> fetchUserHierarchy(String accessLevel, String Value){
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(UserAccessMapping.class);
		detachedCriteria.add(Restrictions.eq("accessLevel", accessLevel));		
		detachedCriteria.add(Restrictions.ilike("accessValue", Value, MatchMode.ANYWHERE));	
		detachedCriteria.setProjection(Projections.projectionList()
			      .add(Projections.property("userID"), "userID"));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(UserAccessMapping.class));
		List<UserAccessMapping> response=(List<UserAccessMapping>)hibernateDao.find(detachedCriteria);
		return response;
	}
	
}
