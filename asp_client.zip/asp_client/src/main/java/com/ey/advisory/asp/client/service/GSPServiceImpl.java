package com.ey.advisory.asp.client.service;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.util.GSPRestUtility;


@Service
@PropertySource("classpath:GSPRestConfig.properties")
public class GSPServiceImpl implements GSPService {

	@Autowired
	private GSPRestUtility gspRestUtility;
	
	private static final Logger LOGGER = Logger.getLogger(GSPRestUtility.class);

	@Autowired
	private Environment env;

	//TODO: revisit on HTTPServletRequest
	@Override
	public String registerASP(String emailAddress, String orgName,HttpServletRequest request) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		JSONObject obj = new JSONObject();
		StringWriter out = new StringWriter();
		try {
			obj.put("emailId", emailAddress);
			obj.put("company", orgName);
			obj.writeJSONString(out);
			return gspRestUtility.executeRestCall(httpHeaders,out.toString(),env.getProperty("gsp-registrationResource"),
					 HttpMethod.POST);
		} catch (IOException e) {
			LOGGER.error("Exception in registerASP"+e);
			return e.getMessage();
		}
		
	}

	

}
