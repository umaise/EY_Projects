package com.ey.advisory.asp.client.gstr1ff.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "tblB2BItemDetails", schema = "gstr1A")
@JsonIgnoreProperties(ignoreUnknown = true)
public class GSTR1FFB2B_ItemDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger
			.getLogger(GSTR1FFB2B_ItemDetail.class);

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	@Column(name = "[LineNo]")
	@JsonProperty("num")
	private int lineNo;

	@Column(name = "ItemTxval")
	@JsonProperty("txval")
	private BigDecimal item_Txval;

	@Column(name = "IGSTAmt")
	@JsonProperty("iamt")
	private BigDecimal IGST_Amt;

	@Column(name = "CGSTAmt")
	@JsonProperty("camt")
	private BigDecimal CGST_Amt;

	@Column(name = "SGSTAmt")
	@JsonProperty("samt")
	private BigDecimal SGST_Amt;

	@Column(name = "CessAmt")
	@JsonProperty("csamt")
	private BigDecimal CessAmt;

	@Column(name = "Rate")
	@JsonProperty("rt")
	private BigDecimal rate;

	// @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	@Column(name = "LoadDate")
	private Date loadDate;

	@Column(name = "LoadName")
	private String loadName;

	// bi-directional many-to-one association to GSTR1B2B_InvoiceDetail
	@ManyToOne
	@JoinColumn(name = "InvoiceDetailsID")
	private GSTR1FFB2B_InvoiceDetails gstr1ffb2bInvoiceDetail;

	@Transient
	@JsonProperty("itm_det")
	private GSTR1FFItemDto itemdet;

	public GSTR1FFItemDto getItemdet() {
		return itemdet;
	}

	public void setItemdet(GSTR1FFItemDto itemdet) {
		this.IGST_Amt = itemdet.getIamt();
		this.CGST_Amt = itemdet.getCamt();
		this.SGST_Amt = itemdet.getSamt();
		this.CessAmt = itemdet.getCess();
		this.item_Txval = itemdet.getItem_Txval();
		this.rate = itemdet.getRate();
		this.itemdet = itemdet;
	}

	public Date getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(Date loadDate) {
		this.loadDate = loadDate;
	}

	public String getLoadName() {
		return loadName;
	}

	public void setLoadName(String loadName) {
		this.loadName = loadName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getLineNo() {
		return lineNo;
	}

	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}

	public BigDecimal getItem_Txval() {
		return item_Txval;
	}

	public void setItem_Txval(BigDecimal item_Txval) {
		this.item_Txval = item_Txval;
	}

	public BigDecimal getIGST_Amt() {
		return IGST_Amt;
	}

	public void setIGST_Amt(BigDecimal iGST_Amt) {
		IGST_Amt = iGST_Amt;
	}

	public BigDecimal getCGST_Amt() {
		return CGST_Amt;
	}

	public void setCGST_Amt(BigDecimal cGST_Amt) {
		CGST_Amt = cGST_Amt;
	}

	public BigDecimal getSGST_Amt() {
		return SGST_Amt;
	}

	public void setSGST_Amt(BigDecimal sGST_Amt) {
		SGST_Amt = sGST_Amt;
	}

	public BigDecimal getCessAmt() {
		return CessAmt;
	}

	public void setCessAmt(BigDecimal cessAmt) {
		CessAmt = cessAmt;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public GSTR1FFB2B_InvoiceDetails getGstr1ffb2bInvoiceDetail() {
		return gstr1ffb2bInvoiceDetail;
	}

	public void setGstr1ffb2bInvoiceDetail(
			GSTR1FFB2B_InvoiceDetails gstr1ffb2bInvoiceDetail) {
		this.gstr1ffb2bInvoiceDetail = gstr1ffb2bInvoiceDetail;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}

}