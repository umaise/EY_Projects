package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;


/**
 * The persistent class for the tblIMPGInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblIMPGInvoiceDetails", schema=Constant.GSTR2_SCHEMA)
public class GSTR2IMPG_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR2IMPG_InvoiceDetail.class);

	@Id
	@Column(name="ID")
	private long id;
	
	@Column(name="Flag")
	private String flag;
	
	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="BillofEntryDate")
	private Date billofEntryDate;

	@Column(name="BillofEntryNum")
	private String billofEntryNum;

	@Column(name="BillofEntryValue")
	private BigDecimal billofEntryValue;

	@Column(name="TaxableValue")
	private BigDecimal taxableValue;

	@Column(name="PortCode")
	private String portCode;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="FileID")
	private long fileID;

	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="InvoiceKey")
	private String invoiceKey;
	
	@Column(name="SubCategory")
	private String subCategory;
	

	public GSTR2IMPG_InvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR2IMPG_InvoiceDetail ");
			}
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getBillofEntryDate() {
		return this.billofEntryDate;
	}

	public void setBillofEntryDate(Date billofEntryDate) {
		this.billofEntryDate = billofEntryDate;
	}

	public String getBillofEntryNum() {
		return this.billofEntryNum;
	}

	public void setBillofEntryNum(String billofEntryNum) {
		this.billofEntryNum = billofEntryNum;
	}

	public BigDecimal getBillofEntryValue() {
		return this.billofEntryValue;
	}

	public void setBillofEntryValue(BigDecimal billofEntryValue) {
		this.billofEntryValue = billofEntryValue;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getPortCode() {
		return this.portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public BigDecimal getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(BigDecimal taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	
	

}