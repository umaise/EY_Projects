package com.ey.advisory.asp.client.dto;

public class SubmitGSTR3Dto {

	private String gstin;
	private String taxperiod;

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getTaxperiod() {
		return taxperiod;
	}

	public void setTaxperiod(String taxperiod) {
		this.taxperiod = taxperiod;
	}

}
