package com.ey.advisory.asp.client.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.client.dao.SummaryFileUploadDao;
import com.ey.advisory.asp.client.domain.SummaryFileLoadMaster;
import com.ey.advisory.asp.common.Constant;

@Component
public class SummaryFileUploadServiceImpl implements SummaryFileUploadService {
	private static final Logger logger = Logger
			.getLogger(SummaryFileUploadServiceImpl.class);
	private static final String CLASS_NAME = SummaryFileUploadServiceImpl.class
			.getName();

	@Autowired
	SummaryFileUploadDao summaryFileUploadDao;

	@Override
	public String insertSummaryFileUpload(
			SummaryFileLoadMaster summaryFileLoadMaster) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " insertSummaryFileUploadDetails");
		}
		return summaryFileUploadDao
				.insertSummaryFileUploadDetails(summaryFileLoadMaster);
	}

	@Override
	public String updateSummaryFileLoadMaster(String status, int summaryFileId,int recordCount) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " updateSummaryFileLoadMaster");
		}
		
		return summaryFileUploadDao.updateSummaryFileLoadMaster(status,
				summaryFileId,recordCount);
	}

}
