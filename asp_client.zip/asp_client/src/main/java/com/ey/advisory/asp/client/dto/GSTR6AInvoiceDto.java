package com.ey.advisory.asp.client.dto;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class GSTR6AInvoiceDto {

	@SerializedName("Type")
	private String tableType;
	
	@SerializedName("SuggestedResponse")
	private String suggestedResp;		
	
	@SerializedName("SGSTIN")
	private String SGSTIN;

	@SerializedName("DocumentType")
	private String documentType;

	@SerializedName("DocumentNo")
	private String documentNo;

	@SerializedName("DocumentDate")
	private String documentDate;

	@SerializedName("CGSTIN")
	private String CGSTIN;

	@SerializedName("SourceIdentifier")
	private String sourceIdentifier;

	@SerializedName("SourceFileName")
	private String sourceFileName;

	@SerializedName("GLAccountCode")
	private String gLAccountCode;

	@SerializedName("Division")
	private String division;

	@SerializedName("SubDivision")
	private String subDivision;

	@SerializedName("ProfitCentre1")
	private String profitCentre1;

	@SerializedName("ProfitCentre2")
	private String profitCentre2;

	@SerializedName("PlantCode")
	private String plantCode;

	@SerializedName("PurchaseVoucherNumber")
	private String purchaseVoucherNumber;

	@SerializedName("PurchaseVoucherDate")
	private String purchaseVoucherDate;

	@SerializedName("SupplierName")
	private String supplierName;

	@SerializedName("SupplierCode")
	private String supplierCode;

	@SerializedName("OriginalDocumentNumber6A")
	private String originalDocumentNumber6A;

	@SerializedName("OriginalDocumentNumberPR")
	private String originalDocumentNumberPR;

	@SerializedName("Original_Document_Date6A")
	private String originalDocumentDate6A;

	@SerializedName("Original_Document_DatePR")
	private String originalDocumentDatePR;

	@SerializedName("Place_Of_Supply6A")
	private String pos6A;

	@SerializedName("Place_Of_SupplyPR")
	private String posPR;
	
	@SerializedName("ReverseChargeFlag6A")
	private String reverseChargeFlag6A;
	
	@SerializedName("ReverseChargeFlagPR")
	private String ReverseChargeFlagPR;


	@SerializedName("TotalTaxableValue6A")
	private Double totalTaxableValue6A;
	
	@SerializedName("TotalTaxableValuePR")
	private Double totalTaxableValuePR;
	
	@SerializedName("TotalIntegratedTaxAmount6A")
	private Double totalIntegratedTaxAmount6A;
	
	@SerializedName("TotalIntegratedTaxAmountPR")
	private Double totalIntegratedTaxAmountPR;
	
	@SerializedName("TotalCentralTaxAmount6A")
	private Double totalCentralTaxAmount6A;
	
	@SerializedName("TotalCentralTaxAmountPR")
	private Double totalCentralTaxAmountPR;
	
	@SerializedName("TotalStateTaxAmount6A")
	private Double totalStateTaxAmount6A;
	
	@SerializedName("TotalStateTaxAmountPR")
	private Double totalStateTaxAmountPR;
	
	@SerializedName("TotalCessAmount6A")
	private Double totalCessTaxAmount6A;
	
	@SerializedName("TotalCessAmountPR")
	private Double totalCessTaxAmountPR;
	
	private Double lineNo6A;		
	private Double lineNoPR;
	private Double rate6A;
	private Double ratePR;
	
	private String clientRes;
	
	@SerializedName("InvoiceKey")
	private String invKey;		

	@SerializedName("LineItemList")
	List<GSTR6FItemDto> itemDetails;

	public String getInvKey() {
		return invKey;
	}

	public void setInvKey(String invKey) {
		this.invKey = invKey;
	}
	
	public String getTableType() {
		return tableType;
	}

	public void setTableType(String tableType) {
		this.tableType = tableType;
	}

	public String getSuggestedResp() {
		return suggestedResp;
	}

	public void setSuggestedResp(String suggestedResp) {
		this.suggestedResp = suggestedResp;
	}

	public String getSGSTIN() {
		return SGSTIN;
	}

	public void setSGSTIN(String sGSTIN) {
		SGSTIN = sGSTIN;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public String getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(String documentDate) {
		this.documentDate = documentDate;
	}

	public String getCGSTIN() {
		return CGSTIN;
	}

	public void setCGSTIN(String cGSTIN) {
		CGSTIN = cGSTIN;
	}

	public String getSourceIdentifier() {
		return sourceIdentifier;
	}

	public void setSourceIdentifier(String sourceIdentifier) {
		this.sourceIdentifier = sourceIdentifier;
	}

	public String getSourceFileName() {
		return sourceFileName;
	}

	public void setSourceFileName(String sourceFileName) {
		this.sourceFileName = sourceFileName;
	}

	public String getgLAccountCode() {
		return gLAccountCode;
	}

	public void setgLAccountCode(String gLAccountCode) {
		this.gLAccountCode = gLAccountCode;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getSubDivision() {
		return subDivision;
	}

	public void setSubDivision(String subDivision) {
		this.subDivision = subDivision;
	}

	public String getProfitCentre1() {
		return profitCentre1;
	}

	public void setProfitCentre1(String profitCentre1) {
		this.profitCentre1 = profitCentre1;
	}

	public String getProfitCentre2() {
		return profitCentre2;
	}

	public void setProfitCentre2(String profitCentre2) {
		this.profitCentre2 = profitCentre2;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getPurchaseVoucherNumber() {
		return purchaseVoucherNumber;
	}

	public void setPurchaseVoucherNumber(String purchaseVoucherNumber) {
		this.purchaseVoucherNumber = purchaseVoucherNumber;
	}

	public String getPurchaseVoucherDate() {
		return purchaseVoucherDate;
	}

	public void setPurchaseVoucherDate(String purchaseVoucherDate) {
		this.purchaseVoucherDate = purchaseVoucherDate;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getOriginalDocumentNumber6A() {
		return originalDocumentNumber6A;
	}

	public void setOriginalDocumentNumber6A(String originalDocumentNumber6A) {
		this.originalDocumentNumber6A = originalDocumentNumber6A;
	}

	public String getOriginalDocumentNumberPR() {
		return originalDocumentNumberPR;
	}

	public void setOriginalDocumentNumberPR(String originalDocumentNumberPR) {
		this.originalDocumentNumberPR = originalDocumentNumberPR;
	}

	public String getOriginalDocumentDate6A() {
		return originalDocumentDate6A;
	}

	public void setOriginalDocumentDate6A(String originalDocumentDate2A) {
		this.originalDocumentDate6A = originalDocumentDate2A;
	}

	public String getOriginalDocumentDatePR() {
		return originalDocumentDatePR;
	}

	public void setOriginalDocumentDatePR(String originalDocumentDatePR) {
		this.originalDocumentDatePR = originalDocumentDatePR;
	}

	public String getPos6A() {
		return pos6A;
	}

	public void setPos6A(String pos6a) {
		pos6A = pos6a;
	}

	public String getPosPR() {
		return posPR;
	}

	public void setPosPR(String posPR) {
		this.posPR = posPR;
	}

	public String getReverseChargeFlag6A() {
		return reverseChargeFlag6A;
	}

	public void setReverseChargeFlag6A(String reverseChargeFlag6A) {
		this.reverseChargeFlag6A = reverseChargeFlag6A;
	}

	public String getReverseChargeFlagPR() {
		return ReverseChargeFlagPR;
	}

	public void setReverseChargeFlagPR(String reverseChargeFlagPR) {
		ReverseChargeFlagPR = reverseChargeFlagPR;
	}
	
	public Double getTotalTaxableValue6A() {
		return totalTaxableValue6A;
	}

	public void setTotalTaxableValue6A(Double totalTaxableValue6A) {
		this.totalTaxableValue6A = totalTaxableValue6A;
	}

	public Double getTotalTaxableValuePR() {
		return totalTaxableValuePR;
	}

	public void setTotalTaxableValuePR(Double totalTaxableValuePR) {
		this.totalTaxableValuePR = totalTaxableValuePR;
	}

	public Double getTotalIntegratedTaxAmount6A() {
		return totalIntegratedTaxAmount6A;
	}

	public void setTotalIntegratedTaxAmount6A(Double totalIntegratedTaxAmount2A) {
		this.totalIntegratedTaxAmount6A = totalIntegratedTaxAmount2A;
	}

	public Double getTotalCentralTaxAmountPR() {
		return totalCentralTaxAmountPR;
	}

	public void setTotalCentralTaxAmountPR(Double totalCentralTaxAmountPR) {
		this.totalCentralTaxAmountPR = totalCentralTaxAmountPR;
	}

	public Double getTotalStateTaxAmount6A() {
		return totalStateTaxAmount6A;
	}

	public void setTotalStateTaxAmount6A(Double totalStateTaxAmount6A) {
		this.totalStateTaxAmount6A = totalStateTaxAmount6A;
	}

	public Double getTotalCessTaxAmountPR() {
		return totalCessTaxAmountPR;
	}

	public void setTotalCessTaxAmountPR(Double totalCessTaxAmountPR) {
		this.totalCessTaxAmountPR = totalCessTaxAmountPR;
	}

	public List<GSTR6FItemDto> getItemDetails() {
		return itemDetails;
	}

	public void setItemDetails(List<GSTR6FItemDto> itemDetails) {
		this.itemDetails = itemDetails;
	}

	public Double getTotalIntegratedTaxAmountPR() {
		return totalIntegratedTaxAmountPR;
	}

	public void setTotalIntegratedTaxAmountPR(Double totalIntegratedTaxAmountPR) {
		this.totalIntegratedTaxAmountPR = totalIntegratedTaxAmountPR;
	}

	public Double getTotalCentralTaxAmount6A() {
		return totalCentralTaxAmount6A;
	}

	public void setTotalCentralTaxAmount6A(Double totalCentralTaxAmount6A) {
		this.totalCentralTaxAmount6A = totalCentralTaxAmount6A;
	}

	public Double getTotalStateTaxAmountPR() {
		return totalStateTaxAmountPR;
	}

	public void setTotalStateTaxAmountPR(Double totalStateTaxAmountPR) {
		this.totalStateTaxAmountPR = totalStateTaxAmountPR;
	}

	public Double getTotalCessTaxAmount6A() {
		return totalCessTaxAmount6A;
	}

	public void setTotalCessTaxAmount6A(Double totalCessTaxAmount6A) {
		this.totalCessTaxAmount6A = totalCessTaxAmount6A;
	}

	public Double getLineNo6A() {
		return lineNo6A;
	}

	public void setLineNo2A(Double lineNo6A) {
		this.lineNo6A = lineNo6A;
	}

	public Double getLineNoPR() {
		return lineNoPR;
	}

	public void setLineNoPR(Double lineNoPR) {
		this.lineNoPR = lineNoPR;
	}

	public Double getRate6A() {
		return rate6A;
	}

	public void setRate6A(Double rate6a) {
		rate6A = rate6a;
	}

	public Double getRatePR() {
		return ratePR;
	}

	public void setRatePR(Double ratePR) {
		this.ratePR = ratePR;
	}

	public String getClientRes() {
		return clientRes;
	}

	public void setClientRes(String clientRes) {
		this.clientRes = clientRes;
	}

}
