package com.ey.advisory.asp.client.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

public class SetoffLiabilityDBDto {
	
	private BigInteger AccountHeadID;	
	private BigDecimal ITCIgstAmt;	
	private BigDecimal ITCCgstAmt;	
	private BigDecimal ITCSgstAmt;	
	private BigDecimal ITCCessAmt;	
	private BigDecimal CashTaxPaid;	
	private BigDecimal CashIntrestPaid;	
	private BigDecimal CashLateFeePaid;
	
	public BigInteger getAccountHeadID() {
		return AccountHeadID;
	}
	public void setAccountHeadID(BigInteger accountHeadID) {
		AccountHeadID = accountHeadID;
	}
	public BigDecimal getITCIgstAmt() {
		return ITCIgstAmt;
	}
	public void setITCIgstAmt(BigDecimal iTCIgstAmt) {
		ITCIgstAmt = iTCIgstAmt;
	}
	public BigDecimal getITCCgstAmt() {
		return ITCCgstAmt;
	}
	public void setITCCgstAmt(BigDecimal iTCCgstAmt) {
		ITCCgstAmt = iTCCgstAmt;
	}
	public BigDecimal getITCSgstAmt() {
		return ITCSgstAmt;
	}
	public void setITCSgstAmt(BigDecimal iTCSgstAmt) {
		ITCSgstAmt = iTCSgstAmt;
	}
	public BigDecimal getITCCessAmt() {
		return ITCCessAmt;
	}
	public void setITCCessAmt(BigDecimal iTCCessAmt) {
		ITCCessAmt = iTCCessAmt;
	}
	public BigDecimal getCashTaxPaid() {
		return CashTaxPaid;
	}
	public void setCashTaxPaid(BigDecimal cashTaxPaid) {
		CashTaxPaid = cashTaxPaid;
	}
	public BigDecimal getCashIntrestPaid() {
		return CashIntrestPaid;
	}
	public void setCashIntrestPaid(BigDecimal cashIntrestPaid) {
		CashIntrestPaid = cashIntrestPaid;
	}
	public BigDecimal getCashLateFeePaid() {
		return CashLateFeePaid;
	}
	public void setCashLateFeePaid(BigDecimal cashLateFeePaid) {
		CashLateFeePaid = cashLateFeePaid;
	}
	
	
	
}
