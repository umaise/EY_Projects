package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR2SummaryItcReversalDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR2SummaryItcReversal;
@Repository
public class GSTR2SummaryItcReversalDaoImpl implements GSTR2SummaryItcReversalDao {
	
	@Autowired
	private HibernateDao  hibernateDao;
	private static final Logger logger = Logger.getLogger(GSTR2SummaryAdvancePaidDaoImpl.class);

	@Override
	public List<GSTR2SummaryItcReversal> getItcReversalMetadata() {
		
		List<GSTR2SummaryItcReversal> itcReversalList = new ArrayList<>();
		try {
			itcReversalList = (List<GSTR2SummaryItcReversal>)hibernateDao.loadAll(GSTR2SummaryItcReversal.class);
		} catch (Exception e) {
			
			logger.error("Exception in getItcReversalMetadata"+e);
		}
		return itcReversalList;
	}

}
