package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;
import org.hibernate.validator.constraints.Length;


/**
 * The persistent class for the tblB2CSInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2CSInvoiceDetails", schema="gstr1")
public class GSTR1B2CS_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR1B2CS_InvoiceDetail.class);

	@Id
	@Column(name="ID")
	private long id;

	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="Etin")
	private String etin;

	@Column(name="FileID")
	private long fileID;

	@Column(name="Flag")
	private String flag;

	@Column(name="InvNum")
    private String invNum;
	
	@Column(name="InvDate")
    private Date invDate;
	
	@Column(name="InvValue")
	private BigDecimal invValue;
	
	@Column(name="OrgInvNum")
	private String origInvNum;
	
	@Column(name="OrgInvDate")
	private Date origInvDate;
	
	@Column(name="POS")
	@Length(max = 2)
	private String pos;
	
	@Column(name="Gstin")
	private String gstin;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="Category")
	private String category;
	
	@Column(name="InvoiceKey")
	private String invoiceKey;
	
	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	@Column(name="SubCategory")
	private String subCategory;
	
	@Column(name="TaxableValue")
	private BigDecimal taxablevalue;

	@Column(name="TaxPeriod")
	private String taxPeriod;

	public GSTR1B2CS_InvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR1B2CS_InvoiceDetail ");
			}
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getEtin() {
		return this.etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public BigDecimal getTaxablevalue() {
		return this.taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

    public String getInvNum() {
        return invNum;
    }

    public void setInvNum(String invNum) {
        this.invNum = invNum;
    }

    public Date getInvDate() {
        return invDate;
    }

    public void setInvDate(Date invDate) {
        this.invDate = invDate;
    }

    
	public BigDecimal getInvValue() {
		return invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public String getOrigInvNum() {
		return origInvNum;
	}

	public void setOrigInvNum(String origInvNum) {
		this.origInvNum = origInvNum;
	}

	public Date getOrigInvDate() {
		return origInvDate;
	}

	public void setOrigInvDate(Date origInvDate) {
		this.origInvDate = origInvDate;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}
    
    

}