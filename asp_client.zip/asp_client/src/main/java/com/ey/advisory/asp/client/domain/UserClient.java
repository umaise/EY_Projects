package com.ey.advisory.asp.client.domain;

import java.util.List;

public class UserClient {

	private Integer userId;
	private String firstName;
	private String lastName;
	private String userName;
	private String email;
	private String mobileNo;
	private String role;
	private Integer groupId;
	private String accessLevel;
	private Long roleId;
	
	private Integer accessLevelId;
	
	private List<String> accessValues;
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getAccessLevel() {
		return accessLevel;
	}
	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}
	
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public List<String> getAccessValues() {
		return accessValues;
	}
	public void setAccessValues(List<String> accessValues) {
		this.accessValues = accessValues;
	}
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public Integer getAccessLevelId() {
		return accessLevelId;
	}
	public void setAccessLevelId(Integer accessLevelId) {
		this.accessLevelId = accessLevelId;
	}
	
	
}
