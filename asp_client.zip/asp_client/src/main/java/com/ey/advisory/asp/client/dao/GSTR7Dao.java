package com.ey.advisory.asp.client.dao;

import java.util.Date;
import java.util.List;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;

public interface GSTR7Dao {
	
	List<InwardInvoiceModel> getDupInvoice(String entityName, String supplierGSTIN, String contractNumber, String documentNo,
			Date documentDate);

	List<InwardInvoiceModel> getTaxableVal(String entityInwardModel, String supplierGSTIN, String contractNumber,
			Date contractdate);

}
