package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.client.dao.impl.InvoiceDaoImpl;

/**
 * The persistent class for the GSTR1AdvA_Payment_ItemDetails database table.
 * 
 */
@Entity
@Table(name="tblAdvAPaymentItemDetails", schema = "gstr1")
public class GSTR1AdvA_Payment_ItemDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR1AdvA_Payment_ItemDetail.class);

	@Id
	@Column(name="AdvAPaymentItemDetails")
	private Long id;
	
	@Column(name="ItemNo")
	private int itemNo;
	
	@Column(name="ItemType")
	private String item_Type;
	
	@Column(name="HSNSC")
	private String hsnSc;
	
	@Column(name="ValIncTax")
	private Double val_Inc_Tax;
	
	@Column(name="TaxableValue")
	private Double taxableValue;

	@Column(name="IGSTAmt")
	private Double IGST_Amt;

	@Column(name="IGSTRt")
	private Double IGST_Rate;

	@Column(name="CGSTAmt")
	private Double CGST_Amt;

	@Column(name="CGSTRt")
	private Double CGST_Rate;

	@Column(name="SGSTAmt")
	private Double SGST_Amt;

	@Column(name="SGSTRt")
	private Double SGST_Rate;

	@Column(name="CessRt")
	private Double cessRt;
	
	@Column(name="CessAmt")
	private Double cessAmt;
	
	@Column(name="AdvATaxPaymentID")
	private Long gstr1advATaxPaymentId;
	
	//bi-directional many-to-one association to GSTR1AdvA_TaxPayment
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @JoinColumn(name = "AdvATaxPaymentID",referencedColumnName="ID", insertable=false,updatable=false )
	private GSTR1AdvA_TaxPayment gstr1advATaxPayment;

	public GSTR1AdvA_Payment_ItemDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR1AdvA_Payment_ItemDetail ");
			}
	}

	public Double getCGST_Amt() {
		return this.CGST_Amt;
	}

	public void setCGST_Amt(Double CGST_Amt) {
		this.CGST_Amt = CGST_Amt;
	}

	public Double getCGST_Rate() {
		return this.CGST_Rate;
	}

	public void setCGST_Rate(Double CGST_Rate) {
		this.CGST_Rate = CGST_Rate;
	}

	public String getHsnSc() {
		return this.hsnSc;
	}

	public void setHsnSc(String hsnSc) {
		this.hsnSc = hsnSc;
	}

	public Double getIGST_Amt() {
		return this.IGST_Amt;
	}

	public void setIGST_Amt(Double IGST_Amt) {
		this.IGST_Amt = IGST_Amt;
	}

	public Double getIGST_Rate() {
		return this.IGST_Rate;
	}

	public void setIGST_Rate(Double IGST_Rate) {
		this.IGST_Rate = IGST_Rate;
	}

	public String getItem_Type() {
		return this.item_Type;
	}

	public void setItem_Type(String item_Type) {
		this.item_Type = item_Type;
	}

	public Double getSGST_Amt() {
		return this.SGST_Amt;
	}

	public void setSGST_Amt(Double SGST_Amt) {
		this.SGST_Amt = SGST_Amt;
	}

	public Double getSGST_Rate() {
		return this.SGST_Rate;
	}

	public void setSGST_Rate(Double SGST_Rate) {
		this.SGST_Rate = SGST_Rate;
	}

	public Double getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public Double getVal_Inc_Tax() {
		return this.val_Inc_Tax;
	}

	public void setVal_Inc_Tax(Double val_Inc_Tax) {
		this.val_Inc_Tax = val_Inc_Tax;
	}

	public GSTR1AdvA_TaxPayment getGstr1advATaxPayment() {
		return this.gstr1advATaxPayment;
	}

	public void setGstr1advATaxPayment(GSTR1AdvA_TaxPayment gstr1advATaxPayment) {
		this.gstr1advATaxPayment = gstr1advATaxPayment;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getItemNo() {
		return itemNo;
	}

	public void setItemNo(int itemNo) {
		this.itemNo = itemNo;
	}

	public Double getCessRt() {
		return cessRt;
	}

	public void setCessRt(Double cessRt) {
		this.cessRt = cessRt;
	}

	public Double getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}

	public Long getGstr1advATaxPaymentId() {
		return gstr1advATaxPaymentId;
	}

	public void setGstr1advATaxPaymentId(Long gstr1advATaxPaymentId) {
		this.gstr1advATaxPaymentId = gstr1advATaxPaymentId;
	}

}