package com.ey.advisory.asp.client.service;

import java.util.List;
import java.util.Set;

import com.ey.advisory.asp.client.domain.FileUploadMasterClient;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.dto.InvoiceProcessDto;


public interface ClientFileUploadService {

 	boolean updateFilejobStatus(String key);
 	boolean updateBifurcationjobStatus(String key);
 	boolean timeoutAndUpdateBifurcationjobStatus(String key);
 	boolean updateBifurcationjobFailStatus(String key);
 	boolean updateStageOneFailStatus(String key);
 	boolean saveSalesErrorInfo(Set<TblSalesErrorInfo> errorInfoList) throws Exception;
 	boolean saveInvoiceStatus(Set<InvoiceProcessDto> invoiceList, Integer fileId) throws Exception;
 	public List<FileUploadMasterClient> getFileFromClientMaster(Long fileId);
}
