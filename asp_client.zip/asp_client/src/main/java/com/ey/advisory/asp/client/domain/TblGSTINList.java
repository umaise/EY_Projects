package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "tblGSTINList",schema="etl")
public class TblGSTINList implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3800162191283758373L;
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GSTINListID")
	private int gSTINListID;
	@Column(name = "GSTIN")
	private String gSTIN;
	@Column(name = "TaxPeriod")
	private String taxPeriod;
	@Column(name = "Status")
	private	String status;
	@Column(name = "IsRoutingDone")
	private	Boolean isRoutingDone;
	@Temporal(TemporalType.DATE)
	@Column(name = "CreatedDate", columnDefinition="DATE")
	private	Date createdDate;
	@Temporal(TemporalType.DATE)
	@Column(name = "UpdatedDate", columnDefinition="DATE")
	private	Date updatedDate;
	@Column(name = "FileId")
	private	int fileId;
	@Column(name = "TransactionType")
	private	String transactionType;
	@Column(name = "ReturnType")
	private	String returnType;
	@Column(name = "IsChunkingInitiated")
	private	Boolean isChunkingInitiated;
	
	public Boolean getIsRoutingDone() {
		return isRoutingDone;
	}
	public void setIsRoutingDone(Boolean isRoutingDone) {
		this.isRoutingDone = isRoutingDone;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public Boolean getIsChunkingInitiated() {
		return isChunkingInitiated;
	}
	public void setIsChunkingInitiated(Boolean isChunkingInitiated) {
		this.isChunkingInitiated = isChunkingInitiated;
	}
	public int getgSTINListID() {
		return gSTINListID;
	}
	public void setgSTINListID(int gSTINListID) {
		this.gSTINListID = gSTINListID;
	}
	public String getgSTIN() {
		return gSTIN;
	}
	public void setgSTIN(String gSTIN) {
		this.gSTIN = gSTIN;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

}
