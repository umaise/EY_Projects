package com.ey.advisory.asp.client.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.common.Constant;

/**
 * @author Divya.Dsouza
 * 
 *Added as a part of sprint 1 to make GSTN call via GSP
 */
@Component
@PropertySource("classpath:GSPConfig.properties")
@PropertySource("classpath:RestConfig.properties")
public class GSPRestUtility {
	
	@Autowired
	GSPRestClientUtility restClientUtility;
	
	@Autowired
	private Environment env;
	
	//post
	public String executeRestCall(HttpHeaders httpHeaders, String inputData, String resource, HttpMethod httpMethod) {

		return restClientUtility.executeRestCall(resource, getCustomHeaders(httpHeaders), inputData,
				httpMethod);
	}

	//get
	public String executeRestCall(HttpHeaders httpHeaders, String resource, HttpMethod httpMethod) {
	
		return restClientUtility.executeRestCall(resource, getCustomHeaders(httpHeaders), httpMethod);
		
	}


	private HttpHeaders getCustomHeaders(HttpHeaders httpHeaders) {
	
		httpHeaders.add(Constant.IP_USR, env.getProperty("ip.usr"));
		httpHeaders.add(Constant.GSP_USER, env.getProperty("gsp-user"));
		httpHeaders.add(Constant.GSP_CLIENT_ID, env.getProperty("gsp-clientid"));
		httpHeaders.add(Constant.GSP_CLIENT_SECRET, env.getProperty("gsp-client-secret"));
		httpHeaders.add(Constant.PARAM_OAUTH,env.getProperty("auth.token"));
		httpHeaders.add(Constant.STATECD, env.getProperty("state.cd"));
		httpHeaders.add(Constant.USERNAME, env.getProperty("rest.username"));
		httpHeaders.add(Constant.TXN, env.getProperty("rest.txn"));
		return httpHeaders;
	}
}
