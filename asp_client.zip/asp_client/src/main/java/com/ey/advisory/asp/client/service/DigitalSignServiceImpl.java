package com.ey.advisory.asp.client.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dto.DocumentMeta;
import com.ey.advisory.asp.client.dto.DownloadedData;
import com.ey.advisory.asp.client.dto.UploadRawAndGetSignRequest;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;
import com.ey.advisory.asp.client.service.gstr1.Gstr1ServiceImpl;
import com.ey.advisory.asp.client.util.GSTNRestUtility;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.google.api.client.util.Base64;

/**
 * @author Divya.Dsouza
 *
 */
@Service
@PropertySource("classpath:GSPRestConfig.properties")
public class DigitalSignServiceImpl implements DigitalSignService {

	private static final Logger LOGGER = Logger
			.getLogger(Gstr1ServiceImpl.class);
	private static final String CLASS_NAME = Gstr1ServiceImpl.class.getName();

	@Autowired
	private Environment env;

	@Autowired
	Gstr1Service gstr1Service;

	@Autowired
	GSTNRestUtility gstnRestUtility;

	@Override
	public String uploadData(String emailId,String content) throws IOException, NoSuchAlgorithmException,
			URISyntaxException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering " + CLASS_NAME + " Method : uploadData");
		}
		UploadRawAndGetSignRequest request = new UploadRawAndGetSignRequest();
		request.setSigner(emailId);
		request.setFormat(UploadRawAndGetSignRequest.RawContentFormat.JSON);

		request.setContent(content);

		try {
			String auth = "Basic "
					+ Base64.encodeBase64String((env
							.getProperty("digio.client.id") + ":" + env
							.getProperty("digio.client.secret"))
							.getBytes("utf-8"));
			String jsonInString = new ObjectMapper().setPropertyNamingStrategy(
					PropertyNamingStrategy.SNAKE_CASE).writeValueAsString(
					request);
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("jsonString:  " + jsonInString );
				}
			
			String uri = env.getProperty("digio.base.url")
					+ env.getProperty("digio.upload");
			String res = gstnRestUtility.executeRestCallTest(getHeaders(auth),
					jsonInString, uri, HttpMethod.POST);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			DocumentMeta documentMeta = new ObjectMapper().setDateFormat(df).readValue(res,
					DocumentMeta.class);

			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Exiting " + CLASS_NAME + " Method : uploadData");
			}
			return documentMeta.getId();

		} catch (Exception e) {
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Error " + CLASS_NAME + " Method : uploadData" +e);
			}
			return null;
		}
	}

	@Override
	public DownloadedData downloadSignedData(String docId)
			throws NoSuchAlgorithmException, URISyntaxException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering " + CLASS_NAME + " Method : downloadSignedData");
		}
		DownloadedData downloadedData = null;
		try {
			String auth = "Basic "
					+ Base64.encodeBase64String((env
							.getProperty("digio.client.id") + ":" + env
							.getProperty("digio.client.secret"))
							.getBytes("utf-8"));
			String uri = env.getProperty("digio.base.url")
					+ env.getProperty("digio.download") + "?document_id="
					+ docId;
			String res = gstnRestUtility.executeRestCallTest(getHeaders(auth),
					uri, HttpMethod.GET);
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("jsonString:  " + res );
			}
			downloadedData = new ObjectMapper().readValue(res,
					DownloadedData.class);
		} catch (Exception e) {
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Error " + CLASS_NAME + " Method : downloadSignedData" +e);
			}
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Exiting " + CLASS_NAME + " Method : downloadSignedData");
		}
		return downloadedData;
	}

	private HttpHeaders getHeaders(String auth) {

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		httpHeaders.set("Authorization", auth);
		return httpHeaders;
	}
}
