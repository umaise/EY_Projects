package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.SaleStagingDao;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;
@Service
@Transactional
public class SaleStagingServiceImpl implements SaleStagingService{
	@Autowired
	private SaleStagingDao salesDao;
	
	@Autowired
	HibernateDao hibernateDao;
	private static final Logger logger = Logger.getLogger(SaleStagingServiceImpl.class);
	private static final String CLASS_NAME = SaleStagingServiceImpl.class.getName();
	
	/* * @see com.ey.advisory.asp.client.service.ClientSpCallService#getLineItemList()
	 * This method is used to retrieve the GSTR1 lineItem values for data pipeline2
	 */
	@Override
	public List<String> getLineItemList(String applicableState,String returnType,String fileId,String recordType,String datalevel) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getLineItemList()");
		}
		List<String> listItem=null;

	    try {

	     listItem =getLineItemList(applicableState,returnType,fileId,recordType,datalevel);
	
	    } catch (Exception e) {
	    	logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getLineItemList()",e);
	    }
	    if(logger.isInfoEnabled()){
	    logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getLineItemList()");
	    }
		return listItem;
	}
	/*(non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#getDataCount(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 * Used to get Invoice Count from database
	 */
	@Override
	public List<String> getDataCount(String applicableState, String returnType,String fileData,String isProccessed,String jobStatus,List<String> fileIds,String recordType, String groupCode) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getDataCount()");
		}
		List<String> listInvCount=new ArrayList<>();
			
	    try {
	   
	    	listInvCount =getDataCount( applicableState,  returnType, fileData, isProccessed, jobStatus, fileIds, recordType,  groupCode);
	      
	    } catch (Exception e) {
	    	logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getDataCount()",e);
	    }
	    if(logger.isInfoEnabled()){
	    logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getDataCount()");
	    }
		return listInvCount;
	}
	
	@Override
	public List<OutwardInvoiceModel> getProcessedRecords(Long fileId, int firstResult, int pageSize){
		
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getProcessedRecords");
		List<OutwardInvoiceModel> processRecList= null;
		
		try{
			processRecList = salesDao.fetchProcessedRecords(fileId,firstResult, pageSize);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +" Method : getProcessedRecords", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getProcessedRecords");
		return processRecList;
	}
	
	@Override
	public Long getProcessedCount(Long fileId){
		
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getProcessedCount");
		
		Long count = null;
		try{
			count = salesDao.getTotalProcessedCount(fileId);
			
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +" Method : getProcessedCount", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getProcessedCount");
		return count;
	}
	
	@Override
	public List<OutwardInvoiceModel> fetchDupRecords(Long fileId, int firstResult, int pageSize){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" fetchDupRecords");
		List<OutwardInvoiceModel> dupRecList = null;
		
		try{
			dupRecList = salesDao.fetchDupRecords(fileId,firstResult, pageSize);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +" Method : fetchDupRecords", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" fetchDupRecords");
		return dupRecList;
	}
	
	@Override
	public List<OutwardInvoiceModel> getTotalRecords(Long  fileId,int firstResult, int pageSize){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getTotalRecords");
		List<OutwardInvoiceModel> totalRecordList = null;
		
		try{
			totalRecordList = salesDao.fetchTotalRecords(fileId,firstResult, pageSize);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +" Method : getTotalRecords", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getTotalRecords");
		return totalRecordList;
	}
	
	@Override
	public Long getDupCount(Long fileId){
		
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getDupCount");

		Long count = null;
		try{
			count = salesDao.getTotalDupCount(fileId);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +" Method : getDupCount", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getDupCount");
		
		return count;
	}
	@Override
	public List<OutwardInvoiceModel> fetchErrorRecords(Long fileId, int firstResult, int pageSize) {
		
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" fetchErrorRecords");
		List<OutwardInvoiceModel> errorList = null;
		
		try{
			errorList = salesDao.fetchErrorRecords(fileId,firstResult, pageSize);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+" Method : fetchErrorRecords", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" fetchErrorRecords");
		return errorList;
	}
	
	@Override
	public Long getTotalErrorCount(Long fileId) {

		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getTotalErrorCount");

		Long count = null;
		try{
			count = salesDao.getTotalErrorCount(fileId);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+" Method : getTotalErrorCount", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getTotalErrorCount");
		return count;
	}
	
}
