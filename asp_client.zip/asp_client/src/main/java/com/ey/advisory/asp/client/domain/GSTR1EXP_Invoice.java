package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;


/**
 * The persistent class for the tblExportInvoice database table.
 * 
 */
@Entity
@Table(name="tblExportInvoice", schema="gstr1")
public class GSTR1EXP_Invoice implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR1EXP_Invoice.class);

	@Id
	@Column(name="ID")
	private long id;

	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="ExpBillDate")
	private Date expBillDate;

	@Column(name="ExpBillNo")
	private String expBillNo;

	@Column(name="ExpType")
	private String expType;

	@Column(name="FileID")
	private long fileID;

	@Column(name="Flag")
	private String flag;

	@Column(name="Gstin")
	private String gstin;

	@Column(name="InvDate")
	private Date invDate;

	@Column(name="InvNum")
	private String invNum;

	@Column(name="InvValue")
	private BigDecimal invValue;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;

	@Column(name="TaxPeriod")
	private String taxPeriod;

	@Column(name="InvoiceKey")
	private String invoiceKey;

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public GSTR1EXP_Invoice() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR1EXP_Invoice ");
			}
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public Date getExpBillDate() {
		return this.expBillDate;
	}

	public void setExpBillDate(Date expBillDate) {
		this.expBillDate = expBillDate;
	}

	public String getExpBillNo() {
		return this.expBillNo;
	}

	public void setExpBillNo(String expBillNo) {
		this.expBillNo = expBillNo;
	}

	public String getExpType() {
		return this.expType;
	}

	public void setExpType(String expType) {
		this.expType = expType;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Date getInvDate() {
		return this.invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getInvNum() {
		return this.invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public BigDecimal getInvValue() {
		return this.invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public BigDecimal getTaxablevalue() {
		return this.taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

}