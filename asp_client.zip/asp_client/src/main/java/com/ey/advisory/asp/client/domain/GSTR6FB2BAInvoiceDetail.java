package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;


/**
 * The persistent class for the tblB2BAInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2BAInvoiceDetails", schema=Constant.GSTR6F_SCHEMA)
public class GSTR6FB2BAInvoiceDetail implements Serializable {


    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = Logger.getLogger(GSTR6FB2BAInvoiceDetail.class);

	@Id
	@Column(name="ID")
	private long invoiceDetailsId;

	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="CntrPrtyFilingStatus")
	private String cntrPrtyFilingStatus;

	@Column(name="CustGSTIN")
	private String cust_GSTIN;

	@Column(name="FilingStatus")
	private String filingStatus;

	@Column(name="Flag")
	private String flag;

	@Column(name="Gstin")
	private String gstin;

	@Column(name="InvDate")
	private Date doc_Date;

	@Column(name="InvNum")
	private String doc_Num;

	@Column(name="InvoiceUploader")
	private String invoiceUploader;

	@Column(name="InvValue")
	private Double invValue;

	@Column(name="IsAccepted")
    private Integer isAccepted;

	@Column(name="OrgInvDt")
	private Date orgInvDt;

	@Column(name="OrgInvNum")
	private String orgInvNum;

	@Column(name="POS")
	private String placeOfSupply;

	@Column(name="RevChrg")
	private String reverseCharge;

	@Column(name="Status")
	private String status;

	@Column(name="SupplierName")
	private String supplierName;

	@Column(name="TaxableValue")
	private Double taxableValue;

	@Column(name="TaxPeriod")
	private String taxPeriod;

    @Column(name="InvOrder")
    private long invOrder;

    
    
    @Column(name="ClientResponse")
    private String clientResponse;
    
    @Column(name="DrAvailability")
    private String drAvailability;

	@OneToMany(cascade = CascadeType.REFRESH, mappedBy="gstr6FB2BAItemDetailsPK.invoiceDetails", fetch = FetchType.EAGER)
    @OrderBy("gstr6FB2BAItemDetailsPK.lineNo")
    private Set<GSTR6FB2BAItemDetailsModel> itemDetails = new HashSet<>(); 
	

	public String getCust_GSTIN() {
        return cust_GSTIN;
    }

    public void setCust_GSTIN(String cust_GSTIN) {
        this.cust_GSTIN = cust_GSTIN;
    }

    public Date getDoc_Date() {
        return doc_Date;
    }

    public void setDoc_Date(Date doc_Date) {
        this.doc_Date = doc_Date;
    }

    public String getDoc_Num() {
        return doc_Num;
    }

    public void setDoc_Num(String doc_Num) {
        this.doc_Num = doc_Num;
    }

    public String getPlaceOfSupply() {
        return placeOfSupply;
    }

    public void setPlaceOfSupply(String placeOfSupply) {
        this.placeOfSupply = placeOfSupply;
    }

    public String getReverseCharge() {
        return reverseCharge;
    }

    public void setReverseCharge(String reverseCharge) {
        this.reverseCharge = reverseCharge;
    }
    
    public Set<GSTR6FB2BAItemDetailsModel> getItemDetails() {
        return itemDetails;
    }

    public void setItemDetails(Set<GSTR6FB2BAItemDetailsModel> itemDetails) {
        this.itemDetails = itemDetails;
    }
	
	public GSTR6FB2BAInvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR6FB2BAInvoiceDetail ");
			}
	}


	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getCntrPrtyFilingStatus() {
		return this.cntrPrtyFilingStatus;
	}

	public void setCntrPrtyFilingStatus(String cntrPrtyFilingStatus) {
		this.cntrPrtyFilingStatus = cntrPrtyFilingStatus;
	}

	public String getFilingStatus() {
		return this.filingStatus;
	}

	public void setFilingStatus(String filingStatus) {
		this.filingStatus = filingStatus;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getInvoiceUploader() {
		return this.invoiceUploader;
	}

	public void setInvoiceUploader(String invoiceUploader) {
		this.invoiceUploader = invoiceUploader;
	}

	public Double getInvValue() {
		return this.invValue;
	}

	public void setInvValue(Double invValue) {
		this.invValue = invValue;
	}

	public Integer getIsAccepted() {
        return isAccepted;
    }

    public void setIsAccepted(Integer isAccepted) {
        this.isAccepted = isAccepted;
    }

    public Date getOrgInvDt() {
		return this.orgInvDt;
	}

	public void setOrgInvDt(Date orgInvDt) {
		this.orgInvDt = orgInvDt;
	}

	public String getOrgInvNum() {
		return this.orgInvNum;
	}

	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSupplierName() {
		return this.supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public Double getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

    public Set<TblIsdErrorInfo> getErrorInfo() {
        return errorInfo;
    }

    public void setErrorInfo(Set<TblIsdErrorInfo> errorInfo) {
        this.errorInfo = errorInfo;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public long getInvOrder() {
        return invOrder;
    }

    public void setInvOrder(long invOrder) {
        this.invOrder = invOrder;
    }
    
    @Transient
    private Set<TblIsdErrorInfo> errorInfo = new HashSet<>();


	public String getClientResponse() {
		return clientResponse;
	}

	public void setClientResponse(String clientResponse) {
		this.clientResponse = clientResponse;
	}

	public String getDrAvailability() {
		return drAvailability;
	}

	public void setDrAvailability(String drAvailability) {
		this.drAvailability = drAvailability;
	}

	public long getInvoiceDetailsId() {
		return invoiceDetailsId;
	}

	public void setInvoiceDetailsId(long invoiceDetailsId) {
		this.invoiceDetailsId = invoiceDetailsId;
	}


}