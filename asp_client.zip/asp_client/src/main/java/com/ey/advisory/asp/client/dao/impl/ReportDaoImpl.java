package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.ReportDao;
import com.ey.advisory.asp.common.Constant;

@Repository
public class ReportDaoImpl implements ReportDao{
	
	@Autowired
	private HibernateDao hibernateDao;

	private static final Logger LOGGER = Logger.getLogger(ReportDaoImpl.class);
	@SuppressWarnings("unchecked")
	@Override
	public Object getRectifiedReportDetails(JSONObject jsonObj) {
		Object resultXml=null;
		List<String> rectifiedXml = new ArrayList<>();
		Session session = null;
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.DBO_SCHEMA);
			queryString.append(".");
			String processType = String.valueOf(jsonObj.get(Constant.PROCESS_TYPE));
			if(processType.equalsIgnoreCase(Constant.GSTR1_RECTIFIED_REPORT)){
				queryString.append(Constant.GSTR1_RECTIFIED_REPORT_PROC_NAME);
			}
			queryString.append(" ?,?,?,?,?,?,?,?,? ");
			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());
			query.setString(0,  String.valueOf(jsonObj.get(Constant.ENTITY)));
			query.setString(1,  String.valueOf(jsonObj.get(Constant.CIRCLE)));
			query.setString(2, String.valueOf(jsonObj.get(Constant.GSTIN_CODE)));
			query.setString(3,  String.valueOf(jsonObj.get(Constant.SUB_DIVISION)));
			query.setString(4,  String.valueOf(jsonObj.get(Constant.PROFIT_CENTER)));
			query.setString(5, String.valueOf(jsonObj.get(Constant.BUSINESS_UNIT)));
			query.setString(6,  String.valueOf(jsonObj.get(Constant.PLANT_CODE)));
			query.setString(7,  String.valueOf(jsonObj.get(Constant.FROM_TAXPERIOD)));
			query.setString(8,  String.valueOf(jsonObj.get(Constant.TO_TAXPERIOD)));
			rectifiedXml = query.list();
			if (rectifiedXml != null && !rectifiedXml.isEmpty()) {
				resultXml = (Object) rectifiedXml.get(0);
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(resultXml);
		} catch (Exception e) {
			
			LOGGER.error("Exception in getRectifiedReportDetails"+ e);
			
		}finally{
			if(session!=null && session.isOpen()){
				try{
				session.close();}
				catch(Exception e ){
					LOGGER.error("Exception in getRectifiedReportDetails "+e);
				}
			}
		}
		return resultXml;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Object getErrorReportDetails(JSONObject jsonObj) {
		List<String> errorsXml  = new ArrayList<>();		
		String procName="";
		try {        
			List<String> inputList=new ArrayList<>();
			inputList.add(((String) jsonObj.get(Constant.ENTITY)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.ENTITY) );
			inputList.add(((String) jsonObj.get(Constant.CIRCLE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.CIRCLE) );
			inputList.add(((String) jsonObj.get(Constant.GSTIN_CODE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.GSTIN_CODE) );
			inputList.add(((String) jsonObj.get(Constant.SUB_DIVISION)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.SUB_DIVISION) );
			inputList.add(((String) jsonObj.get(Constant.PROFIT_CENTER)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.PROFIT_CENTER) );
			inputList.add(((String) jsonObj.get(Constant.BUSINESS_UNIT)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.BUSINESS_UNIT) );
			inputList.add(((String) jsonObj.get(Constant.PLANT_CODE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.PLANT_CODE) );
			inputList.add(((String) jsonObj.get(Constant.FROM_TAXPERIOD)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.FROM_TAXPERIOD) );
			inputList.add(((String) jsonObj.get(Constant.TO_TAXPERIOD)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.TO_TAXPERIOD) );					
					
			String processType = String.valueOf(jsonObj.get(Constant.PROCESS_TYPE));
			if(processType.equalsIgnoreCase(Constant.GSTR1_ERROR_REPORT)){
				inputList.add(((String) jsonObj.get("slctText")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("slctText") );				
				inputList.add(((String) jsonObj.get("fileId")).equalsIgnoreCase("null") ? "0" :(String) jsonObj.get("fileId") );
				inputList.add(((String) jsonObj.get("selectPageSize")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("selectPageSize") );
				procName=Constant.GSTR1_ERROR_REPORT_PROC_NAME;
			}else if(processType.equalsIgnoreCase(Constant.GSTR2_ERROR_REPORT)){
				inputList.add(((String) jsonObj.get("slctText")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("slctText") );
				inputList.add(((String) jsonObj.get("fileId")).equalsIgnoreCase("null") ? "0" :(String) jsonObj.get("fileId") );
				inputList.add(((String) jsonObj.get("selectPageSize")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("selectPageSize") );
				procName=Constant.GSTR2_ERROR_REPORT_PROC_NAME;
			}else if(processType.equalsIgnoreCase(Constant.RECTIFICATION_GSTR1))
			{	
				inputList.add(((String) jsonObj.get("slctText")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("slctText") );		
				inputList.add(((String) jsonObj.get("fileId")).equalsIgnoreCase("null") ? "0" :(String) jsonObj.get("fileId") );
				inputList.add(((String) jsonObj.get("selectPageSize")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("selectPageSize") );
				procName=Constant.GSTR1_RECTIFICATION_REPORT_PROC_NAME;				
			}else if(processType.equalsIgnoreCase(Constant.RECTIFICATION_GSTR2))
			{	
				inputList.add(((String) jsonObj.get("slctText")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("slctText") );
				inputList.add(((String) jsonObj.get("fileId")).equalsIgnoreCase("null") ? "0" :(String) jsonObj.get("fileId") );
				inputList.add(((String) jsonObj.get("selectPageSize")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("selectPageSize") );
				procName=Constant.GSTR2_RECTIFICATION_REPORT_PROC_NAME;				
			}							
			errorsXml = hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, procName, String.valueOf(inputList.size()), inputList);
			
			
		} catch (Exception e) {
			
			LOGGER.error("Exception in getErrorReportDetails"+ e);
		}
		return errorsXml.get(0);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<String> getGstr2AReportDetails(JSONObject jsonObj) {
		List<String> errorsXml  = new ArrayList<>();		
		String procName="";
		try {        
			List<String> inputList=new ArrayList<>();
			
			inputList.add(((String) jsonObj.get(Constant.GSTIN_CODE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.GSTIN_CODE) );
			inputList.add(((String) jsonObj.get(Constant.TO_TAXPERIOD)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.TO_TAXPERIOD) );					
			inputList.add(((String) jsonObj.get("slctText")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("slctText") );	
			String processType = String.valueOf(jsonObj.get(Constant.PROCESS_TYPE));
			 if(processType.equalsIgnoreCase(Constant.GSTR2A_DUMP))
			{	
				procName=Constant.GSTR2A_REPORT_PROC_NAME;		
				
			}else
			{
				procName=Constant.GSTR2F_REPORT_PROC_NAME;
			}
			errorsXml = hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, procName, String.valueOf(inputList.size()), inputList);
			
			
		} catch (Exception e) {
			
			LOGGER.error("Exception in getGstr2AReportDetails"+ e);
		}
		return errorsXml;
	}
	
	@SuppressWarnings("unchecked")
	public Object getCounterpartyDetails(JSONObject jsonObj) {
		String outputXml  ="";
		String procName="";
		String supplyType = "";
		try {        
						
			List<String> inputList=new ArrayList<>();
			inputList.add(((String) jsonObj.get("inputGstin")).equalsIgnoreCase("null") ? null :(String) jsonObj.get("inputGstin") );
			inputList.add(((String) jsonObj.get("cptyGstin")).equalsIgnoreCase("-") ? null :(String) jsonObj.get("cptyGstin") );
			inputList.add(((String) jsonObj.get("cptyName")).equalsIgnoreCase("-") ? null :(String) jsonObj.get("cptyName") );
			inputList.add(((String) jsonObj.get("taxperiod")).equalsIgnoreCase("null") ? null :(String) jsonObj.get("taxperiod") );
			
			if(((String) jsonObj.get("supplyType")).equalsIgnoreCase(Constant.CDN) || 
					((String) jsonObj.get("supplyType")).equalsIgnoreCase(Constant.CDN_INV)){
				supplyType = Constant.CR+","+Constant.DR;
			}
			else if(((String) jsonObj.get("supplyType")).equalsIgnoreCase(Constant.CDNA) || 
					((String) jsonObj.get("supplyType")).equalsIgnoreCase(Constant.CDNA_INV)){
				supplyType = Constant.RCR+","+Constant.RDR;
			}
			else
				supplyType= (String) jsonObj.get("supplyType");
			
			inputList.add(supplyType);							
					
			String processType = String.valueOf(jsonObj.get("type"));
			if(processType.equalsIgnoreCase(Constant.GSTR1_ERROR_REPORT)){				
				procName=Constant.GSTR1_COUNTER_PARTY_REPORT_PROC_NAME;
			}else if(processType.equalsIgnoreCase(Constant.GSTR2_ERROR_REPORT)){				
				procName=Constant.GSTR2_COUNTER_PARTY_REPORT_PROC_NAME;
			}							
			outputXml = hibernateDao.executeStoredProcedure(Constant.DBO_SCHEMA, procName, String.valueOf(inputList.size()), inputList);
			
			
		} catch (Exception e) {
			
			LOGGER.error("Exception in getCounterpartyDetails"+ e);
		}
		return outputXml;
	}
}
