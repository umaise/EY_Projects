package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TblTurnoverMaster",schema="gstr6")
public class TblTurnoverMaster implements Serializable {


	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3307406712449276256L;

	@Id
	@Column(name = "ID")
	private	Integer id;
	
	@Column(name = "ISDGSTN")
	private String isdgstn;
	
	@Column(name = "GSTN")
	private String gstin;
	
	@Column(name = "Email")
	private String email;
	
	@Column(name = "IsUnregistredEntity")
	private boolean isUnregistredEntity;
	
	@Column(name = "StateCode")
	private String stateCode;
	
	@Column(name = "GSTNUserName")
	private String gstnUserName;
	
	@Column(name = "IsActive")
	private boolean isActive;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getIsdgstn() {
		return isdgstn;
	}

	public void setIsdgstn(String isdgstn) {
		this.isdgstn = isdgstn;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isUnregistredEntity() {
		return isUnregistredEntity;
	}

	public void setUnregistredEntity(boolean isUnregistredEntity) {
		this.isUnregistredEntity = isUnregistredEntity;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getGstnUserName() {
		return gstnUserName;
	}

	public void setGstnUserName(String gstnUserName) {
		this.gstnUserName = gstnUserName;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	
}
