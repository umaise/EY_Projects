package com.ey.advisory.asp.client.util;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.ey.advisory.asp.common.Constant;

@Configuration
@ComponentScan(basePackages = { "com.ey.*" })
@PropertySource("classpath:RestConfig.properties")
public class GSTNRestUtility {

	@Autowired
	private Environment env;

	@Autowired
	GSTNRestClientUtility gstnRestClientUtility;

	private static final Logger LOGGER = Logger
			.getLogger(GSTNRestUtility.class);
	private static final String CLASS_NAME = GSTNRestUtility.class.getName();


	// post
	public String executeRestCall(HttpHeaders httpHeaders, String inputData,
			String resource, HttpMethod httpMethod) {

		return gstnRestClientUtility.executeRestCall(resource, getHeaders(),
				inputData, httpMethod);
	}

	// get
	public String executeRestCall(HttpHeaders httpHeaders, String resource,
			HttpMethod httpMethod) {

		return gstnRestClientUtility.executeRestCall(resource, getHeaders(),
				httpMethod);

	}

	// post call fro Digio
	public String executeRestCallTest(HttpHeaders httpHeaders,
			String inputData, String resource, HttpMethod httpMethod) {

		return gstnRestClientUtility.executeRestCallTest(resource,
				httpHeaders, inputData, httpMethod);
	}

	// get call for Digio
	public String executeRestCallTest(HttpHeaders httpHeaders, String resource,
			HttpMethod httpMethod) {

		return gstnRestClientUtility.executeRestCallTest(resource,
				httpHeaders, httpMethod);

	}

	public String getResource(boolean gstnHost, String resouceType, String gstr) {
		String host ;
		String resource ;

		if (gstnHost) {
			host = env.getProperty("restapi.host");
			resource = env.getProperty(resouceType);
		} else  {
			host = env.getProperty("restapi.mail.host");
			resource = "";
		}

		String uri = host + resource + gstr;
		return uri;

	}

	public HttpHeaders getHeaders() {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering " + CLASS_NAME + " Method : getHeaders");
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constant.USERNAME, env.getProperty("rest.username"));
		headers.add(Constant.CLIENT_ID, env.getProperty("client.id"));
		headers.add(Constant.CLIENT_SECRET, env.getProperty("client.secret"));
		headers.add(Constant.IP_USR, env.getProperty("ip.usr"));
		headers.add(Constant.STATECD, env.getProperty("state.cd"));
		headers.add(Constant.TXN, env.getProperty("rest.txn"));
		headers.add(Constant.PARAM_OAUTH, env.getProperty("auth.token"));
		headers.add(Constant.CONTENT_TYPE,
				MediaType.APPLICATION_JSON_UTF8_VALUE);

		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Exiting " + CLASS_NAME + " Method : getHeaders");
		}
		return headers;
	}

}
