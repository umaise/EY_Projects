package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TblTurnoverDetails",schema="gstr6")
public class TblTurnoverDetails implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1580324678532339885L;

	@Id
	@Column(name = "ID")
	private	Integer id;
	
	@Column(name = "TurnoverMasterID")
	private Integer turnoverMasterID;
	
	@Column(name = "TaxPeriod")
	private String taxPeriod;
	
	@Column(name = "IsFreezed")
	private boolean isFreezed;
	
	@Column(name = "Amount")
	private BigDecimal amount;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTurnoverMasterID() {
		return turnoverMasterID;
	}

	public void setTurnoverMasterID(Integer turnoverMasterID) {
		this.turnoverMasterID = turnoverMasterID;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public boolean isFreezed() {
		return isFreezed;
	}

	public void setFreezed(boolean isFreezed) {
		this.isFreezed = isFreezed;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

}