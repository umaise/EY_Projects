package com.ey.advisory.asp.client.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.SummaryFileUploadDao;
import com.ey.advisory.asp.client.domain.SummaryFileLoadMaster;
import com.ey.advisory.asp.common.Constant;

@Repository
public class SummaryFileUploadDaoImpl implements SummaryFileUploadDao {

	private static final Logger logger = Logger
			.getLogger(SummaryFileUploadDaoImpl.class);
	private static final String CLASS_NAME = SummaryFileUploadDaoImpl.class
			.getName();

	@Autowired
	HibernateDao hibernateDao;

	@Override
	public String insertSummaryFileUploadDetails(
			SummaryFileLoadMaster summaryFileLoadMaster) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " insertSummaryFileUploadDetails");
		}
		try {
			hibernateDao.saveOrUpdate(summaryFileLoadMaster);
			if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD
					+ " insertSummaryFileUploadDetails");
			}
			return Constant.SUCCESS;
		} catch (Exception e) {
			if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD
					+ " insertSummaryFileUploadDetails" + e);
			}
			return Constant.FAILED;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public String updateSummaryFileLoadMaster(String status, int summaryFileId,int recordCount) {

		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " updateSummaryFileLoadMaster");
		}
		try {
			
			SummaryFileLoadMaster summaryFileLoadMaster = null;

			DetachedCriteria detachedCriteria = hibernateDao
					.createCriteria(SummaryFileLoadMaster.class);
			detachedCriteria.add(Restrictions
					.eq("summaryFileId", summaryFileId));

			List<SummaryFileLoadMaster> summFileLoadMasterList = (List<SummaryFileLoadMaster>) hibernateDao
					.find(detachedCriteria);

			if (null != summFileLoadMasterList
					&& !summFileLoadMasterList.isEmpty()) {
				summaryFileLoadMaster = summFileLoadMasterList.get(0);
			}

			//Sonar Fix checked for null
			if (null != summaryFileLoadMaster){
			summaryFileLoadMaster.setStatus(status);
			summaryFileLoadMaster.setCountRec(recordCount);
			hibernateDao.saveOrUpdate(summaryFileLoadMaster);
			}
			if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " updateSummaryFileLoadMaster");
			}
			return Constant.SUCCESS;
		} catch (Exception e) {
			if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD + " updateSummaryFileLoadMaster"
					+ e);
			}
			return Constant.FAILED;
		}

	}
}
