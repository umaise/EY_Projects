package com.ey.advisory.asp.client.util;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * @author Divya.Dsouza
 *
 *Added as a part of sprint 1 to make GSTN call via GSP
 */
@Component
@PropertySource("classpath:RestConfig.properties")
public class GSPRestClientUtility {

	private static final Logger LOGGER = Logger.getLogger(GSPRestClientUtility.class);
	
	@Resource(name="${restTemplate.proxy}")
	RestTemplate restTemplate; 

	//POST
	public String executeRestCall(String uri, HttpHeaders httpHeaders, String inputData,HttpMethod httpMethod) {

		String result = "";
		HttpEntity<String> entity = new HttpEntity<>(inputData, httpHeaders);
		try {
			ResponseEntity<String> response = restTemplate.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpClientErrorException hcee) {
			LOGGER.error(hcee);
			return hcee.getMessage();
		} catch (HttpServerErrorException hsee) {
			LOGGER.error(hsee);
			return hsee.getMessage();
		}catch (HttpStatusCodeException hsce) {
			LOGGER.error(hsce);
			return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error(e);
			return e.getMessage();
		}

		return result;
	}

	//GET
	public String executeRestCall(String uri, HttpHeaders httpHeaders, HttpMethod httpMethod){
		String result = "";
		HttpEntity<Object> entity = new HttpEntity<>(httpHeaders);
		try {
			ResponseEntity<String> response = restTemplate.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch(HttpClientErrorException hcce){
			LOGGER.error(hcce);
			return hcce.getMessage();
		}catch (HttpStatusCodeException hsce) {
			LOGGER.error(hsce);
				return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error(e);
			return e.getMessage();
		}

		return result;
	}

}
