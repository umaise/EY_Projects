package com.ey.advisory.asp.client.service.gstr1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.client.dao.GSTR1Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR1AdvA_Payment_ItemDetail;
import com.ey.advisory.asp.client.domain.GSTR1Adv_Payment_ItemDetail;
import com.ey.advisory.asp.client.domain.GSTR1TaxPaidData;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.client.dto.AdvTaxPaymentDto;
import com.ey.advisory.asp.client.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.client.util.ErrorActionUtility;
import com.ey.advisory.asp.common.Constant;

@Service
public class Gstr1AdvTaxValidationServiceImpl implements
		Gstr1AdvTaxValidationService {

	@Autowired
	HibernateDao hibernateDao;

	@Autowired
	GSTR1Dao gstr1Dao;
	
	@Autowired
	ErrorActionUtility errorActionUtility;





}
