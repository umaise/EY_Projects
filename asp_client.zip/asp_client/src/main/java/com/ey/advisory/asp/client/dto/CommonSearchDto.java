package com.ey.advisory.asp.client.dto;

public class CommonSearchDto {
	
	String pageNum;
	
	String rownumInPerPage;
	
	String searchText;
	
	String orderBy;
	
	String entityId;

	String gstin;

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	
	public String getEntityId() {
		return entityId;
	}

	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	/**
	 * @return the pageNum
	 */
	public String getPageNum() {
		return pageNum;
	}

	/**
	 * @param pageNum the pageNum to set
	 */
	public void setPageNum(String pageNum) {
		this.pageNum = pageNum;
	}

	/**
	 * @return the rownumInPerPage
	 */
	public String getRownumInPerPage() {
		return rownumInPerPage;
	}

	/**
	 * @param rownumInPerPage the rownumInPerPage to set
	 */
	public void setRownumInPerPage(String rownumInPerPage) {
		this.rownumInPerPage = rownumInPerPage;
	}

	/**
	 * @return the searchText
	 */
	public String getSearchText() {
		return searchText;
	}

	/**
	 * @param searchText the searchText to set
	 */
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	/**
	 * @return the orderBy
	 */
	public String getOrderBy() {
		return orderBy;
	}

	/**
	 * @param orderBy the orderBy to set
	 */
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

}
