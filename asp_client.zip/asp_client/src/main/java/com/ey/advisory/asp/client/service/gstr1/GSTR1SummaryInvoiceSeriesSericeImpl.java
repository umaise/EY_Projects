package com.ey.advisory.asp.client.service.gstr1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GSTR1SummaryInvoiceSeriesDao;
import com.ey.advisory.asp.client.domain.GSTR1SummaryInvoiceSeries;

@Service
public class GSTR1SummaryInvoiceSeriesSericeImpl implements GSTR1SummaryInvoiceSeriesService{
	
	@Autowired
	private GSTR1SummaryInvoiceSeriesDao invoiceSeriesDao;

	@Override
	public List<GSTR1SummaryInvoiceSeries> getInvoiceSeriesMetadata() {
		return invoiceSeriesDao.getInvoiceSeriesMetadata();
	}

}
