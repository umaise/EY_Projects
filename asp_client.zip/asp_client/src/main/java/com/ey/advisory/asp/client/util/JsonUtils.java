package com.ey.advisory.asp.client.util;

import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/*
 * @author Shreya.Mukund
 * 
 */

public class JsonUtils {

	private static final Logger logger = Logger.getLogger(JsonUtils.class);
	
	
	public static JSONArray convertToJsonArr(List t,List<String> cols){
		JSONArray jsonArr= new JSONArray();
		try{
			if(t!=null){
				for(Object obj : t){
					JSONObject jsonObj = new JSONObject();
					Object[] objArr = (Object[])obj;
					int i=0;
					for(Object column :objArr){
						jsonObj.put(cols.get(i), column);
						i++;
					}
					jsonArr.add(jsonObj);
				}
				
				return jsonArr;
			}else
				return null;
			
		}catch(Exception e){
			logger.error("Exception in conversion of db list to json list",e);
			return null;
		}
	}
}
