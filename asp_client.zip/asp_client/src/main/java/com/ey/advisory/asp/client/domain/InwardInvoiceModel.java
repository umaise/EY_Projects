package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.Length;

import com.ey.advisory.asp.client.util.CommonUtillity;
import com.ey.advisory.asp.common.Constant;
import com.google.gson.annotations.SerializedName;

/**
 * The persistent class for the tblClientPurchaseStaging database table.
 * 
 */
@Entity
@Table(name="tblPurchaseStaging", schema=Constant.ETL_SCHEMA)

@NamedQueries({ 
    @NamedQuery(name = "InwardInvoiceModel.updateStatus",  query = "update InwardInvoiceModel set "
        + "itemStatus=:STATUS , tableType=:TYPE, subCategory=:SUBCATEGORY , eligibilityIndicator=:eligibilityIndicator , availableCESS=:availableCESS, "
        + "availableCGST=:availableCGST, availableIGST=:availableIGST, availableSGST=:availableSGST where fileID= :FILEID and invOrder= :INVORDER and lineNumber = :LINENUMBER") ,
    @NamedQuery(name="InwardInvoiceModel.findAll", query="SELECT t FROM InwardInvoiceModel t"),
    @NamedQuery(name="InwardInvoiceModel.markTechError", query="update InwardInvoiceModel set itemStatus='BATCH_TECH_ERROR' where fileID=:FILEID and itemStatus is null and tableType is null and isError=0")})


public class InwardInvoiceModel implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="ID")
    @SerializedName("ID")
    private int id;

    @Column(name="FileID")
    @SerializedName("FileID")
    private int fileID;

    @Column(name="SourceIdentifier")@Length(max = 25)
    @SerializedName("SourceIdentifier")
    private String sourceIdentifier;
    
    @Column(name="SourceFileName")@Length(max = 50)
    @SerializedName("SourceFileName")
    private String sourceFileName;
    
    @Column(name="GLAccountCode")@Length(max = 25)
    @SerializedName("GLAccountCode")
    private String gLAccountCode;
    
    @Column(name="Division")@Length(max = 20)
    @SerializedName("Division")
    private String division;

    @Column(name="SubDivision")@Length(max = 20)
    @SerializedName("SubDivision")
    private String subDivision;

    @Column(name="ProfitCentre1")@Length(max = 20)
    @SerializedName("ProfitCentre1")
    private String profitCentre1;

    @Column(name="ProfitCentre2")@Length(max = 20)
    @SerializedName("ProfitCentre2")
    private String profitCentre2;

    @Column(name="PlantCode")@Length(max = 20)
    @SerializedName("PlantCode")
    private String plantCode;

    @Column(name="TaxPeriod")
    @SerializedName("TaxPeriod")
    private String taxPeriod;

    @Column(name="CGSTIN")@Length(max = 15)
    @SerializedName("CGSTIN")
    private String CGSTIN;

    @Column(name="DocumentType")@Length(max = 5)
    @SerializedName("DocumentType")
    private String documentType;

    @Column(name="SupplyType")@Length(max = 5)
    @SerializedName("SupplyType")
    private String supplyType;
    
    @Column(name="DocumentNo")@Length(max = 16)
    @SerializedName("DocumentNo")
    private String documentNo;
    
    @Temporal(TemporalType.DATE)
    @Column(name="DocumentDate")
    private Date documentDate;
    
    @Transient
    @SerializedName("DocumentDate")
    private String documentDateStr;

    @Temporal(TemporalType.DATE)
    @Column(name="OriginalDocumentDate")@Length(max =16)
    @SerializedName("OriginalDocumentDate")
    private Date originalDocumentDate;

    @Column(name="OriginalDocumentNo")
    @SerializedName("OriginalDocumentNo")
    private String originalDocumentNo;

    @Column(name="CRDRPreGST")
    @SerializedName("CRDRPreGST")
    private String CRDRPreGST;
    
    @Column(name="LineNumber")
    @SerializedName("LineNumber")
    private int lineNumber;

    @Column(name="SGSTIN")@Length(max = 15)
    @SerializedName("SGSTIN")
    private String SGSTIN;

    @Column(name="OriginalSGSTIN")@Length(max = 15)
    @SerializedName("OriginalSGSTIN")
    private String originalSGSTIN;

    @Column(name="SupplierName")@Length(max = 40)
    @SerializedName("SupplierName")
    private String supplierName;

    @Column(name="SupplierCode")@Length(max = 20)
    @SerializedName("SupplierCode")
    private String supplierCode;

    @Column(name="POS")@Length(max = 2)
    @SerializedName("POS")
    private String pos;

    @Column(name="BillOfEntry")@Length(max = 13)
    @SerializedName("BillOfEntry")
    private String billOfEntry;

    @Temporal(TemporalType.DATE)
    @Column(name="BillOfEntryDate")
    @SerializedName("BillOfEntryDate")
    private Date billOfEntryDate;

    @Column(name="CIFValue")
    @SerializedName("CIFValue")
    private BigDecimal CIFValue;

    @Column(name="CustomDuty")
    @SerializedName("CustomDuty")
    private BigDecimal customDuty;

    @Column(name="HSNorSAC")@Length(max = 10)
    @SerializedName("HSNorSAC")
    private String HSNorSAC;

    @Column(name="ItemCode")@Length(max = 20)
    @SerializedName("ItemCode")
    private String itemCode;

    @Column(name="ItemDescription")@Length(max = 100)
    @SerializedName("ItemDescription")
    private String itemDescription;

    @Column(name="ItemCategory")@Length(max = 30)
    @SerializedName("ItemCategory")
    private String itemCategory;

    @Column(name="UnitofMeasurement")@Length(max = 30)
    @SerializedName("UnitofMeasurement")
    private String unitofMeasurement;

    @Column(name="Quantity")
    @SerializedName("Quantity")
    private BigDecimal quantity;

    @Column(name="TaxableValue")
    @SerializedName("TaxableValue")
    private BigDecimal taxableValue;
    
    @Column(name="IGSTAmount")
    @SerializedName("IGSTAmount")
    private BigDecimal IGSTAmount;

    @Column(name="IGSTRate")
    @SerializedName("IGSTRate")
    private BigDecimal IGSTRate;

    @Column(name="CGSTAmount")
    @SerializedName("CGSTAmount")
    private BigDecimal CGSTAmount;

    @Column(name="CGSTRate")
    @SerializedName("CGSTRate")
    private BigDecimal CGSTRate;

    @Column(name="SGSTAmount")
    @SerializedName("SGSTAmount")
    private BigDecimal SGSTAmount;

    @Column(name="SGSTRate")
    @SerializedName("SGSTRate")
    private BigDecimal SGSTRate;

    @Column(name="CessAmountAdvalorem")
    @SerializedName("CessAmountAdvalorem")
    private BigDecimal cessAmountAdvalorem;

    @Column(name="CessRateAdvalorem")
    @SerializedName("CessRateAdvalorem")
    private BigDecimal cessRateAdvalorem;
    
    @Column(name="CessAmountSpecific")
    @SerializedName("CessAmountSpecific")
    private BigDecimal cessAmountSpecific;

    @Column(name="CessRateSpecific")
    @SerializedName("CessRateSpecific")
    private BigDecimal cessRateSpecific;

    @Column(name="InvoiceValue")
    @SerializedName("InvoiceValue")
    private BigDecimal invoiceValue;

    @Column(name="ReverseCharge")
    @SerializedName("ReverseCharge")
    private String reverseCharge;
    
    @Column(name="EligibilityIndicator")
    @SerializedName("EligibilityIndicator")
    private String eligibilityIndicator;

    @Column(name="CommonSupplyIndicator")
    @SerializedName("CommonSupplyIndicator")
    private String commonSupplyIndicator;

    @Column(name="AvailableCESS")
    @SerializedName("AvailableCESS")
    private BigDecimal availableCESS;

    @Column(name="AvailableCGST")
    @SerializedName("AvailableCGST")
    private BigDecimal availableCGST;

    @Column(name="AvailableIGST")
    @SerializedName("AvailableIGST")
    private BigDecimal availableIGST;

    @Column(name="AvailableSGST")
    @SerializedName("AvailableSGST")
    private BigDecimal availableSGST;

    @Column(name="ITCReversalIdentifier")
    @SerializedName("ITCReversalIdentifier")
    private String ITCReversalIdentifier;

    @Column(name="ReasonForCreditDebitNote")
    @SerializedName("ReasonForCreditDebitNote")
    private String reasonForCreditDebitNote;

    @Column(name="PurchaseVoucherNumber")
    @SerializedName("PurchaseVoucherNumber")
    private String purchaseVoucherNumber;
    
    @Temporal(TemporalType.DATE)
    @Column(name="PurchaseVoucherDate")
    @SerializedName("PurchaseVoucherDate")
    private Date purchaseVoucherDate;

    @Column(name="PaymentVoucherNumber")
    @SerializedName("PaymentVoucherNumber")
    private String paymentVoucherNumber;

    @Temporal(TemporalType.DATE)
    @Column(name="DateofPayment")
    @SerializedName("DateofPayment")
    private Date dateofPayment;

    @Column(name="ContractNumber")
    @SerializedName("ContractNumber")
    private String contractNumber;
    
    @Temporal(TemporalType.DATE)
    @Column(name="Contractdate")
    @SerializedName("Contractdate")
    private Date contractdate;

    @Column(name="ContractValue")
    @SerializedName("ContractValue")
    private BigDecimal contractValue;

    @Column(name="Userdefinedfield1")
    @SerializedName("Userdefinedfield1")
    private String userdefinedfield1;

    @Column(name="Userdefinedfield2")
    @SerializedName("Userdefinedfield2")
    private String userdefinedfield2;
    
    @Column(name="Userdefinedfield3")
    @SerializedName("Userdefinedfield3")
    private String userdefinedfield3;

    @Column(name="AggInvoice")
    @SerializedName("AggInvoice")
    private BigDecimal aggInvoice;

    @Column(name="AggTaxableValue")
    @SerializedName("AggTaxableValue")
    private BigDecimal aggTaxableValue;

    @Column(name="InvOrder")
    @SerializedName("InvOrder")
    private Integer invOrder;

    @Column(name="Status")
    @SerializedName("Status")
    private String itemStatus;
    
    @Column(name="RecordType")
    @SerializedName("RecordType")
    private String tableType;

    @Column(name="SupplyCategory")
    @SerializedName("SupplyCategory")
    private String supplyCategory;
    
    @Column(name="IsProcessed")
    @SerializedName("IsProcessed")
    private boolean isProcessed;

    @Column(name="IsError")
    @SerializedName("IsError")
    private boolean isError;

    @Column(name="NewInvOrder")
    @SerializedName("NewInvOrder")
    private Long newInvOrder;

    @Column(name="IsDuplicate")
    @SerializedName("IsDuplicate")
    private boolean isDuplicate;

    @Column(name="IsPreStageError")
    @SerializedName("IsPreStageError")
    private boolean isPreStageError;

    @Column(name="Chksum")
    @SerializedName("Chksum")
    private String chksum;

    @Column(name="InvoiceKey")
    @SerializedName("InvoiceKey")
    private String invoiceKey;

    @Column(name="SubCategory")
    @SerializedName("SubCategory")
    private String subCategory;
    
    @Column(name="PortCode")
    @SerializedName("PortCode")
    private String portCode;
    
    @Column(name="IsISD")
    @SerializedName("IsISD")
    private boolean isISD;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "InvoiceKey",referencedColumnName="InvoiceKey", nullable = false, insertable=false, updatable=false)
	private GSTR2InvoiceKeyDetail gstr2InvoiceKeyDetail;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "InvoiceKey",referencedColumnName="InvKey", nullable = false, insertable=false, updatable=false)
	private ReconResult reconResult;
	
	@Transient
	private String eySuggestedResponse;
	
	@Transient
	private String clientResponse;
	
	@Transient
	private String reconResponse; 

    
    public GSTR2InvoiceKeyDetail getGstr2InvoiceKeyDetail() {
		return gstr2InvoiceKeyDetail;
	}

	public void setGstr2InvoiceKeyDetail(GSTR2InvoiceKeyDetail gstr2InvoiceKeyDetail) {
		this.gstr2InvoiceKeyDetail = gstr2InvoiceKeyDetail;
	}
	
	public ReconResult getReconResult() {
		return reconResult;
	}

	public void setReconResult(ReconResult reconResult) {
		this.reconResult = reconResult;
	}


	@OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "ErrorInfoID", referencedColumnName="ID")
    private Set<TblPurchaseErrorInfo> tblErrorInfo;
    
    public Set<TblPurchaseErrorInfo> getTblErrorInfo() {
        return tblErrorInfo;
    }

    public void setTblErrorInfo(Set<TblPurchaseErrorInfo> tblErrorInfo) {
        this.tblErrorInfo = tblErrorInfo;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFileID() {
		return fileID;
	}

	public void setFileID(int fileID) {
		this.fileID = fileID;
	}

	public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getSubDivision() {
        return subDivision;
    }

    public void setSubDivision(String subDivision) {
        this.subDivision = subDivision;
    }

    public String getProfitCentre1() {
        return profitCentre1;
    }

    public void setProfitCentre1(String profitCentre1) {
        this.profitCentre1 = profitCentre1;
    }

    public String getProfitCentre2() {
        return profitCentre2;
    }

    public void setProfitCentre2(String profitCentre2) {
        this.profitCentre2 = profitCentre2;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getTaxPeriod() {
        return taxPeriod;
    }

    public void setTaxPeriod(String taxPeriod) {
        this.taxPeriod = taxPeriod;
    }

    public String getCGSTIN() {
        return CGSTIN;
    }

    public void setCGSTIN(String cGSTIN) {
        CGSTIN = cGSTIN;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getSupplyType() {
        return supplyType;
    }

    public void setSupplyType(String supplyType) {
        this.supplyType = supplyType;
    }

    public String getDocumentNo() {
        return documentNo;
    }

    public void setDocumentNo(String documentNo) {
        this.documentNo = documentNo;
    }

    public Date getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }

    public String getOriginalDocumentNo() {
        return originalDocumentNo;
    }

    public void setOriginalDocumentNo(String originalDocumentNo) {
        this.originalDocumentNo = originalDocumentNo;
    }

    public Date getOriginalDocumentDate() {
        return originalDocumentDate;
    }

    public void setOriginalDocumentDate(Date originalDocumentDate) {
        this.originalDocumentDate = originalDocumentDate;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getSGSTIN() {
        return SGSTIN;
    }

    public void setSGSTIN(String sGSTIN) {
        SGSTIN = sGSTIN;
    }

    public String getOriginalSGSTIN() {
        return originalSGSTIN;
    }

    public void setOriginalSGSTIN(String originalSGSTIN) {
        this.originalSGSTIN = originalSGSTIN;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getSupplierCode() {
        return supplierCode;
    }

    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    public String getPos() {
        return pos;
    }

    public void setPos(String pos) {
        this.pos = pos;
    }

    public String getBillOfEntry() {
        return billOfEntry;
    }

    public void setBillOfEntry(String billOfEntry) {
        this.billOfEntry = billOfEntry;
    }

    public Date getBillOfEntryDate() {
        return billOfEntryDate;
    }

    public void setBillOfEntryDate(Date billOfEntryDate) {
        this.billOfEntryDate = billOfEntryDate;
    }

    public BigDecimal getCIFValue() {
        return CIFValue;
    }

    public void setCIFValue(BigDecimal cIFValue) {
        CIFValue = cIFValue;
    }

    public BigDecimal getCustomDuty() {
        return customDuty;
    }

    public void setCustomDuty(BigDecimal customDuty) {
        this.customDuty = customDuty;
    }

    public String getHSNorSAC() {
        return HSNorSAC;
    }

    public void setHSNorSAC(String hSNorSAC) {
        HSNorSAC = hSNorSAC;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public String getItemCategory() {
        return itemCategory;
    }

    public void setItemCategory(String itemCategory) {
        this.itemCategory = itemCategory;
    }

    public String getUnitofMeasurement() {
        return unitofMeasurement;
    }

    public void setUnitofMeasurement(String unitofMeasurement) {
        this.unitofMeasurement = unitofMeasurement;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getTaxableValue() {
        return taxableValue;
    }

    public void setTaxableValue(BigDecimal taxableValue) {
        this.taxableValue = taxableValue;
    }

    public BigDecimal getIGSTAmount() {
        return IGSTAmount;
    }

    public void setIGSTAmount(BigDecimal iGSTAmount) {
        IGSTAmount = iGSTAmount;
    }

    public BigDecimal getIGSTRate() {
        return IGSTRate;
    }

    public void setIGSTRate(BigDecimal iGSTRate) {
        IGSTRate = iGSTRate;
    }

    public BigDecimal getCGSTAmount() {
        return CGSTAmount;
    }

    public void setCGSTAmount(BigDecimal cGSTAmount) {
        CGSTAmount = cGSTAmount;
    }

    public BigDecimal getCGSTRate() {
        return CGSTRate;
    }

    public void setCGSTRate(BigDecimal cGSTRate) {
        CGSTRate = cGSTRate;
    }

    public BigDecimal getSGSTAmount() {
        return SGSTAmount;
    }

    public void setSGSTAmount(BigDecimal sGSTAmount) {
        SGSTAmount = sGSTAmount;
    }

    public BigDecimal getSGSTRate() {
        return SGSTRate;
    }

    public void setSGSTRate(BigDecimal sGSTRate) {
        SGSTRate = sGSTRate;
    }

    public BigDecimal getCessAmountAdvalorem() {
        return cessAmountAdvalorem;
    }

    public void setCessAmountAdvalorem(BigDecimal cessAmountAdvalorem) {
        this.cessAmountAdvalorem = cessAmountAdvalorem;
    }

    public BigDecimal getCessRateAdvalorem() {
        return cessRateAdvalorem;
    }

    public void setCessRateAdvalorem(BigDecimal cessRateAdvalorem) {
        this.cessRateAdvalorem = cessRateAdvalorem;
    }

    public BigDecimal getCessAmountSpecific() {
        return cessAmountSpecific;
    }

    public void setCessAmountSpecific(BigDecimal cessAmountSpecific) {
        this.cessAmountSpecific = cessAmountSpecific;
    }

    public BigDecimal getCessRateSpecific() {
        return cessRateSpecific;
    }

    public void setCessRateSpecific(BigDecimal cessRateSpecific) {
        this.cessRateSpecific = cessRateSpecific;
    }

    public BigDecimal getInvoiceValue() {
        return invoiceValue;
    }

    public void setInvoiceValue(BigDecimal invoiceValue) {
        this.invoiceValue = invoiceValue;
    }

    public String getReverseCharge() {
        return reverseCharge;
    }

    public void setReverseCharge(String reverseCharge) {
        this.reverseCharge = reverseCharge;
    }

    public String getEligibilityIndicator() {
        return eligibilityIndicator;
    }

    public void setEligibilityIndicator(String eligibilityIndicator) {
        this.eligibilityIndicator = eligibilityIndicator;
    }

    public String getCommonSupplyIndicator() {
        return commonSupplyIndicator;
    }

    public void setCommonSupplyIndicator(String commonSupplyIndicator) {
        this.commonSupplyIndicator = commonSupplyIndicator;
    }

    public BigDecimal getAvailableCESS() {
        return availableCESS;
    }

    public void setAvailableCESS(BigDecimal availableCESS) {
        this.availableCESS = availableCESS;
    }

    public BigDecimal getAvailableCGST() {
        return availableCGST;
    }

    public void setAvailableCGST(BigDecimal availableCGST) {
        this.availableCGST = availableCGST;
    }

    public BigDecimal getAvailableIGST() {
        return availableIGST;
    }

    public void setAvailableIGST(BigDecimal availableIGST) {
        this.availableIGST = availableIGST;
    }

    public BigDecimal getAvailableSGST() {
        return availableSGST;
    }

    public void setAvailableSGST(BigDecimal availableSGST) {
        this.availableSGST = availableSGST;
    }

    public String getITCReversalIdentifier() {
        return ITCReversalIdentifier;
    }

    public void setITCReversalIdentifier(String iTCReversalIdentifier) {
        ITCReversalIdentifier = iTCReversalIdentifier;
    }

    public String getReasonForCreditDebitNote() {
        return reasonForCreditDebitNote;
    }

    public void setReasonForCreditDebitNote(String reasonForCreditDebitNote) {
        this.reasonForCreditDebitNote = reasonForCreditDebitNote;
    }

    public String getPurchaseVoucherNumber() {
        return purchaseVoucherNumber;
    }

    public void setPurchaseVoucherNumber(String purchaseVoucherNumber) {
        this.purchaseVoucherNumber = purchaseVoucherNumber;
    }

    public Date getPurchaseVoucherDate() {
        return purchaseVoucherDate;
    }

    public void setPurchaseVoucherDate(Date purchaseVoucherDate) {
        this.purchaseVoucherDate = purchaseVoucherDate;
    }

    public String getPaymentVoucherNumber() {
        return paymentVoucherNumber;
    }

    public void setPaymentVoucherNumber(String paymentVoucherNumber) {
        this.paymentVoucherNumber = paymentVoucherNumber;
    }

    public Date getDateofPayment() {
        return dateofPayment;
    }

    public void setDateofPayment(Date dateofPayment) {
        this.dateofPayment = dateofPayment;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public Date getContractdate() {
        return contractdate;
    }

    public void setContractdate(Date contractdate) {
        this.contractdate = contractdate;
    }

    public BigDecimal getContractValue() {
        return contractValue;
    }

    public void setContractValue(BigDecimal contractValue) {
        this.contractValue = contractValue;
    }

    public BigDecimal getAggInvoice() {
        return aggInvoice;
    }

    public void setAggInvoice(BigDecimal aggInvoice) {
        this.aggInvoice = aggInvoice;
    }

    public BigDecimal getAggTaxableValue() {
        return aggTaxableValue;
    }

    public void setAggTaxableValue(BigDecimal aggTaxableValue) {
        this.aggTaxableValue = aggTaxableValue;
    }

    public Integer getInvOrder() {
        return invOrder;
    }

    public void setInvOrder(Integer invOrder) {
        this.invOrder = invOrder;
    }

    public String getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(String itemStatus) {
        this.itemStatus = itemStatus;
    }

    public String getTableType() {
        return tableType;
    }

    public void setTableType(String tableType) {
        this.tableType = tableType;
    }

    public String getSupplyCategory() {
        return supplyCategory;
    }

    public void setSupplyCategory(String supplyCategory) {
        this.supplyCategory = supplyCategory;
    }

    public boolean isProcessed() {
        return isProcessed;
    }

    public void setProcessed(boolean isProcessed) {
        this.isProcessed = isProcessed;
    }

    public boolean isError() {
        return isError;
    }

    public void setError(boolean isError) {
        this.isError = isError;
    }

    public Long getNewInvOrder() {
        return newInvOrder;
    }

    public void setNewInvOrder(Long newInvOrder) {
        this.newInvOrder = newInvOrder;
    }

    public boolean isDuplicate() {
        return isDuplicate;
    }

    public void setDuplicate(boolean isDuplicate) {
        this.isDuplicate = isDuplicate;
    }

    public boolean isPreStageError() {
        return isPreStageError;
    }

    public void setPreStageError(boolean isPreStageError) {
        this.isPreStageError = isPreStageError;
    }

    public String getChksum() {
        return chksum;
    }

    public void setChksum(String chksum) {
        this.chksum = chksum;
    }

    public String getInvoiceKey() {
        return invoiceKey;
    }

    public void setInvoiceKey(String invoiceKey) {
        this.invoiceKey = invoiceKey;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public String getSourceFileName() {
        return sourceFileName;
    }

    public void setSourceFileName(String sourceFileName) {
        this.sourceFileName = sourceFileName;
    }

    public String getgLAccountCode() {
        return gLAccountCode;
    }

    public void setgLAccountCode(String gLAccountCode) {
        this.gLAccountCode = gLAccountCode;
    }

    public String getCRDRPreGST() {
        return CRDRPreGST;
    }

    public void setCRDRPreGST(String cRDRPreGST) {
        CRDRPreGST = cRDRPreGST;
    }

    public String getUserdefinedfield1() {
        return userdefinedfield1;
    }

    public void setUserdefinedfield1(String userdefinedfield1) {
        this.userdefinedfield1 = userdefinedfield1;
    }

    public String getUserdefinedfield2() {
        return userdefinedfield2;
    }

    public void setUserdefinedfield2(String userdefinedfield2) {
        this.userdefinedfield2 = userdefinedfield2;
    }

    public String getUserdefinedfield3() {
        return userdefinedfield3;
    }

    public void setUserdefinedfield3(String userdefinedfield3) {
        this.userdefinedfield3 = userdefinedfield3;
    }

	public String getDocumentDateStr() {
		return documentDateStr;
	}

	public void setDocumentDateStr(String documentDateStr) {
		this.documentDateStr = documentDateStr;
	}
    
	public String getPortCode() {
		return portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}
	
	public boolean isISD() {
		return isISD;
	}

	public void setISD(boolean isISD) {
		this.isISD = isISD;
	}

	public String getEySuggestedResponse() {
		return eySuggestedResponse;
	}

	public void setEySuggestedResponse(String eySuggestedResponse) {
		this.eySuggestedResponse = eySuggestedResponse;
	}

	public String getClientResponse() {
		return clientResponse;
	}

	public void setClientResponse(String clientResponse) {
		this.clientResponse = clientResponse;
	}
	
	

	public String getReconResponse() {
		return reconResponse;
	}

	public void setReconResponse(String reconResponse) {
		this.reconResponse = reconResponse;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InwardInvoiceModel other = (InwardInvoiceModel) obj;
		if (id != other.id)
			return false;
		return true;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public String toString() {
		return (sourceIdentifier != null ? CommonUtillity.formatCommasWithSpaces(sourceIdentifier) : "") + "," + (sourceFileName != null ? CommonUtillity.formatCommasWithSpaces(sourceFileName) : "") + ","
				+ (gLAccountCode != null ? gLAccountCode : "") + "," + (division != null ? CommonUtillity.formatCommasWithSpaces(division) : "") + ","
				+ (subDivision != null ? CommonUtillity.formatCommasWithSpaces(subDivision) : "") + "," + (profitCentre1 != null ? profitCentre1 : "") + ","
				+ (profitCentre2 != null ? profitCentre2 : "") + "," + (plantCode != null ? plantCode : "") + "," 
				+ (taxPeriod != null ? taxPeriod : "") + "," + (CGSTIN != null ? CGSTIN : "") + ","
				+ (documentType != null ? documentType : "") + "," + (supplyType != null ? supplyType : "") + ","
				+ (documentNo != null ? documentNo : "") + "," + (documentDate != null ? documentDate : "") + ","
				+ (originalDocumentNo != null ? originalDocumentNo : "") + "," + (originalDocumentDate != null ? originalDocumentDate : "") + ","
				+ (CRDRPreGST != null ? CRDRPreGST : "") + "," + (lineNumber != 0 ? lineNumber : "") + "," 
				+ (SGSTIN != null ? SGSTIN : "") + "," + (originalSGSTIN != null ? originalSGSTIN : "") + "," 
				+ (supplierName != null ? supplierName : "") + "," + (supplierCode != null ? supplierCode : "") + ","
				+ (pos != null ? pos : "") + "," + (portCode != null ? portCode : "") + ","  
				+ (billOfEntry != null ? billOfEntry : "") + "," + (billOfEntryDate != null ? billOfEntryDate : "") + ","
				+ (CIFValue != null ? CIFValue : "") + "," + (customDuty != null ? customDuty : "") + ","
				+ (HSNorSAC != null ? HSNorSAC : "") + ","	+ (itemCode != null ? CommonUtillity.formatCommasWithSpaces(itemCode) : "") + "," 
				+ (itemDescription != null ? CommonUtillity.formatCommasWithSpaces(itemDescription) : "") + "," + (itemCategory != null ? CommonUtillity.formatCommasWithSpaces(itemCategory) : "") + "," 
				+ (unitofMeasurement != null ? unitofMeasurement : "") + ","+ (quantity != null ? quantity : "") + "," 
				+ (taxableValue != null ? taxableValue : "") + "," + (IGSTRate != null ? IGSTRate : "") + "," 
				+ (IGSTAmount != null ? IGSTAmount : "") + "," + (CGSTRate != null ? CGSTRate : "") + "," 
				+ (CGSTAmount != null ? CGSTAmount : "") + "," + (SGSTRate != null ? SGSTRate : "") + ","
				+ (SGSTAmount != null ? SGSTAmount : "") + "," + (cessRateAdvalorem != null ? cessRateAdvalorem : "") + "," 
				+ (cessAmountAdvalorem != null ? cessAmountAdvalorem : "") + "," + (cessRateSpecific != null ? cessRateSpecific : "") + "," 
				+ (cessAmountSpecific != null ? cessAmountSpecific : "") + "," + (invoiceValue != null ? invoiceValue : "") + "," 
				+ (reverseCharge != null ? reverseCharge : "") + "," + (eligibilityIndicator != null ? eligibilityIndicator : "") + "," 
				+ (commonSupplyIndicator != null ? commonSupplyIndicator : "") + "," + (availableIGST != null ? availableIGST : "") + "," 
				+ (availableCGST != null ? availableCGST : "") + "," + (availableSGST != null ? availableSGST : "") + "," 
				+ (availableCESS != null ? availableCESS : "") + "," + (ITCReversalIdentifier != null ? ITCReversalIdentifier : "") + ","
				+ (reasonForCreditDebitNote != null ? CommonUtillity.formatCommasWithSpaces(reasonForCreditDebitNote) : "") + "," + (purchaseVoucherNumber != null ? purchaseVoucherNumber : "") + ","
				+ (purchaseVoucherDate != null ? purchaseVoucherDate : "") + ","+ (paymentVoucherNumber != null ? paymentVoucherNumber : "") + "," 
				+ (dateofPayment != null ? dateofPayment : "") + "," + (contractNumber != null ? contractNumber : "") + "," 
				+ (contractdate != null ? contractdate : "") + "," + (contractValue != null ? contractValue : "") + "," 
				+ (userdefinedfield1 != null ? userdefinedfield1 : "") + "," + (userdefinedfield2 != null ? userdefinedfield2 : "") + "," 
				+ (userdefinedfield3 != null ? userdefinedfield3 : "");
	}
	

		/*@Override
		public String toString() {
			return sourceIdentifier + "," + sourceFileName + "," + gLAccountCode 
					+ "," + division + "," + subDivision + "," + profitCentre1
					+ "," + profitCentre2 + "," + plantCode + "," + taxPeriod
					+ "," + CGSTIN + "," + documentType + "," + supplyType
					+ "," + documentNo + "," + documentDate + ","
					+ "," + originalDocumentDate + ","+ portCode +","
					+ originalDocumentNo + "," + CRDRPreGST + "," + lineNumber
					+ "," + SGSTIN + "," + originalSGSTIN + "," + supplierName
					+ "," + supplierCode + "," + pos + "," + billOfEntry + ","
					+ billOfEntryDate + "," + CIFValue + "," + customDuty + ","
					+ HSNorSAC + "," + itemCode + "," + itemDescription + ","
					+ itemCategory + "," + unitofMeasurement + "," + quantity
					+ "," + taxableValue + "," + IGSTAmount + "," + IGSTRate
					+ "," + CGSTAmount + "," + CGSTRate + "," + SGSTAmount
					+ "," + SGSTRate + "," + cessAmountAdvalorem + ","
					+ cessRateAdvalorem + "," + cessAmountSpecific + ","
					+ cessRateSpecific + "," + invoiceValue + "," + reverseCharge
					+ "," + eligibilityIndicator + "," + commonSupplyIndicator
					+ "," + availableCESS + "," + availableCGST + ","
					+ availableIGST + "," + availableSGST + ","
					+ ITCReversalIdentifier + "," + reasonForCreditDebitNote
					+ "," + purchaseVoucherNumber + "," + purchaseVoucherDate
					+ "," + paymentVoucherNumber + "," + dateofPayment + ","
					+ contractNumber + "," + contractdate + "," + contractValue
					+ "," + userdefinedfield1 + "," + userdefinedfield2 + ","
					+ userdefinedfield3 ;
		}*/
}
