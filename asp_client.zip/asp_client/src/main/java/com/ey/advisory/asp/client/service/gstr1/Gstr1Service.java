package com.ey.advisory.asp.client.service.gstr1;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;

import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.GSTR1B2BCLEAInvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR1B2CSA_InvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR1B2CS_InvoiceDetail;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.PayloadStatus;
import com.ey.advisory.asp.client.domain.ReturnType;
import com.ey.advisory.asp.client.domain.TblEmailStatusDetails;
import com.ey.advisory.asp.client.domain.TblFileUploadStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.client.dto.CounterPartySalesDto;
import com.ey.advisory.asp.client.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.client.dto.ParentSalePurchaseDto;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.dto.InvoiceProcessDto;

/**
 * Service contains all the methods related to GSTR1 form
 *
 */
public interface Gstr1Service {

	String gstr1Summary(String gstn, String month, String year);

	Object getGSTR1SummaryfromDB(String gstn, String taxPeriod);

	public String sendGSTR1Data(String jsonGstr1Data,
			String gstinNum);
	
	public String saveTblTypeErrLstAndRoute(String key) throws Exception ;
	
/*	public String timeoutSaveTblTypeErrLstAndRoute(String key) throws Exception ;*/

	boolean saveSalesErrorInfo(Set<TblSalesErrorInfo> errorInfoList) throws Exception ;
	
	boolean timeoutAndSaveSalesErrorInfo(Set<TblSalesErrorInfo> errorInfoList) throws Exception ;

	boolean saveInvoiceStatus(Set<InvoiceProcessDto> invoiceList, Integer fileId) throws Exception;
	
	boolean timeoutAndSaveInvoiceStatus (Set<InvoiceProcessDto> invoiceList, Integer fileId) throws Exception;
	
	boolean timeoutAndMarkInvoiceStatusTechError (Integer fileId) throws Exception;

	void updateTransactionStatus(PayloadStatus payloadDetails);
	
	public List<OutwardInvoiceModel> getCreditListForB2CSA(String originalDocumentNo, Date originalDocumentDate);
	
	public List<GSTR1B2CSA_InvoiceDetail> getB2CARevisedCreditList(OutwardInvoiceModel credit);

	<T> List<T> validateOriginalDocumentNo(OutwardInvoiceDTO outwardInvoiceDTO,
			String entityName, String columnName);

	public boolean isValidAmendment(OutwardInvoiceDTO outwardInvoiceDTO,
			String entityName, String columnName);

	<T> T getEntityByColumn(String entityName, String colunName,
			Object columnValue);

	public List<OutwardInvoiceModel> validateOriginalInvoice(OutwardInvoiceDTO outwardInvoiceDTO,
			String entityName, String columnName, String orgInvNum);

	<T> List<T> validateOriginalDocNoDocDate(
			OutwardInvoiceDTO outwardInvoiceDTO, String entityName,
			String column1, String column2);

	TblGstinRetutnFilingStatus getGStrReturnFilingDetails(String gstinId,
			String taxPeriod, String gstrType);

	public String fileGSTR1(SummaryDto summarydto);


	public EntityModel getEntityDetails(String pan);

	void isValidAmendmentDate(OutwardInvoiceDTO outwardInvoiceDTO);

	boolean isValidTaxPeriod(String origTaxPeriod, String amendTaxPeriod);

	void validateInvoiceDate(OutwardInvoiceDTO outwardInvoiceDTO,
			String taxPeriod);

	public void updatePipeStageStatus(List<String> inputParams);

	//public String getReturnFilingDetails(JSONObject inputParams, List<String> returnType);
	
	public List<TblGstinRetutnFilingStatus> getReturnFilingDetails(JSONObject inputParams, List<String> returnType);

	public String getGstinDueDateMaster(List<String> inputParams);

	public String getEFilingSummary(List<String> inputParams);

	public List<Object[]> getCounterPartySupplyTypes(String sgstin, String taxPeriod);
	
	int getAffectedInvoiceCountForGstin(String gstin,String processType);
	
	/**
	 * This method is used to fetch error code details for a GSTIN for gstr1.
	 * @param gstn
	 * @return
	 */
	public List<Map<String, Object>> fetchGSTR1ErrorCodeDetails(String gstn) ;

	
	public void updateMailStatus(List<TblEmailStatusDetails> notifiedGstinList);
	

	public String getReturnFilingSuccess(String gstinId, String taxPeriod);
	

	void updateRefTxnID(String gstinId, String txprd, String ref_id, String submitted ) throws Exception;

	//void updateFailedStatus(String gstinId, String txprd, String submitted,String errorMsg );


	List<TblGstinRetutnFilingStatus> getReturnFilingDetailsForGSTR1A(String returnPeriod, String returnName, String retFilingStatus, boolean status);

	public	void setErrorList(Set<TblSalesErrorInfo> errorList,
			OutwardInvoiceModel outwardInvoiceModel, String errorInfoCode,
			String errorColumnNames, String processStatus, boolean isProcessed,
			String incidenceLevel);
	public void updateStageAndJobStatus(String stage,String jobStatus,int fileId);
	public List<String> fetchFileList(String stage,String jobStatus,int fileId);
	
	public List<String> getErrorReportDetails(JSONObject obj);
	void updateGstnTranId(String gsptransid, 
			String transid, String gstinNum, String refId, Long chunkId);
	
	public List<ReturnType> getFileUploadTypelist();
	public Object getRectifiedReportDetails(JSONObject obj);

	public CounterPartySalesDto getCounterPartySummary(String supplyGstin, String cgstin, String cname, 
			String taxperiod, String supplyType);
	
	public List<TblFileUploadStatus> fetchFileDetailsList(int fileId);

	public void updateBillNoBillDate(long expInvoiceId, OutwardInvoiceModel lineItem);

	public List<GSTR1B2BCLEAInvoiceDetail> getCreditListForInvoice(String originalDocumentNo, Date originalDocumentDate);

	public List<GSTR1B2CS_InvoiceDetail> getCreditListForB2CS(String originalDocumentNo, Date originalDocumentDate);

	public List<GSTR1B2BCLEAInvoiceDetail> getRevisedCreditList(GSTR1B2BCLEAInvoiceDetail credit);

	List<GSTR1B2CSA_InvoiceDetail> getB2CRevisedCreditList(GSTR1B2CS_InvoiceDetail credit);

	public Object getSpecifcHSNSACDetails(String hsnSac, String className, String columnName);

	public List<Object> getEntityHierarchyfromMaster(String key); 
	
	String getReturnFilingDetailsForDropDown(JSONObject inputParams, List<String> returnType);
	
	public List<OutwardInvoiceModel> getCreditRegisterData(String gstin,String taxperiod,int offset,int maxSize);
	
	public List<OutwardInvoiceModel> getCreditRegisterSummaryData(String gstin,String taxperiod);
	
	public List<InwardInvoiceModel> getDebitRegisterSummaryData(String gstin, String taxPeriod);
	
	public List<InwardInvoiceModel> getDebitRegisterData(String gstin, String taxperiod, int offset, int maxSize);

	public String getOriginalInvoice(OutwardInvoiceModel outwardInvoiceModel, String entityName, String OrgDocNoField,
			String OrgDocDateField);
	public Map<String,List<ParentSalePurchaseDto>> getOutwardSuppliesDetails(List<String> inputs);

	void updateGstnTranId(String gsptransid, 
			String transid, String gstinNum, String refId, Long chunkId,String gstnStatus,String errorDesc);
	
	public void updateAckNum(String gstinId, String taxPeriod,
			String acknowledge);

	List<Object> getOriginalInvoiceList(OutwardInvoiceModel lineItem,
			String entityName, String OrgDocNoField, String OrgDocDateField);
	
	public boolean getReturnFilingStatusForSaveGstrToGstn(String gstin,String taxPeriod,String returnType);

	public void updateReturnFilingStatus(String gstin, String taxPeriod, String returnType);
	
	public List<Object[]> getGstr1CptyGstinList(String supplyGstin, String taxPeriod,
			String cgstin, String cname, String supplyType);
	
	public String getCounterPartyReportDetails(JSONObject obj);
}
