package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblFileUploadStatus;
import com.ey.advisory.asp.client.dto.FileSearchDTO;

public interface TblFileUploadStatusDao {
	public List<TblFileUploadStatus> getFileUploadStatusDetails(String fileId);
	public List<TblFileUploadStatus> getUploadedFiles(FileSearchDTO searchDto);
	List<TblFileUploadStatus> getFilesByDate(FileSearchDTO fileDTO);
	List<TblFileUploadStatus> getFilesByMonth(FileSearchDTO fileDTO);
	public String getLastUploadedDate();
}
