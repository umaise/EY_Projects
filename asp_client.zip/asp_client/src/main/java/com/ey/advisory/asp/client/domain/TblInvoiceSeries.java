package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.ey.advisory.asp.client.util.CommonUtillity;

@Entity
@Table(name="tblInoiceSeries", schema="etl")
@NamedQuery(name = "TblInvoiceSeries.findAll", query = "SELECT t FROM TblInvoiceSeries t")
public class TblInvoiceSeries implements Serializable {
	
	private static final long serialVersionUID = 1;

	@Id
	@Column(name="InvoiceSeriesID")
	private Long invoiceSeriesID;
	
	@Column(name="SupplierGSTIN")
	private String supplierGSTIN;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="SerialNo")
	private Long serialNo;
	
	@Column(name="NatureOfDoc")
	private String natureOfDoc;
	
	@Column(name="FromSeries")
	private String fromSeries;
	
	@Column(name="ToSeries")
	private String toSeries;
	
	@Column(name="TotalNumber")
	private Long totalNumber;
	
	@Column(name="Cancelled")
	private Long cancelled;
	
	@Column(name="NetNumber")
	private Long netNumber;
	
	@Column(name="IsActive")
	private Boolean isActive;
	
	@Column(name="SummaryFileID")
	private Long summaryFileID;

	public Long getInvoiceSeriesID() {
		return invoiceSeriesID;
	}

	public void setInvoiceSeriesID(Long invoiceSeriesID) {
		this.invoiceSeriesID = invoiceSeriesID;
	}

	public String getSupplierGSTIN() {
		return supplierGSTIN;
	}

	public void setSupplierGSTIN(String supplierGSTIN) {
		this.supplierGSTIN = supplierGSTIN;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public Long getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(Long serialNo) {
		this.serialNo = serialNo;
	}

	public String getNatureOfDoc() {
		return natureOfDoc;
	}

	public void setNatureOfDoc(String natureOfDoc) {
		this.natureOfDoc = natureOfDoc;
	}

	public String getFromSeries() {
		return fromSeries;
	}

	public void setFromSeries(String fromSeries) {
		this.fromSeries = fromSeries;
	}

	public String getToSeries() {
		return toSeries;
	}

	public void setToSeries(String toSeries) {
		this.toSeries = toSeries;
	}

	public Long getTotalNumber() {
		return totalNumber;
	}

	public void setTotalNumber(Long totalNumber) {
		this.totalNumber = totalNumber;
	}

	public Long getCancelled() {
		return cancelled;
	}

	public void setCancelled(Long cancelled) {
		this.cancelled = cancelled;
	}

	public Long getNetNumber() {
		return netNumber;
	}

	public void setNetNumber(Long netNumber) {
		this.netNumber = netNumber;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Long getSummaryFileID() {
		return summaryFileID;
	}

	public void setSummaryFileID(Long summaryFileID) {
		this.summaryFileID = summaryFileID;
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((invoiceSeriesID == null) ? 0 : invoiceSeriesID.hashCode());
		return result;
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TblInvoiceSeries other = (TblInvoiceSeries) obj;
		if (invoiceSeriesID == null) {
			if (other.invoiceSeriesID != null)
				return false;
		} else if (!invoiceSeriesID.equals(other.invoiceSeriesID))
			return false;
		return true;
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public String toString() {
		return (supplierGSTIN != null ? supplierGSTIN : "") + ", "
				+ (taxPeriod != null ? taxPeriod : "") + ", "
				+ (serialNo != null ? serialNo : "") + ", "
				+ (natureOfDoc != null ? CommonUtillity.formatCommasWithSpaces(natureOfDoc) : "") + ", "
				+ (fromSeries != null ? fromSeries : "") + ", "
				+ (toSeries != null ? toSeries : "") + ", "
				+ (totalNumber != null ? totalNumber : "") + ", " 
				+ (cancelled != null ? cancelled : "") + ", "
				+ (netNumber != null ? netNumber : "");
	}
	
	
	/*@Override
	public String toString() {
		return supplierGSTIN + "," + taxPeriod + "," + serialNo + "," + natureOfDoc + ","
				+ fromSeries + "," + toSeries + "," + totalNumber + "," + cancelled + ","
				+ netNumber;
				
	}*/
	
	

	
}
