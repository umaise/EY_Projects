package com.ey.advisory.asp.client.service.gstr2;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR2SummaryRCMConsolidated;

@FunctionalInterface
public interface GSTR2SummaryRCMConsolidatedService {
	
	public List<GSTR2SummaryRCMConsolidated> getRCMConsolidatedMetadata();
}
