package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.SummaryJsonChunk;

public interface SummaryJsonChunkService {
	
	public void saveSummaryJsonChunkData(List<SummaryJsonChunk> summJsonChunk);
	public String updateSummaryJsonChunk(String status, int summaryFileId, String chunkSeries);

}
