/**
 * 
 */
package com.ey.advisory.asp.client.dao;

import java.util.Map;

import com.ey.advisory.asp.client.dto.ClientRegistrationDTO;
import com.ey.advisory.asp.client.dto.CommonSearchDto;
import com.ey.advisory.asp.client.dto.ResultPage;

/**
 * @author Shivani.Aggarwal
 *
 */
public interface EntityRegistrationDao {

	ResultPage<ClientRegistrationDTO> fetchRegistrationListPagination(CommonSearchDto searchDto);

	void updateBankAccNumber(ClientRegistrationDTO clientRegistrationDTO);

	void updateClientDetails(ClientRegistrationDTO clientRegistrationDTO);

	void addGSTINFinancialDetails(ClientRegistrationDTO clientRegistrationDTO);

	void addClientDetails(ClientRegistrationDTO clientRegistrationDTO);

	void addGSTINDetails(ClientRegistrationDTO clientRegistrationDTO);

	Map<Long, String> fetchGroupEntityLevelUsers(String entityCode);

}
