package com.ey.advisory.asp.client.dto;

import java.util.Date;

public class Gstr3Dto {

	private String gstin;
	private String fromDate;
	private String toDate;
	private String rtPeriod;
	private String jsonData;
	private String liabType;
	private Date currentDate;
	private boolean isPrevMonth;
	private Date dtFromDate;
	private Date dtToDate;
	private Object[] isFiled;
	private String prevJsonData;
	private String currJsonData;
	
	
	public Object[] getIsFiled() {
		return isFiled;
	}
	public void setIsFiled(Object[] isFiled) {
		this.isFiled = isFiled;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getRtPeriod() {
		return rtPeriod;
	}
	public void setRtPeriod(String rtPeriod) {
		this.rtPeriod = rtPeriod;
	}
	public String getJsonData() {
		return jsonData;
	}
	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}
	public String getLiabType() {
		return liabType;
	}
	public void setLiabType(String liabType) {
		this.liabType = liabType;
	}
	
	
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	public boolean isPrevMonth() {
		return isPrevMonth;
	}
	public void setPrevMonth(boolean isPrevMonth) {
		this.isPrevMonth = isPrevMonth;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public Date getDtFromDate() {
		return dtFromDate;
	}
	public void setDtFromDate(Date dtFromDate) {
		this.dtFromDate = dtFromDate;
	}
	public Date getDtToDate() {
		return dtToDate;
	}
	public void setDtToDate(Date dtToDate) {
		this.dtToDate = dtToDate;
	}
	public String getPrevJsonData() {
		return prevJsonData;
	}
	public void setPrevJsonData(String prevJsonData) {
		this.prevJsonData = prevJsonData;
	}
	public String getCurrJsonData() {
		return currJsonData;
	}
	public void setCurrJsonData(String currJsonData) {
		this.currJsonData = currJsonData;
	}
	
	
}
