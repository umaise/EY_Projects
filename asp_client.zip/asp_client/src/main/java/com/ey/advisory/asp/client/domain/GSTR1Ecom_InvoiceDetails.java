package com.ey.advisory.asp.client.domain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

/**
 * The persistent class for the tblEcominvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblECOMInvoiceDetails" , schema=Constant.GSTR1_SCHEMA)
public class GSTR1Ecom_InvoiceDetails implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ID")
	private long id;
	
	@Column(name="Flag")
	private Character flag;
	
	@Column(name="ChkSum")
	private String chkSum;
	
	@Column(name="ECOMInvType")
	private String ecominvType;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="MerchantID")
	private String merchantId;
	
	@Column(name="GrossSuppVal")
	private BigDecimal grossSuppVal;
	
	@Column(name="TaxableValue")
	private BigDecimal taxableValue;
	
	@Column(name="CustGSTIN")
	private String custGstin;
	
	@Column(name="DocumentNo")
	private String documentNo;
	
	@Column(name="EGSTIN")
	private String egstin;
	
	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="FileID")
	private long fileId;

	@Column(name="IsDelete")
	private boolean isDelete;
	
	public boolean isDelete() {
		return isDelete;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Character getFlag() {
		return this.flag;
	}

	public void setFlag(Character flag) {
		this.flag = flag;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getEcominvType() {
		return this.ecominvType;
	}

	public void setEcominvType(String ecominvType) {
		this.ecominvType = ecominvType;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getMerchantId() {
		return this.merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public BigDecimal getGrossSuppVal() {
		return this.grossSuppVal;
	}

	public void setGrossSuppVal(BigDecimal grossSuppVal) {
		this.grossSuppVal = grossSuppVal;
	}

	public BigDecimal getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(BigDecimal taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getCustGstin() {
		return this.custGstin;
	}

	public void setCustGstin(String custGstin) {
		this.custGstin = custGstin;
	}

	public String getDocumentNo() {
		return this.documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public String getEgstin() {
		return this.egstin;
	}

	public void setEgstin(String egstin) {
		this.egstin = egstin;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public long getFileId() {
		return this.fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

}
