package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR1SummaryInvoiceSeries;

@FunctionalInterface
public interface GSTR1SummaryInvoiceSeriesDao {
	
	public List<GSTR1SummaryInvoiceSeries> getInvoiceSeriesMetadata();

}
