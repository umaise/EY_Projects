package com.ey.advisory.asp.client.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.TblGSTR2AdvancePaid;
import com.ey.advisory.asp.common.Constant;


@Service
public class GSTR2AdvancePaidServiceImpl implements  GSTR2AdvancePaidService {

    @Autowired
    HibernateDao hibernateDao;

    private static final Logger logger = Logger.getLogger(GSTR2AdvancePaidServiceImpl.class);
    
    
    @Override
	public List<TblGSTR2AdvancePaid> fetchAll() {
		return hibernateDao.loadAllByNamedQuery("TblGSTR2AdvancePaid.findAll");
	}

	@Override
	public Long getTotalRecordCount(Long fileId) {
		  Long count = null;
		  try { 
			  
			  if(logger.isInfoEnabled())
				  logger.info(Constant.LOGGER_ENTERING + GSTR2AdvancePaidServiceImpl.class.getName()
						  + " Method : getTotalRecordCount()");
			  
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblGSTR2AdvancePaid.class);
			  criteriaCount.add(Restrictions.eq("summaryFileID", fileId));
			  criteriaCount.add(Restrictions.eq("isActive", Boolean.TRUE));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + GSTR2AdvancePaidServiceImpl.class.getName()
	                + " Method : getTotalRecordCount()" + exe);
	        }
	
		return count;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TblGSTR2AdvancePaid> fetchTotalRecords(Long fileId, int firstResult, int pageSize) {
		List<TblGSTR2AdvancePaid>  tblAdvPaidList = null;
		  try {
			  if(logger.isInfoEnabled())
				  logger.info(Constant.LOGGER_ENTERING + GSTR2AdvancePaidServiceImpl.class.getName()
						  + " Method : fetchTotalRecords()");
			  
			  Criteria criteria = hibernateDao.createNormalCriteria(TblGSTR2AdvancePaid.class);
			  criteria.add(Restrictions.eq("summaryFileID", fileId));
			  criteria.add(Restrictions.eq("isActive", Boolean.TRUE));
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("advPaidID"));
			  tblAdvPaidList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + GSTR2AdvancePaidServiceImpl.class.getName()
	                + " Method : fetchTotalRecords()" + exe);
	        }
	
		return tblAdvPaidList;
	}


}
