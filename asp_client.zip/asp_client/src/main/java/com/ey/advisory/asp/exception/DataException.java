package com.ey.advisory.asp.exception;

public class DataException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DataException(Throwable exceThrowable) {
        super(exceThrowable);
    }
	
	public DataException(String message,Throwable exceThrowable) {
        super(message,exceThrowable);
    }

}
