package com.ey.advisory.asp.client.dto;

import com.google.gson.annotations.SerializedName;

public class GSTR6FItemDto {


	@SerializedName("LineNo6A")
	private Double lineNo6A;
	
	@SerializedName("LineNoPR")
	private Double lineNoPR;


	@SerializedName("Rt6A")
	private Double rate6A;
	
	@SerializedName("RtPR")
	private Double ratePR;
	
	@SerializedName("TaxableValue6A")
	private Double taxableValue6A;

	@SerializedName("TaxableValuePR")
	private Double taxableValuePR;

	@SerializedName("IGSTAmt6A")
	private Double iGSTAmt6A;
	
	@SerializedName("IGSTAmtPR")
	private Double iGSTAmtPR;

	@SerializedName("CGSTAmt6A")
	private Double cGSTAmt6A;
	
	@SerializedName("CGSTAmtPR")
	private Double cGSTAmtPR;

	@SerializedName("SGSTAmt6A")
	private Double sGSTAmt6A;
	
	@SerializedName("SGSTAmtPR")
	private Double sGSTAmtPR;

	@SerializedName("CessAmt6A")
	private Double cessAmt6A;
	
	@SerializedName("CessAmtPR")
	private Double cessAmtPR;

	public Double getLineNoPR() {
		return lineNoPR;
	}

	public void setLineNoPR(Double lineNoPR) {
		this.lineNoPR = lineNoPR;
	}

	public Double getLineNo6A() {
		return lineNo6A;
	}

	public void setLineNo2A(Double lineNo6A) {
		this.lineNo6A = lineNo6A;
	}

	public Double getTaxableValue6A() {
		return taxableValue6A;
	}

	public void setTaxableValue6A(Double taxableValue6A) {
		this.taxableValue6A = taxableValue6A;
	}

	public Double getTaxableValuePR() {
		return taxableValuePR;
	}

	public void setTaxableValuePR(Double taxableValuePR) {
		this.taxableValuePR = taxableValuePR;
	}

	public Double getRatePR() {
		return ratePR;
	}

	public void setRatePR(Double ratePR) {
		this.ratePR = ratePR;
	}

	public Double getRate6A() {
		return rate6A;
	}

	public void setRate2A(Double rate6a) {
		rate6A = rate6a;
	}

	public Double getiGSTAmtPR() {
		return iGSTAmtPR;
	}

	public void setiGSTAmtPR(Double iGSTAmtPR) {
		this.iGSTAmtPR = iGSTAmtPR;
	}

	public Double getiGSTAmt6A() {
		return iGSTAmt6A;
	}

	public void setiGSTAmt6A(Double iGSTAmt6A) {
		this.iGSTAmt6A = iGSTAmt6A;
	}

	public Double getcGSTAmtPR() {
		return cGSTAmtPR;
	}

	public void setcGSTAmtPR(Double cGSTAmtPR) {
		this.cGSTAmtPR = cGSTAmtPR;
	}

	public Double getcGSTAmt6A() {
		return cGSTAmt6A;
	}

	public void setcGSTAmt2A(Double cGSTAmt6A) {
		this.cGSTAmt6A = cGSTAmt6A;
	}

	public Double getsGSTAmtPR() {
		return sGSTAmtPR;
	}

	public void setsGSTAmtPR(Double sGSTAmtPR) {
		this.sGSTAmtPR = sGSTAmtPR;
	}

	public Double getsGSTAmt6A() {
		return sGSTAmt6A;
	}

	public void setsGSTAmt6A(Double sGSTAmt6A) {
		this.sGSTAmt6A = sGSTAmt6A;
	}

	public Double getCessAmtPR() {
		return cessAmtPR;
	}

	public void setCessAmtPR(Double cessAmtPR) {
		this.cessAmtPR = cessAmtPR;
	}

	public Double getCessAmt6A() {
		return cessAmt6A;
	}

	public void setCessAmt6A(Double cessAmt6A) {
		this.cessAmt6A = cessAmt6A;
	}



}
