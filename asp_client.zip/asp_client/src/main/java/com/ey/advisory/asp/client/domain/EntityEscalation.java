package com.ey.advisory.asp.client.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "tblEntityEscalationMatrix", schema="master")
public class EntityEscalation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="MatrixID")
	private Integer matrixId;
	
	@Column(name="UserAccessType")
	private String accessType;
	
	@Column(name="UserLevel")
	private String userLevel;
	
	@Column(name="EntityID")
	private Integer entityId;
	
	@Column(name="ContactPersonID")
	private Integer contactPersonId;
	
	@Transient
	private String contactPersonUserName;
	
	public Integer getMatrixId() {
		return matrixId;
	}
	public void setMatrixId(Integer matrixId) {
		this.matrixId = matrixId;
	}
	public String getAccessType() {
		return accessType;
	}
	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
	public String getContactPersonUserName() {
		return contactPersonUserName;
	}
	public void setContactPersonUserName(String contactPersonUserName) {
		this.contactPersonUserName = contactPersonUserName;
	}
	public String getUserLevel() {
		return userLevel;
	}
	public void setUserLevel(String userLevel) {
		this.userLevel = userLevel;
	}
	public Integer getEntityId() {
		return entityId;
	}
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
	public Integer getContactPersonId() {
		return contactPersonId;
	}
	public void setContactPersonId(Integer contactPersonId) {
		this.contactPersonId = contactPersonId;
	}
	
	
}
