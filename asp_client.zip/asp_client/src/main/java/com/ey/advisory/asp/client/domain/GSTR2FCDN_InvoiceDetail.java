package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;


/**
 * The persistent class for the tblCDNInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblCDNInvoiceDetails", schema=Constant.GSTR2F_SCHEMA)
public class GSTR2FCDN_InvoiceDetail implements Serializable{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR2FCDN_InvoiceDetail.class);

	@Id
	@Column(name="ID")
	private Long id;

	@Column(name="CessAmt")
	private Double cessAmt;

	@Column(name="CessRt")
	private Double cessRt;

	@Column(name="CGSTAmt")
	private Double CGSTAmt;

	@Column(name="CGSTRt")
	private Double CGSTRt;

	@Column(name="Chksum")
	private String chksum;

	@Column(name="CustGSTIN")
	private String custGSTIN;

	@Column(name="CustName")
	private String custName;

	@Column(name="DiffValue")
	private Double diffValue;

	@Column(name="FilingStatus")
	private String filingStatus;

	@Column(name="Flag")
	private String flag;

	@Column(name="IGSTAmt")
	private Double IGSTAmt;

	@Column(name="IGSTRt")
	private Double IGSTRt;

	@Column(name="InvDate")
	private Date doc_Date;

	@Column(name="InvNum")
	private String doc_Num;

	@Column(name="InvOrder")
	private Long invOrder;

	@Column(name="IsAccepted")
	private Integer isAccepted;

	@Column(name="ItcCessAmt")
	private Double itcCessAmt;

	@Column(name="ItcCgstAmt")
	private Double itcCgstAmt;

	@Column(name="ItcEligiblity")
	private String itcEligiblity;

	@Column(name="ItcIgstAmt")
	private Double itcIgstAmt;

	@Column(name="ItcSgstAmt")
	private Double itcSgstAmt;

	@Column(name="NoteDate")
	private Date noteDate;

	@Column(name="NoteNum")
	private String noteNum;

	@Column(name="NoteTyp")
	private String noteTyp;

	@Column(name="Reason")
	private String reason;

	@Column(name="SGSTAmt")
	private Double SGSTAmt;

	@Column(name="SGSTRt")
	private Double SGSTRt;

	@Column(name="Status")
	private String status;

	@Column(name="TaxableValue")
	private Double taxableValue;

	@Column(name="TcCessAmt")
	private Double tcCessAmt;

	@Column(name="TcCgstAmt")
	private Double tcCgstAmt;

	@Column(name="TcIgstAmt")
	private Double tcIgstAmt;

	@Column(name="TcSgstAmt")
	private Double tcSgstAmt;
	
	@Column(name="TaxPeriod")
    private String taxPeriod;
	
	@Column(name="Gstin")
    private String gstin;
    
	@Transient
	private Set<TblPurchaseErrorInfo> errorInfo = new HashSet<>();
	
	public GSTR2FCDN_InvoiceDetail() {

	if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR2FCDN_InvoiceDetail ");
			}
	}


	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}


	public Double getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}

	public Double getCessRt() {
		return cessRt;
	}

	public void setCessRt(Double cessRt) {
		this.cessRt = cessRt;
	}

	public Double getCGSTAmt() {
		return CGSTAmt;
	}

	public void setCGSTAmt(Double cGSTAmt) {
		CGSTAmt = cGSTAmt;
	}

	public Double getCGSTRt() {
		return CGSTRt;
	}

	public void setCGSTRt(Double cGSTRt) {
		CGSTRt = cGSTRt;
	}

	public String getChksum() {
		return chksum;
	}

	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	public String getCustGSTIN() {
		return custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public Double getDiffValue() {
		return diffValue;
	}

	public void setDiffValue(Double diffValue) {
		this.diffValue = diffValue;
	}

	public String getFilingStatus() {
		return filingStatus;
	}

	public void setFilingStatus(String filingStatus) {
		this.filingStatus = filingStatus;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public Double getIGSTAmt() {
		return IGSTAmt;
	}

	public void setIGSTAmt(Double iGSTAmt) {
		IGSTAmt = iGSTAmt;
	}

	public Double getIGSTRt() {
		return IGSTRt;
	}

	public void setIGSTRt(Double iGSTRt) {
		IGSTRt = iGSTRt;
	}

	public Date getDoc_Date() {
        return doc_Date;
    }

    public void setDoc_Date(Date doc_Date) {
        this.doc_Date = doc_Date;
    }

    public String getDoc_Num() {
        return doc_Num;
    }

    public void setDoc_Num(String doc_Num) {
        this.doc_Num = doc_Num;
    }

    public Long getInvOrder() {
		return invOrder;
	}

	public void setInvOrder(Long invOrder) {
		this.invOrder = invOrder;
	}

	public Integer isAccepted() {
		return isAccepted;
	}

	public void setAccepted(Integer isAccepted) {
		this.isAccepted = isAccepted;
	}

	public Double getItcCessAmt() {
		return itcCessAmt;
	}

	public void setItcCessAmt(Double itcCessAmt) {
		this.itcCessAmt = itcCessAmt;
	}

	public Double getItcCgstAmt() {
		return itcCgstAmt;
	}

	public void setItcCgstAmt(Double itcCgstAmt) {
		this.itcCgstAmt = itcCgstAmt;
	}

	public String getItcEligiblity() {
		return itcEligiblity;
	}

	public void setItcEligiblity(String itcEligiblity) {
		this.itcEligiblity = itcEligiblity;
	}

	public Double getItcIgstAmt() {
		return itcIgstAmt;
	}

	public void setItcIgstAmt(Double itcIgstAmt) {
		this.itcIgstAmt = itcIgstAmt;
	}

	public Double getItcSgstAmt() {
		return itcSgstAmt;
	}

	public void setItcSgstAmt(Double itcSgstAmt) {
		this.itcSgstAmt = itcSgstAmt;
	}

	public Date getNoteDate() {
		return noteDate;
	}

	public void setNoteDate(Date noteDate) {
		this.noteDate = noteDate;
	}

	public String getNoteNum() {
		return noteNum;
	}

	public void setNoteNum(String noteNum) {
		this.noteNum = noteNum;
	}

	public String getNoteTyp() {
		return noteTyp;
	}

	public void setNoteTyp(String noteTyp) {
		this.noteTyp = noteTyp;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Double getSGSTAmt() {
		return SGSTAmt;
	}

	public void setSGSTAmt(Double sGSTAmt) {
		SGSTAmt = sGSTAmt;
	}

	public Double getSGSTRt() {
		return SGSTRt;
	}

	public void setSGSTRt(Double sGSTRt) {
		SGSTRt = sGSTRt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public Double getTcCessAmt() {
		return tcCessAmt;
	}

	public void setTcCessAmt(Double tcCessAmt) {
		this.tcCessAmt = tcCessAmt;
	}

	public Double getTcCgstAmt() {
		return tcCgstAmt;
	}

	public void setTcCgstAmt(Double tcCgstAmt) {
		this.tcCgstAmt = tcCgstAmt;
	}

	public Double getTcIgstAmt() {
		return tcIgstAmt;
	}

	public void setTcIgstAmt(Double tcIgstAmt) {
		this.tcIgstAmt = tcIgstAmt;
	}

	public Double getTcSgstAmt() {
		return tcSgstAmt;
	}

	public void setTcSgstAmt(Double tcSgstAmt) {
		this.tcSgstAmt = tcSgstAmt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

    public String getTaxPeriod() {
        return taxPeriod;
    }

    public void setTaxPeriod(String taxPeriod) {
        this.taxPeriod = taxPeriod;
    }

    public Set<TblPurchaseErrorInfo> getErrorInfo() {
        return errorInfo;
    }

    public void setErrorInfo(Set<TblPurchaseErrorInfo> errorInfo) {
        this.errorInfo = errorInfo;
    }
    
     	
}