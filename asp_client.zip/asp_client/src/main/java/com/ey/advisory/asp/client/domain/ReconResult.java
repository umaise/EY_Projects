package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="tblReconResult", schema="gstr2f")
public class ReconResult implements Serializable {
	
    private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ID")
	private int id;
	
	@Column(name="ReconStatusID")
	private int reconStatusID ;
	
	@Column(name="tableType")
	private String tableType;
	
	@Column(name="GSTIN")
	private String gstin;

	@Column(name="InvKey")
	private String invKey;
	
	@Column(name="gstr2Key")
	private int gstr2Key;
	
	@Column(name="gstr2AKey")
	private int gstr2AKey;
	
	@Column(name="TotalTax2")
	private BigDecimal totalTax2;
	
	@Column(name="TotalTax2A")
	private BigDecimal totalTax2A;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="ReconResponse")
	private String reconResponse;
	
	@Column(name="SystemResponse")
	private String systemResponse;
	
	@Column(name="SuggestedResponse")
	private String eySuggestedResponse;
	
	@Column(name="ClientResponse")
	private String clientResponse;
	
	@Column(name="IsActive")
	private Boolean isActive;
	
	@Column(name="CreatedDate")
	private Timestamp createdDate;
	
	@Column(name="UpdatedDate")
	private Timestamp updatedDate;
	
	 @OneToMany(mappedBy = "reconResult",fetch = FetchType.LAZY)
	private List<InwardInvoiceModel> inwardInvoiceModels;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getReconStatusID() {
		return reconStatusID;
	}

	public void setReconStatusID(int reconStatusID) {
		this.reconStatusID = reconStatusID;
	}

	public String getTableType() {
		return tableType;
	}

	public void setTableType(String tableType) {
		this.tableType = tableType;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getInvKey() {
		return invKey;
	}

	public void setInvKey(String invKey) {
		this.invKey = invKey;
	}

	public int getGstr2Key() {
		return gstr2Key;
	}

	public void setGstr2Key(int gstr2Key) {
		this.gstr2Key = gstr2Key;
	}

	public int getGstr2AKey() {
		return gstr2AKey;
	}

	public void setGstr2AKey(int gstr2aKey) {
		gstr2AKey = gstr2aKey;
	}

	public BigDecimal getTotalTax2() {
		return totalTax2;
	}

	public void setTotalTax2(BigDecimal totalTax2) {
		this.totalTax2 = totalTax2;
	}

	public BigDecimal getTotalTax2A() {
		return totalTax2A;
	}

	public void setTotalTax2A(BigDecimal totalTax2A) {
		this.totalTax2A = totalTax2A;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getReconResponse() {
		return reconResponse;
	}

	public void setReconResponse(String reconResponse) {
		this.reconResponse = reconResponse;
	}

	public String getSystemResponse() {
		return systemResponse;
	}

	public void setSystemResponse(String systemResponse) {
		this.systemResponse = systemResponse;
	}

	public String getEySuggestedResponse() {
		return eySuggestedResponse;
	}

	public void setEySuggestedResponse(String eySuggestedResponse) {
		this.eySuggestedResponse = eySuggestedResponse;
	}

	public String getClientResponse() {
		return clientResponse;
	}

	public void setClientResponse(String clientResponse) {
		this.clientResponse = clientResponse;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public List<InwardInvoiceModel> getInwardInvoiceModels() {
		return inwardInvoiceModels;
	}

	public void setInwardInvoiceModels(List<InwardInvoiceModel> inwardInvoiceModels) {
		this.inwardInvoiceModels = inwardInvoiceModels;
	}
	
}
