package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;

import java.math.BigDecimal;


/**
 * The persistent class for the GSTR1B2B_ItemDetails database table.
 * 
 */
@Entity
@Table(name="tblB2BItemDetails",schema=Constant.GSTR1_SCHEMA)
public class GSTR1B2B_ItemDetail implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR1B2B_ItemDetail.class);
	
	@Id
	@Column(name="B2BItemDetailsID")
	private Long id;
	
	@Column(name="CGSTAmt")
	private BigDecimal CGST_Amt;

	@Column(name="CGSTRt")
	private BigDecimal CGST_Rt;

	@Column(name="HSNSC")
	private String hsnSc;

	@Column(name="IGSTAmt")
	private BigDecimal IGST_Amt;

	@Column(name="IGSTRt")
	private BigDecimal IGST_Rt;

	@Column(name="ItemNo")
	private int item_Num;

	@Column(name="ItemStatus")
	private String item_Status;

	@Column(name="ItemTaxval")
	private BigDecimal item_Txval;

	@Column(name="ItemType")
	private String item_Type;

	@Column(name="SGSTAmt")
	private BigDecimal SGST_Amt;

	@Column(name="SGSTRt")
	private BigDecimal SGST_Rt;

	@Column(name="TaxableValue")
	private BigDecimal taxable_value;
	
	
	@Column(name="CessRt")
	private BigDecimal CessRt;
	
	@Column(name="CessAmt")
	private BigDecimal CessAmt;
	
	//bi-directional many-to-one association to GSTR1B2B_InvoiceDetail
	@ManyToOne
	@JoinColumn(name="InvoiceDetailsID")
	private GSTR1B2B_InvoiceDetail gstr1b2bInvoiceDetail;

	public GSTR1B2B_ItemDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR1B2B_ItemDetail ");
			}
	}

	public BigDecimal getCGST_Amt() {
		return this.CGST_Amt;
	}

	public void setCGST_Amt(BigDecimal CGST_Amt) {
		this.CGST_Amt = CGST_Amt;
	}

	public BigDecimal getCGST_Rt() {
		return this.CGST_Rt;
	}

	public void setCGST_Rt(BigDecimal CGST_Rt) {
		this.CGST_Rt = CGST_Rt;
	}

	public String getHsnSc() {
		return this.hsnSc;
	}

	public void setHsnSc(String hsnSc) {
		this.hsnSc = hsnSc;
	}

	public BigDecimal getIGST_Amt() {
		return this.IGST_Amt;
	}

	public void setIGST_Amt(BigDecimal IGST_Amt) {
		this.IGST_Amt = IGST_Amt;
	}

	public BigDecimal getIGST_Rt() {
		return this.IGST_Rt;
	}

	public void setIGST_Rt(BigDecimal IGST_Rt) {
		this.IGST_Rt = IGST_Rt;
	}

	public int getItem_Num() {
		return this.item_Num;
	}

	public void setItem_Num(int item_Num) {
		this.item_Num = item_Num;
	}

	public String getItem_Status() {
		return this.item_Status;
	}

	public void setItem_Status(String item_Status) {
		this.item_Status = item_Status;
	}

	public BigDecimal getItem_Txval() {
		return this.item_Txval;
	}

	public void setItem_Txval(BigDecimal item_Txval) {
		this.item_Txval = item_Txval;
	}

	public String getItem_Type() {
		return this.item_Type;
	}

	public void setItem_Type(String item_Type) {
		this.item_Type = item_Type;
	}

	public BigDecimal getSGST_Amt() {
		return this.SGST_Amt;
	}

	public void setSGST_Amt(BigDecimal SGST_Amt) {
		this.SGST_Amt = SGST_Amt;
	}

	public BigDecimal getSGST_Rt() {
		return this.SGST_Rt;
	}

	public void setSGST_Rt(BigDecimal SGST_Rt) {
		this.SGST_Rt = SGST_Rt;
	}

	public BigDecimal getTaxable_value() {
		return this.taxable_value;
	}

	public void setTaxable_value(BigDecimal taxable_value) {
		this.taxable_value = taxable_value;
	}
	
	public BigDecimal getCessRt() {
		return CessRt;
	}

	public void setCessRt(BigDecimal cessRt) {
		CessRt = cessRt;
	}

	public BigDecimal getCessAmt() {
		return CessAmt;
	}

	public void setCessAmt(BigDecimal cessAmt) {
		CessAmt = cessAmt;
	}


	public GSTR1B2B_InvoiceDetail getGstr1b2bInvoiceDetail() {
		return this.gstr1b2bInvoiceDetail;
	}

	public void setGstr1b2bInvoiceDetail(GSTR1B2B_InvoiceDetail gstr1b2bInvoiceDetail) {
		this.gstr1b2bInvoiceDetail = gstr1b2bInvoiceDetail;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	
}