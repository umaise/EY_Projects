package com.ey.advisory.asp.client.service;

import java.util.Map;

@FunctionalInterface
public interface SystemCodesService {    
    
    Map<String, String> getSystemCodeInfo(String codeKey);

}
