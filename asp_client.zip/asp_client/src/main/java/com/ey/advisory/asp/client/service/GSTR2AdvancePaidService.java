package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblGSTR2AdvancePaid;

public interface GSTR2AdvancePaidService {
	
	List<TblGSTR2AdvancePaid> fetchAll();
	Long getTotalRecordCount(Long fileId);
	List<TblGSTR2AdvancePaid> fetchTotalRecords(Long fileId, int firstResult, int pageSize);

}
