package com.ey.advisory.asp.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GSTR3RateDto {
	
	
	String Group;
	
	double iamt;
	double camt;
	double samt;
	double cess;
	
	@JsonProperty("iamt")
	public double getIamt() {
		return iamt;
	}
	public void setImat(double iamt) {
		this.iamt = iamt;
	}
	
	@JsonProperty("camt")
	public double getCamt() {
		return camt;
	}
	public void setCamt(double camt) {
		this.camt = camt;
	}
	
	@JsonProperty("samt")
	public double getSamt() {
		return samt;
	}
	
	public void setSamt(double samt) {
		this.samt = samt;
	}
	
	@JsonProperty("cess")
	public double getCess() {
		return cess;
	}
	public void setCess(double cess) {
		this.cess = cess;
	}
	
	@JsonIgnore
	public String getGroup() {
		return Group;
	}
	public void setGroup(String group) {
		Group = group;
	}

}
