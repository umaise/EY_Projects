package com.ey.advisory.asp.client.service.gstr2;


import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;

import com.ey.advisory.asp.client.domain.GlCodeMaster;
import com.ey.advisory.asp.client.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.ReconciliationDTO;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.client.dto.CounterPartyPurchaseDto;
import com.ey.advisory.asp.client.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.dto.LineItemDTO;


/**
 * @author Smruti.Pradhan Service contains all the methods related to GSTR2 form
 */
public interface Gstr2Service {
	public String sendGSTR2Data(String jsonGstr1Data,String gstinNum);

	Object getGSTR2SummaryfromDB(String gstn, String taxPeriod);

	String gstr2Summary(String gstn, String month, String year);
	
	String getRCMTransaction(String gstn, String taxPeriod);
	
	String getRCMDetailedXML(String gstn, String taxPeriod);

	boolean savePurchaseErrorInfo(Set<TblPurchaseErrorInfo> errorInfoList)throws Exception;

	boolean saveGstr2InvoiceStatus(Set<InvoiceProcessDto> invoiceList, Integer fileId)throws Exception;

	public String fileGSTR2(SummaryDto summarydto);

	public void saveAfterReconStatus(String tableName, String fieldName, String status);

	public void getPurchaseByPAN(ReconciliationDTO dto);

	public String saveTblTypeErrLstAndRoute(String key) throws Exception;
	
	public List<Object[]> getGstrPurchasingStageDetails(String purchaseGstin, String taxPeriod);

	public void validateGSTR2Rules(InwardInvoiceDTO inwardInvoiceDTO, Class<?> clsEntity, String docNum, String docDate);

	//<T> List<T> validateOriginalDocumentNo(InwardInvoiceDTO inwardInvoiceDTO, String entityName, String columnName);
	
	boolean isValidTaxPeriod(String origTaxPeriod, String amendTaxPeriod);

	public InwardInvoiceDTO isValidITCDate(InwardInvoiceDTO inwardInvoiceDTO);
	/**
	 * This method is used to fetch error code details for a GSTIN for gstr2.
	 * @param gstn
	 * @return
	 */
	public List<Map<String,Object>> fetchGSTR2ErrorCodeDetails(String gstn);
	
	public String updateReconFilingStatus(String redisKey);
	
	public void updateITCValues(Set<LineItemDTO> redisLineItemSet);



	public ItemMaster getSpecifcHSNSACDetails(String hsnSac);
	
	public GlobalGSTRatesMasterI  getSpecifcHSNSACDetailsfromglobal(String hsnSac);

	List<Object> getHSNSACDetailsfromMaster(String key);

	public String getReturnFilingSuccess(String gstinId, String taxPeriod);

	public TblGstinRetutnFilingStatus getGStrReturnFilingDetails(String gstnID,
			String taxPeriod, String returnType);
	
	public List<String> getErrorReportDetails(JSONObject obj);

	void setErrorList(InwardInvoiceDTO inwardInvoiceDTO, InwardInvoiceModel lineItem, String errorInfoCode,
			String errorColumnName, String processStatus, boolean isProcessed);

	public List<Object[]> getGstr2CptyGstinList(String cgstin, String taxPeriod,
			String sgstin, String sname, String supplyType);
	
	public CounterPartyPurchaseDto getCounterPartySummary(String cgstin, String sgstin, String sname, 
			String taxperiod, String supplyType);

	public List<String> getCCMReport(String rtPeriod,String gstinId);
	
	public boolean isValidCumulativeTaxableValue(InwardInvoiceModel lineItem, Double cumulativeCRValue, Double sumOfTaxableValue);

	public boolean isSingleInvoiceForCRDR(InwardInvoiceModel lineItem);

	boolean timeoutAndSavePurchaseErrorInfo(Set<TblPurchaseErrorInfo> errorInfo) throws Exception;

	boolean timeoutAndSaveGstr2InvoiceStatus(Set<InvoiceProcessDto> invoice, Integer fileId) throws Exception;

	/*String timeoutSaveTblTypeErrLstAndRoute(String key) throws Exception;*/

	boolean timeoutAndMarkInvoiceStatusTechError(Integer fileId) throws Exception;

	void updateRefTxnID(String gstinId, String txprd, String ref_id, String submitted ) throws Exception;
	
	public String gstr2ITCComputation(String taxPeriod, String gstinId);

	public String gstr2ITCReversal(String taxPeriod, String gstinId);
	
	public List<Object> getGLCodeMasterList(String glCodeMasterDetailsKey);

	public GlCodeMaster getGLMasterByCode(String glCode);

	boolean saveInvoiceStatus(Set<InvoiceProcessDto> invoice, Integer fileId) throws Exception;
	
	public String gstr2Reconciliation(String gstin, String taxPeriod,String groupCode,String masterId);
	
	public String executeRecon(String gstin, String taxPeriod,String masterId);

	public void updateAckNum(String gstinId, String taxPeriod,
			String acknowledge);
	
	public List<Object[]> getCounterPartySupplyTypes(String cgstin, String taxPeriod);
}

