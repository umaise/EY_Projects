package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR2SummaryRCMConsolidatedDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR2SummaryRCMConsolidated;

@Repository
public class GSTR2SummaryRCMConsolidatedDaoImpl implements GSTR2SummaryRCMConsolidatedDao{
	
	@Autowired
	private HibernateDao  hibernateDao;
	
	private static final Logger logger = Logger.getLogger(GSTR2SummaryRCMConsolidatedDaoImpl.class);

	@Override
	public List<GSTR2SummaryRCMConsolidated> getRCMConsolidatedMetadata() {
		List<GSTR2SummaryRCMConsolidated> rcmConsolidatedList = new ArrayList<>();
		try {
			rcmConsolidatedList = (List<GSTR2SummaryRCMConsolidated>)hibernateDao.loadAll(GSTR2SummaryRCMConsolidated.class);
		} catch (Exception e) {
			
			logger.error("Exception in getRCMConsolidatedMetadata"+ e);
		}
		return rcmConsolidatedList;
	}

}