package com.ey.advisory.asp.client.service.gstr1;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR1SummaryAdvanceAdjusted;

@FunctionalInterface
public interface GSTR1SummaryAdvanceAdjustedService {
	
	public List<GSTR1SummaryAdvanceAdjusted> getAdvanceAdjustedMetadata(); 
}
