package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblOnboardingDraftData", schema="trans")
public class ClientDraftData implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="OnboardingID")
	private Integer onBoardingID;

	@Column(name="UserID")
	private Long userID;
	
	@Column(name="GroupID")
	private Long groupID;
	
	@Column(name="EntityName")
	private String entityName;
	
	@Column(name="JSONStructure")
	private String onBoardJson;
	
	@Column(name="last_modified_date")
	private Date lastModifiedDate;
	
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	
	public ClientDraftData() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ClientDraftData(Long userID, Long groupID, String entityName,
			String onBoardJson,Date lastModifiedDate) {
		super();
		this.userID = userID;
		this.groupID = groupID;
		this.entityName = entityName;
		this.onBoardJson = onBoardJson;
		this.lastModifiedDate = lastModifiedDate;
	}
	public Integer getOnBoardingID() {
		return onBoardingID;
	}
	public void setOnBoardingID(Integer onBoardingID) {
		this.onBoardingID = onBoardingID;
	}
	public Long getUserID() {
		return userID;
	}
	public void setUserID(Long userID) {
		this.userID = userID;
	}
	public Long getGroupID() {
		return groupID;
	}
	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public String getOnBoardJson() {
		return onBoardJson;
	}
	public void setOnBoardJson(String onBoardJson) {
		this.onBoardJson = onBoardJson;
	}

	@Override
	public String toString() {
		return "ClientDraftData [groupID=" + groupID + ", entityName="
				+ entityName + ", onBoardJson=" + onBoardJson + ", lastModifiedDate=" + lastModifiedDate +"]";
	}
	
	
}
