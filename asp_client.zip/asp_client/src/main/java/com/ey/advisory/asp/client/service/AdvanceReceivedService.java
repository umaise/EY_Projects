package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblAdvanceReceived;

public interface AdvanceReceivedService {
	
	List<TblAdvanceReceived> fetchAll();
	Long getTotalRecordCount(Long fileId);
	List<TblAdvanceReceived> fetchTotalRecords(Long fileId, int firstResult, int pageSize);

}
