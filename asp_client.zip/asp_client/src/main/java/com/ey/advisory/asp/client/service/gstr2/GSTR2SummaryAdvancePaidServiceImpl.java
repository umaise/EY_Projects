package com.ey.advisory.asp.client.service.gstr2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GSTR2SummaryAdvancePaidDao;
import com.ey.advisory.asp.client.domain.GSTR2SummaryAdvancePaid;

@Service
public class GSTR2SummaryAdvancePaidServiceImpl implements GSTR2SummaryAdvancePaidService{

	@Autowired
	private GSTR2SummaryAdvancePaidDao advancePaidDao;

	@Override
	public List<GSTR2SummaryAdvancePaid> getAdvancePaidMetadata() {
		return advancePaidDao.getAdvancePaidMetadata();
	}

}
