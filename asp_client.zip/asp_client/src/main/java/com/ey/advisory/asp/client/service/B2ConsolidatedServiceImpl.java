package com.ey.advisory.asp.client.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.TblB2CSummary;
import com.ey.advisory.asp.common.Constant;


@Service
public class B2ConsolidatedServiceImpl implements B2ConsolidatedService {

    @Autowired
    HibernateDao hibernateDao;

    private static final Logger logger = Logger.getLogger(B2ConsolidatedServiceImpl.class);
    
    
    @Override
	public List<TblB2CSummary> fetchAll() {
		return hibernateDao.loadAllByNamedQuery("TblB2CSummary.findAll");
	}

	@Override
	public Long getTotalRecordCount(Long fileId) {
		  Long count = null;
		  try { 
			  
			  if(logger.isInfoEnabled())
				  logger.info(Constant.LOGGER_ENTERING + B2ConsolidatedServiceImpl.class.getName()
						  + " Method : getTotalRecordCount()");
			  
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblB2CSummary.class);
			  criteriaCount.add(Restrictions.eq("summaryFileID", fileId));
			  criteriaCount.add(Restrictions.eq("isActive", Boolean.TRUE));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + B2ConsolidatedServiceImpl.class.getName()
	                + " Method : getTotalRecordCount()" + exe);
	        }
	
		return count;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TblB2CSummary> fetchTotalRecords(Long fileId, int firstResult, int pageSize) {
		List<TblB2CSummary>  tblB2CList = null;
		  try {
			  if(logger.isInfoEnabled())
				  logger.info(Constant.LOGGER_ENTERING + B2ConsolidatedServiceImpl.class.getName()
						  + " Method : fetchTotalRecords()");
			  
			  Criteria criteria = hibernateDao.createNormalCriteria(TblB2CSummary.class);
			  criteria.add(Restrictions.eq("summaryFileID", fileId));
			  criteria.add(Restrictions.eq("isActive", Boolean.TRUE));
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("b2CSummaryID"));
			  tblB2CList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + B2ConsolidatedServiceImpl.class.getName()
	                + " Method : fetchTotalRecords()" + exe);
	        }
	
		return tblB2CList;
	}


}
