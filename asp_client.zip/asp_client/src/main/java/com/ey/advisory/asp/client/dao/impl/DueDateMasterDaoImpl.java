package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.DueDateMasterDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.DueDateMaster;

@Repository
public class DueDateMasterDaoImpl implements DueDateMasterDao{

	@Autowired
	private HibernateDao  hibernateDao;

	private static final Logger logger = Logger.getLogger(DueDateMasterDaoImpl.class);
	
	@Override
	public List<DueDateMaster> getGstinDueDateMaster(List<String> returnType, String gstin) {
		
		List<DueDateMaster> resultList = new ArrayList<>();
		try {
			 DetachedCriteria criteria = hibernateDao.createCriteria(DueDateMaster.class);
			 criteria.add(Restrictions.eq("gstnId",gstin));
			 criteria.add(Restrictions.in("applicableReturn", returnType));
			 resultList = (List<DueDateMaster>)hibernateDao.find(criteria);
		} catch (Exception e) {
			
			
			logger.error("Error in DueDateMasterDaoImpl "+e);
			
		}
		return resultList;
	}
	
	@Override
	public String getGstinReturnType(String gstin) {
		
		if(logger.isInfoEnabled()){
			logger.info("Entering getGstinReturnType ");
		}
		
		try {
			 DetachedCriteria criteria = hibernateDao.createCriteria(DueDateMaster.class);
			 criteria.add(Restrictions.eq("gstnId",gstin));
			 criteria.setProjection(Projections.property("applicableReturn"));
			 List returnObj= hibernateDao.find(criteria);
			 if(returnObj!=null && !returnObj.isEmpty() && returnObj.size()>0){
				 if(logger.isInfoEnabled()){
						logger.info("Return type of given gstin is"+returnObj.get(0).toString());
					}
				 return returnObj.get(0).toString();
			 }else
				 return null;
		} catch (Exception e) {
			logger.error("Error in getGstinReturnType in DueDateMasterDaoImpl "+e);
			return null;
		}
		
	}
}
