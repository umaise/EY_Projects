package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblGSTINList;

public interface TblGstinListService {
	public List<TblGSTINList> getGstinRtType(String returnType);
	
	public List<TblGSTINList> getGstinRtType(String returnType, String gstin ,String taxPeriod);

	String insertUpdateGstr12FilingStatus(List<TblGSTINList> gstinList);
	
	void updateGstinList(int fileId);

	void updateGstinList(TblGSTINList gstinData);
	void updateGstnTranId(String gsptransid, String transid, String gstinNum, String refId, long chunkId);
	
	public List<Object[]> getGSTINListEligibleForGstr2A();

}
