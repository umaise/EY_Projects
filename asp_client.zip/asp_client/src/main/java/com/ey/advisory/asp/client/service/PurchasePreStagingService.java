package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblPurchasePreStaging;

public interface PurchasePreStagingService {
	
	List<TblPurchasePreStaging> fetchAll();
 	
 	Long getTotalCount(Long fileId);
 	
 	List<TblPurchasePreStaging> fetchPages(Long fileId, int firstResult, int pageSize);
 	
 	Long getDupCount(Long fileId);

	List<TblPurchasePreStaging> fetchDupRecords(Long fileId, int firstResult, int pageSize);

	Long getTotalErrorCount(Long fileId);

	List<TblPurchasePreStaging> fetchErrorRecords(Long fileId, int firstResult, int pageSize);

}
