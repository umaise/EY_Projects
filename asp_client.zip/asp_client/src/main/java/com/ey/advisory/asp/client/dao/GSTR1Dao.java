package com.ey.advisory.asp.client.dao;

import java.util.Date;
import java.util.List;

public interface GSTR1Dao {
	
	<T> List<T> validateOriginalDocumentNo(String originalDocumentNo, String entityName, String columnName);
	
	<T> List<T> validateOriginalDocumentNoInGSTN(String originalDocumentNo, String entityName, String columnName);

	<T> List<T> isValidAmendment(String originalDOcumentNo, String entityName, String columnName);

	<T> T getEntityByColumn(String entityName, String colunName, Object columnValue);

	<T> List<T> validateOriginalDocNoDocDate(String docNum, Date date, String entityName, String column1,
			String column2);

    boolean isInvoicePresentInGSTN(String invoiceKey);

	Object fetchHsnSacDetails(String hsnSac, String hsnsacTableClass, String columnName);

	<T> List<T> isValidAmendmentGSTN(String originalDocumentNo, String entityName, String columnName);

	<T> List<T> validateOriginalDocumentNoForCR(String originalDOcumentNo, String entityName, String columnName, String origDocType);

	<T> List<T> validateOriginalDocumentNoForRCRRDR(String originalDocumentNo, String entityName, String columnName, String origDocType);

	<T> List<T> validateOriginalDocNoDocDateForCRDR(String docNum, Date documentDate, String entityName, String column1,
			String column2);
	

}
