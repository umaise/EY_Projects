package com.ey.advisory.asp.client.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.PurchaseStagingDao;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;

@Service
@Transactional
public class PurchaseStagingServiceImpl implements PurchaseStagingService{
	
	@Autowired
	HibernateDao hibernateDao;
	@Autowired
	private PurchaseStagingDao purchaseDao;
	
	private static final Logger logger = Logger.getLogger(PurchaseStagingServiceImpl.class);
	private static final String CLASS_NAME = PurchaseStagingServiceImpl.class.getName();

	@Override
	public Long getDupCount(Long fileId) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getDupCount");

		Long count = null;
		try{
			count = purchaseDao.getTotalDupCount(fileId);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +" Method : getDupCount", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getDupCount");
		
		return count;
	}

	@Override
	public Long getProcessedCount(Long fileId) {

		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getProcessedCount");
		
		Long count = null;
		try{
			count = purchaseDao.getTotalProcessedCount(fileId);
			
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +" Method : getProcessedCount", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getProcessedCount");
		return count;
	}

	@Override
	public Long getTotalErrorCount(Long fileId) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getTotalErrorCount");

		Long count = null;
		try{
			count = purchaseDao.getTotalErrorCount(fileId);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+" Method : getTotalErrorCount", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getTotalErrorCount");
		return count;
	}

	@Override
	public List<InwardInvoiceModel> fetchDupRecords(Long fileId,int firstResult, int pageSize) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" fetchDupRecords");
		List<InwardInvoiceModel> dupRecList = null;
		
		try{
			dupRecList = purchaseDao.fetchDupRecords(fileId,firstResult, pageSize);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +" Method : fetchDupRecords", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" fetchDupRecords");
		return dupRecList;
	}

	@Override
	public List<InwardInvoiceModel> getProcessedRecords(Long fileId,int firstResult, int pageSize) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getProcessedRecords");
		List<InwardInvoiceModel> processRecList= null;
		
		try{
			processRecList = purchaseDao.fetchProcessedRecords(fileId,firstResult, pageSize);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +" Method : getProcessedRecords", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getProcessedRecords");
		return processRecList;
	}

	@Override
	public List<InwardInvoiceModel> fetchErrorRecords(Long fileId,int firstResult, int pageSize) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" fetchErrorRecords");
		List<InwardInvoiceModel> errorList = null;
		
		try{
			errorList = purchaseDao.fetchErrorRecords(fileId,firstResult, pageSize);
		}
		catch(Exception e){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+" Method : fetchErrorRecords", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" fetchErrorRecords");
		return errorList;
	}

}
