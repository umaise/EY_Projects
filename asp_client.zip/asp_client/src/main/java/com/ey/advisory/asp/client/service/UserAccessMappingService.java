package com.ey.advisory.asp.client.service;

import java.util.List;

public interface UserAccessMappingService {
	
	public List<String> getGstinByLevel(Integer userId, Integer entityID);
}
