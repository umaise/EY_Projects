package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name="tblB2BItemDetails", schema=Constant.GSTR2A_SCHEMA)
public class GSTR2AB2BItemDetail implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private long id;
	
	@Column(name="LineNo")
	private int lineNo;
	
	@Column(name="ItemTxval")
	private BigDecimal itemTxVal;
	
	@Column(name="IGSTAmt")
	private BigDecimal igstAmt;
	
	@Column(name="CGSTAmt")
	private BigDecimal cgstAmt;
	
	@Column(name="SGSTAmt")
	private BigDecimal sgstAmt;
	
	@Column(name="CessAmt")
	private BigDecimal cessAmt;
	
	@Column(name="Rate")
	private BigDecimal rate;
	
	@Column(name="InvoiceDetailsId")
	private int invoiceDetailsId;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getLineNo() {
		return lineNo;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}

	public BigDecimal getItemTxVal() {
		return itemTxVal;
	}

	public void setItemTxVal(BigDecimal itemTxVal) {
		this.itemTxVal = itemTxVal;
	}

	public BigDecimal getIgstAmt() {
		return igstAmt;
	}

	public void setIgstAmt(BigDecimal igstAmt) {
		this.igstAmt = igstAmt;
	}

	public BigDecimal getCgstAmt() {
		return cgstAmt;
	}

	public void setCgstAmt(BigDecimal cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	public BigDecimal getSgstAmt() {
		return sgstAmt;
	}

	public void setSgstAmt(BigDecimal sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	public BigDecimal getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(BigDecimal cessAmt) {
		this.cessAmt = cessAmt;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public int getInvoiceDetailsId() {
		return invoiceDetailsId;
	}

	public void setInvoiceDetailsId(int invoiceDetailsId) {
		this.invoiceDetailsId = invoiceDetailsId;
	}
	
}
