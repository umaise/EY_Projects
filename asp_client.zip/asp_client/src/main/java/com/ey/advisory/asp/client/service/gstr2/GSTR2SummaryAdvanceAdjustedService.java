package com.ey.advisory.asp.client.service.gstr2;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR2SummaryAdvanceAdjusted;


@FunctionalInterface
public interface GSTR2SummaryAdvanceAdjustedService {
	
	public List<GSTR2SummaryAdvanceAdjusted> getAdvanceAdjustedMetadata(); 

}
