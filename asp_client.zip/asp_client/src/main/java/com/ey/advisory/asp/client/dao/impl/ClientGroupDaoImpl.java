/**
 * 
 */
package com.ey.advisory.asp.client.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.ClientGroupDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.ClientGroupDomain;
import com.ey.advisory.asp.client.domain.EntityModel;

/**
 * @author Nitesh.Tripathi
 *
 */
@Repository
public class ClientGroupDaoImpl implements ClientGroupDao {

	@Autowired
	private HibernateDao hibernateDao;

	private static final Logger LOGGER = Logger.getLogger(ClientGroupDaoImpl.class);

	@Override
	public String getClientGroup(long groupId, String groupcode) {
		LOGGER.info("Checking getClientGroup for " + groupId + " groupcode " + groupcode);
		String output = "1";
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(ClientGroupDomain.class);
		hibernateDao.createCriteria(ClientGroupDomain.class);
		detachedCriteria.add(Restrictions.eq("groupID", groupId));
		detachedCriteria.add(Restrictions.eq("GroupCode", groupcode));
		try {

			@SuppressWarnings("unchecked")
			List<ClientGroupDomain> response = (List<ClientGroupDomain>) hibernateDao.find(detachedCriteria);
			if (response != null && response.size() > 0) {
				output = "0";
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}

		return output;

	}

	@Override
	public List<ClientGroupDomain> getClientGroup() {
		LOGGER.info("Entered getClientGroup");
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(ClientGroupDomain.class);
		List<ClientGroupDomain> response = null;
		try {
			response = (List<ClientGroupDomain>) hibernateDao.find(detachedCriteria);
		} catch (Exception e) {
			LOGGER.error("Exception occured in getClientGroup "+e);
		}
		return response;

	}

}
