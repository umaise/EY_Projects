package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;
import org.hibernate.annotations.Where;


/**
 * The persistent class for the tblPurchaseStaging database table.
 * 
 */
@Entity
@Table(name="tblPurchaseStaging", schema="etl")
@NamedQuery(name="TblPurchaseStaging.findAll", query="SELECT t FROM TblPurchaseStaging t")
public class TblPurchaseStaging implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(TblPurchaseStaging.class);

	@Id
	@Column(name="ID")
	private int id;

	@Column(name="Advances")
	private BigDecimal advances;

	@Column(name="AggInvoice")
	private BigDecimal aggInvoice;

	@Column(name="AggTaxableValue")
	private BigDecimal aggTaxableValue;

	@Column(name="BillQty")
	private BigDecimal billQty;

	@Column(name="CapitalGoodsIdentifier")
	private String capitalGoodsIdentifier;

	@Column(name="CategoryItem")
	private String categoryItem;

	@Column(name="CessAmount")
	private BigDecimal cessAmount;

	@Column(name="CessRate")
	private BigDecimal cessRate;

	private BigDecimal CGSTAmount;

	private BigDecimal CGSTRate;

	@Column(name="CompanyGSTIN")
	private String companyGSTIN;
	
	@Temporal(TemporalType.DATE)
	@Column(name="CompanyRoadPermitDate")
	private Date companyRoadPermitDate;

	@Column(name="CompanyRoadPermitNumber")
	private String companyRoadPermitNumber;
	
	@Temporal(TemporalType.DATE)
	@Column(name="Contractdate")
	private Date contractdate;

	@Column(name="ContractNumber")
	private String contractNumber;

	@Column(name="ContractValue")
	private BigDecimal contractValue;

	@Column(name="CosumptionType")
	private String cosumptionType;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DateofPayment")
	private Date dateofPayment;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DocumentDate")
	private Date documentDate;

	@Column(name="DocumentNo")
	private String documentNo;

	@Column(name="DocumentType")
	private String documentType;

	@Column(name="EligibleInput")
	private String eligibleInput;

	@Column(name="FileID")
	private int fileID;

	private String GLCodeCapitalGoods;

	@Column(name="GoodServices")
	private String goodServices;

	private BigDecimal GSTTaxableValue;

	@Column(name="HSNSAC")
	private String hsnsac;

	private BigDecimal IGSTAmount;

	private BigDecimal IGSTRate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="ImportReportDate")
	private Date importReportDate;

	@Column(name="ImportReportNumber")
	private String importReportNumber;

	@Column(name="InvOrder")
	private Long invOrder;

	@Column(name="InwardSuppliesSubjectTTDS")
	private String inwardSuppliesSubjectTTDS;

	@Column(name="ItcCgstAmt")
	private BigDecimal itcCgstAmt;

	@Column(name="ItcCsgstAmt")
	private BigDecimal itcCsgstAmt;

	@Column(name="ItcIgstAmt")
	private BigDecimal itcIgstAmt;

	@Column(name="ItcSgstAmt")
	private BigDecimal itcSgstAmt;

	@Column(name="ItemCode")
	private String itemCode;

	@Column(name="ItemDescription")
	private String itemDescription;

	@Column(name="LineNumber")
	private String lineNumber;

	@Column(name="LorryNumber")
	private String lorryNumber;

	@Column(name="MonthlyITCavailability")
	private BigDecimal monthlyITCavailability;
	
	@Temporal(TemporalType.DATE)
	@Column(name="OriginalDocumentDate")
	private Date originalDocumentDate;

	@Column(name="OriginalDocumentNo")
	private String originalDocumentNo;

	@Column(name="PaymentVoucherNumber")
	private String paymentVoucherNumber;

	@Column(name="POS")
	private String pos;

	@Column(name="PosCd")
	private String posCd;

	@Column(name="ReceiverPlantCode")
	private String receiverPlantCode;

	@Column(name="RecordType")
	private String recordType;

	@Column(name="ReverseCharge")
	private String reverseCharge;

	private BigDecimal SGSTAmount;

	private BigDecimal SGSTRate;

	@Column(name="Status")
	private String status;

	@Column(name="SupplierAddress")
	private String supplierAddress;

	@Column(name="SupplierCode")
	private String supplierCode;

	@Column(name="SupplierGSTIN")
	private String supplierGSTIN;

	@Column(name="SupplierName")
	private String supplierName;

	@Column(name="SupplierRoadPermitNumber")
	private String supplierRoadPermitNumber;
	
	@Temporal(TemporalType.DATE)
	@Column(name="SuppliersRoadPermitDate")
	private Date suppliersRoadPermitDate;

	@Column(name="SupplyType")
	private String supplyType;

	@Column(name="TaxPeriod")
	private String taxPeriod;

	@Column(name="TcCgstAmt")
	private BigDecimal tcCgstAmt;

	@Column(name="TcCsgstAmt")
	private BigDecimal tcCsgstAmt;

	@Column(name="TcIgstAmt")
	private BigDecimal tcIgstAmt;

	@Column(name="TcSgstAmt")
	private BigDecimal tcSgstAmt;

	private BigDecimal TDS_Cess;

	@Column(name="TDS_CGST")
	private BigDecimal tdsCgst;

	@Column(name="TDS_IGST")
	private BigDecimal tdsIgst;

	@Column(name="TDS_SGST")
	private BigDecimal tdsSgst;

	private BigDecimal TDSCessrate;

	private BigDecimal TDSCGSTrate;

	private BigDecimal TDSGSTrate;

	private BigDecimal TDSIGSTrate;

	@Column(name="TDSUTGST")
	private BigDecimal tdsutgst;

	private BigDecimal TDSUTGSTrate;

	@Column(name="TotalTaxeligibleITC")
	private BigDecimal totalTaxeligibleITC;

	@Column(name="TransactionIDforAdvances")
	private String transactionIDforAdvances;

	@Column(name="TransporterName")
	private String transporterName;

	@Column(name="UnitofMeasurement")
	private String unitofMeasurement;

	private BigDecimal UTGSTAmount;

	private BigDecimal UTGSTRate;

	@Column(name="ValueIncludingTax")
	private BigDecimal valueIncludingTax;

	@Column(name="ValueOnTDS")
	private BigDecimal valueOnTDS;

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "PurchaseStagingID", referencedColumnName="ID")
	private Set<TblPurchaseErrorInfo> tblErrorInfo;
	
	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "PurchaseStagingID", referencedColumnName="ID")
	@Where(clause = "incidenceLevel = 'Invoice'")
	private Set<TblPurchaseErrorInfo> tblInvoiceErrorInfo;
	
	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "PurchaseStagingID", referencedColumnName="ID")
	@Where(clause = "incidenceLevel = 'Line-Item'")
	private Set<TblPurchaseErrorInfo> tblLineItemErrorInfo;
	  
	
	public Set<TblPurchaseErrorInfo> getTblInvoiceErrorInfo() {
		return tblInvoiceErrorInfo;
	}


	public void setTblInvoiceErrorInfo(Set<TblPurchaseErrorInfo> tblInvoiceErrorInfo) {
		this.tblInvoiceErrorInfo = tblInvoiceErrorInfo;
	}


	public Set<TblPurchaseErrorInfo> getTblLineItemErrorInfo() {
		return tblLineItemErrorInfo;
	}


	public void setTblLineItemErrorInfo(Set<TblPurchaseErrorInfo> tblLineItemErrorInfo) {
		this.tblLineItemErrorInfo = tblLineItemErrorInfo;
	}
	
	public TblPurchaseStaging() {

		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in TblPurchaseStaging ");
			}
	}

	public Set<TblPurchaseErrorInfo> getTblErrorInfo() {
		return tblErrorInfo;
	}

	public void setTblErrorInfo(Set<TblPurchaseErrorInfo> tblErrorInfo) {
		this.tblErrorInfo = tblErrorInfo;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public BigDecimal getAdvances() {
		return this.advances;
	}

	public void setAdvances(BigDecimal advances) {
		this.advances = advances;
	}

	public BigDecimal getAggInvoice() {
		return this.aggInvoice;
	}

	public void setAggInvoice(BigDecimal aggInvoice) {
		this.aggInvoice = aggInvoice;
	}

	public BigDecimal getAggTaxableValue() {
		return this.aggTaxableValue;
	}

	public void setAggTaxableValue(BigDecimal aggTaxableValue) {
		this.aggTaxableValue = aggTaxableValue;
	}

	public BigDecimal getBillQty() {
		return this.billQty;
	}

	public void setBillQty(BigDecimal billQty) {
		this.billQty = billQty;
	}

	public String getCapitalGoodsIdentifier() {
		return this.capitalGoodsIdentifier;
	}

	public void setCapitalGoodsIdentifier(String capitalGoodsIdentifier) {
		this.capitalGoodsIdentifier = capitalGoodsIdentifier;
	}

	public String getCategoryItem() {
		return this.categoryItem;
	}

	public void setCategoryItem(String categoryItem) {
		this.categoryItem = categoryItem;
	}

	public BigDecimal getCessAmount() {
		return this.cessAmount;
	}

	public void setCessAmount(BigDecimal cessAmount) {
		this.cessAmount = cessAmount;
	}

	public BigDecimal getCessRate() {
		return this.cessRate;
	}

	public void setCessRate(BigDecimal cessRate) {
		this.cessRate = cessRate;
	}

	public BigDecimal getCGSTAmount() {
		return this.CGSTAmount;
	}

	public void setCGSTAmount(BigDecimal CGSTAmount) {
		this.CGSTAmount = CGSTAmount;
	}

	public BigDecimal getCGSTRate() {
		return this.CGSTRate;
	}

	public void setCGSTRate(BigDecimal CGSTRate) {
		this.CGSTRate = CGSTRate;
	}

	public String getCompanyGSTIN() {
		return this.companyGSTIN;
	}

	public void setCompanyGSTIN(String companyGSTIN) {
		this.companyGSTIN = companyGSTIN;
	}

	public Date getCompanyRoadPermitDate() {
		return this.companyRoadPermitDate;
	}

	public void setCompanyRoadPermitDate(Date companyRoadPermitDate) {
		this.companyRoadPermitDate = companyRoadPermitDate;
	}

	public String getCompanyRoadPermitNumber() {
		return this.companyRoadPermitNumber;
	}

	public void setCompanyRoadPermitNumber(String companyRoadPermitNumber) {
		this.companyRoadPermitNumber = companyRoadPermitNumber;
	}

	public Date getContractdate() {
		return this.contractdate;
	}

	public void setContractdate(Date contractdate) {
		this.contractdate = contractdate;
	}

	public String getContractNumber() {
		return this.contractNumber;
	}

	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	public BigDecimal getContractValue() {
		return this.contractValue;
	}

	public void setContractValue(BigDecimal contractValue) {
		this.contractValue = contractValue;
	}

	public String getCosumptionType() {
		return this.cosumptionType;
	}

	public void setCosumptionType(String cosumptionType) {
		this.cosumptionType = cosumptionType;
	}

	public Date getDateofPayment() {
		return this.dateofPayment;
	}

	public void setDateofPayment(Date dateofPayment) {
		this.dateofPayment = dateofPayment;
	}

	public Date getDocumentDate() {
		return this.documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public String getDocumentNo() {
		return this.documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public String getDocumentType() {
		return this.documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getEligibleInput() {
		return this.eligibleInput;
	}

	public void setEligibleInput(String eligibleInput) {
		this.eligibleInput = eligibleInput;
	}

	public int getFileID() {
		return this.fileID;
	}

	public void setFileID(int fileID) {
		this.fileID = fileID;
	}

	public String getGLCodeCapitalGoods() {
		return this.GLCodeCapitalGoods;
	}

	public void setGLCodeCapitalGoods(String GLCodeCapitalGoods) {
		this.GLCodeCapitalGoods = GLCodeCapitalGoods;
	}

	public String getGoodServices() {
		return this.goodServices;
	}

	public void setGoodServices(String goodServices) {
		this.goodServices = goodServices;
	}

	public BigDecimal getGSTTaxableValue() {
		return this.GSTTaxableValue;
	}

	public void setGSTTaxableValue(BigDecimal GSTTaxableValue) {
		this.GSTTaxableValue = GSTTaxableValue;
	}

	public String getHsnsac() {
		return this.hsnsac;
	}

	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}

	public BigDecimal getIGSTAmount() {
		return this.IGSTAmount;
	}

	public void setIGSTAmount(BigDecimal IGSTAmount) {
		this.IGSTAmount = IGSTAmount;
	}

	public BigDecimal getIGSTRate() {
		return this.IGSTRate;
	}

	public void setIGSTRate(BigDecimal IGSTRate) {
		this.IGSTRate = IGSTRate;
	}

	public Date getImportReportDate() {
		return this.importReportDate;
	}

	public void setImportReportDate(Date importReportDate) {
		this.importReportDate = importReportDate;
	}

	public String getImportReportNumber() {
		return this.importReportNumber;
	}

	public void setImportReportNumber(String importReportNumber) {
		this.importReportNumber = importReportNumber;
	}

	public Long getInvOrder() {
		return this.invOrder;
	}

	public void setInvOrder(Long invOrder) {
		this.invOrder = invOrder;
	}

	public String getInwardSuppliesSubjectTTDS() {
		return this.inwardSuppliesSubjectTTDS;
	}

	public void setInwardSuppliesSubjectTTDS(String inwardSuppliesSubjectTTDS) {
		this.inwardSuppliesSubjectTTDS = inwardSuppliesSubjectTTDS;
	}

	public BigDecimal getItcCgstAmt() {
		return this.itcCgstAmt;
	}

	public void setItcCgstAmt(BigDecimal itcCgstAmt) {
		this.itcCgstAmt = itcCgstAmt;
	}

	public BigDecimal getItcCsgstAmt() {
		return this.itcCsgstAmt;
	}

	public void setItcCsgstAmt(BigDecimal itcCsgstAmt) {
		this.itcCsgstAmt = itcCsgstAmt;
	}

	public BigDecimal getItcIgstAmt() {
		return this.itcIgstAmt;
	}

	public void setItcIgstAmt(BigDecimal itcIgstAmt) {
		this.itcIgstAmt = itcIgstAmt;
	}

	public BigDecimal getItcSgstAmt() {
		return this.itcSgstAmt;
	}

	public void setItcSgstAmt(BigDecimal itcSgstAmt) {
		this.itcSgstAmt = itcSgstAmt;
	}

	public String getItemCode() {
		return this.itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemDescription() {
		return this.itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getLineNumber() {
		return this.lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getLorryNumber() {
		return this.lorryNumber;
	}

	public void setLorryNumber(String lorryNumber) {
		this.lorryNumber = lorryNumber;
	}

	public BigDecimal getMonthlyITCavailability() {
		return this.monthlyITCavailability;
	}

	public void setMonthlyITCavailability(BigDecimal monthlyITCavailability) {
		this.monthlyITCavailability = monthlyITCavailability;
	}

	public Date getOriginalDocumentDate() {
		return this.originalDocumentDate;
	}

	public void setOriginalDocumentDate(Date originalDocumentDate) {
		this.originalDocumentDate = originalDocumentDate;
	}

	public String getOriginalDocumentNo() {
		return this.originalDocumentNo;
	}

	public void setOriginalDocumentNo(String originalDocumentNo) {
		this.originalDocumentNo = originalDocumentNo;
	}

	public String getPaymentVoucherNumber() {
		return this.paymentVoucherNumber;
	}

	public void setPaymentVoucherNumber(String paymentVoucherNumber) {
		this.paymentVoucherNumber = paymentVoucherNumber;
	}

	public String getPos() {
		return this.pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getPosCd() {
		return this.posCd;
	}

	public void setPosCd(String posCd) {
		this.posCd = posCd;
	}

	public String getReceiverPlantCode() {
		return this.receiverPlantCode;
	}

	public void setReceiverPlantCode(String receiverPlantCode) {
		this.receiverPlantCode = receiverPlantCode;
	}

	public String getRecordType() {
		return this.recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getReverseCharge() {
		return this.reverseCharge;
	}

	public void setReverseCharge(String reverseCharge) {
		this.reverseCharge = reverseCharge;
	}

	public BigDecimal getSGSTAmount() {
		return this.SGSTAmount;
	}

	public void setSGSTAmount(BigDecimal SGSTAmount) {
		this.SGSTAmount = SGSTAmount;
	}

	public BigDecimal getSGSTRate() {
		return this.SGSTRate;
	}

	public void setSGSTRate(BigDecimal SGSTRate) {
		this.SGSTRate = SGSTRate;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSupplierAddress() {
		return this.supplierAddress;
	}

	public void setSupplierAddress(String supplierAddress) {
		this.supplierAddress = supplierAddress;
	}

	public String getSupplierCode() {
		return this.supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getSupplierGSTIN() {
		return this.supplierGSTIN;
	}

	public void setSupplierGSTIN(String supplierGSTIN) {
		this.supplierGSTIN = supplierGSTIN;
	}

	public String getSupplierName() {
		return this.supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierRoadPermitNumber() {
		return this.supplierRoadPermitNumber;
	}

	public void setSupplierRoadPermitNumber(String supplierRoadPermitNumber) {
		this.supplierRoadPermitNumber = supplierRoadPermitNumber;
	}

	public Date getSuppliersRoadPermitDate() {
		return this.suppliersRoadPermitDate;
	}

	public void setSuppliersRoadPermitDate(Date suppliersRoadPermitDate) {
		this.suppliersRoadPermitDate = suppliersRoadPermitDate;
	}

	public String getSupplyType() {
		return this.supplyType;
	}

	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public BigDecimal getTcCgstAmt() {
		return this.tcCgstAmt;
	}

	public void setTcCgstAmt(BigDecimal tcCgstAmt) {
		this.tcCgstAmt = tcCgstAmt;
	}

	public BigDecimal getTcCsgstAmt() {
		return this.tcCsgstAmt;
	}

	public void setTcCsgstAmt(BigDecimal tcCsgstAmt) {
		this.tcCsgstAmt = tcCsgstAmt;
	}

	public BigDecimal getTcIgstAmt() {
		return this.tcIgstAmt;
	}

	public void setTcIgstAmt(BigDecimal tcIgstAmt) {
		this.tcIgstAmt = tcIgstAmt;
	}

	public BigDecimal getTcSgstAmt() {
		return this.tcSgstAmt;
	}

	public void setTcSgstAmt(BigDecimal tcSgstAmt) {
		this.tcSgstAmt = tcSgstAmt;
	}

	public BigDecimal getTDS_Cess() {
		return this.TDS_Cess;
	}

	public void setTDS_Cess(BigDecimal TDS_Cess) {
		this.TDS_Cess = TDS_Cess;
	}

	public BigDecimal getTdsCgst() {
		return this.tdsCgst;
	}

	public void setTdsCgst(BigDecimal tdsCgst) {
		this.tdsCgst = tdsCgst;
	}

	public BigDecimal getTdsIgst() {
		return this.tdsIgst;
	}

	public void setTdsIgst(BigDecimal tdsIgst) {
		this.tdsIgst = tdsIgst;
	}

	public BigDecimal getTdsSgst() {
		return this.tdsSgst;
	}

	public void setTdsSgst(BigDecimal tdsSgst) {
		this.tdsSgst = tdsSgst;
	}

	public BigDecimal getTDSCessrate() {
		return this.TDSCessrate;
	}

	public void setTDSCessrate(BigDecimal TDSCessrate) {
		this.TDSCessrate = TDSCessrate;
	}

	public BigDecimal getTDSCGSTrate() {
		return this.TDSCGSTrate;
	}

	public void setTDSCGSTrate(BigDecimal TDSCGSTrate) {
		this.TDSCGSTrate = TDSCGSTrate;
	}

	public BigDecimal getTDSGSTrate() {
		return this.TDSGSTrate;
	}

	public void setTDSGSTrate(BigDecimal TDSGSTrate) {
		this.TDSGSTrate = TDSGSTrate;
	}

	public BigDecimal getTDSIGSTrate() {
		return this.TDSIGSTrate;
	}

	public void setTDSIGSTrate(BigDecimal TDSIGSTrate) {
		this.TDSIGSTrate = TDSIGSTrate;
	}

	public BigDecimal getTdsutgst() {
		return this.tdsutgst;
	}

	public void setTdsutgst(BigDecimal tdsutgst) {
		this.tdsutgst = tdsutgst;
	}

	public BigDecimal getTDSUTGSTrate() {
		return this.TDSUTGSTrate;
	}

	public void setTDSUTGSTrate(BigDecimal TDSUTGSTrate) {
		this.TDSUTGSTrate = TDSUTGSTrate;
	}

	public BigDecimal getTotalTaxeligibleITC() {
		return this.totalTaxeligibleITC;
	}

	public void setTotalTaxeligibleITC(BigDecimal totalTaxeligibleITC) {
		this.totalTaxeligibleITC = totalTaxeligibleITC;
	}

	public String getTransactionIDforAdvances() {
		return this.transactionIDforAdvances;
	}

	public void setTransactionIDforAdvances(String transactionIDforAdvances) {
		this.transactionIDforAdvances = transactionIDforAdvances;
	}

	public String getTransporterName() {
		return this.transporterName;
	}

	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}

	public String getUnitofMeasurement() {
		return this.unitofMeasurement;
	}

	public void setUnitofMeasurement(String unitofMeasurement) {
		this.unitofMeasurement = unitofMeasurement;
	}

	public BigDecimal getUTGSTAmount() {
		return this.UTGSTAmount;
	}

	public void setUTGSTAmount(BigDecimal UTGSTAmount) {
		this.UTGSTAmount = UTGSTAmount;
	}

	public BigDecimal getUTGSTRate() {
		return this.UTGSTRate;
	}

	public void setUTGSTRate(BigDecimal UTGSTRate) {
		this.UTGSTRate = UTGSTRate;
	}

	public BigDecimal getValueIncludingTax() {
		return this.valueIncludingTax;
	}

	public void setValueIncludingTax(BigDecimal valueIncludingTax) {
		this.valueIncludingTax = valueIncludingTax;
	}

	public BigDecimal getValueOnTDS() {
		return this.valueOnTDS;
	}

	public void setValueOnTDS(BigDecimal valueOnTDS) {
		this.valueOnTDS = valueOnTDS;
	}

}