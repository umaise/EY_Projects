package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name="tblInvoiceKeyDetail" , schema=Constant.GSTR2_SCHEMA)
@Where(clause = "isActive=1")
public class GSTR2InvoiceKeyDetail implements Serializable{

	private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Id")
    private Long Id;
    
    @Column(name="InvoiceKey")
    private String invoiceKey;
    
    @Column(name="InvoiceType")
    private String invoiceType;
    
    @Column(name="DraftId")
    private Long draftId;
    
    @Column(name="FileId")
    private int fileId;
    
    @Column(name="Gstin")
    private String gstin;
    
    @Column(name="TaxPeriod")
    private String taxPeriod;
    
    @Column(name="LoadId")
    private Long loadId;
    
    @Column(name="IsLoadedToGstn")
    private Boolean isLoadedToGstn;
    
    @Column(name="IsSuccessToGstn")
    private Boolean isSuccessToGstn;
    
    @Column(name="IsActive")
    private Boolean isActive;
    
    @Column(name="CreatedDt")
    private Timestamp createdDt;
    
    @Column(name="UpdatedDt")
    private Timestamp updatedDt;
    
    @Column(name="TransType")
    private String transType;
    
    @OneToMany(mappedBy = "gstr2InvoiceKeyDetail",fetch = FetchType.LAZY)
   	private List<InwardInvoiceModel> inwardInvoiceModels;

   	public List<InwardInvoiceModel> getInwardInvoiceModels() {
   		return inwardInvoiceModels;
   	}

   	public void setInwardInvoiceModels(List<InwardInvoiceModel> inwardInvoiceModels) {
   		this.inwardInvoiceModels = inwardInvoiceModels;
   	}


	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public Long getDraftId() {
		return draftId;
	}

	public void setDraftId(Long draftId) {
		this.draftId = draftId;
	}

	public int getFileId() {
		return fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public Long getLoadId() {
		return loadId;
	}

	public void setLoadId(Long loadId) {
		this.loadId = loadId;
	}

	public Boolean isLoadedToGstn() {
		return isLoadedToGstn;
	}

	public void setLoadedToGstn(Boolean isLoadedToGstn) {
		this.isLoadedToGstn = isLoadedToGstn;
	}

	public Boolean isSuccessToGstn() {
		return isSuccessToGstn;
	}

	public void setSuccessToGstn(Boolean isSuccessToGstn) {
		this.isSuccessToGstn = isSuccessToGstn;
	}

	public Boolean isActive() {
		return isActive;
	}

	public void setActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Timestamp getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}

	public Timestamp getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Timestamp updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}
	
}
