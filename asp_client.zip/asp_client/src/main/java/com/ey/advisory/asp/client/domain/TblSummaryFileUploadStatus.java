package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;

@Entity
@Table(name = "tblSummaryFileLoad",schema="etl")
public class TblSummaryFileUploadStatus implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1001672047932139225L;
	private static final Logger LOGGER = Logger.getLogger(TblSummaryFileUploadStatus.class);
	
	@Id
	@Column(name = "SummaryFileID")
	private Integer fileId;
	
	@Column(name = "FileName")
	private String fileName;
	
	@Column(name = "FilePath")
	private	String filePath;
	
	@Column(name = "Content")
	private	String content;
	
	@Column(name = "FileType")
	private String fileType;
	
	@Column(name = "IsActive")
	private Boolean isActive;
	
	@Column(name = "IsDuplicate")
	private Boolean isDuplicate;
	
	@Column(name = "FileHash")
	private	String fileHash;
	
	@Column(name = "CountofRecInFile")
	private Integer countofRecInFile;
	
	
	@Column(name = "UpdatedDate")
	private	Date updatedDate;
	
	@Column(name = "UploadDate")
	private	Date uploadDate;
	
	@Column(name = "CreatedBy")
	private	String createdBy;
	
	@Column(name = "UpdatedBy")
	private	String updatedBy;
	
	@Column(name = "Status")
	private String status;
	
	@Column(name = "UserID")
	private int userID;
	
	@Transient
	private String uiDate;
	
	public TblSummaryFileUploadStatus(){
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in TblSummaryFileUploadStatus ");
			}
	}
	
	public TblSummaryFileUploadStatus(Integer fileId, String fileName, String content,
			String uiDate,String status) {
		super();
		this.fileId = fileId;
		this.fileName = fileName;
		this.content = content;
		this.status = status;
		this.uiDate = uiDate;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsDuplicate() {
		return isDuplicate;
	}

	public void setIsDuplicate(Boolean isDuplicate) {
		this.isDuplicate = isDuplicate;
	}

	public String getFileHash() {
		return fileHash;
	}

	public void setFileHash(String fileHash) {
		this.fileHash = fileHash;
	}

	public Integer getCountofRecInFile() {
		return countofRecInFile;
	}

	public void setCountofRecInFile(Integer countofRecInFile) {
		this.countofRecInFile = countofRecInFile;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Date getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getUiDate() {
		return uiDate;
	}

	public void setUiDate(String uiDate) {
		this.uiDate = uiDate;
	}

	
	
}
