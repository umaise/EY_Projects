package com.ey.advisory.asp.client.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.TblInvoiceSeries;
import com.ey.advisory.asp.common.Constant;


@Service
public class InvoiceSeriesServiceImpl implements InvoiceSeriesService {

    @Autowired
    HibernateDao hibernateDao;

    private static final Logger logger = Logger.getLogger(InvoiceSeriesServiceImpl.class);
    
    
    @Override
	public List<TblInvoiceSeries> fetchAll() {
		return hibernateDao.loadAllByNamedQuery("TblInvoiceSeries.findAll");
	}

	@Override
	public Long getTotalRecordCount(Long fileId) {
		  Long count = null;
		  try { 
			  
			  if(logger.isInfoEnabled())
				  logger.info(Constant.LOGGER_ENTERING + InvoiceSeriesServiceImpl.class.getName()
						  + " Method : getTotalRecordCount()");
			  
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblInvoiceSeries.class);
			  criteriaCount.add(Restrictions.eq("summaryFileID", fileId));
			  criteriaCount.add(Restrictions.eq("isActive", Boolean.TRUE));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + InvoiceSeriesServiceImpl.class.getName()
	                + " Method : getTotalRecordCount()" + exe);
	        }
	
		return count;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TblInvoiceSeries> fetchTotalRecords(Long fileId, int firstResult, int pageSize) {
		List<TblInvoiceSeries>  tblInvSeriesList = null;
		  try {
			  if(logger.isInfoEnabled())
				  logger.info(Constant.LOGGER_ENTERING + InvoiceSeriesServiceImpl.class.getName()
						  + " Method : fetchTotalRecords()");
			  
			  Criteria criteria = hibernateDao.createNormalCriteria(TblInvoiceSeries.class);
			  criteria.add(Restrictions.eq("summaryFileID", fileId));
			  criteria.add(Restrictions.eq("isActive", Boolean.TRUE));
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("invoiceSeriesID"));
			  tblInvSeriesList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + InvoiceSeriesServiceImpl.class.getName()
	                + " Method : fetchPages()" + exe);
	        }
	
		return tblInvSeriesList;
	}


}
