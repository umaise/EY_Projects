package com.ey.advisory.asp.client.dto;

public class AdvTaxPaymentDto {

	private String custGstin;
	private Double igstAmt;
	private Double cgstAmt;
	private Double sgstAmt;
	private Double cessAmt;
	
	public String getCustGstin() {
		return custGstin;
	}
	public void setCustGstin(String custGstin) {
		this.custGstin = custGstin;
	}
	public Double getIgstAmt() {
		return igstAmt;
	}
	public void setIgstAmt(Double igstAmt) {
		this.igstAmt = igstAmt;
	}
	public Double getCgstAmt() {
		return cgstAmt;
	}
	public void setCgstAmt(Double cgstAmt) {
		this.cgstAmt = cgstAmt;
	}
	public Double getSgstAmt() {
		return sgstAmt;
	}
	public void setSgstAmt(Double sgstAmt) {
		this.sgstAmt = sgstAmt;
	}
	public Double getCessAmt() {
		return cessAmt;
	}
	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}
	
	
}
