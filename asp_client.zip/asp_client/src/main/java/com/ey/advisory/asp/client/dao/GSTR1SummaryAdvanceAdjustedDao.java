package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR1SummaryAdvanceAdjusted;

@FunctionalInterface
public interface GSTR1SummaryAdvanceAdjustedDao {
	
	public List<GSTR1SummaryAdvanceAdjusted> getAdvanceAdjustedMetadata(); 

}
