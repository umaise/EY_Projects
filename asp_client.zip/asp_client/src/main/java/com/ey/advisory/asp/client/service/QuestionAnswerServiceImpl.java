package com.ey.advisory.asp.client.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.QuestionAnswerMapping;
import com.ey.advisory.asp.common.Constant;

@Service
public class QuestionAnswerServiceImpl implements QuestionAnswerService{

    @Autowired
    HibernateDao hibernateDao;
    
    private static final Logger logger = Logger.getLogger(QuestionAnswerServiceImpl.class);
    private static final String CLASS_NAME = QuestionAnswerServiceImpl.class.getName();
    

    @Override
    public void saveQuestionAnswerMapping(
        List<com.ey.advisory.asp.client.domain.QuestionAnswerMapping> questionAnswerMappingList) {
    	if(logger.isInfoEnabled()){
        logger.info(Constant.LOGGER_EXITING + CLASS_NAME
            + " Method : saveQuestionAnswerMapping");
    	}
        hibernateDao.saveOrUpdateAll(questionAnswerMappingList);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<Object[]> loadClientOnBoardingInfoDetails(String PAN) {

        

        String query = "select a.QuestionID, a.AnswerID from [master].[tblQuestionAnswerMapping] as a, [master].[tblEntity] as b where a.EntityID = b.EntityID and b.PAN = ?";
        
        return (List<Object[]>)hibernateDao.executeNativeSql(query, new Object[]{PAN});
    }

	@Override
	public List<QuestionAnswerMapping> fetchQuestionAnswers(Integer entityId) {
		if (logger.isInfoEnabled())
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " getEntityNames()");
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(QuestionAnswerMapping.class);
		detachedCriteria.add(Restrictions.eq("entityID", entityId));
		List<QuestionAnswerMapping> questionAnswerMappingList = null;
		try {
			questionAnswerMappingList = (List<QuestionAnswerMapping>) hibernateDao.find(detachedCriteria);
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getEntityNames()" + e);
		}
		return questionAnswerMappingList;
	}

    
}
