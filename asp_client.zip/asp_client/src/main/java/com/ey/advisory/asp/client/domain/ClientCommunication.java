package com.ey.advisory.asp.client.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "tblGSTINUserMapping", schema="master")
public class ClientCommunication {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="GSTINUserMappingID")
	private Integer gstinUserMappingId;
	
	@Column(name="GSTIN")
	private String gstin;

	@Column(name="PrimaryAuthUserID")
	private Integer pAuthUserId;
	
	@Column(name="SecondaryAuthUserID")
	private Integer sAuthUserId;
	
	@Column(name="PrimaryContactID")
	private Integer pContactUserId;
	
	@Column(name="SecondaryContactID")
	private Integer sContactUserId;
	
	@Transient
	private String primaryAuthUserName;
	@Transient
	private String secondaryAuthUserName;
	@Transient
	private String primaryContact;
	@Transient
	private String secondaryContact;
	

	public Integer getGstinUserMappingId() {
		return gstinUserMappingId;
	}
	public void setGstinUserMappingId(Integer gstinUserMappingId) {
		this.gstinUserMappingId = gstinUserMappingId;
	}
	
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getPrimaryAuthUserName() {
		return primaryAuthUserName;
	}
	public void setPrimaryAuthUserName(String primaryAuthUserName) {
		this.primaryAuthUserName = primaryAuthUserName;
	}
	public String getSecondaryAuthUserName() {
		return secondaryAuthUserName;
	}
	public void setSecondaryAuthUserName(String secondaryAuthUserName) {
		this.secondaryAuthUserName = secondaryAuthUserName;
	}
	public String getPrimaryContact() {
		return primaryContact;
	}
	public void setPrimaryContact(String primaryContact) {
		this.primaryContact = primaryContact;
	}
	public String getSecondaryContact() {
		return secondaryContact;
	}
	public void setSecondaryContact(String secondaryContact) {
		this.secondaryContact = secondaryContact;
	}
	public Integer getpAuthUserId() {
		return pAuthUserId;
	}
	public void setpAuthUserId(Integer pAuthUserId) {
		this.pAuthUserId = pAuthUserId;
	}
	public Integer getsAuthUserId() {
		return sAuthUserId;
	}
	public void setsAuthUserId(Integer sAuthUserId) {
		this.sAuthUserId = sAuthUserId;
	}
	public Integer getpContactUserId() {
		return pContactUserId;
	}
	public void setpContactUserId(Integer pContactUserId) {
		this.pContactUserId = pContactUserId;
	}
	public Integer getsContactUserId() {
		return sContactUserId;
	}
	public void setsContactUserId(Integer sContactUserId) {
		this.sContactUserId = sContactUserId;
	}
	
	@Override
	public String toString() {
		return "ClientCommunication [gstin=" + gstin + ", primaryAuthUserName="
				+ primaryAuthUserName + ", secondaryAuthUserName="
				+ secondaryAuthUserName + ", primaryContact=" + primaryContact
				+ ", secondaryContact=" + secondaryContact + ", pAuthUserId="
				+ pAuthUserId + ", sAuthUserId=" + sAuthUserId
				+ ", pContactUserId=" + pContactUserId + ", sContactUserId="
				+ sContactUserId + "]";
	}
}
