/**
 * 
 */
package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.EntityRegistrationDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.dto.ClientRegistrationDTO;
import com.ey.advisory.asp.client.dto.CommonSearchDto;
import com.ey.advisory.asp.client.dto.EntityHierarchyDTO;
import com.ey.advisory.asp.client.dto.ResultPage;
import com.ey.advisory.asp.common.Constant;

/**
 * @author Shivani.Aggarwal
 *
 */

@Service
@Transactional
public class EntityRegistrationServiceImpl implements EntityRegistrationService{

	private static final Logger logger = Logger.getLogger(EntityRegistrationServiceImpl.class);
	private static final String CLASS_NAME = EntityRegistrationServiceImpl.class.getName();
	
	
	@Autowired
	EntityRegistrationDao entityRegistrationDao;
	
	@Autowired
	EntityHeirarchyService entityHeirarchyService;
	
	@Autowired
	UserAccessMapHierarchy userAccessMapHierarchy;
	
	@Autowired
	HibernateDao hibernateDao;
	
	@Override
	public ResultPage<ClientRegistrationDTO> fetchRegistrationDataPag(CommonSearchDto searchDto) {
		ResultPage<ClientRegistrationDTO> gstinRegList = null;
		try {
			gstinRegList = entityRegistrationDao.fetchRegistrationListPagination(searchDto);
			List<Object[]> clientRegList= gstinRegList.getResultListArray();
			List<ClientRegistrationDTO> clientRegistrationList = new ArrayList<ClientRegistrationDTO>();
			ClientRegistrationDTO clientRegDTO = null;
			for(Object[] clientReg: clientRegList){
				clientRegDTO = new ClientRegistrationDTO();
				
				clientRegDTO.setGstinId((String)clientReg[0]);
				clientRegDTO.setEntityID((Integer)clientReg[1]);
				clientRegDTO.setgSTNUserName(clientReg[2]==null?null:(String)clientReg[2]);
				clientRegDTO.setTurnOverAmount(clientReg[3]==null?null:(Double)clientReg[3]);
				clientRegDTO.setTypeOfReg(clientReg[4]==null?null:(String)clientReg[4]);
				clientRegDTO.setRegdt(clientReg[5]==null?null:(Date)clientReg[5]);
				clientRegDTO.setBankAccountNumber(clientReg[6]==null?null:(String)clientReg[6]);
				clientRegDTO.setQuarterTurnOvrAmt(clientReg[7]==null?null:(Double)clientReg[7]);
				clientRegDTO.setpAuthUserId(clientReg[8]==null?null:(Integer)clientReg[8]);
				clientRegDTO.setsAuthUserId(clientReg[9]==null?null:(Integer)clientReg[9]);
				clientRegDTO.setpContactUserId(clientReg[10]==null?null:(Integer)clientReg[10]);
				clientRegDTO.setsContactUserId(clientReg[11]==null?null:(Integer)clientReg[11]);
				clientRegDTO.setIsActive((Boolean)clientReg[12]);
				clientRegDTO.setUpdatedDate((Date)clientReg[13]);
				clientRegistrationList.add(clientRegDTO);
			}
			gstinRegList.setResultList(clientRegistrationList);
			
		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " fetchRegistrationDataPag()", e);
		}
		if (logger.isInfoEnabled()) {
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD + " fetchRegistrationDataPag()");
		}
		return gstinRegList;
	}

	@Override
	public void deleteRegistrationData(String gstin) throws Exception {
		logger.info("Entered deleteRegistrationData");
		try{
			TblGstinDetailsDomain gstinDetailsDomain= hibernateDao.load(TblGstinDetailsDomain.class, gstin);
			gstinDetailsDomain.setIsActive(false);
			gstinDetailsDomain.setUpdatedDate(new Date());
			hibernateDao.merge(gstinDetailsDomain);
		}catch(Exception e){
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " deleteRegistrationData()", e);
			throw new Exception(e.getMessage());
		}
		
	}

	@Override
	public void updateRegistrationData(ClientRegistrationDTO clientRegistrationDTO) throws Exception {
		
		logger.info("Entered updateRegistrationData");
		try{
			entityRegistrationDao.updateBankAccNumber(clientRegistrationDTO);
			entityRegistrationDao.updateClientDetails(clientRegistrationDTO);
			
		}catch(Exception e){
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " updateRegistrationData()", e);
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public void addRegistrationData(ClientRegistrationDTO clientRegistrationDTO) throws Exception {
		logger.info("Entered addRegistrationData");
		try{
			entityRegistrationDao.addGSTINDetails(clientRegistrationDTO);
			entityRegistrationDao.addClientDetails(clientRegistrationDTO);
			entityRegistrationDao.addGSTINFinancialDetails(clientRegistrationDTO);
			
		}catch(Exception e){
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " addRegistrationData()", e);
			throw new Exception(e.getMessage());
		}
		
	}

	@Override
	public Map<Long,String> fetchGroupEntityLevelUsers(String entityCode) throws Exception {
		logger.info("Entered fetchGroupEntityLevelUsers");
		Map<Long,String> userIdLevelMap = new HashMap<Long,String>();
		try{
			userIdLevelMap = entityRegistrationDao.fetchGroupEntityLevelUsers(entityCode);
		}catch(Exception e){
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " fetchGroupEntityLevelUsers()", e);
			throw new Exception(e.getMessage());
		}
		return userIdLevelMap;
	}

	@Override
	public Map<Long, String> fetchGSTINRegisteredContacts(String gstin) {
		Map<Long, String> userIdLevelMap = new HashMap<Long, String>();
		logger.info("Entered fetchGSTINRegisteredContacts gstin: "+gstin);
		List<EntityHierarchy> entityHierarchyList = entityHeirarchyService.fetchByGSTIN(gstin);
		if(entityHierarchyList!=null && entityHierarchyList.size()>0){
			EntityHierarchyDTO entityHierarchyDTO = new EntityHierarchyDTO();
			List<String> circleCodeList = new ArrayList<String>();
			List<String> subDivCodeList = new ArrayList<String>();
			List<String> profitCenterList = new ArrayList<String>();
			List<String> businessCodeList = new ArrayList<String>();
			List<String> plantCodeList = new ArrayList<String>();
			for(EntityHierarchy entityHierarchy: entityHierarchyList){
				circleCodeList.add(entityHierarchy.getCircleCode());
				subDivCodeList.add(entityHierarchy.getSubDivCode());
				profitCenterList.add(entityHierarchy.getProfitCenterCode());
				businessCodeList.add(entityHierarchy.getBusinessUnitCode());
				plantCodeList.add(entityHierarchy.getPlantCode());
			}
			entityHierarchyDTO.setGroupCode(entityHierarchyList.get(0).getGroupCode());
			entityHierarchyDTO.setEntityCode(entityHierarchyList.get(0).getEntityCode());
			entityHierarchyDTO.setGstin(entityHierarchyList.get(0).getgSTIN());
			userIdLevelMap = userAccessMapHierarchy.fetchUserAccessMap(entityHierarchyDTO);
		}
		return userIdLevelMap;
	}

}
