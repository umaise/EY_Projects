package com.ey.advisory.asp.common;

public enum RegistrationTypes {
	
	REGULAR("GSTR1,GSTR2,GSTR3,GSTR3B"),TCS("TCS"),TDS("TDS"),ISD("GSTR6");//TO DO Once Database tables are finalised , Need to fetch from DB
	
	private String type;

	public String getType() {
		return type;
	}

	private RegistrationTypes(String type) {
		this.type = type;
	}

}
