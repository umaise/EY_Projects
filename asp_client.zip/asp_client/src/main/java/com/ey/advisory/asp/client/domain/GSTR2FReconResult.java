package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name="tblB2BInvoiceDetails", schema=Constant.GSTR2F_SCHEMA)
public class GSTR2FReconResult implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ID")
	private long id;
	
	@Column(name="ReconStatusID")
	private long reconStatusID;
	
	@Column(name="TableType")
	private String tableType;
	
	@Column(name="GSTIN")
	private String gstin;
	
	@Column(name="InvKey")
	private String invKey;
	
	@Column(name="gstr2Key")
	private int gstr2Key;
	
	@Column(name="gstr2AKey")
	private int gstr2AKey;
	
	@Column(name="TotalTax2")
	private BigDecimal totalTax2;
	
	@Column(name="TotalTax2A")
	private BigDecimal totalTax2A;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="ReconResponse")
	private String ReconResponse;
	
	@Column(name="SystemResponse")
	private String systemResponse;
	
	@Column(name="SuggestedResponse")
	private String suggestedResponse;
	
	@Column(name="ClientResponse")
	private String clientResponse;
	
	@Column(name="isActive")
	private Boolean IsActive;
	
	@Column(name="createdDate")
	private Date CreatedDate;
	
	@Column(name="updatedDate")
	private Date UpdatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getReconStatusID() {
		return reconStatusID;
	}

	public void setReconStatusID(long reconStatusID) {
		this.reconStatusID = reconStatusID;
	}

	public String getTableType() {
		return tableType;
	}

	public void setTableType(String tableType) {
		this.tableType = tableType;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getInvKey() {
		return invKey;
	}

	public void setInvKey(String invKey) {
		this.invKey = invKey;
	}

	public int getGstr2Key() {
		return gstr2Key;
	}

	public void setGstr2Key(int gstr2Key) {
		this.gstr2Key = gstr2Key;
	}

	public int getGstr2AKey() {
		return gstr2AKey;
	}

	public void setGstr2AKey(int gstr2aKey) {
		gstr2AKey = gstr2aKey;
	}

	public BigDecimal getTotalTax2() {
		return totalTax2;
	}

	public void setTotalTax2(BigDecimal totalTax2) {
		this.totalTax2 = totalTax2;
	}

	public BigDecimal getTotalTax2A() {
		return totalTax2A;
	}

	public void setTotalTax2A(BigDecimal totalTax2A) {
		this.totalTax2A = totalTax2A;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getReconResponse() {
		return ReconResponse;
	}

	public void setReconResponse(String reconResponse) {
		ReconResponse = reconResponse;
	}

	public String getSystemResponse() {
		return systemResponse;
	}

	public void setSystemResponse(String systemResponse) {
		this.systemResponse = systemResponse;
	}

	public String getSuggestedResponse() {
		return suggestedResponse;
	}

	public void setSuggestedResponse(String suggestedResponse) {
		this.suggestedResponse = suggestedResponse;
	}

	public String getClientResponse() {
		return clientResponse;
	}

	public void setClientResponse(String clientResponse) {
		this.clientResponse = clientResponse;
	}

	public Boolean getIsActive() {
		return IsActive;
	}

	public void setIsActive(Boolean isActive) {
		IsActive = isActive;
	}

	public Date getCreatedDate() {
		return CreatedDate;
	}

	public void setCreatedDate(Date createdDate) {
		CreatedDate = createdDate;
	}

	public Date getUpdatedDate() {
		return UpdatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		UpdatedDate = updatedDate;
	}
	
	
}
