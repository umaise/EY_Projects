package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "tblGSTINSummaryList",schema="etl")
public class TblGSTINSummaryList implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8629016080177216783L;
	
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GSTINSummaryListID")
	private int gstinSummaryListID;
	@Column(name = "GSTIN")
	private String gSTIN;
	@Column(name = "TaxPeriod")
	private String taxPeriod;
	@Column(name = "Status")
	private	String status;
	@Column(name = "IsRoutingDone")
	private	Boolean isRoutingDone;
	@Column(name = "CreatedDate")
	private	Date createdDate;
	@Column(name = "UpdatedDate")
	private	Date updatedDate;
	@Column(name = "FileId")
	private	int fileId;
	@Column(name = "TransactionType")
	private	String transactionType;
	@Column(name = "ReturnType")
	private	String returnType;
	@Column(name = "IsSaveInitiated")
	private	Boolean isSaveInitiated;
	
	public Boolean getIsRoutingDone() {
		return isRoutingDone;
	}
	public void setIsRoutingDone(Boolean isRoutingDone) {
		this.isRoutingDone = isRoutingDone;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public Boolean getIsSaveInitiated() {
		return isSaveInitiated;
	}
	public void setIsSaveInitiated(Boolean isSaveInitiated) {
		this.isSaveInitiated = isSaveInitiated;
	}
	
	public String getgSTIN() {
		return gSTIN;
	}
	public void setgSTIN(String gSTIN) {
		this.gSTIN = gSTIN;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public int getGstinSummaryListID() {
		return gstinSummaryListID;
	}
	public void setGstinSummaryListID(int gstinSummaryListID) {
		this.gstinSummaryListID = gstinSummaryListID;
	}

}
