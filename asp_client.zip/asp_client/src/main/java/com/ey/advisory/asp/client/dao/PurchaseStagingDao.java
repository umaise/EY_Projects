package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;


public interface PurchaseStagingDao {
	
	List<InwardInvoiceModel> fetchProcessedRecords(Long fileId,int firstResult, int pageSize);

	List<InwardInvoiceModel> fetchTotalRecords(Long fileId,int firstResult, int pageSize);

	List<InwardInvoiceModel> fetchDupRecords(Long fileId,int firstResult, int pageSize);

	Long getTotalCount(Long fileId);

	Long getTotalProcessedCount(Long fileId);

	Long getTotalDupCount(Long fileId);
	
	public List<InwardInvoiceModel> fetchErrorRecords(Long fileId,int firstResult, int pageSize);
	
	public Long getTotalErrorCount(Long fileId);

}
