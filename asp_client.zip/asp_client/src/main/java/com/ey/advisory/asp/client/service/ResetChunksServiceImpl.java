package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.common.Constant;

@Service
public class ResetChunksServiceImpl implements ResetChunksService{

	private static final Logger logger = Logger.getLogger(ResetChunksServiceImpl.class);
	private static final String CLASS_NAME = ResetChunksServiceImpl.class.getName();

	@Autowired
	private HibernateDao hibernateDao;

	@Override
	public String resetChunks(JSONObject jsonObject) {
		String response = "";
		if(jsonObject.get(Constant.RETUTN_TYPE) == null || jsonObject.get(Constant.GSTIN) == null 
				|| jsonObject.get(Constant.TAXPERIOD) == null || jsonObject.get(Constant.RESET_GROUP) == null)
			return Constant.FAILED;
		try{
			List<String> list = new ArrayList<String>();
			list.add(jsonObject.get(Constant.RETUTN_TYPE).toString());
			list.add(jsonObject.get(Constant.GSTIN).toString());
			list.add(jsonObject.get(Constant.TAXPERIOD).toString());
			list.add(jsonObject.get(Constant.RESET_GROUP).toString());
			list.add(jsonObject.get(Constant.USERNAME).toString());
			response  = hibernateDao.executeStoredProcedure(Constant.DBO_SCHEMA,Constant.PROC_USPADMINRESETCHUNK, Constant.FIVE , list);
		}catch (Exception e) {
            logger.error("Error in updatescript" + e, e);
            response = Constant.FAILED;
        }
		return response;
	}

}
