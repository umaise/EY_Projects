package com.ey.advisory.asp.client.domain;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblGlobalGSTRatesMasterII",schema="master")
public class GlobalGSTRatesMasterII implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MasterId")
	private Long masterId;
	
	@Column(name = "HSNSAC")
	private String hsn_sac;
	
	@Column(name = "Description")
	private String desc;
	
	@Column(name = "UnitofMeasurement")
	private String unitOfMeasurement;
	
	@Column(name = "GstIGSTRt")
	private BigDecimal gst_igst;
	
	@Column(name = "GstCGSTRt")
	private BigDecimal gst_cgst;
	
	@Column(name = "GstSGSTRt")
	private BigDecimal gst_sgst;
	
	@Column(name = "GstUTGSTRt")
	private BigDecimal gst_utgst;
	
	@Column(name = "GstCessRt")
	private BigDecimal gst_cess;
	
	@Column(name = "ExmtCircularNumber")
	private String exempted_gst_circular_number;
	
	@Column(name = "ExmtCircularDate")
	private java.util.Date exempted_gst_circularDate;
	
	@Column(name = "ExmtEffectiveDate")
	private java.util.Date exempted_gst_effectiveDate;
	
	@Column(name = "ExmtGstIGSTRt")
	private BigDecimal exempted_gst_igst;
	
	@Column(name = "ExmtGstCGSTRt")
	private BigDecimal exempted_gst_cgst;
	
	@Column(name = "ExmtGstSGSTRt")
	private BigDecimal exempted_gst_sgst;
	
	@Column(name = "ExmtGstUTGSTRt")
	private BigDecimal exempted_gst_utgst;
	
	@Column(name = "ExmtGstCessRt")
	private BigDecimal exempted_gst_cess;
	
	@Column(name = "TdsIGSTRt")
	private BigDecimal gst_tds_igst;
	
	@Column(name = "TdsCGSTRt")
	private BigDecimal gst_tds_cgst;
	
	@Column(name = "TdsSGSTRt")
	private BigDecimal gst_tds_sgst;
	
	@Column(name = "TdsUTGSTRt")
	private BigDecimal gst_tds_utgst;
	
	@Column(name = "TdsCessRt")
	private BigDecimal gst_tds_cess;
	
	@Column(name = "ExmtTdsIGSTRt")
	private BigDecimal exempted_tds_igst;
	
	@Column(name = "ExmtTdsCGSTRt")
	private BigDecimal exempted_tds_cgst;
	
	@Column(name = "ExmtTdsSGSTRt")
	private BigDecimal exempted_tds_sgst;
	
	@Column(name = "ExmtTdsUTGSTRt")
	private BigDecimal exempted_tds_utgst;
	
	@Column(name = "ExmtTdsCessRt")
	private BigDecimal exempted_tds_cess;
	
	@Column(name = "ExmtTdsCircularNumber")
	private String exempted_tds_circular_number;
	
	@Column(name = "ExmtTdsCircularDate")
	private java.util.Date exempted_tds_circularDate;
	
	@Column(name = "ExmtTdsEffectiveDate")
	private java.util.Date exempted_tds_effectiveDate;
	
	
	public String getHsn_sac() {
		return hsn_sac;
	}
	public void setHsn_sac(String hsn_sac) {
		this.hsn_sac = hsn_sac;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getUnitOfMeasurement() {
		return unitOfMeasurement;
	}
	public void setUnitOfMeasurement(String unitOfMeasurement) {
		this.unitOfMeasurement = unitOfMeasurement;
	}
	public BigDecimal getGst_igst() {
		return gst_igst;
	}
	public void setGst_igst(BigDecimal gst_igst) {
		this.gst_igst = gst_igst;
	}
	public BigDecimal getGst_cgst() {
		return gst_cgst;
	}
	public void setGst_cgst(BigDecimal gst_cgst) {
		this.gst_cgst = gst_cgst;
	}
	public BigDecimal getGst_sgst() {
		return gst_sgst;
	}
	public void setGst_sgst(BigDecimal gst_sgst) {
		this.gst_sgst = gst_sgst;
	}
	public BigDecimal getGst_utgst() {
		return gst_utgst;
	}
	public void setGst_utgst(BigDecimal gst_utgst) {
		this.gst_utgst = gst_utgst;
	}
	public BigDecimal getGst_cess() {
		return gst_cess;
	}
	public void setGst_cess(BigDecimal gst_cess) {
		this.gst_cess = gst_cess;
	}
	public String getExempted_gst_circular_number() {
		return exempted_gst_circular_number;
	}
	public void setExempted_gst_circular_number(String exempted_gst_circular_number) {
		this.exempted_gst_circular_number = exempted_gst_circular_number;
	}
	public java.util.Date getExempted_gst_circularDate() {
		return exempted_gst_circularDate;
	}
	public void setExempted_gst_circularDate(
			java.util.Date exempted_gst_circularDate) {
		this.exempted_gst_circularDate = exempted_gst_circularDate;
	}
	public java.util.Date getExempted_gst_effectiveDate() {
		return exempted_gst_effectiveDate;
	}
	public void setExempted_gst_effectiveDate(
			java.util.Date exempted_gst_effectiveDate) {
		this.exempted_gst_effectiveDate = exempted_gst_effectiveDate;
	}
	public BigDecimal getExempted_gst_igst() {
		return exempted_gst_igst;
	}
	public void setExempted_gst_igst(BigDecimal exempted_gst_igst) {
		this.exempted_gst_igst = exempted_gst_igst;
	}
	public BigDecimal getExempted_gst_cgst() {
		return exempted_gst_cgst;
	}
	public void setExempted_gst_cgst(BigDecimal exempted_gst_cgst) {
		this.exempted_gst_cgst = exempted_gst_cgst;
	}
	public BigDecimal getExempted_gst_sgst() {
		return exempted_gst_sgst;
	}
	public void setExempted_gst_sgst(BigDecimal exempted_gst_sgst) {
		this.exempted_gst_sgst = exempted_gst_sgst;
	}
	public BigDecimal getExempted_gst_utgst() {
		return exempted_gst_utgst;
	}
	public void setExempted_gst_utgst(BigDecimal exempted_gst_utgst) {
		this.exempted_gst_utgst = exempted_gst_utgst;
	}
	public BigDecimal getExempted_gst_cess() {
		return exempted_gst_cess;
	}
	public void setExempted_gst_cess(BigDecimal exempted_gst_cess) {
		this.exempted_gst_cess = exempted_gst_cess;
	}
	public BigDecimal getGst_tds_igst() {
		return gst_tds_igst;
	}
	public void setGst_tds_igst(BigDecimal gst_tds_igst) {
		this.gst_tds_igst = gst_tds_igst;
	}
	public BigDecimal getGst_tds_cgst() {
		return gst_tds_cgst;
	}
	public void setGst_tds_cgst(BigDecimal gst_tds_cgst) {
		this.gst_tds_cgst = gst_tds_cgst;
	}
	public BigDecimal getGst_tds_sgst() {
		return gst_tds_sgst;
	}
	public void setGst_tds_sgst(BigDecimal gst_tds_sgst) {
		this.gst_tds_sgst = gst_tds_sgst;
	}
	public BigDecimal getGst_tds_utgst() {
		return gst_tds_utgst;
	}
	public void setGst_tds_utgst(BigDecimal gst_tds_utgst) {
		this.gst_tds_utgst = gst_tds_utgst;
	}
	public BigDecimal getGst_tds_cess() {
		return gst_tds_cess;
	}
	public void setGst_tds_cess(BigDecimal gst_tds_cess) {
		this.gst_tds_cess = gst_tds_cess;
	}
	public BigDecimal getExempted_tds_igst() {
		return exempted_tds_igst;
	}
	public void setExempted_tds_igst(BigDecimal exempted_tds_igst) {
		this.exempted_tds_igst = exempted_tds_igst;
	}
	public BigDecimal getExempted_tds_cgst() {
		return exempted_tds_cgst;
	}
	public void setExempted_tds_cgst(BigDecimal exempted_tds_cgst) {
		this.exempted_tds_cgst = exempted_tds_cgst;
	}
	public BigDecimal getExempted_tds_sgst() {
		return exempted_tds_sgst;
	}
	public void setExempted_tds_sgst(BigDecimal exempted_tds_sgst) {
		this.exempted_tds_sgst = exempted_tds_sgst;
	}
	public BigDecimal getExempted_tds_utgst() {
		return exempted_tds_utgst;
	}
	public void setExempted_tds_utgst(BigDecimal exempted_tds_utgst) {
		this.exempted_tds_utgst = exempted_tds_utgst;
	}
	public BigDecimal getExempted_tds_cess() {
		return exempted_tds_cess;
	}
	public void setExempted_tds_cess(BigDecimal exempted_tds_cess) {
		this.exempted_tds_cess = exempted_tds_cess;
	}
	public String getExempted_tds_circular_number() {
		return exempted_tds_circular_number;
	}
	public void setExempted_tds_circular_number(String exempted_tds_circular_number) {
		this.exempted_tds_circular_number = exempted_tds_circular_number;
	}
	public java.util.Date getExempted_tds_circularDate() {
		return exempted_tds_circularDate;
	}
	public void setExempted_tds_circularDate(
			java.util.Date exempted_tds_circularDate) {
		this.exempted_tds_circularDate = exempted_tds_circularDate;
	}
	public java.util.Date getExempted_tds_effectiveDate() {
		return exempted_tds_effectiveDate;
	}
	public void setExempted_tds_effectiveDate(
			java.util.Date exempted_tds_effectiveDate) {
		this.exempted_tds_effectiveDate = exempted_tds_effectiveDate;
	}

}
