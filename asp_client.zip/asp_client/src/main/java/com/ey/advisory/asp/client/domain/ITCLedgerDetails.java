/**
 * 
 */
package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Uma.Chandranaik
 *
 */
@Entity
@Table(name="tblgstr3ITCLedgerDetails", schema="gstr3")
public class ITCLedgerDetails implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private Long ITCID;

	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "MasterLedgerID")
	private CashITCLedgerMaster masterId;
	
	@Column(name="IsActive")
	private boolean isActive;
	
	@Column(name="IGSTAmt")
	private BigDecimal igstAmt;
	
	@Column(name="CGSTAmt")
	private BigDecimal cgstAmt;
	
	@Column(name="SGSTAmt")
	private BigDecimal sgstAmt;
	
	@Column(name="CessAmt")
	private BigDecimal cessAmt;
	
	@Column(name="Total")
	private BigDecimal total;

	public Long getITCID() {
		return ITCID;
	}

	public void setITCID(Long iTCID) {
		ITCID = iTCID;
	}

	public CashITCLedgerMaster getMasterId() {
		return masterId;
	}

	public void setMasterId(CashITCLedgerMaster masterId) {
		this.masterId = masterId;
	}

	public BigDecimal getIgstAmt() {
		return igstAmt;
	}

	public void setIgstAmt(BigDecimal igstAmt) {
		this.igstAmt = igstAmt;
	}

	public BigDecimal getCgstAmt() {
		return cgstAmt;
	}

	public void setCgstAmt(BigDecimal cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	public BigDecimal getSgstAmt() {
		return sgstAmt;
	}

	public void setSgstAmt(BigDecimal sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	public BigDecimal getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(BigDecimal cessAmt) {
		this.cessAmt = cessAmt;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	
	
}
