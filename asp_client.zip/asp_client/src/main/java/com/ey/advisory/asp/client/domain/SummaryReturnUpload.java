package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblSummaryReturnUpload", schema="trans")
public class SummaryReturnUpload implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LoadId")
	private Long loadId;
	
	@Column(name="ReturnFilingId")
	private Long filingId;
	
	@Column(name="ReturnType")
	private String returnType;
	
	@Column(name="MinInvoice")
	private Long minInvoice;
	
	@Column(name="MaxInnvoice")
	private Long maxInnvoice;
	
	@Column(name="ReferenceId")
	private String refId;
	
	@Column(name="TransactionId")
	private String TrxId; 	
	
	@Column(name="GSPRefId")
	private String gspRefId;
		
	@Column(name="IsActive")
	private Boolean isActive;
	
	@Column(name="CreatedDate")
	private Timestamp createdDt;
	
	@Column(name="UpdatedDate")
	private Timestamp updatedDt; 
	
	@Column(name="GSTNStatus")
	private String gstnStatus;

	public Long getLoadId() {
		return loadId;
	}

	public void setLoadId(Long loadId) {
		this.loadId = loadId;
	}

	

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public Long getMinInvoice() {
		return minInvoice;
	}

	public void setMinInvoice(Long minInvoice) {
		this.minInvoice = minInvoice;
	}

	public Long getMaxInnvoice() {
		return maxInnvoice;
	}

	public void setMaxInnvoice(Long maxInnvoice) {
		this.maxInnvoice = maxInnvoice;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getTrxId() {
		return TrxId;
	}

	public void setTrxId(String trxId) {
		TrxId = trxId;
	}

	public String getGspRefId() {
		return gspRefId;
	}

	public void setGspRefId(String gspRefId) {
		this.gspRefId = gspRefId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Timestamp getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}

	public Timestamp getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Timestamp updatedDt) {
		this.updatedDt = updatedDt;
	}


	public Long getTblGstnreStatus() {
		return filingId;
	}

	public void setTblGstnreStatus(Long tblGstnreStatus) {
		this.filingId = tblGstnreStatus;
	}

	public String getGstnStatus() {
		return gstnStatus;
	}

	public void setGstnStatus(String gstnStatus) {
		this.gstnStatus = gstnStatus;
	}
}	
