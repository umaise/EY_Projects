package com.ey.advisory.asp.client.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.SignAuthDao;
import com.ey.advisory.asp.client.domain.ClientCommunication;

@Repository
public class SignAuthDaoImpl implements SignAuthDao{

	@Autowired
	HibernateDao hibernateDao;
	
	private static final Logger LOGGER = Logger.getLogger(SignAuthDaoImpl.class);
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ClientCommunication> fetchAuthorizedSignatureGstins(Long userId) {
		
		List<ClientCommunication> clientCommunications = null;
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(ClientCommunication.class);

			Criterion rest1 = Restrictions.and(Restrictions.eq("pAuthUserId", userId.intValue()));
			Criterion rest2 = Restrictions.and(Restrictions.eq("sAuthUserId", userId.intValue()));
			detachedCriteria.add(Restrictions.or(rest1, rest2));

			clientCommunications = (List<ClientCommunication>) hibernateDao.find(detachedCriteria);

		} catch (Exception exec) {
			LOGGER.error("Exception in fetchAuthorizedSignatureGstins" + exec);
		}
		return clientCommunications;
	}
}
