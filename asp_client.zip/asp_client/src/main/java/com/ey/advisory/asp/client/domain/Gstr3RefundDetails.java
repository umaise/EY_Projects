package com.ey.advisory.asp.client.domain;

import java.math.BigDecimal;

public class Gstr3RefundDetails {

	
	private String gstin;
	private String returnPeriod;
	
	private BigDecimal refTaxIgstAmt;
	private BigDecimal refTaxCgstAmt;
	private BigDecimal refTaxSgstAmt;
	private BigDecimal refTaxCessAmt;
	private BigDecimal refTaxUtgstAmt;
	private BigDecimal refInterestIgstAmt;
	private BigDecimal refInterestCgstAmt;
	private BigDecimal refInterestSgstAmt;
	private BigDecimal refInterestCessAmt;
	private BigDecimal refInterestUtgstAmt;
	private BigDecimal refPenaltyIgstAmt;
	private BigDecimal refPenaltyCgstAmt;
	private BigDecimal refPenaltySgstAmt;
	private BigDecimal refPenaltyCessAmt;
	private BigDecimal refPenaltyUtgstAmt;
	private BigDecimal refFeeIgstAmt;
	private BigDecimal refFeeCgstAmt;
	private BigDecimal refFeeSgstAmt;
	private BigDecimal refFeeCessAmt;
	private BigDecimal refFeeUtgstAmt;
	private BigDecimal refOthersIgstAmt;
	private BigDecimal refOthersCgstAmt;
	private BigDecimal refOthersSgstAmt;
	private BigDecimal refOthersCessAmt;
	private BigDecimal refOthersUtgstAmt;
	private BigDecimal refTotalIgstAmt;
	private BigDecimal refTotalCgstAmt;
	private BigDecimal refTotalSgstAmt;
	private BigDecimal refTotalCessAmt;
	private BigDecimal refTotalUtgstAmt;
	private String bankAccNo;
	private String refDebitNo;
	
	
	
	public BigDecimal getRefTotalUtgstAmt() {
		return refTotalUtgstAmt;
	}
	public void setRefTotalUtgstAmt(BigDecimal refTotalUtgstAmt) {
		this.refTotalUtgstAmt = refTotalUtgstAmt;
	}
	public BigDecimal getRefTotalIgstAmt() {
		return refTotalIgstAmt;
	}
	public void setRefTotalIgstAmt(BigDecimal refTotalIgstAmt) {
		this.refTotalIgstAmt = refTotalIgstAmt;
	}
	public BigDecimal getRefTotalCgstAmt() {
		return refTotalCgstAmt;
	}
	public void setRefTotalCgstAmt(BigDecimal refTotalCgstAmt) {
		this.refTotalCgstAmt = refTotalCgstAmt;
	}
	public BigDecimal getRefTotalSgstAmt() {
		return refTotalSgstAmt;
	}
	public void setRefTotalSgstAmt(BigDecimal refTotalSgstAmt) {
		this.refTotalSgstAmt = refTotalSgstAmt;
	}
	public BigDecimal getRefTotalCessAmt() {
		return refTotalCessAmt;
	}
	public void setRefTotalCessAmt(BigDecimal refTotalCessAmt) {
		this.refTotalCessAmt = refTotalCessAmt;
	}
	public String getBankAccNo() {
		return bankAccNo;
	}
	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}
	public BigDecimal getRefTaxCessAmt() {
		return refTaxCessAmt;
	}
	public void setRefTaxCessAmt(BigDecimal refTaxCessAmt) {
		this.refTaxCessAmt = refTaxCessAmt;
	}
	public BigDecimal getRefTaxUtgstAmt() {
		return refTaxUtgstAmt;
	}
	public void setRefTaxUtgstAmt(BigDecimal refTaxUtgstAmt) {
		this.refTaxUtgstAmt = refTaxUtgstAmt;
	}
	public BigDecimal getRefInterestCessAmt() {
		return refInterestCessAmt;
	}
	public void setRefInterestCessAmt(BigDecimal refInterestCessAmt) {
		this.refInterestCessAmt = refInterestCessAmt;
	}
	public BigDecimal getRefInterestUtgstAmt() {
		return refInterestUtgstAmt;
	}
	public void setRefInterestUtgstAmt(BigDecimal refInterestUtgstAmt) {
		this.refInterestUtgstAmt = refInterestUtgstAmt;
	}
	public BigDecimal getRefPenaltyCessAmt() {
		return refPenaltyCessAmt;
	}
	public void setRefPenaltyCessAmt(BigDecimal refPenaltyCessAmt) {
		this.refPenaltyCessAmt = refPenaltyCessAmt;
	}
	public BigDecimal getRefPenaltyUtgstAmt() {
		return refPenaltyUtgstAmt;
	}
	public void setRefPenaltyUtgstAmt(BigDecimal refPenaltyUtgstAmt) {
		this.refPenaltyUtgstAmt = refPenaltyUtgstAmt;
	}
	public BigDecimal getRefFeeCessAmt() {
		return refFeeCessAmt;
	}
	public void setRefFeeCessAmt(BigDecimal refFeeCessAmt) {
		this.refFeeCessAmt = refFeeCessAmt;
	}
	public BigDecimal getRefFeeUtgstAmt() {
		return refFeeUtgstAmt;
	}
	public void setRefFeeUtgstAmt(BigDecimal refFeeUtgstAmt) {
		this.refFeeUtgstAmt = refFeeUtgstAmt;
	}
	public BigDecimal getRefOthersCessAmt() {
		return refOthersCessAmt;
	}
	public void setRefOthersCessAmt(BigDecimal refOthersCessAmt) {
		this.refOthersCessAmt = refOthersCessAmt;
	}
	public BigDecimal getRefOthersUtgstAmt() {
		return refOthersUtgstAmt;
	}
	public void setRefOthersUtgstAmt(BigDecimal refOthersUtgstAmt) {
		this.refOthersUtgstAmt = refOthersUtgstAmt;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public BigDecimal getRefTaxIgstAmt() {
		return refTaxIgstAmt;
	}
	public void setRefTaxIgstAmt(BigDecimal refTaxIgstAmt) {
		this.refTaxIgstAmt = refTaxIgstAmt;
	}
	public BigDecimal getRefTaxCgstAmt() {
		return refTaxCgstAmt;
	}
	public void setRefTaxCgstAmt(BigDecimal refTaxCgstAmt) {
		this.refTaxCgstAmt = refTaxCgstAmt;
	}
	public BigDecimal getRefTaxSgstAmt() {
		return refTaxSgstAmt;
	}
	public void setRefTaxSgstAmt(BigDecimal refTaxSgstAmt) {
		this.refTaxSgstAmt = refTaxSgstAmt;
	}
	public BigDecimal getRefInterestIgstAmt() {
		return refInterestIgstAmt;
	}
	public void setRefInterestIgstAmt(BigDecimal refInterestIgstAmt) {
		this.refInterestIgstAmt = refInterestIgstAmt;
	}
	public BigDecimal getRefInterestCgstAmt() {
		return refInterestCgstAmt;
	}
	public void setRefInterestCgstAmt(BigDecimal refInterestCgstAmt) {
		this.refInterestCgstAmt = refInterestCgstAmt;
	}
	public BigDecimal getRefInterestSgstAmt() {
		return refInterestSgstAmt;
	}
	public void setRefInterestSgstAmt(BigDecimal refInterestSgstAmt) {
		this.refInterestSgstAmt = refInterestSgstAmt;
	}
	public BigDecimal getRefPenaltyIgstAmt() {
		return refPenaltyIgstAmt;
	}
	public void setRefPenaltyIgstAmt(BigDecimal refPenaltyIgstAmt) {
		this.refPenaltyIgstAmt = refPenaltyIgstAmt;
	}
	public BigDecimal getRefPenaltyCgstAmt() {
		return refPenaltyCgstAmt;
	}
	public void setRefPenaltyCgstAmt(BigDecimal refPenaltyCgstAmt) {
		this.refPenaltyCgstAmt = refPenaltyCgstAmt;
	}
	public BigDecimal getRefPenaltySgstAmt() {
		return refPenaltySgstAmt;
	}
	public void setRefPenaltySgstAmt(BigDecimal refPenaltySgstAmt) {
		this.refPenaltySgstAmt = refPenaltySgstAmt;
	}
	public BigDecimal getRefFeeIgstAmt() {
		return refFeeIgstAmt;
	}
	public void setRefFeeIgstAmt(BigDecimal refFeeIgstAmt) {
		this.refFeeIgstAmt = refFeeIgstAmt;
	}
	public BigDecimal getRefFeeCgstAmt() {
		return refFeeCgstAmt;
	}
	public void setRefFeeCgstAmt(BigDecimal refFeeCgstAmt) {
		this.refFeeCgstAmt = refFeeCgstAmt;
	}
	public BigDecimal getRefFeeSgstAmt() {
		return refFeeSgstAmt;
	}
	public void setRefFeeSgstAmt(BigDecimal refFeeSgstAmt) {
		this.refFeeSgstAmt = refFeeSgstAmt;
	}
	public BigDecimal getRefOthersIgstAmt() {
		return refOthersIgstAmt;
	}
	public void setRefOthersIgstAmt(BigDecimal refOthersIgstAmt) {
		this.refOthersIgstAmt = refOthersIgstAmt;
	}
	public BigDecimal getRefOthersCgstAmt() {
		return refOthersCgstAmt;
	}
	public void setRefOthersCgstAmt(BigDecimal refOthersCgstAmt) {
		this.refOthersCgstAmt = refOthersCgstAmt;
	}
	public BigDecimal getRefOthersSgstAmt() {
		return refOthersSgstAmt;
	}
	public void setRefOthersSgstAmt(BigDecimal refOthersSgstAmt) {
		this.refOthersSgstAmt = refOthersSgstAmt;
	}
	public String getRefDebitNo() {
		return refDebitNo;
	}
	public void setRefDebitNo(String refDebitNo) {
		this.refDebitNo = refDebitNo;
	}
	
	
	
}
