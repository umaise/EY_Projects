package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.apache.log4j.Logger;
import org.hibernate.validator.constraints.Length;

/**
 * The persistent class for the tblPurchaseErrorInfo database table.
 * 
 */
@Entity
@Table(name="tblTDSErrorInfo", schema="trans")
@NamedQuery(name="TblTdsErrorInfo.findAll", query="SELECT t FROM TblTdsErrorInfo t")
public class TblTdsErrorInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(TblTdsErrorInfo.class);


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ErrorInfoID")
	private Integer errorInfoID;

	@Column(name="CreateDate")
	private Timestamp createDate;

	@Column(name="CreatedBy")@Length(max = 50)
	private String createdBy;

	@Column(name="ErrorColumnName")@Length(max = 100)
	private String errorColumnName;

	@Column(name="ErrorDesc")@Length(max = 500)
	private String errorDesc;

	@Column(name="ErrorInfoCode")@Length(max = 10)
	private String errorInfoCode;

	@Column(name="IsError")
	private char isError;

	@Column(name="IsProcessed")
	private boolean isProcessed;

	@Column(name="ProcessStatus")@Length(max = 200)
	private String processStatus;

	@Column(name="TDSStagingID")
	private Integer tdsStagingID;

	@Column(name="UpdatedDate")
	private Timestamp updatedDate;
	
	@Column(name="InvoiceNum")@Length(max = 50)
	private String invoiceNum;
	
	@Column(name="Gstin")@Length(max = 15)
	private String gstin;
	
	@Column(name="IncidenceLevel")
	private String incidenceLevel;


	public TblTdsErrorInfo() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in TblTdsErrorInfo ");
			}
	}
	
	public TblTdsErrorInfo(Integer tdsStagingID, String errorInfoCode, String errorDesc, String errorColumnName,
			String processStatus, boolean isProcessed, String invoiceNum, String gstin, String incidenceLevel, char isError) {
		this.tdsStagingID=tdsStagingID;
		this.errorInfoCode=errorInfoCode;
		this.errorDesc=errorDesc;
		this.errorColumnName=errorColumnName;
		this.processStatus=processStatus;
		this.isProcessed=isProcessed;
		this.invoiceNum = invoiceNum;
		this.gstin = gstin;
		this.incidenceLevel=incidenceLevel;
		this.isError = isError;
	}

	
	public Integer getErrorInfoID() {
		return errorInfoID;
	}



	public void setErrorInfoID(Integer errorInfoID) {
		this.errorInfoID = errorInfoID;
	}

	public Timestamp getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getErrorColumnName() {
		return this.errorColumnName;
	}

	public void setErrorColumnName(String errorColumnName) {
		this.errorColumnName = errorColumnName;
	}

	public String getErrorDesc() {
		return this.errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getErrorInfoCode() {
		return this.errorInfoCode;
	}

	public void setErrorInfoCode(String errorInfoCode) {
		this.errorInfoCode = errorInfoCode;
	}

	public char getIsError() {
		return this.isError;
	}

	public void setIsError(char isError) {
		this.isError = isError;
	}

	public boolean getIsProcessed() {
		return this.isProcessed;
	}

	public void setIsProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	

	public Integer getTdsStagingID() {
		return tdsStagingID;
	}

	public void setTdsStagingID(Integer tdsStagingID) {
		this.tdsStagingID = tdsStagingID;
	}

	public Timestamp getUpdatedDate() {
		return this.updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}


	public String getInvoiceNum() {
		return invoiceNum;
	}


	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}


	public String getGstin() {
		return gstin;
	}


	public void setGstin(String gstin) {
		this.gstin = gstin;
	}


	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	public String getIncidenceLevel() {
		return incidenceLevel;
	}

	public void setIncidenceLevel(String incidenceLevel) {
		this.incidenceLevel = incidenceLevel;
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((errorInfoCode == null) ? 0 : errorInfoCode.hashCode());
        result = prime * result + ((invoiceNum == null) ? 0 : invoiceNum.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TblTdsErrorInfo other = (TblTdsErrorInfo) obj;
        if (errorInfoCode == null) {
            if (other.errorInfoCode != null)
                return false;
        }
        else if (!errorInfoCode.equals(other.errorInfoCode))
            return false;
        if (invoiceNum == null) {
            if (other.invoiceNum != null)
                return false;
        }
        else if (!invoiceNum.equals(other.invoiceNum))
            return false;
        return true;
    }

}