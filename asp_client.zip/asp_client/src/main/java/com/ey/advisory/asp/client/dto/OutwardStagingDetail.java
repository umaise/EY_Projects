package com.ey.advisory.asp.client.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * The persistent class for the tblClientSalesStaging database table.
 * 
 */

public class OutwardStagingDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(OutwardStagingDetail.class);

	
	@JsonProperty("ID")
	private int id;
	
	private String advance;
	private BigDecimal aggInvoice;
	private BigDecimal aggTaxableValue;
	private String basicUnitValue;
	private int basicValueQtySupplied;
	private String billState;
	private double cessAmount;
	private double cessRate;
	private double cgstAmount;
	private double cgstRate;
	private String customerAddress;
	private String customerCode;
	private String customerGSTINUIN;
	private String customerLocationState;
	private String customerName;
	private String custStCd;
	private String dateReceiptFromRecepient;
	private String dateSupplyGoodsServices;
	private String discount;
	private String division;
	private String docNum;
	private Object documentDate;
	private String documentType;
	private int fileID;
	private String goodsServices;
	private String group;
	private String gstinEOperator;
	private String hsnsac;
	private double igstAmount;
	private double igstRate;
	private String indicateSupplyAttractsReversecharge;
	private double invoicedForeignCurrency;
	private String itemCode;
	private String itemDescription;
	private String legalEntity;
	private String lineNoOfDocno;
	private String lorryReceiptDate;
	private String lorryReceiptNumber;
	private String merchantID;
	private String netBasicValue;
	private String orgDocType;
	private Object originalDocumentDate;
	private String originalDocumentNo;
	private String othertaxes1;
	private double othertaxes2;
	private String paymentAmountReceived;
	private String plantCodeSupplier;
	private String pos;
	private String posCd;
	private String psnlCnsmptnLstDstrydGiftwoffsamples;
	private double qtySuppliedinvoiced;
	private long rank;
	private Object salesOrderAgreementDate;
	private String salesOrderAgreementNo;
	private double sgstAmount;
	private double sgstRate;
	private String shipFromLocationSupplier;
	private Object shippingBillDate;
	private String shippingBillNo;
	private String shipState;
	private String shipStateCd;
	private String subjectToTDS;
	private String supplierERN;
	private Object supplierERNDate;
	private String supplierIssuerGSTIN;
	private String supplyGoodsServicesReferenceDocumentNumber;
	private String supplyType;
	private String supStCd;
	private double taxableValue;
	private String taxPaidUnderProvisionalAssessment;
	private String taxperiod;
	private String transactionIDAdvances;
	private String transporterName;
	private String unitMeasurement;
	private double valueIncludingTax;
	private double valueIncludingTaxes;
	private Object voucherRedemptionDate;
	private String vouchers;
	private Object vouchersIssueDate;
	private String itemStatus;
	private String tableType;

	public OutwardStagingDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in OutwardStagingDetail ");
			}
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdvance() {
		return this.advance;
	}

	public void setAdvance(String advance) {
		this.advance = advance;
	}

	public BigDecimal getAggInvoice() {
		return this.aggInvoice;
	}

	public void setAggInvoice(BigDecimal aggInvoice) {
		this.aggInvoice = aggInvoice;
	}

	public BigDecimal getAggTaxableValue() {
		return this.aggTaxableValue;
	}

	public void setAggTaxableValue(BigDecimal aggTaxableValue) {
		this.aggTaxableValue = aggTaxableValue;
	}

	public String getBasicUnitValue() {
		return this.basicUnitValue;
	}

	public void setBasicUnitValue(String basicUnitValue) {
		this.basicUnitValue = basicUnitValue;
	}

	public int getBasicValueQtySupplied() {
		return this.basicValueQtySupplied;
	}

	public void setBasicValueQtySupplied(int basicValueQtySupplied) {
		this.basicValueQtySupplied = basicValueQtySupplied;
	}

	public String getBillState() {
		return this.billState;
	}

	public void setBillState(String billState) {
		this.billState = billState;
	}

	public double getCessAmount() {
		return this.cessAmount;
	}

	public void setCessAmount(double cessAmount) {
		this.cessAmount = cessAmount;
	}

	public double getCessRate() {
		return this.cessRate;
	}

	public void setCessRate(double cessRate) {
		this.cessRate = cessRate;
	}

	public double getCGSTAmount() {
		return this.cgstAmount;
	}

	public void setCGSTAmount(double cgstAmount) {
		this.cgstAmount = cgstAmount;
	}

	public double getCGSTRate() {
		return this.cgstRate;
	}

	public void setCGSTRate(double cgstRate) {
		this.cgstRate = cgstRate;
	}

	public String getCustomerAddress() {
		return this.customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerCode() {
		return this.customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerGSTINUIN() {
		return this.customerGSTINUIN;
	}

	public void setCustomerGSTINUIN(String customerGSTINUIN) {
		this.customerGSTINUIN = customerGSTINUIN;
	}

	public String getCustomerLocationState() {
		return this.customerLocationState;
	}

	public void setCustomerLocationState(String customerLocationState) {
		this.customerLocationState = customerLocationState;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustStCd() {
		return this.custStCd;
	}

	public void setCustStCd(String custStCd) {
		this.custStCd = custStCd;
	}

	public String getDateReceiptFromRecepient() {
		return this.dateReceiptFromRecepient;
	}

	public void setDateReceiptFromRecepient(String dateReceiptFromRecepient) {
		this.dateReceiptFromRecepient = dateReceiptFromRecepient;
	}

	public String getDateSupplyGoodsServices() {
		return this.dateSupplyGoodsServices;
	}

	public void setDateSupplyGoodsServices(String dateSupplyGoodsServices) {
		this.dateSupplyGoodsServices = dateSupplyGoodsServices;
	}

	public String getDiscount() {
		return this.discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getDivision() {
		return this.division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getDocNum() {
		return this.docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	public Object getDocumentDate() {
		return this.documentDate;
	}

	public void setDocumentDate(Object documentDate) {
		this.documentDate = documentDate;
	}

	public String getDocumentType() {
		return this.documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public int getFileID() {
		return this.fileID;
	}

	public void setFileID(int fileID) {
		this.fileID = fileID;
	}

	public String getGoodsServices() {
		return this.goodsServices;
	}

	public void setGoodsServices(String goodsServices) {
		this.goodsServices = goodsServices;
	}

	public String getGroup() {
		return this.group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getGSTINEOperator() {
		return this.gstinEOperator;
	}

	public void setGSTINEOperator(String gstinEOperator) {
		this.gstinEOperator = gstinEOperator;
	}

	public String getHsnsac() {
		return this.hsnsac;
	}

	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}

	public double getIGSTAmount() {
		return this.igstAmount;
	}

	public void setIGSTAmount(double igstAmount) {
		this.igstAmount = igstAmount;
	}

	public double getIGSTRate() {
		return this.igstRate;
	}

	public void setIGSTRate(double igstRate) {
		this.igstRate = igstRate;
	}

	public String getIndicateSupplyAttractsReversecharge() {
		return this.indicateSupplyAttractsReversecharge;
	}

	public void setIndicateSupplyAttractsReversecharge(String indicateSupplyAttractsReversecharge) {
		this.indicateSupplyAttractsReversecharge = indicateSupplyAttractsReversecharge;
	}

	public double getInvoicedForeignCurrency() {
		return this.invoicedForeignCurrency;
	}

	public void setInvoicedForeignCurrency(double invoicedForeignCurrency) {
		this.invoicedForeignCurrency = invoicedForeignCurrency;
	}

	public String getItemCode() {
		return this.itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemDescription() {
		return this.itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getLegalEntity() {
		return this.legalEntity;
	}

	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}

	public String getLineNoOfDocno() {
		return this.lineNoOfDocno;
	}

	public void setLineNoOfDocno(String lineNoOfDocno) {
		this.lineNoOfDocno = lineNoOfDocno;
	}

	public String getLorryReceiptDate() {
		return this.lorryReceiptDate;
	}

	public void setLorryReceiptDate(String lorryReceiptDate) {
		this.lorryReceiptDate = lorryReceiptDate;
	}

	public String getLorryReceiptNumber() {
		return this.lorryReceiptNumber;
	}

	public void setLorryReceiptNumber(String lorryReceiptNumber) {
		this.lorryReceiptNumber = lorryReceiptNumber;
	}

	public String getMerchantID() {
		return this.merchantID;
	}

	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

	public String getNetBasicValue() {
		return this.netBasicValue;
	}

	public void setNetBasicValue(String netBasicValue) {
		this.netBasicValue = netBasicValue;
	}

	public String getOrgDocType() {
		return this.orgDocType;
	}

	public void setOrgDocType(String orgDocType) {
		this.orgDocType = orgDocType;
	}

	public Object getOriginalDocumentDate() {
		return this.originalDocumentDate;
	}

	public void setOriginalDocumentDate(Object originalDocumentDate) {
		this.originalDocumentDate = originalDocumentDate;
	}

	public String getOriginalDocumentNo() {
		return this.originalDocumentNo;
	}

	public void setOriginalDocumentNo(String originalDocumentNo) {
		this.originalDocumentNo = originalDocumentNo;
	}

	public String getOthertaxes1() {
		return this.othertaxes1;
	}

	public void setOthertaxes1(String othertaxes1) {
		this.othertaxes1 = othertaxes1;
	}

	public double getOthertaxes2() {
		return this.othertaxes2;
	}

	public void setOthertaxes2(double othertaxes2) {
		this.othertaxes2 = othertaxes2;
	}

	public String getPaymentAmountReceived() {
		return this.paymentAmountReceived;
	}

	public void setPaymentAmountReceived(String paymentAmountReceived) {
		this.paymentAmountReceived = paymentAmountReceived;
	}

	public String getPlantCodeSupplier() {
		return this.plantCodeSupplier;
	}

	public void setPlantCodeSupplier(String plantCodeSupplier) {
		this.plantCodeSupplier = plantCodeSupplier;
	}

	public String getPos() {
		return this.pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getPOSCd() {
		return this.posCd;
	}

	public void setPOSCd(String posCd) {
		this.posCd = posCd;
	}

	public String getPsnlCnsmptnLstDstrydGiftwoffsamples() {
		return this.psnlCnsmptnLstDstrydGiftwoffsamples;
	}

	public void setPsnlCnsmptnLstDstrydGiftwoffsamples(String psnlCnsmptnLstDstrydGiftwoffsamples) {
		this.psnlCnsmptnLstDstrydGiftwoffsamples = psnlCnsmptnLstDstrydGiftwoffsamples;
	}

	public double getQtySuppliedinvoiced() {
		return this.qtySuppliedinvoiced;
	}

	public void setQtySuppliedinvoiced(double qtySuppliedinvoiced) {
		this.qtySuppliedinvoiced = qtySuppliedinvoiced;
	}

	public long getRank() {
		return this.rank;
	}

	public void setRank(long rank) {
		this.rank = rank;
	}

	public Object getSalesOrderAgreementDate() {
		return this.salesOrderAgreementDate;
	}

	public void setSalesOrderAgreementDate(Object salesOrderAgreementDate) {
		this.salesOrderAgreementDate = salesOrderAgreementDate;
	}

	public String getSalesOrderAgreementNo() {
		return this.salesOrderAgreementNo;
	}

	public void setSalesOrderAgreementNo(String salesOrderAgreementNo) {
		this.salesOrderAgreementNo = salesOrderAgreementNo;
	}

	public double getSGSTAmount() {
		return this.sgstAmount;
	}

	public void setSGSTAmount(double sgstAmount) {
		this.sgstAmount = sgstAmount;
	}

	public double getSGSTRate() {
		return this.sgstRate;
	}

	public void setSGSTRate(double sgstRate) {
		this.sgstRate = sgstRate;
	}

	public String getShipFromLocationSupplier() {
		return this.shipFromLocationSupplier;
	}

	public void setShipFromLocationSupplier(String shipFromLocationSupplier) {
		this.shipFromLocationSupplier = shipFromLocationSupplier;
	}

	public Object getShippingBillDate() {
		return this.shippingBillDate;
	}

	public void setShippingBillDate(Object shippingBillDate) {
		this.shippingBillDate = shippingBillDate;
	}

	public String getShippingBillNo() {
		return this.shippingBillNo;
	}

	public void setShippingBillNo(String shippingBillNo) {
		this.shippingBillNo = shippingBillNo;
	}

	public String getShipState() {
		return this.shipState;
	}

	public void setShipState(String shipState) {
		this.shipState = shipState;
	}

	public String getShipStateCd() {
		return this.shipStateCd;
	}

	public void setShipStateCd(String shipStateCd) {
		this.shipStateCd = shipStateCd;
	}

	public String getSubjectToTDS() {
		return this.subjectToTDS;
	}

	public void setSubjectToTDS(String subjectToTDS) {
		this.subjectToTDS = subjectToTDS;
	}

	public String getSupplierERN() {
		return this.supplierERN;
	}

	public void setSupplierERN(String supplierERN) {
		this.supplierERN = supplierERN;
	}

	public Object getSupplierERNDate() {
		return this.supplierERNDate;
	}

	public void setSupplierERNDate(Object supplierERNDate) {
		this.supplierERNDate = supplierERNDate;
	}

	public String getSupplierIssuerGSTIN() {
		return this.supplierIssuerGSTIN;
	}

	public void setSupplierIssuerGSTIN(String supplierIssuerGSTIN) {
		this.supplierIssuerGSTIN = supplierIssuerGSTIN;
	}

	public String getSupplyGoodsServicesReferenceDocumentNumber() {
		return this.supplyGoodsServicesReferenceDocumentNumber;
	}

	public void setSupplyGoodsServicesReferenceDocumentNumber(String supplyGoodsServicesReferenceDocumentNumber) {
		this.supplyGoodsServicesReferenceDocumentNumber = supplyGoodsServicesReferenceDocumentNumber;
	}

	public String getSupplyType() {
		return this.supplyType;
	}

	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}

	public String getSupStCd() {
		return this.supStCd;
	}

	public void setSupStCd(String supStCd) {
		this.supStCd = supStCd;
	}

	public double getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getTaxPaidUnderProvisionalAssessment() {
		return this.taxPaidUnderProvisionalAssessment;
	}

	public void setTaxPaidUnderProvisionalAssessment(String taxPaidUnderProvisionalAssessment) {
		this.taxPaidUnderProvisionalAssessment = taxPaidUnderProvisionalAssessment;
	}

	public String getTaxperiod() {
		return this.taxperiod;
	}

	public void setTaxperiod(String taxperiod) {
		this.taxperiod = taxperiod;
	}

	public String getTransactionIDAdvances() {
		return this.transactionIDAdvances;
	}

	public void setTransactionIDAdvances(String transactionIDAdvances) {
		this.transactionIDAdvances = transactionIDAdvances;
	}

	public String getTransporterName() {
		return this.transporterName;
	}

	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}

	public String getUnitMeasurement() {
		return this.unitMeasurement;
	}

	public void setUnitMeasurement(String unitMeasurement) {
		this.unitMeasurement = unitMeasurement;
	}

	public double getValueIncludingTax() {
		return this.valueIncludingTax;
	}

	public void setValueIncludingTax(double valueIncludingTax) {
		this.valueIncludingTax = valueIncludingTax;
	}

	public double getValueIncludingTaxes() {
		return this.valueIncludingTaxes;
	}

	public void setValueIncludingTaxes(double valueIncludingTaxes) {
		this.valueIncludingTaxes = valueIncludingTaxes;
	}

	public Object getVoucherRedemptionDate() {
		return this.voucherRedemptionDate;
	}

	public void setVoucherRedemptionDate(Object voucherRedemptionDate) {
		this.voucherRedemptionDate = voucherRedemptionDate;
	}

	public String getVouchers() {
		return this.vouchers;
	}

	public void setVouchers(String vouchers) {
		this.vouchers = vouchers;
	}

	public Object getVouchersIssueDate() {
		return this.vouchersIssueDate;
	}

	public void setVouchersIssueDate(Object vouchersIssueDate) {
		this.vouchersIssueDate = vouchersIssueDate;
	}

	public String getTableType() {
		return tableType;
	}

	public void setTableType(String tableType) {
		this.tableType = tableType;
	}

	public String getItemStatus() {
		return itemStatus;
	}

	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}
	

	
}