package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.TblDivision;
import com.ey.advisory.asp.client.dto.EntityModelDTO;
import com.ey.advisory.asp.client.dto.GroupDto;

public interface EntityModelService {

	public EntityModel getEntityDetails(String entityId);
	public List<EntityModel> fetchEntitiesByGroupId(String groupId);
	public List<TblDivision> fetchDivisionByEntityId(Integer entityId);
	public List<String> fetchGSTINIdByEntity(Integer entityID);
	public JSONArray fetchDivAndGSTIn(String id, boolean flag);
	public void saveUserInClientTables(JSONObject groupJson,int userID);
	public JSONObject fetchClientSideUserTablesAsJson(int userId,List<GroupDto> groupIds);
	public void updateUserInClientTables(JSONObject groupJson,int userID);
	public void deleteObject(JSONObject json);
	public List<EntityModel> getEntityDetails(ArrayList<Integer> entityId);
	
	/**
	 * To fetch all the entity details for loading into redis
	 * @return
	 */
	public Map<String, EntityModelDTO> getEntityDetails();
	String fetchEntityNameById(Integer entityID);
	
	public String isEntityExitsWithName(String entityName);
	public String saveEntityData(EntityModel entity) throws Exception;
}
