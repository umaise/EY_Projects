package com.ey.advisory.returnfiling.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;

@Service
public class ReturnFilingClientServiceImpl implements ReturnFilingClientService {

	@Autowired
	private ReturnFilingDao returnDoa;

	@Override
	public TblGstinRetutnFilingStatus getReturnFilingDetails(String taxPeriod, String gstin, String type,
			String filed) {

		return returnDoa.getReturnFilingDetails(taxPeriod, gstin, type, filed);
	}

}
