package com.ey.advisory.asp.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
@XmlAccessorType(XmlAccessType.FIELD)
public class OutwardSuppliesSelectedColumns {
	
	@XmlElement(name="Column")
	private List<String> Column;

	public List<String> getColumn() {
		return Column;
	}

	public void setColumn(List<String> column) {
		Column = column;
	}


	
	

}
