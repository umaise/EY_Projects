/**
 * 
 */
package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.ClientGroupDomain;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface ClientGroupDao {

	public String getClientGroup(long groupId, String groupcode);
	
	public List<ClientGroupDomain> getClientGroup();
	
}
