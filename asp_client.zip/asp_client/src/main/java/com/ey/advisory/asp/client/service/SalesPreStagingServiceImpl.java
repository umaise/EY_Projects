package com.ey.advisory.asp.client.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.TblSalesPreStaging;
import com.ey.advisory.asp.common.Constant;
/*
 * TODO: Place the loggers
 */
@Service
public class SalesPreStagingServiceImpl implements SalesPreStagingService {

    @Autowired
    HibernateDao hibernateDao;

    private static final Logger logger = Logger.getLogger(SalesPreStagingServiceImpl.class);

	@Override
	public List<TblSalesPreStaging> fetchAll() {
		// TODO Auto-generated method stub
		return hibernateDao.loadAllByNamedQuery("TblSalesPreStaging.findAll");
	}

	@Override
	public Long getTotalCount(Long fileId) {
		  Long count = null;
		  try { 
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblSalesPreStaging.class);
			  criteriaCount.add(Restrictions.eq("fileID", fileId));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + SalesPreStagingServiceImpl.class.getName()
	                + " Method : getStageInfo()" + exe);
	        }
	
		return count;
	}

	@Override
	public List<TblSalesPreStaging> fetchPages(Long fileId, int firstResult, int pageSize) {
		List<TblSalesPreStaging>  salesPreStagingList = null;
		  try {
			  Criteria criteria = hibernateDao.createNormalCriteria(TblSalesPreStaging.class);
			  criteria.add(Restrictions.eq("fileID", fileId));
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("id"));
			  salesPreStagingList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + SalesPreStagingServiceImpl.class.getName()
	                + " Method : fetchPages()" + exe);
	        }
	
		return salesPreStagingList;
	}

	@Override
	public Long getDupCount(Long fileId) {
		 Long count = null;
		  try { 
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblSalesPreStaging.class);
			  criteriaCount.add(Restrictions.eq("fileID", fileId));
			  criteriaCount.add(Restrictions.eq("duplicateStatus", "D"));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + SalesPreStagingServiceImpl.class.getName()
	                + " Method : getDupCount()" + exe);
	        }
	
		return count;
	}
	
	@Override
	public List<TblSalesPreStaging> fetchDupRecords(Long fileId, int firstResult, int pageSize) {
		List<TblSalesPreStaging>  salesPreStagingList = null;
		  try {
			  Criteria criteria = hibernateDao.createNormalCriteria(TblSalesPreStaging.class);
			  criteria.add(Restrictions.eq("fileID", fileId));
			  criteria.add(Restrictions.eq("duplicateStatus", "D"));
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("id"));
			  salesPreStagingList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + SalesPreStagingServiceImpl.class.getName()
	                + " Method : fetchDupRecords()" + exe);
	        }
	
		return salesPreStagingList;
	}

	@Override
	public Long getTotalErrorCount(Long fileId) {
		
		 Long count = null;
		  try { 
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblSalesPreStaging.class);
			  criteriaCount.add(Restrictions.eq("fileID", fileId));
			  criteriaCount.add(Restrictions.isNull("duplicateStatus"));
			  criteriaCount.add(Restrictions.eq("isError", "1"));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + SalesPreStagingServiceImpl.class.getName()
	                + " Method : getTotalErrorCount()" + exe);
	        }
	
		return count;
	}
	
	@Override
	public List<TblSalesPreStaging> fetchErrorRecords(Long fileId, int firstResult, int pageSize) {
		List<TblSalesPreStaging>  salesPreStagingList = null;
		  try {
			  Criteria criteria = hibernateDao.createNormalCriteria(TblSalesPreStaging.class);
			  criteria.add(Restrictions.eq("fileID", fileId));
			  criteria.add(Restrictions.isNull("duplicateStatus"));
			  criteria.add(Restrictions.eq("isError", "1"));
			  
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("id"));
			  salesPreStagingList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + SalesPreStagingServiceImpl.class.getName()
	                + " Method : fetchDupRecords()" + exe);
	        }
	
		return salesPreStagingList;
	}


}
