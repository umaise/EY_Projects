package com.ey.advisory.asp.client.service.gstr1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GSTR1SummaryB2CConsolidatedDao;
import com.ey.advisory.asp.client.domain.GSTR1SummaryB2CConsolidated;

@Service
public class GSTR1SummaryB2CConsolidatedServiceImpl implements GSTR1SummaryB2CConsolidatedService{
	
	@Autowired
	private GSTR1SummaryB2CConsolidatedDao b2CConsolidatedDao;

	@Override
	public List<GSTR1SummaryB2CConsolidated> getB2CConsolidatedMetadata() {
		return b2CConsolidatedDao.getB2CConsolidatedMetadata();
	}

}
