package com.ey.advisory.asp.client.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.NoSuchAlgorithmException;

import com.ey.advisory.asp.client.dto.DownloadedData;

public interface DigitalSignService {

	public String uploadData(String emailId,String content)
			throws IOException, NoSuchAlgorithmException, URISyntaxException;

	public DownloadedData downloadSignedData(String docId)
			throws NoSuchAlgorithmException, URISyntaxException;

}
