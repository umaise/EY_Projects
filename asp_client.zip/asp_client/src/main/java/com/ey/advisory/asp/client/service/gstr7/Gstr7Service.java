package com.ey.advisory.asp.client.service.gstr7;

import java.util.Set;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.dto.InvoiceProcessDto;

public interface Gstr7Service {

	String getGSTR7SummaryfromStub(String gstinId, String rtPeriod);

	public TblGstinRetutnFilingStatus getGStrReturnFilingDetails(String gstinId, String taxPeriod, String gstrType);

	public TblGstinRetutnFilingStatus getGstr7ReturnFilingDetails(String gstinId, String taxPeriod, String gstrType);

	public String getReturnFilingSuccess(String gstinId, String taxPeriod);
	
	public boolean getDupInvoice(InwardInvoiceModel inwardInvoiceModel);

	public boolean getTaxableVal(InwardInvoiceModel inwardInvoiceModel);
	
	boolean saveGstr7InvoiceStatus(Set<InvoiceProcessDto> invoiceList, Integer fileId);
    
    boolean saveTdsErrorInfo(Set<TblTdsErrorInfo> errorInfoList);
 
	public String fileGSTR7(SummaryDto summarydto);

	boolean timeoutAndMarkInvoiceStatusTechError(Integer fileId) throws Exception;
}
