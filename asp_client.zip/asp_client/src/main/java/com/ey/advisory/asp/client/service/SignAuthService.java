/**
 * 
 */
package com.ey.advisory.asp.client.service;

import java.util.List;
import java.util.Set;

import com.ey.advisory.asp.client.domain.ClientCommunication;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface SignAuthService {
	
	public List<ClientCommunication> fetchAuthorizedSignatureGstins(Long userId);
	
	public Set<String> fetchAuthorizedSignatureGstinsSet(Long userId);

}
