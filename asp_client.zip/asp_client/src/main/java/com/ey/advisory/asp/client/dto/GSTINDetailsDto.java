/**
 * 
 */
package com.ey.advisory.asp.client.dto;

/**
 * @author Nitesh.Tripathi
 *
 */
public class GSTINDetailsDto {

	private String GstinId;
	
	private String GSTNUserName;
	
	private Long EntityID;
	
	private String StateCode;
	/**
	 * @return the gstinId
	 */
	public String getGstinId() {
		return GstinId;
	}
	/**
	 * @param gstinId the gstinId to set
	 */
	public void setGstinId(String gstinId) {
		GstinId = gstinId;
	}
	/**
	 * @return the gSTNUserName
	 */
	public String getGSTNUserName() {
		return GSTNUserName;
	}
	/**
	 * @param gSTNUserName the gSTNUserName to set
	 */
	public void setGSTNUserName(String gSTNUserName) {
		GSTNUserName = gSTNUserName;
	}
	/**
	 * @return the entityID
	 */
	public Long getEntityID() {
		return EntityID;
	}
	/**
	 * @param entityID the entityID to set
	 */
	public void setEntityID(Long entityID) {
		EntityID = entityID;
	}
	/**
	 * @return the stateCode
	 */
	public String getStateCode() {
		return StateCode;
	}
	/**
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(String stateCode) {
		StateCode = stateCode;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GSTINDetailsDto [GstinId=" + GstinId + ", GSTNUserName=" + GSTNUserName + ", EntityID=" + EntityID
				+ ", StateCode=" + StateCode + "]";
	}
	
	
}
