package com.ey.advisory.asp.client.service.master;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.CustomerMaster;
import com.ey.advisory.asp.client.domain.DueDateMaster;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.ErrorInformationCodeMaster;
import com.ey.advisory.asp.client.domain.GlCodeMaster;
import com.ey.advisory.asp.client.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.client.domain.GlobalGSTRatesMasterII;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.MasterTable;
import com.ey.advisory.asp.client.domain.ProductMaster;
import com.ey.advisory.asp.client.domain.StateCodeMaster;
import com.ey.advisory.asp.client.domain.VendorMaster;
import com.ey.advisory.asp.common.Constant;


@Service("masterTableService")
public class MasterTableServiceImpl implements MasterTableService {

	@Autowired
	HibernateDao hibernateDao;
	
	@Override
	public List<Object> getMasterTableDetails(MasterTable masterTableDto) {
		
		String key=masterTableDto.getKey();
		List<Object> masterTableDetailsList=new ArrayList<>();
		switch (key) {
		case "dueDateDetails":
			DetachedCriteria detachedCriteriaDueDateDueDate = hibernateDao.createCriteria(DueDateMaster.class);
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaDueDateDueDate);
			break;
			
		case "itemMasterDetails":
			DetachedCriteria detachedCriteriaItem = hibernateDao.createCriteria(ItemMaster.class);
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaItem);
			break;
			
		case "globalGstRatesMasterDetails":
			DetachedCriteria detachedCriteriaGlobalGSTRates = hibernateDao.createCriteria(GlobalGSTRatesMasterI.class);
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaGlobalGSTRates);
			break;
			
			
		case "globalGstRatesMasterDetailsSecond":
			DetachedCriteria detachedCriteriaGlobalGSTRatesSecond = hibernateDao.createCriteria(GlobalGSTRatesMasterII.class);
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaGlobalGSTRatesSecond);
			break;
			
			
		case "glCodeMasterDetails":
			DetachedCriteria detachedCriteriaGlCodeMaster = hibernateDao.createCriteria(GlCodeMaster.class);
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaGlCodeMaster);
			break;
			
			
		case "productMasterDetails":
			DetachedCriteria detachedCriteriaProduct = hibernateDao.createCriteria(ProductMaster.class);
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaProduct);
			break;
			
		case "customerMaster":
			DetachedCriteria detachedCriteriaCustomer = hibernateDao.createCriteria(CustomerMaster.class);
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaCustomer);
                    break;

		case "vendorMasterDetails":
			DetachedCriteria detachedCriteriaVendor = hibernateDao.createCriteria(VendorMaster.class);
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaVendor);
			break;
			
		case "informationCodeMasterDetails":
			DetachedCriteria detachedCriteriaInfomationCode = hibernateDao.createCriteria(ErrorInformationCodeMaster.class);
			detachedCriteriaInfomationCode.add(Restrictions.eq("isError", Constant.INFORMATION_CODE_MASTER_FLAG));
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaInfomationCode);
			break;
			
		case "errorCodeMasterDetails":
			DetachedCriteria detachedCriteriaErrorCode = hibernateDao.createCriteria(ErrorInformationCodeMaster.class);
			detachedCriteriaErrorCode.add(Restrictions.eq("isError", Constant.ERROR_CODE_MASTER_FLAG));
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaErrorCode);
			break;
			
		case "entityHierarchyMasterDetails":
			DetachedCriteria detachedCriteriaEntityHierarchy = hibernateDao.createCriteria(EntityHierarchy.class);
			masterTableDetailsList = (List<Object>) hibernateDao.find(detachedCriteriaEntityHierarchy);
			break;
			
		default:
			break;
		}
		return masterTableDetailsList;
	
	}


}
