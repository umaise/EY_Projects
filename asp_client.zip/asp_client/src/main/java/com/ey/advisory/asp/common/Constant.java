package com.ey.advisory.asp.common;

import java.util.Calendar;

public class Constant {


	public static final String SAVESUCESS = "SaveSuccesfully";
	public static final String LoadId = "loadId";
	public static final String REC = "REC";
	public static final String SUBMIT_REC = "SubmitREC";
	public static final String INPROGRESS = "IP";
	public static final String SUBMIT_IP = "SubmitIP";
	public static final String SUBMITSUCESS = "SUBMITTED";
	public static final String SUCESS = "SaveSuccesfully";
	public static final String FALSE = "FALSE";
	public static final String TRUE = "TRUE";
	public static final String YES = "Yes";
	public static final String NO = "No";
	public static final String Y = "Y";
	public static final String CURRENTUSER = "CURRENTUSER";
	public static final String CURRENTUSEREMAILID = "CURRENTUSEREMAILID";
	public static final String USERGSTNROLES = "USERGSTNROLES";
	public static final String CURRENTROLE = "CURRENTROLE";
	public static final String GSTNTIME = "GSTNTIME";
	public static final String MAX_BAD_LOGIN = "MAX_BAD_LOGIN";
	public static final String PASS_EXPIRY_DAYS = "PASS_EXPIRY_DAYS";
	public static final String ENTER = "Enter ";
	public static final String EXIT = "Exit ";
	public final static String DATE_FORMAT = "MM-dd-yyyy";
	// Added for pagination
	public static final String DEFAULT_PAGE_SIZE = "DEFAULT_PAGE_SIZE";
	public final static String DATE_FORMAT_IN_HOURS = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String SYMBOL_COLON = ":";

	public static final String SEPERATOR_DOT = "\\.";

	// Service Map changes
	public static final String SERVICE_RELATION = "Level 4";
	public static final Long MENU_LEVEL = (long) 1;
	public static final String USER_ROLE_MENUS = "UserRoleMenus";
	public static final String USER_ROLE_FUNS = "UserRoleFuns";

	//
	/****** Resource Strings **********/
	public static final String AUTHENTICATE = "rest.authenticate";

	public static final String RETURNS = "gsp-transactionStatus";

	public static final String GSTR1 = "/gstr1";

	public static final String GSTR2 = "/gstr2";

	public static final String HOST = "http://devapi.gstsystem.co.in";

	public static final String LEDGERS = "/taxpayerapi/v0.1/ledgers";
	public static final String GSTIN = "GSTIN";

	public static final String FILENUM = "fileNum";
	public static final String MONTH = "month";
	public static final String YEAR = "year";
	public static final String SHARED_PATH = "sharedPath";
	public static final String OUTWARD = "outward";
	public static final String INWARD = "inward";
	public static final String REGISTER_TYPE = "registerType";

	final public static String GSP_USER = "eygspuser";

	final public static String GSP_CLIENT_ID = "eygspclientid";

	final public static String GSP_CLIENT_SECRET = "eygspclientsecret";
	public static final String RETSAVE = "RETSAVE";
	public static final String OTPREQUEST = "OTPREQUEST";
	public static final String AUTHTOKEN = "AUTHTOKEN";
	public static final String RETSUBMIT = "RETSUBMIT";

	public static final String RETDEL = "RETDEL";
	public static final String RETSTATUS = "RETSTATUS";
	public static final String GENERATE = "GENERATE";

	public static final String MAILHOST = "restapi.mail.host";

	public static final String ESIGN = "ESIGN";
	public static final String STATUS = "status";
	public static final String ACK_NUM = "Ack_num";
	public static final String EMAILID = "emailId";
	public static final String OTP = "otp";
	public static final String NEW_PASSWORD = "newPassword";
	public static final String RESET_PASSWORD_VALIDATION = "New password must be different from Current password.";
	public static final String CHOOSE_PASSWORD_VALIDATION = "New password and confirm password does not match";
	public static final String CURRENT_PASSWORD_VALIDATION = "Current password does not match";
	public static final String SUCCESS = "success";
	public static final String DB = "DB";
	public static final String INVALID_EMAILID = "Entered emailId is not registered";
	public static final String STATECD = "state-cd";
	public static final String USERNAME = "username";
	public static final String TXN = "txn";
	public static final String GET_INITIAL = "?";
	public static final String PARAM_OAUTH = "auth-token";
	public static final String PARAM_GSTIN = "gstin=";
	public static final String PARAM_MONTH = "month=";
	public static final String PARAM_YEAR = "year=";
	public static final String AMPERSAND = "&";
	public static final String RETSUM = "RETSUM";
	public static final String IP_USR = "ip-usr";
	public static final String SPACE = " ";
	public static final String UNDERSCORE = "_";
	public static final String MASTER_SCHEMA = "master";
	public static final String ETL_SCHEMA = "etl";
	public static final String DBO_SCHEMA = "dbo";
	public static final String CONFIG_SCHEMA = "config";
	public static final String GSTR1_SCHEMA = "gstr1";
	public static final String GSTR2_SCHEMA = "gstr2";
	public static final String GSTR2F_SCHEMA = "gstr2F";
	public static final String GSTR6F_SCHEMA = "gstr6F";
	public static final String GSTR2A_SCHEMA = "gstr2A";
	public static final String TRANS_SCHEMA = "trans";
	public static final String UPDATE_PASSWORD_FAILURE = "Password could not be updated as something went wrong!";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String CLIENT_ID = "clientid";
	public static final String CLIENT_SECRET = "client-secret";

	// logger related
	public static final String LOGGER_ENTERING = "Entering";
	public static final String LOGGER_EXITING = "Exiting";
	public static final String LOGGER_ERROR = "Error in";
	public static final String LOGGER_METHOD = "Method : ";
	public static final String STATUS_GSTR2_STG1 = "GSTR2_BR_STG1";

	// Status Related
	public static final String FREEZED = "FREEZED";
	public static final String SUBMITTED = "SUBMITTED";
	public static final String PENDING = "PENDING";
	public static final String PROCESSING = "PROCESSING";
	public static final String SAVED = "SAVED";

	// GSTR3
	public static final String CASHSUM = "CASHSUM";
	public static final String ITCSUM = "ITCSUM";
	public static final String RETDET = "RETDET";
	public static final String GSTR3 = "/gstr3";

	// Added for GSTR3 ledgers
	public static final String CASHDTL = "CASHDTL";
	public static final String ITCDTL = "ITCDTL";
	public static final String TAX = "TAX";
	public static final String UTLCSH = "UTLCSH";
	public static final String UTLITC = "UTLITC";

	// gstr1 data pipeline 2
	public static final String B2B = "B2B";
	public static final String B2BA = "B2BA";
	public static final String B2CS = "B2CS";
	public static final String B2CSA = "B2CSA";
	public static final String B2CL = "B2CL";
	public static final String B2CLA = "B2CLA";
	public static final String EXPA = "EXPA";
	public static final String B2BCLEA = "B2BCLEA";
	public static final String CDN = "CDNR";
	public static final String CDN_INV = "CDN";
	public static final String CDNA_INV = "CDNA";
	public static final String CDNA = "CDNRA";
	public static final String TDS = "TDS";
	public static final String TCS = "TCS";
	public static final String ISD = "ISD";
	public static final String BUS_RULE_ERROR = "BUS_RULE_ERROR";
	public final static String AT = "AT";
	public final static String ATA = "ATA";
	public static final String TXPD = "TXPD";
	public static final String INVOICE = "Invoice";
	public static final String ITEM = "item";
	public static final String ENTITY_GSTR2FB2B_InvoiceDetail = "Gstr2B2BInvoiceDetailsModel";
	public static final String ENTITY_GSTR2FB2BA_InvoiceDetail = "GSTR2FB2B_InvoiceDetail";
	public static final String ENTITY_GSTR2FCDN_InvoiceDetail = "GSTR2FCDN_InvoiceDetail";
	public static final String ENTITY_GSTR2FCDNA_InvoiceDetail = "GSTR2FCDNA_InvoiceDetail";
	public static final String ENTITY_GSTR2AB2B_InvoiceDetail = "GSTR2AB2BInvoiceDetail";
	public static final String ENTITY_GSTR2AB2B_ItemDetail = "GSTR2AB2BItemDetail";
	public static final String ENTITY_GSTR2ACDN_ItemDetail = "GSTR2ACDNItemDetail";
	public static final String ENTITY_GSTR2ACDN_InvoiceDetail = "GSTR2ACDNInvoiceDetail";
	public static final String ENTITY_GSTR2B2B_InvoiceDetail = "GSTR2B2B_InvoiceDetail";
	public static final String ENTITY_GSTR2B2BCLIA_InvoiceDetail = "GSTR2B2BCLIAInvoiceDetails";
	public static final String ENTITY_GSTR6TurnoverDetailsPriorFY = "GSTR6TurnoverDetailsPriorFY";


	// doc type
	public static final String INV = "INV";
	public static final String RNV = "RNV";
	public static final String CR = "CR";
	public static final String DR = "DR";
	public static final String RCR = "RCR";
	public static final String RDR = "RDR";
	public static final String RADV = "RADV";

	// redis template
	public static final String REDIS_HOST = "redis.host";
	public static final String REDIS_PORT = "redis.port";

	public static final String REDIS_POOL_MAX_ACTIVE = "redis.pool.maxActive";
	public static final String REDIS_POOL_MAX_IDLE = "redis.pool.maxIdle";
	public static final String REDIS_POOL_MAX_WAIT = "redis.pool.maxWait";
	public static final String REDIS_POOL_TEST_ON_BORROW = "redis.pool.testOnBorrow";

	public static final String REDIS_CACHE = "REDIS_CACHE";
	public static final String ERROR_MASTER_LIST = "ERROR_MASTER_LIST";
	public static final String GSTR1_BR_STG1 = "GSTR1_BR_STG1";
	public static final String GSTR1_BR_STG2 = "GSTR1_BR_STG2";
	public static final String IGST = "IGST";
	public static final String CGST_SGST = "CGST/SGST";
	public static final int CUTOFF_START_MONTH = Calendar.APRIL;
	public static final int CUTOFF_START_DATE = 1;
	public static final int CUTOFF_END_MONTH = Calendar.SEPTEMBER;
	public static final int CUTOFF_END_DATE = 30;
	public static final String GSTR9 = "GSTR9";
	public static final String GSTR_1 = "Gstr1";
	public static final String GSTR_3 = "Gstr3";
	public static final String GSTR_2 = "Gstr2";
	public static final String GSTR_6 = "Gstr6";
	public static final String GSTR_7 = "Gstr7";
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String DATE_FORMAT_MMM_YYYY = "MMM yyyy";

	public static final String ENTITY_KEY = "ENTITY_KEY";
	public static final String GSTR3_PROC_SCHEMA = "gstr3";
	public static final String GSTR3_PROC_NAME = "ledgerProcName";
	public static final String PROC_GSTR3_SAVE_ITCDATA = "uspGSTR3SaveITCData";
	public static final String PROC_GSTR3_SAVE_CASHDATA = "uspGSTR3SaveCash";
	public static final String PROC_GSTR3_SAVE_LIABDATA = "uspGSTR3SaveTaxLiability";
	public static final String PROC_GSTR3_CASHCREDIT_AUTOFILL = "USPCashCreditAutoFIll";
	public static final String PROC_GSTR3_CASH_SAVE_TRANSACTION = "uspSaveCashTransaction";
	// Needs to chage the name
	public static final String PROC_GSTR3_GET_LIABDATA = "USPGetgstr3LiabilityDetails";
	public static final String PROC_GSTR3_GET_CASHDATA = "uspGetCashBalance";
	public static final String PROC_GSTR3_GET_CASH_SUBMIT = "uspGetCashForSubmission";
	public static final String PROC_GSTR3_GET_ITCDATA = "uspGSTR3CashValidation";
	public static final String PROC_GSTR3_AUTO_FILL_ITC = "uspITCUtilizationAutofill";
	public static final String PROC_GSTR3_SAVE_ITC = "uspSaveITCTransaction";
	public static final String PROC_GSTR3_ITC_BALANCE = "uspGetITCBalance";
	public static final String PROC_GSTR3_SUBMIT_ITC = "uspGetITCForSubmission";

	public static final String INPUT_SIZE = "5";
	public static final String GSTIN_DEATILS = "GSTIN_DEATILS";

	public static final String KEY_GSTR2 = "gstr2";

	public static final String PROC_USPGETGSTINID = "uspGetGSTINID";
	public static final String PROC_USPOUTWARDSUPPLY = "uspOutwardSupplyCFODB";
	public static final String PROC_USPINWARDSUPPLY = "uspInwardSupplyCFODB";
	public static final int AMENDMENT_THRESHOLD = 0;

	// CFODashboard
	public static final String GSTIN_PERIOD1_CONTEXT = "CTX_PERIOD1_LVL";
	public static final String GSTIN_PERIOD2_CONTEXT = "CTX_PERIOD2_LVL";
	public static final String GSTIN_PERIOD3_CONTEXT = "CTX_PERIOD3_LVL";
	public static final String GSTIN_PERIOD4_CONTEXT = "CTX_PERIOD4_LVL";

	public static final int GSTIN_LENGTH = 15;
	public static final int GSTR1_START = 1;
	public static final int GSTR1_END = 10;
	public static final int GSTR2_START = 11;
	public static final int GSTR2_END = 15;
	public static final int GSTR3_START = 16;
	public static final int GSTR3_END = 20;

	public static final String COLOR_PENDING = "f5e427";
	public static final String COLOR_COMPLETED = "0e6a12";
	public static final String COLOR_DELAYED = "b0250e";

	public static final int CURRENY_VALUE = 5; // to convert in Lakhs
	public static final String GSTR2A = "GSTR2A";
	public static final String RECONSTATE = "DATA_RECEIVED";
	public static final String GSTR1_RETURN_TYPE = "gstr1";
	public static final String GSTR2_RETURN_TYPE = "gstr2";
	public static final String GSTIN_IDLIST = "GSTIN_IDLIST";

	public static final String UNKNOWN_ERROR = "UNKNOWN ERROR";

	public static final String GSTR1_Filing = "GSTR1";
	public static final String GSTR2_Filing = "GSTR2";
	public static final String GSTR7_Filing = "GSTR7";
	public static final String FILED = "FILED";
	public static final String LINE_ITEM = "Line-Item";
	public static final String LEDGER_BALANCE_PROC_NAME = "uspGetLedgerBalance";

	public static final String PROC_USPSALES_CHART = "UspSalesForDashBoard";
	public static final String PROC_USPPURCHASE_CHART = "UspPuchaseForDashBoard";

	public static final String MAILSTATUS_RETURNTYPE_GSTR1 = "GSTR1";
	public static final String MAILSTATUS_RETURNTYPE_GSTR2 = "GSTR2";
	public static final String MAILSTATUS_RETURNTYPE_GSTR2RECON = "GSTR2RECON";
	public static final int MAILSTATUS_EMAIL_RETRY_COUNT_ZERO = 0;

	public static final String STATUS_RECON_COMPLETE = "RECON_COMPLETE";
	public static final String STATUS_RECON_FAILED = "RECON_FAILED";
	public static final String FIELD_SEPERATOR = "|";

	public static final String FILING_RECORD_TYPE_PURCHASE_REGISTER = "PR";
	public static final String FILING_RECORD_TYPE_GSTR2A = "GSTR2A";
	public static final String FILING_RECORD_TYPE_GSTR2A_DONE = "GSTR2A_DONE";
	public static final String RECON_TYPE_ADDITIONAL = "ADD";
	public static final String RECON_TYPE_MISSING = "MIS";
	public static final String RECON_TYPE_MATCHED = "MAT";
	public static final String ENTITY_INWARD_MODEL = "InwardInvoiceModel";
	//public static final String GSTR3_UPDATE__GSTR3_SAVECASH_PROC= "uspGSTR3SaveCash_Summary_Json";
	public static final String GSTR6_SAVE_DETERMINATION = "uspGSTR6SaveDetermination";
	public static final String SAVE_DETERMINATION_SCHEMA = "dbo";

	public static final String Gstr2RCMTransactionSP = "uspGSTR2RCMTransactionReport";

	public static final String Gstr2RCMDetailedSP = "uspRCMDetailed";

	public static final String STATUS_ACCEPTED = "A";

	// Master Tables
	public static final char INFORMATION_CODE_MASTER_FLAG = 'I';
	public static final char ERROR_CODE_MASTER_FLAG = 'E';

	public static final String PROCESS_STATUS = "RECON";
	public static final String GSTR6 = "/gstr6";

	public static final String IS_VALID = "Valid";
	public static final String IS_INVALID = "Invalid";

	public static final String REK = "rek";
	public static final String DATA = "data";
	public static final String STATUS_CD = "status_cd";

	public static final String SESSION_KEY = "837ey46d-ooi9-12s3-lo90-19ijuys5";

	// FOR CFODASHBOARD
	public static final String OUTWARD_TYPE = "Sales";
	public static final String INWARD_TYPE = "Purchase";

	public static final String JOB_WORK = "JW";
	public static final String STOCK_TRANSFER = "STR";
	public static final String SEZ = "SEZ";
	public static final String SEZG = "SEZG";
	public static final String EXPORTS = "EXP";
	public static final String IMPORTS = "IMP";
	public static final String EXPORTS_OR_IMPORTS = "EXP-IMP";
	public static final String THIRDPARTY_SALES_OR_PURCHASE = "TP";
	public static final String NIL = "NIL";
	public static final String EXEMPT = "EXT";
	public static final String COMPOSITION_SCHEME = "COM";
	public static final String DEEMED_EXPORTS = "DXP";
	public static final String EXPORT_WITHOUT_PAYMENT = "EXPWT";

	public static final String TAXABLE = "TAXABLE";
	public static final String NON_TAXABLE = "NON-TAXABLE";

	public static final String GSTR1_BR_STG6 = "GSTR1_BR_STG6";

	public static final String KEY_GSTR6 = "gstr6";
	public static final String GSTR6_Filing = "GSTR2";
	public static final String MAILSTATUS_RETURNTYPE_GSTR6 = "GSTR6";

	public static final String SUPPLY_METADATA = "SUPPLY_METADATA";
	public static final String BUSINESS_RULE = "Business Rule";
	public static final String ORG_DOC_NO = "ORG_DOC_NO";
	public static final String IGST_AMOUNT = "IGST_AMT";
	public static final String CGST_AMOUNT = "CGST_AMT";
	public static final String SGST_AMOUNT = "SGST_AMT";
	public static final String CESS_AMOUNT = "CESS_AMT";
	public static final String CGSTIN = "CGSTIN";
	public static final String DOC_NO = "DOC_NO";
	public static final String DOC_DATE = "DOC_DATE";

	// for gstr6 recon
	public static final String ENTITY_GSTR6FB2B_InvoiceDetail = "GSTR6FB2BInvoiceDetailsModel";
	public static final String ENTITY_GSTR6FB2BA_InvoiceDetail = "GSTR6FB2BAInvoiceDetail";
	public static final String ENTITY_GSTR6FCDN_InvoiceDetail = "GSTR6FCDNInvoiceDetail";
	public static final String ENTITY_GSTR6FCDNA_InvoiceDetail = "GSTR6FCDNAInvoiceDetail";

	public static final String INVOICEKEY_DETAILS = "INVOICEKEY_DETAILS";

	public static final String DATA_FLOW_STAGES_RETURNTYPE_GSTR1 = "GSTR1";
	public static final String DATA_FLOW_STAGES_RETURNTYPE_GSTR2 = "GSTR2";
	public static final String DATA_FLOW_STAGES_BR_STAGE1 = "BR STAGE1";
	public static final String DATA_FLOW_STAGES_BIFURCATION = "BIFURCATE";
	public static final String FILE_BIFURCATION_FLAG = "BIF";

	public static final String SYSTEM_CODE_STATUS = "STATUS";
	public static final String SYSTEM_CODE_STATUS_PROCESSED = "Processed";
	public static final String SYSTEM_CODE_STATUS_FAILED = "Failed";
	public static final String DUPLICATE = "DUPLICATE";

	public static final String GSTR1_PROC_SCHEMA = "gstr1";
	public static final String GSTR1_ERROR_REPORT_PROC_NAME = "uspGSTR1ErrorReport";
	public static final String GSTR2_ERROR_REPORT_PROC_NAME = "uspGSTR2ErrorReport";
	public static final String GSTR6_ERROR_REPORT_PROC_NAME = "uspGSTR6ErrorReport";

	public static final String GSTR1_ERROR_REPORT = "GSTR1";
	public static final String GSTR2_ERROR_REPORT = "GSTR2";
	public static final String GSTR6_ERROR_REPORT = "GSTR6";
	public static final String PROCESS_TYPE = "PROCESSTYPE";
	public static final String FROM_TAXPERIOD = "fromTaxperiod";
	public static final String TO_TAXPERIOD = "toTaxperiod";
	public static final String GROUP = "GROUP";
	public static final String ENTITY = "ENTITY";
	public static final String CIRCLE = "CIRCLE";
	public static final String GSTIN_CODE = "GSTIN";
	public static final String SUB_DIVISION = "SUBDIVISION";
	public static final String PROFIT_CENTER = "PROFITCENTER";
	public static final String BUSINESS_UNIT = "BUSINESSUNIT";
	public static final String PLANT_CODE = "PLANTCODE";
	public static final String SAVESTATE = "INPROGRESS";
	public static final String PROCESSED = "PROCESSED";
	public static final String TRANSACTIONALDATA = "transactionalData";
	public static final String SAVE_PROC = "uspInvoiceLoadTracker";

	// Transaction ID Polling starts
	public static final String FILING_ID = "filingId";
	public static final String GSTN_STATUS = "gstnStatus";
	public static final String ERROR = "ER";
	public static final String ERRORSTATUS = "E";
	public static final String PROCESSED_ = "P";
	public static final String PROCESSED_WITH_ERROR = "PE";
	public static final String SUBMIT_P = "SubmitP";
	public static final String SAVED_P = "SAVED";
	public static final String SUBMIT_PE = "SubmitPE";
	public static final String SAVED_PE = "SAVE_ERROR";
	public static final String SUBMIT_E = "SubmitE";
	public static final String SAVED_E = "SAVE_ERROR";
	public static final String SAVED_REC = "SavedREC";
	public static final String SAVED_IP = "SavedIP";
	public static final String SUMMARY_STATUS = "SummaryStatus";
	public static final String IN_PROGRESS = "InProgress";
	// Transaction ID Polling ends

	public static final String ENTITY_GSTR6FB2B_InvoiceDetail_DR = "GSTR6FDRB2BInvoiceDetails";
	public static final String ENTITY_GSTR6FB2BA_InvoiceDetail_DR = "GSTR6FDRB2BAInvoiceDetail";
	public static final String ENTITY_GSTR6FCDN_InvoiceDetail_DR = "GSTR6FDRCDNInvoiceDetail";
	public static final String ENTITY_GSTR6FCDNA_InvoiceDetail_DR = "GSTR6FDRCDNAInvoiceDetail";
	public static final String FAILED = "Failed";

	public static final String SUMMARYSTATE = "SaveR";
	public static final String QUES_SAVE_FREQ_ID = "9";
	public static final String ANS_FREQ_ID_1 = "D";
	public static final String ANS_FREQ_ID_2 = "W";
	public static final String ANS_FREQ_ID_3 = "F";
	public static final String ANS_FREQ_ID_4 = "M";

	public static final String L1_ACCESS_LEVEL = "L1";
	public static final String L2_ACCESS_LEVEL = "L2";
	public static final String L3A_ACCESS_LEVEL = "L3A";
	public static final String L3B_ACCESS_LEVEL = "L3B";
	public static final String L4A_ACCESS_LEVEL = "L4A";
	public static final String L4B_ACCESS_LEVEL = "L4B";
	public static final String L4C_ACCESS_LEVEL = "L4C";
	public static final String L5_ACCESS_LEVEL = "L5";
	public static final String ACCESS_LEVEL = "accessLevel";
	public static final String ACCESS_VALUE = "accessValue";

	public static final String DOC_TYPE = "DOC_TYPE";
	public static final String SUPPLY_TYPE = "SUPPLY_TYPE";

	public static final String CATEGORY = "Category";
	public static final String SUB_CATEGORY = "SubCategory";
	public static final String GSTR1_RECTIFIED_REPORT = "GSTR1";
	public static final String GSTR1_RECTIFIED_REPORT_PROC_NAME = "";

	public static final String GSTIN_FINANCIAL_PERIOD = "April-June(2017)";
	public static final String PURCHASE_METADATA = "PURCHASE_METADATA";

	public static final String INVOICE_COUNT = "InvCount";
	public static final String INVOICE_STATUS = "InvStatus";
	public static final String INVOICE_ERROR_DETAILS = "InvError";
	public static final String INVOICE_PSD_COUNT = "InvPsdCount";
	public static final String PREV_INVOICE_PSD_COUNT = "PreviousInvPsdCount";
	public static final String zero = "0";
	public static final String Schema = "dbo";
	public static final String Gstr1RoutingProcName = "uspGstr1Routing";
	public static final String Gstr1RoutingChunkProcName = "uspGstr1RoutingChunk";
	public static final String Gstr2RoutingProcName = "uspGstr2Routing";
	public static final String Gstr2RoutingChunkProcName = "uspGstr2RoutingChunk";
	public static final String SEC_SUM = "SEC_SUM";
	public static final String INV_SUM = "INV_SUM";

	public static final String GSTR3B_SUMMARY_XML_START_TAG = "<Gstr3bSummary>";
	public static final String GSTR3B_SUMMARY_XML_END_TAG = "</Gstr3bSummary>";
	public static final String TAXPERIOD = "taxPeriod";
	public static final String SUBMIT_RECORD_TYPE_GSTR3B = "GSTR3B";
	public static final String RECORD_TYPE_GSTR3B_FILED = "FILED";
	public static final double ZERO_DOUBLE = 0.00;

	public static final String GSTR6_SCHEMA = "gstr6";
	public static final String GSTR6_INV_MAPPING_UPDATE_PROC_NAME = "";
	public static final String GSTR6_INVOICE_REPORT_PROC_NAME = "USPGetgstr6InvoicesForMapping";
	public static final String GSTR6_DOWNLOAD_DETSUMM_PROC_NAME = "uspgstr6DtSummaryDownload";
	public static final String SYSTEM_CODE_STATUS_ERROR = "Processed With Errors";

	//Please assign JDBC_BATCH_SIZE value from  hibernate.jdbc.batch_size property
	public static final int JDBC_BATCH_SIZE = 50;

	public static final int SQL_BATCH_SIZE = 5000;

	public static final String GSTR6_DETERMINATION_REPORT_PROC_NAME = "USPGetgstr6DeterminationInvoices";
	public static final String ERROR_REPORT = "ER";
	public static final String SAVED_ER = "SavedER";

	public static final String ERROR_MSG = "You have already exceeded the limit of Report Request. ";

	public static final String SUBMITTED_SMARTREPORT = "Submitted";
	public static final String GENERATE_SMARTREPORT = "Generated";
	public static final String NODATA_SMARTREPORT = "NoData";
	public static final String QUARTER1 = "April-June(2017)";

	public static final String RECTIFICATION_GSTR1 = "RECTIFIED_GSTR1";
	public static final String RECTIFICATION_GSTR2 = "RECTIFIED_GSTR2";
	public static final String RECTIFICATION_GSTR6 = "RECTIFIED_GSTR6";
	public static final String GSTR1_RECTIFICATION_REPORT_PROC_NAME = "uspGSTR1RectificationReport";
	public static final String GSTR2_RECTIFICATION_REPORT_PROC_NAME = "uspGSTR2RectificationReport";
	public static final String GSTR6_RECTIFICATION_REPORT_PROC_NAME = "uspGSTR2RectificationReport";
	public static final String NEW_STATUS = "NEW";
	public static final String TOKEN_RECEIVED = "TOKEN_RECEIVED";
	public static final String GSTR2A_BATCH_FAILED = "FAILED_BATCH";
	public static final String GSTR2_RECON_SP_SCHEMA = "dbo";
	public static final String GSTR2_RECON_SP = "UspGstr2Recon";
	public static final String GSTR6A_RECON_SP_SCHEMA = "dbo";
	public static final String GSTR6A_RECON_SP = "UspGstr6Recon";
	public static final String GSTR6RECON_JOB = "reconciliationProcessGstr6AJob";
	public static final String GSTR2_RECON_SP_INPUT_COUNT = "2";
	public static final String SCHEDULE_TENANT_SIMPLE_TRIGGER = "asp-scheduleTenantSimpleTrigger";
	public static final String FILEDETAIL_JOB = "getGstr2aFileDetailsFromGstnJob";
	public static final String JOB_TRIGGERED = "Success";
	public static final String BATCH_API_HOST = "asp-restbatchapi.host";
	public static final String GSTR2RECON_JOB = "reconciliationProcessGstr2Job";
	public static final String ReturnFilingId = "filingId";

	/*
	 * Recon report types
	 */
	public static final String MATCHED_REPORT = "MATCHED";
	public static final String MATCHED_ASP_REPORT = "MATCH-ASP";
	public static final String MIS_MATCHED_REPORT = "MIS-MATCH";
	public static final String ADDITIONAL_REPORT = "ADDITIONAL";
	public static final String MISSING_REPORT = "MISSING";

	public static final String RECON_INVOICE_MATCH_HEADER = "report.recon.matched.invoice";
	public static final String RECON_LINEITEM_MATCH_HEADER = "report.recon.matched.lineItem";
	public static final String RECON_INVOICE_MATCH_DROPDOWN = "report.recon.matched.dropdown";
	public static final String RECON_INVOICE_MATCH_DEFAULT = "report.recon.matched.defaultResp";

	public static final String RECON_INVOICE_MISMATCH_HEADER = "report.recon.misMatched.invoice";
	public static final String RECON_LINEITEM_MISMATCH_HEADER = "report.recon.misMatched.lineItem";
	public static final String RECON_INVOICE_MISMATCH_DROPDOWN = "report.recon.misMatched.dropdown";
	public static final String RECON_INVOICE_MISMATCH_DEFAULT = "report.recon.misMatched.defaultResp";

	public static final String RECON_INVOICE_ADDITIONAL_HEADER = "report.recon.additional.invoice";
	public static final String RECON_LINEITEM_ADDITIONAL_HEADER = "report.recon.additional.lineItem";
	public static final String RECON_INVOICE_ADDITIONAL_DROPDOWN = "report.recon.additional.dropdown";
	public static final String RECON_INVOICE_ADDITIONAL_DEFAULT = "report.recon.additional.defaultResp";

	public static final String RECON_INVOICE_MISSING_HEADER = "report.recon.missing.invoice";
	public static final String RECON_LINEITEM_MISSING_HEADER = "report.recon.missing.lineItem";
	public static final String RECON_INVOICE_MISSING_DROPDOWN = "report.recon.missing.dropdown";
	public static final String RECON_INVOICE_MISSING_DEFAULT = "report.recon.missing.defaultResp";

	public static final String RECON_INVOICE_MATCHASP_HEADER = "report.recon.matchedAsp.invoice";
	public static final String RECON_LINEITEM_MATCHASP_HEADER = "report.recon.matchedAsp.lineItem";
	public static final String RECON_INVOICE_MATCHASP_DROPDOWN = "report.recon.matchedAsp.dropdown";
	public static final String RECON_INVOICE_MATCHASP_DEFAULT = "report.recon.matchedAsp.defaultResp";

	public static final String RECON_MISSING = "";
	public static final String RECON_ADDITIONAL = "";
	public static final String RECON_MISMATCH = "";
	public static final String RECON_MATCH = "M";
	public static final String RECON_MATCH_ASP = "";
	public static final int RECON_DATE = 10;

	public static final String RECON_INVOICE_B2B = "report.reconB2B";

	public static final String FOLDER_STRUCT_RECON_REPORT = "folder.structure.recon.report";
	public static final String CREATED_DATE = "createdDt";

	public static final String INVOICE_TYPE = "invoiceType";
	public static final String GSTIN_ID = "gstin";

	public static final String GSTR2A_DUMP = "GSTR2A";
	public static final String GSTR2A_REPORT_PROC_NAME = "uspGSTR2AReport";
	public static final String GSTR2F_REPORT_PROC_NAME = "uspGSTR2FReport";
	// table constants
	public static final String TABLE_4_1_A = "T.4.1.A";
	public static final String TABLE_4_1_B = "T.4.1.B";
	public static final String TABLE_4_1_C = "T.4.1.C";
	public static final String TABLE_4_1_D = "T.4.1.D";

	public static final String TABLE_4_2_A = "T.4.2.A";
	public static final String TABLE_4_2_B = "T.4.2.B";
	public static final String TABLE_4_2_C = "T.4.2.C";

	public static final String TABLE_4_3_1_A = "T.4.3.1.A";
	public static final String TABLE_4_3_1_B = "T.4.3.1.B";
	public static final String TABLE_4_3_1_C = "T.4.3.1.C";

	public static final String TABLE_4_3_2_A = "T.4.3.2.A";
	public static final String TABLE_4_3_2_B = "T.4.3.2.B";

	public static final String TABLE_5_A_1 = "T.5.A.1";
	public static final String TABLE_5_A_2 = "T.5.A.2";

	public static final String TABLE_5_B_1 = "T.5.B.1";
	public static final String TABLE_5_B_2 = "T.5.B.2";

	public static final String TABLE_6_1_T_A = "T.6.1.T.A";
	public static final String TABLE_6_1_T_B = "T.6.1.T.B";
	public static final String TABLE_6_1_T_C = "T.6.1.T.C";
	public static final String TABLE_6_1_I_A = "T.6.1.I.A";
	public static final String TABLE_6_1_I_B = "T.6.1.I.B";
	public static final String TABLE_6_1_I_C = "T.6.1.I.C";

	public static final String TABLE_6_2_T_A = "T.6.2.T.A";
	public static final String TABLE_6_2_T_B = "T.6.2.T.B";
	public static final String TABLE_6_2_T_C = "T.6.2.T.C";
	public static final String TABLE_6_2_I_A = "T.6.2.I.A";
	public static final String TABLE_6_2_I_B = "T.6.2.I.B";
	public static final String TABLE_6_2_I_C = "T.6.2.I.C";

	public static final String TABLE_7_A = "T.7.A";
	public static final String TABLE_7_B = "T.7.B";
	public static final String TABLE_7_C = "T.7.C";
	public static final String TABLE_7_D = "T.7.D";
	public static final String TABLE_7_E = "T.7.E";
	public static final String TABLE_7_F = "T.7.F";
	public static final String TABLE_7_G = "T.7.G";
	public static final String TABLE_7_G_A = "T.7.G.A";
	public static final String TABLE_7_G_B = "T.7.G.B";

	public static final String TABLE_9_A = "T.9.A";
	public static final String TABLE_9_B = "T.9.B";

	public static final String TABLE_10_2 = "T.10.2";
	public static final String TABLE_10_3 = "T.10.3";
	public static final String TABLE_10_4 = "T.10.4";
	public static final String TABLE_10_5 = "T.10.5";
	public static final String TABLE_10_6 = "T.10.6";
	public static final String TABLE_10_7 = "T.10.7";
	public static final String TABLE_10_8 = "T.10.8";
	public static final String TABLE_10_9 = "T.10.9";

	public static final String TABLE_11 = "T11";

	public static final String TABLE_12_2 = "T.12.2";
	public static final String TABLE_12_3 = "T.12.3";
	public static final String TABLE_12_4 = "T.12.4";
	public static final String TABLE_12_5 = "T.12.5";
	public static final String TABLE_12_6 = "T.12.6";
	public static final String TABLE_12_7 = "T.12.7";
	public static final String TABLE_12_8 = "T.12.8";

	public static final String TABLE_13_1_P = "T.13.1.P";
	public static final String TABLE_13_1_D = "T.13.1.D";
	public static final String TABLE_13_2_P = "T.13.2.P";
	public static final String TABLE_13_2_D = "T.13.2.D";

	public static final String TABLE_15_2 = "T.15.2";
	public static final String TABLE_15_3 = "T.15.3";
	public static final String TABLE_15_4 = "T.15.4";
	public static final String TABLE_15_5 = "T.15.5";
	public static final String TABLE_15_6 = "T.15.6";
	public static final String TABLE_15_7 = "T.15.7";
	public static final String TABLE_15_8 = "T.15.8";

	public static final String TABLE_14_2 = "T.14.2";
	public static final String TABLE_14_3 = "T.14.3";
	public static final String TABLE_14_4 = "T.14.4";
	public static final String TABLE_14_5 = "T.14.5";
	public static final String TABLE_14_6 = "T.14.6";
	public static final String TABLE_14_7 = "T.14.7";

	public static final String TABLE_TYPE_4 = "T4";
	public static final String TABLE_TYPE_5 = "T5";
	public static final String TABLE_TYPE_6 = "T6";
	public static final String TABLE_6_1_T = "T.6.1.T";
	public static final String TABLE_6_1_I = "T.6.1.I";
	public static final String TABLE_6_2_T = "T.6.2.T";
	public static final String TABLE_6_2_I = "T.6.2.I";
	public static final String TABLE_TYPE_7 = "T7";
	public static final String TABLE_TYPE_9 = "T9";

	public static final String TABLE_TYPE_8 = "T8";
	public static final String TABLE_8_A = "T.8.A";
	public static final String TABLE_8_B = "T.8.B";
	public static final String TABLE_8_C = "T.8.C";
	public static final String TABLE_8_D = "T.8.D";

	public static final String TABLE_TYPE_10 = "T10";
	public static final String TABLE_TYPE_11 = "T11";
	public static final String TABLE_TYPE_12 = "T12";
	public static final String TABLE_TYPE_13 = "T13";
	public static final String TABLE_TYPE_14 = "T14";

	public static final String TABLE_TYPE_15 = "T15";

	public static final String TABLETYPE = "TableType";
	public static final String SUBGROUP = "SubGroup";
	public static final String RATE = "Rate";
	public static final String EGSIN = "eGSIN";
	public static final String TAXABLEVALUE = "TaxableValue";
	public static final String ISACTIVE = "IsActive";

	public static final String INTRST_LIAB_ITC_RVL_USR_TCODE = "51";
	public static final String INTRST_LIAB_LIAB_FWD_TCODE = "54";
	public static final String INTRST_LIAB_PYMT_TX_USR_TCODE = "55";

	public static final String TABLE_TYPE_3 = "T3";
	public static final String TABLE_3_1 = "T.3.1";
	public static final String TABLE_3_2 = "T.3.2";
	public static final String TABLE_3_3 = "T.3.3";
	public static final String TABLE_3_4 = "T.3.4";
	public static final String TABLE_3_5 = "T.3.5";
	public static final String TABLE_3_6 = "T.3.6";
	public static final String TABLE_3_7 = "T.3.7";
	public static final String TABLE_3_8 = "T.3.8";

	public static final String GENERATE_GSTR3 = "GENERATE";	
	public static final String TURNOVER ="turnover"; 


	public static final String INTEREST = "Interest";
	public static final String PENALTY = "Penalty";
	public static final String FEE = "Fee";
	public static final String OTHER = "Other";
	public static final String DEBITENTRYNUM = "DebitEntryNum";
	public static final String ACCOUNTNUMBER = "AccountNumber";
	public static final String CLAIMTYPE = "ClaimType";
	public static final String CLAIM_INTEGRATED = "igrfclm";
	public static final String CLAIM_CENTRAL = "cgrfclm";
	public static final String CLAIM_STATE = "sgrfclm";
	public static final String CLAIM_CESS = "csrfclm";
	public static final String RETUTN_TYPE = "returnType";
	public static final String RESET_GROUP = "tableType";
	public static final String PROC_USPADMINRESETCHUNK = "uspAdminResetChunk";
	public static final String FOUR = "4";
	public static final String DISTRIBUTION_TURNOVER_DATA = "dtTurnOverJson";
	public static final String[] FAILED_GSTR2A_URL_STATUS = {"NEW","Failed"};
	public static final Object TABLE_TYPE = "tableType";
	public static final Object TAX_PERIOD = "taxPeriod";
	public static final String EXP = "EXP";
	public static final String B2BCL = "B2BCL";
	public static final String HSN = "HSN";
	public static final String TXR = "TXR";
	public static final String TXI = "TXI";
	public static final String IS = "IS";
	public static final String ALL = "ALL";
	public static final String ITCRVRSL = "ITCRVRST";
	public static final String RECON = "RECON";
	public static final String FIVE = "5";
	public static final String CLIENT_IP = "ip-usr";
	public static final String CO_RELATION_ID = "co-relation-id";
	public static final String USER_PRINCIPAL = "user-principal";
	public static final String UNKNOWN_USER = "UNKNOWN_USER";
	public static final String REQUEST_TENANT_HEADER ="X-TENANT-ID";
	public static final String GSTR6_RECON_REPORT = "GSTR6_ReconReport_";

	// 1FF
	public static final String GSTR1FF_TOKEN_JOB = "gstr1fftokenjob";
	public static final String SMART_REPORT_RECORDS_SBMITTED_TO_GSTN = "RecordsSubmittedToGSTN";
	public static final String GSTR1FF = "GSTR1FF";
	public static final String FILING_RECORD_TYPE_GSTR1FF = "GSTR1FF";
	public static final String FILING_RECORD_TYPE_GSTR1FF_DONE = "GSTR1FF_DONE";
	public static final String DATA_RECEIVED = "DATA_RECEIVED";

	public static final String GSTR1FF_B2B= "GSTR1FF_B2B";
	public static final String GSTR1FF_B2BA= "GSTR1FF_B2BA";
	public static final String GSTR1FF_B2CL= "GSTR1FF_B2CL";
	public static final String GSTR1FF_B2CLA= "GSTR1FF_B2CLA";
	public static final String GSTR1FF_B2CS= "GSTR1FF_B2CS";
	public static final String GSTR1FF_B2CSA= "GSTR1FF_B2CSA";
	public static final String GSTR1FF_CDNR= "GSTR1FF_CDNR";
	public static final String GSTR1FF_CDNRA= "GSTR1FF_CDNRA";
	//public static final String GSTR1FF_Nil Rated Supplies
	public static final String GSTR1FF_EXP = "GSTR1FF_EXP";
	public static final String GSTR1FF_EXPA = "GSTR1FF_EXPA";
	public static final String GSTR1FF_AT = "GSTR1FF_AT";
	public static final String GSTR1FF_ATA = "GSTR1FF_ATA";
	public static final String GSTR1FF_TXP = "GSTR1FF_TXP";
	//public static final String GSTR1FF_HSN Summary details	

	//GSTR6A Recon Reports Properties

	public static final String RECON_INVOICE_ADDITIONAL_HEADER_6A = "report.recon.additional.invoice.gstr6a";
	public static final String RECON_LINEITEM_ADDITIONAL_HEADER_6A = "report.recon.additional.lineItem.gstr6a";
	public static final String RECON_INVOICE_ADDITIONAL_DROPDOWN_6A = "report.recon.additional.dropdown.gstr6a";
	public static final String RECON_INVOICE_ADDITIONAL_DEFAULT_6A = "report.recon.additional.defaultResp.gstr6a";

	public static final String RECON_INVOICE_MISSING_HEADER_6A = "report.recon.missing.invoice.gstr6a";
	public static final String RECON_LINEITEM_MISSING_HEADER_6A = "report.recon.missing.lineItem.gstr6a";
	public static final String RECON_INVOICE_MISSING_DROPDOWN_6A = "report.recon.missing.dropdown.gstr6a";
	public static final String RECON_INVOICE_MISSING_DEFAULT_6A = "report.recon.missing.defaultResp.gstr6a";

	public static final String RECON_INVOICE_MATCH_HEADER_6A = "report.recon.matched.invoice.gstr6a";
	public static final String RECON_LINEITEM_MATCH_HEADER_6A = "report.recon.matched.lineItem.gstr6a";
	public static final String RECON_INVOICE_MATCH_DROPDOWN_6A = "report.recon.matched.dropdown.gstr6a";
	public static final String RECON_INVOICE_MATCH_DEFAULT_6A = "report.recon.matched.defaultResp.gstr6a";

	public static final String RECON_INVOICE_MISMATCH_HEADER_6A = "report.recon.misMatched.invoice.gstr6a";
	public static final String RECON_LINEITEM_MISMATCH_HEADER_6A = "report.recon.misMatched.lineItem.gstr6a";
	public static final String RECON_INVOICE_MISMATCH_DROPDOWN_6A = "report.recon.misMatched.dropdown.gstr6a";
	public static final String RECON_INVOICE_MISMATCH_DEFAULT_6A = "report.recon.misMatched.defaultResp.gstr6a";

	public static final String RECON_INVOICE_MATCHASP_HEADER_6A = "report.recon.matchedAsp.invoice.gstr6a";
	public static final String RECON_LINEITEM_MATCHASP_HEADER_6A = "report.recon.matchedAsp.lineItem.gstr6a";
	public static final String RECON_INVOICE_MATCHASP_DROPDOWN_6A = "report.recon.matchedAsp.dropdown.gstr6a";
	public static final String RECON_INVOICE_MATCHASP_DEFAULT_6A = "report.recon.matchedAsp.defaultResp.gstr6a";

	public static final String GSTR1_COUNTER_PARTY_REPORT_PROC_NAME = "uspGSTR1CounterPartySummary";
	public static final String GSTR2_COUNTER_PARTY_REPORT_PROC_NAME = "uspGSTR2CounterPartySummary";
}