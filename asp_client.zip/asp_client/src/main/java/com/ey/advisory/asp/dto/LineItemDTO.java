package com.ey.advisory.asp.dto;

import java.io.Serializable;

public class LineItemDTO implements Serializable{
	
	private Long Id;
	private Double itcCgstAmt;
	private Double itcSgstAmt;
	private Double itcIgstAmt;
	private Double itcCessAmt;
	private Double iGSTAmount;
	private Double cGSTAmount;
	private Double sGSTAmount;
	private String tableType;
	private Integer lineNo;
	
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public Double getItcCgstAmt() {
		return itcCgstAmt;
	}
	public void setItcCgstAmt(Double itcCgstAmt) {
		this.itcCgstAmt = itcCgstAmt;
	}
	public Double getItcSgstAmt() {
		return itcSgstAmt;
	}
	public void setItcSgstAmt(Double itcSgstAmt) {
		this.itcSgstAmt = itcSgstAmt;
	}
	public Double getItcIgstAmt() {
		return itcIgstAmt;
	}
	public void setItcIgstAmt(Double itcIgstAmt) {
		this.itcIgstAmt = itcIgstAmt;
	}
	public Double getItcCessAmt() {
		return itcCessAmt;
	}
	public void setItcCessAmt(Double itcCessAmt) {
		this.itcCessAmt = itcCessAmt;
	}
	public String getTableType() {
		return tableType;
	}
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	public Integer getLineNo() {
		return lineNo;
	}
	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}
	public Double getiGSTAmount() {
		return iGSTAmount;
	}
	public void setiGSTAmount(Double iGSTAmount) {
		this.iGSTAmount = iGSTAmount;
	}
	public Double getcGSTAmount() {
		return cGSTAmount;
	}
	public void setcGSTAmount(Double cGSTAmount) {
		this.cGSTAmount = cGSTAmount;
	}
	public Double getsGSTAmount() {
		return sGSTAmount;
	}
	public void setsGSTAmount(Double sGSTAmount) {
		this.sGSTAmount = sGSTAmount;
	}
	
}
