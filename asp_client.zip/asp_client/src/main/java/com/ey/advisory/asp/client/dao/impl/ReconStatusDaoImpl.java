package com.ey.advisory.asp.client.dao.impl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.ReconStatusDao;
import com.ey.advisory.asp.client.domain.ReconStatus;
import com.ey.advisory.asp.client.service.gstr2.GSTR2AServiceImpl;
import com.ey.advisory.asp.common.Constant;

@Repository
public class ReconStatusDaoImpl implements ReconStatusDao {

	private static final Logger LOGGER = Logger.getLogger(ReconStatusDaoImpl.class);
	
	@Autowired
	HibernateDao hibernateDao;

	@Override
	public ReconStatus getReconStatus(String gstin, String taxPeriod,Integer masterId) {
		List<ReconStatus> reconStatusList = null;
		Criteria criteria = hibernateDao.createNormalCriteria(ReconStatus.class);
		criteria.add(Restrictions.eq("gstin", gstin));
		criteria.add(Restrictions.eq("taxPeriod", taxPeriod));
		criteria.add(Restrictions.eq("isActive", true));
		criteria.add(Restrictions.eq("masterId", masterId));
		reconStatusList = criteria.list();
		if (reconStatusList != null && reconStatusList.size() > 0) {
			return reconStatusList.get(0);
		}
		return null;
	}

	/**
	 * This method is to get the matched recon records.
	 * 
	 */
	@Override
	public String getMatchedReconRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("Start of getMatchedReconRecords");
		
		String jsonResponse = null;

		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetReconMatchRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getMatchedReconRecords");
		
		return jsonResponse;
		 
	}

	/**
	 * This method is to get the ASP matched recon records.
	 * 
	 */
	@Override
	public String getMatchedAspReconRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("Start of getMatchedAspReconRecords");
		
		String jsonResponse = null;

		
		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetReconMatchedASPRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getMatchedAspReconRecords");
		return jsonResponse;
	}

	/**
	 * This method is to get the mis matched recon records.
	 * 
	 */
	@Override
	public String getMisMatchedReconRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("Start of getMisMatchedReconRecords");
		
		String jsonResponse = null;

		
		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetReconMissmatchRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getMisMatchedReconRecords");
		return jsonResponse;
	}

	/**
	 * This method is to get the additional recon records.
	 * 
	 */
	@Override
	public String getAdditionalReconRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("Start of getAdditionalReconRecords");
		
		String jsonResponse = null;

		
		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetReconAdditionalRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getAdditionalReconRecords");
		return jsonResponse;
		 
	}

	/**
	 * This method is to get the recon missing records.
	 * 
	 */
	@Override
	public String getReconMissingRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("End of getReconMissingRecords");
		
		String jsonResponse = null;

		
		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetReconMissingRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getReconMissingRecords");
		
		return jsonResponse;
	}

	@SuppressWarnings("null")
	@Override
	public void saveReconStatus(String gstin, String taxPeriod, Integer masterId) {
		LOGGER.info("Start of saveReconStatus in client");
		ReconStatus reconStatus = null;
		try{
			reconStatus = new ReconStatus();
			reconStatus.setGstin(gstin);
			reconStatus.setTaxPeriod(taxPeriod);
			reconStatus.setMasterId(masterId);
			reconStatus.setReconStatus("ReconInitiated");
			reconStatus.setCreatedDate(new Date());
			reconStatus.setIsActive(true);
			reconStatus.setIsAdditionalGenerated(Constant.IN_PROGRESS);
			reconStatus.setIsMatchedASPGenerated(Constant.IN_PROGRESS);
			reconStatus.setIsMatchedGenerated(Constant.IN_PROGRESS);
			reconStatus.setIsMisMatchedGenerated(Constant.IN_PROGRESS);
			reconStatus.setIsMissingGenerated(Constant.IN_PROGRESS);
			hibernateDao.save(reconStatus);
			LOGGER.info("End of saveReconStatus in client");
		}catch(Exception e){
			LOGGER.info("Exception in saveReconStatus in client "+e);
		}
	}

	@Override
	public void updateReconStatus(String gstin, String taxPeriod,Integer masterId) {
		LOGGER.info("Start of updateReconStatus in client");
		ReconStatus reconStatus = null;
		try{
			reconStatus = getReconStatus(gstin,taxPeriod,masterId);
			if(reconStatus != null){
				reconStatus.setIsActive(false);
				hibernateDao.update(reconStatus);
			}
			LOGGER.info("End of updateReconStatus in client");
		}catch(Exception e){
			LOGGER.info("Exception  in updateReconStatus in client "+e);
		}
	}

	@Override
	public ReconStatus getActiveReconStatus(String gstin, String taxPeriod) {
		List<ReconStatus> reconStatusList = null;
		Criteria criteria = hibernateDao.createNormalCriteria(ReconStatus.class);
		criteria.add(Restrictions.eq("gstin", gstin));
		criteria.add(Restrictions.eq("taxPeriod", taxPeriod));
		criteria.add(Restrictions.eq("isActive", true));
		reconStatusList = criteria.list();
		if (reconStatusList != null && reconStatusList.size() > 0) {
			return reconStatusList.get(0);
		}
		return null;
	}

	@Override
	public ReconStatus getReconStatus(String gstin, String taxPeriod) {
		List<ReconStatus> reconStatusList = null;
		Criteria criteria = hibernateDao.createNormalCriteria(ReconStatus.class);
		criteria.add(Restrictions.eq("gstin", gstin));
		criteria.add(Restrictions.eq("taxPeriod", taxPeriod));
		criteria.add(Restrictions.eq("isActive", true));
		reconStatusList = criteria.list();
		if (reconStatusList != null && reconStatusList.size() > 0) {
			return reconStatusList.get(0);
		}
		return null;
	}
	
	@Override
	public void updateReconReportStatus(String gstin, String taxPeriod,String reportType, String status) {
		LOGGER.info("Start of updateReconReportStatus in client");
		ReconStatus reconStatus = null;
		try{
			reconStatus = getReconStatus(gstin,taxPeriod);
			if(reconStatus != null){
				
				if(reportType.equalsIgnoreCase(Constant.MISSING_REPORT)){
					
					reconStatus.setIsMissingGenerated(status);	
				}
				
				else if(reportType.equalsIgnoreCase(Constant.MATCHED_REPORT)){
					
					reconStatus.setIsMatchedGenerated(status);	
				}
				
				else if(reportType.equalsIgnoreCase(Constant.MIS_MATCHED_REPORT)){
					
					reconStatus.setIsMisMatchedGenerated(status);	
				}
				
				else if(reportType.equalsIgnoreCase(Constant.MATCHED_ASP_REPORT)){
					
					reconStatus.setIsMatchedASPGenerated(status);	
				}
				else if(reportType.equalsIgnoreCase(Constant.ADDITIONAL_REPORT)){
					
					reconStatus.setIsAdditionalGenerated(status);	
				}
				
				hibernateDao.update(reconStatus);
			}
			LOGGER.info("End of updateReconReportStatus in client");
		}catch(Exception e){
			LOGGER.info("Exception  in updateReconReportStatus in client "+e);
		}
	}
	
	@Override
	public ReconStatus getReconReportStatus(String gstin, String taxPeriod) {
		List<ReconStatus> reconStatusList = null;
		Criteria criteria = hibernateDao.createNormalCriteria(ReconStatus.class);
		criteria.add(Restrictions.eq("gstin", gstin));
		criteria.add(Restrictions.eq("taxPeriod", taxPeriod));
		criteria.add(Restrictions.eq("isActive", true));
		reconStatusList = criteria.list();
		if (reconStatusList != null && reconStatusList.size() > 0) {
			return reconStatusList.get(0);
		}
		return null;
	}
	
	@Override
	public void updateReconCompletedDate(String gstin, String taxPeriod,
			Integer masterId) {
			LOGGER.info("Start of updateReconCompletedDate in client");
			ReconStatus reconStatus = null;
			try{
				reconStatus = getReconStatus(gstin,taxPeriod,masterId);
				if(reconStatus != null){
					Date now = new Date(); 
		        	Timestamp ts = new Timestamp(now.getTime());
					reconStatus.setReconCompleteDate(ts);
					hibernateDao.update(reconStatus);
				}
				LOGGER.info("End of updateReconCompletedDate in client");
			}catch(Exception e){
				LOGGER.info("Exception  in updateReconCompletedDate in client "+e);
			}
		
	}

	@Override
	public void updateReconStatus(String gstin, String taxPeriod,
			Integer masterId, String status) {
		LOGGER.info("Start of updateReconcilationStatus in client");
		ReconStatus reconStatus = null;
		try{
			reconStatus = getReconStatus(gstin,taxPeriod,masterId);
			if(reconStatus != null){
				reconStatus.setReconStatus(status);
				
				if(status.equalsIgnoreCase("RECON_FAILED")){
					
					reconStatus.setIsAdditionalGenerated("Error");
					reconStatus.setIsMatchedASPGenerated("Error");
					reconStatus.setIsMatchedGenerated("Error");
					reconStatus.setIsMisMatchedGenerated("Error");
					reconStatus.setIsMissingGenerated("Error");
				}
				hibernateDao.update(reconStatus);
			}
			LOGGER.info("End of updateReconcilationStatus in client");
		}catch(Exception e){
			LOGGER.info("Exception  in updateReconcilationStatus in client "+e);
		}
	}

}
