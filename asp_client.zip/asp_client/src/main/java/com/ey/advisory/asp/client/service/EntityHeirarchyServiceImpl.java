package com.ey.advisory.asp.client.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.EntityHeirarchyDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.dto.CommonSearchDto;
import com.ey.advisory.asp.client.dto.ResultPage;
import com.ey.advisory.asp.common.Constant;

@Service
@Transactional
public class EntityHeirarchyServiceImpl implements EntityHeirarchyService {

	@Autowired
	EntityHeirarchyDao entityHeirarchyDao;
	
	@Autowired
	HibernateDao hibernateDao;
	
	private static final Logger logger = Logger.getLogger(EntityHeirarchyServiceImpl.class);
	private static final String CLASS_NAME = EntityHeirarchyServiceImpl.class.getName();
	

	@SuppressWarnings("unchecked")
	@Override
	public List<EntityHierarchy> getEntityNames(String groupId) {
		if (logger.isInfoEnabled())
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " getEntityNames()");

		List<EntityHierarchy> entities = null;
		try {
			entities = entityHeirarchyDao.getEntityNames(groupId);

		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getEntityNames()", e);
		}
		if (logger.isInfoEnabled()) {
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD + " getEntityNames()");
		}
		return entities;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void saveEntityHierarchy(EntityHierarchy entityHierarchy) throws Exception{
		if(logger.isInfoEnabled())
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
	            +Constant.LOGGER_METHOD+" saveEntityHierarchy()");
		
		try {
			EntityModel entityModel = hibernateDao.load(EntityModel.class, entityHierarchy.getEntityID());
			entityHierarchy.setEntityName(entityModel.getEntityName());
			entityHierarchy.setEntityCode(entityModel.getEntityCode());
			entityHierarchy.setIsActive("1");
			entityHierarchy.setCreatedDate(new Date());
			entityHierarchy.setCreatedBy(entityHierarchy.getCreatedBy());
			hibernateDao.save(entityHierarchy);
		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
	                +Constant.LOGGER_METHOD+" getEntityNames()" , e);
			throw new Exception(e.getMessage());
		}
		if(logger.isInfoEnabled()){
		 logger.info(Constant.LOGGER_EXITING + CLASS_NAME
		            +Constant.LOGGER_METHOD+" saveEntityHierarchy()");
		}
	}
	
	@Override
	public List<Object[]> fetchHierarchyList(Long groupId) {
		
		logger.info("Entered fetchHierarchyList");
		List<Object[]> resultList = null;
		try {
			 
			 DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
			 detachedCriteria.add(Restrictions.eq("groupID", groupId));
				detachedCriteria.setProjection(Projections.distinct(Projections.projectionList()
				        .add(Projections.property("entityID"))
				        .add(Projections.property("entityName"))));
			 
			 resultList = (List<Object[]>)hibernateDao.find(detachedCriteria);
			 if(resultList!=null && !resultList.isEmpty())
			 {
				 
				 return resultList;
			 }
		}catch(Exception e){
			logger.error("Exception in fetchHierarchyList "+e);
		}
		return null;
	}
	
	@Override
	public ResultPage<EntityHierarchy> fetchHierarchyListPagination(CommonSearchDto searchDto){
		ResultPage<EntityHierarchy> entities = null;
		try {
			entities = entityHeirarchyDao.fetchHierarchyListPagination(searchDto);
		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " fetchHierarchyListPagination()", e);
		}
		if (logger.isInfoEnabled()) {
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD + " fetchHierarchyListPagination()");
		}
		return entities;
	}

	@Override
	public void deleteEntityHierarchy(String hierarchyId) throws Exception{
		logger.info("Entered deleteEntityHierarchy");
		try{
			EntityHierarchy entityHierarchy= hibernateDao.load(EntityHierarchy.class, Integer.parseInt(hierarchyId));
			entityHierarchy.setIsActive("0");
			entityHierarchy.setUpdatedDate(new Date());
			hibernateDao.merge(entityHierarchy);
		}catch(Exception e){
			logger.error("Exception in deleteEntityHierarchy"+e);
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public EntityHierarchy updateEntityHierarchy(EntityHierarchy entityHierarchyDTO) throws Exception{
		logger.info("Entered updateEntityHierarchy");
		EntityHierarchy entityHierarchyOld = new EntityHierarchy();
		try{
			EntityHierarchy entityHierarchy= hibernateDao.load(EntityHierarchy.class, entityHierarchyDTO.getHierarchyId());
			entityHierarchy.setIsActive("1");
			
			/********Reading old values*************/
			entityHierarchyOld.setBusinessUnitCode(entityHierarchy.getBusinessUnitCode());
			entityHierarchyOld.setCircleCode(entityHierarchy.getCircleCode());
			entityHierarchyOld.setPlantCode(entityHierarchy.getPlantCode());
			entityHierarchyOld.setProfitCenterCode(entityHierarchy.getProfitCenterCode());
			entityHierarchyOld.setSubDivCode(entityHierarchy.getSubDivCode());
			/*****************done**********/
			
			entityHierarchy.setBusinessUnitName(entityHierarchyDTO.getBusinessUnitName());
			entityHierarchy.setCircleName(entityHierarchyDTO.getCircleName());
			entityHierarchy.setPlantCode(entityHierarchyDTO.getPlantCode());
			entityHierarchy.setProfitCenterName(entityHierarchyDTO.getProfitCenterName());
			entityHierarchy.setSubDivName(entityHierarchyDTO.getSubDivName());
			entityHierarchy.setUpdatedDate(new Date());
			entityHierarchy.setUpdatedBy(entityHierarchyDTO.getUpdatedBy());
			hibernateDao.merge(entityHierarchy);
			
			
		}catch(Exception e){
			logger.error("Exception in updateEntityHierarchy"+e);
			throw new Exception(e.getMessage());
		}
		
		return entityHierarchyOld;

	}
	
	
	
	@Override
	public Boolean checkIfDuplicateEntryExists(EntityHierarchy entityHierarchyDTO) throws Exception{
		logger.info("Entered checkIfDuplicateEntryExists");
		Boolean alreadyExists=false;
		try{
			alreadyExists = entityHeirarchyDao.checkIfDuplicateEntryExists(entityHierarchyDTO);
			
		}catch(Exception e){
			logger.error("Exception in updateEntityHierarchy"+e);
			throw new Exception(e.getMessage());
		}
		return alreadyExists;
	}
	
	
	@Override
	public EntityHierarchy loadEntityH(Integer id){
		EntityHierarchy eh = (EntityHierarchy) hibernateDao.get(EntityHierarchy.class.getName(), id);//.load(EntityHierarchy.class, id);
		return eh;
	}

	@Override
	public List fetchGstinList(String entityId) {
		List gstinList = entityHeirarchyDao.fetchGstinList(entityId);
		return gstinList;
	}
	
	
	@Override
	public List<EntityHierarchy> fetchEntityHierarchyList(String entityCode) throws Exception {
		List hierarchyList = entityHeirarchyDao.fetchEntityHierarchyList(entityCode);
		return hierarchyList;
	}

	@Override
	public List<EntityHierarchy> fetchByGSTIN(String gstin) {
		return entityHeirarchyDao.fetchByGSTIN(gstin);
	}
	
	@Override
	public List<EntityHierarchy> fetchUserHierarchy(String accessLevel,String property, Object Value){
		
		return entityHeirarchyDao.fetchUserHierarchy(accessLevel, property, Value);
		
	}

	@Override
	public ResultPage<EntityHierarchy> fetchByHierarchyIdList(Map<Integer,String> hierarchyMap,
			CommonSearchDto commonSearchDto) throws Exception {
		return entityHeirarchyDao.fetchByHierarchyIdList(hierarchyMap,commonSearchDto);
	}
	
	@Override
	public List<EntityHierarchy> fetchValues(String txt, String values){
		return entityHeirarchyDao.fetchValues(txt, values);
	}
		
	@Override
	public List<EntityHierarchy> fetchUserHierarchyUserTab(Integer accessLevelId,String accessLevel,String property, Object Value){
		
		return entityHeirarchyDao.fetchUserHierarchyUserTab( accessLevelId, accessLevel, property, Value);
		
	}

	@Override
	public List<EntityHierarchy> getGstinsByEntityId(String entityCode) {
		return entityHeirarchyDao.getGstinsByEntityId(entityCode);
	}

	@Override
	public List<EntityHierarchy> getGstinsByGroupCode(String groupCode) {
		return entityHeirarchyDao.getGstinsByGroupCode(groupCode);
	}

	@Override
	public List<EntityHierarchy> getEntityHierarchyByEntityID(Integer entityID) {
		
		return entityHeirarchyDao.getEntityHierarchyByEntityID(entityID);
	}

	@Override
	public List<EntityHierarchy> getEntityHierarchyByCircleCode(String circleCode) {
		return entityHeirarchyDao.getEntityHierarchyByCircleCode(circleCode);
	}
}
