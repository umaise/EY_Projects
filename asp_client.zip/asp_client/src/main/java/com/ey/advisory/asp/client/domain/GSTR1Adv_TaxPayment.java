package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;


/**
 * The persistent class for the GSTR1Adv_TaxPayment database table.
 * 
 */
@Entity
@Table(name = "tblAdvTaxPayment",schema=Constant.GSTR1_SCHEMA)
public class GSTR1Adv_TaxPayment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private long GSTR1Adv_TaxPayment_ID;

	@Column(name="AdvAmt")
	private Double adv_Amt;

	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="CustGSTIN")
	private String cust_GSTIN;

	@Column(name="CustName")
	private String cust_Name;

	@Column(name="DocDate")
	private String doc_Date;

	@Column(name="DocNum")
	private String doc_Num;

	@Column(name="Flag")
	private String flag;

	@Column(name="RecpStateCD")
	private String recp_StateCD;

	@Column(name="Taxablevalue")
	private Double taxableValue;

	@Column(name="FileID")
	private long fileId;
	
	@Column(name="TransIdAdv")
	private String transId;
	
	@Column(name="IsDelete")
	private Boolean isDelete;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="Gstin")
	private String gstin;
	
	public long getGSTR1Adv_TaxPayment_ID() {
		return this.GSTR1Adv_TaxPayment_ID;
	}

	public void setGSTR1Adv_TaxPayment_ID(long GSTR1Adv_TaxPayment_ID) {
		this.GSTR1Adv_TaxPayment_ID = GSTR1Adv_TaxPayment_ID;
	}

	public Double getAdv_Amt() {
		return this.adv_Amt;
	}

	public void setAdv_Amt(Double adv_Amt) {
		this.adv_Amt = adv_Amt;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getCust_GSTIN() {
		return this.cust_GSTIN;
	}

	public void setCust_GSTIN(String cust_GSTIN) {
		this.cust_GSTIN = cust_GSTIN;
	}

	public String getCust_Name() {
		return this.cust_Name;
	}

	public void setCust_Name(String cust_Name) {
		this.cust_Name = cust_Name;
	}

	public String getDoc_Date() {
		return this.doc_Date;
	}

	public void setDoc_Date(String doc_Date) {
		this.doc_Date = doc_Date;
	}

	public String getDoc_Num() {
		return this.doc_Num;
	}

	public void setDoc_Num(String doc_Num) {
		this.doc_Num = doc_Num;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getRecp_StateCD() {
		return this.recp_StateCD;
	}

	public void setRecp_StateCDE(String recp_StateCDE) {
		this.recp_StateCD = recp_StateCDE;
	}

	public Double getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public Boolean getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Boolean isDelete) {
		this.isDelete = isDelete;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public void setRecp_StateCD(String recp_StateCD) {
		this.recp_StateCD = recp_StateCD;
	}

}