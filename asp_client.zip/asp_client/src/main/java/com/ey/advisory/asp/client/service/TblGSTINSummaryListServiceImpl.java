package com.ey.advisory.asp.client.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.TblGSTINSummaryListDao;
import com.ey.advisory.asp.client.domain.TblGSTINSummaryList;


@Service
@Transactional
public class TblGSTINSummaryListServiceImpl implements TblGSTINSummaryListService{

	
	@Autowired
	TblGSTINSummaryListDao tblGSTINSummaryListDao;
	private static final Logger logger = Logger.getLogger(TblGSTINSummaryListServiceImpl.class);
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#getGstinRtType(java.util.List)
	 * get the gstin based on entity level
	 */
	@Override
	public List<TblGSTINSummaryList> getGstinRtSummaryType(List<Integer> fileIdList) {
		 logger.info("*********** entering method getGstinRtSummaryType " + fileIdList.toString());
		List<TblGSTINSummaryList> tblGSTINSummaryList = null;
		try
		{
			tblGSTINSummaryList=tblGSTINSummaryListDao.getGstinRtSummaryType(fileIdList);
			
		}
		catch(Exception ex)
		{
			logger.error("*********** ERROR in Job getGstinRtSummaryType *********** ",ex);
		}
		return tblGSTINSummaryList;
	}
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#insertUpdateGstr12FilingStatus(java.util.List)
	 * insert or update records in tblGstinRetutnFilingStatus table
	 */
	@Override
    public String insertUpdateGstr12SummaryStatus(List<TblGSTINSummaryList> gstinList) {
         logger.info("*********** entering Job insertUpdateGstr12SummaryStatus " + gstinList);
  
        try{
        	tblGSTINSummaryListDao.insertUpdateGstr12SummaryStatus(gstinList);
   
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job insertUpdateGstr12SummaryStatus ",e);
		} 
         return "Success";
    }

	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#updateGstinList(com.ey.advisory.asp.client.domain.TblGSTINList)
	 * Update the Status of GSTIN after sending to NodeJs
	 */
	@Override
	public void updateGstinSummaryList(TblGSTINSummaryList gstinData) {
		 logger.info("*********** entering method updateGstinSummaryList " + gstinData);
		 try{
			 tblGSTINSummaryListDao.updateGstinSummaryList(gstinData);
			 }
		 catch(Exception ex){
			 logger.error("*********** ERROR in method updateGstinSummaryList ",ex);
		 }
	}

}
