package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

@SuppressWarnings("serial")
@Entity
@Table(name="tblB2BInvoiceDetails", schema="gstr6F")
public class GSTR6FB2BInvoiceDetailsModel implements Serializable{
    
    @Id
    @Column(name="ID")
    private Long invoiceDetailsId;
    
    @Column(name="CustGSTIN")
    private String cust_GSTIN;

    @Column(name="InvDate")
    private Date doc_Date;

    @Column(name="InvNum")
    private String doc_Num;
    
    @Column(name="POS")
    private String placeOfSupply;
    
    @Column(name="RevChrg")
    private String reverseCharge;
    
    @Column(name="Status")
    private String status;
    
    @Column(name="IsAccepted")
    private Integer isAccepted;
    
    @Column(name="Gstin")
    private String gstin;
    
    @Column(name="TaxPeriod")
    private String taxPeriod;
    
    @Column(name="FilingStatus")
    private String filingStatus;

    
    
    @Column(name="ClientResponse")
    private String clientResponse;
    
    @Column(name="DrAvailability")
    private String drAvailability;
    
    @OneToMany(cascade = CascadeType.REFRESH, mappedBy="gstr6FB2BItemDetailsPK.invoiceDetails", fetch = FetchType.EAGER)
    @OrderBy("gstr6FB2BItemDetailsPK.lineNo")
    private Set<GSTR6FB2BItemDetailsModel> itemDetails = new HashSet<>();
    
    @Transient
    private Set<TblIsdErrorInfo> errorInfo = new HashSet<>();

    public Long getInvoiceDetailsId() {
        return invoiceDetailsId;
    }

    public void setInvoiceDetailsId(Long invoiceDetailsId) {
        this.invoiceDetailsId = invoiceDetailsId;
    }

    public String getCust_GSTIN() {
        return cust_GSTIN;
    }

    public void setCust_GSTIN(String cust_GSTIN) {
        this.cust_GSTIN = cust_GSTIN;
    }

    public Date getDoc_Date() {
        return doc_Date;
    }

    public void setDoc_Date(Date doc_Date) {
        this.doc_Date = doc_Date;
    }

    public String getDoc_Num() {
        return doc_Num;
    }

    public void setDoc_Num(String doc_Num) {
        this.doc_Num = doc_Num;
    }

    public String getPlaceOfSupply() {
        return placeOfSupply;
    }

    public void setPlaceOfSupply(String placeOfSupply) {
        this.placeOfSupply = placeOfSupply;
    }

    public String getReverseCharge() {
        return reverseCharge;
    }

    public void setReverseCharge(String reverseCharge) {
        this.reverseCharge = reverseCharge;
    }

    public Set<GSTR6FB2BItemDetailsModel> getItemDetails() {
        return itemDetails;
    }

    public void setItemDetails(Set<GSTR6FB2BItemDetailsModel> itemDetails) {
        this.itemDetails = itemDetails;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getIsAccepted() {
        return isAccepted;
    }

    public void setIsAccepted(Integer isAccepted) {
        this.isAccepted = isAccepted;
    }

    public String getGstin() {
        return gstin;
    }

    public void setGstin(String gstin) {
        this.gstin = gstin;
    }

    public String getTaxPeriod() {
        return taxPeriod;
    }

    public void setTaxPeriod(String taxPeriod) {
        this.taxPeriod = taxPeriod;
    }

	public String getFilingStatus() {
		return filingStatus;
	}

	public void setFilingStatus(String filingStatus) {
		this.filingStatus = filingStatus;
	}

    public Set<TblIsdErrorInfo> getErrorInfo() {
        return errorInfo;
    }

    public void setErrorInfo(Set<TblIsdErrorInfo> errorInfo) {
        this.errorInfo = errorInfo;
    }

	public String getClientResponse() {
		return clientResponse;
	}

	public void setClientResponse(String clientResponse) {
		this.clientResponse = clientResponse;
	}

	public String getDrAvailability() {
		return drAvailability;
	}

	public void setDrAvailability(String drAvailability) {
		this.drAvailability = drAvailability;
	}

            
}
