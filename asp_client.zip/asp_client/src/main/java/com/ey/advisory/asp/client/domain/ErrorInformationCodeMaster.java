package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "tblErrorMaster",schema="master")
//@Table(name="[master].[tblErrorMaster]")
public class ErrorInformationCodeMaster implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ErrorId")
	private int errorInformationId;
	
	@Column(name="ErrorInfoCode")
	private String errorInformationCode;
	
	@Column(name="IncidenceLevel")
	private String incidenceLevel;
	
	@Column(name="ReturnImpacted")
	private String returnImpacted;
	
	@Column(name="ErrorInfoDesc")
	private String errorInformationDescription;
	
	@Column(name="IsError")
	private char isError;

	
	public int getErrorInformationId() {
		return errorInformationId;
	}

	public void setErrorInformationId(int errorInformationId) {
		this.errorInformationId = errorInformationId;
	}

	public String getErrorInformationCode() {
		return errorInformationCode;
	}

	public void setErrorInformationCode(String errorInformationCode) {
		this.errorInformationCode = errorInformationCode;
	}

	public String getIncidenceLevel() {
		return incidenceLevel;
	}

	public void setIncidenceLevel(String incidenceLevel) {
		this.incidenceLevel = incidenceLevel;
	}

	public String getReturnImpacted() {
		return returnImpacted;
	}

	public void setReturnImpacted(String returnImpacted) {
		this.returnImpacted = returnImpacted;
	}

	public String getErrorInformationDescription() {
		return errorInformationDescription;
	}

	public void setErrorInformationDescription(String errorInformationDescription) {
		this.errorInformationDescription = errorInformationDescription;
	}

	public char getIsError() {
		return isError;
	}

	public void setIsError(char isError) {
		this.isError = isError;
	}
		
}