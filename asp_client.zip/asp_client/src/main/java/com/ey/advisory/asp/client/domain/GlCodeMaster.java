package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name = "GLCodeMaster",schema=Constant.MASTER_SCHEMA)
public class GlCodeMaster implements Serializable {

private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GLId")
	private long glID;

	@Column(name = "GLDescription")
	private String glDescription;
	
	@Column(name = "Eligibility")
	private String eligibility;
	
	@Column(name = "GLCode")
	private String glCode;
	
	public long getGlID() {
		return glID;
	}

	public void setGlID(long glID) {
		this.glID = glID;
	}

	public String getGlDescription() {
		return glDescription;
	}

	public void setGlDescription(String glDescription) {
		this.glDescription = glDescription;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getGlCode() {
		return glCode;
	}

	public void setGlCode(String glCode) {
		this.glCode = glCode;
	}

	
	
}
