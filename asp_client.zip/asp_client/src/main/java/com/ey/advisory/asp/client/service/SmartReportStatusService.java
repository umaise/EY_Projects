package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.SmartReport;

public interface SmartReportStatusService {

	public List<SmartReport>  getSmartReportData(int offset,int pageSize);

	public void updateCancelStatus(String requestId, String fileCategory);

	public List<SmartReport> getSearchSmartReportData(String requestId, String fileCategory, int offset,
			int pageSize);

	public SmartReport getFileDetails(String requestId, String fileCategory);
			
}
