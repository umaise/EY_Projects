package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblTurnoverDetailsPriorFY",schema="gstr6")
public class GSTR6TurnoverDetailsPriorFY implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1580324678532339885L;

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private	Integer id;
	
	@Column(name = "TurnoverMasterID")
	private Integer turnoverMasterID;
	
	@Column(name = "FY")
	private String fy;
	
	
	@Column(name = "IsFreezed")
	private boolean isFreezed;
	
	@Column(name = "Amount")
	private BigDecimal amount;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTurnoverMasterID() {
		return turnoverMasterID;
	}

	public void setTurnoverMasterID(Integer turnoverMasterID) {
		this.turnoverMasterID = turnoverMasterID;
	}


	public boolean isFreezed() {
		return isFreezed;
	}

	public void setFreezed(boolean isFreezed) {
		this.isFreezed = isFreezed;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getFy() {
		return fy;
	}
	public void setFy(String fy) {
		this.fy = fy;
	}

}