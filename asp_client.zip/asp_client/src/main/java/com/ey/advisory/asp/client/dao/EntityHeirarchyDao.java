package com.ey.advisory.asp.client.dao;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.dto.CommonSearchDto;
import com.ey.advisory.asp.client.dto.ResultPage;


public interface EntityHeirarchyDao {
	
	public List<EntityHierarchy> getEntityNames(String groupId);
	
	public ResultPage<EntityHierarchy> fetchHierarchyListPagination(CommonSearchDto searchDto);

	public Boolean checkIfDuplicateEntryExists(EntityHierarchy entityHierarchyDTO);

	public List fetchGstinList(String entityId);
	
	public List<EntityHierarchy> fetchUserHierarchy(String accessLevel, String property, Object Value);

	public List<EntityHierarchy> fetchByGSTIN(String gstin);

	public List fetchEntityHierarchyList(String entityCode) throws Exception;

	public ResultPage<EntityHierarchy> fetchByHierarchyIdList(Map<Integer,String> hierarchyMap,
			CommonSearchDto commonSearchDto) throws Exception;
	
	public List<EntityHierarchy> fetchValues(String txt, String values);
	
	 public List<EntityHierarchy> fetchUserHierarchyUserTab(Integer accessLevelId,String accessLevel, String property, Object Value);

	 public List<EntityHierarchy> getGstinsByEntityId(String entityCode);
	 
	 public List<EntityHierarchy> getGstinsByGroupCode(String groupCode);
	 
	 public List<EntityHierarchy> getEntityHierarchyByEntityID(Integer entityiD);
	 
	 public List<EntityHierarchy> getEntityHierarchyByCircleCode(String circleCode);

}
