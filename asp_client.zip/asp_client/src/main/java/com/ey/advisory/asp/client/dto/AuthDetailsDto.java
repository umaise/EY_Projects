package com.ey.advisory.asp.client.dto;

public class AuthDetailsDto {
	private byte[] sessionKey;
	private String hmac;
	private String encryptedData;
	private String rek;
	private byte[] apiKey;
	private String originalAppKey;
	private String action;
	private String userName;
	private String appKey;
	private String otp;
	private String encryptedAppKey;
	private String encryptedOTP;
	
	public String getOriginalAppKey() {
		return originalAppKey;
	}
	public void setOriginalAppKey(String originalAppKey) {
		this.originalAppKey = originalAppKey;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAppKey() {
		return appKey;
	}
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getEncryptedAppKey() {
		return encryptedAppKey;
	}
	public void setEncryptedAppKey(String encryptedAppKey) {
		this.encryptedAppKey = encryptedAppKey;
	}
	public String getEncryptedOTP() {
		return encryptedOTP;
	}
	public void setEncryptedOTP(String encryptedOTP) {
		this.encryptedOTP = encryptedOTP;
	}
	public byte[] getApiKey() {
		return apiKey;
	}
	public void setApiKey(byte[] apiKey) {
		this.apiKey = apiKey;
	}
	public String getRek() {
		return rek;
	}
	public void setRek(String rek) {
		this.rek = rek;
	}
	public byte[] getSessionKey() {
		return sessionKey;
	}
	public void setSessionKey(byte[] sessionKey) {
		this.sessionKey = sessionKey;
	}
	public String getHmac() {
		return hmac;
	}
	public void setHmac(String hmac) {
		this.hmac = hmac;
	}
	public String getEncryptedData() {
		return encryptedData;
	}
	public void setEncryptedData(String encryptedData) {
		this.encryptedData = encryptedData;
	}
	public String getOriginalAppapiKey() {
		return originalAppKey;
	}
	public void setOriginalAppapiKey(String originalAppapiKey) {
		this.originalAppKey = originalAppapiKey;
	}
	
}
