package com.ey.advisory.asp.client.gstr1ff.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "tblB2BInvoiceDetails", schema = "gstr1A")
@JsonIgnoreProperties(ignoreUnknown = true)
public class GSTR1FFB2B_InvoiceDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger
			.getLogger(GSTR1FFB2B_InvoiceDetails.class);

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long GSTR1FFB2B_InvoiceDetails_ID;

	@Column(name = "CustGSTIN")
	@JsonProperty("ctin")
	private String custGSTIN;

	@Column(name = "CntrPrtyFilingStatus")
	@JsonProperty("cfs")
	private String cntrPrtyFilingStatus;

	@Column(name = "ChkSum")
	@JsonProperty("chksum")
	private String chkSum;

	@Column(name = "InvoiceUploader")
	@JsonProperty("updby")
	private String UploadedBy;



	@Column(name = "InvNum")
	@JsonProperty("inum")
	private String inv_Num;

	// @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Basic
	@Temporal(TemporalType.DATE)
	@Column(name = "InvDate")
	// ,columnDefinition="DATE"
	private Date inv_Date;

	@Transient
	@JsonProperty("idt")
	private String i_dt;

	@Column(name = "InvValue")
	@JsonProperty("val")
	private BigDecimal invValue;

	@Column(name = "POS")
	@JsonProperty("pos")
	private String pos;

	@Column(name = "RevChrg")
	@JsonProperty("rchrg")
	private String revChrg;

	@Column(name = "EcomGSTIN")
	@JsonProperty("etin")
	private String etin;

	@Column(name = "Invtyp")
	@JsonProperty("inv_typ")
	private String invtyp;

	@Column(name = "counterPartyFlag")
	@JsonProperty("cflag")
	private String counterPartyFlag;

	@Column(name = "TaxPeriod")
	private String taxPeriod;

	@Column(name = "Gstin")
	private String gstin;

	@Column(name = "Taxablevalue")
	private BigDecimal taxablevalue;

	@Column(name = "TotalTax")
	private BigDecimal totalTax;

	/*
	 * @Column(name="IsDelete") private boolean isDelete;
	 */

	@Column(nullable = false, columnDefinition = "TINYINT(1) default 1")
	private boolean IsActive;

	// @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	@Column(name = "LoadDate")
	private Date loadDate;

	@Column(name = "LoadName")
	private String loadName;

	// bi-directional many-to-one association to GSTR1AB2B_ItemDetail
	@OneToMany(mappedBy = "gstr1ffb2bInvoiceDetail", cascade = CascadeType.ALL)
	@JsonProperty("itms")
	private List<GSTR1FFB2B_ItemDetail> gstr1ffb2bItemDetails;

	public long getGSTR1FFB2B_InvoiceDetails_ID() {
		return GSTR1FFB2B_InvoiceDetails_ID;
	}

	public void setGSTR1FFB2B_InvoiceDetails_ID(
			long gSTR1FFB2B_InvoiceDetails_ID) {
		GSTR1FFB2B_InvoiceDetails_ID = gSTR1FFB2B_InvoiceDetails_ID;
	}

	public String getUploadedBy() {
		return UploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		UploadedBy = uploadedBy;
	}

	public String getI_dt() {
		return i_dt;
	}

	public void setI_dt(String i_dt) {
		this.i_dt = i_dt;
	}

	public String getEtin() {
		return etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	public boolean isIsActive() {
		return IsActive;
	}

	public void setIsActive(boolean isActive) {
		IsActive = isActive;
	}

	public Date getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(Date loadDate) {
		this.loadDate = loadDate;
	}

	public String getLoadName() {
		return loadName;
	}

	public void setLoadName(String loadName) {
		this.loadName = loadName;
	}

	public List<GSTR1FFB2B_ItemDetail> getGstr1ffb2bItemDetails() {
		return gstr1ffb2bItemDetails;
	}

	public void setGstr1ffb2bItemDetails(
			List<GSTR1FFB2B_ItemDetail> gstr1ffb2bItemDetails) {
		BigDecimal tot_tax_val = new BigDecimal(0) ;
		BigDecimal tot_tx = new BigDecimal(0);
		
		for(GSTR1FFB2B_ItemDetail itemDetail : gstr1ffb2bItemDetails){
			itemDetail.setGstr1ffb2bInvoiceDetail(this);
			tot_tax_val.add(itemDetail.getItem_Txval());
			tot_tx.add(itemDetail.getIGST_Amt());
			tot_tx.add(itemDetail.getCGST_Amt());
			tot_tx.add(itemDetail.getSGST_Amt());
			tot_tx.add(itemDetail.getCessAmt());
			
		}
		this.taxablevalue = tot_tax_val;
		this.totalTax = tot_tx;
		this.gstr1ffb2bItemDetails = gstr1ffb2bItemDetails;
	}

	public String getCustGSTIN() {
		return custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getCntrPrtyFilingStatus() {
		return cntrPrtyFilingStatus;
	}

	public void setCntrPrtyFilingStatus(String cntrPrtyFilingStatus) {
		this.cntrPrtyFilingStatus = cntrPrtyFilingStatus;
	}

	public String getChkSum() {
		return chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}



	public String getInv_Num() {
		return inv_Num;
	}

	public void setInv_Num(String inv_Num) {
		this.inv_Num = inv_Num;
	}

	public Date getInv_Date() {
		return inv_Date;
	}

	public void setInv_Date(java.util.Date date) {
		this.inv_Date = date;
	}

	public BigDecimal getInvValue() {
		return invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getRevChrg() {
		return revChrg;
	}

	public void setRevChrg(String revChrg) {
		this.revChrg = revChrg;
	}

	public String getInvtyp() {
		return invtyp;
	}

	public void setInvtyp(String invtyp) {
		this.invtyp = invtyp;
	}

	public String getCounterPartyFlag() {
		return counterPartyFlag;
	}

	public void setCounterPartyFlag(String counterPartyFlag) {
		this.counterPartyFlag = counterPartyFlag;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public BigDecimal getTaxablevalue() {
		return taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public BigDecimal getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(BigDecimal totalTax) {
		this.totalTax = totalTax;
	}

	/*
	 * public boolean isDelete() { return isDelete; }
	 * 
	 * 
	 * public void setDelete(boolean isDelete) { this.isDelete = isDelete; }
	 */

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public static Logger getLogger() {
		return LOGGER;
	}

}