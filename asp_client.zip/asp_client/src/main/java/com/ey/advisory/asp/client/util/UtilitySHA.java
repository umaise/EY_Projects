package com.ey.advisory.asp.client.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Hex;

public class UtilitySHA {

	private static MessageDigest getDigest(final String algorithm) {
		try {
			return MessageDigest.getInstance(algorithm);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Returns an SHA digest.
	 *
	 * @return An SHA digest instance.
	 * @throws RuntimeException
	 *             when a {@link java.security.NoSuchAlgorithmException} is
	 *             caught,
	 */
	private static MessageDigest getSha256Digest() {
		return getDigest("SHA-256");
	}

	/**
	 * Calculates the SHA digest and returns the value as a <code>byte[]</code>.
	 *
	 * @param data
	 *            Data to digest
	 * @return SHA digest
	 */
	public static byte[] sha(final byte[] data) {
		return getSha256Digest().digest(data);
	}

	/**
	 * Calculates the SHA digest and returns the value as a <code>byte[]</code>.
	 *
	 * @param data
	 *            Data to digest
	 * @return SHA digest
	 */
	public static byte[] sha(final String data) {
		return sha(data.getBytes());
	}

	/**
	 * Calculates the SHA digest and returns the value as a hex string.
	 *
	 * @param data
	 *            Data to digest
	 * @return SHA digest as a hex string
	 */
	public static String shaHex(final byte[] data) {
		return new String(Hex.encodeHex(sha(data)));
	}

	/**
	 * Calculates the SHA digest and returns the value as a hex string.
	 *
	 * @param data
	 *            Data to digest
	 * @return SHA digest as a hex string
	 */
	public static String shaHex(final String data, final String salt) {
		return new String(Hex.encodeHex(sha(new StringBuilder().append(data)
				.append("{").append(salt).append("}").toString())));
	}


}
