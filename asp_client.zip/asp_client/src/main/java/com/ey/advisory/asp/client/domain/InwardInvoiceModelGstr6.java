package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.*;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;



import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.Length;

import com.google.gson.annotations.SerializedName;

/**
 * The persistent class for the tblIsdPurchaseStaging database table.
 * 
 */
@Entity
@Table(name="tblISDStaging", schema="etl")

@NamedQueries({ 
	@NamedQuery(name = "InwardInvoiceModelGstr6.updateStatus",  query = "update InwardInvoiceModelGstr6 set "
		+ "itemStatus=:STATUS , tableType=:TYPE where fILEID= :FILEID and invOrder= :INVORDER") ,
		@NamedQuery(name="InwardInvoiceModelGstr6.findAll", query="SELECT t FROM InwardInvoiceModelGstr6 t")})


public class InwardInvoiceModelGstr6 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ISDStagingID")
	@SerializedName("ISDStagingID")
	private int id;
	
	@Column(name="FileID")
	@SerializedName("FileID")
	private int fILEID;
	
	@Column(name="TaxableValue")
	@SerializedName("TaxableValue")
	private Double taxableValue;
	
	@Column(name="ReceiverPlantCode")@Length(max = 15)
	@SerializedName("ReceiverPlantCode")
	private String receiverPlantCode;
	
	@Column(name="TaxPeriod")@Length(max = 10)
	@SerializedName("TaxPeriod")
	private String taxPeriod;
	
	@Column(name="ContractNumber")@Length(max = 50)
	@SerializedName("ContractNumber")
	private String contractNumber;
	
	@Column(name="Contractdate")
	@SerializedName("Contractdate")
	private Date contractdate;
	
	@Column(name="ContractValue")
	@SerializedName("ContractValue")
	private Double contractValue;
	
	@Column(name="DocumentType")@Length(max = 5)
	@SerializedName("DocumentType")
	private String documentType;
	
	@Column(name="SupplyType")@Length(max = 5)
	@SerializedName("SupplyType")
	private String supplyType;
	
	@Column(name="DcoumentAttribute")@Length(max = 5)
	@SerializedName("DcoumentAttribute")
	private String dcoumentAttribute;
	
	@Column(name="CompanyGSTIN")@Length(max = 15)
	@SerializedName("CompanyGSTIN")
	private String companyGSTIN;
	
	@Column(name="SupplierGSTIN")@Length(max = 15)
	@SerializedName("SupplierGSTIN")
	private String supplierGSTIN;
	
	@Column(name="SupplierCode")@Length(max = 10)
	@SerializedName("SupplierCode")
	private String supplierCode;
	
	@Column(name="SupplierName")@Length(max = 40)
	@SerializedName("SupplierName")
	private String supplierName;
	
	@Column(name="SupplierAddress")@Length(max = 100)
	@SerializedName("SupplierAddress")
	private String supplierAddress;
	
	@Column(name="ImportReportNumber")@Length(max = 100)
	@SerializedName("ImportReportNumber")
	private String importReportNumber;
	
	@Column(name="ImportReportDate")
	@SerializedName("ImportReportDate")
	private Date importReportDate;
	
	@Column(name="DocumentNo")
	@SerializedName("DocumentNo")@Length(max = 50)
	private String docNum;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DocumentDate")
	@SerializedName("DocumentDate")
	private Date documentDate;
	
	@Column(name="LineNumber")@Length(max = 4)
	@SerializedName("LineNumber")
	private String lineNumber;
	
	@Column(name="OriginalDocumentNo")
	@SerializedName("OriginalDocumentNo")@Length(max = 50)
	private String originalDocumentNo;
	
	@Column(name="OriginalDocumentDate")
	@SerializedName("OriginalDocumentDate")
	private Date originalDocumentDate;
	
	@Column(name="UnitofMeasurement")@Length(max = 30)
	@SerializedName("UnitofMeasurement")
	private String unitofMeasurement;
	
	@Column(name="BillQty")
	@SerializedName("BillQty")
	private Double billQty;
	
	@Column(name="Advances")
	@SerializedName("Advances")
	private Double advances;
	
	@Column(name="GSTTaxableValue")
	@SerializedName("GSTTaxableValue")
	private Double gSTTaxableValue;
	
	@Column(name="TransactionIDforAdvances")@Length(max = 20)
	@SerializedName("TransactionIDforAdvances")
	private String transactionIDforAdvances;
	
	@Column(name="GoodServices")@Length(max = 1)
	@SerializedName("GoodServices")
	private String goodServices;
	
	@Column(name="HSNSAC")@Length(max = 10)
	@SerializedName("HSNSAC")
	private String hSNSAC;
	
	@Column(name="ItemCode")@Length(max = 10)
	@SerializedName("ItemCode")
	private String itemCode;
	
	@Column(name="ItemDescription")@Length(max = 30)
	@SerializedName("ItemDescription")
	private String itemDescription;
	
	@Column(name="CategoryItem")@Length(max = 10)
	@SerializedName("CategoryItem")
	private String categoryItem;
	
	@Column(name="IGSTRate")
	@SerializedName("IGSTRate")
	private Double igstRate;
	
	@Column(name="IGSTAmount")
	@SerializedName("IGSTAmount")
	private Double iGSTAmount;
	
	@Column(name="CGSTRate")
	@SerializedName("CGSTRate")
	private Double cgstRate;
	
	@Column(name="CGSTAmount")
	@SerializedName("CGSTAmount")
	private Double cGSTAmount;
	
	@Column(name="SGSTRate")
	@SerializedName("SGSTRate")
	private Double sgstRate;
	
	@Column(name="SGSTAmount")
	@SerializedName("SGSTAmount")
	private Double sGSTAmount;
	
	@Column(name="UTGSTRate")
	@SerializedName("UTGSTRate")
	private Double uTGSTRate;
	
	@Column(name="UTGSTAmount")
	@SerializedName("UTGSTAmount")
	private Double uTGSTAmount;
	
	@Column(name="CessRate")
	@SerializedName("CessRate")
	private Double cessRate;
	
	@Column(name="CessAmount")
	@SerializedName("CessAmount")
	private Double cessAmount;
	
	@Column(name="ValueIncludingTax")
	@SerializedName("ValueIncludingTax")
	private Double valueIncludingTax;
	
	@Column(name="POS")@Length(max = 2)
	@SerializedName("POS")
	private String pOS;
	
	@Column(name="ReverseCharge")@Length(max = 1)
	@SerializedName("ReverseCharge")
	private String reverseCharge;
	
	@Column(name="CosumptionType")@Length(max = 15)
	@SerializedName("CosumptionType")
	private String cosumptionType;
	
	@Column(name="PaymentVoucherNumber")@Length(max = 50)
	@SerializedName("PaymentVoucherNumber")
	private String paymentVoucherNumber;
	
	@Column(name="DateofPayment")
	@SerializedName("DateofPayment")
	private Date dateofPayment;
	
	@Column(name="ValueOnTDS")
	@SerializedName("ValueOnTDS")
	private Double valueOnTDS;
	
	@Column(name="GLCodeCapitalGoods")@Length(max = 20)
	@SerializedName("GLCodeCapitalGoods")
	private String gLCodeCapitalGoods;
	
	@Column(name="CapitalGoodsIdentifier")@Length(max = 2)
	@SerializedName("CapitalGoodsIdentifier")
	private String capitalGoodsIdentifier;
	
	@Column(name="EligibleInput")@Length(max = 2)
	@SerializedName("EligibleInput")
	private String eligibleInput;
	
	@Column(name="EligibilityIndicator")@Length(max = 2)
	@SerializedName("EligibilityIndicator")
	private String eligibilityIndicator;
	
	@Column(name="TotalTaxeligibleITC")
	@SerializedName("TotalTaxeligibleITC")
	private Double totalTaxeligibleITC;
	
	@Column(name="MonthlyITCavailability")
	@SerializedName("MonthlyITCavailability")
	private Double monthlyITCavailability;
	
	@Column(name="ItcIgstAmt")
	@SerializedName("ItcIgstAmt")
	private Double itcIgstAmt;
	
	@Column(name="ItcCgstAmt")
	@SerializedName("ItcCgstAmt")
	private Double itcCgstAmt;
	
	@Column(name="ItcSgstAmt")
	@SerializedName("ItcSgstAmt")
	private Double itcSgstAmt;
	
	@Column(name="ItcCsgstAmt")
	@SerializedName("ItcCsgstAmt")
	private Double itcCsgstAmt;
	
	@Column(name="TcIgstAmt")
	@SerializedName("TcIgstAmt")
	private Double tcIgstAmt;
	
	@Column(name="TcCgstAmt")
	@SerializedName("TcCgstAmt")
	private Double tcCgstAmt;
	
	@Column(name="TcSgstAmt")
	@SerializedName("TcSgstAmt")
	private Double tcSgstAmt;
	
	@Column(name="TcCsgstAmt")
	@SerializedName("TcCsgstAmt")
	private Double tcCsgstAmt;
	
	@Column(name="InwardSuppliesSubjectTTDS")@Length(max = 1)
	@SerializedName("InwardSuppliesSubjectTTDS")
	private String inwardSuppliesSubjectTTDS;
	
	@Column(name="TDSIGSTrate")
	@SerializedName("TDSIGSTrate")
	private Double tDSIGSTrate;
	
	@Column(name="TDS_IGST")
	@SerializedName("TDS_IGST")
	private Double tDSIGST;
	
	@Column(name="TDSGSTrate")
	@SerializedName("TDSGSTrate")
	private Double tDSGSTrate;
	
	@Column(name="TDS_SGST")
	@SerializedName("TDS_SGST")
	private Double tDSSGST;
	
	@Column(name="TDSCGSTrate")
	@SerializedName("TDSCGSTrate")
	private Double tDSCGSTrate;
	
	@Column(name="TDS_CGST")
	@SerializedName("TDS_CGST")
	private Double tDSCGST;
	
	@Column(name="TDSUTGSTrate")
	@SerializedName("TDSUTGSTrate")
	private Double tDSUTGSTrate;
	
	@Column(name="TDSUTGST")
	@SerializedName("TDSUTGST")
	private Double tDSUTGST;
	
	@Column(name="TDSCessrate")
	@SerializedName("TDSCessrate")
	private Double tDSCessrate;
	
	@Column(name="TDS_Cess")
	@SerializedName("TDS_Cess")
	private Double tDSCess;
	
	@Column(name="CompanyRoadPermitNumber")@Length(max = 50)
	@SerializedName("CompanyRoadPermitNumber")
	private String companyRoadPermitNumber;
	
	@Column(name="CompanyRoadPermitDate")
	@SerializedName("CompanyRoadPermitDate")
	private Date companyRoadPermitDate;
	
	@Column(name="TransporterName")@Length(max = 40)
	@SerializedName("TransporterName")
	private String transporterName;
	
	@Column(name="LorryNumber")@Length(max = 40)
	@SerializedName("LorryNumber")
	private String lorryNumber;
	
	@Column(name="SupplierRoadPermitNumber")@Length(max = 50)
	@SerializedName("SupplierRoadPermitNumber")
	private String supplierRoadPermitNumber;
	
	@Column(name="SuppliersRoadPermitDate")
	@SerializedName("SuppliersRoadPermitDate")
	private Date suppliersRoadPermitDate;
	
	
	@Column(name="AggTaxableValue")
	@SerializedName("AggTaxableValue")
	private Double aggTaxableValue;
	
	@Column(name="AggInvoice")
	@SerializedName("AggInvoice")
	private Double aggInvoice;
	
	@Column(name="POScd")@Length(max = 2)
	@SerializedName("POScd")
	private String pOScd;
	
	@Column(name="InvOrder")
	@SerializedName("InvOrder")
	private Integer invOrder;
	
	@Column(name="Status")@Length(max = 20)
	@SerializedName("Status")
	private String itemStatus;

	
	@Column(name="RecordType")@Length(max = 20)
	@SerializedName("RecordType")
	private String tableType;
	
	
	
	@Column(name="SupplyCategory")@Length(max = 11)
	@SerializedName("SupplyCategory")
	private String supplyCategory;
	
	@Column(name="IsProcessed")
	@SerializedName("IsProcessed")
	private char isProcessed;
	
	@Column(name="IsError")
	@SerializedName("IsError")
	private char isError;
	
	@Column(name="NewInvOrder")
	@SerializedName("NewInvOrder")
	private String newInvOrder;
	
	@Column(name="IsDuplicate")
	@SerializedName("IsDuplicate")
	private char isDuplicate;
	
	@Column(name="IsErrorExists")
	@SerializedName("IsErrorExists")
	private char isErrorExists;
	
	@Column(name="Chksum")
	@SerializedName("Chksum")
	private String chksum;
	

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "ISDErrorInfoID", referencedColumnName="ISDStagingID")
	
	private Set<TblIsdErrorInfo> tblErrorInfo;
	
	
	

	public String getEligibilityIndicator() {
		return eligibilityIndicator;
	}


	public void setEligibilityIndicator(String eligibilityIndicator) {
		this.eligibilityIndicator = eligibilityIndicator;
	}


	public Double getTaxableValue() {
		return taxableValue;
	}


	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}


	public Set<TblIsdErrorInfo> getTblErrorInfo() {
		return tblErrorInfo;
	}


	public void setTblErrorInfo(Set<TblIsdErrorInfo> tblErrorInfo) {
		this.tblErrorInfo = tblErrorInfo;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getfILEID() {
		return fILEID;
	}


	public void setfILEID(int fILEID) {
		this.fILEID = fILEID;
	}


	public String getReceiverPlantCode() {
		return receiverPlantCode;
	}


	public void setReceiverPlantCode(String receiverPlantCode) {
		this.receiverPlantCode = receiverPlantCode;
	}


	public String getTaxPeriod() {
		return taxPeriod;
	}


	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}


	public String getContractNumber() {
		return contractNumber;
	}


	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}


	public Date getContractdate() {
		return contractdate;
	}


	public void setContractdate(Date contractdate) {
		this.contractdate = contractdate;
	}


	public Double getContractValue() {
		return contractValue;
	}


	public void setContractValue(Double contractValue) {
		this.contractValue = contractValue;
	}


	public String getDocumentType() {
		return documentType;
	}


	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}


	public String getSupplyType() {
		return supplyType;
	}


	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}


	public String getCompanyGSTIN() {
		return companyGSTIN;
	}


	public void setCompanyGSTIN(String companyGSTIN) {
		this.companyGSTIN = companyGSTIN;
	}


	public String getSupplierGSTIN() {
		return supplierGSTIN;
	}


	public void setSupplierGSTIN(String supplierGSTIN) {
		this.supplierGSTIN = supplierGSTIN;
	}


	public String getSupplierCode() {
		return supplierCode;
	}


	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}


	public String getSupplierName() {
		return supplierName;
	}


	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}


	public String getSupplierAddress() {
		return supplierAddress;
	}


	public void setSupplierAddress(String supplierAddress) {
		this.supplierAddress = supplierAddress;
	}


	public String getImportReportNumber() {
		return importReportNumber;
	}


	public void setImportReportNumber(String importReportNumber) {
		this.importReportNumber = importReportNumber;
	}


	public Date getImportReportDate() {
		return importReportDate;
	}


	public void setImportReportDate(Date importReportDate) {
		this.importReportDate = importReportDate;
	}


	public String getDocumentNo() {
		return docNum;
	}


	public void setDocumentNo(String documentNo) {
		this.docNum = documentNo;
	}


	public Date getDocumentDate() {
		return documentDate;
	}


	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}


	public String getLineNumber() {
		return lineNumber;
	}


	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}


	public String getOriginalDocumentNo() {
		return originalDocumentNo;
	}


	public void setOriginalDocumentNo(String originalDocumentNo) {
		this.originalDocumentNo = originalDocumentNo;
	}


	public Date getOriginalDocumentDate() {
		return originalDocumentDate;
	}


	public void setOriginalDocumentDate(Date originalDocumentDate) {
		this.originalDocumentDate = originalDocumentDate;
	}


	public String getUnitofMeasurement() {
		return unitofMeasurement;
	}


	public void setUnitofMeasurement(String unitofMeasurement) {
		this.unitofMeasurement = unitofMeasurement;
	}


	public Double getBillQty() {
		return billQty;
	}


	public void setBillQty(Double billQty) {
		this.billQty = billQty;
	}


	public Double getAdvances() {
		return advances;
	}


	public void setAdvances(Double advances) {
		this.advances = advances;
	}


	public Double getgSTTaxableValue() {
		return gSTTaxableValue;
	}


	public void setgSTTaxableValue(Double gSTTaxableValue) {
		this.gSTTaxableValue = gSTTaxableValue;
	}


	public String getTransactionIDforAdvances() {
		return transactionIDforAdvances;
	}


	public void setTransactionIDforAdvances(String transactionIDforAdvances) {
		this.transactionIDforAdvances = transactionIDforAdvances;
	}


	public String getGoodServices() {
		return goodServices;
	}


	public void setGoodServices(String goodServices) {
		this.goodServices = goodServices;
	}


	public String gethSNSAC() {
		return hSNSAC;
	}


	public void sethSNSAC(String hSNSAC) {
		this.hSNSAC = hSNSAC;
	}


	public String getItemCode() {
		return itemCode;
	}


	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public String getCategoryItem() {
		return categoryItem;
	}


	public void setCategoryItem(String categoryItem) {
		this.categoryItem = categoryItem;
	}


	public Double getIgstRate() {
		return igstRate;
	}


	public void setIgstRate(Double igstRate) {
		this.igstRate = igstRate;
	}


	public Double getiGSTAmount() {
		return iGSTAmount;
	}


	public void setiGSTAmount(Double iGSTAmount) {
		this.iGSTAmount = iGSTAmount;
	}


	public Double getCgstRate() {
		return cgstRate;
	}


	public void setCgstRate(Double cgstRate) {
		this.cgstRate = cgstRate;
	}


	public Double getcGSTAmount() {
		return cGSTAmount;
	}


	public void setcGSTAmount(Double cGSTAmount) {
		this.cGSTAmount = cGSTAmount;
	}


	public Double getSgstRate() {
		return sgstRate;
	}


	public void setSgstRate(Double sgstRate) {
		this.sgstRate = sgstRate;
	}


	public Double getsGSTAmount() {
		return sGSTAmount;
	}


	public void setsGSTAmount(Double sGSTAmount) {
		this.sGSTAmount = sGSTAmount;
	}


	public Double getuTGSTRate() {
		return uTGSTRate;
	}


	public void setuTGSTRate(Double uTGSTRate) {
		this.uTGSTRate = uTGSTRate;
	}


	public Double getuTGSTAmount() {
		return uTGSTAmount;
	}


	public void setuTGSTAmount(Double uTGSTAmount) {
		this.uTGSTAmount = uTGSTAmount;
	}


	public Double getCessRate() {
		return cessRate;
	}


	public void setCessRate(Double cessRate) {
		this.cessRate = cessRate;
	}


	public Double getCessAmount() {
		return cessAmount;
	}


	public void setCessAmount(Double cessAmount) {
		this.cessAmount = cessAmount;
	}


	public Double getValueIncludingTax() {
		return valueIncludingTax;
	}


	public void setValueIncludingTax(Double valueIncludingTax) {
		this.valueIncludingTax = valueIncludingTax;
	}


	public String getpOS() {
		return pOS;
	}


	public void setpOS(String pOS) {
		this.pOS = pOS;
	}


	public String getReverseCharge() {
		return reverseCharge;
	}


	public void setReverseCharge(String reverseCharge) {
		this.reverseCharge = reverseCharge;
	}


	public String getCosumptionType() {
		return cosumptionType;
	}


	public void setCosumptionType(String cosumptionType) {
		this.cosumptionType = cosumptionType;
	}


	public String getPaymentVoucherNumber() {
		return paymentVoucherNumber;
	}


	public void setPaymentVoucherNumber(String paymentVoucherNumber) {
		this.paymentVoucherNumber = paymentVoucherNumber;
	}


	public Date getDateofPayment() {
		return dateofPayment;
	}


	public void setDateofPayment(Date dateofPayment) {
		this.dateofPayment = dateofPayment;
	}


	public Double getValueOnTDS() {
		return valueOnTDS;
	}


	public void setValueOnTDS(Double valueOnTDS) {
		this.valueOnTDS = valueOnTDS;
	}


	public String getgLCodeCapitalGoods() {
		return gLCodeCapitalGoods;
	}


	public void setgLCodeCapitalGoods(String gLCodeCapitalGoods) {
		this.gLCodeCapitalGoods = gLCodeCapitalGoods;
	}


	public String getCapitalGoodsIdentifier() {
		return capitalGoodsIdentifier;
	}


	public void setCapitalGoodsIdentifier(String capitalGoodsIdentifier) {
		this.capitalGoodsIdentifier = capitalGoodsIdentifier;
	}


	public String getEligibleInput() {
		return eligibleInput;
	}


	public void setEligibleInput(String eligibleInput) {
		this.eligibleInput = eligibleInput;
	}


	public Double getTotalTaxeligibleITC() {
		return totalTaxeligibleITC;
	}


	public void setTotalTaxeligibleITC(Double totalTaxeligibleITC) {
		this.totalTaxeligibleITC = totalTaxeligibleITC;
	}


	public Double getMonthlyITCavailability() {
		return monthlyITCavailability;
	}


	public void setMonthlyITCavailability(Double monthlyITCavailability) {
		this.monthlyITCavailability = monthlyITCavailability;
	}


	public Double getItcIgstAmt() {
		return itcIgstAmt;
	}


	public void setItcIgstAmt(Double itcIgstAmt) {
		this.itcIgstAmt = itcIgstAmt;
	}


	public Double getItcCgstAmt() {
		return itcCgstAmt;
	}


	public void setItcCgstAmt(Double itcCgstAmt) {
		this.itcCgstAmt = itcCgstAmt;
	}


	public Double getItcSgstAmt() {
		return itcSgstAmt;
	}


	public void setItcSgstAmt(Double itcSgstAmt) {
		this.itcSgstAmt = itcSgstAmt;
	}


	public Double getItcCsgstAmt() {
		return itcCsgstAmt;
	}


	public void setItcCsgstAmt(Double itcCsgstAmt) {
		this.itcCsgstAmt = itcCsgstAmt;
	}


	public Double getTcIgstAmt() {
		return tcIgstAmt;
	}


	public void setTcIgstAmt(Double tcIgstAmt) {
		this.tcIgstAmt = tcIgstAmt;
	}


	public Double getTcCgstAmt() {
		return tcCgstAmt;
	}


	public void setTcCgstAmt(Double tcCgstAmt) {
		this.tcCgstAmt = tcCgstAmt;
	}


	public Double getTcSgstAmt() {
		return tcSgstAmt;
	}


	public void setTcSgstAmt(Double tcSgstAmt) {
		this.tcSgstAmt = tcSgstAmt;
	}


	public Double getTcCsgstAmt() {
		return tcCsgstAmt;
	}


	public void setTcCsgstAmt(Double tcCsgstAmt) {
		this.tcCsgstAmt = tcCsgstAmt;
	}


	public String getInwardSuppliesSubjectTTDS() {
		return inwardSuppliesSubjectTTDS;
	}


	public void setInwardSuppliesSubjectTTDS(String inwardSuppliesSubjectTTDS) {
		this.inwardSuppliesSubjectTTDS = inwardSuppliesSubjectTTDS;
	}


	public Double gettDSIGSTrate() {
		return tDSIGSTrate;
	}


	public void settDSIGSTrate(Double tDSIGSTrate) {
		this.tDSIGSTrate = tDSIGSTrate;
	}


	


	public Double gettDSGSTrate() {
		return tDSGSTrate;
	}


	public void settDSGSTrate(Double tDSGSTrate) {
		this.tDSGSTrate = tDSGSTrate;
	}


	


	public Double gettDSCGSTrate() {
		return tDSCGSTrate;
	}


	public void settDSCGSTrate(Double tDSCGSTrate) {
		this.tDSCGSTrate = tDSCGSTrate;
	}


	


	public Double gettDSUTGSTrate() {
		return tDSUTGSTrate;
	}


	public void settDSUTGSTrate(Double tDSUTGSTrate) {
		this.tDSUTGSTrate = tDSUTGSTrate;
	}


	public Double gettDSUTGST() {
		return tDSUTGST;
	}


	public void settDSUTGST(Double tDSUTGST) {
		this.tDSUTGST = tDSUTGST;
	}


	public Double gettDSCessrate() {
		return tDSCessrate;
	}


	public void settDSCessrate(Double tDSCessrate) {
		this.tDSCessrate = tDSCessrate;
	}


	


	public String getCompanyRoadPermitNumber() {
		return companyRoadPermitNumber;
	}


	public void setCompanyRoadPermitNumber(String companyRoadPermitNumber) {
		this.companyRoadPermitNumber = companyRoadPermitNumber;
	}


	public Date getCompanyRoadPermitDate() {
		return companyRoadPermitDate;
	}


	public void setCompanyRoadPermitDate(Date companyRoadPermitDate) {
		this.companyRoadPermitDate = companyRoadPermitDate;
	}


	public String getTransporterName() {
		return transporterName;
	}


	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}


	public String getLorryNumber() {
		return lorryNumber;
	}


	public void setLorryNumber(String lorryNumber) {
		this.lorryNumber = lorryNumber;
	}


	public String getSupplierRoadPermitNumber() {
		return supplierRoadPermitNumber;
	}


	public void setSupplierRoadPermitNumber(String supplierRoadPermitNumber) {
		this.supplierRoadPermitNumber = supplierRoadPermitNumber;
	}


	public Date getSuppliersRoadPermitDate() {
		return suppliersRoadPermitDate;
	}


	public void setSuppliersRoadPermitDate(Date suppliersRoadPermitDate) {
		this.suppliersRoadPermitDate = suppliersRoadPermitDate;
	}


	public Double getAggTaxableValue() {
		return aggTaxableValue;
	}


	public void setAggTaxableValue(Double aggTaxableValue) {
		this.aggTaxableValue = aggTaxableValue;
	}


	public Double getAggInvoice() {
		return aggInvoice;
	}


	public void setAggInvoice(Double aggInvoice) {
		this.aggInvoice = aggInvoice;
	}


	public String getpOScd() {
		return pOScd;
	}


	public void setpOScd(String pOScd) {
		this.pOScd = pOScd;
	}


	public Integer getInvOrder() {
		return invOrder;
	}


	public void setInvOrder(Integer invOrder) {
		this.invOrder = invOrder;
	}


	public String getItemStatus() {
		return itemStatus;
	}


	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}


	public String getTableType() {
		return tableType;
	}


	public void setTableType(String tableType) {
		this.tableType = tableType;
	}


	public String getDcoumentAttribute() {
		return dcoumentAttribute;
	}


	public void setDcoumentAttribute(String dcoumentAttribute) {
		this.dcoumentAttribute = dcoumentAttribute;
	}


	public String getSupplyCategory() {
		return supplyCategory;
	}


	public void setSupplyCategory(String supplyCategory) {
		this.supplyCategory = supplyCategory;
	}


	public String getDocNum() {
		return docNum;
	}


	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}


	public Double gettDSIGST() {
		return tDSIGST;
	}


	public void settDSIGST(Double tDSIGST) {
		this.tDSIGST = tDSIGST;
	}


	public Double gettDSSGST() {
		return tDSSGST;
	}


	public void settDSSGST(Double tDSSGST) {
		this.tDSSGST = tDSSGST;
	}


	public Double gettDSCGST() {
		return tDSCGST;
	}


	public void settDSCGST(Double tDSCGST) {
		this.tDSCGST = tDSCGST;
	}


	public Double gettDSCess() {
		return tDSCess;
	}


	public void settDSCess(Double tDSCess) {
		this.tDSCess = tDSCess;
	}


	public char getIsProcessed() {
		return isProcessed;
	}


	public void setIsProcessed(char isProcessed) {
		this.isProcessed = isProcessed;
	}


	public char getIsError() {
		return isError;
	}


	public void setIsError(char isError) {
		this.isError = isError;
	}


	public String getNewInvOrder() {
		return newInvOrder;
	}


	public void setNewInvOrder(String newInvOrder) {
		this.newInvOrder = newInvOrder;
	}


	public char getIsDuplicate() {
		return isDuplicate;
	}


	public void setIsDuplicate(char isDuplicate) {
		this.isDuplicate = isDuplicate;
	}


	public char getIsErrorExists() {
		return isErrorExists;
	}


	public void setIsErrorExists(char isErrorExists) {
		this.isErrorExists = isErrorExists;
	}


	public String getChksum() {
		return chksum;
	}


	public void setChksum(String chksum) {
		this.chksum = chksum;
	}


	
	
	
	
}
