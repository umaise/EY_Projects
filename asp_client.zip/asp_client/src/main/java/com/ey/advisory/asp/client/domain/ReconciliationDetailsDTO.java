package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.SerializedName;

public class ReconciliationDetailsDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SerializedName("ID")
	private int id;
	
	@SerializedName("InvoiceDetailsId")
	private Double invoiceDetailsId;
	
	@SerializedName("CustGSTIN")
	private String custGSTIN;
	
	@SerializedName("CntrPrtyFilingStatus")
	private String cntrPrtyFilingStatus;
	
	@SerializedName("ChkSum")
	private String chkSum;
	
	@SerializedName("InvNum")
	private String invNum;
	
	@SerializedName("InvDate")
	private Date invDate;
	
	@SerializedName("InvValue")
	private Double invValue;
	
	@SerializedName("NtNum")
	private String noteNum;
	
	@SerializedName("NtDate")
	private Date noteDate;
	
	@SerializedName("Rsn")
	private String rsn;
	
	@SerializedName("PreGst")
    private String preGst;
	
	@SerializedName("POS")
	private String pos;
	
	@SerializedName("SubCategory")
	private String subCategory;
	
	@SerializedName("RevChrg")
	private String revChrg;
	
	@SerializedName("TaxableValue")
	private Double taxableValue;
	
	@SerializedName("InvTyp")
	private String invTyp;
	
	@SerializedName("TaxPeriod")
	private String taxPeriod;
	
	@SerializedName("Gstin")
	private String gstin;
	
	@SerializedName("InvKey")
	private String invKey;
	
	@SerializedName("isDelete")
	private String isDelete;
	
	@SerializedName("CHUNKID")
	private String chunkId;
	
	@SerializedName("TotalTax")
	private Double totalTax;
	
	@SerializedName("LineNo")
	private int lineNo;

	@SerializedName("ItemTxval")
	private Double itemTxVal;
	
	@SerializedName("IGSTAmt")
	private Double igstAmt;
	
	@SerializedName("CGSTAmt")
	private Double cgstAmt;
	
	@SerializedName("SGSTAmt")
	private Double sgstAmt;
	
	@SerializedName("CessAmt")
	private Double cessAmt;
	
	@SerializedName("Rate")
	private Double rate;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustGSTIN() {
		return custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getCntrPrtyFilingStatus() {
		return cntrPrtyFilingStatus;
	}

	public void setCntrPrtyFilingStatus(String cntrPrtyFilingStatus) {
		this.cntrPrtyFilingStatus = cntrPrtyFilingStatus;
	}

	public String getChkSum() {
		return chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getInvNum() {
		return invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public Date getInvDate() {
		return invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public Double getInvValue() {
		return invValue;
	}

	public void setInvValue(Double invValue) {
		this.invValue = invValue;
	}

	public String getNoteNum() {
		return noteNum;
	}

	public void setNoteNum(String noteNum) {
		this.noteNum = noteNum;
	}

	public Date getNoteDate() {
		return noteDate;
	}

	public void setNoteDate(Date noteDate) {
		this.noteDate = noteDate;
	}

	public String getRsn() {
		return rsn;
	}

	public void setRsn(String rsn) {
		this.rsn = rsn;
	}

	public String getPreGst() {
		return preGst;
	}

	public void setPreGst(String preGst) {
		this.preGst = preGst;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getRevChrg() {
		return revChrg;
	}

	public void setRevChrg(String revChrg) {
		this.revChrg = revChrg;
	}

	public Double getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getInvTyp() {
		return invTyp;
	}

	public void setInvTyp(String invTyp) {
		this.invTyp = invTyp;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getInvKey() {
		return invKey;
	}

	public void setInvKey(String invKey) {
		this.invKey = invKey;
	}

	public String getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(String isDelete) {
		this.isDelete = isDelete;
	}

	public String getChunkId() {
		return chunkId;
	}

	public void setChunkId(String chunkId) {
		this.chunkId = chunkId;
	}

	public Double getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(Double totalTax) {
		this.totalTax = totalTax;
	}

	public Double getInvoiceDetailsId() {
		return invoiceDetailsId;
	}

	public void setInvoiceDetailsId(Double invoiceDetailsId) {
		this.invoiceDetailsId = invoiceDetailsId;
	}

	public int getLineNo() {
		return lineNo;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}

	public Double getItemTxVal() {
		return itemTxVal;
	}

	public void setItemTxVal(Double itemTxVal) {
		this.itemTxVal = itemTxVal;
	}

	public Double getIgstAmt() {
		return igstAmt;
	}

	public void setIgstAmt(Double igstAmt) {
		this.igstAmt = igstAmt;
	}

	public Double getCgstAmt() {
		return cgstAmt;
	}

	public void setCgstAmt(Double cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	public Double getSgstAmt() {
		return sgstAmt;
	}

	public void setSgstAmt(Double sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	public Double getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}
	
}
