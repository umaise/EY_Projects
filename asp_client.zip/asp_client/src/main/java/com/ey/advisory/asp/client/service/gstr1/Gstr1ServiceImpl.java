package com.ey.advisory.asp.client.service.gstr1;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import redis.clients.jedis.exceptions.JedisConnectionException;

import com.ey.advisory.asp.client.dao.DueDateMasterDao;
import com.ey.advisory.asp.client.dao.EntityModelDao;
import com.ey.advisory.asp.client.dao.GSTR1Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.InvoiceDao;
import com.ey.advisory.asp.client.dao.ReportDao;
import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.dao.ReturnTypeDao;
import com.ey.advisory.asp.client.domain.DueDateMaster;
import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.FileUploadMasterClient;
import com.ey.advisory.asp.client.domain.GSTR1B2BCLEAInvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR1B2CSA_InvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR1B2CS_InvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR1EXP_Invoice;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.MasterTable;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.PayloadStatus;
import com.ey.advisory.asp.client.domain.ReturnType;
import com.ey.advisory.asp.client.domain.TblEmailStatusDetails;
import com.ey.advisory.asp.client.domain.TblFileUploadStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.client.dto.AuthDetailsDto;
import com.ey.advisory.asp.client.dto.CounterPartySalesDto;
import com.ey.advisory.asp.client.dto.OutwardInvoiceDTO;
import com.ey.advisory.asp.client.dto.ParentSalePurchaseDto;
import com.ey.advisory.asp.client.dto.SalePurchasedto;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.client.service.ClientFileUploadService;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.CommonApiService;
import com.ey.advisory.asp.client.service.InvoiceService;
import com.ey.advisory.asp.client.service.SalePurchaseServiceImpl;
import com.ey.advisory.asp.client.service.master.MasterTableService;
import com.ey.advisory.asp.client.util.AuthenticationUtility;
import com.ey.advisory.asp.client.util.CommonUtillity;
import com.ey.advisory.asp.client.util.ErrorActionUtility;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.InvoiceProcessDto;

@Service
@PropertySource("classpath:RestConfig.properties")
@Transactional
public class Gstr1ServiceImpl implements Gstr1Service {

	@Autowired
	HibernateDao hibernateDao;

	@Autowired
	AuthenticationUtility authenticationUtility;

	@Autowired
	private InvoiceDao invoiceDao;
	
	@Autowired
	private InvoiceService invoiceService;

	@Autowired
	private ReturnFilingDao returnFilingDao;

	@Autowired
	private GSTR1Dao gstr1Dao;

	@Autowired
	ClientFileUploadService clientFileUploadService;

	@Autowired
	ClientSpCallService clientSpCallService;

	@Autowired(required = false)
	private RedisTemplate redisTemplate;

	@Autowired
	private EntityModelDao entityModelDao;

	@Autowired
	private MasterTableService masterTableService;

	@Autowired(required=false)
	private EntityModel entityModel;

	@Autowired
	ErrorActionUtility errorActionUtility;

	@Autowired
	DueDateMasterDao dueDateMasterDao;

	// Added as a part of Sprint 1 to make GSTN call via gsp
	@Resource(name = "${api.call}")
	private CommonApiService commonApiService;


	@Autowired
	ReportDao reportDao;

	@Autowired
	private ReturnTypeDao returnTypeDao;

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	private static final Logger logger = Logger
			.getLogger(Gstr1ServiceImpl.class);
	private static final String CLASS_NAME = Gstr1ServiceImpl.class.getName();

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.service.gstr1.Gstr1Service#gstr1Summary(com.ey.advisory
	 * .asp.dto.YearMonthDto) Makes GSTN call Directly or GSTN call via GSP
	 * based on the gsp.enabled property value
	 */
	@Override
	public String gstr1Summary(String gstin, String month, String year) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+" gstr1Summary");
		String jsonDataValue = "";

		AuthDetailsDto authDetails = authenticationUtility
				.validateAuthToken("");
		String result = commonApiService.gstr1Summary(gstin, month, year);

		try {
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result,
					authDetails);
			logger.info("Exiting " + CLASS_NAME +Constant.LOGGER_METHOD+" gstr1Summary");
			return jsonDataValue;
		} catch (Exception e) {
			logger.error("Exiting " + CLASS_NAME +Constant.LOGGER_METHOD+" gstr1Summary",e);
			return e.getMessage();
		}
	}

	@Override
	public Object getGSTR1SummaryfromDB(String gstn, String taxPeriod) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getGSTR1SummaryfromDB");
		List<?> result = null;
		StringBuffer jsonRes = new StringBuffer();
		Object[] obj = new Object[2];
		obj[0] = gstn;
		obj[1] = taxPeriod;
		try {

			result = hibernateDao.executeNativeSql(
					" exec dbo.uspGetGSTR1SummaryDetails ?, ? ", obj);
			if(result!=null && !result.isEmpty()){
				for(int i=0;i<result.size();i++){
					jsonRes.append(result.get((i)));
				}
			}
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+" Method : getGSTR1SummaryfromDB", e);
		}
		logger.info("Exiting " + CLASS_NAME +Constant.LOGGER_METHOD+" getGSTR1SummaryfromDB");
		return jsonRes.toString();
	}

	/**
	 * this method is used to update the Invoice status,type in database
	 * 
	 * @param InvoiceList
	 * @param fileId
	 * 
	 * @return save status
	 */
	@Override
	public boolean saveInvoiceStatus(Set<InvoiceProcessDto> invoice,Integer fileId) throws Exception{

		return invoiceDao.saveInvoiceStatus(invoice,fileId);
	}

	/**
	 * this method is used to update the Invoice status,type in database
	 * 
	 * @param InvoiceList
	 * @param fileId
	 * 
	 * @return save status
	 */
	@Override
	public boolean timeoutAndSaveInvoiceStatus(Set<InvoiceProcessDto> invoice,Integer fileId) throws Exception{

		return invoiceDao.saveInvoiceStatus(invoice,fileId);
	}

	/**
	 * this method is used to update the Invoice status to TECH_ERROR
	 * 
	 * @param InvoiceList
	 * @param fileId
	 * 
	 * @return save status
	 */
	@Override
	public boolean timeoutAndMarkInvoiceStatusTechError(Integer fileId) throws Exception{

		return invoiceDao.markTechErrorInvoiceStatus(fileId);
	}


	/**
	 * this method is used to save the ErrorInfo of rules applied on staging
	 * table in database
	 * 
	 * @param ErrorInfo
	 *            List
	 */
	@Override
	public boolean saveSalesErrorInfo(Set<TblSalesErrorInfo> errorInfo) throws Exception{
		return saveMailStatusDetailsInfo(errorInfo) && invoiceDao.saveSalesErrorInfo(errorInfo);
	}

	/**
	 * this method is used to save the ErrorInfo of rules applied on staging
	 * table in database
	 * 
	 * @param ErrorInfo
	 *            List
	 */
	@Override
	public boolean timeoutAndSaveSalesErrorInfo(Set<TblSalesErrorInfo> errorInfo) throws Exception{
		return saveMailStatusDetailsInfo(errorInfo) && invoiceDao.saveSalesErrorInfo(errorInfo);
	}

	private boolean saveMailStatusDetailsInfo(Set<TblSalesErrorInfo> errorList) {

		Set<String> gstinList = new HashSet<>();
		boolean status = Boolean.TRUE;
		for (TblSalesErrorInfo tblSalesErrorInfo : errorList) {
			if(tblSalesErrorInfo.getGstin() != null && !tblSalesErrorInfo.getGstin().isEmpty()){
				gstinList.add(tblSalesErrorInfo.getGstin());
			}
		}
		if(!gstinList.isEmpty()){
			status = invoiceDao.saveMailStatusDetailsInfo(gstinList, Constant.MAILSTATUS_RETURNTYPE_GSTR1);
		}
		return status;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.service.gstr1.Gstr1Service#sendGSTR1Data(int,
	 * java.lang.String) This method is used to send data to gstn
	 */
	@Override
	public String sendGSTR1Data(String jsonGstr1Data,String gstinNum) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" sendGSTR1Data");
		String jsonDataValue = null;
		String gsptransid = null;
		String transid = null;
		String result = null;
		try {
			AuthDetailsDto authDetails = authenticationUtility
					.validateAuthToken(jsonGstr1Data);
			result = commonApiService.sendGSTR1Data(authDetails);
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result,
					authDetails);
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject) jsonParser
					.parse(jsonDataValue);
			transid = (String) jsonObject.get("trans_id");
			updateGstnTranId(gsptransid, transid,gstinNum);
		} catch (Exception exec) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" sendGSTR1Data" ,exec);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" sendGSTR1Data");
		return null;
	}

	/**
	 * this method is used to save transaction id in database
	 * 
	 * @param gsptrnsId
	 * @param gstnTransId
	 * @param fileId
	 */
	@SuppressWarnings("unchecked")
	private void updateGstnTranId(String gsptrnsId, String gstnTransId,
			String gstinNum) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateGstnTranId()");
		try {

			PayloadStatus payloadStatus = new PayloadStatus();
			payloadStatus.setGsptransId(gsptrnsId);
			payloadStatus.setTaxPayerGstin(gstinNum);
			payloadStatus.setUpdateDate(new Date());
			payloadStatus.setGstntransId(gstnTransId);
			hibernateDao.save(payloadStatus);


		} catch (Exception exec) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" updateGstnTranId()" ,exec);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateGstnTranId()");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.service.gstr1.Gstr1Service#getReturnFilingDetails
	 * get filingdetails
	 */


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.service.gstr1.Gstr1Service#getReturnFilingDetails
	 * get filingdetails
	 */
	@Override
	public TblGstinRetutnFilingStatus getGStrReturnFilingDetails(String gstnID, String taxPeriod,String returnType) {

		return returnFilingDao.fetchGstrReturnDetails(gstnID, taxPeriod,returnType);

	}

	/**
	 * this method is used to update transaction status in database
	 * 
	 * @param status
	 * @param gstnTransId
	 */
	@Override
	public void updateTransactionStatus(PayloadStatus payloadDetails) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateTransactionStatus()");
		try {

			hibernateDao.update(payloadDetails);

		} catch (Exception exec) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" updateTransactionStatus()" ,exec);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateTransactionStatus()");
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public <T> List<T> validateOriginalDocumentNo(OutwardInvoiceDTO outwardInvoiceDTO,
			String entityName, String columnName) {

		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" validateOriginalDocumentNo()");

		List<T> entityList = null;
		if (outwardInvoiceDTO.getLineItemList() != null
				&& !outwardInvoiceDTO.getLineItemList().isEmpty()) {
			OutwardInvoiceModel lineItem = outwardInvoiceDTO.getLineItemList()
					.get(0);

			try {
				if((lineItem.getDocumentType().equals(Constant.CR) || lineItem.getDocumentType().equals(Constant.DR)) && 
						lineItem.getcRDRPreGST()!=null && (lineItem.getcRDRPreGST().equalsIgnoreCase(Constant.Y))){
					return entityList;
				}

				if(Constant.EXPA.equalsIgnoreCase(lineItem.getTableType())) {
					entityList = gstr1Dao.validateOriginalDocumentNoInGSTN(
							lineItem.getOriginalDocumentNo(), entityName, columnName);
				} else if(lineItem.getDocumentType().equals(Constant.CR) || lineItem.getDocumentType().equals(Constant.DR)) {
					entityList = gstr1Dao.validateOriginalDocumentNoForCR(
							lineItem.getOriginalDocumentNo(), entityName,
							columnName, Constant.INV);
				} else if(lineItem.getDocumentType().equals(Constant.RCR) || lineItem.getDocumentType().equals(Constant.RDR)
						|| lineItem.getDocumentType().equals(Constant.RNV)) {
					entityList = gstr1Dao.validateOriginalDocumentNoForRCRRDR(
							lineItem.getOriginalDocumentNo(), entityName,
							columnName, getOriginalDocType(lineItem.getDocumentType()));
				}
				if (entityList == null || entityList.isEmpty()) {

					outwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
					lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
					if(lineItem.getDocumentType().equals(Constant.RCR)) {
						outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER211", Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
					} else if(lineItem.getDocumentType().equals(Constant.RDR)) {
						outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER212", Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
					} 
					else{
						outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER208", Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE, Constant.INVOICE));
					}
				}
			} catch (Exception e) {
				logger.info(
						Constant.LOGGER_ERROR
						+ CLASS_NAME
						+Constant.LOGGER_METHOD+" validateOriginalDocumentNo(). Unable to validate Original Doc Num for Invoice: "
						+ lineItem.getId(), e);
			}
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" validateOriginalDocumentNo()");

		return entityList;

	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public boolean isValidAmendment(OutwardInvoiceDTO outwardInvoiceDTO,
			String entityName, String columnName) {

		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" isValidAmendment()");

		if (outwardInvoiceDTO.getLineItemList() != null
				&& !outwardInvoiceDTO.getLineItemList().isEmpty()) {
			OutwardInvoiceModel lineItem = outwardInvoiceDTO.getLineItemList()
					.get(0);

			try {
				List<Object> entityList = null;
				if(lineItem.getDocumentType().equals(Constant.CR) || lineItem.getDocumentType().equals(Constant.DR)) {
					entityList = gstr1Dao.isValidAmendment(
							lineItem.getOriginalDocumentNo(), entityName, columnName);
				} else {
					entityList = gstr1Dao.isValidAmendmentGSTN(
							lineItem.getOriginalDocumentNo(), entityName, columnName);
				}
				if (entityList != null && entityList.size() > Constant.AMENDMENT_THRESHOLD) {
					outwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
					lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
					outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER222", Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));

					return Boolean.FALSE;
				}
			} catch (Exception e) {
				logger.info(
						Constant.LOGGER_ERROR
						+ CLASS_NAME
						+Constant.LOGGER_METHOD+" validateOriginalDocumentNo(). Unable to validate Amendment for Invoice: "
						+ lineItem.getId(), e);
			}
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" validateOriginalDocumentNo()");
		return Boolean.TRUE;

	}

	@Override
	public <T> T getEntityByColumn(String entityName, String colunName,
			Object columnValue) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getEntityByColumn()");

		try {
			return gstr1Dao.getEntityByColumn(entityName, colunName,
					columnValue);

		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" getEntityByColumn(). Unable to fetch entity: "
					+ entityName + " by Column: " + colunName, e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getEntityByColumn()");
		return null;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public List<OutwardInvoiceModel> validateOriginalInvoice(OutwardInvoiceDTO outwardInvoiceDTO,
			String entityName, String columnName, String orgInvNum) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" validateOriginalInvoice()");

		List<OutwardInvoiceModel> origInvoiceList = null;

		if (outwardInvoiceDTO.getLineItemList() != null
				&& !outwardInvoiceDTO.getLineItemList().isEmpty()) {
			OutwardInvoiceModel lineItem = outwardInvoiceDTO.getLineItemList()
					.get(0);

			try {
				List<OutwardInvoiceModel> entityList = null;
				if(lineItem.getDocumentType().equals(Constant.RCR) || lineItem.getDocumentType().equals(Constant.RDR)) {
					entityList = gstr1Dao.validateOriginalDocumentNoForCR(
							orgInvNum, entityName, columnName, Constant.INV);

					if (entityList == null || entityList.isEmpty()) {
						outwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
						lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
						outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER208",Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
					}else{
						origInvoiceList = entityList;
					}
				}
			} catch (Exception e) {
				logger.info(
						Constant.LOGGER_ERROR
						+ CLASS_NAME
						+Constant.LOGGER_METHOD+" validateOriginalInvoice(). Unable to validate Original Inv Num for Invoice: "
						+ lineItem.getId(), e);
			}
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" validateOriginalInvoice()");

		}
		return origInvoiceList;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public <T> List<T> validateOriginalDocNoDocDate(
			OutwardInvoiceDTO outwardInvoiceDTO, String entityName,
			String column1, String column2) {

		List<T> entityList = null;

		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" validateOriginalDocNoDocDate()");


		if (outwardInvoiceDTO.getLineItemList() != null
				&& !outwardInvoiceDTO.getLineItemList().isEmpty()) {
			OutwardInvoiceModel lineItem = outwardInvoiceDTO.getLineItemList()
					.get(0);
//			if(gstr1Dao.isInvoicePresentInGSTN(lineItem.getInvoiceKey())) {
				try {

					if(lineItem.getDocumentDate() != null){	
						if(lineItem.getDocumentType().equals(Constant.CR) || lineItem.getDocumentType().equals(Constant.DR)
								|| lineItem.getTableType().equals(Constant.B2CS)) {
							entityList = gstr1Dao.validateOriginalDocNoDocDateForCRDR(lineItem.getDocumentNo(),
									lineItem.getDocumentDate(), entityName, column1, column2);
						}else {
							entityList = gstr1Dao.validateOriginalDocNoDocDate(lineItem.getDocumentNo(),
									lineItem.getDocumentDate(), entityName, column1, column2);
						}
					}else if(lineItem.getDocumentDate() == null && lineItem.getDocumentDateStr() != null){
						Date documentDate=null;
						logger.info("DocumentDateStr : "+ lineItem.getDocumentDateStr());
						documentDate = CommonUtillity.getDateByPattern(lineItem.getDocumentDateStr());
						if(lineItem.getDocumentType().equals(Constant.CR) || lineItem.getDocumentType().equals(Constant.DR)
								|| lineItem.getTableType().equals(Constant.B2CS)) {
							entityList = gstr1Dao.validateOriginalDocNoDocDateForCRDR(lineItem.getDocumentNo(),
									documentDate, entityName, column1, column2);
						}else {
							entityList = gstr1Dao.validateOriginalDocNoDocDate(lineItem.getDocumentNo(), documentDate, entityName, column1, column2);
						}
					}
				} catch (Exception e) {
					logger.info(
							Constant.LOGGER_ERROR
							+ CLASS_NAME
							+Constant.LOGGER_METHOD+" validateOriginalDocNoDocDate(). Unable to validate Original Doc Num for Invoice: "
							+ lineItem.getId(), e);
				}
//			}
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" validateOriginalDocNoDocDate()");

		return entityList;

	}

	@Override
	public String fileGSTR1(SummaryDto summarydto) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" fileGSTR1");
		String acknowledge = "";
		try {

			AuthDetailsDto authDetails = authenticationUtility
					.validateAuthToken("");
			SummaryDto finalDto = authenticationUtility.encryptPayloadData(
					summarydto, authDetails);
			String jsonDataValue = authenticationUtility
					.executeRestCallGSTNPost(authenticationUtility
							.fileGstrReqPayload(finalDto, Constant.RETSUBMIT),
							Constant.RETURNS, true, Constant.GSTR1);
			authDetails = authenticationUtility.getRek(jsonDataValue,
					authDetails);
			acknowledge = authenticationUtility.getPayloadForGSTN(
					jsonDataValue, authDetails);
			returnFilingDao.insertReturnFilingData(summarydto.getGstinId(),Constant.GSTR1_Filing,summarydto.getTaxPeriod(),acknowledge);
		} catch (Exception ex) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" fileGSTR1",ex);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" fileGSTR1");
		return acknowledge;
	}


	@SuppressWarnings("unchecked")
	@Override
	public EntityModel getEntityDetails(String pan){



		DetachedCriteria detachedCriteria =
				hibernateDao.createCriteria(EntityModel.class);

		detachedCriteria.add(Restrictions.eq("pan", pan));

		List<EntityModel> entityDetails = (List<EntityModel>) hibernateDao.find(detachedCriteria);

		EntityModel entity = null;

		if(entityDetails!=null && !entityDetails.isEmpty() ){
			entity = entityDetails.get(0);
		}
		return entity;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public void validateInvoiceDate(OutwardInvoiceDTO outwardInvoiceDTO, String taxperiod) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" validateInvoiceDate()");

		Date annualFilingDate = null;
		OutwardInvoiceModel lineItem = outwardInvoiceDTO.getLineItemList().get(0);
		Date documentDate = null;
		if(lineItem.getDocumentDate() != null){
			documentDate = lineItem.getDocumentDate();
		}else if(lineItem.getDocumentDate() == null && lineItem.getDocumentDateStr() != null){
			try {
				documentDate = CommonUtillity.getDateByPattern(lineItem.getDocumentDateStr());
			} catch (ParseException e) {
				logger.info(
						Constant.LOGGER_ERROR
						+ CLASS_NAME
						+Constant.LOGGER_METHOD+" validateInvoiceDate(). Unable to parse DocumentDate String: "
						+ lineItem.getDocumentDateStr(), e);
			}
		}

		Date cutOffStartDate = getCutOffStartDate(documentDate);
		Date cutOffEndDate = getCutOffEndDate(documentDate);
		Date taxPeriodDate = null;

		try {
			taxPeriodDate = CommonUtillity.getDateByPattern(taxperiod);        	
			annualFilingDate = returnFilingDao.getReturnFilingDate(
					getFY(documentDate),
					lineItem.getsGSTIN(), "GSTR9");
		} catch (Exception e) {
			logger.info(
					Constant.LOGGER_ERROR
					+ CLASS_NAME
					+Constant.LOGGER_METHOD+" validateInvoiceDate(). Unable to validate Amendment for Invoice: "
					+ lineItem.getId(), e);
		}

		if(annualFilingDate != null && annualFilingDate.before(cutOffEndDate)){
			cutOffEndDate = annualFilingDate;
		}

		if(taxPeriodDate!=null && taxPeriodDate.after(cutOffStartDate) && taxPeriodDate.before(cutOffEndDate)){
			outwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
			lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
			String columnNames = Constant.DOC_NO + "," +Constant.DOC_DATE;
			if(lineItem.getDocumentType().equals(Constant.CR)) {
				outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER246", columnNames,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
			} else if(lineItem.getDocumentType().equals(Constant.DR)) {
				outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER247", columnNames,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
			} else{
				outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER207", columnNames,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
			}
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME  +Constant.LOGGER_METHOD+" validateInvoiceDate()");

	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public void isValidAmendmentDate(OutwardInvoiceDTO outwardInvoiceDTO) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" isValidAmendmentDate()");
	/*	Date annualFilingDate = null;
		OutwardInvoiceModel lineItem = outwardInvoiceDTO.getLineItemList().get(0);

		if(lineItem != null){
				Date cutOffdate = getCutOffdateForAmendment(lineItem.getOriginalDocumentDate());
				Date documentDate = null;
				if(lineItem.getDocumentDate() != null){
					documentDate = lineItem.getDocumentDate();
				} else if(lineItem.getDocumentDate() == null && lineItem.getDocumentDateStr() != null)  {
					try {
						logger.info("DocumentDateStr : "+ lineItem.getDocumentDateStr());
						documentDate = CommonUtillity.getDateByPattern(lineItem.getDocumentDateStr());
					} catch (Exception e) {
						logger.error("Unable to parse date : "+ lineItem.getDocumentDateStr());
					}
				}

				Date amendmentDate = documentDate;
				try {
					annualFilingDate = returnFilingDao.getReturnFilingDate(
							getFY(lineItem.getOriginalDocumentDate()),
							lineItem.getsGSTIN(), "GSTR9");
				} catch (Exception e) {
					logger.info(
							Constant.LOGGER_ERROR
							+ CLASS_NAME
							+Constant.LOGGER_METHOD+" isValidAmendmentDate(). Unable to validate Amendment Date for Invoice: "
							+ lineItem.getId(), e);
				}
				if (cutOffdate != null) {
					if (annualFilingDate != null && annualFilingDate.before(cutOffdate)) {
						cutOffdate = annualFilingDate;
					}
					if (amendmentDate!=null && amendmentDate.after(cutOffdate)) {
						outwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
						lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
						if(lineItem.getDocumentType().equals(Constant.RCR)) {
							outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER214",Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
						} else if(lineItem.getDocumentType().equals(Constant.RDR)) {
							outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER215",Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
						}else if(lineItem.getDocumentType().equalsIgnoreCase(Constant.CR)){
							outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER239", Constant.ORG_DOC_NO, Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
						}else {
							outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER209",Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
						}
					}
				}


				if(cutOffdate != null && lineItem.getDocumentType().equals(Constant.CR)) {
					Calendar currentDate = Calendar.getInstance();
					if(annualFilingDate!=null && annualFilingDate.before(cutOffdate)) {
						if(currentDate.after(annualFilingDate)) {
							outwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
							outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER231",Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE)); 
						}
					} else {
						Calendar cutoffDatePlus20 = Calendar.getInstance();
						cutoffDatePlus20.setTime(cutOffdate);
						cutoffDatePlus20.add(Calendar.DATE, 20);

						if(currentDate.after(cutoffDatePlus20)) {
							outwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
							outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER231",Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
						}
					}
				}
		}*/
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" isValidAmendmentDate()");

	}

	private String getFY(Date originalDocumentDate) {
		String fy = null;
		if(originalDocumentDate != null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(originalDocumentDate);
			int month = cal.get(Calendar.MONTH);
			int year = cal.get(Calendar.YEAR);
			if(month < Calendar.APRIL){
				fy = String.valueOf(year - 1)+String.valueOf(year);
			}else{
				fy = String.valueOf(year)+String.valueOf(year+1);
			}
		}
		return fy;
	}

	private Date getCutOffdateForAmendment(Date documentDate) {
		if(documentDate != null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(documentDate);
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			if(month < Calendar.APRIL){
				cal.set(year, Constant.CUTOFF_END_MONTH, Constant.CUTOFF_END_DATE);
			}else{
				cal.set(year+1,Constant.CUTOFF_END_MONTH, Constant.CUTOFF_END_DATE);
			}
			return cal.getTime();
		}
		return null;
	}

	private Date getCutOffStartDate(Date documentDate) {
		if(documentDate != null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(documentDate);
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);

			if(month < Calendar.OCTOBER){
				cal.set(year-1, Constant.CUTOFF_START_MONTH, Constant.CUTOFF_START_DATE);
			}else{
				cal.set(year, Constant.CUTOFF_START_MONTH, Constant.CUTOFF_START_DATE);
			}
			return cal.getTime();
		}
		return null;
	}

	private Date getCutOffEndDate(Date documentDate){
		if(documentDate != null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(documentDate);
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);

			cal.set(year, month-1, 1);
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			return cal.getTime();
		}
		return null;
	}

	@Override
	public boolean isValidTaxPeriod(String origTaxPeriod, String amendTaxPeriod) {
		if(origTaxPeriod != null && !origTaxPeriod.isEmpty() && amendTaxPeriod != null && !amendTaxPeriod.isEmpty()){
			Calendar orig = Calendar.getInstance();
			Calendar amend = Calendar.getInstance();

			try {
				orig.setTime(CommonUtillity.getDateByPattern(origTaxPeriod));
				amend.setTime(CommonUtillity.getDateByPattern(amendTaxPeriod));
			} catch (ParseException e) {
				logger.error("could not parse date :" + origTaxPeriod +" or " +amendTaxPeriod, e);
			}
			if((orig.get(Calendar.YEAR) + 1 == amend.get(Calendar.YEAR) && orig.get(Calendar.MONTH) >= Calendar.APRIL)
					|| (orig.get(Calendar.YEAR) == amend.get(Calendar.YEAR) && orig.get(Calendar.MONTH) < amend.get(Calendar.MONTH))){
				return true;
			}
		}
		return false;
	}

	@Override
	public void setErrorList(Set<TblSalesErrorInfo> errorList, OutwardInvoiceModel outwardInvoiceModel, String errorInfoCode,
			String errorColumnNames, String processStatus, boolean isProcessed, String incidenceLevel) {
		if(errorList == null){
			errorList = new HashSet<>();
		}

		errorList.add(errorActionUtility.getSalesTblErrorInfo(outwardInvoiceModel, errorInfoCode, errorColumnNames, processStatus, isProcessed,incidenceLevel));

	}

	@Override
	public void updatePipeStageStatus(List<String>  fileUploadStatus){


		int fileId=Integer.parseInt(fileUploadStatus.get(0));
		String fName= fileUploadStatus.get(1);
		List<TblFileUploadStatus> entity =  (List<TblFileUploadStatus>) hibernateDao.find("from TblFileUploadStatus where fileId=?" , fileId);

		//set the value which has to be updated
		for(TblFileUploadStatus tblFileUploadStatus : entity){
			tblFileUploadStatus.setfName(fName);
			tblFileUploadStatus.setFileId(fileId);
			hibernateDao.update(tblFileUploadStatus);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getReturnFilingDetailsForDropDown(JSONObject inputParams, List<String> returnType) {

		JSONObject obj = new JSONObject();
		String sGSTIN = inputParams.get("gstnid").toString();
		String status = inputParams.get("status").toString();
		boolean eFiled = Boolean.valueOf(inputParams.get("eFiled").toString());

		List<TblGstinRetutnFilingStatus> returnFiling = returnFilingDao.getReturnFilingDetails(returnType, sGSTIN,
				status, eFiled);
		StringBuilder str = new StringBuilder();
		if (null != returnFiling && !returnFiling.isEmpty()) {
			returnFiling.stream().forEach(action -> {
				str.append(action.getId().getTaxPeriod() + "_" + action.getId().getReturnType() + "|");
			});
		}

		obj.put("RETURN_FILING_DETAILS", str.toString());
		return obj.toString();
	}

	/*@SuppressWarnings("unchecked")
	@Override
	public String getReturnFilingDetails(JSONObject inputParams, List<String> returnType){

		HashMap<String, String> dueDateMap = new HashMap<>();
		JSONObject obj = new JSONObject();	
		String returnPeriod = inputParams.get("returnPeriod").toString();
		String sGSTIN = inputParams.get("gstnid").toString();
		String status = inputParams.get("status").toString();
		boolean eFiled = Boolean.valueOf(inputParams.get("eFiled").toString()); 
		List<String> returnPeriodList = new ArrayList<>();
		String[] splitStr = returnPeriod.split("\\s+");
		int month = Month.valueOf(splitStr[0].toUpperCase()).getValue();
		String monthVal = (month) < 10 ? Constant.zero + String.valueOf(month) : String.valueOf(month);
		returnPeriodList.add(String.valueOf(monthVal)+String.valueOf(splitStr[1]));

		if(!eFiled){
			List<DueDateMaster> dueDateMaster= dueDateMasterDao.getGstinDueDateMaster(returnType, sGSTIN);
			dueDateMaster.forEach(item -> {
				dueDateMap.put(item.getApplicableReturn(), String.valueOf(item.getGstnMandatedDate()));
			});
		}

		List<TblGstinRetutnFilingStatus> returnFiling = returnFilingDao.getReturnFilingDetails(returnPeriodList,  returnType, sGSTIN, status,  eFiled);
		if(null!=returnFiling && !returnFiling.isEmpty()){
			returnFiling.stream().forEach(action -> {
				if(!obj.containsKey(dueDateMap.get(action.getId().getReturnType())))
					obj.put(action.getId().getReturnType(), String.valueOf(dueDateMap.get(action.getId().getReturnType())));
			});
		}
		return obj.toString();   
	}
*/
	public List<TblGstinRetutnFilingStatus> getReturnFilingDetails(JSONObject inputParams, List<String> returnType){

		HashMap<String, String> dueDateMap = new HashMap<>();
		JSONObject obj = new JSONObject();	
		String returnPeriod = inputParams.get("returnPeriod").toString();
		String sGSTIN = inputParams.get("gstnid").toString();
		String status = inputParams.get("status").toString();
		boolean eFiled = Boolean.valueOf(inputParams.get("eFiled").toString()); 
		List<String> returnPeriodList = new ArrayList<>();
		String[] splitStr = returnPeriod.split("\\s+");
		int month = Month.valueOf(splitStr[0].toUpperCase()).getValue();
		String monthVal = (month) < 10 ? Constant.zero + String.valueOf(month) : String.valueOf(month);
		returnPeriodList.add(String.valueOf(monthVal)+String.valueOf(splitStr[1]));

		/*if(!eFiled){
			List<DueDateMaster> dueDateMaster= dueDateMasterDao.getGstinDueDateMaster(returnType, sGSTIN);
			dueDateMaster.forEach(item -> {
				dueDateMap.put(item.getApplicableReturn(), String.valueOf(item.getGstnMandatedDate()));
			});
		}*/

		List<TblGstinRetutnFilingStatus> returnFiling = returnFilingDao.getReturnFilingDetails(returnPeriodList,  returnType, sGSTIN, status,  eFiled);
		/*if(null!=returnFiling && !returnFiling.isEmpty()){
			returnFiling.stream().forEach(action -> {
				if(!obj.containsKey(dueDateMap.get(action.getId().getReturnType())))
					obj.put(action.getId().getReturnType(), String.valueOf(dueDateMap.get(action.getId().getReturnType())));
			});
		}
		return obj.toString();   */
		return returnFiling;
	}
	
	@Override
	public String getEFilingSummary(List<String>  inputParams){

		String returnName = inputParams.get(0);
		String returnPeriod = inputParams.get(1);
		String sGSTIN = inputParams.get(2);
		String filedStatus = inputParams.get(3);
		boolean isSuccess = Boolean.parseBoolean(inputParams.get(4));

		TblGstinRetutnFilingStatus returnFiling = returnFilingDao.getEFilingSummary(returnPeriod, sGSTIN, returnName, filedStatus, isSuccess);
		if(null == returnFiling){
			return "1";
		}
		return "0";
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getGstinDueDateMaster(List<String> inputParams){

		String returnType = inputParams.get(0);
		String sGSTIN = inputParams.get(2);
		List<String> returnTypeList = new ArrayList<>();
		returnTypeList.add(returnType);

		JSONObject obj = new JSONObject();	

		List<DueDateMaster> dueDateMaster= dueDateMasterDao.getGstinDueDateMaster(returnTypeList, sGSTIN);
		dueDateMaster.forEach(item -> {
			if(!obj.containsKey(item.getApplicableReturn()))
				obj.put(item.getApplicableReturn(), String.valueOf(item.getGstnMandatedDate()));

		});
		return obj.toString();
	}

	@Override
	public List<Object[]> getCounterPartySupplyTypes(String sgstin, String taxPeriod) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCounterPartySupplyTypes");
		List<Object[]> supplyTypesData=null;

		DetachedCriteria criteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
		ProjectionList projList = Projections.projectionList();
		projList.add(Projections.property("cGSTIN"));
		projList.add(Projections.property("customerName"));
		criteria.add(Restrictions.eq("sGSTIN", sgstin));
		criteria.add(Restrictions.in("tableType", CommonUtillity.cptyGstr1SupplyType()));
		criteria.add(Restrictions.eq("taxperiod", taxPeriod));
		criteria.add(Restrictions.eq("isError", false));
		criteria.setProjection(Projections.distinct(projList));

		try {
			supplyTypesData = (List<Object[]>) hibernateDao.find(criteria);
		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" getCounterPartySupplyTypes",e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCounterPartySupplyTypes");
		return supplyTypesData;
	}

	@Override
	public int getAffectedInvoiceCountForGstin(String gstin,String processType) {
		return invoiceDao.getAffectedInvoiceCountForGstin(gstin,processType);
	}



	/**
	 * This Method For ErrorCode & Description showing from db using gstin for GSTR1 
	 * @throws IOException
	 */
	@Override
	public List<Map<String, Object>> fetchGSTR1ErrorCodeDetails(String gstn) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+" fetchGSTR1ErrorCodeDetails()");
		List<Map<String, Object>> errorCodeDetailsList = new ArrayList<>();
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblSalesErrorInfo.class);
			detachedCriteria.add(Restrictions.eq("gstin",gstn));
			detachedCriteria.add(Restrictions.eq("isProcessed",false));
			detachedCriteria.setProjection(Projections.projectionList().add(Projections.max("updatedDate"))
					.add(Projections.groupProperty("errorInfoCode")).add(Projections.groupProperty("errorDesc")));
			List<Object[]> errorCodeDetailsResult = (List<Object[]>) hibernateDao.find(detachedCriteria);
			if (errorCodeDetailsResult != null && !errorCodeDetailsResult.isEmpty()) {
				for (Object[] errorCodeDetail : errorCodeDetailsResult) {

					Map<String, Object> detailMap = new HashMap<>();
					detailMap.put("errorCode", (String) errorCodeDetail[1]);
					detailMap.put("errorDesc", (String) errorCodeDetail[2]);
					if (errorCodeDetail[0] != null && !errorCodeDetail[0].getClass().equals(String.class)) {
						DateFormat df = new SimpleDateFormat("dd/MM/YYYY HH:MM:SS");
						String lastUpdateDate = df.format((Date) errorCodeDetail[0]);
						detailMap.put("lastUpdated", lastUpdateDate);
					} else {
						detailMap.put("lastUpdated","");//If Date is NULL in database show empty on screen.
					}
					errorCodeDetailsList.add(detailMap);
				}
			}
		} catch (Exception ex) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+" fetchGSTR1ErrorCodeDetails()" ,ex);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" fetchGSTR1ErrorCodeDetails()");
		return errorCodeDetailsList;
	}

	@Override
	public void updateMailStatus(List<TblEmailStatusDetails> notifiedGstinList) {

		List<TblEmailStatusDetails> toBeUpdatedStatusList=new ArrayList<>();
		try{
			for(TblEmailStatusDetails tblEmailStatusDetails : notifiedGstinList){
				List<TblEmailStatusDetails> statusList=(List<TblEmailStatusDetails>) hibernateDao.find("from TblEmailStatusDetails where gstin=? and returnType=?" , tblEmailStatusDetails.getGstin(),tblEmailStatusDetails.getReturnType());
				if(statusList!=null && !statusList.isEmpty()){
					TblEmailStatusDetails status=statusList.get(0);
					status.setEmailFlag(Boolean.FALSE);
					toBeUpdatedStatusList.add(status);
				}
			}
			if(!toBeUpdatedStatusList.isEmpty())
				hibernateDao.saveOrUpdateAll(toBeUpdatedStatusList);
		}
		catch(Exception e){
			logger.error(Constant.LOGGER_EXITING + CLASS_NAME
					+Constant.LOGGER_METHOD+" updateMailStatus",e);
		}
	}


	@Override
	public List<TblFileUploadStatus> fetchFileDetailsList(int fileId) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblFileUploadStatus.class);
		detachedCriteria.add(Restrictions.eq("fileId",fileId));
		List<TblFileUploadStatus> entity = (List<TblFileUploadStatus>) hibernateDao.find(detachedCriteria);
		return entity;
	} 

	@Override
	public String getReturnFilingSuccess(String gstinId, String taxPeriod){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+" getReturnFilingSuccess");
		String isFilingAllowed = returnFilingDao.getReturnFilingSuccess(gstinId, Constant.GSTR_1, taxPeriod);
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getReturnFilingSuccess");
		return isFilingAllowed;
	}

	@Override
	public List<TblGstinRetutnFilingStatus> getReturnFilingDetailsForGSTR1A(String returnPeriod, String returnName, String retFilingStatus, boolean status){

		List<TblGstinRetutnFilingStatus> returnFiling = returnFilingDao.getReturnFilingDetailsForGSTR1A(returnPeriod, returnName, retFilingStatus, status);
		return returnFiling;

	}


	@Override
	public void updateRefTxnID(String gstin,String txprd,String ref_id, String submitted) throws Exception{
		returnFilingDao.updateReturnFilingDetailsForSubmit(gstin,txprd,ref_id, submitted);


	}
	
//	public void updateFailedStatus(String gstin, String txprd,String submitted, String errorMsg) {
//		returnFilingDao.upDateReturnFilingDetailsForSubmitFailStatus(gstin, txprd, submitted, errorMsg);
//	}


	@Override
	public void updateStageAndJobStatus(String stage, String jobStatus,
			int fileId) {
		List<TblFileUploadStatus> entity =  (List<TblFileUploadStatus>) hibernateDao.find("from TblFileUploadStatus where fileId=?" , fileId);

		for(TblFileUploadStatus tblFileUploadStatus : entity){
			tblFileUploadStatus.setStatus(jobStatus);
			tblFileUploadStatus.setStage(stage);
			hibernateDao.update(tblFileUploadStatus);
		}
	}

	@Override
	public List<String> fetchFileList(String stage, String jobStatus, int fileId) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblFileUploadStatus.class);
		detachedCriteria.add(Restrictions.eq("fileId",fileId));
		detachedCriteria.add(Restrictions.eq("stage",stage));
		detachedCriteria.add(Restrictions.eq("status",jobStatus));
		detachedCriteria.setProjection(Projections.projectionList().add(Projections.property("fileId")));
		List<String> entity = (List<String>) hibernateDao.find(detachedCriteria);
		return entity;
	}

	@Override
	public List<String> getErrorReportDetails(JSONObject jsonObj){
		Object[] errorData= (Object[])reportDao.getErrorReportDetails(jsonObj);
		List<String> errorDtls=new ArrayList<String>();			
		for(Object ob:errorData){
			if(ob!=null){			
				//for(int i=0; i<errorData.length; i++)
					errorDtls.add(ob.toString());
			}
		}
		return	errorDtls;
	} 

	/**
	 * this method is used to save transaction id in database
	 * 
	 * @param gsptrnsId
	 * @param gstnTransId
	 * @param refId 
	 * @param fileId
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void updateGstnTranId(String gsptrnsId, String transid,String gstinNum, String refId, Long chunkId) 
	{
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateGstnTranId()");
		List<String> inputParamsList = new ArrayList<>();
		try {
			inputParamsList.add(String.valueOf(chunkId));
			inputParamsList.add("");
			inputParamsList.add(refId);
			inputParamsList.add(transid);
			inputParamsList.add(null);
			inputParamsList.add(null);
			hibernateDao.executeStoredProcedure(Constant.DBO_SCHEMA,Constant.SAVE_PROC, "6", inputParamsList);

		} catch (Exception exec) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" updateGstnTranId()" ,exec);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateGstnTranId()");
	}

	@Override
	public List<ReturnType> getFileUploadTypelist() {

		return returnTypeDao.getFileUploadTypelist();

	}

	@Override
	public Object getRectifiedReportDetails(JSONObject obj) {
		return reportDao.getRectifiedReportDetails(obj);
	}

	@Override
	public CounterPartySalesDto getCounterPartySummary(String supplyGstin, String cgstin, String cname, 
			String taxperiod, String supplyType) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCounterPartySummary");
		CounterPartySalesDto gstinList=null;
		List<String> supplyTypes = new ArrayList<>();
		if(supplyType.equalsIgnoreCase(Constant.CDN)){
			supplyTypes.add(Constant.CR);
			supplyTypes.add(Constant.DR);
		}
		else if(supplyType.equalsIgnoreCase(Constant.CDNA)){
			supplyTypes.add(Constant.RCR);
			supplyTypes.add(Constant.RDR);
		}
		else
			supplyTypes.add(supplyType);
		
		DetachedCriteria criteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
		ProjectionList projList = Projections.projectionList();
		projList.add(Projections.countDistinct("documentNo"),"recCount");
		projList.add(Projections.sum("taxableValue"),"taxableValue");
		projList.add(Projections.sum("invoiceValue"),"invoiceValue");
		projList.add(Projections.sum("igstAmount"),"igstAmount");
		projList.add(Projections.sum("cgstAmount"),"cgstAmount");
		projList.add(Projections.sum("sgstAmount"),"sgstAmount");
		projList.add(Projections.sum("cessAmountAdvalorem"),"cessAmountAdvalorem");
		projList.add(Projections.sum("cessAmountSpecific"),"cessAmountSpecific");
		criteria.add(Restrictions.eq("sGSTIN", supplyGstin));
		criteria.add(Restrictions.in("tableType", supplyTypes));
		if(cgstin.equalsIgnoreCase("-"))
			criteria.add(Restrictions.isNull("cGSTIN"));
		else
			criteria.add(Restrictions.eq("cGSTIN", cgstin));
		if(cname.equalsIgnoreCase("-"))
			criteria.add(Restrictions.isNull("customerName"));
		else
			criteria.add(Restrictions.eq("customerName", cname));
		criteria.add(Restrictions.eq("taxperiod", taxperiod));
		criteria.add(Restrictions.eq("isDuplicate", false));
		criteria.add(Restrictions.eq("itemStatus", Constant.GSTR1_BR_STG1));
		criteria.setProjection(projList);
		criteria.setResultTransformer(Transformers.aliasToBean(CounterPartySalesDto.class));
		
		try{
			List<CounterPartySalesDto> dtoList = (List<CounterPartySalesDto>) hibernateDao.find(criteria);
			if(dtoList!=null && !dtoList.isEmpty()){
				gstinList = dtoList.get(0);
			}
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+" Method : getCounterPartySummary", e);
		}
		logger.info("Exiting " + CLASS_NAME +Constant.LOGGER_METHOD+" getCounterPartySummary");
		return gstinList;
	}

	@Override
	public String saveTblTypeErrLstAndRoute(String key) throws Exception {
		if (logger.isInfoEnabled()) {
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " routing()");
		}
		String routingResult = "";
		String result = Constant.SUCCESS;
		try {
			logger.info("file key " + key);
			Integer fileId = Integer.parseInt(key.split("_")[1]);
			String invCountKey= key + "_" + Constant.INVOICE_COUNT;
			String invStatusKey = key + "_" + Constant.INVOICE_STATUS;
			String invErrKey = key + "_" + Constant.INVOICE_ERROR_DETAILS;
			String invPsdKey=key + "_" +Constant.INVOICE_PSD_COUNT;
			String previousInvProcessedKey=key+"_"+Constant.PREV_INVOICE_PSD_COUNT;

			//logger.info("Before fetching from redis for file key : " + key);
			logger.info("invStatusKey of redis  " + invStatusKey);
			logger.info("invErrKey of redis  " + invErrKey);

			Integer origInvCount=(Integer) redisTemplate.opsForValue().get(invCountKey);
			Long invPsdCnt=redisTemplate.opsForHash().size(invPsdKey);
			
			List<FileUploadMasterClient> fileList=invoiceDao.getFileFromClientMaster(fileId.longValue());
			if(fileList!=null && !fileList.isEmpty()){
				FileUploadMasterClient clientFile=fileList.get(0);
				if(clientFile.getStage().equalsIgnoreCase(Constant.FILE_BIFURCATION_FLAG)){
					return Constant.DUPLICATE;
				}
			}

			List<InvoiceProcessDto> invoiceListTemp=  redisTemplate.opsForHash().values(invStatusKey);

			Set<InvoiceProcessDto> invoiceList=new HashSet<InvoiceProcessDto>(invoiceListTemp);

			/*Set<InvoiceProcessDto> invoiceList = (Set<InvoiceProcessDto>) redisTemplate
					.opsForHash().get(key, invStatusKey);
			Set<TblSalesErrorInfo> errorInfoList = (Set<TblSalesErrorInfo>) redisTemplate
					.opsForHash().get(key, invErrKey);*/

			List<Set<TblSalesErrorInfo>> errorList=  redisTemplate.opsForHash().values(invErrKey);
			Set<TblSalesErrorInfo> errorInfoList=new HashSet<TblSalesErrorInfo>();
			for(Set<TblSalesErrorInfo> errSet:errorList){
				errorInfoList.addAll(errSet);
			}

			//logger.info("InvoiceList " + invoiceList);
			//logger.info("ErrorList " + errorInfoList);

			if (errorInfoList == null && invoiceList == null) {
				logger.info("Business Stage 1 Failed:");
				clientFileUploadService.updateStageOneFailStatus(key);
			} else {
				try {
					if (invoiceList != null && !invoiceList.isEmpty()) {
						logger.info("InvoiceList Size" + invoiceList.size());
						saveInvoiceStatus(invoiceList, fileId);
					}
					if (errorInfoList != null && !errorInfoList.isEmpty()) {
						logger.info("Error Size" + errorInfoList.size());
						if(saveSalesErrorInfo(errorInfoList)){
							if(origInvCount.equals(invPsdCnt.intValue())){
								doGSTR1Bifurcation(fileId,key);
							}else{
								timeoutAndDoGSTR1Bifurcation(fileId,key);
							}
						}
					}else{
						if(origInvCount.equals(invPsdCnt.intValue())){
							doGSTR1Bifurcation(fileId,key);
						}else{
							timeoutAndDoGSTR1Bifurcation(fileId,key);
						}
					}



					/*List<String> inputParams = new ArrayList<String>();
					inputParams.add(fileId.toString());
					routingResult = clientSpCallService.executeStoredProcedure(
							Constant.Schema, Constant.Gstr1RoutingProcName,
							String.valueOf(inputParams.size()), inputParams);
					if (Constant.zero.equals(routingResult)) {
						logger.info("Routing Success:" + routingResult);
						clientFileUploadService.updateBifurcationjobStatus(key);
					}else{
						//TODO : Custom DBException
						throw new Exception("Routing procedure has an issue");
					}*/
					redisTemplate.delete(key);
					redisTemplate.delete(invStatusKey);
					redisTemplate.delete(invErrKey);
					redisTemplate.delete(invPsdKey);
					redisTemplate.delete(invCountKey);
					redisTemplate.delete(previousInvProcessedKey);
					//redisTemplate.opsForHash().delete(key, invStatusKey);
					//redisTemplate.opsForHash().delete(key, invErrKey);

				} catch (Exception e) {
					logger.info("Routing Failed:" + result);
					result = Constant.FAILED;
					clientFileUploadService.updateBifurcationjobFailStatus(key);
				}
			}
		}catch(JedisConnectionException jce){
			result = Constant.FAILED;
			logger.error("Error fecthing the redis Connection for GSTR1--"+key, jce);
			clientFileUploadService.updateStageOneFailStatus(key); //Yet to finalise - temp fix
		}catch (Exception e) {
			result = Constant.FAILED;
			logger.error("Error saving Invoice details for GSTR1--"+key, e);
			throw new Exception("Database Connection exception"); //TODO : Custom DBException
		}

		if (logger.isInfoEnabled()) {
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " saveTblTypeErrLstAndRoute()");
		}
		return result;
	}

	private void doGSTR1Bifurcation(Integer fileId,String redisKey) throws Exception{
		String routingResult = "";
		String fileChunkId = redisKey.split("_")[2];
		List<String> inputParams = new ArrayList<String>();
		inputParams.add(fileId.toString());
		inputParams.add(fileChunkId);
		/*routingResult = clientSpCallService.executeStoredProcedure(
		Constant.Schema, Constant.Gstr1RoutingProcName,
		String.valueOf(inputParams.size()), inputParams);*/
		routingResult = clientSpCallService.executeStoredProcedure(
		Constant.Schema, Constant.Gstr1RoutingChunkProcName,
		String.valueOf(inputParams.size()), inputParams);
		if (Constant.zero.equals(routingResult)) {
			logger.info("Routing Success:" + routingResult);
			//clientFileUploadService.updateBifurcationjobStatus(redisKey);
		}else{
			//TODO : Custom DBException
			throw new Exception("Routing procedure has an issue");
		}
	}

/*	@Override
	public String timeoutSaveTblTypeErrLstAndRoute(String key) throws Exception {
		if (logger.isInfoEnabled()) {
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " routing()");
		}
		String result = Constant.SUCCESS;
		try {
			logger.info("key " + key);
			Integer fileId = Integer.parseInt(key.split("_")[1]);
			String invStatusKey = key + "_" + Constant.INVOICE_STATUS;
			String invErrKey = key + "_" + Constant.INVOICE_ERROR_DETAILS;
			String invPsdKey=key + "_" +Constant.INVOICE_PSD_COUNT;
			String previousInvProcessedKey=key+"_"+Constant.PREV_INVOICE_PSD_COUNT;

			logger.info("Before fetching from redis for file key : " + key);
			logger.info("invStatusKey of redis  " + invStatusKey);
			logger.info("invErrKey of redis  " + invErrKey);

			List<InvoiceProcessDto> invoiceListTemp=  redisTemplate.opsForHash().values(invStatusKey);

			Set<InvoiceProcessDto> invoiceList=new HashSet<InvoiceProcessDto>(invoiceListTemp);		

			List<Set<TblSalesErrorInfo>> errorList=  redisTemplate.opsForHash().values(invErrKey);
			Set<TblSalesErrorInfo> errorInfoList=new HashSet<TblSalesErrorInfo>();
			for(Set<TblSalesErrorInfo> errSet:errorList){
				errorInfoList.addAll(errSet);
			}

			logger.info("Timeout InvoiceList " + invoiceList);
			logger.info("Timeout ErrorList " + errorInfoList);

			if (errorInfoList == null && invoiceList == null) {
				logger.info("Business Stage 1 Failed:");
				clientFileUploadService.updateStageOneFailStatus(key);
			} else {
				try {
					if (invoiceList != null && !invoiceList.isEmpty()) {
						logger.info("Timeout InvoiceList Size" + invoiceList.size());
						timeoutAndSaveInvoiceStatus(invoiceList, fileId);
					}
					if (errorInfoList != null && !errorInfoList.isEmpty()) {
						logger.info("Timeout Error Size" + errorInfoList.size());
						if(saveSalesErrorInfo(errorInfoList)){
							timeoutAndDoGSTR1Bifurcation(fileId,key);
						}
					}else{
						timeoutAndDoGSTR1Bifurcation(fileId,key);
					}				

					redisTemplate.delete(key);
					redisTemplate.delete(invStatusKey);
					redisTemplate.delete(invErrKey);
					redisTemplate.delete(invPsdKey);
					redisTemplate.delete(previousInvProcessedKey);

				} catch (Exception e) {
					logger.info("Timeout Routing Failed:" + result);
					result = Constant.FAILED;
					clientFileUploadService.updateBifurcationjobFailStatus(key);
				}
			}
		}catch(JedisConnectionException jce){
			result = Constant.FAILED;
			logger.error("Timeout Error fecthing the redis Connection for GSTR1--"+key, jce);
			clientFileUploadService.updateStageOneFailStatus(key); //Yet to finalise - temp fix
		}catch (Exception e) {
			result = Constant.FAILED;
			logger.error("Timeout Error saving Invoice details for GSTR1--"+key, e);
			throw new Exception("Database Connection exception"); //TODO : Custom DBException
		}

		if (logger.isInfoEnabled()) {
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " saveTblTypeErrLstAndRoute()");
		}
		return result;
	}
*/
	private void timeoutAndDoGSTR1Bifurcation(Integer fileId,String redisKey) throws Exception  {
		String routingResult = "";
		String fileChunkId = redisKey.split("_")[2];
		List<String> inputParams = new ArrayList<String>();
		inputParams.add(fileId.toString());
		inputParams.add(fileChunkId);	
		/*routingResult = clientSpCallService.executeStoredProcedure(
		Constant.Schema, Constant.Gstr1RoutingProcName,
		String.valueOf(inputParams.size()), inputParams);*/
		routingResult = clientSpCallService.executeStoredProcedure(
		Constant.Schema, Constant.Gstr1RoutingChunkProcName,
		String.valueOf(inputParams.size()), inputParams);
		if (Constant.zero.equals(routingResult)) {
			logger.info("Timeout Routing Success:" + routingResult);
			invoiceService.markTechErrorInvoiceStatus(fileId);
			//clientFileUploadService.timeoutAndUpdateBifurcationjobStatus(redisKey);
			
		}else{
			throw new Exception("GSTR 1 Timeout Routing procedure has an issue");
		}

	}

	@Override
	public void updateBillNoBillDate(long expInvoiceId, OutwardInvoiceModel lineItem) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateBillNoBillDate");
		try{
			DetachedCriteria detachedCriteria =
					hibernateDao.createCriteria(GSTR1EXP_Invoice.class);

			detachedCriteria.add(Restrictions.eq("id", expInvoiceId));

			List<GSTR1EXP_Invoice> invDetailsList = (List<GSTR1EXP_Invoice>) hibernateDao.find(detachedCriteria);

			if(invDetailsList !=null && !invDetailsList.isEmpty() ){
				GSTR1EXP_Invoice invDetails = invDetailsList.get(0);
				invDetails.setExpBillNo(lineItem.getShippingBillNo());
				invDetails.setExpBillDate(lineItem.getShippingBillDate());
				hibernateDao.saveOrUpdate(invDetails);
			}
		}catch(Exception e){
			logger.error("Error Updating Export Invoice Details for shipping no. and date", e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateBillNoBillDate");
	}

	@Override
	public List<GSTR1B2BCLEAInvoiceDetail> getCreditListForInvoice(String originalDocumentNo, Date originalDocumentDate) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCreditListForInvoice");
		List<GSTR1B2BCLEAInvoiceDetail> creditList = null;
		try{
			if(originalDocumentNo==null || originalDocumentNo.trim().isEmpty()){
				return null;
			}
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR1B2BCLEAInvoiceDetail.class);
			detachedCriteria.add(Restrictions.eq("orgInvNum", originalDocumentNo));
			detachedCriteria.add(Restrictions.eq("orgInvDate", originalDocumentDate));
			detachedCriteria.add(Restrictions.eq("category", Constant.CR));
			creditList = (List<GSTR1B2BCLEAInvoiceDetail>) hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			logger.error("Error fetching Credit List for Invoice" + originalDocumentNo, e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCreditListForInvoice");
		return creditList;
	}

	@Override
	public List<GSTR1B2CS_InvoiceDetail> getCreditListForB2CS(String originalDocumentNo, Date originalDocumentDate) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCreditListForB2CS");
		List<GSTR1B2CS_InvoiceDetail> creditList = null;
		try{
			if(originalDocumentNo==null || originalDocumentNo.trim().isEmpty()){
				return null;
			}
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR1B2CS_InvoiceDetail.class);
			detachedCriteria.add(Restrictions.eq("origInvNum", originalDocumentNo));
			detachedCriteria.add(Restrictions.eq("origInvDate", originalDocumentDate));
			detachedCriteria.add(Restrictions.eq("category", Constant.CR));
			creditList = (List<GSTR1B2CS_InvoiceDetail>) hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			logger.error("Error fetching Credit List for Invoice" + originalDocumentNo, e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCreditListForB2CS");
		return creditList;
	}

	@Override
	public List<GSTR1B2BCLEAInvoiceDetail> getRevisedCreditList(GSTR1B2BCLEAInvoiceDetail credit) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getRevisedCreditList");

		List<GSTR1B2BCLEAInvoiceDetail> revisedCreditList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR1B2BCLEAInvoiceDetail.class);
			detachedCriteria.add(Restrictions.eq("orgInvNum", credit.getInvNum()));
			detachedCriteria.add(Restrictions.eq("orgInvDate", credit.getInvDate()));
			detachedCriteria.add(Restrictions.eq("category", Constant.RCR));
			revisedCreditList = (List<GSTR1B2BCLEAInvoiceDetail>) hibernateDao.find(detachedCriteria);

		}catch(Exception e){
			logger.error("Error fetching revised Credit List for credit" + credit.getInvNum(), e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getRevisedCreditList");
		return revisedCreditList;
	}

	@Override
	public List<GSTR1B2CSA_InvoiceDetail> getB2CRevisedCreditList(GSTR1B2CS_InvoiceDetail credit) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getB2CRevisedCreditList");
		List<GSTR1B2CSA_InvoiceDetail> revisedCreditList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR1B2CSA_InvoiceDetail.class);
			detachedCriteria.add(Restrictions.eq("orgInvNum", credit.getInvNum()));
			detachedCriteria.add(Restrictions.eq("orgInvDate", credit.getInvDate()));
			detachedCriteria.add(Restrictions.eq("category", Constant.RCR));
			revisedCreditList = (List<GSTR1B2CSA_InvoiceDetail>) hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			logger.error("Error fetching B2C revised credit list for credit" + credit.getInvNum(), e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getB2CRevisedCreditList");
		return revisedCreditList;
	}
	
	@Override
	public List<OutwardInvoiceModel> getCreditListForB2CSA(String originalDocumentNo, Date originalDocumentDate) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCreditListForB2CSA");
		List<OutwardInvoiceModel> creditList = null;
		try{
			if(originalDocumentNo==null || originalDocumentNo.trim().isEmpty()){
				return null;
			}
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
			detachedCriteria.add(Restrictions.eq("originalDocumentNo", originalDocumentNo));
			detachedCriteria.add(Restrictions.eq("originalDocumentDate", originalDocumentDate));
			detachedCriteria.add(Restrictions.isNotNull("tableType"));
			detachedCriteria.add(Restrictions.ne("itemStatus", Constant.BUS_RULE_ERROR));
			detachedCriteria.add(Restrictions.eq("documentType", Constant.CR));
			creditList = (List<OutwardInvoiceModel>) hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			logger.error("Error fetching Credit List for Invoice" + originalDocumentNo, e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCreditListForB2CSA");
		return creditList;
	}

	@Override
	public List<GSTR1B2CSA_InvoiceDetail> getB2CARevisedCreditList(OutwardInvoiceModel credit) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getB2CARevisedCreditList");
		List<GSTR1B2CSA_InvoiceDetail> revisedCreditList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR1B2CSA_InvoiceDetail.class);
			detachedCriteria.add(Restrictions.eq("orgInvNum", credit.getDocumentNo()));
			detachedCriteria.add(Restrictions.eq("orgInvDate", credit.getDocumentDate()));
			detachedCriteria.add(Restrictions.eq("category", Constant.RCR));
			revisedCreditList = (List<GSTR1B2CSA_InvoiceDetail>) hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			logger.error("Error fetching B2C revised credit list for credit" + credit.getDocumentNo(), e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getB2CARevisedCreditList");
		return revisedCreditList;
	}
	@Override
	public Object getSpecifcHSNSACDetails(String hsnSac, String className, String columnName) {

		return gstr1Dao.fetchHsnSacDetails(hsnSac, className, columnName);
	}

	@Override
	public List<Object> getEntityHierarchyfromMaster(String key) {
		MasterTable masterTable= new MasterTable();
		masterTable.setKey(key);
		return masterTableService.getMasterTableDetails(masterTable);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<OutwardInvoiceModel> getCreditRegisterData(String gstin,String taxperiod,int offset,int maxSize) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getB2CRevisedCreditList");
		List<OutwardInvoiceModel> revisedCreditList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
			detachedCriteria.createAlias("invoiceKeyDetail", "invoiceKeyDetail");
			detachedCriteria.add(Restrictions.eq("taxperiod", taxperiod));
			detachedCriteria.add(Restrictions.eq("sGSTIN", gstin));
			detachedCriteria.add(Restrictions.in("tableType", new String[]{"B2CS","B2CL","B2CSA","B2BCLEA"}));
			detachedCriteria.add(Restrictions.in("documentType", new String[]{"CR","RCR"}));
			detachedCriteria.add(Restrictions.eq("supplyType", "NSY"));
			detachedCriteria.add(Restrictions.eq("isError", false));
			detachedCriteria.add(Restrictions.eq("isDuplicate", false));
			detachedCriteria.add(Restrictions.eq("invoiceKeyDetail.isSuccessToGstn", true));
			detachedCriteria.setProjection(Projections.projectionList()
					.add(Projections.property("documentType"), "documentType")
					.add(Projections.property("supplyType"), "supplyType")
					.add(Projections.property("documentNo"), "documentNo")
					.add(Projections.property("documentDate"), "documentDate")
					.add(Projections.property("originalDocumentNo"), "originalDocumentNo")
					.add(Projections.property("originalDocumentDate"), "originalDocumentDate")
					.add(Projections.property("reasonForCreditDebitNote"), "reasonForCreditDebitNote")
					.add(Projections.property("itemCode"), "itemCode")
					.add(Projections.property("itemDescription"), "itemDescription")
					.add(Projections.property("unitofMeasurement"), "unitofMeasurement")
					.add(Projections.property("qtySupplied"), "qtySupplied")
					.add(Projections.property("customerName"), "customerName")
					.add(Projections.property("cGSTIN"), "cGSTIN")
					.add(Projections.property("pos"), "pos")
					.add(Projections.property("invoiceValue"), "invoiceValue"))
			.setResultTransformer(Transformers.aliasToBean(OutwardInvoiceModel.class));
			detachedCriteria.addOrder(Order.asc("id"));
			revisedCreditList = (List<OutwardInvoiceModel>) hibernateDao.findByCriteria(detachedCriteria, offset, maxSize);
		}catch(Exception e){
			logger.error("Error fetching B2C revised credit list for credit" + e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getB2CRevisedCreditList");
		return revisedCreditList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OutwardInvoiceModel> getCreditRegisterSummaryData(String gstin,String taxperiod) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getB2CRevisedCreditList");
		List<OutwardInvoiceModel> revisedCreditList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
			detachedCriteria.createAlias("invoiceKeyDetail", "invoiceKeyDetail"); 
			detachedCriteria.add(Restrictions.eq("taxperiod", taxperiod));
			detachedCriteria.add(Restrictions.eq("sGSTIN", gstin));
			detachedCriteria.add(Restrictions.in("tableType", new String[]{"B2CS","B2CL","B2CSA","B2BCLEA"}));
			detachedCriteria.add(Restrictions.in("documentType", new String[]{"CR","RCR"}));
			detachedCriteria.add(Restrictions.eq("supplyType", "NSY"));
			detachedCriteria.add(Restrictions.eq("isError", false));
			detachedCriteria.add(Restrictions.eq("isDuplicate", false));
			detachedCriteria.add(Restrictions.eq("invoiceKeyDetail.isSuccessToGstn", true));
			detachedCriteria.setProjection(Projections.projectionList()
					.add(Projections.sum("invoiceValue"), "invoiceValue")
					.add(Projections.groupProperty("documentType"), "documentType")
					.add(Projections.groupProperty("reasonForCreditDebitNote"), "reasonForCreditDebitNote"))
			.setResultTransformer(Transformers.aliasToBean(OutwardInvoiceModel.class));
			revisedCreditList = (List<OutwardInvoiceModel>) hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			logger.error("Error fetching B2C revised credit list for credit" + e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getB2CRevisedCreditList");
		return revisedCreditList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<InwardInvoiceModel> getDebitRegisterData(String gstin,String taxperiod,int offset,int maxSize) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getB2CRevisedCreditList");
		List<InwardInvoiceModel> revisedDebitList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(InwardInvoiceModel.class);
			detachedCriteria.createAlias("gstr2InvoiceKeyDetail", "gstr2InvoiceKeyDetail");
			detachedCriteria.add(Restrictions.eq("taxPeriod", taxperiod));
			detachedCriteria.add(Restrictions.eq("CGSTIN", gstin));
			detachedCriteria.add(Restrictions.in("tableType", new String[]{"B2CS","B2CL","B2CSA","B2BCLEA"}));
			detachedCriteria.add(Restrictions.in("documentType", new String[]{"DR","RDR"}));
			detachedCriteria.add(Restrictions.eq("supplyType", "NSY"));
			detachedCriteria.add(Restrictions.eq("isError", false));
			detachedCriteria.add(Restrictions.eq("isDuplicate", false));
			detachedCriteria.add(Restrictions.eq("gstr2InvoiceKeyDetail.isSuccessToGstn", true));
			detachedCriteria.setProjection(Projections.projectionList()
					.add(Projections.property("documentType"), "documentType")
					.add(Projections.property("supplyType"), "supplyType")
					.add(Projections.property("documentNo"), "documentNo")
					.add(Projections.property("documentDate"), "documentDate")
					.add(Projections.property("originalDocumentNo"), "originalDocumentNo")
					.add(Projections.property("originalDocumentDate"), "originalDocumentDate")
					.add(Projections.property("reasonForCreditDebitNote"), "reasonForCreditDebitNote")
					.add(Projections.property("itemCode"), "itemCode")
					.add(Projections.property("itemDescription"), "itemDescription")
					.add(Projections.property("unitofMeasurement"), "unitofMeasurement")
					.add(Projections.property("quantity"), "quantity")
					.add(Projections.property("supplierName"), "supplierName")
					.add(Projections.property("SGSTIN"), "SGSTIN")
					.add(Projections.property("pos"), "pos")
					.add(Projections.property("invoiceValue"), "invoiceValue"))
			.setResultTransformer(Transformers.aliasToBean(InwardInvoiceModel.class));
			detachedCriteria.addOrder(Order.asc("id"));
			revisedDebitList = (List<InwardInvoiceModel>) hibernateDao.findByCriteria(detachedCriteria, offset, maxSize);
		}catch(Exception e){
			logger.error("Error fetching B2C revised debit list for debit" + e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getDebitRegisterData");
		return revisedDebitList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<InwardInvoiceModel> getDebitRegisterSummaryData(String gstin,String taxPeriod) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" getDebitRegisterSummaryData");
		List<InwardInvoiceModel> revisedDebitList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(InwardInvoiceModel.class);
			detachedCriteria.createAlias("gstr2InvoiceKeyDetail", "gstr2InvoiceKeyDetail"); 
			detachedCriteria.add(Restrictions.eq("taxPeriod", taxPeriod));
			detachedCriteria.add(Restrictions.eq("SGSTIN", gstin));
			detachedCriteria.add(Restrictions.in("tableType", new String[]{"B2CS","B2CL","B2CSA","B2BCLEA"}));
			detachedCriteria.add(Restrictions.in("documentType", new String[]{"DR","RDR"}));
			detachedCriteria.add(Restrictions.eq("supplyType", "NSY"));
			detachedCriteria.add(Restrictions.eq("isError", false));
			detachedCriteria.add(Restrictions.eq("isDuplicate", false));
			detachedCriteria.add(Restrictions.eq("gstr2InvoiceKeyDetail.isSuccessToGstn", true));
			detachedCriteria.setProjection(Projections.projectionList()
					.add(Projections.sum("invoiceValue"), "invoiceValue")
					.add(Projections.groupProperty("documentType"), "documentType")
					.add(Projections.groupProperty("reasonForCreditDebitNote"), "reasonForCreditDebitNote"))
			.setResultTransformer(Transformers.aliasToBean(InwardInvoiceModel.class));
			revisedDebitList = (List<InwardInvoiceModel>) hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			logger.error("Error fetching getDebitRegisterSummaryData " + e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME+Constant.LOGGER_METHOD+" getDebitRegisterSummaryData");
		return revisedDebitList;
	}


	private String getOriginalDocType(String amendmentDocType) {

		String orgDocType= "";
		if(Constant.RCR.equals(amendmentDocType))
			orgDocType = Constant.CR;
		if(Constant.RDR.equals(amendmentDocType))
			orgDocType = Constant.DR;
		if(Constant.RNV.equals(amendmentDocType))
			orgDocType = Constant.INV;

		return orgDocType;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public String getOriginalInvoice(OutwardInvoiceModel lineItem, String entityName, String OrgDocNoField,
			String OrgDocDateField) {

		List<Object> entityList = null;

		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getOriginalInvoice()");

		if (lineItem != null) {
			try {
				if(lineItem.getOriginalDocumentNo()!=null && lineItem.getOriginalDocumentDate() != null) {	
					entityList = gstr1Dao.validateOriginalDocNoDocDate(lineItem.getOriginalDocumentNo(),
							lineItem.getOriginalDocumentDate(), entityName, OrgDocNoField, OrgDocDateField);
					
					if(entityList!=null && !entityList.isEmpty()) {
						return Constant.TRUE;
					}
				}
			} catch (Exception e) {
				logger.info(
						Constant.LOGGER_ERROR
						+ CLASS_NAME
						+Constant.LOGGER_METHOD+" getOriginalInvoice(). Unable to get Original Doc Num for Invoice: "
						+ lineItem.getId(), e);
			}
		}

		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getOriginalInvoice()");

		return Constant.FALSE;

	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public List<Object> getOriginalInvoiceList(OutwardInvoiceModel lineItem, String entityName, String OrgDocNoField,
			String OrgDocDateField) {

		List<Object> entityList = null;

		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getOriginalInvoice()");

		if (lineItem != null) {
			try {
				if(lineItem.getOriginalDocumentNo()!=null && lineItem.getOriginalDocumentDate() != null) {	
					entityList = gstr1Dao.validateOriginalDocNoDocDate(lineItem.getOriginalDocumentNo(),
							lineItem.getOriginalDocumentDate(), entityName, OrgDocNoField, OrgDocDateField);
					
					if(entityList!=null && !entityList.isEmpty()) {
						return entityList;
					}
				}
			} catch (Exception e) {
				logger.info(
						Constant.LOGGER_ERROR
						+ CLASS_NAME
						+Constant.LOGGER_METHOD+" getOriginalInvoiceList(). Unable to get Original Doc Num for Invoice: "
						+ lineItem.getId(), e);
			}
		}

		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getOriginalInvoiceList()");

		return null;

	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Map<String,List<ParentSalePurchaseDto>> getOutwardSuppliesDetails(List<String> inputs){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getOutwardSuppliesDetails");
		List<SalePurchasedto> listDto = new ArrayList<>();
		SalePurchaseServiceImpl ob = new SalePurchaseServiceImpl();
		List<Object[]> listItem = null;
		try {
			listItem = (List<Object[]>) hibernateDao.executeStoredProcedureReturnList
					(Constant.DBO_SCHEMA, Constant.PROC_USPOUTWARDSUPPLY, "3", inputs);
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" getOutwardSuppliesDetails"+e);
		}
		if(listItem!=null && !listItem.isEmpty()){
			for(Object[] obj:listItem){
				SalePurchasedto dto = new SalePurchasedto();
				dto.setSupplyType(obj[0].toString());
				dto.setSupplyCategory(obj[1].toString());
				dto.setValue(ob.toDouble(obj[2]));
				dto.setValueIncludingTax(ob.toDouble(obj[3]));
				dto.setIGSTRate(ob.toDouble(obj[4]));
				dto.setIGSTAmount(ob.toDouble(obj[5]));
				dto.setCGSTRate(ob.toDouble(obj[6]));
				dto.setCGSTAmount(ob.toDouble(obj[7]));
				dto.setSGSTRate(ob.toDouble(obj[8]));
				dto.setSGSTAmount(ob.toDouble(obj[9]));
				dto.setCessRate(ob.toDouble(obj[10]));
				dto.setCessAmount(ob.toDouble(obj[11]));
				dto.setTranType(obj[12].toString());
				listDto.add(dto);
			}
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getOutwardSuppliesDetails");
		return resultToMap(listDto);
	}
	
	@SuppressWarnings("rawtypes")
	private static Map<String,List<ParentSalePurchaseDto>> resultToMap(List<SalePurchasedto> l){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" resultToMap");
		Map<String,List<ParentSalePurchaseDto>> m = new LinkedHashMap();
		List<ParentSalePurchaseDto> list = new ArrayList<>();
		/*List<SalePurchasedto> jWSublist = new ArrayList<>();*/
		List<SalePurchasedto> compSchemeSublist = new ArrayList<>();
		List<SalePurchasedto> strSublist = new ArrayList<>();
		List<SalePurchasedto> sezSublist = new ArrayList<>();
		List<SalePurchasedto> tpSublist = new ArrayList<>();
		List<SalePurchasedto> nilRateSublist = new ArrayList<>();
		List<SalePurchasedto> expImpSublist = new ArrayList<>();
		List<SalePurchasedto> extSublist = new ArrayList<>();
		List<SalePurchasedto> dxpSublist = new ArrayList<>();



		for(SalePurchasedto obj : l ){
			if(obj.getSupplyType().equals(Constant.DEEMED_EXPORTS)){
				dxpSublist.add(obj);	
			}else if(obj.getSupplyType().equals(Constant.STOCK_TRANSFER)){
				strSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.SEZ)){
				sezSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.EXPORTS) /*|| obj.getSupplyType().equals(Constant.EXPORT_WITHOUT_PAYMENT)*/ || obj.getSupplyType().equals(Constant.IMPORTS) ){
				expImpSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.THIRDPARTY_SALES_OR_PURCHASE)){
				tpSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.NIL)){
				nilRateSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.EXEMPT)){
				extSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.COMPOSITION_SCHEME)){
				compSchemeSublist.add(obj);	
			}

		}

		ParentSalePurchaseDto obj1 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.THIRDPARTY_SALES_OR_PURCHASE,tpSublist);
		ParentSalePurchaseDto obj2 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.STOCK_TRANSFER,strSublist);
		ParentSalePurchaseDto obj3 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.SEZ,sezSublist);
		ParentSalePurchaseDto obj4 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.EXPORTS_OR_IMPORTS,expImpSublist);
		ParentSalePurchaseDto obj5 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.DEEMED_EXPORTS,dxpSublist);
		ParentSalePurchaseDto obj6 = new ParentSalePurchaseDto(Constant.NON_TAXABLE,Constant.NIL,nilRateSublist);
		ParentSalePurchaseDto obj7 = new ParentSalePurchaseDto(Constant.NON_TAXABLE,Constant.EXEMPT,extSublist);
		ParentSalePurchaseDto obj8 = new ParentSalePurchaseDto(Constant.NON_TAXABLE,Constant.COMPOSITION_SCHEME,compSchemeSublist);

		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.add(obj4);
		list.add(obj5);
		list.add(obj6);
		list.add(obj7);
		list.add(obj8);
		m.put("Supply", list);
		logger.info(Constant.LOGGER_EXITING+ CLASS_NAME
				+Constant.LOGGER_METHOD+" resultToMap");
		return m;
	}

	// to reset flags for failed chunks
	@Override
	public void updateGstnTranId(String gsptransid, String transid, String gstinNum, String refId, Long chunkId,
			String gstnStatus, String errorDesc) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateGstnTranId()");
		List<String> inputParamsList = new ArrayList<>();
		try {
			inputParamsList.add(String.valueOf(chunkId));
			inputParamsList.add("");
			inputParamsList.add(refId);
			inputParamsList.add(transid);
			inputParamsList.add(gstnStatus);
			inputParamsList.add(errorDesc);
			hibernateDao.executeStoredProcedure(Constant.DBO_SCHEMA,Constant.SAVE_PROC, "6", inputParamsList);

		} catch (Exception exec) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" updateGstnTranId()" ,exec);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" updateGstnTranId()");
	}
		
	@Override
	public void updateAckNum(String gstinId, String taxPeriod,
			String acknowledge) {
		returnFilingDao.updateReturnFilingDetailsForFiling(gstinId,taxPeriod,
				Constant.GSTR1_Filing,acknowledge, Constant.FILED);
	}
	
	@SuppressWarnings("unchecked")
    @Override
    public boolean getReturnFilingStatusForSaveGstrToGstn(String gstin,String taxPeriod,String returnType) {

           boolean alreadySubmitted = returnFilingDao.getReturnFilingStatusForSaveGstrToGstn(gstin, taxPeriod, returnType);
           return alreadySubmitted;
    }

	@Override
	public void updateReturnFilingStatus(String gstin, String taxPeriod, String returnType) {
		returnFilingDao.updateReturnFilingStatus(gstin, taxPeriod, returnType);
	}

	@Override
	public List<Object[]> getGstr1CptyGstinList(String supplyGstin,
			String taxPeriod, String cgstin, String cname, String supplyType) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCounterPartySupplyTypes");
		List<Object[]> gstinList=null;
		List<String> supplyTypes = new ArrayList<>();
		if(supplyType.equalsIgnoreCase(Constant.CDN)){
			supplyTypes.add(Constant.CR);
			supplyTypes.add(Constant.DR);
		}
		else if(supplyType.equalsIgnoreCase(Constant.CDNA)){
			supplyTypes.add(Constant.RCR);
			supplyTypes.add(Constant.RDR);
		}
		else
			supplyTypes.add(supplyType);
		
		DetachedCriteria criteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
		ProjectionList projList = Projections.projectionList();
		projList.add(Projections.property("cGSTIN"));
		projList.add(Projections.property("customerName"));
		criteria.add(Restrictions.eq("sGSTIN", supplyGstin));
		criteria.add(Restrictions.in("tableType", supplyTypes));
		criteria.add(Restrictions.eq("taxperiod", taxPeriod));
		criteria.add(Restrictions.eq("isError", false));
		if(cgstin!=null && !cgstin.equalsIgnoreCase(""))
			criteria.add(Restrictions.eq("cGSTIN", cgstin));
		else
			criteria.add(Restrictions.eq("customerName", cname));
		criteria.setProjection(Projections.distinct(projList));
		
		try {
			gstinList = (List<Object[]>) hibernateDao.find(criteria);
		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD+" getCounterPartySupplyTypes",e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" getCounterPartySupplyTypes");
		return gstinList;
	}

	@Override
	public String getCounterPartyReportDetails(JSONObject jsonObj){
		String counterpartyData = null;
		try {
			counterpartyData = (String)reportDao.getCounterpartyDetails(jsonObj);
			System.out.println(counterpartyData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return counterpartyData;
	} 
	
}
