package com.ey.advisory.asp.client.dao.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.TblFileUploadStatusDao;
import com.ey.advisory.asp.client.domain.TblFileUploadStatus;
import com.ey.advisory.asp.client.dto.FileSearchDTO;
import com.ey.advisory.asp.client.service.TblFileUploadStatusServiceImpl;
import com.ey.advisory.asp.common.Constant;
@Repository
public class TblFileUploadStatusDaoImpl implements TblFileUploadStatusDao{
	@Autowired
	HibernateDao hibernateDao;
	private static final Logger logger = Logger.getLogger(TblFileUploadStatusServiceImpl.class);
	private static final String CLASS_NAME = TblFileUploadStatusServiceImpl.class.getName();
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#getFileUploadStatusDetails(java.lang.String)
	 * This method is used to get TblFileUploadStatus list from the database
	 */
	@Override
	public List<TblFileUploadStatus> getFileUploadStatusDetails(String fileId) {
		List<TblFileUploadStatus> loadstatusDetails = new ArrayList<>();
		try {
			DetachedCriteria detachedCriteria = hibernateDao
					.createCriteria(TblFileUploadStatus.class);
			detachedCriteria.add(Restrictions.eq("fileId", Integer.parseInt(fileId)));
			ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property("gstin"), "gstin");
			detachedCriteria.setProjection(Projections.distinct(projList));
			loadstatusDetails = (List<TblFileUploadStatus>) hibernateDao
					.find(detachedCriteria);
			
		} catch (Exception exec) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : updateGstnTranId()" + exec);
		}
		return loadstatusDetails;
	}
	
	@Override
	public List<TblFileUploadStatus> getUploadedFiles(FileSearchDTO fileDTO) {
		
		if(fileDTO.getFromDate()!=null && fileDTO.getFromDate().length()!=0)
   			return getFilesByDate(fileDTO);
   		else
   			return getFilesByMonth(fileDTO);
	}
	@Override
	public List<TblFileUploadStatus> getFilesByDate(FileSearchDTO fileDTO)
	{
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getFilesByDate()" );
		List<TblFileUploadStatus> fileList = new ArrayList<>();
		List<Object[]> resultList=null;
		fileDTO.setFromDate(fileDTO.getFromDate()+" 00:00:00");
		fileDTO.setToDate(fileDTO.getToDate()+ " 23:59:59");
	try{
		String sql= "SELECT distinct t.FileId,t.fName,t.content,t.UploadDt,sc.Description FROM [etl].tblfileupload t"
				+" INNER JOIN [dbo].[tblSystemCodes] sc ON t.Status=sc.Code"
				+" WHERE t.UserId= ? AND t.UploadDt BETWEEN ? AND ? " ;	
	
		String sqlSummary= "SELECT distinct t.SummaryFileID,t.FileName,t.Content,t.UploadDate,sc.Description FROM [etl].tblSummaryFileLoad t"
				+" INNER JOIN [dbo].[tblSystemCodes] sc ON t.Status=sc.Code"
				+" WHERE t.UserId= ? AND t.UploadDate BETWEEN ? AND ? " ;		
		

			resultList = (List<Object[]>) hibernateDao.executeNativeSql(sql,
					new Object[] { fileDTO.getUserId(), fileDTO.getFromDate(), fileDTO.getToDate() });
			
			if (resultList != null && !resultList.isEmpty()) {
				prepareList(resultList, fileList, Boolean.TRUE);
			}

			resultList = (List<Object[]>) hibernateDao.executeNativeSql(sqlSummary,
					new Object[] { fileDTO.getUserId(), fileDTO.getFromDate(), fileDTO.getToDate() });
			
			if (resultList != null && !resultList.isEmpty())
				return prepareList(resultList, fileList, Boolean.FALSE);
	
	}catch (Exception exec) {
		logger.info(Constant.LOGGER_ERROR + CLASS_NAME
				+ " Method : getFilesByDate()" + exec);
	}			
		return fileList;
	}
	
	@Override
	public List<TblFileUploadStatus> getFilesByMonth(FileSearchDTO fileDTO)
	{
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getFilesByMonth()" );
		List<TblFileUploadStatus> fileList = new ArrayList<>();
		try{
			String sql=	"SELECT distinct t.FileId,t.fName,t.content,t.UploadDt,sc.Description FROM [etl].tblfileupload t"
					 +" INNER JOIN [dbo].[tblSystemCodes] sc ON t.Status=sc.Code"
					 + " WHERE t.UserId= ? AND MONTH(UploadDt)= ? AND YEAR(UploadDt)= ? ";
		
			String sqlSummary=	"SELECT distinct t.SummaryFileID,t.FileName,t.Content,t.UploadDate,sc.Description FROM [etl].tblSummaryFileLoad t"
				 +" INNER JOIN [dbo].[tblSystemCodes] sc ON t.Status=sc.Code"
				 + " WHERE t.UserId= ? AND MONTH(UploadDate)= ? AND YEAR(UploadDate)= ? ";
			
			List<Object[]> resultList= (List<Object[]>) hibernateDao.executeNativeSql(sql, new Object[]{fileDTO.getUserId(),fileDTO.getMonth(),fileDTO.getYear()});
			if(resultList!=null && !resultList.isEmpty())
				 prepareList(resultList,fileList, Boolean.TRUE);
			
			resultList=(List<Object[]>) hibernateDao.executeNativeSql(sqlSummary, new Object[]{fileDTO.getUserId(),fileDTO.getMonth(),fileDTO.getYear()});
			
			if(resultList!=null && !resultList.isEmpty())
				return prepareList(resultList,fileList, Boolean.FALSE);
			
		}catch (Exception exec) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : getFilesByMonth()" , exec);
		}			
		return fileList;
	}
	
	private List<TblFileUploadStatus> prepareList(List<Object[]> responseList,List<TblFileUploadStatus> fileList, Boolean isLiveDashboard)
	{
		SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		String status;
		for (Object[] objects : responseList) {
			status=objects[4]==null?"N.A":objects[4].toString();
			
			fileList.add(new TblFileUploadStatus(Integer.valueOf(objects[0].toString()),objects[1].toString(),String.valueOf(objects[2]),sdf.format((Timestamp)objects[3]),status, isLiveDashboard));
		}
		return fileList;
	}

	@Override
	public String getLastUploadedDate() {
		TblFileUploadStatus tblFileData = null;
		DetachedCriteria detachedCriteria = hibernateDao
				.createCriteria(TblFileUploadStatus.class);
		detachedCriteria.add(Restrictions.eq("status","PSD"));
		detachedCriteria.add(Restrictions.eq("stage", "BIF"));
		detachedCriteria.addOrder(Order.desc("uploadDt"));
		List<TblFileUploadStatus> loadstatusDetails = (List<TblFileUploadStatus>) hibernateDao
				.find(detachedCriteria);
		if(loadstatusDetails!=null && !loadstatusDetails.isEmpty()){
			tblFileData = loadstatusDetails.get(0);
			return tblFileData.getUploadDt().toString();
		}
		else{
			return null;
		}
	}
}
