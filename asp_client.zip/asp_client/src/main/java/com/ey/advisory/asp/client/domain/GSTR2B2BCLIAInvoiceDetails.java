package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

/**
 * The persistent class for the tblB2BCLIAInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2BCLIAInvoiceDetails",schema=Constant.GSTR2_SCHEMA)
public class GSTR2B2BCLIAInvoiceDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private long id;
	
	@Column(name="Chksum")
	private String chksum;
	
	@Column(name="OrgSGSTIN")
	private String orgSGSTIN;

	@Column(name="OrgInvDate")
	private Date orgInvDate;

	@Column(name="OrgInvNum")
	private String orgInvNum;

	@Column(name="SGSTIN")
	private String SGSTIN;
	
	@Column(name="InvDate")
	private Date invDate;

	@Column(name="InvNum")
	private String invNum;
	
	@Column(name="InvValue")
	private BigDecimal invValue;
	
	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;
	
	@Column(name="POS")
	private String pos;

	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="FileID")
	private long fileID;
	
	@Column(name="Category")
	private String category;

	@Column(name="SubCategory")
	private String subCategory;

	@Column(name="InvoiceKey")
	private String invoiceKey;	

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="Flag")
	private String flag;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getChksum() {
		return chksum;
	}

	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	public String getOrgSGSTIN() {
		return orgSGSTIN;
	}

	public void setOrgSGSTIN(String orgSGSTIN) {
		this.orgSGSTIN = orgSGSTIN;
	}

	public Date getOrgInvDate() {
		return orgInvDate;
	}

	public void setOrgInvDate(Date orgInvDate) {
		this.orgInvDate = orgInvDate;
	}

	public String getOrgInvNum() {
		return orgInvNum;
	}

	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	public String getSGSTIN() {
		return SGSTIN;
	}

	public void setSGSTIN(String SGSTIN) {
		this.SGSTIN = SGSTIN;
	}

	public Date getInvDate() {
		return invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getInvNum() {
		return invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public BigDecimal getInvValue() {
		return invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public BigDecimal getTaxablevalue() {
		return taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public long getFileID() {
		return fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public boolean isDelete() {
		return isDelete;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}
	
	
	
	

	
	

	

	
}
