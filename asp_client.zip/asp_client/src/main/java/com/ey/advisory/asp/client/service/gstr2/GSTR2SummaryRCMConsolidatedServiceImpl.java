package com.ey.advisory.asp.client.service.gstr2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GSTR2SummaryRCMConsolidatedDao;
import com.ey.advisory.asp.client.domain.GSTR2SummaryRCMConsolidated;

@Service
public class GSTR2SummaryRCMConsolidatedServiceImpl implements GSTR2SummaryRCMConsolidatedService{

	@Autowired
	private GSTR2SummaryRCMConsolidatedDao rcmConsolidatedDao;

	@Override
	public List<GSTR2SummaryRCMConsolidated> getRCMConsolidatedMetadata() {
		return rcmConsolidatedDao.getRCMConsolidatedMetadata();
	}

}
