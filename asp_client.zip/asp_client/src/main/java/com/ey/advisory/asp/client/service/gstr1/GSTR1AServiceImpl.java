package com.ey.advisory.asp.client.service.gstr1;

import java.net.URL;

import org.springframework.stereotype.Service;

/**
 * @author Mayank3.Kumar
 *
 */
@Service
public class GSTR1AServiceImpl implements GSTR1AService{

	@Override
	public void generateGSTR1FReconReport(String groupCode, String gstin, String taxPeriod, URL template_Dir) {
		// TODO Auto-generated method stub
		
	}

}
