package com.ey.advisory.asp.client.dto;

import java.util.List;
import java.util.Map;

public class DashBoardMapDto {

	private Map<String,String> stateColorMap;
	private Map<String, List<MapGstinDto>> stateGSTINMap;
	
	public Map<String, String> getStateColorMap() {
		return stateColorMap;
	}
	public void setStateColorMap(Map<String, String> stateColorMap) {
		this.stateColorMap = stateColorMap;
	}
	public Map<String, List<MapGstinDto>> getStateGSTINMap() {
		return stateGSTINMap;
	}
	public void setStateGSTINMap(Map<String, List<MapGstinDto>> stateGSTINMap) {
		this.stateGSTINMap = stateGSTINMap;
	}

	
}
