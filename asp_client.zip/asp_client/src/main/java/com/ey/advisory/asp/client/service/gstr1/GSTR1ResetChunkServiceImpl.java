package com.ey.advisory.asp.client.service.gstr1;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.jdbc.Work;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.common.Constant;

@Service
public class GSTR1ResetChunkServiceImpl implements GSTR1ResetChunkService {

	private static final Logger logger = Logger
			.getLogger(GSTR1ResetChunkServiceImpl.class);
	private static final String CLASS_NAME = GSTR1ResetChunkServiceImpl.class
			.getName();

	@Autowired
	private HibernateDao hibernateDao;

	@Override
	public String resetGSTR1Chunks(JSONObject jsonObject) {
		// TODO Auto-generated method stub
		String response = "";
		List<String> updateListQueries = getGSTR1ResetChunkUpdateQueries(jsonObject);
		Session session = hibernateDao.getSession();
		//hibernateDao.executeStoredProcedure(Constant.GSTR1, storedProcName, inputParamsCount, inputParamsList);
		Transaction tx = session.beginTransaction();
		try {
			session.doWork(new Work() {
				int count[];

				@Override
				public void execute(Connection connection) throws SQLException {
					// TODO Auto-generated method stub
					Statement preparedStatement = connection.createStatement();
					for (String string : updateListQueries) {
						preparedStatement.addBatch(string);
					}
					count = preparedStatement.executeBatch();
				}

			});
			tx.commit();
			session.close();
			response = Constant.SUCCESS;
		} catch (Exception e) {
			logger.error("Error in updatescript" + e, e);
			e.printStackTrace();
			response = Constant.FAILED;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return response;
	}
	
	public List<String> getGSTR1ResetChunkUpdateQueries(JSONObject jsonObject){
		List<String> list = new ArrayList<String>();
		if(jsonObject == null)
			return list;
		try{
			if(jsonObject.get(Constant.TABLE_TYPE) != null){
				if(Constant.B2B.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblB2BInvoiceDetails SET ISDELETE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" +jsonObject.get(Constant.GSTIN).toString() + "'" );
					list.add("UPDATE GSTR1.tblInvoiceKeyDetail SET LOADID = NULL, IsLoadedToGstn = NULL, IsSuccessToGstn = NULL  WHERE TAXPERIOD=" + "'" +jsonObject.get(Constant.TAX_PERIOD).toString()+"'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString()+ "'" + " AND LOADID IS NOT NULL");
				}
				
				if(Constant.EXP.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblExportInvoice SET ISDELETE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'"+ " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblInvoiceKeyDetail SET LOADID = NULL, IsLoadedToGstn = NULL, IsSuccessToGstn = NULL  WHERE TAXPERIOD=" + "'" +jsonObject.get(Constant.TAX_PERIOD).toString()+ "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString()+ "'" + " AND LOADID IS NOT NULL");
				}
				
				if(Constant.B2BCL.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblB2BCLEAInvoiceDetails SET ISDELETE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblInvoiceKeyDetail SET LOADID = NULL, IsLoadedToGstn = NULL, IsSuccessToGstn = NULL  WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'" + " AND LOADID IS NOT NULL");
				}
				
				if(Constant.NIL.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblNilRatedInvoiceDetails SET ISDELETE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblInvoiceKeyDetail SET LOADID = NULL, IsLoadedToGstn = NULL, IsSuccessToGstn = NULL  WHERE TAXPERIOD=" + "'" +jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString()+ "'" + " AND LOADID IS NOT NULL");
				}
				
				if(Constant.HSN.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblHsnSummary SET ISDELETE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" +  "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblSummaryGSTNSubmissionStatus SET ISACTIVE = 0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString()+ "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'" + " AND LOADID IS NOT NULL");
				}
				
				if(Constant.TXR.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblSummaryAdvTaxRec SET ISACTIVE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + jsonObject.get(Constant.GSTIN).toString() + "'" );
					list.add("UPDATE GSTR1.tblSummaryGSTNSubmissionStatus SET ISACTIVE = 0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'" + " AND LOADID IS NOT NULL");
				}
				
				if(Constant.TXI.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblSummaryAdvTaxAdj SET ISACTIVE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblSummaryGSTNSubmissionStatus SET ISACTIVE = 0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'" + " AND LOADID IS NOT NULL");
				}
				
				if(Constant.B2CS.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblSummaryB2CS SET ISACTIVE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblSummaryGSTNSubmissionStatus SET ISACTIVE = 0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString()+ "'" + " AND LOADID IS NOT NULL");
				}
				
				if(Constant.IS.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblSummaryInvoiceseries SET ISACTIVE = 1 WHERE TAXPERIOD=" + "'" +  jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblSummaryGSTNSubmissionStatus SET ISACTIVE = 0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" +jsonObject.get(Constant.GSTIN).toString() + "'" + " AND LOADID IS NOT NULL");
				}
				
				if(Constant.ALL.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR1.tblHsnSummary SET ISDELETE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblSummaryB2CS SET ISACTIVE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblSummaryAdvTaxAdj SET ISACTIVE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" +  jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblSummaryAdvTaxRec SET ISACTIVE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblSummaryInvoiceseries SET ISACTIVE = 1 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR1.tblSummaryGSTNSubmissionStatus SET ISACTIVE = 0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
				}
			}
			return list;
		}catch(Exception e){
			logger.error("Error in adding queries to the list" + e , e);
			e.printStackTrace();
			return list;
		}
	}
}
