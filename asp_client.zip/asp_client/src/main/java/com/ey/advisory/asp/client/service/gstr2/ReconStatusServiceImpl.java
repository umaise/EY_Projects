package com.ey.advisory.asp.client.service.gstr2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.ReconStatusDao;
import com.ey.advisory.asp.client.domain.ReconStatus;

@Service
public class ReconStatusServiceImpl implements ReconStatusService {

	@Autowired
	private ReconStatusDao reconStatusDao;

	@Override
	public ReconStatus getReconStatus(String gstin, String taxPeriod, Integer masterId) {
		return reconStatusDao.getReconStatus(gstin, taxPeriod, masterId);
	}

	@Override
	public void saveReconStatus(String gstin, String taxPeriod, Integer masterId) {
		reconStatusDao.saveReconStatus(gstin, taxPeriod, masterId);
	}

	@Override
	public void updateReconStatus(String gstin, String taxPeriod, Integer masterId) {
		reconStatusDao.updateReconStatus(gstin, taxPeriod, masterId);
	}

	@Override
	public ReconStatus getActiveReconStatus(String gstin, String taxPeriod) {
		return reconStatusDao.getActiveReconStatus(gstin, taxPeriod);
	}

	@Override
	public ReconStatus getReconStatus(String gstin, String taxPeriod) {
		return reconStatusDao.getReconStatus(gstin, taxPeriod);
	}

	@Override
	public void updateReconCompletionDate(String gstin, String taxPeriod, Integer masterId) {
		reconStatusDao.updateReconCompletedDate(gstin, taxPeriod, masterId);
	}

	@Override
	public void updateReconStatus(String gstin, String taxPeriod, Integer masterId, String status) {
		reconStatusDao.updateReconStatus(gstin, taxPeriod, masterId, status);

	}

}
