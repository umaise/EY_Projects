package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;
import java.math.BigDecimal;

import javax.persistence.*;

@Entity
@Table(name = "tblVendorMaster",schema="master")
public class VendorMaster implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "VendorID")
	private Long  vendorID;
	
	@Column(name = "SGSTIN")
	private String receiverGSTIN;
	
	@Column(name = "VGSTIN")
	private String vendorGSTIN;
	
	@Column(name = "VendorCode")
	private String vendorCode;
	
	@Column(name = "VendorName")
	private String vendorName;
	
	@Column(name = "VendorAddress")
	private String vendorAddress;
	
	@Column(name = "VendorLocationCode")
	private String vendorLocationCode;
	
	@Column(name = "VendorCategory")
	private String vendorCategory;
	
	@Column(name = "CompanyType")
	private String co_LLP_P_Individual ;
	
	@Column(name = "Category")
	private String category;
	
	@Column(name = "HSNSAC")
	private String aHSNOrSAC;
	
	@Column(name = "POS")
	private String aPOS;
	
	@Column(name = "Info")
	private String illustrativeExample;
	
	@Column(name = "PrimaryContact")
	private String vendorPrimaryContactPerson;
	
	@Column(name = "PrimaryeMailId")
	private String primaryEmailId;
	
	@Column(name = "PrimaryMobileNo")
	private long primaryMobileNumber;
	
	@Column(name = "SecondaryContact")
	private String vendorSecondaryContactPerson;
	
	@Column(name = "SecondaryeMailId")
	private String secondaryEmailId;
	
	@Column(name = "SecondaryMobileNo")
	private long secondaryMobileNumber;
	
	@Column(name = "IsExempt")
	private Character isExemptOrconcessionalYorN;
	
	@Column(name = "NotificationNumber")
	private String circularOrNotificationNumber;
	
	@Column(name = "NotificationDate")
	private java.util.Date circularOrNotificationDate;
	
	@Column(name = "SerialNumber")
	private String serialNumberOfCircular;
	
	@Column(name = "IGSTRt")
	private BigDecimal aIGSTRate;
	
	@Column(name = "CGSTRt")
	private BigDecimal aCGSTRate;
	
	@Column(name = "SGSTRt")
	private BigDecimal aSGSTRate;
	
	@Column(name = "UTGSTRt")
	private BigDecimal aUTGSTRate;
	
	@Column(name = "CESSRt")
	private BigDecimal aCessRate;
	
	@Column(name = "IsTDS")
	private Character isTDS;

	@Column(name = "ADD1")    		  
	private String add1;
	
	@Column(name = "ADD2")
	private String add2;
	
	@Column(name = "ADD3")
	private String add3;
	
	@Column(name = "ADD4")
	private BigDecimal add4;
	
	@Column(name = "ADD5")
	private BigDecimal add5;

	public Long getVendorID() {
		return vendorID;
	}

	public void setVendorID(Long vendorID) {
		this.vendorID = vendorID;
	}

	public String getReceiverGSTIN() {
		return receiverGSTIN;
	}

	public void setReceiverGSTIN(String receiverGSTIN) {
		this.receiverGSTIN = receiverGSTIN;
	}

	public String getVendorGSTIN() {
		return vendorGSTIN;
	}

	public void setVendorGSTIN(String vendorGSTIN) {
		this.vendorGSTIN = vendorGSTIN;
	}

	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}

	public String getVendorLocationCode() {
		return vendorLocationCode;
	}

	public void setVendorLocationCode(String vendorLocationCode) {
		this.vendorLocationCode = vendorLocationCode;
	}

	public String getVendorCategory() {
		return vendorCategory;
	}

	public void setVendorCategory(String vendorCategory) {
		this.vendorCategory = vendorCategory;
	}

	public String getCo_LLP_P_Individual() {
		return co_LLP_P_Individual;
	}

	public void setCo_LLP_P_Individual(String co_LLP_P_Individual) {
		this.co_LLP_P_Individual = co_LLP_P_Individual;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getaHSNOrSAC() {
		return aHSNOrSAC;
	}

	public void setaHSNOrSAC(String aHSNOrSAC) {
		this.aHSNOrSAC = aHSNOrSAC;
	}

	public String getaPOS() {
		return aPOS;
	}

	public void setaPOS(String aPOS) {
		this.aPOS = aPOS;
	}

	public String getIllustrativeExample() {
		return illustrativeExample;
	}

	public void setIllustrativeExample(String illustrativeExample) {
		this.illustrativeExample = illustrativeExample;
	}

	public String getVendorPrimaryContactPerson() {
		return vendorPrimaryContactPerson;
	}

	public void setVendorPrimaryContactPerson(String vendorPrimaryContactPerson) {
		this.vendorPrimaryContactPerson = vendorPrimaryContactPerson;
	}

	public String getPrimaryEmailId() {
		return primaryEmailId;
	}

	public void setPrimaryEmailId(String primaryEmailId) {
		this.primaryEmailId = primaryEmailId;
	}

	public long getPrimaryMobileNumber() {
		return primaryMobileNumber;
	}

	public void setPrimaryMobileNumber(long primaryMobileNumber) {
		this.primaryMobileNumber = primaryMobileNumber;
	}

	public String getVendorSecondaryContactPerson() {
		return vendorSecondaryContactPerson;
	}

	public void setVendorSecondaryContactPerson(String vendorSecondaryContactPerson) {
		this.vendorSecondaryContactPerson = vendorSecondaryContactPerson;
	}

	public String getSecondaryEmailId() {
		return secondaryEmailId;
	}

	public void setSecondaryEmailId(String secondaryEmailId) {
		this.secondaryEmailId = secondaryEmailId;
	}

	public long getSecondaryMobileNumber() {
		return secondaryMobileNumber;
	}

	public void setSecondaryMobileNumber(long secondaryMobileNumber) {
		this.secondaryMobileNumber = secondaryMobileNumber;
	}

	public Character getIsExemptOrconcessionalYorN() {
		return isExemptOrconcessionalYorN;
	}

	public void setIsExemptOrconcessionalYorN(Character isExemptOrconcessionalYorN) {
		this.isExemptOrconcessionalYorN = isExemptOrconcessionalYorN;
	}

	public String getCircularOrNotificationNumber() {
		return circularOrNotificationNumber;
	}

	public void setCircularOrNotificationNumber(String circularOrNotificationNumber) {
		this.circularOrNotificationNumber = circularOrNotificationNumber;
	}

	public java.util.Date getCircularOrNotificationDate() {
		return circularOrNotificationDate;
	}

	public void setCircularOrNotificationDate(
			java.util.Date circularOrNotificationDate) {
		this.circularOrNotificationDate = circularOrNotificationDate;
	}

	public String getSerialNumberOfCircular() {
		return serialNumberOfCircular;
	}

	public void setSerialNumberOfCircular(String serialNumberOfCircular) {
		this.serialNumberOfCircular = serialNumberOfCircular;
	}

	public BigDecimal getaIGSTRate() {
		return aIGSTRate;
	}

	public void setaIGSTRate(BigDecimal aIGSTRate) {
		this.aIGSTRate = aIGSTRate;
	}

	public BigDecimal getaCGSTRate() {
		return aCGSTRate;
	}

	public void setaCGSTRate(BigDecimal aCGSTRate) {
		this.aCGSTRate = aCGSTRate;
	}

	public BigDecimal getaSGSTRate() {
		return aSGSTRate;
	}

	public void setaSGSTRate(BigDecimal aSGSTRate) {
		this.aSGSTRate = aSGSTRate;
	}

	public BigDecimal getaUTGSTRate() {
		return aUTGSTRate;
	}

	public void setaUTGSTRate(BigDecimal aUTGSTRate) {
		this.aUTGSTRate = aUTGSTRate;
	}

	public BigDecimal getaCessRate() {
		return aCessRate;
	}

	public void setaCessRate(BigDecimal aCessRate) {
		this.aCessRate = aCessRate;
	}

	public Character getIsTDS() {
		return isTDS;
	}

	public void setIsTDS(Character isTDS) {
		this.isTDS = isTDS;
	}

	public String getAdd1() {
		return add1;
	}

	public void setAdd1(String add1) {
		this.add1 = add1;
	}

	public String getAdd2() {
		return add2;
	}

	public void setAdd2(String add2) {
		this.add2 = add2;
	}

	public String getAdd3() {
		return add3;
	}

	public void setAdd3(String add3) {
		this.add3 = add3;
	}

	public BigDecimal getAdd4() {
		return add4;
	}

	public void setAdd4(BigDecimal add4) {
		this.add4 = add4;
	}

	public BigDecimal getAdd5() {
		return add5;
	}

	public void setAdd5(BigDecimal add5) {
		this.add5 = add5;
	}

}
