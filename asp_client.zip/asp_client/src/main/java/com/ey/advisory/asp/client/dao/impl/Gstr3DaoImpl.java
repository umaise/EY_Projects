package com.ey.advisory.asp.client.dao.impl;

import static java.util.stream.Collectors.toMap;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.SQLGrammarException;
import org.hibernate.jdbc.Work;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.Gstr3Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.BankAccountDetails;
import com.ey.advisory.asp.client.domain.CashITCLedgerMaster;
import com.ey.advisory.asp.client.domain.CashITCUtilization;
import com.ey.advisory.asp.client.domain.CashLedgerDetails;
import com.ey.advisory.asp.client.domain.CashUtilizationTransaction;
import com.ey.advisory.asp.client.domain.FIleSubmissionStatusDetails;
import com.ey.advisory.asp.client.domain.Gstr3AccountHead;
import com.ey.advisory.asp.client.domain.Gstr3OpeningClosingTaxPosition;
import com.ey.advisory.asp.client.domain.Gstr3OpeningClosingTaxPositionAmount;
import com.ey.advisory.asp.client.domain.Gstr3RefundDetails;
import com.ey.advisory.asp.client.domain.Gstr3TurnoverDetails;
import com.ey.advisory.asp.client.domain.ITCLedgerDetails;
import com.ey.advisory.asp.client.domain.ReturnSubmissionStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.dto.GSTR3RootDTO;
import com.ey.advisory.asp.client.dto.Gstr3Dto;
import com.ey.advisory.asp.client.dto.JsonUtility;
import com.ey.advisory.asp.client.util.CommonUtillity;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.GSTR3InterestLiablityDto;
import com.ey.advisory.asp.dto.GSTR3IntrLiabDto;
import com.ey.advisory.asp.dto.GSTR3RateDto;
import com.ey.advisory.asp.dto.GSTR3SubmitInterestDto;
import com.ey.advisory.asp.exception.DataException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class Gstr3DaoImpl implements Gstr3Dao {

	@Autowired
	private HibernateDao hibernateDao;

	private static final Logger LOGGER = Logger.getLogger(Gstr3DaoImpl.class);
	private static final String CLASS_NAME = Gstr3DaoImpl.class.getName();

	@Override
	public String saveTurnoverDetials(Gstr3TurnoverDetails gstr3TurnoverDetails) {
		try {
			if (gstr3TurnoverDetails != null) {
				Gstr3Dto gstr3Dto = new Gstr3Dto();
				gstr3Dto.setGstin(gstr3TurnoverDetails.getGstin());
				gstr3Dto.setRtPeriod(gstr3TurnoverDetails.getFinancialYear());
				List<Gstr3TurnoverDetails> turnoverDetails = fetchTurnoverDetails(gstr3Dto);
				Iterator<Gstr3TurnoverDetails> it = turnoverDetails.iterator();
				Gstr3TurnoverDetails details;
				while (it.hasNext()) {
					details = it.next();
					details.setActive(false);
					details.setUpdatedBy(gstr3TurnoverDetails.getCreatedBy());
					details.setUpdatedOn(new Date());
					hibernateDao.update(details);
				}
				hibernateDao.save(gstr3TurnoverDetails);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in saveTurnoverDetials" + e);
		}
		return "success";
	}

	public List<Gstr3TurnoverDetails> fetchTurnoverDetails(Gstr3Dto gstr3Dto) {
		List<Gstr3TurnoverDetails> turnoverDetails = null;
		try {
			if (gstr3Dto != null) {
				DetachedCriteria detachedCriteria = hibernateDao
						.createCriteria(Gstr3TurnoverDetails.class);
				detachedCriteria.add(Restrictions.eq("gstin",
						gstr3Dto.getGstin()));
				detachedCriteria.add(Restrictions.eq("financialYear",
						gstr3Dto.getRtPeriod()));
				detachedCriteria.add(Restrictions.eq("isActive", true));
				turnoverDetails = (List<Gstr3TurnoverDetails>) hibernateDao
						.find(detachedCriteria);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in fetchTurnoverDetails" + e);
		}
		return turnoverDetails;
	}

	@Override
	public String saveGstr3CashLegderDetails(String gstn,
			String jsonCashGstr3Data, String rtPeriod) {
		String procStatus = "";
		Session session = null;
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_SAVE_CASHDATA);
			queryString.append(" ?,?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());
			query.setString(0, gstn);
			query.setString(1, jsonCashGstr3Data);
			query.setString(2, rtPeriod);
			List procList = query.list();
			if (procList != null) {
				procStatus = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in saveGstr3CashLegderDetails" + e);
			try {
				closeSession(session);
			} catch (Exception ex) {
				LOGGER.error("Exception in saveGstr3CashLegderDetails" + ex);

			}
		} finally {
			closeSession(session);
		}
		return procStatus;
	}

	@Override
	public String saveGstr3ITCLegderDetails(String gstn,
			String jsonITCGstr3Data, String rtPeriod) {

		String procStatus = "";
		List procList = null;
		Session session = null;
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_SAVE_ITCDATA);
			queryString.append(" ?,?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());
			query.setString(0, gstn);
			query.setString(1, jsonITCGstr3Data);
			query.setString(2, rtPeriod);
			procList = query.list();
			if (procList != null) {
				procStatus = (String) procList.get(0);
			}

		} catch (Exception e) {
			LOGGER.error("Exception in saveGstr3ITCLegderDetails" + e);
			try {
				closeSession(session);
			} catch (Exception ex) {

				LOGGER.error(ex);
			}
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return procStatus;
	}

	@Override
	public String saveGstr3LiabilityLedgerDetail(String gstn, String rtPeriod,
			String jsonGstr3Data) {
		String procStatus = "";
		List procList = null;
		Session session = null;
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_SAVE_LIABDATA);
			queryString.append(" ?,?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());
			query.setString(0, gstn);
			query.setString(1, rtPeriod);
			query.setString(2, jsonGstr3Data);
			procList = query.list();
			if (procList != null) {
				procStatus = (String) procList.get(0);
			}

		} catch (Exception e) {
			LOGGER.error("Exception in saveGstr3LiabilityLedgerDetail" + e);
			try {
				closeSession(session);
			} catch (Exception ex) {
				LOGGER.error(ex);
			}
		} finally {
			closeSession(session);
		}

		return procStatus;
	}

	@Override
	public Gstr3TurnoverDetails getTurnoverDetials(Gstr3Dto gstr3Dto) {
		List<Gstr3TurnoverDetails> turnoverDetails = null;
		try {
			if (gstr3Dto != null) {
				turnoverDetails = fetchTurnoverDetails(gstr3Dto);
				;
				if (turnoverDetails != null && !turnoverDetails.isEmpty()) {
					return turnoverDetails.get(0);
				}
			}
		} catch (Exception e) {

			LOGGER.error("Exception in getTurnoverDetials" + e);

		}
		return new Gstr3TurnoverDetails();
	}

	@Override
	public List<String> getCashAutoFill(String gstn, String rtDate) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getCashAutoFill");
		List<String> procList = null;
		Session session = null;
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_CASHCREDIT_AUTOFILL);
			queryString.append(" ?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());

			if (!(CommonUtillity.isEmpty(gstn) && CommonUtillity
					.isEmpty(rtDate))) {
				query.setString(0, gstn);
				query.setString(1, rtDate);
				procList = query.list();
			}

		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : getCashAutoFill" + e);
			try {
				closeSession(session);
			} catch (Exception ex) {

				LOGGER.error("Exception in getTurnoverDetials" + ex);
			}
		} finally {
			closeSession(session);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getCashAutoFill");
		return procList;
	}

	/**
	 * Save the cash transaction details in the running ledgers
	 */
	@Override
	public String saveCashUtilizationTransaction(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : saveCashUtilizationTransaction");
		List<String> procList = null;
		String procStatus = "";
		Session session = null;
		// Need to change the SP name and parameters
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_CASH_SAVE_TRANSACTION);
			queryString.append(" ?,?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());
			if (!(CommonUtillity.isEmpty(gstr3Dto))
					&& !(CommonUtillity.isEmpty(gstr3Dto.getGstin()))
					&& !(CommonUtillity.isEmpty(gstr3Dto.getRtPeriod()))
					&& !(CommonUtillity.isEmpty(gstr3Dto.getCurrJsonData()))) {
				query.setString(0, gstr3Dto.getGstin());
				query.setString(1, gstr3Dto.getJsonData());
				query.setString(2, gstr3Dto.getRtPeriod());
				procList = query.list();

			}
			if (procList != null && !procList.isEmpty()) {
				procStatus = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : saveCashUtilizationTransaction" + e);
			try {
				closeSession(session);
			} catch (Exception ex) {
				LOGGER.error("Exception in saveCashUtilizationTransaction" + ex);
			}
		} finally {
			closeSession(session);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : saveCashUtilizationTransaction");
		return procStatus;
	}

	@Override
	public String saveReturnSubmissionStatus(
			ReturnSubmissionStatus rtSubmissionStatus) {
		String message = "";
		try {
			if (rtSubmissionStatus != null) {
				message = (String) hibernateDao.save(rtSubmissionStatus);
			}
		} catch (Exception e) {

			LOGGER.error("Exception in saveReturnSubmissionStatus" + e);
		}
		return message;
	}

	@Override
	public boolean updateFileStatus(Gstr3TurnoverDetails gstr3TurnoverDetails) {
		boolean saveStatus = false;
		Session session = hibernateDao.getSession();
		try {

			Query query = session
					.getNamedQuery("Gstr3TurnoverDetails.updateIsFiled");
			query.setParameter("GSTN", gstr3TurnoverDetails.getGstin());
			query.setParameter("FILED", gstr3TurnoverDetails.isFiled());
			query.setParameter("FYEAR", gstr3TurnoverDetails.getFinancialYear());
			query.executeUpdate();
			session.close();
			saveStatus = true;
		} catch (Exception e) {
			LOGGER.error("Exception in updateFileStatus" + e);
		} finally {
			closeSession(session);
		}
		return saveStatus;
	}

	@Override
	public String saveFileStatus(
			FIleSubmissionStatusDetails fIleSubmissionStatus) {
		try {
			if (fIleSubmissionStatus != null) {
				BigInteger i = (BigInteger) hibernateDao
						.save(fIleSubmissionStatus);
				fIleSubmissionStatus = getIsFiledStatus(i);
				if (fIleSubmissionStatus != null) {
					Gstr3TurnoverDetails gstr3TurnoverDetails = new Gstr3TurnoverDetails();
					gstr3TurnoverDetails.setFinancialYear(fIleSubmissionStatus
							.getReturnPeriod());
					gstr3TurnoverDetails.setGstin(fIleSubmissionStatus
							.getGstin());
					gstr3TurnoverDetails.setFiled(fIleSubmissionStatus
							.isFiled());
					updateFileStatus(gstr3TurnoverDetails);
				}
			}
		} catch (Exception e) {

			LOGGER.error("Exception in saveFileStatus" + e);
		}
		return "success";
	}

	private FIleSubmissionStatusDetails getIsFiledStatus(BigInteger i) {
		List<FIleSubmissionStatusDetails> fIleSubmissionStatus1 = null;
		try {
			DetachedCriteria detachedCriteria = hibernateDao
					.createCriteria(FIleSubmissionStatusDetails.class);
			detachedCriteria.add(Restrictions.eq("fIleSubmissionStatusUID", i));
			fIleSubmissionStatus1 = (List<FIleSubmissionStatusDetails>) hibernateDao
					.find(detachedCriteria);

			if (fIleSubmissionStatus1 != null
					&& !fIleSubmissionStatus1.isEmpty()) {

				return fIleSubmissionStatus1.get(0);
			}
		} catch (Exception e) {

			LOGGER.error("Exception in getIsFiledStatus" + e);
		}
		return null;
	}

	@Override
	public List<FIleSubmissionStatusDetails> getFileGstr3Status(
			Gstr3Dto gstr3Dto) {
		List<FIleSubmissionStatusDetails> fIleSubmissionStatus1 = null;
		try {
			if (gstr3Dto != null) {
				DetachedCriteria detachedCriteria = hibernateDao
						.createCriteria(FIleSubmissionStatusDetails.class);
				detachedCriteria.add(Restrictions.eq("gstin",
						gstr3Dto.getGstin()));
				detachedCriteria.add(Restrictions.eq("returnPeriod",
						gstr3Dto.getRtPeriod()));
				detachedCriteria.setProjection(Projections.property("isFiled"));
				fIleSubmissionStatus1 = (List<FIleSubmissionStatusDetails>) hibernateDao
						.find(detachedCriteria);
				if (fIleSubmissionStatus1.isEmpty()) {
					return (List<FIleSubmissionStatusDetails>) new FIleSubmissionStatusDetails();
				}
			}
		} catch (Exception e) {

			LOGGER.error("Exception in getFileGstr3Status" + e);
		}
		return fIleSubmissionStatus1;
	}

	@Override
	public List<CashUtilizationTransaction> getCashUtilizationTransaction(
			Gstr3Dto gstr3Dto) {
		List<CashUtilizationTransaction> cashUtilTrnxList = null;
		try {
			if (gstr3Dto != null) {
				DetachedCriteria detachedCriteria = hibernateDao
						.createCriteria(CashUtilizationTransaction.class);
				detachedCriteria.add(Restrictions.eq("gstin",
						gstr3Dto.getGstin()));
				detachedCriteria.add(Restrictions.eq("returnPeriod",
						gstr3Dto.getRtPeriod()));
				cashUtilTrnxList = (List<CashUtilizationTransaction>) hibernateDao
						.find(detachedCriteria);
			}
		} catch (Exception e) {

			LOGGER.error("Exception in getCashUtilizationTransaction" + e);
		}
		return cashUtilTrnxList;
	}

	@Override
	public List<ReturnSubmissionStatus> getITCCashDetials(Gstr3Dto gstr3Dto) {
		List<ReturnSubmissionStatus> returnSubmissionStatusList = null;
		try {
			if (gstr3Dto != null) {
				returnSubmissionStatusList = fetchITCCashDetails(gstr3Dto);
				if (returnSubmissionStatusList.isEmpty()) {
					return (List<ReturnSubmissionStatus>) new ReturnSubmissionStatus();

				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in getITCCashDetials" + e);
		}
		return returnSubmissionStatusList;

	}

	@Override
	public List<ReturnSubmissionStatus> fetchITCCashDetails(Gstr3Dto gstr3Dto) {
		List<ReturnSubmissionStatus> returnSubmissionStatusList = null;
		try {
			if (gstr3Dto != null) {

				DetachedCriteria detachedCriteria = hibernateDao
						.createCriteria(ReturnSubmissionStatus.class);
				detachedCriteria.add(Restrictions.eq("gstin",
						gstr3Dto.getGstin()));
				detachedCriteria.add(Restrictions.eq("rtPeriod",
						gstr3Dto.getRtPeriod()));
				detachedCriteria.add(Restrictions.eq("ledgerFlag", true));

				returnSubmissionStatusList = (List<ReturnSubmissionStatus>) hibernateDao
						.find(detachedCriteria);
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return returnSubmissionStatusList;

	}

	public boolean isFiled(Gstr3Dto gstr3Dto, String returnType) {
		boolean isFiled = false;
		List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatusList;
		DetachedCriteria detachedCriteria = hibernateDao
				.createCriteria(TblGstinRetutnFilingStatus.class);
		detachedCriteria
				.add(Restrictions.eq("id.gstinId", gstr3Dto.getGstin()));
		detachedCriteria.add(Restrictions.eq("id.returnType", returnType)
				.ignoreCase());
		if (returnType.equalsIgnoreCase(Constant.GSTR_3)) {
			detachedCriteria.add(Restrictions.ne("id.taxPeriod",
					gstr3Dto.getRtPeriod()));

		} else {
			detachedCriteria.add(Restrictions.eq("id.taxPeriod",
					gstr3Dto.getRtPeriod()));
		}
		tblGstinRetutnFilingStatusList = (List<TblGstinRetutnFilingStatus>) hibernateDao
				.find(detachedCriteria);
		if (tblGstinRetutnFilingStatusList.isEmpty()) {
			isFiled = false;
		} else {
			Iterator<TblGstinRetutnFilingStatus> it = tblGstinRetutnFilingStatusList
					.iterator();
			TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus;
			while (it.hasNext()) {
				tblGstinRetutnFilingStatus = it.next();
				if (null != tblGstinRetutnFilingStatus.getStatus()
						&& tblGstinRetutnFilingStatus.getStatus()
								.equalsIgnoreCase(Constant.FILED)) {
					isFiled = true;
				} else {
					isFiled = false;
					break;
				}
			}
		}
		return isFiled;
	}

	/**
	 * Get the liability details as on date.
	 */
	@Override
	public String getLiabilityPosition(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getLiabilityPosition");
		List procList = null;
		Session session = null;
		String liabilityJson = "";
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_GET_LIABDATA);
			queryString.append(" ?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());
			if (!(CommonUtillity.isEmpty(gstr3Dto)
					&& CommonUtillity.isEmpty(gstr3Dto.getGstin()) && CommonUtillity
						.isEmpty(gstr3Dto.getRtPeriod()))) {
				query.setString(0, gstr3Dto.getGstin());
				query.setString(1, gstr3Dto.getRtPeriod());
			}
			procList = query.list();
			if (procList != null && !procList.isEmpty()) {
				liabilityJson = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : getCashDataFromDB" + e);
			try {
				closeSession(session);
			} catch (Exception ex) {
				LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
						+ " Method : getCashDataFromDB" + e);
				throw ex;
			}
		} finally {
			closeSession(session);
		}
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getCashDataFromDB");
		return liabilityJson;
	}

	/**
	 * Get the liability details as on date.
	 */
	@Override
	public String getLiabilityDetails(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getLiabilityPosition");

		return null;

	}

	/**
	 * Get the cash position as on date
	 */
	@Override
	public String getCashPosition(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getCashPosition");
		List procList = null;
		String procStatus = "";
		Session session = null;
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_GET_CASHDATA);
			queryString.append(" ?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());
			// Need to change the input parameter once the SP is Ready
			if (!(CommonUtillity.isEmpty(gstr3Dto)
					&& CommonUtillity.isEmpty(gstr3Dto.getGstin()) && CommonUtillity
						.isEmpty(gstr3Dto.getRtPeriod()))) {
				query.setString(0, gstr3Dto.getGstin());
				query.setString(1, gstr3Dto.getRtPeriod());
			}

			procList = query.list();

			if (procList != null && !procList.isEmpty()) {
				procStatus = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : getCashPosition " + e);
			try {
				closeSession(session);
			} catch (Exception ex) {
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME
						+ " Method : getCashPosition " + ex);
			}
		} finally {
			closeSession(session);
		}

		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getCashPosition");
		return procStatus;
	}

	@Override
	public String getITCPosition(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getITCPosition");
		List procList = null;
		String procStatus = "";
		Session session = null;
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_GET_ITCDATA);
			queryString.append(" ?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());
			// Need to change the input parameter once the SP is Ready
			if (!(CommonUtillity.isEmpty(gstr3Dto)
					&& CommonUtillity.isEmpty(gstr3Dto.getGstin()) && CommonUtillity
						.isEmpty(gstr3Dto.getRtPeriod()))) {
				query.setString(0, gstr3Dto.getGstin());
				query.setString(1, gstr3Dto.getRtPeriod());
			}

			procList = query.list();

			if (procList != null && !procList.isEmpty()) {
				procStatus = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : getITCPosition " + e);
			try {
				closeSession(session);
			} catch (Exception ex) {
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME
						+ " Method : getITCPosition " + ex);
			}
		} finally {
			closeSession(session);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getITCPosition");
		return procStatus;
	}

	private void closeSession(Session session) {
		if (session != null && session.isOpen()) {
			session.close();
		}
	}

	@Override
	public boolean isPreviousTaxPeriodFiled(Gstr3Dto gstr3Dto) {
		boolean isFiled = isFiled(gstr3Dto, Constant.GSTR_3);
		return isFiled;
	}

	/**
	 * Get the consolidated cash transaction details from the DB
	 */
	@Override
	public String getConsCashTransaction(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getConsCashTransaction");
		List procList = null;
		String procStatus = "";
		Session session = null;
		// Need to change the SP Name once it is ready is Ready
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_GET_CASH_SUBMIT);
			queryString.append(" ?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());

			if (!(CommonUtillity.isEmpty(gstr3Dto)
					&& CommonUtillity.isEmpty(gstr3Dto.getGstin()) && CommonUtillity
						.isEmpty(gstr3Dto.getRtPeriod()))) {
				query.setString(0, gstr3Dto.getGstin());
				query.setString(1, gstr3Dto.getRtPeriod());
				procList = query.list();
			}
			if (procList != null && !procList.isEmpty()) {
				procStatus = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : getConsCashTransaction " + e);
			try {
				closeSession(session);
			} catch (Exception ex) {

				LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
						+ " Method : getConsCashTransaction " + ex);
			}
		} finally {
			closeSession(session);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getConsCashTransaction");
		return procStatus;
	}

	@Override
	public List<BankAccountDetails> fetchBankAccDetails(String Gstin) {
		List<BankAccountDetails> bankAccDetailList = null;
		try {
			DetachedCriteria detachedCriteria = hibernateDao
					.createCriteria(BankAccountDetails.class);
			detachedCriteria.createAlias("tblGstinDetailsDomain",
					"tblGstinDetailsDomain");
			detachedCriteria.add(Restrictions.eq(
					"tblGstinDetailsDomain.gstinId", Gstin));
			bankAccDetailList = (List<BankAccountDetails>) hibernateDao
					.find(detachedCriteria);
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return bankAccDetailList;
	}

	@Transactional
	@Override
	public String saveRefundDetails(Gstr3RefundDetails gstr3RefundDetails) {

		try {
			if (gstr3RefundDetails != null) {
				saveAmount(gstr3RefundDetails);

			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return "Success";

	}

	private Collection<Gstr3OpeningClosingTaxPositionAmount> saveOpClAmount(
			BigInteger taxPosId/*
								 * Gstr3OpeningClosingTaxPosition
								 * gstr3OpeningClosingTaxPosition
								 */, Gstr3RefundDetails gstr3RefundDetails) {
		Collection<Gstr3OpeningClosingTaxPositionAmount> opclList = new ArrayList<>();

		if (gstr3RefundDetails.getRefTaxIgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefTaxIgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefTaxCgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefTaxCgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefTaxSgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefTaxSgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefTaxCessAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefTaxCessAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefTaxUtgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefTaxUtgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}

		if (gstr3RefundDetails.getRefInterestIgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefInterestIgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefInterestCgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefInterestCgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefInterestSgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefInterestSgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefInterestCessAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefInterestCessAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefInterestUtgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefInterestUtgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}

		if (gstr3RefundDetails.getRefPenaltyIgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefPenaltyIgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefPenaltyCgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefPenaltyCgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefPenaltySgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefPenaltySgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefPenaltyCessAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefPenaltyCessAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefPenaltyUtgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefPenaltyUtgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}

		if (gstr3RefundDetails.getRefFeeIgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefFeeIgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefFeeCgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefFeeCgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefFeeSgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefFeeSgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefFeeCessAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefFeeCessAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefFeeUtgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefFeeUtgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}

		if (gstr3RefundDetails.getRefOthersIgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(1));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefOthersIgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefOthersCgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(2));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefOthersCgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefOthersSgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(3));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefOthersSgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefOthersCessAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefOthersCessAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}
		if (gstr3RefundDetails.getRefOthersUtgstAmt() != null) {
			Gstr3OpeningClosingTaxPositionAmount gstr3OpeningClosingTaxPositionAmount = new Gstr3OpeningClosingTaxPositionAmount();
			gstr3OpeningClosingTaxPositionAmount.setTaxPositionID(taxPosId);
			gstr3OpeningClosingTaxPositionAmount.setTaxHeadID(BigInteger
					.valueOf(4));
			gstr3OpeningClosingTaxPositionAmount.setTaxSubHeadID(BigInteger
					.valueOf(5));
			gstr3OpeningClosingTaxPositionAmount
					.setAmount((BigDecimal) gstr3RefundDetails
							.getRefOthersUtgstAmt());
			opclList.add(gstr3OpeningClosingTaxPositionAmount);
		}

		return opclList;

	}

	private void saveAmount(Gstr3RefundDetails gstr3RefundDetails) {
		Gstr3OpeningClosingTaxPosition gstr3OpeningClosingTaxPosition = new Gstr3OpeningClosingTaxPosition();
		gstr3OpeningClosingTaxPosition.setGstin(gstr3RefundDetails.getGstin());
		gstr3OpeningClosingTaxPosition.setTaxPeriod(gstr3RefundDetails
				.getReturnPeriod());
		gstr3OpeningClosingTaxPosition.setLedgerEntryDate(new Date());
		gstr3OpeningClosingTaxPosition.setActive(true);
		gstr3OpeningClosingTaxPosition.setLedgerTypeID(BigInteger.valueOf(3));
		BankAccountDetails bankAccountDetails = fetchBankAccDetails(
				gstr3RefundDetails.getGstin()).get(0);
		gstr3RefundDetails.setBankAccNo(bankAccountDetails.getBankAccNo());
		gstr3OpeningClosingTaxPosition
				.setBankAccountDetails(bankAccountDetails);
		BigInteger i = (BigInteger) hibernateDao
				.save(gstr3OpeningClosingTaxPosition);
		Collection<Gstr3OpeningClosingTaxPositionAmount> gstr3OpeningClosingTaxPositionAmountList = saveOpClAmount(
				i/* gstr3OpeningClosingTaxPosition */, gstr3RefundDetails);
		hibernateDao.saveOrUpdateAll(gstr3OpeningClosingTaxPositionAmountList);

	}

	@Override
	public Gstr3RefundDetails getRefundDetail(
			Gstr3RefundDetails gstr3RefundDetails) {

		Gstr3RefundDetails gstr3RfdDetails = new Gstr3RefundDetails();
		try {
			Gstr3Dto gstr3Dto = new Gstr3Dto();
			gstr3Dto.setGstin(gstr3RefundDetails.getGstin());
			gstr3Dto.setRtPeriod(gstr3RefundDetails.getReturnPeriod());
			String response = getCashPosition(gstr3Dto);

			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject;
			jsonObject = (JSONObject) jsonParser.parse(response);
			JSONArray cashBalance = (JSONArray) jsonObject.get("Cash Balance");
			JSONObject cashVal = (JSONObject) cashBalance.get(0);
			double intrestcess = (double) cashVal.get("Interest");
			double feecess = (double) cashVal.get("Late Fees");
			double otherscess = (double) cashVal.get("Others");
			double penaltycess = (double) cashVal.get("Penalty");
			double txcess = (double) cashVal.get("Tax");
			double totalcess = (double) cashVal.get("Total");

			double intrestcgst = (double) cashVal.get("Interest");
			double feecgst = (double) cashVal.get("Late Fees");
			double otherscgst = (double) cashVal.get("Others");
			double penaltycgst = (double) cashVal.get("Penalty");
			double txcgst = (double) cashVal.get("Tax");
			double totalcgst = (double) cashVal.get("Total");

			double intrestIgst = (double) cashVal.get("Interest");
			double feeIgst = (double) cashVal.get("Late Fees");
			double othersIgst = (double) cashVal.get("Others");
			double penaltyIgst = (double) cashVal.get("Penalty");
			double txIgst = (double) cashVal.get("Tax");
			double totalIgst = (double) cashVal.get("Total");

			double intrestsgst = (double) cashVal.get("Interest");
			double feesgst = (double) cashVal.get("Late Fees");
			double otherssgst = (double) cashVal.get("Others");
			double penaltysgst = (double) cashVal.get("Penalty");
			double txsgst = (double) cashVal.get("Tax");
			double totalsgst = (double) cashVal.get("Total");

			gstr3RfdDetails.setRefTaxIgstAmt(BigDecimal.valueOf(txIgst));
			gstr3RfdDetails.setRefTaxCgstAmt(BigDecimal.valueOf(txcgst));
			gstr3RfdDetails.setRefTaxSgstAmt(BigDecimal.valueOf(txsgst));
			gstr3RfdDetails.setRefTaxCessAmt(BigDecimal.valueOf(txcess));
			gstr3RfdDetails.setRefTaxUtgstAmt(BigDecimal.valueOf(0.0));

			gstr3RfdDetails.setRefInterestIgstAmt(BigDecimal
					.valueOf(intrestIgst));
			gstr3RfdDetails.setRefInterestCgstAmt(BigDecimal
					.valueOf(intrestcgst));
			gstr3RfdDetails.setRefInterestSgstAmt(BigDecimal
					.valueOf(intrestsgst));
			gstr3RfdDetails.setRefInterestCessAmt(BigDecimal
					.valueOf(intrestcess));
			gstr3RfdDetails.setRefInterestUtgstAmt(BigDecimal.valueOf(0.0));

			gstr3RfdDetails.setRefPenaltyIgstAmt(BigDecimal
					.valueOf(penaltyIgst));
			gstr3RfdDetails.setRefPenaltyCgstAmt(BigDecimal
					.valueOf(penaltycgst));
			gstr3RfdDetails.setRefPenaltySgstAmt(BigDecimal
					.valueOf(penaltysgst));
			gstr3RfdDetails.setRefPenaltyCessAmt(BigDecimal
					.valueOf(penaltycess));
			gstr3RfdDetails.setRefPenaltyUtgstAmt(BigDecimal.valueOf(0.0));

			gstr3RfdDetails.setRefFeeIgstAmt(BigDecimal.valueOf(feeIgst));
			gstr3RfdDetails.setRefFeeCgstAmt(BigDecimal.valueOf(feecgst));
			gstr3RfdDetails.setRefFeeSgstAmt(BigDecimal.valueOf(feesgst));
			gstr3RfdDetails.setRefFeeCessAmt(BigDecimal.valueOf(feecess));
			gstr3RfdDetails.setRefFeeUtgstAmt(BigDecimal.valueOf(0.0));

			gstr3RfdDetails.setRefOthersIgstAmt(BigDecimal.valueOf(othersIgst));
			gstr3RfdDetails.setRefOthersCgstAmt(BigDecimal.valueOf(otherscgst));
			gstr3RfdDetails.setRefOthersSgstAmt(BigDecimal.valueOf(otherssgst));
			gstr3RfdDetails.setRefOthersCessAmt(BigDecimal.valueOf(otherscess));
			gstr3RfdDetails.setRefOthersUtgstAmt(BigDecimal.valueOf(0.0));

			gstr3RfdDetails.setRefTotalIgstAmt(BigDecimal.valueOf(totalIgst));
			gstr3RfdDetails.setRefTotalCgstAmt(BigDecimal.valueOf(totalcgst));
			gstr3RfdDetails.setRefTotalSgstAmt(BigDecimal.valueOf(totalsgst));
			gstr3RfdDetails.setRefTotalCessAmt(BigDecimal.valueOf(totalcess));

			BankAccountDetails arr = fetchBankAccDetails(
					gstr3RefundDetails.getGstin()).get(0);
			gstr3RfdDetails.setBankAccNo(arr.getBankAccNo());

		} catch (Exception e) {
			LOGGER.error("Exception in getRefundDetail " + e);

		}
		return gstr3RfdDetails;
	}

	@Override
	public String autoFillItc(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : autoFillItc");
		List procList = null;
		String procStatus = "";
		Session session = null;
		// Need to change the SP Name once it is ready is Ready
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_AUTO_FILL_ITC);
			queryString.append(" ?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());

			if (!(CommonUtillity.isEmpty(gstr3Dto)
					&& CommonUtillity.isEmpty(gstr3Dto.getGstin()) && CommonUtillity
						.isEmpty(gstr3Dto.getRtPeriod()))) {
				query.setString(0, gstr3Dto.getGstin());
				query.setString(1, gstr3Dto.getRtPeriod());
				procList = query.list();
			}
			if (procList != null && !procList.isEmpty()) {
				procStatus = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : autoFillItc " + e);
			try {
				closeSession(session);
			} catch (Exception ex) {
				LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
						+ " Method : autoFillItc" + ex);
			}
		} finally {
			closeSession(session);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getConsCashTransaction");
		return procStatus;
	}

	@Override
	public String saveItc(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : saveItc");
		String saveItcRes = "";
		List procList = null;
		Session session = null;
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_SAVE_ITC);
			queryString.append(" ?,?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());

			if (!(CommonUtillity.isEmpty(gstr3Dto)
					&& CommonUtillity.isEmpty(gstr3Dto.getGstin()) && CommonUtillity
						.isEmpty(gstr3Dto.getRtPeriod()))) {
				query.setString(0, gstr3Dto.getGstin());
				query.setString(1, gstr3Dto.getJsonData());
				query.setString(2, gstr3Dto.getRtPeriod());
				procList = query.list();
			}
			if (procList != null && !procList.isEmpty()) {
				saveItcRes = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : saveItc " + e);
			try {
				closeSession(session);
			} catch (Exception ex) {
				LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
						+ " Method : saveItc " + ex);
			}
		} finally {
			closeSession(session);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : saveItc");
		return saveItcRes;
	}

	@Override
	public String submitItc(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : submitItc");
		List procList = null;
		String itcJson = "";
		Session session = null;
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_SUBMIT_ITC);
			queryString.append(" ?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());

			if (!(CommonUtillity.isEmpty(gstr3Dto)
					&& CommonUtillity.isEmpty(gstr3Dto.getGstin()) && CommonUtillity
						.isEmpty(gstr3Dto.getRtPeriod()))) {
				query.setString(0, gstr3Dto.getGstin());
				query.setString(1, gstr3Dto.getRtPeriod());
				procList = query.list();
			}
			if (procList != null && !procList.isEmpty()) {
				itcJson = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : submitItc " + e);
			try {
				closeSession(session);
			} catch (Exception ex) {
				LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
						+ " Method : submitItc " + ex);
			}
		} finally {
			closeSession(session);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : submitItc");
		return itcJson;
	}

	@Override
	public String getItcBalance(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getItcBalance");
		List procList = null;
		String itcBalanceJson = "";
		Session session = null;
		// Need to change the SP Name once it is ready is Ready
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.GSTR3_PROC_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.PROC_GSTR3_ITC_BALANCE);
			queryString.append(" ?,?");

			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());

			if (!(CommonUtillity.isEmpty(gstr3Dto)
					&& CommonUtillity.isEmpty(gstr3Dto.getGstin()) && CommonUtillity
						.isEmpty(gstr3Dto.getRtPeriod()))) {
				query.setString(0, gstr3Dto.getGstin());
				query.setString(1, gstr3Dto.getRtPeriod());
				procList = query.list();
			}
			if (procList != null && !procList.isEmpty()) {
				itcBalanceJson = (String) procList.get(0);
			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : getItcBalance " + e);
			try {
				closeSession(session);
			} catch (Exception ex) {

				LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
						+ " Method : getItcBalance " + ex);
			}
		} finally {
			closeSession(session);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getItcBalance");
		return itcBalanceJson;
	}

	@Override
	public List<String> checkISDGstin(String gstin) {

		String queryStr = "select a.typeOfReg from  TblGstinDetailsDomain a where a.gstinId = '"
				+ gstin + "'";
		Session session = null;
		session = hibernateDao.getSession();
		Query query = session.createQuery(queryStr);
		List<String> entityGstins = null;

		try {
			entityGstins = query.list();

		} catch (Exception e) {

			LOGGER.error(Constant.LOGGER_ERROR + " " + Constant.LOGGER_METHOD,
					e);

		} finally {
			closeSession(session);
		}
		return entityGstins;

	}

	/* Method to get saved interest liability from db */

	@Override
	public String getInterestLiabilitySaved(Gstr3Dto gstr3Dto) {

		String json = "";
		Session session = hibernateDao.getSession();

		String queryString = "SELECT [Group],IGSTAmt,CGSTAmt,SGSTAmt,CessAmt FROM gstr3.tblgstr3LiabilityCorrection as det inner join  master.tblgstr3TileMaster as tile on det.TileID = tile.ID inner join gstr3.tblGetgstr3Master as mast on  det.MasterID = mast.id where (tile.[group]='"
				+ Constant.TABLE_10_4
				+ "' OR tile.[group]='"
				+ Constant.TABLE_10_7
				+ "' OR tile.[group]='"
				+ Constant.TABLE_10_8
				+ "') and mast.gstin='"
				+ gstr3Dto.getGstin()
				+ "' and mast.TaxPeriod ='"
				+ gstr3Dto.getRtPeriod() + "'";

		try {

			List<Object[]> result = session.createSQLQuery(queryString).list();

			json = convertInterestCorrectionDTOtoJson(result);

			// System.out.println();
		} catch (Exception e) {
			LOGGER.error("-- Error in method fetchSavedInterestLiability for -- gstin:"
					+ gstr3Dto.getGstin()
					+ " and taxperiod :"
					+ gstr3Dto.getRtPeriod());
			LOGGER.error("Exception in fetchSavedInterestLiability" + e);
		} finally {
			if (session != null)
				session.close();
		}
		return json;
	}

	@Override
	public boolean fetchRecordfromDB(Gstr3Dto gstr3Dto) throws DataException {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("-- Inside method fetrecord -- gstin:"
					+ gstr3Dto.getGstin() + " and taxperiod :"
					+ gstr3Dto.getRtPeriod());
		}

		String queryString = "select count(*) from [gstr3].[tblgetgstr3Details] det join gstr3.tblGetgstr3Master mast on det.masterid = mast.id where  mast.GSTIN = '"
				+ gstr3Dto.getGstin()
				+ "' and mast.TaxPeriod = '"
				+ gstr3Dto.getRtPeriod()
				+ "' and mast.isActive=1 and det.isActive =1";

		Session session = null;
		try {

			session = hibernateDao.getSession();
			int rows = (int) session.createSQLQuery(queryString).uniqueResult();

			return rows > 0 ? true : false;

		} catch (SQLGrammarException e) {

			LOGGER.error("-- Error in method fetchrecord for -- gstin:"
					+ gstr3Dto.getGstin() + " and taxperiod :"
					+ gstr3Dto.getRtPeriod());
			LOGGER.error("Exception in fetchrecord" + e.getMessage());
			throw new DataException(e.getMessage(), e);
		}

		finally {

			if (session != null && session.isOpen())
				session.close();
		}

	}

	// method to contruct json
	public String convertInterestCorrectionDTOtoJson(List<Object[]> result) {

		GSTR3SubmitInterestDto interestdto = new GSTR3SubmitInterestDto();
		interestdto.setIntr_liab(new GSTR3IntrLiabDto());

		String json = "";
		for (Object[] row : result) {

			GSTR3RateDto dto = new GSTR3RateDto();
			dto.setImat(Double.parseDouble(row[1].toString()));
			dto.setCamt(Double.parseDouble(row[2].toString()));
			dto.setSamt(Double.parseDouble(row[3].toString()));
			dto.setCess(Double.parseDouble(row[4].toString()));

			if (row[0].toString().equalsIgnoreCase(Constant.TABLE_10_4)) {
				interestdto.getIntr_liab().setOth_itc_rvl_usr(dto);
			} else if (row[0].toString().equalsIgnoreCase(Constant.TABLE_10_7)) {
				interestdto.getIntr_liab().setIntr_liab_fwd_usr(dto);
			} else if (row[0].toString().equalsIgnoreCase(Constant.TABLE_10_8)) {
				interestdto.getIntr_liab().setDel_pymt_tx_usr(dto);
			}
		}

		try {
			json = new ObjectMapper().writeValueAsString(interestdto);
		} catch (JsonProcessingException e) {
			LOGGER.error("Exception in convertjson to dto" + e);
		}
		return json;
	}

	public boolean saveGSTR3GetDetails(List<String> insertStatemens)
			throws Exception {

		boolean saveStatus = false;
		Session session = hibernateDao.getSession();
		// Iterator<InvoiceProcessDto> invoiceIterator=invoiceList.iterator();
		try {

			Transaction tx = session.beginTransaction();
			long startTime = System.currentTimeMillis();
			session.doWork(new Work() {
				public void execute(Connection connection) throws SQLException {
					Statement preparedStatement = connection.createStatement();
					int i = 0;
					int[] count;
					try {

						for (String insertStatement : insertStatemens) {
							i++;
							preparedStatement.addBatch(insertStatement);

							if (i % Constant.SQL_BATCH_SIZE == 0) {
								count = preparedStatement.executeBatch();
								LOGGER.info("Executing batch");
							}
						}

						count = preparedStatement.executeBatch();
						LOGGER.info(count.length + " updated : ");

					} finally {
						if (preparedStatement != null) {
							preparedStatement.close();
						}
					}

				}
			});

			tx.commit();
			session.close();
			LOGGER.info("Total Time taken to insert " + insertStatemens.size()
					+ " sattement : "
					+ (System.currentTimeMillis() - startTime)
					+ " Milli Seconds");

			saveStatus = true;
		} catch (Exception e) {
			LOGGER.error(e);
			// ToDo add the custom exceptions for database
			throw new Exception(e);
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return saveStatus;
	}

	public static void main(String args[]) {
		List<GSTR3RateDto> list = new ArrayList<>();

		String[] vals = new String[3];
		vals[0] = Constant.TABLE_10_4;
		vals[1] = Constant.TABLE_10_7;
		vals[2] = Constant.TABLE_10_8;

		for (int i = 0; i < 3; i++) {
			GSTR3RateDto d = new GSTR3RateDto();
			d.setGroup(vals[i]);
			d.setCamt(100.0);
			d.setCess(10.0);
			d.setImat(99.0);
			d.setSamt(100.0);

			list.add(d);
		}

		// String aaa= new
		// Gstr3DaoImpl().convertInterestCorrectionDTOtoJson(list);

		// System.out.println(aaa);
	}

	// save Sandeep
	@Override
	public String saveGstr3Details(int masterId, GSTR3RootDTO gstr3Dto)
			throws DataException {
		String status = Constant.FAILED;
		Session session = null;
		Transaction tx = null;

		String queryString = "select id,SubGroup,[Group],TableType from master.tblgstr3TileMaster";
		try {

			session = hibernateDao.getSession();
			List<Object[]> rows = session.createSQLQuery(queryString).list();

			Map<String, Integer> tileMap = rows.stream().collect(
					toMap(e -> fetchGroupsubgroup(e),
							e -> ((BigInteger) e[0]).intValue()));

			List<String> insertStatements = gstr3Dto.fetchInsertScripts(
					masterId, tileMap);

			tx = session.beginTransaction();
			long startTime = System.currentTimeMillis();

			// session.createSQLQuery("insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values (1,8,10.0,null,2509.27,100.0,null,null,80.0,1)").executeUpdate();

			session.doWork(new Work() {
				public void execute(Connection connection) throws SQLException {
					Statement preparedStatement = connection.createStatement();
					int i = 0;
					int[] count;
					try {

						for (String insertStatement : insertStatements) {
							i++;
							preparedStatement.addBatch(insertStatement);

							if (i % Constant.SQL_BATCH_SIZE == 0) {
								count = preparedStatement.executeBatch();
							}
						}
						count = preparedStatement.executeBatch();
						if (LOGGER.isInfoEnabled())
							LOGGER.info(count.length + " updated : ");

					} finally {
						if (preparedStatement != null) {
							preparedStatement.close();
						}
					}

				}

			});

			tx.commit();

			LOGGER.info("Total Time taken to insert " + insertStatements.size()
					+ " sattement : "
					+ (System.currentTimeMillis() - startTime)
					+ " Milli Seconds");

			status = Constant.SUCCESS;
		} catch (SQLGrammarException e) {
			LOGGER.error("Error while executing Insertscript " + e.getMessage());
			if (tx != null)
				tx.rollback();

			throw new DataException(e.getMessage(), e);

		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return status;
	}

	private String fetchGroupsubgroup(Object[] obj) {
		// TODO Auto-generated method stub
		System.out.println("Inside" + obj[0]);
		if (obj[1] != null && !obj[1].toString().isEmpty())
			return obj[1].toString();
		else if (obj[2] != null && !obj[2].toString().isEmpty())
			return obj[2].toString();
		else
			return obj[3].toString();
	}

	@Override
	public String getSummaryJSON(Gstr3Dto gstr3dto) throws DataException {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getSummaryJSON ");

		// String status = "failure";
		String responseJson = "";
		Session session = hibernateDao.getSession();

		String sqlSelect = "Select [TableType],[Group],[Subgroup],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],details.[IsActive] FROM [gstr3].[tblgetgstr3Details] details inner JOIN  [master].[tblgstr3TileMaster] tMaster on details.TileID = tMaster.ID inner JOIN  [gstr3].[tblGetgstr3Master] gMaster on details.MasterId = gMaster.ID where GSTIN='"
				+ gstr3dto.getGstin()
				+ "' and taxperiod='"
				+ gstr3dto.getRtPeriod()
				+ "' and gMaster.IsActive=1 and details.IsActive =1";

		String sqlTod = "Select [TableType],[Group],[TurnOver],details.[IsActive] FROM [gstr3].[tblgstr3TurnOverDetails] details JOIN  [master].[tblgstr3TileMaster] tMaster on details.TileID = tMaster.ID JOIN  [gstr3].[tblGetgstr3Master] gMaster on details.MasterID = gMaster.ID where gMaster.GSTIN='"
				+ gstr3dto.getGstin()
				+ "' and gMaster.taxperiod='"
				+ gstr3dto.getRtPeriod()
				+ "' and gMaster.IsActive=1 and details.IsActive =1";

		String sqlRefund = "Select [Tax],[Interest],[Penalty],[Fee],[Other],refund.[DebitEntryNum],[AccountNumber],[CLAIMTYPE],refund.[IsActive] FROM [gstr3].[tblgstr3RefundClaim] refund JOIN  [gstr3].[tblGetgstr3Master] gMaster on refund.MasterID = gMaster.ID where gMaster.GSTIN=  '"
				+ gstr3dto.getGstin()
				+ "'and taxperiod = '"
				+ gstr3dto.getRtPeriod()
				+ "' and gMaster.IsActive=1 and refund.IsActive =1";

		//
		String sqlsaveCorrection = "Select IntrestLiabilitySubmitted,InterestLiabilitySaved FROM [gstr3].[tblGetgstr3Master] gMaster where GSTIN='"
				+ gstr3dto.getGstin()
				+ "' and taxperiod='"
				+ gstr3dto.getRtPeriod() + "' and gMaster.IsActive=1";

		String sqlcorrectionSelect = "Select [TableType],[Group],[Subgroup],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],details.[IsActive] FROM [gstr3].[tblgstr3LiabilityCorrection] details inner JOIN  [master].[tblgstr3TileMaster] tMaster on details.TileID = tMaster.ID inner JOIN  [gstr3].[tblGetgstr3Master] gMaster on details.MasterId = gMaster.ID where GSTIN='"
				+ gstr3dto.getGstin()
				+ "' and taxperiod='"
				+ gstr3dto.getRtPeriod()
				+ "' and gMaster.IsActive=1 and details.IsActive =1";

		String sqlcorrectionTableSelect = "Select [TableType],[Group],[Subgroup],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],details.[IsActive] FROM [gstr3].[tblgetgstr3Details] details inner JOIN  [master].[tblgstr3TileMaster] tMaster on details.TileID = tMaster.ID inner JOIN  [gstr3].[tblGetgstr3Master] gMaster on details.MasterId = gMaster.ID where GSTIN='"
				+ gstr3dto.getGstin()
				+ "' and taxperiod='"
				+ gstr3dto.getRtPeriod()
				+ "' and gMaster.IsActive=1 and details.IsActive =1 and tMaster.[Group] NOT IN ('T.10.4','T.10.7','T.10.8')";

		SQLQuery sqlQuery;
		Transaction tx = null;

		try {
			 tx = session.beginTransaction();

			// check interest liability saved ,submit toggle
			sqlQuery = session.createSQLQuery(sqlsaveCorrection);

			Object[] result = (Object[]) sqlQuery.uniqueResult();

			boolean isSubmit = (boolean) result[0];
			boolean isSave = (boolean) result[1];

			List<Object[]> results = new ArrayList<Object[]>();

			if (isSave && !isSubmit) {

				sqlQuery = session.createSQLQuery(sqlcorrectionTableSelect);

				results = sqlQuery.list();
			} else {
				sqlQuery = session.createSQLQuery(sqlSelect);

				results = sqlQuery.list();
			}

			List<Map<String, Object>> list = new ArrayList<>();

			for (Object[] object : results) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put(Constant.TABLETYPE, object[0]);
				map.put(Constant.GROUP, object[1]);
				map.put(Constant.SUBGROUP, object[2]);
				map.put(Constant.RATE, object[3]);
				map.put(Constant.EGSIN, object[4]);
				map.put(Constant.TAXABLEVALUE, object[5]);
				map.put(Constant.IGST_AMOUNT, object[6]);
				map.put(Constant.CGST_AMOUNT, object[7]);
				map.put(Constant.SGST_AMOUNT, object[8]);
				map.put(Constant.CESS_AMOUNT, object[9]);
				map.put(Constant.ISACTIVE, object[10]);
				list.add(map);
			}

			if (isSave && !isSubmit) {
				sqlQuery = session.createSQLQuery(sqlcorrectionSelect);
				results = sqlQuery.list();

				for (Object[] object : results) {
					Map<String, Object> map = new HashMap<String, Object>();
					map.put(Constant.TABLETYPE, object[0]);
					map.put(Constant.GROUP, object[1]);
					map.put(Constant.SUBGROUP, object[2]);
					map.put(Constant.RATE, object[3]);
					map.put(Constant.EGSIN, object[4]);
					map.put(Constant.TAXABLEVALUE, object[5]);
					map.put(Constant.IGST_AMOUNT, object[6]);
					map.put(Constant.CGST_AMOUNT, object[7]);
					map.put(Constant.SGST_AMOUNT, object[8]);
					map.put(Constant.CESS_AMOUNT, object[9]);
					map.put(Constant.ISACTIVE, object[10]);
					list.add(map);
				}
			}

			sqlQuery = session.createSQLQuery(sqlTod);

			results = sqlQuery.list();

			for (Object[] object : results) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put(Constant.TABLETYPE, object[0]);
				map.put(Constant.GROUP, object[1]);
				map.put(Constant.TURNOVER, object[2]);

				list.add(map);
			}

			// For Refund Details
			sqlQuery = session.createSQLQuery(sqlRefund);

			results = sqlQuery.list();

			for (Object[] object : results) {

				Map<String, Object> map = new HashMap<String, Object>();
				map.put(Constant.TABLETYPE, Constant.TABLE_TYPE_14);
				map.put(Constant.TAX, object[0]);
				map.put(Constant.INTEREST, object[1]);
				map.put(Constant.PENALTY, object[2]);
				map.put(Constant.FEE, object[3]);
				map.put(Constant.OTHER, object[4]);
				map.put(Constant.DEBITENTRYNUM, object[5]);
				map.put(Constant.ACCOUNTNUMBER, object[6]);
				map.put(Constant.CLAIMTYPE, object[7]);
				list.add(map);

			}

			Map<String, List<Map<String, Object>>> mapGrpBytABLEtYPE = groupByTableType(list);
			GSTR3RootDTO dto = new GSTR3RootDTO();// (GSTR3RootDTO)
													// JsonUtility.parseJsonToDTO(jsonString);
			dto.populateRootDTO(mapGrpBytABLEtYPE);
			responseJson = JsonUtility.parseDTOtoJson(dto);
			// System.out.println(responseJson);

			tx.commit();
			// session.close();
			// status = "success";

		} catch (SQLGrammarException e) {

			LOGGER.error("Error in getSummaryJSON " + e.getMessage());
			throw new DataException(e.getMessage(), e);
		}

		finally {
			if (session != null)
				session.close();
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getSummaryJSON");
		return responseJson;
	}

	public static Map<String, List<Map<String, Object>>> groupByTableType(
			List<Map<String, Object>> list) {
		// public static Map<String, List<Map<String, String>>>
		// groupByTableType(List <Object[]> list) {
		Map<String, List<Map<String, Object>>> mapGrpBytABLEtYPE = new HashMap<>();

		for (Map<String, Object> map : list) {
			if (mapGrpBytABLEtYPE.containsKey(map.get(Constant.TABLETYPE))) {
				List<Map<String, Object>> list2 = mapGrpBytABLEtYPE.get(map
						.get(Constant.TABLETYPE));
				list2.add(map);
			} else {
				List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();
				list2.add(map);
				mapGrpBytABLEtYPE.put(map.get(Constant.TABLETYPE).toString(),
						list2);
			}
		}
		return mapGrpBytABLEtYPE;
	}

	@Override
	public int findMasterDetails(Gstr3Dto gstr3Dto) throws DataException {
		
		BigInteger id = BigInteger.ZERO;
		Session session = null;

		String sqlSelect = "Select id FROM [gstr3].[tblGetgstr3Master] where GSTIN='"
				+ gstr3Dto.getGstin()
				+ "' and taxperiod='"
				+ gstr3Dto.getRtPeriod() + "' and isActive = 1";

		try {
			session = hibernateDao.getSession();
			Transaction tx = session.beginTransaction();
			SQLQuery sqlQuery = session.createSQLQuery(sqlSelect);
			id = (BigInteger) sqlQuery.uniqueResult();

			tx.commit();
			
			//return id.intValue();
		} catch (SQLGrammarException e) {
			throw new DataException(e.getMessage(), e);
		} 
		finally{
			if(session != null && session.isOpen())
			session.close();
			}
		return id.intValue();
	}

	@Override
	public boolean saveInterestLiability(GSTR3InterestLiablityDto dto) {

		if (LOGGER.isDebugEnabled())
			LOGGER.debug(Constant.LOGGER_ENTERING + CLASS_NAME
					+ " Method : saveInterestLiability ");

		boolean status = false;
		SQLQuery sqlQuery;
		Session session = hibernateDao.getSession();

		String gstin = "'" + dto.getGstin() + "'";
		String taxPeriod = "'" + dto.getTaxPeriod() + "'";

		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		SimpleDateFormat f = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss.SSS");
		String currentTimeStamp = f.format(new Date());

		if (LOGGER.isInfoEnabled())
			LOGGER.info(Constant.LOGGER_ENTERING
					+ " Saving Interest Liabilities For GSTIN " + gstin
					+ " and Taxperiod " + taxPeriod);

		double itcRvlIgst = dto.getIntr_liab().getOth_itc_rvl_usr().getIamt();
		double itcRvlCgst = dto.getIntr_liab().getOth_itc_rvl_usr().getCamt();
		double itcRvlSgst = dto.getIntr_liab().getOth_itc_rvl_usr().getSamt();
		double itcRvlCessgst = dto.getIntr_liab().getOth_itc_rvl_usr()
				.getCess();

		double liabFwdIgst = dto.getIntr_liab().getIntr_liab_fwd_usr()
				.getIamt();
		double liabFwdCgst = dto.getIntr_liab().getIntr_liab_fwd_usr()
				.getCamt();
		double liabFwdSgst = dto.getIntr_liab().getIntr_liab_fwd_usr()
				.getSamt();
		double liabFwdCessgst = dto.getIntr_liab().getIntr_liab_fwd_usr()
				.getCess();

		double pymtTxIgst = dto.getIntr_liab().getDel_pymt_tx_usr().getIamt();
		double pymtTxCgst = dto.getIntr_liab().getDel_pymt_tx_usr().getCamt();
		double pymtTxSgst = dto.getIntr_liab().getDel_pymt_tx_usr().getSamt();
		double pymtTxCessgst = dto.getIntr_liab().getDel_pymt_tx_usr()
				.getCess();

		String masterIdRet = "select ID from gstr3.tblGetgstr3Master where GSTIN="
				+ gstin + "and TaxPeriod=" + taxPeriod + "and isActive= 1";

		Transaction tx = session.beginTransaction();

		try {

			sqlQuery = session.createSQLQuery(masterIdRet);

			List<BigInteger> list = sqlQuery.list();

			Object result = sqlQuery.uniqueResult();
			String masterID = result.toString();

			String newCheck = "select ID from gstr3.tblgstr3LiabilityCorrection where MasterID='"
					+ masterID + "'";

			sqlQuery = session.createSQLQuery(newCheck);

			List<BigInteger> newlist = sqlQuery.list();

			if (newlist.size() > 0) {

				// If record is there data will be updated in
				// "gstr3.tblgstr3LiabilityCorrection" table

				session.doWork(new Work() {
					public void execute(Connection connection)
							throws SQLException {
						Statement statement = connection.createStatement();

						int[] count;

						String updateItcRvl = "UPDATE gstr3.tblgstr3LiabilityCorrection SET IGSTAmt="
								+ itcRvlIgst
								+ ",CGSTAmt="
								+ itcRvlCgst
								+ ",SGSTAmt="
								+ itcRvlSgst
								+ ",CessAmt="
								+ itcRvlCessgst
								+ ",ModifiedOn='"
								+ currentTimeStamp
								+ "' WHERE MasterID="
								+ masterID
								+ " and TileID="
								+ Constant.INTRST_LIAB_ITC_RVL_USR_TCODE;

						statement.addBatch(updateItcRvl);

						String updateLiabFwd = "UPDATE gstr3.tblgstr3LiabilityCorrection SET IGSTAmt="
								+ liabFwdIgst
								+ ",CGSTAmt="
								+ liabFwdCgst
								+ ",SGSTAmt="
								+ liabFwdSgst
								+ ",CessAmt="
								+ liabFwdCessgst
								+ ",ModifiedOn='"
								+ currentTimeStamp
								+ "' WHERE MasterID="
								+ masterID
								+ " and TileID="
								+ Constant.INTRST_LIAB_LIAB_FWD_TCODE;

						statement.addBatch(updateLiabFwd);

						String updatePymtTx = "UPDATE gstr3.tblgstr3LiabilityCorrection SET IGSTAmt="
								+ pymtTxIgst
								+ ",CGSTAmt="
								+ pymtTxCgst
								+ ",SGSTAmt="
								+ pymtTxSgst
								+ ",CessAmt="
								+ pymtTxCessgst
								+ ",ModifiedOn='"
								+ currentTimeStamp
								+ "' WHERE MasterID="
								+ masterID
								+ " and TileID="
								+ Constant.INTRST_LIAB_PYMT_TX_USR_TCODE;

						statement.addBatch(updatePymtTx);

						count = statement.executeBatch();

						if (LOGGER.isDebugEnabled()) {
							LOGGER.info(count.length + " updated : ");
						}

					}
				});

			} else {

				// If record is not there data will be inserted into
				// "gstr3.tblgstr3LiabilityCorrection" table

				session.doWork(new Work() {
					public void execute(Connection connection)
							throws SQLException {
						Statement statement = connection.createStatement();

						int[] count;

						String insertItcRvl = "INSERT INTO gstr3.tblgstr3LiabilityCorrection (MasterID ,TileID ,Rate ,eGSIN ,TaxableValue ,IGSTAmt ,CGSTAmt ,SGSTAmt ,CessAmt ,IsActive ,CreatedOn ,ModifiedOn)"
								+ "VALUES("
								+ masterID
								+ ","
								+ Constant.INTRST_LIAB_ITC_RVL_USR_TCODE
								+ ",NULL,NULL,NULL"
								+ ","
								+ itcRvlIgst
								+ ","
								+ itcRvlCgst
								+ ","
								+ itcRvlSgst
								+ ","
								+ itcRvlCessgst
								+ ",1,'"
								+ currentTimeStamp
								+ "','" + currentTimeStamp + "')";

						statement.addBatch(insertItcRvl);

						String insertLiabFwd = "INSERT INTO gstr3.tblgstr3LiabilityCorrection (MasterID ,TileID ,Rate ,eGSIN ,TaxableValue ,IGSTAmt ,CGSTAmt ,SGSTAmt ,CessAmt ,IsActive ,CreatedOn ,ModifiedOn)"
								+ "VALUES("
								+ masterID
								+ ","
								+ Constant.INTRST_LIAB_LIAB_FWD_TCODE
								+ ",NULL,NULL,NULL"
								+ ","
								+ liabFwdIgst
								+ ","
								+ liabFwdCgst
								+ ","
								+ liabFwdSgst
								+ ","
								+ liabFwdCessgst
								+ ",1,'"
								+ currentTimeStamp
								+ "','" + currentTimeStamp + "')";

						statement.addBatch(insertLiabFwd);

						String insertPymtTx = "INSERT INTO gstr3.tblgstr3LiabilityCorrection (MasterID ,TileID ,Rate ,eGSIN ,TaxableValue ,IGSTAmt ,CGSTAmt ,SGSTAmt ,CessAmt ,IsActive ,CreatedOn ,ModifiedOn)"
								+ "VALUES("
								+ masterID
								+ ","
								+ Constant.INTRST_LIAB_PYMT_TX_USR_TCODE
								+ ",NULL,NULL,NULL"
								+ ","
								+ pymtTxIgst
								+ ","
								+ pymtTxCgst
								+ ","
								+ pymtTxSgst
								+ ","
								+ pymtTxCessgst
								+ ",1,'"
								+ currentTimeStamp
								+ "','" + currentTimeStamp + "')";

						statement.addBatch(insertPymtTx);

						String corrStatusUpdate = "UPDATE gstr3.tblGetgstr3Master SET InterestLiabilitySaved=1 WHERE ID="
								+ masterID
								+ " and TaxPeriod="
								+ taxPeriod
								+ " and isActive=1";

						statement.addBatch(corrStatusUpdate);

						count = statement.executeBatch();

						if (LOGGER.isDebugEnabled()) {
							LOGGER.info(count.length + " inserted : ");
						}

					}
				});
			}
			tx.commit();
			status = true;

		} catch (Exception e) {
			tx.rollback();
			LOGGER.error(Constant.LOGGER_ERROR + " " + " For GSTIN " + gstin
					+ " and Taxperiod " + taxPeriod + Constant.LOGGER_METHOD, e);
		} finally {
			session.close();
		}
		if (LOGGER.isDebugEnabled())
			LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME
					+ " Method : saveInterestLiability : For GSTIN " + gstin
					+ " and Taxperiod " + taxPeriod);
		return status;
	}

	@Override
	public boolean updateInterestLiabilitySubmit(String refId, Gstr3Dto gstr3Dto) {

		boolean status = false;
		Session session = hibernateDao.getSession();

		String corrStatusUpdate = "UPDATE gstr3.tblGetgstr3Master SET IntrestLiabilitySubmitted=1,InterestLiabilityRefId = '"
				+ refId
				+ "' WHERE GSTIN='"
				+ gstr3Dto.getGstin()
				+ "' and TaxPeriod='"
				+ gstr3Dto.getRtPeriod()
				+ "' and IsActive = 1";
		try {

			Transaction tx = session.beginTransaction();

			SQLQuery sqlQuery = session.createSQLQuery(corrStatusUpdate);
			sqlQuery.executeUpdate();
			tx.commit();
			status = true;

		} catch (Exception e) {
			LOGGER.error(
					Constant.LOGGER_ERROR + " " + " For GSTIN "
							+ gstr3Dto.getGstin() + " and Taxperiod "
							+ gstr3Dto.getRtPeriod() + Constant.LOGGER_METHOD,
					e);
		} finally {
			if (session != null)
				session.close();
		}
		if (LOGGER.isDebugEnabled())
			LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME
					+ " Method : saveInterestLiability : For GSTIN "
					+ gstr3Dto.getGstin() + " and Taxperiod "
					+ gstr3Dto.getRtPeriod());

		return status;
	}

	@Override
	public String saveCashItcBalance(String cashITCJson, String gstin,
			String taxPeriod) {
		Session session = null;
		try {
			List<CashITCLedgerMaster> itcLedgerMasters = new ArrayList<>();
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject) jsonParser.parse(cashITCJson);

			CashITCLedgerMaster cashITCLedgerMaster = new CashITCLedgerMaster();

			if (!(CommonUtillity.isEmpty(gstin) && CommonUtillity
					.isEmpty(taxPeriod))) {
				DetachedCriteria detachedCriteria = hibernateDao
						.createCriteria(CashITCLedgerMaster.class);
				detachedCriteria.add(Restrictions.eq("GSTIN", gstin));
				detachedCriteria.add(Restrictions.eq("taxPeriod", taxPeriod));
				detachedCriteria.add(Restrictions.eq("isActive", true));
				itcLedgerMasters = (List<CashITCLedgerMaster>) hibernateDao
						.find(detachedCriteria);
			}

			if (itcLedgerMasters.size() > 0) {
				cashITCLedgerMaster = itcLedgerMasters.get(0);

				session = hibernateDao.getSession();
				String queryStr = "update CashLedgerDetails e set e.isActive = :isActive where e.masterId.cashItcMasterId = :masterId";
				Query query = session.createQuery(queryStr);
				query.setParameter("isActive", false);
				query.setParameter("masterId",
						cashITCLedgerMaster.getCashItcMasterId());
				query.executeUpdate();

				// session = hibernateDao.getSession();
				String queryStr2 = "update ITCLedgerDetails e set e.isActive = :isActive where e.masterId.cashItcMasterId = :masterId";
				Query query2 = session.createQuery(queryStr2);
				query2.setParameter("isActive", false);
				query2.setParameter("masterId",
						cashITCLedgerMaster.getCashItcMasterId());
				query2.executeUpdate();

			} else {
				if (!(CommonUtillity.isEmpty(gstin))) {
					cashITCLedgerMaster.setGSTIN(gstin);
				}
				if (!(CommonUtillity.isEmpty(taxPeriod)))
					cashITCLedgerMaster.setTaxPeriod(taxPeriod);
				cashITCLedgerMaster.setActive(true);
				cashITCLedgerMaster.setCreatedOn(new Date());
				cashITCLedgerMaster.setModifiedOn(new Date());
				Long masterSavedID = (Long) hibernateDao
						.save(cashITCLedgerMaster);
				cashITCLedgerMaster.setCashItcMasterId(masterSavedID);
			}
			JSONObject itcVal = (JSONObject) jsonObject.get("itc_bal");

			ITCLedgerDetails itcLedgerDetails = new ITCLedgerDetails();
			itcLedgerDetails.setMasterId(cashITCLedgerMaster);

			if (itcVal.get("igst_bal") instanceof Double) {
				itcLedgerDetails.setIgstAmt(BigDecimal.valueOf((double) itcVal
						.get("igst_bal")));
			} else {
				itcLedgerDetails.setIgstAmt(BigDecimal.valueOf((long) itcVal
						.get("igst_bal")));
			}
			if (itcVal.get("cgst_bal") instanceof Double) {
				itcLedgerDetails.setCgstAmt(BigDecimal.valueOf((double) itcVal
						.get("cgst_bal")));
			} else {
				itcLedgerDetails.setCgstAmt(BigDecimal.valueOf((long) itcVal
						.get("cgst_bal")));
			}
			if (itcVal.get("sgst_bal") instanceof Double) {
				itcLedgerDetails.setSgstAmt(BigDecimal.valueOf((double) itcVal
						.get("sgst_bal")));
			} else {
				itcLedgerDetails.setSgstAmt(BigDecimal.valueOf((long) itcVal
						.get("sgst_bal")));
			}

			if (itcVal.get("cess_bal") instanceof Double) {
				itcLedgerDetails.setCessAmt(BigDecimal.valueOf((double) itcVal
						.get("cess_bal")));
			} else {
				itcLedgerDetails.setCessAmt(BigDecimal.valueOf((long) itcVal
						.get("cess_bal")));
			}

			itcLedgerDetails.setActive(true);
			hibernateDao.saveOrUpdate(itcLedgerDetails);

			List<CashLedgerDetails> cashLedgerList = new ArrayList<>();

			CashLedgerDetails cashLedgerDetails = new CashLedgerDetails();
			Gstr3AccountHead gstr3AccountHead = new Gstr3AccountHead();
			JSONObject cashVal = (JSONObject) jsonObject.get("cash_bal");

			JSONObject cashIgst = (JSONObject) cashVal.get("igst");
			gstr3AccountHead.setTaxHeadId(new BigInteger("1"));
			cashLedgerDetails.setAccHeadId(gstr3AccountHead);
			cashLedgerDetails.setMasterId(cashITCLedgerMaster);
			cashLedgerDetails = populateCashDetails(cashLedgerDetails, cashIgst);
			cashLedgerList.add(cashLedgerDetails);

			cashLedgerDetails = new CashLedgerDetails();
			JSONObject cashCgst = (JSONObject) cashVal.get("cgst");
			gstr3AccountHead = new Gstr3AccountHead();
			gstr3AccountHead.setTaxHeadId(new BigInteger("2"));
			cashLedgerDetails.setAccHeadId(gstr3AccountHead);
			cashLedgerDetails.setMasterId(cashITCLedgerMaster);
			cashLedgerDetails = populateCashDetails(cashLedgerDetails, cashCgst);
			cashLedgerList.add(cashLedgerDetails);

			cashLedgerDetails = new CashLedgerDetails();
			JSONObject cashSgst = (JSONObject) cashVal.get("sgst");
			gstr3AccountHead = new Gstr3AccountHead();
			gstr3AccountHead.setTaxHeadId(new BigInteger("3"));
			cashLedgerDetails.setAccHeadId(gstr3AccountHead);
			cashLedgerDetails.setMasterId(cashITCLedgerMaster);
			cashLedgerDetails = populateCashDetails(cashLedgerDetails, cashSgst);
			cashLedgerList.add(cashLedgerDetails);

			cashLedgerDetails = new CashLedgerDetails();
			JSONObject cashCess = (JSONObject) cashVal.get("cess");
			gstr3AccountHead = new Gstr3AccountHead();
			gstr3AccountHead.setTaxHeadId(new BigInteger("5"));
			cashLedgerDetails.setAccHeadId(gstr3AccountHead);
			cashLedgerDetails.setMasterId(cashITCLedgerMaster);
			cashLedgerDetails = populateCashDetails(cashLedgerDetails, cashCess);
			cashLedgerList.add(cashLedgerDetails);

			hibernateDao.saveOrUpdateAll(cashLedgerList);

		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : saveCashItcBalance " + e);
		}
		return "success";
	}

	private CashLedgerDetails populateCashDetails(
			CashLedgerDetails cashLedgerDetails, JSONObject cashSubUnit) {
		cashLedgerDetails.setTax(BigDecimal.valueOf((double) cashSubUnit
				.get("tx")));
		cashLedgerDetails.setPenalty(BigDecimal.valueOf((double) cashSubUnit
				.get("pen")));
		cashLedgerDetails.setInterest(BigDecimal.valueOf((double) cashSubUnit
				.get("intr")));
		cashLedgerDetails.setFee(BigDecimal.valueOf((double) cashSubUnit
				.get("fee")));
		cashLedgerDetails.setOthers(BigDecimal.valueOf((double) cashSubUnit
				.get("oth")));
		cashLedgerDetails.setActive(true);
		return cashLedgerDetails;

	}

	@Override
	public String saveEditedCashItcDetails(String cashITCJson) {
		Session session = null;
		try {
			List<CashITCUtilization> cashItcUtilList = null;
			Gstr3AccountHead gstr3AccountHead = null;
			CashITCUtilization cashITCUtilization = null;
			List<CashITCLedgerMaster> itcLedgerMasters = new ArrayList<>();
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject) jsonParser.parse(cashITCJson);
			String gstinId = (String) jsonObject.get("gstinId");
			String taxPeriod = (String) jsonObject.get("taxPeriod");
			CashITCLedgerMaster ledgerMaster = null;
			if (!(CommonUtillity.isEmpty(gstinId) && CommonUtillity
					.isEmpty(taxPeriod))) {
				DetachedCriteria detachedCriteria = hibernateDao
						.createCriteria(CashITCLedgerMaster.class);
				detachedCriteria.add(Restrictions.eq("GSTIN", gstinId));
				detachedCriteria.add(Restrictions.eq("taxPeriod", taxPeriod));
				detachedCriteria.add(Restrictions.eq("isActive", true));
				itcLedgerMasters = (List<CashITCLedgerMaster>) hibernateDao
						.find(detachedCriteria);
				ledgerMaster = itcLedgerMasters.get(0);
				session = hibernateDao.getSession();
				String queryStr = "update CashITCUtilization e set e.isActive = :isActive where e.masterId.cashItcMasterId = :masterId";
				Query query = session.createQuery(queryStr);
				query.setParameter("isActive", false);
				query.setParameter("masterId",
						ledgerMaster.getCashItcMasterId());
				query.executeUpdate();
			}

			if (itcLedgerMasters.size() > 0) {
				cashItcUtilList = new ArrayList<>();
				ledgerMaster = itcLedgerMasters.get(0);
				// populate igst detail
				cashITCUtilization = new CashITCUtilization();
				gstr3AccountHead = new Gstr3AccountHead();
				gstr3AccountHead.setTaxHeadId(new BigInteger("1"));
				cashITCUtilization.setAccHeadId(gstr3AccountHead);
				cashITCUtilization.setMasterId(ledgerMaster);
				cashITCUtilization = populateCashUtilDao(
						(double) jsonObject.get("igstITCInt"),
						(double) jsonObject.get("igstITCCent"),
						(double) jsonObject.get("igstITCState"),
						(double) jsonObject.get("igstITCCess"),
						(double) jsonObject.get("igstCashPaid"),
						(double) jsonObject.get("igstIntPaid"),
						(double) jsonObject.get("igstLateFeePaid"),
						cashITCUtilization);
				cashItcUtilList.add(cashITCUtilization);

				// populate cgst detail
				cashITCUtilization = new CashITCUtilization();
				gstr3AccountHead = new Gstr3AccountHead();
				gstr3AccountHead.setTaxHeadId(new BigInteger("2"));
				cashITCUtilization.setAccHeadId(gstr3AccountHead);
				cashITCUtilization.setMasterId(ledgerMaster);
				cashITCUtilization = populateCashUtilDao(
						(double) jsonObject.get("cgstITCInt"),
						(double) jsonObject.get("cgstITCCent"),
						(double) jsonObject.get("cgstITCState"),
						(double) jsonObject.get("cgstITCCess"),
						(double) jsonObject.get("cgstCashPaid"),
						(double) jsonObject.get("cgstIntPaid"),
						(double) jsonObject.get("cgstLateFeePaid"),
						cashITCUtilization);
				cashItcUtilList.add(cashITCUtilization);

				// populate sgst detail
				cashITCUtilization = new CashITCUtilization();
				gstr3AccountHead = new Gstr3AccountHead();
				gstr3AccountHead.setTaxHeadId(new BigInteger("3"));
				cashITCUtilization.setAccHeadId(gstr3AccountHead);
				cashITCUtilization.setMasterId(ledgerMaster);
				cashITCUtilization = populateCashUtilDao(
						(double) jsonObject.get("sgstITCInt"),
						(double) jsonObject.get("sgstITCCent"),
						(double) jsonObject.get("sgstITCState"),
						(double) jsonObject.get("sgstITCCess"),
						(double) jsonObject.get("sgstCashPaid"),
						(double) jsonObject.get("sgstIntPaid"),
						(double) jsonObject.get("sgstLateFeePaid"),
						cashITCUtilization);
				cashItcUtilList.add(cashITCUtilization);

				// populate cess detail
				cashITCUtilization = new CashITCUtilization();
				gstr3AccountHead = new Gstr3AccountHead();
				gstr3AccountHead.setTaxHeadId(new BigInteger("5"));
				cashITCUtilization.setAccHeadId(gstr3AccountHead);
				cashITCUtilization.setMasterId(ledgerMaster);
				cashITCUtilization = populateCashUtilDao(
						(double) jsonObject.get("cessITCInt"),
						(double) jsonObject.get("cessITCCent"),
						(double) jsonObject.get("cessITCState"),
						(double) jsonObject.get("cessITCCess"),
						(double) jsonObject.get("cessCashPaid"),
						(double) jsonObject.get("cessIntPaid"),
						(double) jsonObject.get("cessLateFeePaid"),
						cashITCUtilization);
				cashItcUtilList.add(cashITCUtilization);

				hibernateDao.saveOrUpdateAll(cashItcUtilList);

				// update tblCashITCLedgerMaster with flag

				session = hibernateDao.getSession();
				String queryStr = "update CashITCLedgerMaster e set e.isSaved = :isSaved where e.GSTIN = :gstinId and e.taxPeriod = :taxPeriod ";
				Query query = session.createQuery(queryStr);
				query.setParameter("isSaved", true);
				query.setParameter("gstinId", gstinId);
				query.setParameter("taxPeriod", taxPeriod);
				query.executeUpdate();

			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : saveEditedCashItcDetails " + e);
			return "failure";
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return "success";
	}

	private CashITCUtilization populateCashUtilDao(double itcInt,
			double itcCent, double itcState, double itcCess,
			double cashTaxPaid, double cashIntPaid, double cashLateFeePaid,
			CashITCUtilization cashITCUtilization) {
		cashITCUtilization.setITCIgstAmt(BigDecimal.valueOf(itcInt));
		cashITCUtilization.setITCCgstAmt(BigDecimal.valueOf(itcCent));
		cashITCUtilization.setITCSgstAmt(BigDecimal.valueOf(itcState));
		cashITCUtilization.setITCCessAmt(BigDecimal.valueOf(itcCess));
		cashITCUtilization.setCashTaxPaid(BigDecimal.valueOf(cashTaxPaid));
		cashITCUtilization.setCashIntrestPaid(BigDecimal.valueOf(cashIntPaid));
		cashITCUtilization.setCashLateFeePaid(BigDecimal
				.valueOf(cashLateFeePaid));
		cashITCUtilization.setActive(true);
		return cashITCUtilization;
	}

	@Override
	public List<CashITCUtilization> getEditedCashItcDetails(String gstinId,
			String taxPeriod) {
		List<CashITCUtilization> cashITCUtilizations = null;
		CashITCLedgerMaster cashITCLedgerMaster = null;
		List<CashITCLedgerMaster> itcLedgerMasters = null;
		String savedDetails = "";
		try {
			if (!(CommonUtillity.isEmpty(gstinId) && CommonUtillity
					.isEmpty(taxPeriod))) {
				DetachedCriteria detachedCriteria = hibernateDao
						.createCriteria(CashITCLedgerMaster.class);
				detachedCriteria.add(Restrictions.eq("GSTIN", gstinId));
				detachedCriteria.add(Restrictions.eq("taxPeriod", taxPeriod));
				detachedCriteria.add(Restrictions.eq("isSaved", true));
				itcLedgerMasters = (List<CashITCLedgerMaster>) hibernateDao
						.find(detachedCriteria);
			}
			if (itcLedgerMasters.size() > 0) {
				cashITCLedgerMaster = itcLedgerMasters.get(0);
				DetachedCriteria detachedCriteria = hibernateDao
						.createCriteria(CashITCUtilization.class);
				detachedCriteria.createAlias("masterId", "masterObject").add(
						Restrictions.eq("masterObject.cashItcMasterId",
								cashITCLedgerMaster.getCashItcMasterId()));
				detachedCriteria.add(Restrictions.eq("isActive", true));
				detachedCriteria.setFetchMode("masterId", FetchMode.EAGER);
				detachedCriteria.setFetchMode("accHeadId", FetchMode.EAGER);
				cashITCUtilizations = (List<CashITCUtilization>) hibernateDao
						.find(detachedCriteria);

			}
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : getEditedCashItcDetails " + e);
		}
		return cashITCUtilizations;

	}

	@Override
	public Map<String, String> isSubmitGSTR3FormSection(Gstr3Dto gstr3Dto) throws DataException {

	    String status = Constant.FAILED;
        Map<String,String> formMap =new HashMap<String, String>();
       Session session = null;

       String sqlStatement = "select [IntrestLiabilitySubmitted],[UtilizationSubmitted],[InterestLiabilitySaved],[IsSubmitted] from [gstr3].[tblGetgstr3Master]  where GSTIN='"+gstr3Dto.getGstin()+"' and taxperiod='"+gstr3Dto.getRtPeriod()+"' and isActive = 1";

       SQLQuery sqlQuery;

       try {
       	session = hibernateDao.getSession();
             Transaction tx = session.beginTransaction();
             
             //update fetch date in master
             sqlQuery = session.createSQLQuery(sqlStatement);
             List<Object[]> rows = sqlQuery.list();
             
            
             if(rows.size() > 0){
                
               formMap.put("IntrestLiabilitySubmitted", rows.get(0)[0].toString());
               formMap.put("UtilizationSubmitted", rows.get(0)[1].toString());
               formMap.put("InterestLiabilitySaved", rows.get(0)[2].toString());
               formMap.put("IsSubmitted", rows.get(0)[3].toString());
               
             }
             
           
          tx.commit();

       } catch (SQLGrammarException e) {
             LOGGER.error("Error in formStatuscall"+
                         e.getMessage());
             throw new DataException(e.getMessage(),e);
       }
       finally{
   		if(session != null && session.isOpen())
   		session.close();
   		}
       return formMap;

	}

	@Override
	public String updateActiveStatus(Gstr3Dto gstr3dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + " Method : updateActiveStatus "
				+ gstr3dto.toString());

		String status = Constant.FAILED;
		Session session = null;
		Transaction tx = null;
		try {
			session = hibernateDao.getSession();
			tx = session.beginTransaction();

			String sqlSelect = "Select count([ID]) from [gstr3].[tblgetgstr3Details] where [MasterID] = (select [ID] from [gstr3].[tblGetgstr3Master] where  GSTIN ='"
					+ gstr3dto.getGstin()
					+ "' and taxperiod ='"
					+ gstr3dto.getRtPeriod()
					+ "' and isActive = 1) and isActive = 1";
			String sqldetUpdate = "UPDATE [gstr3].[tblgetgstr3Details] set IsActive = 0 where [MasterID] = (select [ID] from [gstr3].[tblGetgstr3Master] where  GSTIN ='"
					+ gstr3dto.getGstin()
					+ "' and taxperiod ='"
					+ gstr3dto.getRtPeriod()
					+ "' and isActive = 1) and isActive = 1";

			String masterQuery = "update [gstr3].[tblGetgstr3Master] set fetchDate = CURRENT_TIMESTAMP where GSTIN ='"
					+ gstr3dto.getGstin()
					+ "' and taxperiod = '"
					+ gstr3dto.getRtPeriod() + "' and isActive = 1";

			String sqlTodUpdate = "UPDATE [gstr3].[tblgstr3TurnOverDetails] set IsActive = 0 where [MasterID] = (select [ID] from [gstr3].[tblGetgstr3Master] where  GSTIN ='"
					+ gstr3dto.getGstin()
					+ "' and taxperiod ='"
					+ gstr3dto.getRtPeriod()
					+ "' and isActive = 1) and isActive = 1";

			String sqlrcUpdate = "UPDATE [gstr3].[tblgstr3RefundClaim] set IsActive = 0 where [MasterID] = (select [ID] from [gstr3].[tblGetgstr3Master] where  GSTIN ='"
					+ gstr3dto.getGstin()
					+ "' and taxperiod ='"
					+ gstr3dto.getRtPeriod()
					+ "' and isActive = 1) and isActive = 1";

			
			session.doWork(new Work() {
				public void execute(Connection connection) throws SQLException {
					Statement preparedStatement = connection.createStatement();
					// int i = 0;
					int[] count;
					try {

						preparedStatement.addBatch(masterQuery);
						preparedStatement.addBatch(sqldetUpdate);
						preparedStatement.addBatch(sqlTodUpdate);
						preparedStatement.addBatch(sqlrcUpdate);

						count = preparedStatement.executeBatch();

						if (LOGGER.isInfoEnabled())
							LOGGER.info("Number of updates = " + count.length);

					} finally {
						if (preparedStatement != null) {
							preparedStatement.close();
						}
					}

				}

			});

			// commit
			if (tx != null)
				tx.commit();
		} catch (SQLGrammarException e) {
			if (tx != null)
			tx.rollback();
			new DataException(e.getMessage(), e);
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return status;

	}

	@Override
	public boolean updateSetoffLiabilitySubmit(String refId, Gstr3Dto gstr3dto) {
		boolean status = false;
		Session session = hibernateDao.getSession();

		String corrStatusUpdate = "UPDATE gstr3.tblGetgstr3Master SET UtilizationSubmitted=1,TaxOffsetRefID = '"
				+ refId
				+ "' WHERE GSTIN='"
				+ gstr3dto.getGstin()
				+ "' and TaxPeriod='"
				+ gstr3dto.getRtPeriod()
				+ "' and IsActive = 1";
		try {

			Transaction tx = session.beginTransaction();

			SQLQuery sqlQuery = session.createSQLQuery(corrStatusUpdate);
			sqlQuery.executeUpdate();
			tx.commit();
			status = true;

		} catch (Exception e) {
			LOGGER.error(
					Constant.LOGGER_ERROR + " " + " For GSTIN "
							+ gstr3dto.getGstin() + " and Taxperiod "
							+ gstr3dto.getRtPeriod() + Constant.LOGGER_METHOD,
					e);
		} finally {
			if (session != null)
				session.close();
		}
		if (LOGGER.isDebugEnabled())
			LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME
					+ " Method : saveInterestLiability : For GSTIN "
					+ gstr3dto.getGstin() + " and Taxperiod "
					+ gstr3dto.getRtPeriod());

		return status;

	}

	@Override
	public boolean updateGstr3Submit(String gstin, String taxperiod) {
		boolean status = false;
		Session session = hibernateDao.getSession();

		String corrStatusUpdate = "UPDATE gstr3.tblGetgstr3Master SET IsSubmitted = 1 WHERE GSTIN='"
				+ gstin
				+ "' and TaxPeriod='"
				+ taxperiod
				+ "' and IsActive = 1";
		try {

			Transaction tx = session.beginTransaction();

			SQLQuery sqlQuery = session.createSQLQuery(corrStatusUpdate);
			sqlQuery.executeUpdate();
			tx.commit();
			status = true;

		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + " " + " For GSTIN " + gstin
					+ " and Taxperiod " + taxperiod + Constant.LOGGER_METHOD, e);
		} finally {
			if (session != null)
				session.close();
		}
		if (LOGGER.isDebugEnabled())
			LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME
					+ " Method : saveInterestLiability : For GSTIN " + gstin
					+ " and Taxperiod " + taxperiod);

		return status;
	}

	/*
	 * create new data in tblGetgstr3Master table after generate call
	 */

	@Override
	public boolean insertGstr3GenerateData(String refId, Gstr3Dto gstr3dto) {
		boolean status = false;
		Session session = hibernateDao.getSession();

		String corrStatusUpdate = "INSERT INTO gstr3.tblGetgstr3Master (GSTIN ,TaxPeriod ,RefID ,IsActive ,GenerateDate ,FetchDate ,DebitEntryNum ,IntrestLiabilitySubmitted ,UtilizationSubmitted ,ModifiedOn ,CreatedBy ,UpdatedBy ,InterestLiabilityRefID ,TaxOffsetRefID ,SubmitRefID ,RefundCliamRefID,InterestLiabilitySaved,IsSubmitted) "
				+ "VALUES ('"
				+ gstr3dto.getGstin()
				+ "','"
				+ gstr3dto.getRtPeriod()
				+ "','"
				+ refId
				+ "',1,CURRENT_TIMESTAMP,NULL,NULL,0,0,CURRENT_TIMESTAMP,NULL,NULL,NULL,NULL,NULL,NULL,0,0)";

		try {

			Transaction tx = session.beginTransaction();

			SQLQuery sqlQuery = session.createSQLQuery(corrStatusUpdate);
			sqlQuery.executeUpdate();
			tx.commit();
			status = true;

		} catch (Exception e) {
			LOGGER.error(
					Constant.LOGGER_ERROR + " " + " For GSTIN "
							+ gstr3dto.getGstin() + " and Taxperiod "
							+ gstr3dto.getRtPeriod() + Constant.LOGGER_METHOD,
					e);
		} finally {
			if (session != null)
				session.close();
		}
		if (LOGGER.isDebugEnabled())
			LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME
					+ " Method : saveInterestLiability : For GSTIN "
					+ gstr3dto.getGstin() + " and Taxperiod "
					+ gstr3dto.getRtPeriod());

		return status;
	}

	@Override
	public Map<String, Boolean> isGtsr1AndGstr2Filed(Gstr3Dto gstr3Dto) {

		Map<String, Boolean> statusMap = new HashMap<String, Boolean>();
		boolean isFiled = false;
		boolean isGstr3 = false;
		boolean isGstr1Filed = isFiled(gstr3Dto, Constant.GSTR1_RETURN_TYPE);
		if (isGstr1Filed && isFiled(gstr3Dto, Constant.GSTR2_RETURN_TYPE)) {
			isFiled = true;
		}
		isGstr3 = isGSTR3Generated(gstr3Dto);
		statusMap.put("Gtsr1AndGstr2Filed", isFiled);
		statusMap.put("Gstr3Generated", isGstr3);
		return statusMap;
	}

	@Override
	public boolean isGSTR3Generated(Gstr3Dto gstr3Dto) {

		boolean status = false;

		Session session = hibernateDao.getSession();

		String sqlStatement = "select RefID from [gstr3].[tblGetgstr3Master]  where GSTIN='"
				+ gstr3Dto.getGstin()
				+ "' and taxperiod='"
				+ gstr3Dto.getRtPeriod() + "' and isActive = 1";

		SQLQuery sqlQuery;

		try {
			Transaction tx = session.beginTransaction();

			sqlQuery = session.createSQLQuery(sqlStatement);
			Object refId = sqlQuery.uniqueResult();

			if (refId != null) {
				status = true;
			}

			tx.commit();

		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + " " + Constant.LOGGER_METHOD,
					e);
		} finally {
			if (session != null)
				session.close();
		}
		if (LOGGER.isDebugEnabled())
			LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME
					+ " Method : isGSTR3Generated");
		return status;

	}

	public boolean isFiledGstr1(String gstnid, String taxPeriod)
			throws Exception {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(Constant.LOGGER_ENTERING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " isFiledGstr1");
		}

		String retFileType = "GSTR1";
		Session session = hibernateDao.getSession();
		boolean isFiled = false;
		try {
			Transaction tx = session.beginTransaction();
			String fileStatus = "";
			String selectSql = "Select Status from master.tblGstinReturnFilingStatus where GstinId='"
					+ gstnid
					+ "' and TaxPeriod = '"
					+ taxPeriod
					+ "' and ReturnType = '" + retFileType + "'";
			fileStatus = session.createSQLQuery(selectSql).uniqueResult()
					.toString();
			LOGGER.info("GSTR1 Filing status for GSTIN::" + gstnid
					+ " Tax Period::" + taxPeriod + " is " + fileStatus);

			if (fileStatus != null && fileStatus.equals("FILED")) {
				isFiled = true;
			}
			tx.commit();
			session.close();

		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD + " isFiledGstr1");

			throw new Exception(e);
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " isFiledGstr1");
		}
		return isFiled;
	}

	public boolean isFiledGstr2(String gstnid, String taxPeriod) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(Constant.LOGGER_ENTERING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " isFiledGstr2");
		}

		String retFileType = "GSTR2";
		Session session = hibernateDao.getSession();
		boolean isFiled = false;
		try {
			Transaction tx = session.beginTransaction();
			String fileStatus = "";
			String selectSql = "Select Status from master.tblGstinReturnFilingStatus where GstinId='"
					+ gstnid
					+ "' and TaxPeriod = '"
					+ taxPeriod
					+ "' and ReturnType = '" + retFileType + "'";
			fileStatus = session.createSQLQuery(selectSql).uniqueResult()
					.toString();
			LOGGER.info("GSTR2 Filing status for GSTIN::" + gstnid
					+ " Tax Period::" + taxPeriod + " is " + fileStatus);

			if (fileStatus != null && fileStatus.equals("FILED")) {
				isFiled = true;
			}
			tx.commit();
			session.close();

		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD + " isFiledGstr2");
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " isFiledGstr2");
		}
		return isFiled;
	}

}