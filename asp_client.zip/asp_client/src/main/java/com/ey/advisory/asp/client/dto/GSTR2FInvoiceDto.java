package com.ey.advisory.asp.client.dto;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class GSTR2FInvoiceDto {
	
		@SerializedName("Type")
		private String tableType;
		
		@SerializedName("SuggestedResponse")
		private String suggestedResp;		
		
		@SerializedName("SGSTIN")
		private String SGSTIN;

		@SerializedName("DocumentType")
		private String documentType;

		@SerializedName("DocumentNo")
		private String documentNo;

		@SerializedName("DocumentDate")
		private String documentDate;

		@SerializedName("CGSTIN")
		private String CGSTIN;

		@SerializedName("SourceIdentifier")
		private String sourceIdentifier;

		@SerializedName("SourceFileName")
		private String sourceFileName;

		@SerializedName("GLAccountCode")
		private String gLAccountCode;

		@SerializedName("Division")
		private String division;

		@SerializedName("SubDivision")
		private String subDivision;

		@SerializedName("ProfitCentre1")
		private String profitCentre1;

		@SerializedName("ProfitCentre2")
		private String profitCentre2;

		@SerializedName("PlantCode")
		private String plantCode;

		@SerializedName("PurchaseVoucherNumber")
		private String purchaseVoucherNumber;

		@SerializedName("PurchaseVoucherDate")
		private String purchaseVoucherDate;

		@SerializedName("SupplierName")
		private String supplierName;

		@SerializedName("SupplierCode")
		private String supplierCode;

		@SerializedName("OriginalDocumentNumber2A")
		private String originalDocumentNumber2A;

		@SerializedName("OriginalDocumentNumberPR")
		private String originalDocumentNumberPR;

		@SerializedName("Original_Document_Date2A")
		private String originalDocumentDate2A;

		@SerializedName("Original_Document_DatePR")
		private String originalDocumentDatePR;

		@SerializedName("Place_Of_Supply2A")
		private String pos2A;

		@SerializedName("Place_Of_SupplyPR")
		private String posPR;
		
		@SerializedName("ReverseChargeFlag2A")
		private String reverseChargeFlag2A;
		
		@SerializedName("ReverseChargeFlagPR")
		private String ReverseChargeFlagPR;


		@SerializedName("TotalTaxableValue2A")
		private Double totalTaxableValue2A;
		
		@SerializedName("TotalTaxableValuePR")
		private Double totalTaxableValuePR;
		
		@SerializedName("TotalIntegratedTaxAmount2A")
		private Double totalIntegratedTaxAmount2A;
		
		@SerializedName("TotalIntegratedTaxAmountPR")
		private Double totalIntegratedTaxAmountPR;
		
		@SerializedName("TotalCentralTaxAmount2A")
		private Double totalCentralTaxAmount2A;
		
		@SerializedName("TotalCentralTaxAmountPR")
		private Double totalCentralTaxAmountPR;
		
		@SerializedName("TotalStateTaxAmount2A")
		private Double totalStateTaxAmount2A;
		
		@SerializedName("TotalStateTaxAmountPR")
		private Double totalStateTaxAmountPR;
		
		@SerializedName("TotalCessAmount2A")
		private Double totalCessTaxAmount2A;
		
		@SerializedName("TotalCessAmountPR")
		private Double totalCessTaxAmountPR;
		
		private Double lineNo2A;		
		private Double lineNoPR;
		private Double rate2A;
		private Double ratePR;
		
		private String clientRes;
		
		@SerializedName("InvoiceKey")
		private String invKey;		

		@SerializedName("LineItemList")
		List<GSTR2FItemDto> itemDetails;

		public String getInvKey() {
			return invKey;
		}

		public void setInvKey(String invKey) {
			this.invKey = invKey;
		}
		
		public String getTableType() {
			return tableType;
		}

		public void setTableType(String tableType) {
			this.tableType = tableType;
		}

		public String getSuggestedResp() {
			return suggestedResp;
		}

		public void setSuggestedResp(String suggestedResp) {
			this.suggestedResp = suggestedResp;
		}

		public String getSGSTIN() {
			return SGSTIN;
		}

		public void setSGSTIN(String sGSTIN) {
			SGSTIN = sGSTIN;
		}

		public String getDocumentType() {
			return documentType;
		}

		public void setDocumentType(String documentType) {
			this.documentType = documentType;
		}

		public String getDocumentNo() {
			return documentNo;
		}

		public void setDocumentNo(String documentNo) {
			this.documentNo = documentNo;
		}

		public String getDocumentDate() {
			return documentDate;
		}

		public void setDocumentDate(String documentDate) {
			this.documentDate = documentDate;
		}

		public String getCGSTIN() {
			return CGSTIN;
		}

		public void setCGSTIN(String cGSTIN) {
			CGSTIN = cGSTIN;
		}

		public String getSourceIdentifier() {
			return sourceIdentifier;
		}

		public void setSourceIdentifier(String sourceIdentifier) {
			this.sourceIdentifier = sourceIdentifier;
		}

		public String getSourceFileName() {
			return sourceFileName;
		}

		public void setSourceFileName(String sourceFileName) {
			this.sourceFileName = sourceFileName;
		}

		public String getgLAccountCode() {
			return gLAccountCode;
		}

		public void setgLAccountCode(String gLAccountCode) {
			this.gLAccountCode = gLAccountCode;
		}

		public String getDivision() {
			return division;
		}

		public void setDivision(String division) {
			this.division = division;
		}

		public String getSubDivision() {
			return subDivision;
		}

		public void setSubDivision(String subDivision) {
			this.subDivision = subDivision;
		}

		public String getProfitCentre1() {
			return profitCentre1;
		}

		public void setProfitCentre1(String profitCentre1) {
			this.profitCentre1 = profitCentre1;
		}

		public String getProfitCentre2() {
			return profitCentre2;
		}

		public void setProfitCentre2(String profitCentre2) {
			this.profitCentre2 = profitCentre2;
		}

		public String getPlantCode() {
			return plantCode;
		}

		public void setPlantCode(String plantCode) {
			this.plantCode = plantCode;
		}

		public String getPurchaseVoucherNumber() {
			return purchaseVoucherNumber;
		}

		public void setPurchaseVoucherNumber(String purchaseVoucherNumber) {
			this.purchaseVoucherNumber = purchaseVoucherNumber;
		}

		public String getPurchaseVoucherDate() {
			return purchaseVoucherDate;
		}

		public void setPurchaseVoucherDate(String purchaseVoucherDate) {
			this.purchaseVoucherDate = purchaseVoucherDate;
		}

		public String getSupplierName() {
			return supplierName;
		}

		public void setSupplierName(String supplierName) {
			this.supplierName = supplierName;
		}

		public String getSupplierCode() {
			return supplierCode;
		}

		public void setSupplierCode(String supplierCode) {
			this.supplierCode = supplierCode;
		}

		public String getOriginalDocumentNumber2A() {
			return originalDocumentNumber2A;
		}

		public void setOriginalDocumentNumber2A(String originalDocumentNumber2A) {
			this.originalDocumentNumber2A = originalDocumentNumber2A;
		}

		public String getOriginalDocumentNumberPR() {
			return originalDocumentNumberPR;
		}

		public void setOriginalDocumentNumberPR(String originalDocumentNumberPR) {
			this.originalDocumentNumberPR = originalDocumentNumberPR;
		}

		public String getOriginalDocumentDate2A() {
			return originalDocumentDate2A;
		}

		public void setOriginalDocumentDate2A(String originalDocumentDate2A) {
			this.originalDocumentDate2A = originalDocumentDate2A;
		}

		public String getOriginalDocumentDatePR() {
			return originalDocumentDatePR;
		}

		public void setOriginalDocumentDatePR(String originalDocumentDatePR) {
			this.originalDocumentDatePR = originalDocumentDatePR;
		}

		public String getPos2A() {
			return pos2A;
		}

		public void setPos2A(String pos2a) {
			pos2A = pos2a;
		}

		public String getPosPR() {
			return posPR;
		}

		public void setPosPR(String posPR) {
			this.posPR = posPR;
		}

		public String getReverseChargeFlag2A() {
			return reverseChargeFlag2A;
		}

		public void setReverseChargeFlag2A(String reverseChargeFlag2A) {
			this.reverseChargeFlag2A = reverseChargeFlag2A;
		}

		public String getReverseChargeFlagPR() {
			return ReverseChargeFlagPR;
		}

		public void setReverseChargeFlagPR(String reverseChargeFlagPR) {
			ReverseChargeFlagPR = reverseChargeFlagPR;
		}
		
		public Double getTotalTaxableValue2A() {
			return totalTaxableValue2A;
		}

		public void setTotalTaxableValue2A(Double totalTaxableValue2A) {
			this.totalTaxableValue2A = totalTaxableValue2A;
		}

		public Double getTotalTaxableValuePR() {
			return totalTaxableValuePR;
		}

		public void setTotalTaxableValuePR(Double totalTaxableValuePR) {
			this.totalTaxableValuePR = totalTaxableValuePR;
		}

		public Double getTotalIntegratedTaxAmount2A() {
			return totalIntegratedTaxAmount2A;
		}

		public void setTotalIntegratedTaxAmount2A(Double totalIntegratedTaxAmount2A) {
			this.totalIntegratedTaxAmount2A = totalIntegratedTaxAmount2A;
		}

		public Double getTotalCentralTaxAmountPR() {
			return totalCentralTaxAmountPR;
		}

		public void setTotalCentralTaxAmountPR(Double totalCentralTaxAmountPR) {
			this.totalCentralTaxAmountPR = totalCentralTaxAmountPR;
		}

		public Double getTotalStateTaxAmount2A() {
			return totalStateTaxAmount2A;
		}

		public void setTotalStateTaxAmount2A(Double totalStateTaxAmount2A) {
			this.totalStateTaxAmount2A = totalStateTaxAmount2A;
		}

		public Double getTotalCessTaxAmountPR() {
			return totalCessTaxAmountPR;
		}

		public void setTotalCessTaxAmountPR(Double totalCessTaxAmountPR) {
			this.totalCessTaxAmountPR = totalCessTaxAmountPR;
		}

		public List<GSTR2FItemDto> getItemDetails() {
			return itemDetails;
		}

		public void setItemDetails(List<GSTR2FItemDto> itemDetails) {
			this.itemDetails = itemDetails;
		}

		public Double getTotalIntegratedTaxAmountPR() {
			return totalIntegratedTaxAmountPR;
		}

		public void setTotalIntegratedTaxAmountPR(Double totalIntegratedTaxAmountPR) {
			this.totalIntegratedTaxAmountPR = totalIntegratedTaxAmountPR;
		}

		public Double getTotalCentralTaxAmount2A() {
			return totalCentralTaxAmount2A;
		}

		public void setTotalCentralTaxAmount2A(Double totalCentralTaxAmount2A) {
			this.totalCentralTaxAmount2A = totalCentralTaxAmount2A;
		}

		public Double getTotalStateTaxAmountPR() {
			return totalStateTaxAmountPR;
		}

		public void setTotalStateTaxAmountPR(Double totalStateTaxAmountPR) {
			this.totalStateTaxAmountPR = totalStateTaxAmountPR;
		}

		public Double getTotalCessTaxAmount2A() {
			return totalCessTaxAmount2A;
		}

		public void setTotalCessTaxAmount2A(Double totalCessTaxAmount2A) {
			this.totalCessTaxAmount2A = totalCessTaxAmount2A;
		}

		public Double getLineNo2A() {
			return lineNo2A;
		}

		public void setLineNo2A(Double lineNo2A) {
			this.lineNo2A = lineNo2A;
		}

		public Double getLineNoPR() {
			return lineNoPR;
		}

		public void setLineNoPR(Double lineNoPR) {
			this.lineNoPR = lineNoPR;
		}

		public Double getRate2A() {
			return rate2A;
		}

		public void setRate2A(Double rate2a) {
			rate2A = rate2a;
		}

		public Double getRatePR() {
			return ratePR;
		}

		public void setRatePR(Double ratePR) {
			this.ratePR = ratePR;
		}

		public String getClientRes() {
			return clientRes;
		}

		public void setClientRes(String clientRes) {
			this.clientRes = clientRes;
		}

		
		

}
