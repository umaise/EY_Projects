package com.ey.advisory.asp.client.dto;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

/**
 * Utility class for handing JSON and DTO
 * @author Ashok.Dash
 *
 */

public class JsonUtility {
	
	/**
	 * Parses the JSON body and populates the DTO 
	 * @param jsonBody
	 * @return dto object
	 */
	public static Object parseJsonToDTO(String jsonBodyString){
		Gson gson = new Gson();
		GSTR3RootDTO dtoObj = null;
		try {
			dtoObj = gson.fromJson(jsonBodyString, GSTR3RootDTO.class);
			
		} catch (JsonSyntaxException e) {
			//TODO log exception
		}
		return dtoObj;
		
	}
	
	/**
	 * Parses the DTO values and creates corresponding Json string
	 * @param dto
	 * @return
	 */
	
	public static String parseDTOtoJson(Object dto){
		Gson gson = new Gson();
		String jsonInString = null;
		try {
			jsonInString = gson.toJson(dto);
			
		} catch (Exception e) {
			//TODO log exception
		}
		return jsonInString;
	}

}
