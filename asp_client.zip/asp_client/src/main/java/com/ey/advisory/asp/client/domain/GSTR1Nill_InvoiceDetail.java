package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import javax.persistence.*;

import com.ey.advisory.asp.common.Constant;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the tblB2CSInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblNilRatedInvoiceDetails", schema=Constant.GSTR1_SCHEMA)
public class GSTR1Nill_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private long id;
	
	@Column(name="Flag")
	private String flag;
	
	@Column(name="ChkSum")
	private String chkSum;
	
	@Column(name="SupplyType")
	private String supplyType;
	
	@Column(name="ValIncTax")
	private BigDecimal ValIncTax;
	
	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;

	@Column(name="NilAmt")
	private BigDecimal nilAmount;
	
	@Column(name="ExptAmt")
	private BigDecimal exptAmountt;
	
	@Column(name="NonGSTAmt")
	private BigDecimal nonGSTAmount;
	
	@Column(name="ItemType")
	private String item_Type;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="FileID")
	private long fileID;
	
	@Column(name="IsDelete")
	private boolean isDelete;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getChkSum() {
		return chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getSupplyType() {
		return supplyType;
	}

	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}

	public BigDecimal getValIncTax() {
		return ValIncTax;
	}

	public void setValIncTax(BigDecimal valIncTax) {
		ValIncTax = valIncTax;
	}

	public BigDecimal getTaxablevalue() {
		return taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public BigDecimal getNilAmount() {
		return nilAmount;
	}

	public void setNilAmount(BigDecimal nilAmount) {
		this.nilAmount = nilAmount;
	}

	public BigDecimal getExptAmountt() {
		return exptAmountt;
	}

	public void setExptAmountt(BigDecimal exptAmountt) {
		this.exptAmountt = exptAmountt;
	}

	public BigDecimal getNonGSTAmount() {
		return nonGSTAmount;
	}

	public void setNonGSTAmount(BigDecimal nonGSTAmount) {
		this.nonGSTAmount = nonGSTAmount;
	}

	public String getItem_Type() {
		return item_Type;
	}

	public void setItem_Type(String item_Type) {
		this.item_Type = item_Type;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public long getFileID() {
		return fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}
	
	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}


}