package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;

@Entity
@Table(name="tblAccountHead", schema="gstr3")
public class Gstr3AccountHead implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(Gstr3AccountHead.class);

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="TaxHeadID" , unique=true, nullable=false)
	private BigInteger taxHeadId;
	
	@Column(name="TaxHead" , unique=true, nullable=false)
	private String taxHead ;
	
	@Column(name="DisplayOrder", unique=true, nullable=false)
	private int displayOrder;

	public BigInteger getTaxHeadId() {
		return taxHeadId;
	}

	public void setTaxHeadId(BigInteger taxHeadId) {
		this.taxHeadId = taxHeadId;
	}

	public String getTaxHead() {
		return taxHead;
	}

	public void setTaxHead(String taxHead) {
		this.taxHead = taxHead;
	}

	public int getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}
	
	public Gstr3AccountHead(){
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in Gstr3AccountHead ");
			}
		
	}
	
	
}
