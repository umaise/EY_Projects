package com.ey.advisory.asp.client.service.gstr2;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ey.advisory.asp.client.domain.GSTR2FB2B_InvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR2FCDNA_InvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR2FCDN_InvoiceDetail;
import com.ey.advisory.asp.client.domain.Gstr2B2BInvoiceDetailsModel;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;

public interface Gstr2ReconDetailsService {
    
    public List<Gstr2B2BInvoiceDetailsModel> getGstr2B2BInvoiceDetails(String gstin, String taxPeriod);
    public List<GSTR2FCDNA_InvoiceDetail> getCDNADetails(String gstin, String taxPeriod);
    public List<GSTR2FCDN_InvoiceDetail> getCDNDetails(String gstin, String taxPeriod);
    public List<GSTR2FB2B_InvoiceDetail> getGSTR2B2BAInvoiceDetails(String gstin, String taxPeriod);
    public <T> Map<String,Set<TblPurchaseErrorInfo>> getTblPurchaseErrorInfo(String gstin, String taxPeriod, Class<T> classType);
    public long getMaxNoOfReconErrorCode(String gstin, String taxPeriod, String status, String mismatchStatus);
    public List<String> getGstnListForFileId(List<Integer> fileIdList);
}
