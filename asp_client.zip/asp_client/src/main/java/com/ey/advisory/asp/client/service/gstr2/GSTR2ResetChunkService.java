package com.ey.advisory.asp.client.service.gstr2;

import org.json.simple.JSONObject;
public interface GSTR2ResetChunkService {

	public String resetGSTR2Chunks(JSONObject jsonObject);

}
