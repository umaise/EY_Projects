package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR2SummaryAdvancePaid;

@FunctionalInterface
public interface GSTR2SummaryAdvancePaidDao {

	public List<GSTR2SummaryAdvancePaid> getAdvancePaidMetadata(); 
}
