package com.ey.advisory.asp.client.service.gstr1;

import java.net.URL;

/**
 * @author Mayank3.Kumar
 *
 */
public interface GSTR1AService {

	
	/**
	 * To generate GSTR1FRecon report.
	 * 
	 * @param gstin
	 * @param taxPeriod
	 * @param template_Dir 
	 */
	public void generateGSTR1FReconReport(String groupCode, String gstin, String taxPeriod, URL template_Dir);
}
