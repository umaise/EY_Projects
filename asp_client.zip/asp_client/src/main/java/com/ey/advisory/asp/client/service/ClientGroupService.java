/**
 * 
 */
package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.ClientGroupDomain;

/**
 * @author Nitesh.Tripathi
 *
 */
public interface ClientGroupService {

	public String getClientGroup(long groupId, String groupcode);

	public List<ClientGroupDomain> getClientGroup();
	
}
