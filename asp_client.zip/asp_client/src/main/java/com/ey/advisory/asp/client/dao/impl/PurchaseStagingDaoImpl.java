package com.ey.advisory.asp.client.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.PurchaseStagingDao;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblPurchasePreStaging;

@Repository
public class PurchaseStagingDaoImpl implements PurchaseStagingDao{
	
	@Autowired
	HibernateDao hibernateDao;

	@Override
	public List<InwardInvoiceModel> fetchProcessedRecords(Long fileId,int firstResult, int pageSize) {
		List<InwardInvoiceModel> purchaseProcessedList = null;
        Criteria criteria = hibernateDao.createNormalCriteria(InwardInvoiceModel.class);
		criteria.add(Restrictions.eq("fileID", fileId.intValue()));
		criteria.add(Restrictions.eq("isError", false));
		criteria.add(Restrictions.eq("isDuplicate", false));
       
        criteria.setFirstResult(firstResult);
        criteria.setMaxResults(pageSize);
        criteria.addOrder(Order.asc("id"));
        purchaseProcessedList = criteria.list();
		return purchaseProcessedList;
	}

	@Override
	public List<InwardInvoiceModel> fetchTotalRecords(Long fileId,int firstResult, int pageSize) {
		List<InwardInvoiceModel> purchaseTotalList = null;
		Criteria criteria = hibernateDao.createNormalCriteria(TblPurchasePreStaging.class);
        criteria.add(Restrictions.eq("fileID", fileId));
        criteria.setFirstResult(firstResult);
        criteria.setMaxResults(pageSize);
        criteria.addOrder(Order.asc("id"));
        purchaseTotalList = criteria.list();
        return purchaseTotalList;
	}

	@Override
	public List<InwardInvoiceModel> fetchDupRecords(Long fileId,int firstResult, int pageSize) {
		List<InwardInvoiceModel> purchaseDupList;
        Criteria criteria = hibernateDao.createNormalCriteria(InwardInvoiceModel.class);
        criteria.add(Restrictions.eq("fileID", fileId.intValue()));
        criteria.add(Restrictions.eq("isDuplicate", Boolean.TRUE));
        criteria.setFirstResult(firstResult);
        criteria.setMaxResults(pageSize);
        criteria.addOrder(Order.asc("id"));
        purchaseDupList = criteria.list();
		return purchaseDupList;
	}

	@Override
	public Long getTotalCount(Long fileId) {
		Long count = null;
		Criteria criteriaCount = hibernateDao.createNormalCriteria(TblPurchasePreStaging.class);
        criteriaCount.add(Restrictions.eq("fileID", fileId));
        criteriaCount.add(Restrictions.eq("isDuplicate", true));
        criteriaCount.setProjection(Projections.rowCount());
        count = (Long) (criteriaCount).uniqueResult();
		return count;
	}

	@Override
	public Long getTotalProcessedCount(Long fileId) {
		Long count = null;
		Criteria criteriaCount = hibernateDao.createNormalCriteria(InwardInvoiceModel.class);
		criteriaCount.add(Restrictions.eq("fileID", fileId.intValue()));
		criteriaCount.add(Restrictions.eq("isError", false));
		criteriaCount.add(Restrictions.eq("isDuplicate", false));
		criteriaCount.setProjection(Projections.rowCount());
		count = (Long) (criteriaCount).uniqueResult();
		return count;
	}

	@Override
	public Long getTotalDupCount(Long fileId) {
		Long count = null;
		Criteria criteriaCount = hibernateDao.createNormalCriteria(InwardInvoiceModel.class);
		criteriaCount.add(Restrictions.eq("fileID", fileId.intValue()));
		criteriaCount.add(Restrictions.eq("isDuplicate", true));
		criteriaCount.setProjection(Projections.rowCount());
		count = (Long) (criteriaCount).uniqueResult();
		return count;
	}

	@Override
	public List<InwardInvoiceModel> fetchErrorRecords(Long fileId,int firstResult, int pageSize) {
		List<InwardInvoiceModel> purchaseDupList;
        Criteria criteria = hibernateDao.createNormalCriteria(InwardInvoiceModel.class);
        criteria.add(Restrictions.eq("fileID", fileId.intValue()));
        criteria.add(Restrictions.eq("isError", Boolean.TRUE));
        criteria.setFirstResult(firstResult);
        criteria.setMaxResults(pageSize);
        criteria.addOrder(Order.asc("id"));
        purchaseDupList = criteria.list();
		return purchaseDupList;
	}

	@Override
	public Long getTotalErrorCount(Long fileId) {
		Long count = null;
		Criteria criteriaCount = hibernateDao.createNormalCriteria(InwardInvoiceModel.class);
		criteriaCount.add(Restrictions.eq("fileID", fileId.intValue()));
		criteriaCount.add(Restrictions.eq("isError", Boolean.TRUE));
		criteriaCount.setProjection(Projections.rowCount());
		count = (Long) (criteriaCount).uniqueResult();
		return count;
	}

}
