package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="tblB2CSummary", schema="etl")
@NamedQuery(name = "TblB2CSummary.findAll", query = "SELECT t FROM TblB2CSummary t")
public class TblB2CSummary implements Serializable {
	
	private static final long serialVersionUID = 1;

	@Id
	@Column(name="B2CSummaryID")
	private Long b2CSummaryID;
	
	@Column(name="SupplierGSTIN")
	private String supplierGSTIN;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="OrgDetailsMonth")
	private String orgDetailsMonth;
	
	@Column(name="OrgDetailsPOS")
	private String orgDetailsPOS;
	
	@Column(name="OrgDetailsRate")
	private BigDecimal orgDetailsRate;
	
	@Column(name="OrgDetailsTaxableValue")
	private BigDecimal orgDetailsTaxableValue; 
	
	@Column(name="OrgDetailsGSTINofEcom")
	private String orgDetailsGSTINofEcom;
	
	@Column(name="OrgDetailsSuppliesThroughEcom")
	private BigDecimal orgDetailsSuppliesThroughEcom; 
	
	
	@Column(name="NewDetailsPOS")
	private String newDetailsPOS;
	
	@Column(name="NewDetailsRate")
	private BigDecimal newDetailsRate;
	
	@Column(name="NewDetailsTaxableValue")
	private BigDecimal newDetailsTaxableValue;
	
	@Column(name="NewDetailsGSTINofEcom")
	private String newDetailsGSTINofEcom;
	
	@Column(name="NewDetailsSuppliesThroughEcom")
	private BigDecimal newDetailsSuppliesThroughEcom; 
	
	@Column(name="AmtIGST")
	private BigDecimal amtIGST;
	
	@Column(name="AmtCGST")
	private BigDecimal amtCGST;
	
	@Column(name="AmtSGST")
	private BigDecimal amtSGST;
	
	@Column(name="AmtCESS")
	private BigDecimal amtCESS;
	
	@Column(name="gHSNorSAC")
	private String gHSNorSAC;
	
	@Column(name="OrgUnitOfMeasurement")
	private String orgUnitOfMeasurement;
	
	@Column(name="OrgQuantity")
	private BigDecimal orgQuantity;
	
	@Column(name="NewHSNorSAC")
	private String newHSNorSAC;
	
	@Column(name="NewUnitOfMeasurement")
	private String newUnitOfMeasurement;
	
	@Column(name="NewQuantity")
	private BigDecimal newQuantity;
	
	@Column(name="IsActive")
	private Boolean isActive;
	
	@Column(name="SummaryFileID")
	private Long summaryFileID;
	
	@Column(name="TotalValue")
	private BigDecimal totalValue;
	
	
	public Long getB2CSummaryID() {
		return b2CSummaryID;
	}

	public void setB2CSummaryID(Long b2cSummaryID) {
		b2CSummaryID = b2cSummaryID;
	}

	public String getSupplierGSTIN() {
		return supplierGSTIN;
	}

	public void setSupplierGSTIN(String supplierGSTIN) {
		this.supplierGSTIN = supplierGSTIN;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getOrgDetailsMonth() {
		return orgDetailsMonth;
	}

	public void setOrgDetailsMonth(String orgDetailsMonth) {
		this.orgDetailsMonth = orgDetailsMonth;
	}

	public String getOrgDetailsPOS() {
		return orgDetailsPOS;
	}

	public void setOrgDetailsPOS(String orgDetailsPOS) {
		this.orgDetailsPOS = orgDetailsPOS;
	}

	public BigDecimal getOrgDetailsRate() {
		return orgDetailsRate;
	}

	public void setOrgDetailsRate(BigDecimal orgDetailsRate) {
		this.orgDetailsRate = orgDetailsRate;
	}

	public BigDecimal getOrgDetailsTaxableValue() {
		return orgDetailsTaxableValue;
	}

	public void setOrgDetailsTaxableValue(BigDecimal orgDetailsTaxableValue) {
		this.orgDetailsTaxableValue = orgDetailsTaxableValue;
	}

	public String getOrgDetailsGSTINofEcom() {
		return orgDetailsGSTINofEcom;
	}

	public void setOrgDetailsGSTINofEcom(String orgDetailsGSTINofEcom) {
		this.orgDetailsGSTINofEcom = orgDetailsGSTINofEcom;
	}

	public BigDecimal getOrgDetailsSuppliesThroughEcom() {
		return orgDetailsSuppliesThroughEcom;
	}

	public void setOrgDetailsSuppliesThroughEcom(BigDecimal orgDetailsSuppliesThroughEcom) {
		this.orgDetailsSuppliesThroughEcom = orgDetailsSuppliesThroughEcom;
	}

	public String getNewDetailsPOS() {
		return newDetailsPOS;
	}

	public void setNewDetailsPOS(String newDetailsPOS) {
		this.newDetailsPOS = newDetailsPOS;
	}

	public BigDecimal getNewDetailsRate() {
		return newDetailsRate;
	}

	public void setNewDetailsRate(BigDecimal newDetailsRate) {
		this.newDetailsRate = newDetailsRate;
	}

	public BigDecimal getNewDetailsTaxableValue() {
		return newDetailsTaxableValue;
	}

	public void setNewDetailsTaxableValue(BigDecimal newDetailsTaxableValue) {
		this.newDetailsTaxableValue = newDetailsTaxableValue;
	}

	public String getNewDetailsGSTINofEcom() {
		return newDetailsGSTINofEcom;
	}

	public void setNewDetailsGSTINofEcom(String newDetailsGSTINofEcom) {
		this.newDetailsGSTINofEcom = newDetailsGSTINofEcom;
	}

	public BigDecimal getNewDetailsSuppliesThroughEcom() {
		return newDetailsSuppliesThroughEcom;
	}

	public void setNewDetailsSuppliesThroughEcom(BigDecimal newDetailsSuppliesThroughEcom) {
		this.newDetailsSuppliesThroughEcom = newDetailsSuppliesThroughEcom;
	}

	public BigDecimal getAmtIGST() {
		return amtIGST;
	}

	public void setAmtIGST(BigDecimal amtIGST) {
		this.amtIGST = amtIGST;
	}

	public BigDecimal getAmtCGST() {
		return amtCGST;
	}

	public void setAmtCGST(BigDecimal amtCGST) {
		this.amtCGST = amtCGST;
	}

	public BigDecimal getAmtSGST() {
		return amtSGST;
	}

	public void setAmtSGST(BigDecimal amtSGST) {
		this.amtSGST = amtSGST;
	}

	public BigDecimal getAmtCESS() {
		return amtCESS;
	}

	public void setAmtCESS(BigDecimal amtCESS) {
		this.amtCESS = amtCESS;
	}

	public String getgHSNorSAC() {
		return gHSNorSAC;
	}

	public void setgHSNorSAC(String gHSNorSAC) {
		this.gHSNorSAC = gHSNorSAC;
	}

	public String getOrgUnitOfMeasurement() {
		return orgUnitOfMeasurement;
	}

	public void setOrgUnitOfMeasurement(String orgUnitOfMeasurement) {
		this.orgUnitOfMeasurement = orgUnitOfMeasurement;
	}

	public BigDecimal getOrgQuantity() {
		return orgQuantity;
	}

	public void setOrgQuantity(BigDecimal orgQuantity) {
		this.orgQuantity = orgQuantity;
	}

	public String getNewHSNorSAC() {
		return newHSNorSAC;
	}

	public void setNewHSNorSAC(String newHSNorSAC) {
		this.newHSNorSAC = newHSNorSAC;
	}

	public String getNewUnitOfMeasurement() {
		return newUnitOfMeasurement;
	}

	public void setNewUnitOfMeasurement(String newUnitOfMeasurement) {
		this.newUnitOfMeasurement = newUnitOfMeasurement;
	}

	public BigDecimal getNewQuantity() {
		return newQuantity;
	}

	public void setNewQuantity(BigDecimal newQuantity) {
		this.newQuantity = newQuantity;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Long getSummaryFileID() {
		return summaryFileID;
	}

	public void setSummaryFileID(Long summaryFileID) {
		this.summaryFileID = summaryFileID;
	}
	
	public BigDecimal getTotalValue() {
		return totalValue;
	}

	public void setTotalValue(BigDecimal totalValue) {
		this.totalValue = totalValue;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((b2CSummaryID == null) ? 0 : b2CSummaryID.hashCode());
		return result;
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TblB2CSummary other = (TblB2CSummary) obj;
		if (b2CSummaryID == null) {
			if (other.b2CSummaryID != null)
				return false;
		} else if (!b2CSummaryID.equals(other.b2CSummaryID))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return (supplierGSTIN != null ? supplierGSTIN : "") + ", "
				+ (taxPeriod != null ? taxPeriod : "") + ", "
				+ (orgDetailsMonth != null ? orgDetailsMonth : "") + ", "
				+ (orgDetailsPOS != null ? orgDetailsPOS : "") + ", "
				+ (gHSNorSAC != null ? gHSNorSAC : "") + ", "
				+ (orgUnitOfMeasurement != null ? orgUnitOfMeasurement : "") + ", "
				+ (orgQuantity != null ? orgQuantity : "") + ", "
				+ (orgDetailsRate != null ? orgDetailsRate : "") + ", "
				+ (orgDetailsTaxableValue != null ? orgDetailsTaxableValue : "") + ", "
				+ (orgDetailsGSTINofEcom != null ? orgDetailsGSTINofEcom : "") + ", "
				+ (orgDetailsSuppliesThroughEcom != null ? orgDetailsSuppliesThroughEcom : "") + ", "
				+ (newDetailsPOS != null ? newDetailsPOS : "") + ", "
				+ (newHSNorSAC != null ? newHSNorSAC : "") + ", "
				+ (newUnitOfMeasurement != null ? newUnitOfMeasurement : "") + ", "
				+ (newQuantity != null ? newQuantity : "")+ ", "
				+ (newDetailsRate != null ? newDetailsRate : "") + ", "
				+ (newDetailsTaxableValue != null ? newDetailsTaxableValue : "") + ", "
				+ (newDetailsGSTINofEcom != null ? newDetailsGSTINofEcom : "") + ", "
				+ (newDetailsSuppliesThroughEcom != null ? newDetailsSuppliesThroughEcom : "") + ", "
				+ (amtIGST != null ? amtIGST : "") + ", "
				+ (amtCGST != null ? amtCGST : "") + ", "
				+ (amtSGST != null ? amtSGST : "") + ", "
				+ (amtCESS != null ? amtCESS : "") + ", "
				+ (totalValue != null ? totalValue : "");
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	/*@Override
	public String toString() {
		return (supplierGSTIN != null ? supplierGSTIN : "") + ", "
				+ (taxPeriod != null ? taxPeriod : "") + ", "
				+ (orgDetailsMonth != null ? orgDetailsMonth : "") + ", "
				+ (orgDetailsPOS != null ? orgDetailsPOS : "") + ", "
				+ (gHSNorSAC != null ? gHSNorSAC : "") + ", "
				+ (orgUnitOfMeasurement != null ? orgUnitOfMeasurement : "") + ", "
				+ (orgQuantity != null ? orgQuantity : "") + ", "
				+ (orgDetailsRate != null ? orgDetailsRate : "") + ", "
				+ (orgDetailsTaxableValue != null ? orgDetailsTaxableValue : "") + ", "
				+ (orgDetailsGSTINofEcom != null ? orgDetailsGSTINofEcom : "") + ", "
				+ (orgDetailsSuppliesThroughEcom != null ? orgDetailsSuppliesThroughEcom : "") + ", "
				+ (newDetailsPOS != null ? newDetailsPOS : "") + ", "
				+ (newHSNorSAC != null ? newHSNorSAC : "") + ", "
				+ (newUnitOfMeasurement != null ? newUnitOfMeasurement : "") + ", "
				+ (newQuantity != null ? newQuantity : "")+ ", "
				+ (newDetailsRate != null ? newDetailsRate : "") + ", "
				+ (newDetailsTaxableValue != null ? newDetailsTaxableValue : "") + ", "
				+ (newDetailsGSTINofEcom != null ? newDetailsGSTINofEcom : "") + ", "
				+ (newDetailsSuppliesThroughEcom != null ? newDetailsSuppliesThroughEcom : "") + ", "
				+ (amtIGST != null ? amtIGST : "") + ", "
				+ (amtCGST != null ? amtCGST : "") + ", "
				+ (amtSGST != null ? amtSGST : "")  + ", "
				+ (amtCESS != null ? amtCESS : "");
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	/*@Override
	public String toString() {
		return  supplierGSTIN + "," + taxPeriod + "," + orgDetailsMonth + "," + orgDetailsPOS + "," + gHSNorSAC +"," 
				+ orgUnitOfMeasurement + "," + orgQuantity + "," + orgDetailsRate + "," + orgDetailsTaxableValue + "," + orgDetailsGSTINofEcom + ","
				+ orgDetailsSuppliesThroughEcom + "," + newDetailsPOS + "," + newHSNorSAC + "," + newUnitOfMeasurement + "," + newQuantity
				+ "," + newDetailsRate + ", "+ newDetailsTaxableValue + "," + newDetailsGSTINofEcom + "," + newDetailsSuppliesThroughEcom + ","
				+ amtIGST + "," + amtCGST + "," + amtSGST + "," + amtCESS;
	}
*/
	
	
}
