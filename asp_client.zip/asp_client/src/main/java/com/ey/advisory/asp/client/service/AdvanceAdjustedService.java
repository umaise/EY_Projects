package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblAdvanceAdjusted;

public interface AdvanceAdjustedService {
	
	List<TblAdvanceAdjusted> fetchAll();
	Long getTotalRecordCount(Long fileId);
	List<TblAdvanceAdjusted> fetchTotalRecords(Long fileId, int firstResult, int pageSize);

}
