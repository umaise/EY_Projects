/**
 * 
 */
package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Uma.Chandranaik
 *
 */
@Entity
@Table(name="tblGetgstr3Master", schema="gstr3")
public class GSTR3Master implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	private BigInteger ID;
	
	
	@Column(name="GSTIN")
	private String GSTIN;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="RefID")
	private String refId;
	
	@Column(name="IsActive")
	private boolean isActive;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
	@Column(name="GenerateDate")
    private Date generatedDate;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
	@Column(name="FetchDate")
    private Date fetchDate;
	
	
	@Column(name="DebitEntryNum")
	private String debitEntryNum;
	
	@Column(name="IntrestLiabilitySubmitted")
	private boolean intLiabSubmitted;
	
	@Column(name="UtilizationSubmitted")
	private boolean utilLiabSubmitted;
	
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
	@Column(name="ModifiedOn")
    private Date modifiedOn;
	
	@Column(name="CreatedBy")
	private String createdBy;;
	
	
	@Column(name="UpdatedBy")
	private String updatedBy;


	public BigInteger getID() {
		return ID;
	}


	public void setID(BigInteger iD) {
		ID = iD;
	}


	public String getGSTIN() {
		return GSTIN;
	}


	public void setGSTIN(String gSTIN) {
		GSTIN = gSTIN;
	}


	public String getTaxPeriod() {
		return taxPeriod;
	}


	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}


	public String getRefId() {
		return refId;
	}


	public void setRefId(String refId) {
		this.refId = refId;
	}


	public boolean isActive() {
		return isActive;
	}


	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}


	public Date getGeneratedDate() {
		return generatedDate;
	}


	public void setGeneratedDate(Date generatedDate) {
		this.generatedDate = generatedDate;
	}


	public Date getFetchDate() {
		return fetchDate;
	}


	public void setFetchDate(Date fetchDate) {
		this.fetchDate = fetchDate;
	}


	public String getDebitEntryNum() {
		return debitEntryNum;
	}


	public void setDebitEntryNum(String debitEntryNum) {
		this.debitEntryNum = debitEntryNum;
	}


	public boolean isIntLiabSubmitted() {
		return intLiabSubmitted;
	}


	public void setIntLiabSubmitted(boolean intLiabSubmitted) {
		this.intLiabSubmitted = intLiabSubmitted;
	}


	public boolean isUtilLiabSubmitted() {
		return utilLiabSubmitted;
	}


	public void setUtilLiabSubmitted(boolean utilLiabSubmitted) {
		this.utilLiabSubmitted = utilLiabSubmitted;
	}


	public Date getModifiedOn() {
		return modifiedOn;
	}


	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	};
	
	
}
