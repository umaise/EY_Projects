package com.ey.advisory.asp.client.service;

import com.ey.advisory.asp.client.dto.Mail;

public interface MailService {

	public String sendMail(Mail mail);

	public void fileGSTR1(String toAddress, String gstin, String taxPeriod) throws Exception;

	public void fileGSTR2(String toAddress, String gstin, String taxPeriod) throws Exception;
	
	public void fileGSTR3(String toAddress, String gstin, String month,
			String year) throws Exception;

	public void fileGSTR6(String toAddress, String gstin, String taxPeriod) throws Exception;

	public void fileGSTR7(String toAddress, String gstin,String taxPeriod) throws Exception;

}
