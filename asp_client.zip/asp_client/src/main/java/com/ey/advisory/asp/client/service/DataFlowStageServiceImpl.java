package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.DataFlowStageModel;
import com.ey.advisory.asp.common.Constant;

public class DataFlowStageServiceImpl implements DataFlowStageService{
    
    @Autowired
    private HibernateDao hibernateDao;

    private static final Logger logger = Logger.getLogger(DataFlowStageServiceImpl.class);

    @SuppressWarnings("unchecked")
    @Override
    public Map<String, String> getStageInfo(String type) {
        List<DataFlowStageModel> dataFlowStageModelList = new ArrayList<>();
        
        Map<String, String> stageInfo = new HashMap<>();

        try {
            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(DataFlowStageModel.class);
            detachedCriteria.add(Restrictions.eq("returnType", type));
            dataFlowStageModelList = (List<DataFlowStageModel>) hibernateDao.find(detachedCriteria);
        }
        catch (Exception exe) {
        	if(logger.isInfoEnabled())
            logger.info(Constant.LOGGER_ERROR + DataFlowStageServiceImpl.class.getName()
                + " Method : getStageInfo()" + exe);
        }
        
        for(DataFlowStageModel dataFlowStageModel : dataFlowStageModelList){
            stageInfo.put(dataFlowStageModel.getStageCode(), dataFlowStageModel.getStageDesc());
        }
        
        return stageInfo;
    }
    
    

}
