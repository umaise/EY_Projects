package com.ey.advisory.asp.client.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GstinFinancialsDetailsDao;
import com.ey.advisory.asp.common.Constant;

@Service
public class GstinFinancialsDetailsServiceImpl implements
		GstinFinancialsDetailsService {

	private static final Logger logger = Logger.getLogger(GstinFinancialsDetailsServiceImpl.class);
	private static final String CLASS_NAME = GstinFinancialsDetailsServiceImpl.class.getName();
	
	@Autowired
	GstinFinancialsDetailsDao gstinFinancialsDetailsDao;
	
	@Override
	public Double getTurnOverforEntity(String entityId) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD +"getTurnOverforEntity()");
		return gstinFinancialsDetailsDao.getTurnOverforEntity(entityId);
	}
}
