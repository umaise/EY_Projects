package com.ey.advisory.asp.client.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.SummaryJsonChunkDao;
import com.ey.advisory.asp.client.domain.SummaryJsonChunk;
import com.ey.advisory.asp.common.Constant;

@Repository
public class SummaryJsonChunkDaoImpl implements SummaryJsonChunkDao {

	private static final Logger logger = Logger
			.getLogger(SummaryJsonChunkDaoImpl.class);
	private static final String CLASS_NAME = SummaryJsonChunkDaoImpl.class
			.getName();

	@Autowired
	HibernateDao hibernateDao;
	
	@Override
	public void saveSummaryJsonChunkData(List<SummaryJsonChunk> summJsonChunk){
		
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " saveSummaryJsonChunkData");
		}
		try {
			
			hibernateDao.saveOrUpdateAll(summJsonChunk);
			
			if(logger.isInfoEnabled())
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " saveSummaryJsonChunkData");
		} catch (Exception e) {
			if(logger.isInfoEnabled())
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD + " saveSummaryJsonChunkData"
					+ e);
		}
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public String updateSummaryJsonChunk(String status, int summaryFileId, String chunkSeries) {

		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " updateSummaryJsonChunk");
		}
		try {
			
			SummaryJsonChunk summaryJsonChunk = null;

			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(SummaryJsonChunk.class);
			detachedCriteria.add(Restrictions.eq("summaryFileID", summaryFileId));
			detachedCriteria.add(Restrictions.eq("chunkSeries", chunkSeries));

			List<SummaryJsonChunk> summJsonChunkList = (List<SummaryJsonChunk>) hibernateDao
					.find(detachedCriteria);

			if (null != summJsonChunkList
					&& !summJsonChunkList.isEmpty()) {
				summaryJsonChunk = summJsonChunkList.get(0);
			}
			if (null != summaryJsonChunk){
			summaryJsonChunk.setStatusOfChunk(status);
			hibernateDao.saveOrUpdate(summaryJsonChunk);
			}
			if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " updateSummaryJsonChunk");
			}
			return Constant.SUCCESS;
		} catch (Exception e) {
			if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD + " updateSummaryJsonChunk"
					+ e);
			}
			return Constant.FAILED;
		}

	}

	
}
