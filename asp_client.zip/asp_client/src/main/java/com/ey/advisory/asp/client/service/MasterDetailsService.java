package com.ey.advisory.asp.client.service;

import java.sql.SQLDataException;
import java.util.List;

import com.ey.advisory.asp.client.domain.CustomerMaster;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.ProductMaster;
import com.ey.advisory.asp.client.domain.QuestionAnswerMapping;
import com.ey.advisory.asp.client.domain.VendorMaster;
import com.ey.advisory.asp.client.dto.OnBoardDto;


public interface MasterDetailsService {
	
	public List<QuestionAnswerMapping> getQuestionAnswerList(String enittyID) throws SQLDataException;
	public String saveEditClientData(OnBoardDto onBoardDto) throws SQLDataException;
	public List<ItemMaster> fetchItemMasterDetails() throws SQLDataException;
	public List<VendorMaster> fetchVendorMasterDetails() throws SQLDataException;
	public List<ProductMaster> fetchProductMasterDetails() throws SQLDataException;
	public List<CustomerMaster> fetchCustomerMasterDetails() throws SQLDataException;
	public void deleteQuestionAnswer(List<QuestionAnswerMapping> questionAnswerList) throws SQLDataException;
}
