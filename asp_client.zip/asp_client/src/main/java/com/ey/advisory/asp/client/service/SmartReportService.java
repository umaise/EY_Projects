package com.ey.advisory.asp.client.service;

import java.util.List;

import org.json.simple.parser.ParseException;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.SmartReport;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.dto.SmartReportDto;
import com.ey.advisory.asp.dto.DynamicSmartReportDto;

public interface SmartReportService {
	public String saveSmartReportDetails(SmartReportDto smartReportDto) ;
	
	public List<SmartReport> getSmartReportDetails(String status);
	
	public List<OutwardInvoiceModel> getOutwardSuppliesData(DynamicSmartReportDto requestDetails,int offset,int pageSize) throws Exception;
	
	public List<InwardInvoiceModel> getInwardSuppliesData(DynamicSmartReportDto requestDetails,int offset,int pageSize);
	
	public boolean updateSmartReportPathAndFileName(String reportId,String filePath,String fileName);
	
	public List<OutwardInvoiceModel> getStockTransferData(DynamicSmartReportDto requestDetails,String cGstin, int offset, int pageSize) throws Exception;

	public List<InwardInvoiceModel> getRcmData(DynamicSmartReportDto requestDetails,String category, int offset, int pageSize);
	
	public boolean updateSmartReportStatus(String reportId,String status);

	public SmartReport getSmartReportDetailsByReportId(String reportId);
	
	public TblGstinRetutnFilingStatus findReportJobStatus(String gstin, String retPeriod, String api);

	public String getGSTR1FFStatus(String gstin, String retPeriod, String api);
	
	/**
	 * Method to check the status once gstr1ff is done
	 * @param gstin
	 * @param retPeriod
	 * @return
	 * @throws Exception
	 *//*
	public String findGSTR1FFStatus(String gstin, String retPeriod, String api);*/
	
	public String saveGSTR1FFData(String gstinId, String rtPeriod, String groupCode,  String  invType, String  json, String  chunkId);
	
	
	/**
	 * Method to update the status once gstr1ff is done
	 * @param gstin
	 * @param retPeriod
	 * @return
	 * @throws Exception
	 */
	public String updateGSTR1FFStatus(String gstin, String retPeriod, String status);
	
	/**
	 * Method to update the status once gstr1FF is done
	 * @param gstin
	 * @param retPeriod
	 * @return
	 * @throws Exception
	 */
	public String insertGSTR1FFStatus(String gstin, String retPeriod, String status) throws Exception;
	

	/**
	 * method to process GETB2B for GSTR1FF
	 * @param gstin
	 * @param retPeriod
	 * @param groupCode
	 * @param b2b
	 * @return
	 * @throws Exception 
	 */
	public String saveGSTR1FFData(String gstin, String retPeriod, String groupCode, String invType, String jsonResponse,Integer chunkId) throws Exception;

	public String processRecievedResponse(String b2bRespJSON, String gstin, String retPeriod, String groupCode,
			String action, String hitCount) throws ParseException, Exception; 
	
	public String scheduleSimpleTrigger(String resourceURL,
			 String groupCode, String est, String action, String gstin, String token,
			String retPeriod, String hitCount);
}
