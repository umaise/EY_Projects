package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;


/**
 * The persistent class for the tblCDNInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblCDNInvoiceDetails", schema="gstr1")
public class GSTR1CDN_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR1CDN_InvoiceDetail.class);

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private long id;

	@Column(name="CustGSTIN")
	private String custGSTIN;

	@Column(name="CustName")
	private String custName;

	@Column(name="InvType")
	private String invType;

	@Column(name="Flag")
	private String flag;

	@Column(name="ChkSum")
	private String chkSum;	

	@Column(name="NoteNum")
	private String noteNum;

	@Column(name="NoteTyp")
	private String noteTyp;
		
	@Column(name="NoteDate")
	private Date noteDate;

	@Column(name="Reason")
	private String reason;

	@Column(name="InvNum")
	private String orgInvNum;
	
	@Column(name="InvDate")
	private Date invDate;

	@Column(name="Rchrg")
	private char rchrg;

	@Column(name="DiffValue")
	private BigDecimal diffValue;
	
	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;

	@Column(name="IGSTAmt")
	private BigDecimal IGSTAmt;

	@Column(name="IGSTRt")
	private BigDecimal IGSTRt;

	@Column(name="SGSTAmt")
	private BigDecimal SGSTAmt;

	@Column(name="SGSTRt")
	private BigDecimal SGSTRt;
	
	@Column(name="CessAmt")
	private BigDecimal cessAmt;

	@Column(name="CessRt")
	private BigDecimal cessRt;

	@Column(name="CGSTAmt")
	private BigDecimal CGSTAmt;

	@Column(name="CGSTRt")
	private BigDecimal CGSTRt;
	
	@Column(name="Etin")
	private String etin;
	
	@Column(name="Gstin")
	private String gstin;

	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="FileID")
	private long fileID;

	@Column(name="IsDelete")
	private boolean isDelete;

	public char getRchrg() {
		return rchrg;
	}

	public void setRchrg(char rchrg) {
		this.rchrg = rchrg;
	}

	public BigDecimal getCessRt() {
		return cessRt;
	}

	public void setCessRt(BigDecimal cessRt) {
		this.cessRt = cessRt;
	}

	public BigDecimal getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(BigDecimal cessAmt) {
		this.cessAmt = cessAmt;
	}

	public String getEtin() {
		return etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	public boolean isDelete() {
		return isDelete;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public GSTR1CDN_InvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR1CDN_InvoiceDetail ");
			}
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getCGSTAmt() {
		return this.CGSTAmt;
	}

	public void setCGSTAmt(BigDecimal CGSTAmt) {
		this.CGSTAmt = CGSTAmt;
	}

	public BigDecimal getCGSTRt() {
		return this.CGSTRt;
	}

	public void setCGSTRt(BigDecimal CGSTRt) {
		this.CGSTRt = CGSTRt;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getCustGSTIN() {
		return this.custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getCustName() {
		return this.custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public BigDecimal getDiffValue() {
		return this.diffValue;
	}

	public void setDiffValue(BigDecimal diffValue) {
		this.diffValue = diffValue;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public BigDecimal getIGSTAmt() {
		return this.IGSTAmt;
	}

	public void setIGSTAmt(BigDecimal IGSTAmt) {
		this.IGSTAmt = IGSTAmt;
	}

	public BigDecimal getIGSTRt() {
		return this.IGSTRt;
	}

	public void setIGSTRt(BigDecimal IGSTRt) {
		this.IGSTRt = IGSTRt;
	}

	public Date getInvDate() {
		return this.invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getInvType() {
		return this.invType;
	}

	public void setInvType(String invType) {
		this.invType = invType;
	}

	public Date getNoteDate() {
		return this.noteDate;
	}

	public void setNoteDate(Date noteDate) {
		this.noteDate = noteDate;
	}

	public String getNoteNum() {
		return this.noteNum;
	}

	public void setNoteNum(String noteNum) {
		this.noteNum = noteNum;
	}

	public String getNoteTyp() {
		return this.noteTyp;
	}

	public void setNoteTyp(String noteTyp) {
		this.noteTyp = noteTyp;
	}

	public String getOrgInvNum() {
		return this.orgInvNum;
	}

	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public BigDecimal getSGSTAmt() {
		return this.SGSTAmt;
	}

	public void setSGSTAmt(BigDecimal SGSTAmt) {
		this.SGSTAmt = SGSTAmt;
	}

	public BigDecimal getSGSTRt() {
		return this.SGSTRt;
	}

	public void setSGSTRt(BigDecimal SGSTRt) {
		this.SGSTRt = SGSTRt;
	}

	public BigDecimal getTaxablevalue() {
		return this.taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

}