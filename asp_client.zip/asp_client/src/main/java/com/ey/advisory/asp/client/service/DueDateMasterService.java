package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.DueDateMaster;


public interface DueDateMasterService {

	public List<DueDateMaster> getGstinDueDateMaster(List<String> returnType, String gstin);
	public String getGstinReturnType(String gstin);
}
