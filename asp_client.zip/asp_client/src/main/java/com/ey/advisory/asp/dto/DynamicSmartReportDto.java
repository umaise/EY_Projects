package com.ey.advisory.asp.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="query")
@XmlAccessorType(XmlAccessType.FIELD)
public class DynamicSmartReportDto {
	
	@XmlElement(name="selectedCols")
	private OutwardSuppliesSelectedColumns selectedColumns;
	
	@XmlElement(name="whereCondition")
	private SmartReportConditions whereConditions;

	public OutwardSuppliesSelectedColumns getSelectedColumns() {
		return selectedColumns;
	}

	public void setSelectedColumns(OutwardSuppliesSelectedColumns selectedColumns) {
		this.selectedColumns = selectedColumns;
	}

	public SmartReportConditions getWhereConditions() {
		return whereConditions;
	}

	public void setWhereConditions(SmartReportConditions whereConditions) {
		this.whereConditions = whereConditions;
	}

	
	
	
}
