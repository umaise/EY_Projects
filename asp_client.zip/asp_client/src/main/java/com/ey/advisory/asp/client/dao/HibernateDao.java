package com.ey.advisory.asp.client.dao;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.orm.hibernate4.HibernateTemplate;


public interface HibernateDao {

	/**
	 * Return the persistent instance of the given entity class with the given
	 * identifier
	 * 
	 * @param entityName
	 *            - a persistent class
	 * @param id
	 *            - the identifier of the persistent instance
	 * @return the persistent instance
	 */
	<T> T load(Class<T> entityName, Serializable id);

	/**
	 * Return all persistent instances of the given entity class
	 * 
	 * @param entityName
	 *            - a persistent class
	 * @return - a {@link List} containing 0 or more persistent instances
	 */
	<T> List<T> loadAll(Class<T> entityName);
	
	/**
	 * Return all persistent instances of the given Named Query
	 * 
	 * @param queryName
	 *            - Named query
	 * @return - a {@link List} containing 0 or more persistent instances
	 */
	<T> List<T> loadAllByNamedQuery(String queryName);

	/**
	 * Persist the given transient instance
	 * 
	 * @param entity
	 *            - the transient instance to persist
	 * @return - the generated identifier
	 */
	<T> Serializable save(T entity);
	
	/**
	 * Save or update  given persistent instances, according to its id
	 * (matching the configured "unsaved-value"?)
	 * 
	 * @param entities
	 *            - the persistent instances to save or update
	 */
	<T> void saveOrUpdate(T entity);

	/**
	 * Save or update all given persistent instances, according to its id
	 * (matching the configured "unsaved-value"?)
	 * 
	 * @param entities
	 *            - the persistent instances to save or update
	 */
	<E> void saveOrUpdateAll(Collection<E> entities);

	/**
	 * Update the given persistent instance, associating it with the current
	 * Hibernate Session.
	 * 
	 * @param entity
	 *            - the persistent instance to update
	 */
	<T> void update(T entity);

	/**
	 * Delete the given persistent instance.
	 * 
	 * @param entity
	 *            - the persistent instance to delete
	 */
	<T> void delete(T entity);

	/**
	 * Delete all given persistent instances.
	 * 
	 * @param entities
	 *            - the persistent instances to delete
	 */
	<E> void deleteAll(Collection<E> entities);

	/**
	 * Copy the state of the given object onto the persistent object with the
	 * same identifier.</BR>Similar to saveOrUpdate, but never associates the
	 * given object with the current Hibernate Session. In case of a new entity,
	 * the state will be copied over as well.
	 * 
	 * @param entity
	 *            - the object to merge with the corresponding persistence
	 *            instance
	 * @return - the updated, registered persistent instance
	 */
	<T> T merge(T entity);

	/**
	 * Create a new Criteria instance, for the given entity name
	 * 
	 * @param entityName
	 *            - a persistent class
	 * @return -{@link DetachedCriteria} the detached Hibernate criteria object
	 */
	<T> DetachedCriteria createCriteria(Class<T> entityName);
	
	<T> Criteria createNormalCriteria(Class<T> entityName);
	
	
	/**
	 * Create a new Criteria instance, for the given entity name and alias
	 * 
	 * @param entityName
	 *            - a persistent class
	 * @param alias
	 * @return -{@link DetachedCriteria} the detached Hibernate criteria object
	 */
	<T> DetachedCriteria createCriteria(Class<T> entityName, String alias);
	
	<T> Criteria createNormalCriteria(Class<T> entityName, String alias);

	/**
	 * Execute a query based on a given Hibernate criteria object.
	 * 
	 * @param criteria
	 *            - the detached Hibernate criteria object
	 * @return - a {@link List} containing 0 or more persistent instances
	 */
	List<?> find(DetachedCriteria criteria);

	/**
	 * Execute an HQL query, binding a number of values to "?" parameters in the
	 * query string.
	 * 
	 * @param query
	 *            - a query expressed in Hibernate's query language
	 * @param values
	 *            - the values of the parameters
	 * @return - a {@link List} containing the results of the query execution
	 */
	List<?> find(String query, Object... values);
	
	/**
	 * Execute an HQL query (Update statement), binding a number of values to
	 * "?" parameters in the query string.
	 * 
	 * @param hqlString
	 *            - a query expressed in Hibernate's query language
	 * @param values
	 *            - the values of the parameters
	 */
	void bulkUpdate(String query, Object... values);
	
	/**
	 * Execute an HQL query (Update statement)
	 * 
	 * @param hqlString
	 *            - a query expressed in Hibernate's query language
	 */
	void bulkUpdate(String hqlString);
	
	/**Execute a SQL query 
	 * @param <T>
	 * 
	 * 
	 * @param query {@link String}
	 */
	<T> List<T> executeNativeSql(String query,Class<T> classType,final Object... values);
	/**Execute SQL query and return void
	 * 
	 * @param query
	 * @param values
	 */
	void executeNativeSqlNoReturn(String query,final Object... values);
	
	/**
	 * Execute procedure and return data
	 * 
	 * @param sql
	 *            - sql query to execute procedure. Format CALL
	 *            procName(:procVariable1,:procVariable2)
	 * @param parameterMap
	 *            - {@link List} parameters to be passed to procedure.
	 * @throws SQLException
	 */
	void executeProcedureNoReturn(final String sql, List<Object> parameterList)
			throws SQLException;

	/**
	 * Limit the result 
	 * @param criteria
	 * @param firstResult
	 * @param maxResults
	 * @return
	 */
	List<?> findByCriteria(DetachedCriteria criteria, int firstResult,
			int maxResults);
	
	/*
	 * Execute an HQL query, binding a number of values to ":" named parameters in the query string.
	 */
	List<?> findByNamedParam(String queryString, String[] paramNames, Object[] values);


  public SessionFactory getFactory();
  
  public String executeStoredProcedure(String storedProcSchema, String storedProcName,
			String inputParamsCount, List<String> inputParamsList);
  
  public List executeStoredProcedureReturnList(String storedProcSchema, String storedProcName,
			String inputParamsCount, List<String> inputParamsList);

  Session getSession();

  List<?> executeNativeSql(String query, Object[] values);

public HibernateTemplate getHibernateTemplate();	

   public Object get(String entityName, Serializable id);
}