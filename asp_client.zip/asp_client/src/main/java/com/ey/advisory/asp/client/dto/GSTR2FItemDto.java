package com.ey.advisory.asp.client.dto;

import com.google.gson.annotations.SerializedName;

/**
 * This is GSTR2F Item DTO.
 * 
 * @author Prakash.Naik
 *
 */
public class GSTR2FItemDto {

	@SerializedName("LineNo2A")
	private Double lineNo2A;
	
	@SerializedName("LineNoPR")
	private Double lineNoPR;


	@SerializedName("Rt2A")
	private Double rate2A;
	
	@SerializedName("RtPR")
	private Double ratePR;
	
	@SerializedName("TaxableValue2A")
	private Double taxableValue2A;

	@SerializedName("TaxableValuePR")
	private Double taxableValuePR;

	@SerializedName("IGSTAmt2A")
	private Double iGSTAmt2A;
	
	@SerializedName("IGSTAmtPR")
	private Double iGSTAmtPR;

	@SerializedName("CGSTAmt2A")
	private Double cGSTAmt2A;
	
	@SerializedName("CGSTAmtPR")
	private Double cGSTAmtPR;

	@SerializedName("SGSTAmt2A")
	private Double sGSTAmt2A;
	
	@SerializedName("SGSTAmtPR")
	private Double sGSTAmtPR;

	@SerializedName("CessAmt2A")
	private Double cessAmt2A;
	
	@SerializedName("CessAmtPR")
	private Double cessAmtPR;

	public Double getLineNoPR() {
		return lineNoPR;
	}

	public void setLineNoPR(Double lineNoPR) {
		this.lineNoPR = lineNoPR;
	}

	public Double getLineNo2A() {
		return lineNo2A;
	}

	public void setLineNo2A(Double lineNo2A) {
		this.lineNo2A = lineNo2A;
	}

	public Double getTaxableValue2A() {
		return taxableValue2A;
	}

	public void setTaxableValue2A(Double taxableValue2A) {
		this.taxableValue2A = taxableValue2A;
	}

	public Double getTaxableValuePR() {
		return taxableValuePR;
	}

	public void setTaxableValuePR(Double taxableValuePR) {
		this.taxableValuePR = taxableValuePR;
	}

	public Double getRatePR() {
		return ratePR;
	}

	public void setRatePR(Double ratePR) {
		this.ratePR = ratePR;
	}

	public Double getRate2A() {
		return rate2A;
	}

	public void setRate2A(Double rate2a) {
		rate2A = rate2a;
	}

	public Double getiGSTAmtPR() {
		return iGSTAmtPR;
	}

	public void setiGSTAmtPR(Double iGSTAmtPR) {
		this.iGSTAmtPR = iGSTAmtPR;
	}

	public Double getiGSTAmt2A() {
		return iGSTAmt2A;
	}

	public void setiGSTAmt2A(Double iGSTAmt2A) {
		this.iGSTAmt2A = iGSTAmt2A;
	}

	public Double getcGSTAmtPR() {
		return cGSTAmtPR;
	}

	public void setcGSTAmtPR(Double cGSTAmtPR) {
		this.cGSTAmtPR = cGSTAmtPR;
	}

	public Double getcGSTAmt2A() {
		return cGSTAmt2A;
	}

	public void setcGSTAmt2A(Double cGSTAmt2A) {
		this.cGSTAmt2A = cGSTAmt2A;
	}

	public Double getsGSTAmtPR() {
		return sGSTAmtPR;
	}

	public void setsGSTAmtPR(Double sGSTAmtPR) {
		this.sGSTAmtPR = sGSTAmtPR;
	}

	public Double getsGSTAmt2A() {
		return sGSTAmt2A;
	}

	public void setsGSTAmt2A(Double sGSTAmt2A) {
		this.sGSTAmt2A = sGSTAmt2A;
	}

	public Double getCessAmtPR() {
		return cessAmtPR;
	}

	public void setCessAmtPR(Double cessAmtPR) {
		this.cessAmtPR = cessAmtPR;
	}

	public Double getCessAmt2A() {
		return cessAmt2A;
	}

	public void setCessAmt2A(Double cessAmt2A) {
		this.cessAmt2A = cessAmt2A;
	}

}
