package com.ey.advisory.asp.client.dto;

import java.math.BigDecimal;

public class LfeeoffsetDto {
	
	private BigDecimal c_pdlfee;
	private BigDecimal s_pdlfee;
	
	public BigDecimal getC_pdlfee() {
		return c_pdlfee;
	}
	public void setC_pdlfee(BigDecimal c_pdlfee) {
		this.c_pdlfee = c_pdlfee;
	}
	public BigDecimal getS_pdlfee() {
		return s_pdlfee;
	}
	public void setS_pdlfee(BigDecimal s_pdlfee) {
		this.s_pdlfee = s_pdlfee;
	}
	
}
