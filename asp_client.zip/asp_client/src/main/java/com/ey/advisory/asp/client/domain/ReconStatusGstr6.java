package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="tblReconStatus", schema="gstr6")
public class ReconStatusGstr6 implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer id;
	
	@Column(name = "GSTIN")
	private String gstin;
	
	@Column(name = "TaxPeriod")
	private String taxPeriod;

	@Column(name = "ReconStatus")
	private String reconStatus;
	
	@Column(name = "ReconCompleteDate")
	private Date reconCompleteDate;
	
	@Column(name = "CreatedDate")
	private Date createdDate;
	
	@Column(name = "IsActive")
	private Boolean isActive;
	
	@Column(name = "MasterID")
	private Integer masterId;
	
	@Column(name = "isMatchedGenerated")
	private String isMatchedGenerated;
	
	@Column(name = "isMisMatchedGenerated")
	private String isMisMatchedGenerated;
	
	@Column(name = "isMatchedASPGenerated")
	private String isMatchedASPGenerated;
	
	@Column(name = "isAdditionalGenerated")
	private String isAdditionalGenerated;
	
	@Column(name = "isMissingGenerated")
	private String isMissingGenerated;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getReconStatus() {
		return reconStatus;
	}

	public void setReconStatus(String reconStatus) {
		this.reconStatus = reconStatus;
	}

	public Date getReconCompleteDate() {
		return reconCompleteDate;
	}

	public void setReconCompleteDate(Date reconCompleteDate) {
		this.reconCompleteDate = reconCompleteDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getMasterId() {
		return masterId;
	}

	public void setMasterId(Integer masterId) {
		this.masterId = masterId;
	}

	public String getIsMatchedGenerated() {
		return isMatchedGenerated;
	}

	public void setIsMatchedGenerated(String isMatchedGenerated) {
		this.isMatchedGenerated = isMatchedGenerated;
	}

	public String getIsMisMatchedGenerated() {
		return isMisMatchedGenerated;
	}

	public void setIsMisMatchedGenerated(String isMisMatchedGenerated) {
		this.isMisMatchedGenerated = isMisMatchedGenerated;
	}

	public String getIsMatchedASPGenerated() {
		return isMatchedASPGenerated;
	}

	public void setIsMatchedASPGenerated(String isMatchedASPGenerated) {
		this.isMatchedASPGenerated = isMatchedASPGenerated;
	}

	public String getIsAdditionalGenerated() {
		return isAdditionalGenerated;
	}

	public void setIsAdditionalGenerated(String isAdditionalGenerated) {
		this.isAdditionalGenerated = isAdditionalGenerated;
	}

	public String getIsMissingGenerated() {
		return isMissingGenerated;
	}

	public void setIsMissingGenerated(String isMissingGenerated) {
		this.isMissingGenerated = isMissingGenerated;
	}

	
}
