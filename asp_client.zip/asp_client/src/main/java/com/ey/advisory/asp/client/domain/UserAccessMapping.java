/**
 * 
 */
package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Nitesh.Tripathi
 *
 */
@Entity
@Table(name = "tblUserAccessMapping", schema="master")
public class UserAccessMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="userAccessID",nullable =false)
	private Integer userAccessID;
	
	@Column(name="userID")
    private Integer userID;
	
	@Column(name="accessLevel")
    private String accessLevel;
	
	@Column(name="accessValue")
    private String accessValue;
    
	/**
	 * @return the userAccessID
	 */
	public Integer getUserAccessID() {
		return userAccessID;
	}
	/**
	 * @return the userID
	 */
	public Integer getUserID() {
		return userID;
	}
	/**
	 * @return the accessLevel
	 */
	public String getAccessLevel() {
		return accessLevel;
	}
	/**
	 * @return the accessValue
	 */
	public String getAccessValue() {
		return accessValue;
	}
	/**
	 * @param userAccessID the userAccessID to set
	 */
	public void setUserAccessID(Integer userAccessID) {
		this.userAccessID = userAccessID;
	}
	/**
	 * @param userID the userID to set
	 */
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	/**
	 * @param accessLevel the accessLevel to set
	 */
	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}
	/**
	 * @param accessValue the accessValue to set
	 */
	public void setAccessValue(String accessValue) {
		this.accessValue = accessValue;
	}
	
}
