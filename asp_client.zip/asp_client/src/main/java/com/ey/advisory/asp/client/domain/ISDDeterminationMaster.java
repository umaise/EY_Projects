package com.ey.advisory.asp.client.domain;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblISDDeterminationMaster",schema="gstr6")
public class ISDDeterminationMaster implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "ISDGSTIN")
	private String isdgstin;
	
	@Column(name = "TaxPeriod")
	private String taxPeriod;
	
	@Column(name = "IsDistribuited")
	private String isDistribuited;
	
	@Column(name = "CreatedDate")
	private String createdDate;
	
	@Column(name = "CreatedBy")
	private String createdBy;
	
	@Column(name = "DistributedDate")
	private String distributedDate;
	
	@Column(name = "IsFinalupload")
	private String isFinalupload;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIsdgstin() {
		return isdgstin;
	}

	public void setIsdgstin(String isdgstin) {
		this.isdgstin = isdgstin;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getIsDistribuited() {
		return isDistribuited;
	}

	public void setIsDistribuited(String isDistribuited) {
		this.isDistribuited = isDistribuited;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getDistributedDate() {
		return distributedDate;
	}

	public void setDistributedDate(String distributedDate) {
		this.distributedDate = distributedDate;
	}

	public String getIsFinalupload() {
		return isFinalupload;
	}

	public void setIsFinalupload(String isFinalupload) {
		this.isFinalupload = isFinalupload;
	}
	
	
}
