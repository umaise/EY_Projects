package com.ey.advisory.asp.client.service;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ey.advisory.asp.client.dao.SmartReportStatusDao;
import com.ey.advisory.asp.client.domain.SmartReport;
import com.ey.advisory.asp.common.Constant;

@Service("SmartReportStatusService")
public class SmartReportStatusServiceImpl implements SmartReportStatusService{

	@Autowired
	private SmartReportStatusDao smartReportStatusDao;

	private static final Logger logger = Logger.getLogger(SmartReportStatusServiceImpl.class);
	private static final String CLASS_NAME = SmartReportStatusServiceImpl.class.getName();

	@Override
	public List<SmartReport> getSmartReportData(int offset,int pageSize) {
		List<SmartReport> reportList = null;
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getSmartReportData");
		}
		try{
			reportList = smartReportStatusDao.getSmartReportData(offset, pageSize);
		}
		catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getSmartReportData",e);
		}

		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getSmartReportData");
		}
		return reportList;
	}

	@Override
	public List<SmartReport> getSearchSmartReportData(String requestId, String fileCategory,int offset,int pageSize) {
		List<SmartReport> reportList = null;
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getSearchSmartReportData : Params : requestId "+requestId+" fileCategory "+fileCategory);
		}
		try{
			reportList = smartReportStatusDao.getSearchSmartReportData(requestId, fileCategory, offset, pageSize);

		}
		catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getSearchSmartReportData",e);
		}

		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getSearchSmartReportData");
		}
		return reportList;
	}

	@Override
	public void updateCancelStatus(String requestId, String fileCategory) {
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : updateCancelStatus : Params : requestId "+requestId+" fileCategory "+fileCategory);
		}
		try{
			smartReportStatusDao.updateCancelStatus(requestId, fileCategory);

		}
		catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : updateCancelStatus",e);
		}

		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : updateCancelStatus");
		}

	}

	@Override
	public SmartReport getFileDetails(String requestId, String fileCategory) {
		SmartReport reportDetails = null;
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getFileDetails : Params : requestId "+requestId+" fileCategory "+fileCategory);
		}
		try{
			reportDetails = smartReportStatusDao.getFileDetails(requestId, fileCategory);

		}
		catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getFileDetails",e);
		}

		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getFileDetails");
		}
		return reportDetails;
	}

}
