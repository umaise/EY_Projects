package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import org.apache.log4j.Logger;

public class ReconProcessDTO implements Serializable {
	private static final long serialVersionUID = -5474991123453046027L;
	private static final Logger LOGGER = Logger.getLogger(ReconProcessDTO.class);
	
	private int id;
	private Double itemTxVal;
	private Double igstAmt;
	private Double cgstAmt;
	private Double sgstAmt;
	private Double cessAmt;
	
	public ReconProcessDTO(){
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in ReconProcessDTO ");
			}
	}
	
	public ReconProcessDTO(ReconciliationDetailsDTO reconDet) {
		if(reconDet != null){
			this.id = reconDet.getId();
			this.itemTxVal = reconDet.getItemTxVal();
			this.igstAmt = reconDet.getIgstAmt();
			this.cgstAmt = reconDet.getCgstAmt();
			this.sgstAmt = reconDet.getSgstAmt();
			this.cessAmt = reconDet.getCessAmt();
		}
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Double getItemTxVal() {
		return itemTxVal;
	}
	public void setItemTxVal(Double itemTxVal) {
		this.itemTxVal = itemTxVal;
	}
	public Double getIgstAmt() {
		return igstAmt;
	}
	public void setIgstAmt(Double igstAmt) {
		this.igstAmt = igstAmt;
	}
	public Double getCgstAmt() {
		return cgstAmt;
	}
	public void setCgstAmt(Double cgstAmt) {
		this.cgstAmt = cgstAmt;
	}
	public Double getSgstAmt() {
		return sgstAmt;
	}
	public void setSgstAmt(Double sgstAmt) {
		this.sgstAmt = sgstAmt;
	}
	public Double getCessAmt() {
		return cessAmt;
	}
	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}

}
