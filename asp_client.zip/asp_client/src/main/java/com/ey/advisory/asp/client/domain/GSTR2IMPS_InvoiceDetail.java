package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;


/**
 * The persistent class for the tblIMPSInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblIMPSInvoiceDetails", schema=Constant.GSTR2_SCHEMA)
public class GSTR2IMPS_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR2IMPS_InvoiceDetail.class);

	@Id
	@Column(name="ID")
	private long id;

	@Column(name="Chksum")
	private String chksum;

	@Column(name="FileId")
	private long fileId;

	@Column(name="Flag")
	private String flag;

	@Column(name="Gstin")
	private String gstin;

	@Column(name="InvDt")
	private Date invDt;

	@Column(name="InvNum")
	private String invNum;

	@Column(name="InvVal")
	private BigDecimal invVal;

	@Column(name="TaxableValue")
	private BigDecimal taxableValue;

	@Column(name="TaxPeriod")
	private String taxPeriod;

	public GSTR2IMPS_InvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR2IMPS_InvoiceDetail ");
			}
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getChksum() {
		return this.chksum;
	}

	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	public long getFileId() {
		return this.fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Date getInvDt() {
		return this.invDt;
	}

	public void setInvDt(Date invDt) {
		this.invDt = invDt;
	}

	public String getInvNum() {
		return this.invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public BigDecimal getInvVal() {
		return this.invVal;
	}

	public void setInvVal(BigDecimal invVal) {
		this.invVal = invVal;
	}

	public BigDecimal getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(BigDecimal taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

}