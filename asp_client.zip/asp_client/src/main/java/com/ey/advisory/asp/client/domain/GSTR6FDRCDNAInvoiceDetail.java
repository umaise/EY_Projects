package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.ey.advisory.asp.common.Constant;


/**
 * The persistent class for the tblCDNAInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblDRCDNAInvoiceDetails", schema=Constant.GSTR6F_SCHEMA)
public class GSTR6FDRCDNAInvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private Long id;

	@Column(name="SrNo")
	private Long srNo;

	@Column(name="ISDRegisteredGSTIN")
	private String isdRegisteredGSTIN;

	@Column(name="GSTINofSupplier")
	private String gstsinNofSupplier;

	@Column(name="DocumentType")
	private String docType;

	@Column(name="DocumentNo")
	private String docNo;

	@Column(name="DocumentDate")
	private Date docDate;

	@Column(name="SAC")
	private String sac;

	@Column(name="GSTINofReceiver")
	private String gstinOfReceiver;

	@Column(name="ISDInvoicesDocumentNo")
	private String isdInvoices_DocNo;

	@Column(name="ISDInvoiceDate")
	private Date isdInvoiceDate;

	@Column(name="IGST")
    private Double igst;

	@Column(name="CGST")
	private Double cgst;

	@Column(name="SGSTUTGST")
	private Double sgst_UTGST;

	@Column(name="CESS")
	private Double cess;

	@Column(name="ItcIGST")
	private Double itcIGST;

	@Column(name="ItcCGST")
	private Double itcCGST;

	@Column(name="ItcSGSTUTGST")
	private Double itcSGST_UTGST;

	@Column(name="ItcCESS")
	private Double itcCESS;

	@Column(name="fileID")
	private Long fileID;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSrNo() {
		return srNo;
	}

	public void setSrNo(Long srNo) {
		this.srNo = srNo;
	}

	public String getIsdRegisteredGSTIN() {
		return isdRegisteredGSTIN;
	}

	public void setIsdRegisteredGSTIN(String isdRegisteredGSTIN) {
		this.isdRegisteredGSTIN = isdRegisteredGSTIN;
	}

	public String getGstsinNofSupplier() {
		return gstsinNofSupplier;
	}

	public void setGstsinNofSupplier(String gstsinNofSupplier) {
		this.gstsinNofSupplier = gstsinNofSupplier;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocNo() {
		return docNo;
	}

	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}

	public Date getDocDate() {
		return docDate;
	}

	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}

	public String getSac() {
		return sac;
	}

	public void setSac(String sac) {
		this.sac = sac;
	}

	public String getGstinOfReceiver() {
		return gstinOfReceiver;
	}

	public void setGstinOfReceiver(String gstinOfReceiver) {
		this.gstinOfReceiver = gstinOfReceiver;
	}

	public String getIsdInvoices_DocNo() {
		return isdInvoices_DocNo;
	}

	public void setIsdInvoices_DocNo(String isdInvoices_DocNo) {
		this.isdInvoices_DocNo = isdInvoices_DocNo;
	}

	public Date getIsdInvoiceDate() {
		return isdInvoiceDate;
	}

	public void setIsdInvoiceDate(Date isdInvoiceDate) {
		this.isdInvoiceDate = isdInvoiceDate;
	}

	public Double getIgst() {
		return igst;
	}

	public void setIgst(Double igst) {
		this.igst = igst;
	}

	public Double getCgst() {
		return cgst;
	}

	public void setCgst(Double cgst) {
		this.cgst = cgst;
	}

	public Double getSgst_UTGST() {
		return sgst_UTGST;
	}

	public void setSgst_UTGST(Double sgst_UTGST) {
		this.sgst_UTGST = sgst_UTGST;
	}

	public Double getCess() {
		return cess;
	}

	public void setCess(Double cess) {
		this.cess = cess;
	}

	public Double getItcIGST() {
		return itcIGST;
	}

	public void setItcIGST(Double itcIGST) {
		this.itcIGST = itcIGST;
	}

	public Double getItcCGST() {
		return itcCGST;
	}

	public void setItcCGST(Double itcCGST) {
		this.itcCGST = itcCGST;
	}

	public Double getItcSGST_UTGST() {
		return itcSGST_UTGST;
	}

	public void setItcSGST_UTGST(Double itcSGST_UTGST) {
		this.itcSGST_UTGST = itcSGST_UTGST;
	}

	public Double getItcCESS() {
		return itcCESS;
	}

	public void setItcCESS(Double itcCESS) {
		this.itcCESS = itcCESS;
	}

	public Long getFileID() {
		return fileID;
	}

	public void setFileID(Long fileID) {
		this.fileID = fileID;
	}
	
	
	
}