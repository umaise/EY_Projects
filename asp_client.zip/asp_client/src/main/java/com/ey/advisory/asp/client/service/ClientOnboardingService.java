package com.ey.advisory.asp.client.service;

import java.sql.SQLDataException;
import java.util.List;

import com.ey.advisory.asp.client.domain.ClientDraftData;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.dto.OnBoardDto;


public interface ClientOnboardingService {

 	String saveOnboardClientData(OnBoardDto onBoardDto) throws SQLDataException;
 	
 	String saveOnBoardDraftData(OnBoardDto onBoardDto);
 	
 	String fetchOnBoardingDraftData(ClientDraftData draftObj);
 	
 	String deleteDraftData(Integer draftID) throws SQLDataException;
 	
 	String deleteDraftData (Integer draftID, Long userID) throws SQLDataException;

	List<Object[]> getHierarchyCode(EntityHierarchy entityHierarchy);

	List<Long> findAllL1Users();
	
	String fetchAuthorizedSignatureGstins(Long userId);

}
