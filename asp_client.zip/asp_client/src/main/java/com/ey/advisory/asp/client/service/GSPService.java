package com.ey.advisory.asp.client.service;

import javax.servlet.http.HttpServletRequest;



 
@FunctionalInterface
public interface GSPService {
	
	String registerASP(String emailAdress, String orgName,HttpServletRequest request);

}
