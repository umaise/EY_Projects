package com.ey.advisory.asp.client.service;

import java.sql.SQLDataException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.ClientDraftDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.ClientCommunication;
import com.ey.advisory.asp.client.domain.ClientDraftData;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.QuestionAnswerMapping;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.domain.TblGstinFinancialDetails;
import com.ey.advisory.asp.client.domain.UserAccessMapping;
import com.ey.advisory.asp.client.domain.UserClient;
import com.ey.advisory.asp.client.dto.OnBoardDto;
import com.ey.advisory.asp.common.Constant;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.ProjectionList;

@Service
@Transactional
public class ClientOnboardingServiceImpl implements ClientOnboardingService {

	@Autowired
	HibernateDao hibernateDao;
	
	@Autowired
	ClientDraftDao clientDraftdao;
	
	private static final Logger LOGGER = Logger.getLogger(ClientOnboardingServiceImpl.class);
	
	@Override
	public String saveOnboardClientData(OnBoardDto onBoardDto) throws SQLDataException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering method saveOnboardClientData() of class ClientOnboardingServiceImpl ");
		}
		
		String response="FAILED";
		Map<String,UserClient> userMap;
		int submitStage=0;
		try
		{
			String groupCode = null,freq=null;
			EntityModel clientEntity=onBoardDto.getClientEntity();
			clientEntity.setCreatedDate(new Date());
			//checkIfEntityAlreadyExists(clientEntity.getEntityName());
			Integer ID=(Integer) hibernateDao.save(clientEntity);
			if(ID!=null)
			{
				String entityCode=clientDraftdao.getEntityCode(ID);
				clientEntity.setEntityCode(entityCode);
				clientEntity.setEntityID(ID);
		
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("Client Entity saved successfully" );
				LOGGER.info("Entity ID= "+clientEntity.getEntityID());
				}
				
				List<TblGstinDetailsDomain> gstinDomainList = onBoardDto.getClientGstinList();
				if(gstinDomainList!=null && !gstinDomainList.isEmpty())
				{
					List<TblGstinFinancialDetails> financeDetailsList=new ArrayList<>();
					for(TblGstinDetailsDomain gstinObj : gstinDomainList)
		            {
		                gstinObj.setEntityID(clientEntity.getEntityID());
		                gstinObj.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		                gstinObj.setIsActive(Boolean.TRUE);
		                gstinObj.setIsRegCertificate(Boolean.TRUE);
		                
		                financeDetailsList.add(new TblGstinFinancialDetails
		                		(gstinObj.getGstinId(), gstinObj.getQuarterTurnOvrAmt()));
		            }
					hibernateDao.saveOrUpdateAll(gstinDomainList);
					if(LOGGER.isInfoEnabled()){
						LOGGER.info("gstinDetails saved successfully" );
					}
					hibernateDao.saveOrUpdateAll(financeDetailsList);
					if(LOGGER.isInfoEnabled()){
						LOGGER.info("gstinFinancialDetails saved successfully" );
					}
				}
				
				List<EntityHierarchy> entityHierarchyList = onBoardDto.getHierarchyList();
				if(entityHierarchyList!=null && !entityHierarchyList.isEmpty())
				{
					for (EntityHierarchy hObj : entityHierarchyList) {
						groupCode=hObj.getGroupCode();
						hObj.setGroupID(clientEntity.getGroupId());
						hObj.setEntityID(clientEntity.getEntityID());
						hObj.setEntityName(clientEntity.getEntityName());
						hObj.setEntityCode(clientEntity.getEntityCode());
						hObj.setIsActive("1");
						hObj.setCreatedDate(new Date());
					}
					hibernateDao.saveOrUpdateAll(entityHierarchyList);
					if(LOGGER.isInfoEnabled()){
						LOGGER.info("EntityHierarchy saved successfully" );
					}
					
				}
				userMap=new HashMap<>();
				List<UserAccessMapping> userAccessMappingList = new ArrayList<>();
				List<EntityHierarchy> entityHierarchyList1 = getListFromDB(entityHierarchyList);
				for(UserClient clientUser:onBoardDto.getClientUser())
				{
					userMap.put(clientUser.getEmail(), clientUser);
					for(String accessValue : clientUser.getAccessValues())
					{
						UserAccessMapping accessMapping=new UserAccessMapping();
						accessMapping.setUserID(clientUser.getUserId());
						accessMapping.setAccessLevel(clientUser.getAccessLevel());
						accessMapping.setAccessValue(getAccessValue(clientUser.getAccessLevel(),accessValue,entityHierarchyList1,groupCode,entityCode));
						userAccessMappingList.add(accessMapping);
					}
				}
				hibernateDao.saveOrUpdateAll(userAccessMappingList);
				if(LOGGER.isInfoEnabled()){
					LOGGER.info("UserAccessMapping saved successfully" );
				}
				
				List<QuestionAnswerMapping> questionAnswerList  = onBoardDto.getQuestionAnswerList();
				if(questionAnswerList!=null && !questionAnswerList.isEmpty())
	            {	
	                for (QuestionAnswerMapping questionAnswerMapping : questionAnswerList) {
	                        questionAnswerMapping.setEntityID(clientEntity.getEntityID());
	                        questionAnswerMapping.setIsDeleted(Boolean.FALSE);
	                        questionAnswerMapping.setUpdatedDate(new Date());
	                        questionAnswerMapping.setCreatedDate(new Date());
	                        
	                        if(questionAnswerMapping.getQuestionID().equals(Constant.QUES_SAVE_FREQ_ID))
	                        {
	                        	String ansId=questionAnswerMapping.getAnswerID();
	                        	switch(ansId)
	                        	{
	                        	case "1":
	                        		freq=Constant.ANS_FREQ_ID_1;
	                        		break;
	                        	case "2":
	                        		freq=Constant.ANS_FREQ_ID_2;
	                        		break;
	                        	case "3":
	                        		freq=Constant.ANS_FREQ_ID_3;
	                        		break;
	                        	case "4":
	                        		freq=Constant.ANS_FREQ_ID_4;
	                        		break;
	                        	default:
	                                break;
	                        	}
	                        }
	                }
	                hibernateDao.saveOrUpdateAll(questionAnswerList);
	                if(LOGGER.isInfoEnabled()){
						LOGGER.info("Question Answer Entity saved successfully" );
						LOGGER.info("Entity ID= "+clientEntity.getEntityID());
				    }
		     	}
	            submitStage=1;
				if(onBoardDto.getCustomerMasterList()!=null && !onBoardDto.getCustomerMasterList().isEmpty())
	            {
	                hibernateDao.saveOrUpdateAll(onBoardDto.getCustomerMasterList());
	                submitStage=2;
	            }
		
				if(onBoardDto.getVendorMasterList()!=null && !onBoardDto.getVendorMasterList().isEmpty())
	            {
	                hibernateDao.saveOrUpdateAll(onBoardDto.getVendorMasterList());
	                submitStage=3;
	            }
	            
	            if(onBoardDto.getItemMasterList()!=null && !onBoardDto.getItemMasterList().isEmpty())
	            {
	                hibernateDao.saveOrUpdateAll(onBoardDto.getItemMasterList());
	                submitStage=4;
	            }
	            
				if(onBoardDto.getProductMasterList()!=null && !onBoardDto.getProductMasterList().isEmpty()){
	                hibernateDao.saveOrUpdateAll(onBoardDto.getProductMasterList());
	                submitStage=5;
	            }
			
				Map<String,Long> userIdL1Map = onBoardDto.getUserIdL1Map();
				
				
				List<ClientCommunication> clientCommunicationList = onBoardDto.getCommunicationList();
				if(clientCommunicationList!=null && !clientCommunicationList.isEmpty())
				{
					Integer authUserId,authSUserId,contactSUserId;
					for (ClientCommunication comm : clientCommunicationList) {
							authUserId = userMap.get(comm.getPrimaryAuthUserName())==null?userIdL1Map.get(comm.getPrimaryAuthUserName()).intValue():userMap.get(comm.getPrimaryAuthUserName()).getUserId();
							comm.setpAuthUserId(authUserId);
							if(userMap.get(comm.getSecondaryAuthUserName())!=null){
								authSUserId = userMap.get(comm.getSecondaryAuthUserName()).getUserId();
							}else if(userIdL1Map.get(comm.getSecondaryAuthUserName())!=null){
								authSUserId = userIdL1Map.get(comm.getSecondaryAuthUserName()).intValue();
							}else{
								authSUserId = null;
							}
							comm.setsAuthUserId(authSUserId);
							comm.setpContactUserId(userMap.get(comm.getPrimaryContact()).getUserId());
							contactSUserId=userMap.get(comm.getSecondaryContact())==null?null:userMap.get(comm.getSecondaryContact()).getUserId();
							comm.setsContactUserId(contactSUserId);
					}
					hibernateDao.saveOrUpdateAll(clientCommunicationList);
					submitStage=6;
				}
				
				if(LOGGER.isInfoEnabled()){
	            LOGGER.info("GSTIN Entity saved successfully" );
				LOGGER.info("AccessMapping saved successfully" );
				LOGGER.info("Deleteing draftRow , draftID=" + onBoardDto.getDraftId());
				}
				
				//deleteDraftData(onBoardDto.getDraftId());
				deleteDraftData(onBoardDto.getDraftId(), onBoardDto.getUserID());
				LOGGER.info("Deleted Successfully");
				submitStage=8;
				LOGGER.info("Preparing json for setClientDatauploadFrequency()" );
				
				JsonObject jObj=new JsonObject();
				jObj.addProperty("groupCode",groupCode);
				jObj.addProperty("triggerFrequency",freq);
				jObj.addProperty("entityId",String.valueOf(ID));
				jObj.addProperty("entityCode",String.valueOf(entityCode));
				jObj.addProperty("jobName","scheduleSimpleTriggerwithETAJob");
				
				String jobJson=jObj.toString();
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("JobJSON= "+jobJson);
				}
				response="SUCC;"+jobJson;
			}
		}catch(SQLDataException e){
			LOGGER.error("Error while deleteing draft data" + e);
			response="FAILED"+submitStage;
		}
		catch(Exception e)
		{
			LOGGER.error("Error while saving clentdata=>" + e);
			response="FAILED"+submitStage;
		}
		return response;
	}

	private void checkIfEntityAlreadyExists(String entityName) throws Exception {
		List<EntityModel> entityModelList=null;
		try {
			 DetachedCriteria criteria = hibernateDao.createCriteria(EntityModel.class);
			 criteria.add(Restrictions.eq("entityName",entityName));
			 entityModelList = (List<EntityModel>)hibernateDao.find(criteria);
		} catch (Exception e) {
			LOGGER.error("Exception in checkIfEntityAlreadyExists"+e);
		}
		if(entityModelList!=null && entityModelList.size()>0){
			throw new Exception();
		}
	}

	private String getAccessValue(String accessLevel,String accessValue, List<EntityHierarchy> entityHierarchyList,String groupCode,String entityCode) {
		String dataAccessLevelValue="";
		List<Object[]> resultList ;
		switch(accessLevel.trim()){
		case "L1":
			dataAccessLevelValue = groupCode;
			break;
		case "L2":
			dataAccessLevelValue = entityCode;
			break;
			 case "L3A":
				 for(EntityHierarchy  entity:entityHierarchyList){
	                 if(entity.getCircleName() != null && entity.getCircleName().equalsIgnoreCase(accessValue)){
	                	 resultList = getHierarchyCode(entity);
	                	 dataAccessLevelValue = String.valueOf(resultList.get(0)[0]);
	                	 break;
	                 }
			 	}
				 break;
			 case "L3B":
				 dataAccessLevelValue = accessValue;
				 break;
			 case "L4A":
				 for(EntityHierarchy  entity:entityHierarchyList){
	                 if(entity.getSubDivName() != null && entity.getSubDivName().equalsIgnoreCase(accessValue)){
	                	 resultList = getHierarchyCode(entity);
	                	 dataAccessLevelValue = String.valueOf(resultList.get(0)[1]);
	                	 break;
	                 }
			 	}
				 break;
			 case "L4B":
				 for(EntityHierarchy  entity:entityHierarchyList){
	                 if(entity.getProfitCenterName() != null && entity.getProfitCenterName().equalsIgnoreCase(accessValue)){
	                	 resultList = getHierarchyCode(entity);
	                	 dataAccessLevelValue = String.valueOf(resultList.get(0)[2]);
	                	 break;
	                 }
			 	}
				 break;
			 case "L4C":
				 for(EntityHierarchy  entity:entityHierarchyList){
	                 if(entity.getBusinessUnitName() != null && entity.getBusinessUnitName().equalsIgnoreCase(accessValue)){
	                	 resultList = getHierarchyCode(entity);
	                	 dataAccessLevelValue = String.valueOf(resultList.get(0)[3]);
	                	 break;
	                 }
			 	}
				 break;
			 case "L5":
				 dataAccessLevelValue = accessValue;
				 break;
			 default:
				 dataAccessLevelValue = accessValue;
				 break;
			 }
		return dataAccessLevelValue;
	}

	@Override
	public String saveOnBoardDraftData(OnBoardDto onBoardDto) {
		LOGGER.info("Entering method saveOnBoardDraftData() of class ClientOnboardingServiceImpl ");
		String response="";
		try
		{
			Gson gson=new Gson();
			String onBoardJson=gson.toJson(onBoardDto);
			
			ClientDraftData draftdata=new ClientDraftData(onBoardDto.getUserID(),onBoardDto.getClientEntity().getGroupId(),
					onBoardDto.getClientEntity().getEntityName(),onBoardJson,new Date());
			if(onBoardDto.getDraftId()==null)
			{
				Integer draftId=(Integer) hibernateDao.save(draftdata);
				response="ID;"+draftId;
			}
			else
			{
				draftdata.setOnBoardingID(onBoardDto.getDraftId());
				hibernateDao.update(draftdata);
				response="Success";
			}
			LOGGER.info("ClientDraftData saved successfully" );
		}catch(Exception e)
		{
			LOGGER.error("Error while saving draftData=>" + e);
			response="Failed";
		}
		return response;
	}

	@Override
	public String fetchOnBoardingDraftData(ClientDraftData draftObj) {
		try
		{
			List<ClientDraftData> clientDraftList;
			if(draftObj.getOnBoardingID()==null)
			{
				clientDraftList=clientDraftdao.loadAllDraftData(draftObj);
			}else
			{
				clientDraftList=clientDraftdao.loadDraftDataByBoardingId(draftObj);
			}
			Gson gson=new Gson();
			return gson.toJson(clientDraftList);
		}catch(Exception e){
			LOGGER.error("Error in fetchOnBoardingDraftData=>" + e);
			return null;
		}
	}

	@Override
	public String deleteDraftData(Integer draftID) throws SQLDataException {
		try
		{	
			ClientDraftData draftObj=new ClientDraftData();
			draftObj.setOnBoardingID(draftID);
			hibernateDao.delete(draftObj);
			return Constant.SUCCESS;
		}catch(Exception e)
		{
			LOGGER.error("Failed deleting draft data",e);
			throw new SQLDataException("FAILED"+e.getMessage());
		}
	}
	
	@Override
	public String deleteDraftData(Integer draftID, Long userID)
			throws SQLDataException {
		try{
			ClientDraftData draftClientDraftData = hibernateDao.load(ClientDraftData.class, draftID);
			
			if(draftClientDraftData != null && draftClientDraftData.getUserID().equals(userID)){
				hibernateDao.delete(draftClientDraftData);
				return Constant.SUCCESS;
			} else {
				return Constant.FAILED;
			}
			
		}catch(Exception e){
		  LOGGER.error("Failed deleting client draft data as draft does not belongs to User", e);	
		  throw new SQLDataException("FAILED" + e.getMessage());
		}
		
	}
	
	
	private List<EntityHierarchy> getListFromDB(List<EntityHierarchy> list){
		
		 List<EntityHierarchy> ehList = new ArrayList<EntityHierarchy>();
		 for(EntityHierarchy er:list){
			 
			 EntityHierarchy ertemp = hibernateDao.load(EntityHierarchy.class, er.getHierarchyId());
			 ehList.add(ertemp);
			 
		 }
		 
		 return ehList;
		
	}
	
	
	
	@Override
	public List<Object[]> getHierarchyCode(EntityHierarchy entityHierarchy) {
		
		List<Object[]> resultList = null;
		try {
			 DetachedCriteria criteria = hibernateDao.createCriteria(EntityHierarchy.class);
			 criteria.add(Restrictions.eq("hierarchyId",entityHierarchy.getHierarchyId()));
			 criteria.setProjection(Projections.projectionList()
				        .add(Projections.property("circleCode"))
				        .add(Projections.property("subDivCode"))
				        .add(Projections.property("profitCenterCode"))
				        .add(Projections.property("businessUnitCode")));
					 
			 resultList = (List<Object[]>)hibernateDao.find(criteria);
			 if(resultList!=null && !resultList.isEmpty())
			 {
				 return resultList;
			 }
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in getHierarchyCode"+e);
		
		}
		return null; 
	}

	@Override
	public List<Long> findAllL1Users() {
		List<Long> resultList = new ArrayList<Long>();
		try {
			 DetachedCriteria criteria = hibernateDao.createCriteria(UserAccessMapping.class);
			 criteria.add(Restrictions.eq("accessLevel",Constant.L1_ACCESS_LEVEL));
			 criteria.setProjection(Projections.projectionList()
				        .add(Projections.property("userID")));
					 
			 List<Integer> resultList1 = (List<Integer>)hibernateDao.find(criteria);
			 if(resultList1!=null && !resultList1.isEmpty())
			 {
				 for(Integer result: resultList1){
					 resultList.add(Long.valueOf(result));
				 }
				 return resultList;
			 }
		} catch (Exception e) {
			LOGGER.error("Exception in findAllL1Users"+e);
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public String fetchAuthorizedSignatureGstins(Long userId) {
		String authorizedGstins = null;
		List<ClientCommunication> clientCommunications = null;
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(ClientCommunication.class);

			Criterion rest1 = Restrictions.and(Restrictions.eq("pAuthUserId", userId.intValue()));
			Criterion rest2 = Restrictions.and(Restrictions.eq("sAuthUserId", userId.intValue()));
			detachedCriteria.add(Restrictions.or(rest1, rest2));

			clientCommunications = (List<ClientCommunication>) hibernateDao.find(detachedCriteria);

			authorizedGstins = getAuthorizedSignatureGstinsComma(clientCommunications);

		} catch (Exception exec) {
			LOGGER.error("Exception in fetchAuthorizedSignatureGstins" + exec);
		}
		return authorizedGstins;
	}

	private String getAuthorizedSignatureGstinsComma(List<ClientCommunication> clientCommunications) {

		StringBuffer gstins = new StringBuffer();
		for (ClientCommunication clientComm : clientCommunications) {

			gstins.append(clientComm.getGstin());
			gstins.append(",");
		}
		return gstins.toString();
	} 
	
}
