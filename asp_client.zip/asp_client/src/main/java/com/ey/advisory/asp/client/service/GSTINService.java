package com.ey.advisory.asp.client.service;

import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;

public interface GSTINService {
	
	/**
	 * To fetch GSTIN details from table tblGSTINDetails
	 */
	public void fetchGstinDetails();
	
	/**
	 * To fetch GSTIN details from table tblGSTINDetails for a particular gstinId
	 * @return 
	 */
	public TblGstinDetailsDomain fetchGstinDetails(String gstinId);

}
