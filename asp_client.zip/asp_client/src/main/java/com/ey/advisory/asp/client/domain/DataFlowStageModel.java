package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the tblDataFlowStages database table.
 * 
 */
@Entity
@Table(name="tblDataFlowStages", schema ="dbo")
public class DataFlowStageModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FlowId")
	private long flowId;

	@Column(name="FlowOrder")
	private int flowOrder;

	@Column(name="ReturnType")
	private String returnType;

	@Column(name="StageCode")
	private String stageCode;

	@Column(name="StageDesc")
	private String stageDesc;

	public long getFlowId() {
		return this.flowId;
	}

	public void setFlowId(long flowId) {
		this.flowId = flowId;
	}

	public int getFlowOrder() {
		return this.flowOrder;
	}

	public void setFlowOrder(int flowOrder) {
		this.flowOrder = flowOrder;
	}

	public String getReturnType() {
		return this.returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public String getStageCode() {
		return this.stageCode;
	}

	public void setStageCode(String stageCode) {
		this.stageCode = stageCode;
	}

	public String getStageDesc() {
		return this.stageDesc;
	}

	public void setStageDesc(String stageDesc) {
		this.stageDesc = stageDesc;
	}

}