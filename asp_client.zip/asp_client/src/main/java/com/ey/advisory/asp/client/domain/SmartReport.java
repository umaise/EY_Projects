package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.google.gson.annotations.SerializedName;

@Entity
@Table(name = "tblSmartReportDetails",schema="config")
public class SmartReport  implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ReportID")
	@GenericGenerator(name = "request_id", strategy = "com.ey.advisory.asp.client.util.SmartReportRequestIDGenerator")
	@GeneratedValue(generator = "request_id")
	private String reportId;
	
	@Column(name = "Params")
	private String params;
	
	@Column(name = "FilePath")
	private String filePath;
	
	@Column(name = "FileName")
	private String fileName;
	
	@Column(name = "Status")
	private String status;
	
	@Column(name = "CreatedDate")
	private Date createdDate;
	
	@Column(name = "UpdatedDate")
	private Date updatedDate;
	
	@Column(name = "FileCategory")
	private String fileCategory;
	
	@SerializedName("UserId")
	@Column(name="UserId")
	private Long userId;
	
	@Transient
	private String taxPeriod;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getParams() {
		return params;
	}

	public void setParams(String params) {
		this.params = params;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getFileCategory() {
		return fileCategory;
	}

	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}

	public String getReportId() {
		return reportId;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	
	
}
