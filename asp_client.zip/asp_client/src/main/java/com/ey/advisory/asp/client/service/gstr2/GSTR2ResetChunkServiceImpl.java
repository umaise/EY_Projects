package com.ey.advisory.asp.client.service.gstr2;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.jdbc.Work;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.common.Constant;

@Service
public class GSTR2ResetChunkServiceImpl implements GSTR2ResetChunkService {

	private static final Logger logger = Logger
			.getLogger(GSTR2ResetChunkServiceImpl.class);
	private static final String CLASS_NAME = GSTR2ResetChunkServiceImpl.class
			.getName();

	@Autowired
	private HibernateDao hibernateDao;

	@SuppressWarnings("null")
	@Override
	public String resetGSTR2Chunks(JSONObject jsonObject) {
		// TODO Auto-generated method stub
		String response = "";
		List<String> updateListQuery = getGSTR2ResetChunkUpdateQueries(jsonObject);
		Session session = hibernateDao.getSession();
		Transaction tx = session.beginTransaction();
		try {
			session.doWork(new Work() {
				int count[];

				@Override
				public void execute(Connection connection) throws SQLException {
					// TODO Auto-generated method stub
					Statement preparedStatement = connection.createStatement();
					for (String string : updateListQuery) {
						preparedStatement.addBatch(string);
					}
					count = preparedStatement.executeBatch();
				}

			});
			tx.commit();
			session.close();
			response = Constant.SUCCESS;
		} catch (Exception e) {
			logger.error("Error in updatescript" + e, e); //PROC_USPOUTWARDSUPPLY
			e.printStackTrace();
			response = Constant.FAILED;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return response;
	}
	
	public List<String> getGSTR2ResetChunkUpdateQueries(JSONObject jsonObject){
		List<String> list = new ArrayList<String>();
		if(jsonObject == null)
			return list;
		
		try{
			if(jsonObject.get(Constant.TABLE_TYPE) != null){
				if(Constant.NIL.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString()))
					list.add("UPDATE GSTR2.TBLNILRATEDINVOICEDETAILS  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" + "'" +  jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'" );
				
				if(Constant.HSN.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR2.TBLHSNSUMMARY  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" +  jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR2.TBLSUMMARYGSTNSUBMISSIONSTATUS SET ISACTIVE = 0 WHERE TAXPERIOD="+ "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
				}
				
				if(Constant.TXI.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR2.TBLSUMMARYADVTAXPAID  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR2.TBLSUMMARYGSTNSUBMISSIONSTATUS SET ISACTIVE = 0 WHERE TAXPERIOD="+ "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
				}
				
				if(Constant.TXPD.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR2.TBLSUMMARYADVTAXADJ  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR2.TBLSUMMARYGSTNSUBMISSIONSTATUS SET ISACTIVE = 0 WHERE TAXPERIOD="+ "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
				}
				
				if(Constant.ITCRVRSL.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR2.TBLSUMMARYADVTAXPAID  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" + "'" +  jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR2.TBLSUMMARYGSTNSUBMISSIONSTATUS SET ISACTIVE = 0 WHERE TAXPERIOD="+ "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
				}
				
				if(Constant.ALL.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString())){
					list.add("UPDATE GSTR2.TBLNILRATEDINVOICEDETAILS  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'" );
					list.add("UPDATE GSTR2.TBLHSNSUMMARY  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR2.TBLSUMMARYADVTAXPAID  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" +  jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR2.TBLSUMMARYADVTAXADJ  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" +  "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR2.TBLSUMMARYITCREVERSAL  SET CHUNKID = NULL,ISGSTNSUCCESS=0 WHERE TAXPERIOD=" +  "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
					list.add("UPDATE GSTR2.TBLSUMMARYGSTNSUBMISSIONSTATUS SET ISACTIVE = 0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'");
				}
				
				if(Constant.B2B.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString()))
					list.add("UPDATE GSTR2.TBLINVOICEKEYDETAIL  SET LOADID = NULL WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'"  + " AND GSTIN=" + "'" +  jsonObject.get(Constant.GSTIN).toString() + "'" + " AND ISRECONDONE = 0 AND LOADID IS NOT NULL");
				
				if(Constant.RECON.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString()) || Constant.ALL.equalsIgnoreCase(jsonObject.get(Constant.TABLE_TYPE).toString()))
					list.add("UPDATE GSTR2.TBLINVOICEKEYDETAIL  SET LOADID = NULL WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" +  "'" + jsonObject.get(Constant.GSTIN).toString()  + "'" + " AND ISRECONDONE = 1 AND LOADID IS NOT NULL");
					
				list.add("UPDATE ETL.TBLGSTINLIST SET ISCHUNKINGINITIATED = 0 WHERE TAXPERIOD=" + "'" + jsonObject.get(Constant.TAX_PERIOD).toString() + "'" + " AND GSTIN=" + "'" + jsonObject.get(Constant.GSTIN).toString() + "'" + " AND RETURNTYPE = 'GSTR2'");
				return list;
			}

		}catch(Exception e){
			logger.error("Error in adding queries to the list" + e , e);
			e.printStackTrace();
			return list;
		}
		return list;
	}
}
