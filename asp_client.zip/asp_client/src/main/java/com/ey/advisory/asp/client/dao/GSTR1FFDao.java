package com.ey.advisory.asp.client.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;

public interface GSTR1FFDao {
	public String saveB2B(String jsonStr, String gstin, String retPeriod, Integer chunkId);
	/**
	 * Method to update the status once gstr1FF is done
	 * @param gstin
	 * @param retPeriod
	 * @return
	 * @throws Exception
	 */
	
	/** 
	 * Method to find status for gstr1ff
	 * @param outputParamList
	 * @return
	 */
	public TblGstinRetutnFilingStatus getGSTR1FFEntry (List<String> outputParamsList);
	
	/** 
	 * Method to insert status for gstr2a
	 * @param outputParamList
	 * @return
	 */
	public String insertGSTR1FFStatus(List<String> outputParamList);
	
	public String insertGSTR1FFStatus(String gstin, String retPeriod, String status) throws Exception;
	
	
	public TblGstinRetutnFilingStatus checkGSTR1FFEntry (String gstinId, String taxPeriod);
	
	
	
}
