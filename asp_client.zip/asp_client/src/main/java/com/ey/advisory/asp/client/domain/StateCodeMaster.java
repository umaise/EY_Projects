package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblStates",schema="master")
public class StateCodeMaster implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "StateID")
	int serialNumber;
	
	@Column(name = "StateName")
	String stateName;
	
	
	@Column(name = "StateIdentifier")
	String stateIdentifier;  // Column added as part of Product Backlog Item 378
	
	@Column(name = "Statecode")
	String stateCode;
	
	@Column(name = "IsUT")
	String isUT;  // Not a Mandatory field
	
	
	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	
	public String getStateCode() {
		return stateCode;
	}
	public String getStateIdentifier() {
		return stateIdentifier;
	}
	public void setStateIdentifier(String stateIdentifier) {
		this.stateIdentifier = stateIdentifier;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	
}
