package com.ey.advisory.asp.client.service;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonProcessingException;

public interface PowerBIService {

	public Map<String, String> getBIAccessToken(String grpID,String reportID, HashMap<String, String> paramMap, String embedURLConfig) throws JsonProcessingException, UnsupportedEncodingException;
}
