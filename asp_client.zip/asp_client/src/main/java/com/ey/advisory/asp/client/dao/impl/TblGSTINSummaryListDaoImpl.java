package com.ey.advisory.asp.client.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.TblGSTINSummaryListDao;
import com.ey.advisory.asp.client.domain.TblGSTINSummaryList;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatusPK;
import com.ey.advisory.asp.common.Constant;

@Repository
public class TblGSTINSummaryListDaoImpl implements TblGSTINSummaryListDao{
	private static final Logger logger = Logger.getLogger(TblGSTINSummaryListDaoImpl.class);
	@Autowired
	HibernateDao hibernateDao;

	
	
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.dao.TblGSTINSummaryListDao#insertUpdateGstr12SummaryStatus(java.util.List)
	 */
	@Override
    public String insertUpdateGstr12SummaryStatus(List<TblGSTINSummaryList> gstinList) {
         logger.info("*********** entering Job insertUpdateGstr12SummaryStatus " + gstinList);
  
        try{
        	
        	 TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
 	         
 	         TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
         for(TblGSTINSummaryList gstinRec:gstinList)
         {
        	 DetachedCriteria detachedCriteria = hibernateDao
     				.createCriteria(TblGstinRetutnFilingStatus.class);
     		detachedCriteria
     				.add(Restrictions.eq("id.gstinId", gstinRec.getgSTIN()));
     		detachedCriteria.add(Restrictions.eq("id.taxPeriod", gstinRec.getTaxPeriod()));
     		detachedCriteria.add(Restrictions.eq("id.returnType", Constant.GSTR1_Filing));
     		detachedCriteria.add(Restrictions.eq("status", Constant.SAVESTATE));
     		detachedCriteria.add(Restrictions.eq("summaryStatus", Constant.SAVESTATE));
     		detachedCriteria.add(Restrictions.eq("isSuccess", Boolean.TRUE));
      		List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
     		if(null!=gstinRetutnFilingStatus && !gstinRetutnFilingStatus.isEmpty()){
     			//do nothing
     		}else
     		{
     			 //insert record for GSTIN 
     	         tblGstinRetutnFilingStatusPK.setGstinId(gstinRec.getgSTIN());
     	         tblGstinRetutnFilingStatusPK.setReturnType(Constant.GSTR1_Filing);
     	         tblGstinRetutnFilingStatusPK.setTaxPeriod(gstinRec.getTaxPeriod());            
     	         tblGstinRetutnFilingStatus.setStatus(Constant.SAVESTATE);
     	        tblGstinRetutnFilingStatus.setSummaryStatus(Constant.SAVESTATE);
     	         tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
     	         tblGstinRetutnFilingStatus.setIsSuccess(Boolean.TRUE);
     	         hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
     		}
         }
   
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job insertUpdateGstr12SummaryStatus ",e);
		} 
         return "Success";
    }
	

	
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.dao.TblGSTINSummaryListDao#updateGstinSummaryList(com.ey.advisory.asp.client.domain.TblGSTINSummaryList)
	 */
	@Override
	public void updateGstinSummaryList(TblGSTINSummaryList gstinData) {
		 logger.info("*********** entering method updateGstinSummaryList " + gstinData);
		 try{
			 TblGSTINSummaryList gstnData=new TblGSTINSummaryList();
		 //gstnData.setIsChunkingInitiated(Boolean.TRUE);//to do (update the status column)
		 gstnData.setUpdatedDate(new Date());
		 hibernateDao.saveOrUpdate(gstnData);
		 }
		 catch(Exception ex){
			 logger.error("*********** ERROR in method updateGstinSummaryList ",ex);
		 }
	}

	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#getGstinRtType(java.util.List)
	 * get the gstin based on entity level
	 */
	@Override
	public List<TblGSTINSummaryList> getGstinRtSummaryType(List<Integer> fileIdList) {
		 logger.info("*********** entering method getGstinRtSummaryType " + fileIdList.toString());
		List<TblGSTINSummaryList> tblGSTINSummaryList = null;
		try
		{
			
			/* DetachedCriteria detachedCriteriasub = hibernateDao.createCriteria(EntityHierarchy.class);
			 detachedCriteriasub.add(Restrictions.eq("entityID",Integer.parseInt(entityId)));
			 ProjectionList projectionList=Projections.projectionList();
			 projectionList.add(Projections.property("gSTIN"));
			 detachedCriteriasub.setProjection(projectionList);*/
			 
		    DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGSTINSummaryList.class);
		    detachedCriteria.add(Restrictions.in("fileId",fileIdList));
		    detachedCriteria.addOrder(Order.asc("taxPeriod"));
		   // detachedCriteria.add(Restrictions.in("status","New"));//need to check
		   // detachedCriteria.add((Subqueries.propertyIn("gSTIN", detachedCriteriasub)));
		    tblGSTINSummaryList = (List<TblGSTINSummaryList>) hibernateDao.find(detachedCriteria);
		}
		catch(Exception ex)
		{
			logger.error("*********** ERROR in Job getGstinRtSummaryType *********** ",ex);
		}
		return tblGSTINSummaryList;
	}
}
