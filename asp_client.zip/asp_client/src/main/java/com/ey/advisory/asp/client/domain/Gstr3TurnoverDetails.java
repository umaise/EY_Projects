package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 */

@Entity
@Table(name="tblgstr3GrossTurnOver", schema="gstr3")
@NamedQuery(name = "Gstr3TurnoverDetails.updateIsFiled",  query = "update Gstr3TurnoverDetails set "
		+ "isFiled=:FILED where gstin= :GSTN and financialYear= :FYEAR")
public class Gstr3TurnoverDetails implements Serializable{
		private static final long serialVersionUID = 1L;

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name="Gstr3GrossTurnOverUID")
		private int grossturnoverId;

		@Column(name="GSTIN")
		private String gstin;
		
		@Column(name="FinancialYear")
		private String financialYear;

		@Column(name="GrossTurnOver")
		private double grossTurnover;

		@Column(name="ExportTurnOver")
		private double exportTurnover;

		@Column(name="NilOrExemptedTurnOver")
		private double nillRatedAndExemptedTurnover;

		@Column(name="NonGSTTurnOver")
		private double nonGstTurnover;

		@Column(name="NetTaxableTurnOver")
		private double taxableTurnover;

		@Column(name="Isactive")
		private boolean isActive;
		
		@Column(name="IsFiled")
		private boolean isFiled;
		
		@Temporal(TemporalType.DATE)
		@Column(name = "CreatedOn")
		private Date createdOn;	
		
		@Column(name = "CreatedBy")
		private String createdBy;	
		
		@Temporal(TemporalType.DATE)
		@Column(name = "UpDatedOn")
		private Date updatedOn;	
		
		@Column(name = "UpdatedBy")
		private String updatedBy;	

		public int getGrossturnoverId() {
			return grossturnoverId;
		}

		public void setGrossturnoverId(int grossturnoverId) {
			this.grossturnoverId = grossturnoverId;
		}

		public String getGstin() {
			return gstin;
		}

		public void setGstin(String gstin) {
			this.gstin = gstin;
		}

		public String getFinancialYear() {
			return financialYear;
		}

		public void setFinancialYear(String financialYear) {
			this.financialYear = financialYear;
		}

		public double getGrossTurnover() {
			return grossTurnover;
		}

		public void setGrossTurnover(double grossTurnover) {
			this.grossTurnover = grossTurnover;
		}

		public double getExportTurnover() {
			return exportTurnover;
		}

		public void setExportTurnover(double exportTurnover) {
			this.exportTurnover = exportTurnover;
		}

		public double getNillRatedAndExemptedTurnover() {
			return nillRatedAndExemptedTurnover;
		}

		public void setNillRatedAndExemptedTurnover(double nillRatedAndExemptedTurnover) {
			this.nillRatedAndExemptedTurnover = nillRatedAndExemptedTurnover;
		}

		public double getNonGstTurnover() {
			return nonGstTurnover;
		}

		public void setNonGstTurnover(double nonGstTurnover) {
			this.nonGstTurnover = nonGstTurnover;
		}

		public double getTaxableTurnover() {
			return taxableTurnover;
		}

		public void setTaxableTurnover(double taxableTurnover) {
			this.taxableTurnover = taxableTurnover;
		}

		public boolean isActive() {
			return isActive;
		}

		public void setActive(boolean isActive) {
			this.isActive = isActive;
		}

		public boolean isFiled() {
			return isFiled;
		}

		public void setFiled(boolean isFiled) {
			this.isFiled = isFiled;
		}

		public Date getCreatedOn() {
			return createdOn;
		}

		public void setCreatedOn(Date createdOn) {
			this.createdOn = createdOn;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public Date getUpdatedOn() {
			return updatedOn;
		}

		public void setUpdatedOn(Date updatedOn) {
			this.updatedOn = updatedOn;
		}

		public String getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(String updatedBy) {
			this.updatedBy = updatedBy;
		}
		
}
