package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.QuestionAnswerMapping;

public interface QuestionAnswerService {
    
    
    public List<Object[]> loadClientOnBoardingInfoDetails(String PAN);
    
    public List<QuestionAnswerMapping> fetchQuestionAnswers(Integer entityId);

	void saveQuestionAnswerMapping(List<QuestionAnswerMapping> questionAnswerMappingList);

}
