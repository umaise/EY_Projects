package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblGSTINList;

public interface TblGSTINListDao {
	public String insertUpdateGstr12FilingStatus(List<TblGSTINList> gstinList);
	public void updateGstinList(TblGSTINList gstinData );
	List<TblGSTINList> getGstinRtType(String returnType);
	List<TblGSTINList> getGstinRtType(String returnType, String gstin,String taxPeriod);
	public void updateGstinList(int fileId );
	

}
