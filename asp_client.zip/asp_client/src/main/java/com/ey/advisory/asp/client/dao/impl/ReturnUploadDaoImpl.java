package com.ey.advisory.asp.client.dao.impl;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.ReturnUploadDao;
import com.ey.advisory.asp.client.domain.DueDateMaster;
import com.ey.advisory.asp.client.domain.InvoiceKeyDetail;
import com.ey.advisory.asp.client.domain.ReturnUpload;
import com.ey.advisory.asp.client.domain.SummaryReturnUpload;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.common.Constant;

@Repository
public class ReturnUploadDaoImpl implements ReturnUploadDao {
	
	@Autowired
	private HibernateDao  hibernateDao;
	
	private static final Logger LOGGER = Logger.getLogger(ReturnUploadDaoImpl.class);
	
	@Override
	public Boolean validateSavedStatusAgainstInvoiceKey(String gstinId, String rtPeriod, String retType) {
		

		Boolean canSubmit=true;
		// TODO Auto-generated method stub
		DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class,"tblGstinRetutnStatus");
		detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
		detachedCriteria.add(Restrictions.eq("id.taxPeriod", rtPeriod));
		detachedCriteria.add(Restrictions.eq("id.returnType", retType));
		detachedCriteria.setProjection(Projections.property("filingId"));
		List<Long> tblFilereturnUploadList = (List<Long>) hibernateDao.find(detachedCriteria);
		
		if(tblFilereturnUploadList!=null&& !tblFilereturnUploadList.isEmpty()){
		
			Long filingId = tblFilereturnUploadList.get(0);
		
		DetachedCriteria detachedCriteria1 =hibernateDao.createCriteria(InvoiceKeyDetail.class);
		
		detachedCriteria1.add(Restrictions.eq("fileId", filingId));
		detachedCriteria1.add(Restrictions.eq("gstin", gstinId));
		detachedCriteria1.add(Restrictions.eq("taxPeriod", rtPeriod));
		List<InvoiceKeyDetail> tblInvoiceKeyDetailList = (List<InvoiceKeyDetail>) hibernateDao.find(detachedCriteria1);
		for (InvoiceKeyDetail returnUpload : tblInvoiceKeyDetailList) {
			
			if(!returnUpload.isLoadedToGstn()){
				
				canSubmit=false;
				break;
			}
			else{
				canSubmit=true;
				
				
				
			}
			
		}
		}
		
		else{
			canSubmit=false;
			
		}
		return canSubmit;
	}
	
	  // Transaction ID Polling starts 
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ReturnUpload> getReturnUpload() {
		LOGGER.info("Executing getReturnUpload for TransactionPolling Save");
		List<ReturnUpload> returnUploads = null;
		try{
		DetachedCriteria criteria = hibernateDao.createCriteria(ReturnUpload.class);
		criteria.add(Restrictions.or(Restrictions.isNotNull("refId"), 
                Restrictions.ne("refId", "")));
		criteria.add(Restrictions.or(Restrictions.isNull("gstnStatus"), 
                Restrictions.eq("gstnStatus", ""),
                Restrictions.eq("gstnStatus",Constant.REC),Restrictions.eq("gstnStatus",Constant.INPROGRESS)));
		returnUploads = (List<ReturnUpload>)hibernateDao.find(criteria);
		}
		catch(Exception e){
			LOGGER.error("Exception occured while fetchig RefIds "+e);
		}
		return returnUploads;
	}
	
	//Transaction ID Polling starts for submit call
	
	@SuppressWarnings("unchecked")
	@Override
	public List<TblGstinRetutnFilingStatus> gettblGstinRetutnFilingStatus() {
		List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatus = null;
		try{
			LOGGER.info("Executing gettblGstinRetutnFilingStatus to get submit Refids");	
		DetachedCriteria criteria = hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
		criteria.add(Restrictions.eq("status",Constant.SUBMITSUCESS));
		criteria.add(Restrictions.or(Restrictions.isNotNull("submitRefId"),Restrictions.ne("submitRefId", "null"),
                Restrictions.ne("submitRefId", "")));
		criteria.add(Restrictions.or(Restrictions.isNull("gstnStatus"), 
                Restrictions.eq("gstnStatus", ""),
                Restrictions.eq("gstnStatus",Constant.REC),Restrictions.eq("gstnStatus",Constant.INPROGRESS)));
		tblGstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>)hibernateDao.find(criteria);
		}catch(Exception e){
			LOGGER.error("Exception while fetching submit RefIds "+e);
		}
		return tblGstinRetutnFilingStatus;
	}
	
	@Override
	public ReturnUpload getReturnUpload(Long filingId, String trxId, String refId, Long loadId) {
		List<ReturnUpload> returnUploads = null;
		try{
			LOGGER.info("Fetch records for filingId/Refids/loadids ");
		DetachedCriteria criteria = hibernateDao.createCriteria(ReturnUpload.class);
		criteria.add(Restrictions.eq("filingId", filingId));
		//criteria.add(Restrictions.eq("TrxId", trxId));
		criteria.add(Restrictions.eq("refId", refId));
		criteria.add(Restrictions.eq("loadId", loadId));
		returnUploads = (List<ReturnUpload>)hibernateDao.find(criteria);
		}catch(Exception e){
			LOGGER.error("Exception fetching ReturnUpload based on filingId/Refids/loadids "+e);
		}
		return returnUploads.get(0);
	}
	
	//submit trx status update
	
	@Override
	public TblGstinRetutnFilingStatus gettblGstinRetutnFilingStatus(Long filingId, String trxId, String refId) {
		List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatus;		 
		DetachedCriteria criteria = hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
		criteria.add(Restrictions.eq("filingId", filingId));
		//criteria.add(Restrictions.eq("TrxId", trxId));
		criteria.add(Restrictions.eq("submitRefId", refId));
		//criteria.add(Restrictions.eq("loadId", loadId));
		tblGstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>)hibernateDao.find(criteria);
		return tblGstinRetutnFilingStatus.get(0);
	}

	@Override
	public List<SummaryReturnUpload> getSummaryReturnUpload() {
		List<SummaryReturnUpload> returnUploads ;		 
		DetachedCriteria criteria = hibernateDao.createCriteria(SummaryReturnUpload.class);
		criteria.add(Restrictions.isNotNull("TrxId"));
		criteria.add(Restrictions.isNotNull("refId"));
		criteria.add(Restrictions.isNull("gstnStatus"));
		returnUploads = (List<SummaryReturnUpload>)hibernateDao.find(criteria);
		return returnUploads;
	}
	


	@Override
	public SummaryReturnUpload getSummaryReturnUpload(Long filingId, String trxId, String refId, Long loadId) {
		List<SummaryReturnUpload> returnUploads ;		 
		DetachedCriteria criteria = hibernateDao.createCriteria(SummaryReturnUpload.class);
		criteria.add(Restrictions.eq("filingId", filingId));
		criteria.add(Restrictions.eq("TrxId", trxId));
		criteria.add(Restrictions.eq("refId", refId));
		criteria.add(Restrictions.eq("loadId", loadId));
		returnUploads = (List<SummaryReturnUpload>)hibernateDao.find(criteria);
		return returnUploads.get(0);
	}
	  // Transaction ID Polling ends 

	@Override
	public List<ReturnUpload> getReturnUpload(String gstin,String taxperiod,String returnType) {		
		List<ReturnUpload> returnUploads = null;	
		try{
			LOGGER.info("Calling getReturnUpload() to display status");
		//DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class,"tblGstinRetutnStatus");
		DetachedCriteria criteria = hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
		criteria.add(Restrictions.eq("id.gstinId",gstin));
		criteria.add(Restrictions.eq("id.taxPeriod",taxperiod));
		criteria.add(Restrictions.eq("id.returnType",returnType));
		ProjectionList projList = Projections.projectionList();	
		projList.add(Projections.property(Constant.FILING_ID));
		criteria.setProjection(Projections.distinct(projList));
		List<Long> returnFilingId = (List<Long>) hibernateDao.getHibernateTemplate().findByCriteria(criteria);
		
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(ReturnUpload.class);
		detachedCriteria.add(Restrictions.or(Restrictions.isNotNull("refId"), 
                Restrictions.ne("refId", "")));
		detachedCriteria.add(Restrictions.in(Constant.ReturnFilingId,returnFilingId)); 
		detachedCriteria.addOrder(Order.desc(Constant.CREATED_DATE));
		returnUploads = (List<ReturnUpload>)hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			LOGGER.error("Exception inside getReturnUpload()-RefStatus cannot be displayed"+e);
		}
		return returnUploads;
	}
	/**
	 * Calling return Upload for a particular refId
	 */
	@Override
	public Object getReturnUpload(String gstin,String taxperiod,String returnType, String refId) {		
		List<Object> returnUploadsList = null;	
		Object returnUploads = null;
		try{
			LOGGER.info("Calling getReturnUpload() to display status for refId : "+refId);
		
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(ReturnUpload.class);
		detachedCriteria.setProjection(Projections.property("errorDesc"));
		
		detachedCriteria.add(Restrictions.or(Restrictions.isNotNull("refId"), 
                Restrictions.ne("refId", "")));
		detachedCriteria.add(Restrictions.eqOrIsNull("refId", refId));		
		//detachedCriteria.add(Restrictions.in(Constant.ReturnFilingId,returnFilingId)); 
		detachedCriteria.addOrder(Order.desc(Constant.CREATED_DATE));
		returnUploadsList = (List<Object>)hibernateDao.find(detachedCriteria);
		if(returnUploadsList.size() > 0){
			returnUploads = returnUploadsList.get(0);
		}
		
		}catch(Exception e){
			LOGGER.error("Exception inside getReturnUpload() for refId :" + refId +"\n"+e.getMessage());
		}
		return returnUploads;
	}

	@Override
	public List<Object> getInvoiceKeyDetailList() {
		List<Object> invoiceKeyDetailList=null;
		try{
			LOGGER.info("Inside getInvoiceKeyDetailList()");
		DetachedCriteria criteriaInvoiceKeyDetail = DetachedCriteria.forClass(InvoiceKeyDetail.class);
		    criteriaInvoiceKeyDetail.add(Restrictions.isNotNull(Constant.LoadId));
		    ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property(Constant.GSTIN_ID));
			projList.add(Projections.property(Constant.TAXPERIOD));
		    projList.add(Projections.property(Constant.INVOICE_TYPE));
		    projList.add(Projections.property(Constant.LoadId));
			criteriaInvoiceKeyDetail.setProjection(Projections.distinct(projList));
//			criteriaInvoiceKeyDetail.setResultTransformer(Transformers.aliasToBean(InvoiceKeyDetail.class));
			invoiceKeyDetailList =  (List<Object>) hibernateDao.find(criteriaInvoiceKeyDetail);
		}
		catch(Exception e){
			LOGGER.error("Exception occured inside getInvoiceKeyDetailList() "+e);
		}
			return invoiceKeyDetailList;
			
	}
}
 