package com.ey.advisory.asp.client.domain;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ReturnSubmissionStatus", schema="gstr3")

public class ReturnSubmissionStatus {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ReturnSubmissionStatusUID")
	private BigInteger returnSubmissionStatusUID;
	
	@Column(name="GSTIN")
	private String gstin ;
	
	@Column(name="ReturnPeriod")
	private String rtPeriod;
	
	@Column(name="DebitNum")
	private String debitNum ;
	
	@Column(name="CreatedOn")
	private Date createdOn ;
	
	@Column(name="description")
	private String description;
	
	@Column(name="payable")
	private BigDecimal payable;
	
	@Column(name="ledgerFlag")
	private boolean ledgerFlag;
	
	@Column(name="IGST")
	private BigDecimal igst;
	
	@Column(name="CGST")
	private BigDecimal cgst;
	
	@Column(name="SGST")
	private BigDecimal sgst;
	
	@Column(name="CESS")
	private BigDecimal cess;
	
	@Column(name="UTGST")
	private BigDecimal utgst;
	
	
	
	public BigDecimal getPayable() {
		return payable;
	}
	public void setPayable(BigDecimal payable) {
		this.payable = payable;
	}
	public boolean isLedgerFlag() {
		return ledgerFlag;
	}
	public void setLedgerFlag(boolean ledgerFlag) {
		this.ledgerFlag = ledgerFlag;
	}
	public BigDecimal getIgst() {
		return igst;
	}
	public void setIgst(BigDecimal igst) {
		this.igst = igst;
	}
	public BigDecimal getCgst() {
		return cgst;
	}
	public void setCgst(BigDecimal cgst) {
		this.cgst = cgst;
	}
	public BigDecimal getSgst() {
		return sgst;
	}
	public void setSgst(BigDecimal sgst) {
		this.sgst = sgst;
	}
	public BigDecimal getCess() {
		return cess;
	}
	public void setCess(BigDecimal cess) {
		this.cess = cess;
	}
	public BigDecimal getUtgst() {
		return utgst;
	}
	public void setUtgst(BigDecimal utgst) {
		this.utgst = utgst;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public BigInteger getReturnSubmissionStatusUID() {
		return returnSubmissionStatusUID;
	}
	public void setReturnSubmissionStatusUID(BigInteger returnSubmissionStatusUID) {
		this.returnSubmissionStatusUID = returnSubmissionStatusUID;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getRtPeriod() {
		return rtPeriod;
	}
	public void setRtPeriod(String rtPeriod) {
		this.rtPeriod = rtPeriod;
	}
	public String getDebitNum() {
		return debitNum;
	}
	public void setDebitNum(String debitNum) {
		this.debitNum = debitNum;
	}
	
	
	

}

