package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

/**
 * The persistent class for the GSTR2A tblB2BInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblCDNInvoiceDetails", schema=Constant.GSTR2A_SCHEMA)
public class GSTR2ACDNInvoiceDetail implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ID")
	private long id;
	
	@Column(name="CustGSTIN")
	private String custGSTIN;

	@Column(name="CntrPrtyFilingStatus")
	private String cntrPrtyFilingStatus;
	
	@Column(name="ChkSum")
	private String chkSum;
	
	@Column(name="NtNum")
	private String noteNum;
	
	@Column(name="NtDate")
	private Date noteDate;

	@Column(name="InvNum")
	private String invNum;
	
	@Column(name="InvDate")
	private Date invDate;

	@Column(name="InvValue")
	private BigDecimal invValue;
	
	@Column(name="Rsn")
	private String rsn;
	
	@Column(name="PreGst", length=1)
	private String preGst;
	
	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;
	
	@Column(name="POS")
	private String pos;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="InvKey")
	private String invoiceKey;
	
	@Column(name="IsDelete", length=3)
	private String isDelete;
	
	@Column(name="CHUNKID")
	private String chunkId;
	
	@Column(name="TotalTax")
	private BigDecimal totalTax;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCustGSTIN() {
		return custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getCntrPrtyFilingStatus() {
		return cntrPrtyFilingStatus;
	}

	public void setCntrPrtyFilingStatus(String cntrPrtyFilingStatus) {
		this.cntrPrtyFilingStatus = cntrPrtyFilingStatus;
	}

	public String getChkSum() {
		return chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getInvNum() {
		return invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public Date getInvDate() {
		return invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public BigDecimal getInvValue() {
		return invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public BigDecimal getTaxablevalue() {
		return taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}


	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public String getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(String isDelete) {
		this.isDelete = isDelete;
	}

	public String getChunkId() {
		return chunkId;
	}

	public void setChunkId(String chunkId) {
		this.chunkId = chunkId;
	}

	public BigDecimal getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(BigDecimal totalTax) {
		this.totalTax = totalTax;
	}

	public String getNoteNum() {
		return noteNum;
	}

	public void setNoteNum(String noteNum) {
		this.noteNum = noteNum;
	}

	public Date getNoteDate() {
		return noteDate;
	}

	public void setNoteDate(Date noteDate) {
		this.noteDate = noteDate;
	}

	public String getRsn() {
		return rsn;
	}

	public void setRsn(String rsn) {
		this.rsn = rsn;
	}

	public String getPreGst() {
		return preGst;
	}

	public void setPreGst(String preGst) {
		this.preGst = preGst;
	}

}
