package com.ey.advisory.asp.client.dto;

import java.io.Serializable;
import java.util.List;

public class SmartReportDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String reportType;
	private String fy;
	private String returnPeriod;
	private String startDate;
	private String endDate;
	private String typeOfReport;
	private String typeOfSubmitReport;
	private Long userid;
	private List<String> docType;
	private List<String> summaryType;
	private List<String> supplyType;
	private List<String> attribs;
	private List<String> eligibilityIndicator;
	private List<String> reconResponse;
	private List<String> recpGstin;
	private List<String> revChgCategory;
	private String groupCode;
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	public String getFy() {
		return fy;
	}
	public void setFy(String fy) {
		this.fy = fy;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public List<String> getDocType() {
		return docType;
	}
	public void setDocType(List<String> docType) {
		this.docType = docType;
	}
	public List<String> getSupplyType() {
		return supplyType;
	}
	public void setSupplyType(List<String> supplyType) {
		this.supplyType = supplyType;
	}
	public List<String> getAttribs() {
		return attribs;
	}
	public void setAttribs(List<String> attribs) {
		this.attribs = attribs;
	}
	public List<String> getEligibilityIndicator() {
		return eligibilityIndicator;
	}
	public void setEligibilityIndicator(List<String> eligibilityIndicator) {
		this.eligibilityIndicator = eligibilityIndicator;
	}
	public List<String> getReconResponse() {
		return reconResponse;
	}
	public void setReconResponse(List<String> reconResponse) {
		this.reconResponse = reconResponse;
	}
	public List<String> getRecpGstin() {
		return recpGstin;
	}
	public void setRecpGstin(List<String> recpGstin) {
		this.recpGstin = recpGstin;
	}
	public List<String> getRevChgCategory() {
		return revChgCategory;
	}
	public void setRevChgCategory(List<String> revChgCategory) {
		this.revChgCategory = revChgCategory;
	}
	public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public String getTypeOfReport() {
		return typeOfReport;
	}
	public void setTypeOfReport(String typeOfReport) {
		this.typeOfReport = typeOfReport;
	}
	@Override
	public String toString() {
		return "SmartReportDto [reportType=" + reportType + ", fy=" + fy + ", returnPeriod=" + returnPeriod
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", docType=" + docType + ",typeOfReport="+typeOfReport+", supplyType="
				+ supplyType + ", attribs=" + attribs + ", eligibilityIndicator=" + eligibilityIndicator
				+ ", recpGstin=" + recpGstin + ", revChgCategory=" + revChgCategory + "]";
	}
	public List<String> getSummaryType() {
		return summaryType;
	}
	public void setSummaryType(List<String> summaryType) {
		this.summaryType = summaryType;
	}
	public String getTypeOfSubmitReport() {
		return typeOfSubmitReport;
	}
	public void setTypeOfSubmitReport(String typeOfSubmitReport) {
		this.typeOfSubmitReport = typeOfSubmitReport;
	}
	
	

}
