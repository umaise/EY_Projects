package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblGSTR2SummaryRCMConsolidated", schema="metadata")
public class GSTR2SummaryRCMConsolidated implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="RCMConsolidatedID")
	private Integer RCMConsolidatedId;
	
	@Column(name="ColumnName")
	private String columnName;
	
	@Column(name="ColumnCode")
	private String columnCode;
	
	@Column(name="DataType")
	private String dataType;
	
	@Column(name="ColumnOrderNo")
	private Integer columnOrderNo;

	public Integer getRCMConsolidatedId() {
		return RCMConsolidatedId;
	}

	public void setRCMConsolidatedId(Integer rcmConsolidatedId) {
		RCMConsolidatedId = rcmConsolidatedId;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnCode() {
		return columnCode;
	}

	public void setColumnCode(String columnCode) {
		this.columnCode = columnCode;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public Integer getColumnOrderNo() {
		return columnOrderNo;
	}

	public void setColumnOrderNo(Integer columnOrderNo) {
		this.columnOrderNo = columnOrderNo;
	}
}

