package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="tblBankAccDetails", schema="master")
public class BankAccountDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="BankAccDetailID")
	private BigInteger bankAccDetailID;
	
	@Column(name="BankAccNo")
	private String bankAccNo;
	
	@Column(name="GSTINID")
	private String gstinId;
	

	

	public BigInteger getBankAccDetailID() {
		return bankAccDetailID;
	}

	public void setBankAccDetailID(BigInteger bankAccDetailID) {
		this.bankAccDetailID = bankAccDetailID;
	}

	public String getBankAccNo() {
		return bankAccNo;
	}

	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}

	public String getGstinId() {
		return gstinId;
	}

	public void setGstinId(String gstinId) {
		this.gstinId = gstinId;
	}
	
	
}
