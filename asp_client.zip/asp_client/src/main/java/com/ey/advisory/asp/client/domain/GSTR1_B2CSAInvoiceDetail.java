package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import javax.persistence.*;

import com.ey.advisory.asp.common.Constant;

import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the tblB2CSAInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2CSAInvoiceDetails",schema=Constant.GSTR1_SCHEMA)
public class GSTR1_B2CSAInvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private long id;

	@Column(name="Category")
	private String category;

	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="Etin")
	private String etin;

	@Column(name="FileID")
	private long fileID;

	@Column(name="Flag")
	private String flag;

	@Column(name="Gstin")
	private String gstin;

	@Column(name="InvDate")
	private Date invDate;

	@Column(name="InvNum")
	private String invNum;

	@Column(name="InvoiceKey")
	private String invoiceKey;

	@Column(name="InvValue")
	private BigDecimal invValue;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="OrgInvDate")
	private Date orgInvDate;

	@Column(name="OrgInvNum")
	private String orgInvNum;

	@Column(name="OrgTaxPeriod")
	private String orgTaxPeriod;

	@Column(name="POS")
	private String pos;

	@Column(name="SubCategory")
	private String subCategory;

	@Column(name="TaxableValue")
	private BigDecimal taxableValue;

	@Column(name="TaxPeriod")
	private String taxPeriod;

	@Column(name="TcsFlag")
	private String tcsFlag;

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getEtin() {
		return this.etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Date getInvDate() {
		return this.invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getInvNum() {
		return this.invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public String getInvoiceKey() {
		return this.invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public BigDecimal getInvValue() {
		return this.invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public Date getOrgInvDate() {
		return this.orgInvDate;
	}

	public void setOrgInvDate(Date orgInvDate) {
		this.orgInvDate = orgInvDate;
	}

	public String getOrgInvNum() {
		return this.orgInvNum;
	}

	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	public String getOrgTaxPeriod() {
		return this.orgTaxPeriod;
	}

	public void setOrgTaxPeriod(String orgTaxPeriod) {
		this.orgTaxPeriod = orgTaxPeriod;
	}

	public String getPos() {
		return this.pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getSubCategory() {
		return this.subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public BigDecimal getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(BigDecimal taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getTcsFlag() {
		return this.tcsFlag;
	}

	public void setTcsFlag(String tcsFlag) {
		this.tcsFlag = tcsFlag;
	}

}