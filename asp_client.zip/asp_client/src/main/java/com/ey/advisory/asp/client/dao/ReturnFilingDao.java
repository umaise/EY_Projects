package com.ey.advisory.asp.client.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;

public interface ReturnFilingDao {
	

	public TblGstinRetutnFilingStatus fetchGstrReturnDetails(String gstinId,String taxMonth, String taxYear);

	public Date getReturnFilingDate(String fy, String sGSTIN, String returnName);
	
	public String insertGstr2AFilingStatus(List<String> outputParamList);
	/** 
	 * Method to insert status for gstr2a
	 * @param outputParamList
	 * @return
	 */
	public String insertGstr2AStatus(List<String> outputParamList);
	
	public List<TblGstinRetutnFilingStatus>  getReturnFilingDetails(List<String> returnPeriodList, List<String> returnType,String  gstin, String status, boolean eFiled);
	
	public TblGstinRetutnFilingStatus getReturnFilingDetails(String returnPeriod, String sGSTIN, String returnName, String status);
	
	public TblGstinRetutnFilingStatus getEFilingSummary(String returnPeriod, String sGSTIN, String returnName, String filedStatus, boolean isSuccess);
	
	public void insertReturnFilingData(String gstnId, String gstr1Filing, String taxPeriod, String acknowledge);

    public void saveGstinReturnFillingStatus(Set<String> custGSTINTaxPeriod);

	public String getReturnFilingSuccess(String gstinId, String taxPeriod,
			String gstrType);

	public List<TblGstinRetutnFilingStatus> getReturnFilingDetailsForGSTR1A(String returnPeriod, String returnName, String retFilingStatus, boolean status);

	public TblGstinRetutnFilingStatus gstr7FilingReturnDetails(String gstinId, String taxPeriod, String gstrType);

	public void updateReturnFilingDetailsForSubmit(String gstin, String txprd, String ref_id,
			String submitted) throws Exception;
	public String insertGstr2AReconFilingStatus(List<String> outputParamList);
	
	public List<TblGstinRetutnFilingStatus> loadDataFromTblGSTinReturnFillingStatus();

	// Trnsaction ID Polling starts
	public void updateReturnFilingStatus(Long filingId, String status);
	// Trnsaction ID Polling ends
	
	public String validateSavedStatus(String gstinId, String tax, String returnType);
	
	public boolean insertGstr3BSubmitStatus(String gstin,String taxPeriod);
	
	public boolean getGstr3BStatus(String gstin,String taxPeriod);
	
	public boolean saveAllGstinReturnFilingStatus(
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatusList);

	public void updateReturnFilingDetailsForSubmitGstr2(String gstin, String txprd, String ref_id,
			String submitted) throws Exception;
	
	List<TblGstinRetutnFilingStatus> getReturnFilingDetails(List<String> returnType, String gstin, String status,
			boolean eFiled);

	void updateReturnFilingStatusForSave(Long filingId, String status);
	
	public TblGstinRetutnFilingStatus getStatusFor2A(String gstinId,String taxPeriod, String status);
	public TblGstinRetutnFilingStatus checkGSTR2AEntry(String gstinId,String taxPeriod);
	
	TblGstinRetutnFilingStatus getStatusForReconReport(String gstinId, String taxPeriod, String status);

	public void updateReturnFilingDetailsForFiling(String gstinId,
			String taxPeriod, String gstrType, String acknowledge, String filed);
	
	public String getStatusFor1FF(String gstinId,String taxPeriod, String api);
	
	public TblGstinRetutnFilingStatus getStatusFor6A(String gstinId,String taxPeriod, String status);
	
	public TblGstinRetutnFilingStatus checkGSTR6AEntry(String gstinId,String taxPeriod);
	
	public String insertGstr6AStatus(List<String> outputParamList);
	
	public boolean getReturnFilingStatusForSaveGstrToGstn(String gstin,String taxPeriod,String returnType);

	public void updateReturnFilingStatus(String gstin, String taxPeriod, String returnType);
}
