package com.ey.advisory.asp.client.service;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.dto.CommonSearchDto;
import com.ey.advisory.asp.client.dto.ResultPage;


public interface EntityHeirarchyService {
	
	public List<EntityHierarchy> getEntityNames(String groupId);
	
	public void saveEntityHierarchy(EntityHierarchy entityHierarchy) throws Exception;

	public EntityHierarchy updateEntityHierarchy(EntityHierarchy entityHierarchyDTO) throws Exception;

	void deleteEntityHierarchy(String hierarchyId) throws Exception;

	List<Object[]> fetchHierarchyList(Long groupId);
	
	public ResultPage<EntityHierarchy> fetchHierarchyListPagination(CommonSearchDto searchDto);
	
	public Boolean checkIfDuplicateEntryExists(EntityHierarchy entityHierarchy) throws Exception;
	
	public EntityHierarchy loadEntityH(Integer id);

	public List fetchGstinList(String entityId);

	public List<EntityHierarchy> fetchByGSTIN(String gstin);
	
	public List<EntityHierarchy> fetchUserHierarchy(String accessLevel,String property, Object Value);

	List<EntityHierarchy> fetchEntityHierarchyList(String entityCode) throws Exception;

	public ResultPage<EntityHierarchy> fetchByHierarchyIdList(Map<Integer, String> hierarchyMap,
			CommonSearchDto commonSearchDto) throws Exception;
	
	public List<EntityHierarchy> fetchValues(String txt, String values);
	
	 public List<EntityHierarchy> fetchUserHierarchyUserTab(Integer accessLevelId,String accessLevel, String property, Object Value) ;
	 
	 public List<EntityHierarchy> getGstinsByEntityId(String entityCode);
	 
	 public List<EntityHierarchy> getGstinsByGroupCode(String groupCode);
	 
	 public List<EntityHierarchy> getEntityHierarchyByEntityID(Integer entityID);
	 
	 public List<EntityHierarchy> getEntityHierarchyByCircleCode(String circleCode);
 }
