package com.ey.advisory.asp.client.dao;

import org.json.simple.JSONObject;

public interface ReportDao {
	 public Object getErrorReportDetails(JSONObject gstinId);
	 public Object getRectifiedReportDetails(JSONObject obj);
	Object getGstr2AReportDetails(JSONObject jsonObj);
	 public Object getCounterpartyDetails(JSONObject gstinId);
}
