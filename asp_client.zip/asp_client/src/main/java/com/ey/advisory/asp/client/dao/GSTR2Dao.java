package com.ey.advisory.asp.client.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.ey.advisory.asp.client.domain.TblEmailStatusDetails;
import com.ey.advisory.asp.client.dto.InwardInvoiceDTO;
import com.ey.advisory.asp.client.domain.GSTR2B2BCLIAInvoiceDetails;
import com.ey.advisory.asp.client.domain.GlCodeMaster;
import com.ey.advisory.asp.client.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.client.domain.Gstr2B2BInvoiceDetailsModel;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.ReconProcessDTO;
import com.ey.advisory.asp.dto.LineItemDTO;

public interface GSTR2Dao {
	
	<T> List<T> validateOriginalDocNoDocDate(String docNum, Date date, String entityName, String column1,
			String column2);

	<T> List<T> validateOriginalDocumentNo(String originalDocumentNo, String entityName, String columnName);
	
	public Gstr2B2BInvoiceDetailsModel getReconInvoice(String entityName, String custGSTIN, String gstin, String invNum, Date invDate);

	public void updateReconFilingStatus(Object model);

	void updateITCValues(Set<LineItemDTO> redisLineItemSet);

	List<String> getGSTINListByPAN(String entityName, String custGSTINColumn, String gstinColumn,
			String invNumColumn, String invDateColumn, String custGSTIN, String PAN, String gstin, String invNum, Date invDate);

	public <T> T getReconInvoice(String entityName, String custGSTINColumn, String gstinColumn,
			String invNumColumn, String invDateColumn, String custGSTIN, String gstin, String invNum, Date invDate);

	public <T> T getReconInvoice(String entityName, String invoiceIdColumn, Long invoiceDetailsId);

	ItemMaster fetchHsnSacDetails(String hsnSac);

	GlobalGSTRatesMasterI fetchHsnSacDetailsFromGlobal(String hsnSac);

	public boolean isInvoiceNotPresentInGSTN(String invoiceKey);

	List<GSTR2B2BCLIAInvoiceDetails> getCreditListForInvoice(String originalDocumentNo, Date originalDocumentDate);

	List<GSTR2B2BCLIAInvoiceDetails> getRevisedCreditList(GSTR2B2BCLIAInvoiceDetails credit);

	public boolean isSingleInvoiceForCRDR(InwardInvoiceModel lineItem);

	<T> List<T> validateOriginalDocumentNoInGSTN(String originalDocumentNo, String entityName, String columnName);
	
	String getITCComputationXML(String taxperiod,String gstins);

	String getITCReversalXML(String taxPeriod, String gstinId);

	public GlCodeMaster getGLMasterByCode(String glCode);

	public void updateReconTaxLiability(String entityName, ReconProcessDTO processDTO);

	public void updateReconResult(Integer id, String reconFilingStatus);

	void updateReconStatus(Integer id, String reconStatus);
}
