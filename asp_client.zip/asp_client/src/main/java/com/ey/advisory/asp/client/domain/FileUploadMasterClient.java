package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "tblFileUpload", schema="etl")
public class FileUploadMasterClient implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FileId")
    private long fileId;

    @Column(name = "UserId")
    private long userId;

    @Column(name = "FName")
    private String fName;

    @Column(name = "Status")
    private String status;

    @Column(name = "Stage")
    private String stage;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UploadDt")
    private Date uploadDt;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UpdatedDt")
    private Date updateDt;

    public long getFileId() {
        return fileId;
    }

    public void setFileId(long fileId) {
        this.fileId = fileId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public Date getUploadDt() {
        return uploadDt;
    }

    public void setUploadDt(Date uploadDt) {
        this.uploadDt = uploadDt;
    }

    public Date getUpdateDt() {
        return updateDt;
    }

    public void setUpdateDt(Date updateDt) {
        this.updateDt = updateDt;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((fName == null) ? 0 : fName.hashCode());
        result = prime * result + (int) (fileId ^ (fileId >>> 32));
        result = prime * result + ((stage == null) ? 0 : stage.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((updateDt == null) ? 0 : updateDt.hashCode());
        result = prime * result + ((uploadDt == null) ? 0 : uploadDt.hashCode());
        result = prime * result + (int) (userId ^ (userId >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        FileUploadMasterClient other = (FileUploadMasterClient) obj;
        if (fName == null) {
            if (other.fName != null)
                return false;
        }
        else if (!fName.equals(other.fName))
            return false;
        if (fileId != other.fileId)
            return false;
        if (stage == null) {
            if (other.stage != null)
                return false;
        }
        else if (!stage.equals(other.stage))
            return false;
        if (status == null) {
            if (other.status != null)
                return false;
        }
        else if (!status.equals(other.status))
            return false;
        if (updateDt == null) {
            if (other.updateDt != null)
                return false;
        }
        else if (!updateDt.equals(other.updateDt))
            return false;
        if (uploadDt == null) {
            if (other.uploadDt != null)
                return false;
        }
        else if (!uploadDt.equals(other.uploadDt))
            return false;
        if (userId != other.userId)
            return false;
        return true;
    }

}
