package com.ey.advisory.asp.client.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.client.dao.InvoiceDao;

@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceService {
	
	@Autowired
	private InvoiceDao invoiceDao;
	
	@Override
	public boolean markTechErrorInvoiceStatus(Integer fileId) throws Exception {
		return invoiceDao.markTechErrorInvoiceStatus(fileId);
	}
	
}
