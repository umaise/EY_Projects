package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="tblGstinDetails" , schema="master")
@NamedQuery(name="TblGstinDetailsDomain.findAll", query="SELECT t FROM TblGstinDetailsDomain t")
public class TblGstinDetailsDomain implements Serializable{
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="Gstin", unique=true, nullable=false)
    private String gstinId;
    
    
    @Column(name="GSTNUserName", nullable=false)
    private String  gSTNUserName;
    
    
    @Column(name="IsRegCertificate", nullable=true)
    private Boolean isRegCertificate;
    
    @Column(name="EntityID", nullable =false)
    private Integer entityID;
    
    @Column(name="StateCode", nullable=true)
    private String stateCode;
    
    @Column(name="TurnOverAmount", nullable=true)
    private Double turnOverAmount;
    
    @Column(name="IsActive", nullable=true)
    private Boolean isActive;
    
    
    @Column(name="TypeOfReg", nullable=true)
    private String typeOfReg;
    
    @Column(name="CreatedBy", nullable=true)
    private String createdBy;
     
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
    @Column(name="CreatedDate", nullable=true)
    private Date createdDate;
    
    @Column(name="UpdatedBy", nullable=true)
    private String updatedBy;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    @Column(name="UpdatedDate", nullable=true)
    private Date updatedDate;
    
    @Column(name="RegDate", nullable=true)
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
    @Temporal(TemporalType.DATE) 
    private Date regdt;
    
    @Transient
    private Double quarterTurnOvrAmt;
    
    @Column(name="RegMobileNumber")
    private String regMobileNumber;
    
    
    @Column(name="BankAccountNumber", nullable=true)
    private String bankAccountNumber;
    
    
    /**
     * @return the regMobileNumber
     */
    public String getRegMobileNumber() {
        return regMobileNumber;
    }

    /**
     * @return the bankAccountNumber
     */
    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    /**
     * @param regMobileNumber the regMobileNumber to set
     */
    public void setRegMobileNumber(String regMobileNumber) {
        this.regMobileNumber = regMobileNumber;
    }

    /**
     * @param bankAccountNumber the bankAccountNumber to set
     */
    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public Date getRegdt() {
        return regdt;
    }

    public void setRegdt(Date regdt) {
        this.regdt = regdt;
    }


    /**
     * @return the gstinId
     */
    public String getGstinId() {
        return gstinId;
    }

    /**
     * @return the gSTNUserName
     */
    public String getgSTNUserName() {
        return gSTNUserName;
    }

    /**
     * @return the isRegCertificate
     */
    public Boolean getIsRegCertificate() {
        return isRegCertificate;
    }

    /**
     * @return the entityID
     */
    public Integer getEntityID() {
        return entityID;
    }

    /**
     * @return the stateCode
     */
    public String getStateCode() {
        return stateCode;
    }

    /**
     * @return the turnOverAmount
     */
    public Double getTurnOverAmount() {
        return turnOverAmount;
    }

    /**
     * @return the isActive
     */
    public Boolean getIsActive() {
        return isActive;
    }

    /**
     * @return the typeOfReg
     */
    public String getTypeOfReg() {
        return typeOfReg;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param gstinId the gstinId to set
     */
    public void setGstinId(String gstinId) {
        this.gstinId = gstinId;
    }

    /**
     * @param gSTNUserName the gSTNUserName to set
     */
    public void setgSTNUserName(String gSTNUserName) {
        this.gSTNUserName = gSTNUserName;
    }

    /**
     * @param isRegCertificate the isRegCertificate to set
     */
    public void setIsRegCertificate(Boolean isRegCertificate) {
        this.isRegCertificate = isRegCertificate;
    }

    /**
     * @param entityID the entityID to set
     */
    public void setEntityID(Integer entityID) {
        this.entityID = entityID;
    }

    /**
     * @param stateCode the stateCode to set
     */
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    /**
     * @param turnOverAmount the turnOverAmount to set
     */
    public void setTurnOverAmount(Double turnOverAmount) {
        this.turnOverAmount = turnOverAmount;
    }

    /**
     * @param isActive the isActive to set
     */
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    /**
     * @param typeOfReg the typeOfReg to set
     */
    public void setTypeOfReg(String typeOfReg) {
        this.typeOfReg = typeOfReg;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

	public Double getQuarterTurnOvrAmt() {
		return quarterTurnOvrAmt;
	}

	public void setQuarterTurnOvrAmt(Double quarterTurnOvrAmt) {
		this.quarterTurnOvrAmt = quarterTurnOvrAmt;
	}


}
