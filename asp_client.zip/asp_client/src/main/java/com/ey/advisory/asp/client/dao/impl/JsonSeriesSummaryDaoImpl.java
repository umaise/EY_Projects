package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.JsonSeriesSummaryDao;
import com.ey.advisory.asp.client.domain.JsonSeriesofSummaryData;
import com.ey.advisory.asp.common.Constant;

@Repository
public class JsonSeriesSummaryDaoImpl implements JsonSeriesSummaryDao {

	private static final Logger logger = Logger
			.getLogger(JsonSeriesSummaryDaoImpl.class);
	private static final String CLASS_NAME = JsonSeriesSummaryDaoImpl.class
			.getName();

	@Autowired
	HibernateDao hibernateDao;

	
	@Override
	public List<JsonSeriesofSummaryData> getJsonSeriesSummaryMetadata() {
		List<JsonSeriesofSummaryData> jsoneSeriesList = new ArrayList<>();
		
		if(logger.isDebugEnabled()){
		logger.debug(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " getJsonSeriesSummaryMetadata");
		}
		try {
			jsoneSeriesList = (List<JsonSeriesofSummaryData>)hibernateDao.loadAll(JsonSeriesofSummaryData.class);
			
			if(logger.isDebugEnabled()){
			logger.debug(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " getJsonSeriesSummaryMetadata");
			}
		} catch (Exception e) {
			
			if(logger.isDebugEnabled()){
			logger.debug(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD + " getJsonSeriesSummaryMetadata"
					+ e);
			}
		}
		return jsoneSeriesList;
	}
}
