package com.ey.advisory.asp.client.dao.impl;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;




import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.jdbc.Work;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.client.dao.HibernateDao;

@Repository
public class HibernateDaoImpl implements HibernateDao {

	final private HibernateTemplate hibernateTemplate;
	private static final Logger logger = Logger.getLogger(HibernateDaoImpl.class);

	@Autowired
	public HibernateDaoImpl(final SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}

	@Override
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}
	
	public Object get(String entityName, final Serializable id) {
		return hibernateTemplate.load(entityName, id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#load(java.lang.Class,
	 * java.io.Serializable)
	 */
	@Override
	public <T> T load(final Class<T> entityName, final Serializable id) {
		return hibernateTemplate.load(entityName, id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#loadAll(java.lang.Class)
	 */
	@Override
	public <T> List<T> loadAll(final Class<T> entityName) {
		return hibernateTemplate.loadAll(entityName);
	}

	@Override
	public <T> List<T> loadAllByNamedQuery(String queryName) {
		return (List<T>) hibernateTemplate.findByNamedQuery(queryName);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#save(java.lang.Object)
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public <T> Serializable save(final T entity) {
		return hibernateTemplate.save(entity);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.util.Persistence#saveOrUpdateAll(java.util.
	 * Collection)
	 */
	@Override
	public <E> void saveOrUpdateAll(final Collection<E> entities) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				for (Iterator<E> it = entities.iterator(); it.hasNext();) {
					session.saveOrUpdate(it.next());
				}
				return null;
			}

		});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#update(java.lang.Object)
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW, readOnly=false)
	public <T> void update(final T entity) {
		hibernateTemplate.update(entity);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#delete(java.lang.Object)
	 */
	@Override
	public <T> void delete(final T entity) {
		hibernateTemplate.delete(entity);
		hibernateTemplate.flush();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#deleteAll(java.util.
	 * Collection)
	 */
	@Override
	public <E> void deleteAll(final Collection<E> entities) {
		hibernateTemplate.deleteAll(entities);
		hibernateTemplate.flush();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#merge(java.lang.Object)
	 */
	@Override
	public <T> T merge(final T entity) {
		return hibernateTemplate.merge(entity);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.util.Persistence#createCriteria(java.lang.
	 * Class)
	 */
	@Override
	public <T> DetachedCriteria createCriteria(final Class<T> entityName) {
		return DetachedCriteria.forClass(entityName);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.util.Persistence#createCriteria(java.lang.
	 * Class)
	 */
	@Override
	public <T> DetachedCriteria createCriteria(final Class<T> entityName, String alias) {
		return DetachedCriteria.forClass(entityName, alias);
	}
	
	@Override
	public <T> Criteria createNormalCriteria(final Class<T> entityName, String alias) {
		
		return hibernateTemplate.getSessionFactory().getCurrentSession().createCriteria(entityName, alias);
	}
	
	@Override
	public <T> Criteria createNormalCriteria(final Class<T> entityName) {
		
		return hibernateTemplate.getSessionFactory().getCurrentSession().createCriteria(entityName);
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.util.Persistence#find(org.hibernate.criterion.
	 * DetachedCriteria)
	 */
	@Override
	public List<?> find(final DetachedCriteria criteria) {
		return hibernateTemplate.findByCriteria(criteria);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#find(java.lang.String,
	 * java.lang.Object[])
	 */
	@Override
	public List<?> find(final String query, final Object... values) {
		return hibernateTemplate.find(query, values);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#saveOrUpdate(java.lang.
	 * Object)
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW, readOnly=false)
	public <T> void saveOrUpdate(final T entity) {
		hibernateTemplate.saveOrUpdate(entity);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.util.Persistence#bulkUpdate(java.lang.String,
	 * java.lang.Object[])
	 */
	@Override
	public void bulkUpdate(final String query, final Object... values) {
		hibernateTemplate.bulkUpdate(query, values);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#executeQuery(java.lang.
	 * String)
	 */

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> executeNativeSql(final String query, Class<T> classType, final Object... values) {
		return (List<T>) hibernateTemplate.execute(new HibernateCallback<List<?>>() {
			@Override
			public List<?> doInHibernate(Session session) throws HibernateException {
				int i = 0;
				SQLQuery sqlQuery = session.createSQLQuery(query);
				sqlQuery.addEntity(classType);
				if (null != values) {
					for (Object parameterValue : values) {
						sqlQuery.setParameter(i++, parameterValue);
					}
				}

				return sqlQuery.list();
			}
		});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.util.Persistence#executeNativeSqlNoReturn(java
	 * .lang.String, java.lang.Object[])
	 */
	@Override
	public void executeNativeSqlNoReturn(final String query, final Object... values) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				int i = 0;
				SQLQuery sqlQuery = session.createSQLQuery(query);
				if (null != values) {
					for (Object parameterValue : values) {
						sqlQuery.setParameter(i++, parameterValue);
					}
				}
				sqlQuery.executeUpdate();
				return null;
			}
		});

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.client.util.Persistence#executeQuery(java.lang.
	 * String)
	 */
	@Override
	public List<?> executeNativeSql(final String query, final Object... values) {
		return hibernateTemplate.execute(new HibernateCallback<List<?>>() {
			@Override
			public List<?> doInHibernate(Session session) throws HibernateException {
				int i = 0;
				SQLQuery sqlQuery = session.createSQLQuery(query);
				if (null != values) {
					for (Object parameterValue : values) {
						sqlQuery.setParameter(i++, parameterValue);
					}
				}

				return sqlQuery.list();
			}
		});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.util.Persistence#executeProcedure(java.lang.
	 * String, java.util.List)
	 */
	@SuppressWarnings("deprecation")
	@Override
	public void executeProcedureNoReturn(final String sql, List<Object> parameterList) throws SQLException {
		Session session=null;
		try{
			
			session=hibernateTemplate.getSessionFactory().openSession();
			
			session.doWork(new Work() {
				CallableStatement cst = null;

				@Override
				public void execute(Connection con) throws SQLException {
					try {
						cst = con.prepareCall(sql);
						int index = 1;
						if (parameterList != null) {
							for (Object parameterValue : parameterList) {
								cst.setObject(index++, parameterValue);
							}
						}
						cst.execute();
					} finally {
						if (cst != null) {
							cst.close();
						}
						if (con != null) {
							con.close();
						}
					}
				}

			});
		}catch(Exception ex){
			logger.error("Exception in HibernateDaoImpl while executing executeStoredProcedureReturnList is "+ex);
		}finally{
			if(session!=null){
				try{
				session.close();}
				catch(Exception e ){
					logger.error("Exception in HibernateDaoImpl while executing executeStoredProcedureReturnList is "+e);
				}
			}
		}
	}

	@Override
	public String executeStoredProcedure(String storedProcSchema, String storedProcName, String inputParamsCount,
			List<String> inputParamsList) {
		StringBuilder procStatus=new StringBuilder();
		List<?> result = null;
		SQLQuery query;
		Session session=null;
		try{
		if (Integer.parseInt(inputParamsCount) == inputParamsList.size()) {

			StringBuilder queryString = new StringBuilder();
			queryString.append("exec ").append(storedProcSchema + "." + storedProcName);
			for (int i = 0; i < Integer.parseInt(inputParamsCount); i++) {
				if (i == 0) {
					queryString.append(" ?");
				} else {
					queryString.append(",? ");
				}
			}
			session=hibernateTemplate.getSessionFactory().openSession();
			query = session.createSQLQuery(queryString.toString());
			for (int i = 0; i < inputParamsList.size(); i++) {
				query.setString(i, inputParamsList.get(i));
			}
			result = query.list();
			if(result!=null && !result.isEmpty()){
				procStatus = new StringBuilder();
			for(int i=0;i<result.size();i++){
				procStatus.append(result.get(i));
			}
			}
			return procStatus.toString();

		} else {
			return "Can not call Stored Proc, Input parameters count and Input params list size is not equal";
		  }
		}catch(Exception e){
			logger.error("Exception in HibernateDaoImpl while executing "+storedProcName+"Exception is "+e);
			return "Failed";
		}finally{
			if(session!=null){
				try{
				session.close();}
				catch(Exception e ){
					logger.error("Exception in HibernateDaoImpl while executing executeStoredProcedureReturnList is "+e);
				}
			}
		}
	}

	@Override
	public void bulkUpdate(String hqlString) {

		hibernateTemplate.bulkUpdate(hqlString);

	}

	@Override
	public List<?> findByCriteria(final DetachedCriteria criteria, int firstResult, int maxResults) {
		return hibernateTemplate.findByCriteria(criteria, firstResult, maxResults);
	}

	/*
	 * Execute an HQL query, binding a number of values to ":" named parameters
	 * in the query string.
	 */
	@Override
	public List<?> findByNamedParam(String queryString, String[] paramNames, Object[] values) {
		return hibernateTemplate.findByNamedParam(queryString, paramNames, values);
	}

	@Override
	public SessionFactory getFactory() {

		return (SessionFactory) hibernateTemplate.getSessionFactory().getCurrentSession();

	}

	@Override
	public Session getSession() {
		return hibernateTemplate.getSessionFactory().openSession();
	}

	@Override
	public List executeStoredProcedureReturnList(String storedProcSchema, String storedProcName,
			String inputParamsCount, List<String> inputParamsList) {
		
		List list=new ArrayList();
		Session session=null;
		try{
			if (Integer.parseInt(inputParamsCount) == inputParamsList.size()) {

				StringBuilder queryString = new StringBuilder();
				queryString.append("exec ").append(storedProcSchema + "." + storedProcName);
				for (int i = 0; i < Integer.parseInt(inputParamsCount); i++) {
					if (i == 0) {
						queryString.append(" ?");
					} else {
						queryString.append(",? ");
					}
				}
				
				session=hibernateTemplate.getSessionFactory().openSession();
				
				SQLQuery query = session.createSQLQuery(queryString.toString());
				
				for (int i = 0; i < inputParamsList.size(); i++) {
					query.setString(i, inputParamsList.get(i));
				}
				list= query.list();
			} else {
				return new ArrayList();
			}
		}catch(Exception ex){
			logger.error("Exception in HibernateDaoImpl while executing executeStoredProcedureReturnList is "+ex);
		}finally{
			if(session!=null){
				try{
				session.close();}
				catch(Exception e ){
					logger.error("Exception in HibernateDaoImpl while executing executeStoredProcedureReturnList is "+e);
					
				}
			}
		}
		return list;
		
	}

}