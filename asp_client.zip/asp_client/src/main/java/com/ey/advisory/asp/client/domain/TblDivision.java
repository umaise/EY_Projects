package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.google.gson.annotations.SerializedName;

/**
 * @author Shreya.Mukund
 *
 */
@Entity
@Table(name = "tblDivision", schema="master")
public class TblDivision implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DivisionID")
	@SerializedName("DivisionID")
	private int divisionID;
	

	@Column(name="EntityID")
	@SerializedName("EntityID")
	private int entityID;
	
	@Column(name="DivisionName")
	@SerializedName("DivisionName")
	private String divisionName;
		
	@Column(name="GrossTurnOver")
	@SerializedName("GrossTurnOver")
	private BigDecimal grossTurnOver;
	
	@Column(name="CreatedBy")
	@SerializedName("CreatedBy")
	private String createdBy; 	
	
	@Column(name="CreatedDate")
	@SerializedName("CreatedDate")
	private Date createdDate;
	
	@Column(name="UpdatedBy")
	@SerializedName("UpdatedBy")
	private String updatedBy; 	
	
	@Column(name="UpdatedDate")
	@SerializedName("UpdatedDate")
	private Date updatedDate;

	
	public int getEntityID() {
		return entityID;
	}

	public void setEntityID(int entityID) {
		this.entityID = entityID;
	}

	
	public BigDecimal getGrossTurnOver() {
		return grossTurnOver;
	}

	public void setGrossTurnOver(BigDecimal grossTurnOver) {
		this.grossTurnOver = grossTurnOver;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public int getDivisionID() {
		return divisionID;
	}

	public void setDivisionID(int divisionID) {
		this.divisionID = divisionID;
	}

	public String getDivisionName() {
		return divisionName;
	}

	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}

}	
