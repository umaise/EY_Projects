package com.ey.advisory.asp.client.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.ClientDraftDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.ClientDraftData;
import com.ey.advisory.asp.client.domain.EntityModel;

@Repository
public class ClientDraftDaoImpl implements ClientDraftDao{

	@Autowired
	private HibernateDao hibernateDao;
	
	private static final Logger logger = Logger.getLogger(ClientDraftDaoImpl.class);

	@Override
	public List<ClientDraftData> loadDraftDataByBoardingId(ClientDraftData draftObj) {
		List<ClientDraftData> resultList = null;
		try {
			 DetachedCriteria criteria = hibernateDao.createCriteria(ClientDraftData.class);
			 criteria.add(Restrictions.eq("onBoardingID",draftObj.getOnBoardingID()));
			 resultList = (List<ClientDraftData>)hibernateDao.find(criteria);
		} catch (Exception e) {
			
			
			logger.error("Exception in loadDraftDataByBoardingId"+e);
			
		}
		return resultList;
	}

	@Override
	public List<ClientDraftData> loadAllDraftData(ClientDraftData draftObj) {
		List<ClientDraftData> resultList = null;
		try {
			 DetachedCriteria criteria = hibernateDao.createCriteria(ClientDraftData.class);
			 resultList = (List<ClientDraftData>)hibernateDao.find(criteria);
		} catch (Exception e) {
			logger.error("Exception in loadAllDraftData"+e);
		}
		return resultList;
	}

	@Override
	public String getEntityCode(Integer entityId) {
		List<Object[]> resultList = null;
		try {
			 DetachedCriteria criteria = hibernateDao.createCriteria(EntityModel.class);
			 criteria.add(Restrictions.eq("entityID",entityId));
			 criteria.setProjection(Projections.property("entityCode"));
			 resultList = (List<Object[]>)hibernateDao.find(criteria);
			 if(resultList!=null && !resultList.isEmpty())
			 {
				 String eCode= String.valueOf(resultList.get(0));
				 return eCode;
			 }
		} catch (Exception e) {
			
			logger.error("Exception in getEntityCode"+e);
		
		}
		return "E1";
	}

}
