package com.ey.advisory.asp.client.dto;

import java.util.List;

import com.ey.advisory.asp.client.dto.SalePurchasedto;

public class ParentSalePurchaseDto {

	private String type;
	private String name;
	List<SalePurchasedto> rate;
	
	
	
	public ParentSalePurchaseDto(String type, String name, List<SalePurchasedto> rate) {
		super();
		this.type = type;
		this.name = name;
		this.rate = rate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<SalePurchasedto> getRate() {
		return rate;
	}
	public void setRate(List<SalePurchasedto> rate) {
		this.rate = rate;
	}
	
	
	
	
	
}
