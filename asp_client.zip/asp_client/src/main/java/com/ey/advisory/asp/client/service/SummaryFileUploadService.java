package com.ey.advisory.asp.client.service;

import com.ey.advisory.asp.client.domain.SummaryFileLoadMaster;

public interface SummaryFileUploadService {

	public String insertSummaryFileUpload(
			SummaryFileLoadMaster summaryFileLoadMaster);

	public String updateSummaryFileLoadMaster(String status, int summaryFileId,int recordCount);

}
