package com.ey.advisory.asp.client.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.DueDateMasterDao;
import com.ey.advisory.asp.client.domain.DueDateMaster;


@Service
public class DueDateMasterServiceImpl implements DueDateMasterService{
	
	@Autowired
	DueDateMasterDao dao;

	@Override
	public List<DueDateMaster> getGstinDueDateMaster(List<String> returnType, String gstin) {
		return dao.getGstinDueDateMaster(returnType, gstin);
	}

	@Override
	public String getGstinReturnType(String gstin) {
		return dao.getGstinReturnType(gstin);
	}
	
}
