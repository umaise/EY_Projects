package com.ey.advisory.asp.client.dao;

import org.json.simple.JSONObject;

public interface GSTR3bDao {
	 public String getGSTR3bSummaryDetails(JSONObject obj);
	 
	 public void freezeRecordsFor3b();
}
