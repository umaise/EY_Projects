package com.ey.advisory.asp.client.service;

import java.util.List;
import java.util.Map;
import com.ey.advisory.asp.client.domain.DueDateMaster;
import com.ey.advisory.asp.client.domain.InvoiceKeyDetail;
import com.ey.advisory.asp.client.domain.ReturnUpload;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.dto.Gstr3Dto;
import com.ey.advisory.asp.client.dto.TechReconDTO;
import com.ey.advisory.asp.client.dto.TransactionIDPolling;

public interface GSTINDetailsService {
	
	/**
	 * To fetch GSTIN details from table tblGSTINDetails
	 * @return 
	 */
	public Map<String, TblGstinDetailsDomain> fetchGstinDetails();
	
	/**
	 * To fetch GSTIN details from table tblGSTINDetails for a particular gstinId
	
	 */
	public TblGstinDetailsDomain fetchGstinDetails(String gstinId);
	
	public List fetchGstinDetailsForUser(String userId);
	
	public List<DueDateMaster> fetchGstinReturnTypes(List<String> gstins);
	
	public String getLedgerDetails(Gstr3Dto gstr3dto);
 
	public List<TblGstinDetailsDomain> fetchGstinDetails(List<String> gstinId);
	
	public List<Object> getGstinUserName(String gstinId);
	
	//Trnsaction ID Polling starts 
	public List<TransactionIDPolling> getTransactionIDPollingList(boolean isSummary);
	
	public void updateGstnStatusToReturnUpload(Long filingId, String trxId, String refId, Long loadId,  String status, String errorMsg,String gstin,String gstnStatus,String ErrorDesc, boolean isSummary);
	
	void updateReturnFilingStatusForSummary();
	
	void updateReturnFilingStatus();
	//Trnsaction ID Polling ends
	public List<Object[]> fetchAllActiveGstinList();

	
	void updateGstnStatusToTblReturnFillingstatus(Long filingId, String trxId, String refId, Long loadId, String status,
			String errorMsg, boolean isSummary);

	List<TransactionIDPolling> getTransactionPollingSubmitList(boolean isSummary);
	
	List<TblGstinDetailsDomain> getGstinDetailsByEntity(Integer entityId);

	//public void updateReturnFilingStatusForSave();
	
	public void updateReturnFilingStatusForSave(List<Long> transactionIDPollingList);
	
	public List<ReturnUpload> getChunkStatusAfterSave(String gstin,String taxperiod,String returnType);
	public Object getChunkStatusAfterSave(String gstin,String taxperiod,String returnType, String refId);

	public List<TechReconDTO> getTechReconDTOList();


}
