package com.ey.advisory.asp.client.util;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import com.ey.advisory.asp.client.dto.AuthDetailsDto;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.common.Constant;

@Configuration
public class AuthenticationUtility {

	private static final Logger LOGGER = Logger
			.getLogger(AuthenticationUtility.class);
	private static final String CLASS_NAME = AuthenticationUtility.class
			.getName();

	@Autowired
	GSTNRestUtility gstnRestUtility;

	/**
	 * @return
	 */
	public static AuthDetailsDto produceSampleData() {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : produceSampleData");
		}
		String encryptedAppkey = null;
		String encryptedOtp = null;
		String appkey = null;
		AuthDetailsDto dto = null;
		try {
			appkey = CrypticUtility.generateSecureKey();
			if(LOGGER.isDebugEnabled()){
			LOGGER.debug("App key in encoded : " + appkey);
			}
			encryptedAppkey = CrypticUtility.generateEncAppkey(CrypticUtility
					.decodeBase64StringTOByte(appkey));
			if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Encrypted App Key ->" + encryptedAppkey);
			}
			String otp = "102030";
			encryptedOtp = CrypticUtility.encryptEK(otp.getBytes(),
					CrypticUtility.decodeBase64StringTOByte(appkey));
			if(LOGGER.isDebugEnabled()){
			LOGGER.debug("OTP :" + encryptedOtp);
			}
			dto = new AuthDetailsDto();
			dto.setAppKey(appkey);
			dto.setEncryptedAppKey(encryptedAppkey);
			dto.setEncryptedOTP(encryptedOtp);
		} catch (Exception e) {
			LOGGER.error("Error in produceSampleData : " ,e);
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Exiting" + CLASS_NAME + " Method : produceSampleData");
		}
		return dto;
	}

	/**
	 * @param decryptedAppkey
	 * @param receivedSEK
	 * @param data
	 * @return
	 */
	public static AuthDetailsDto testDataForPut(String decryptedAppkey,
			String receivedSEK, String data) {
			if(LOGGER.isInfoEnabled())
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : testDataForPut");
		}
		AuthDetailsDto authDetails = new AuthDetailsDto();

		byte[] authEK = null;
		String hmac = null;
		String encryptedData = null;
		try {
			if (("").equals(data)) {
				data = "[{\"gstin\":\"06AAMFS3061K1Z7\",\"fp\":\"052017\",\"gt\":0,\"b2cl\":[{\"state_cd\":\"19\",\"inv\":[{\"cname\":\"Basana Ceramics\",\"inum\":\"UD01600007\",\"idt\":\"2016-04-24\",\"val\":271360.00,\"pos\":\"We\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":28320.00,\"irt\":0.18,\"iamt\":4320.00,\"camt\":0.00,\"samt\":0.00},{\"num\":2,\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":243040.00,\"irt\":0.12,\"iamt\":26040.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"19\",\"inv\":[{\"cname\":\"Manuj Electricals\",\"inum\":\"BP01800013\",\"idt\":\"2017-04-19\",\"val\":295000.00,\"pos\":\"We\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"20\",\"inv\":[{\"cname\":\"Manuj Electricals\",\"inum\":\"UD01600002\",\"idt\":\"2016-04-12\",\"val\":277360.00,\"pos\":\"Jh\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":146320.00,\"irt\":0.18,\"iamt\":22320.00,\"camt\":0.00,\"samt\":0.00},{\"num\":2,\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":131040.00,\"irt\":0.12,\"iamt\":14040.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"28\",\"inv\":[{\"cname\":\"Vijaynagar Realtors\",\"inum\":\"BP01800012\",\"idt\":\"2017-04-23\",\"val\":295000.00,\"pos\":\"An\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"28\",\"inv\":[{\"cname\":\"Vijaynagar Realtors\",\"inum\":\"UD01600001\",\"idt\":\"2017-04-18\",\"val\":403560.00,\"pos\":\"An\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":141600.00,\"irt\":0.18,\"iamt\":21600.00,\"camt\":0.00,\"samt\":0.00},{\"num\":2,\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":261960.00,\"irt\":0.18,\"iamt\":39960.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"7 \",\"inv\":[{\"cname\":\"Everex Enterprises\",\"inum\":\"BP01800020\",\"idt\":\"2017-04-24\",\"val\":295000.00,\"pos\":\"De\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]}],\"b2cla\":[{\"state_cd\":\"19\",\"inv\":[{\"cname\":\"Manuj Electricals\",\"num\":\"UD01500362\",\"dt\":\"2016-03-11\",\"val\":368160.00,\"pos\":\"We\",\"onum\":\"UD01500362\",\"odt\":\"2016-03-11\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":169920.00,\"irt\":0.18,\"iamt\":25920.00,\"camt\":0.00,\"samt\":0.00},{\"num\":2,\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":198240.00,\"irt\":0.12,\"iamt\":21240.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"9 \",\"inv\":[{\"cname\":\"Mahalaxmi Enterprise\",\"num\":\"BP01900008\",\"dt\":\"2017-04-30\",\"val\":295000.00,\"pos\":\"Ut\",\"onum\":\"BP01400008\",\"odt\":\"2017-03-23\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"9 \",\"inv\":[{\"cname\":\"Mahalaxmi Enterprise\",\"num\":\"BP01900009\",\"dt\":\"2017-04-30\",\"val\":295000.00,\"pos\":\"Ut\",\"onum\":\"BP01900009\",\"odt\":\"2017-03-24\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]}],\"b2cs\":[{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":59000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":4500.00,\"srt\":0.09,\"samt\":4500.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"irt\":0.18,\"iamt\":36000.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":147500.00,\"irt\":0.18,\"iamt\":22500.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"irt\":0.18,\"iamt\":36000.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"irt\":0.18,\"iamt\":36000.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"19\",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":241900.00,\"irt\":0.18,\"iamt\":36900.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":206500.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":15750.00,\"srt\":0.09,\"samt\":15750.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":236000.00,\"irt\":0.18,\"iamt\":36000.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"29\",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":206500.00,\"irt\":0.18,\"iamt\":31500.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"29\",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":238360.00,\"irt\":0.18,\"iamt\":36360.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":280000.00,\"iamt\":0.00,\"crt\":0.06,\"camt\":15000.00,\"srt\":0.06,\"samt\":15000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":280000.00,\"iamt\":0.00,\"crt\":0.06,\"camt\":15000.00,\"srt\":0.06,\"samt\":15000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":280000.00,\"iamt\":0.00,\"crt\":0.06,\"camt\":15000.00,\"srt\":0.06,\"samt\":15000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":104720.00,\"iamt\":0.00,\"crt\":0.06,\"camt\":5610.00,\"srt\":0.06,\"samt\":5610.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":236320.00,\"irt\":0.12,\"iamt\":25320.00,\"camt\":0.00,\"samt\":0.00}],\"b2csa\":[{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"9 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":147500.00,\"irt\":0.18,\"iamt\":22500.00,\"camt\":0.00,\"samt\":0.00}],\"exp\":[{\"ex_tp\":\"With payment of GST\",\"inv\":[{\"num\":\"EX01600058\",\"dt\":\"2016-04-17\",\"val\":596624.00,\"sbnum\":\"31117500455\",\"sbdt\":\"2016-04-20\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":913320.00,\"irt\":0.18,\"iamt\":139320.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":596624.00,\"irt\":0.12,\"iamt\":63924.00,\"samt\":0.00}]}]},{\"ex_tp\":\"With payment of GST\",\"inv\":[{\"num\":\"EX01600058\",\"dt\":\"2016-04-17\",\"val\":913320.00,\"sbnum\":\"31117500455\",\"sbdt\":\"2016-04-20\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":913320.00,\"irt\":0.18,\"iamt\":139320.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":596624.00,\"irt\":0.12,\"iamt\":63924.00,\"samt\":0.00}]}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01600057\",\"dt\":\"2017-04-11\",\"val\":762300.00,\"sbnum\":\"12145363293\",\"sbdt\":\"2016-04-14\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":1350000.00,\"iamt\":0.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":762300.00,\"iamt\":0.00,\"samt\":0.00}]}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01600057\",\"dt\":\"2017-04-11\",\"val\":1350000.00,\"sbnum\":\"12145363293\",\"sbdt\":\"2016-04-14\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":1350000.00,\"iamt\":0.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":762300.00,\"iamt\":0.00,\"samt\":0.00}]}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01600067\",\"dt\":\"2016-04-23\",\"val\":532700.00,\"sbnum\":\"20519150788\",\"sbdt\":\"2016-04-24\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":774000.00,\"iamt\":0.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":532700.00,\"iamt\":0.00,\"samt\":0.00}]}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01600067\",\"dt\":\"2016-04-23\",\"val\":774000.00,\"sbnum\":\"20519150788\",\"sbdt\":\"2016-04-24\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":774000.00,\"iamt\":0.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":532700.00,\"iamt\":0.00,\"samt\":0.00}]}]}],\"expa\":[{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01500166\",\"dt\":\"2016-01-14\",\"val\":460000.00,\"sbnum\":\"13445363293\",\"sbdt\":\"2016-01-18\"}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01500166\",\"dt\":\"2016-01-14\",\"val\":1550000.00,\"sbnum\":\"13445363293\",\"sbdt\":\"2016-01-18\"}]}],\"ata\":[{\"octin\":\"06AECPG5123Q0Z1\",\"ocname\":\"Lakshi Sales Enterprise\",\"odoc_num\":\"AD01500133\",\"odoc_dt\":\"2017-03-07\",\"ctin\":\"06AECPG5123Q0Z1\",\"cname\":\"Lakshi Sales Enterprise\",\"supst_cd\":\"6 \",\"doc_num\":\"AD01600133\",\"doc_dt\":\"2017-03-07\",\"adamt\":177000.00,\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"crt\":0.09,\"camt\":2700.00,\"srt\":0.09,\"samt\":2700.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"crt\":0.09,\"camt\":10800.00,\"srt\":0.09,\"samt\":10800.00}]}],\"txpd\":[{\"num\":\"BP01600002\",\"doc_num\":\"7912562323\",\"doc_dt\":\"2017-03-19\",\"crt\":0.09,\"camt\":5000.00,\"srt\":0.09,\"samt\":5000.00},{\"num\":\"BP01600002\",\"doc_num\":\"7912562323\",\"doc_dt\":\"2017-03-19\",\"crt\":0.09,\"camt\":8000.00,\"srt\":0.09,\"samt\":8000.00}],\"ecom_invocies\":[{\"ecom_ty\":\"INTER\",\"eInvoices\":[{\"txprd\":\"052017\",\"grsval\":360760.00,\"ctin\":\"29AQUPM3403D2Z4\"}]},{\"ecom_ty\":\"INTER\",\"eInvoices\":[{\"txprd\":\"052017\",\"mid\":\"HR231982\",\"grsval\":1760560.00,\"ctin\":\"NA\"}]},{\"ecom_ty\":\"INTRA\",\"eInvoices\":[{\"txprd\":\"052017\",\"mid\":\"HR231982\",\"grsval\":146320.00,\"ctin\":\"NA\"}]},{\"ecom_ty\":\"INTER\",\"eInvoices\":[{\"flag\":\"M\",\"txprd\":\"052017\",\"mid\":\"HR231982\",\"grsval\":1760560.00,\"ctin\":\"NA\"}]}]},{\"gstin\":\"06AAMFS3061K1Z7\",\"fp\":\"112016\",\"gt\":0}]";
			}
			authEK = CrypticUtility.decrypt(receivedSEK,
					CrypticUtility.decodeBase64StringTOByte(decryptedAppkey));
			if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Encoded Auth EK (Received) : "
					+ CrypticUtility.encodeBase64String(authEK));
			}

			encryptedData = CrypticUtility.encodeBase64String(CrypticUtility
					.encryptData(data, authEK));
			if(LOGGER.isDebugEnabled()){
			LOGGER.debug("encryptedData :  " + encryptedData);
			}
			hmac = CrypticUtility.hmacSHA256(encryptedData,
					CrypticUtility.encodeBase64String(authEK));
			authDetails.setEncryptedData(encryptedData);
			authDetails.setHmac(hmac);
			authDetails.setSessionKey(authEK);
		} catch (Exception e) {
			LOGGER.error("Error in testDataForPut : " ,e);
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : testDataForPut");
		}
		return authDetails;

	}

	/**
	 * @param decryptedAppkey
	 * @param receivedSEK
	 * @param data
	 * @return
	 */
	public static AuthDetailsDto testData(String decryptedAppkey,
			String receivedSEK) {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : testData");
		}
		AuthDetailsDto authDetails = new AuthDetailsDto();

		byte[] authEK = null;
		try {

			authEK = CrypticUtility.decrypt(receivedSEK,
					CrypticUtility.decodeBase64StringTOByte(decryptedAppkey));
			if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Encoded Auth EK (Received):"
					+ CrypticUtility.encodeBase64String(authEK));
			}

			authDetails.setSessionKey(authEK);
		} catch (Exception e) {
			LOGGER.error("Error in testData : " ,e);
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : testData");
		}
		return authDetails;

	}

	/**
	 * @param result
	 * @param authDetailsDto
	 * @return
	 * @throws ParseException
	 */
	public AuthDetailsDto getRek(String result, AuthDetailsDto authDetailsDto)
			throws ParseException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getRek");
		}

		JSONObject jsonObjectVal;
		jsonObjectVal = (JSONObject) new JSONParser().parse(result);
		authDetailsDto.setEncryptedData((String) jsonObjectVal.get("data"));
		authDetailsDto.setRek((String) jsonObjectVal.get("rek"));
		authDetailsDto.setHmac((String) jsonObjectVal.get("hmac"));

		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getRek");
		}
		return authDetailsDto;
	}

	/**
	 * @param output
	 * @param dto
	 * @return
	 * @throws ParseException
	 */
	public static AuthDetailsDto getSessionKey(String output,
			AuthDetailsDto dto, String data) throws ParseException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getSessionKey");
		}

		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject;
		jsonObject = (JSONObject) jsonParser.parse(output);
		String sek = (String) jsonObject.get("sek");
		AuthDetailsDto authDetails = testDataForPut(dto.getAppKey(), sek, data);
		authDetails.setOriginalAppapiKey(dto.getAppKey());

		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getSessionKey");
		}
		return authDetails;
	}

	/**
	 * @param output
	 * @param appKey
	 * @return
	 * @throws ParseException
	 */
	public static AuthDetailsDto getSessionKeyNEW(String output, String appKey)
			throws ParseException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getSessionKey");
		}

		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject;
		jsonObject = (JSONObject) jsonParser.parse(output);
		String sek = (String) jsonObject.get("sek");
		AuthDetailsDto authDetails = testData(appKey, sek);

		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getSessionKey");
		}
		return authDetails;
	}

	/**
	 * @param gotrek
	 * @param authKey
	 * @return
	 */
	private static byte[] getJsonData(String gotrek, byte[] authKey) {
		byte[] apiEK = null;
		try {
			apiEK = CrypticUtility.decrypt(gotrek, authKey);
		} catch (InvalidKeyException ike) {
			LOGGER.error(ike);
		} catch (IllegalBlockSizeException ibse) {
			LOGGER.error(ibse);
		} catch (BadPaddingException bpe) {
			LOGGER.error(bpe);
		} catch (IOException ie) {
			LOGGER.error(ie);
		} catch (Exception e) {
			LOGGER.error(e);
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.debug("Encoded Api EK (Received):"
				+ CrypticUtility.encodeBase64String(apiEK));
		}
		return apiEK;
	}

	/**
	 * @return AuthDetailsDto Validates the auth token for user from session
	 *         else get auth token from GSTN
	 */
	public AuthDetailsDto validateAuthToken(String data) {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getSessionKey");
		}
		String output2 = "";
		AuthDetailsDto dtoVal = null;
		try {
			// TODO: Check for expiration of Auth token

			dtoVal = AuthenticationUtility.produceSampleData();
			dtoVal.setAction("OTPREQUEST");
			dtoVal.setUserName("EYGSPTESTUSER");

			 executeRestCallGSTNPost(reqOTP(dtoVal),
					Constant.AUTHENTICATE, true, "");
			output2 = executeRestCallGSTNPost(authTokenReqBody(dtoVal),
					Constant.AUTHENTICATE, true, "");
			
				dtoVal = getSessionKey(output2, dtoVal, data);

		} catch (org.json.simple.parser.ParseException e) {
				LOGGER.error(e);
		} catch (ClientProtocolException cpe) {
			LOGGER.error(cpe);
		} catch (IOException ie) {
			LOGGER.error(ie);
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getSessionKey");
		}
		return dtoVal;
	}

	/**
	 * @param result
	 * @param authDetails
	 * @return
	 * @throws Exception
	 */
	public String getPayloadForGSTN(String result, AuthDetailsDto authDetails)
			throws Exception {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getPayloadForGSTN");
		}
		byte[] apiek ;
		String resultVal;
		authDetails = getRek(result, authDetails);
		apiek = getJsonData(authDetails.getRek(),
				CrypticUtility.decodeBase64StringTOByte(CrypticUtility
						.encodeBase64String(authDetails.getSessionKey())));
		authDetails.setApiKey(apiek);
		resultVal = getJsonDataFinal(authDetails.getEncryptedData(),
				authDetails.getApiKey());
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : getPayloadForGSTN");
		}
		return resultVal;
	}

	/**
	 * @param data
	 * @param apikey
	 * @return
	 */
	private static String getJsonDataFinal(String data, byte[] apikey) {
		String jsonData = null;
		try {
			jsonData = new String(
					CrypticUtility.decodeBase64StringTOByte(new String(CrypticUtility.decrypt(data, apikey))));
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("json string " + jsonData);
			}
		} catch (InvalidKeyException ike) {
			LOGGER.error(ike);
		} catch (IllegalBlockSizeException ibse) {
			LOGGER.error(ibse);
		} catch (BadPaddingException bpe) {
			LOGGER.error(bpe);
		} catch (IOException ie) {
			LOGGER.error(ie);
		} catch (Exception e) {
			LOGGER.error(e);
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(jsonData);
		}
		return jsonData;

	}

	/**
	 * @param dto
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public static String reqOTP(AuthDetailsDto dto)
			throws JsonGenerationException, JsonMappingException, IOException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : reqOTP");
		}
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", dto.getAction());
		paramMap.put("username", dto.getUserName());
		paramMap.put("appkey", dto.getEncryptedAppKey());
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : reqOTP");
		}
		return mapAsJson;
	}

	/**
	 * @param dto
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public static String authTokenReqBody(AuthDetailsDto dto)
			throws JsonGenerationException, JsonMappingException, IOException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : authTokenReqBody");
		}
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", Constant.AUTHTOKEN);
		paramMap.put("username", dto.getUserName());
		paramMap.put("appkey", dto.getEncryptedAppKey());
		paramMap.put("otp", dto.getEncryptedOTP());
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : authTokenReqBody");
		}
		return mapAsJson;
	}

	public String gstrReqPayload(AuthDetailsDto authDetailsDto, String action)
			throws JsonGenerationException, JsonMappingException, IOException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : gstrReqPayload");
		}
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", action);
		paramMap.put("data", authDetailsDto.getEncryptedData());
		paramMap.put("hmac", authDetailsDto.getHmac());
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : gstrReqPayload");
		}
		return mapAsJson;
	}

	public SummaryDto encryptPayloadData(SummaryDto summDto,
			AuthDetailsDto authDto) {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : encryptPayloadData");
		}
		SummaryDto summaryDto = summDto;
		try {
			String encryptedData = CrypticUtility
					.encodeBase64String(CrypticUtility.encryptData(
							summDto.getPayLoad(), authDto.getSessionKey()));
			summDto.setData(encryptedData);
			String hmac = CrypticUtility.hmacSHA256(encryptedData,
					CrypticUtility.encodeBase64String(authDto.getSessionKey()));
			summDto.setHmac(hmac);
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : encryptPayloadData" ,e);
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : encryptPayloadData");
		}
		return summaryDto;
	}

	public String fileGstrReqPayload(SummaryDto summaryDto, String action)
			throws JsonGenerationException, JsonMappingException, IOException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : fileGstrReqPayload");
		}
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("data", summaryDto.getData());
		paramMap.put("action", action);
		paramMap.put("hmac", summaryDto.getHmac());
		paramMap.put("st", summaryDto.getSignatureType());
		paramMap.put("sid", summaryDto.getSid());
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : fileGstrReqPayload");
		}
		return mapAsJson;
	}

	public String executeRestCallGSTNPost(String body, String resouceType,
			Boolean gstnHost, String gstr) throws ClientProtocolException,
			IOException {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getOTP");
		}
		HttpHeaders httpHeaders = new HttpHeaders();
		String reqBody = gstnRestUtility.executeRestCall(httpHeaders, body, gstnRestUtility.getResource(gstnHost,
				resouceType, gstr), HttpMethod.POST);
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getOTP");
		}
		return reqBody;
	}
	
	/**
	 * @param result
	 * @param rek,sek
	 * @return
	 * @throws Exception
	 */
	public String getBusinessTypeDetailsFromGSTN(String rek, byte[] sessionKey) throws Exception {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering " + CLASS_NAME + " Method : getBusinessTypeDetailsFromGSTN");
		}
		byte[] apikey=CrypticUtility.decrypt(rek, sessionKey);
		String encodedApiData=new String(apikey, "UTF-8");
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Exiting " + CLASS_NAME + " Method : getBusinessTypeDetailsFromGSTN");
		}
		return encodedApiData;
	}

}
