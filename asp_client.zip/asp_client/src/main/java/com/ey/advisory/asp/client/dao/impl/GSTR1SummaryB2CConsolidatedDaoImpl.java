package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR1SummaryB2CConsolidatedDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR1SummaryB2CConsolidated;
@Repository
public class GSTR1SummaryB2CConsolidatedDaoImpl implements GSTR1SummaryB2CConsolidatedDao{
	
	@Autowired
	private HibernateDao  hibernateDao;
	
	private static final Logger logger = Logger.getLogger(GSTR1SummaryB2CConsolidatedDaoImpl.class);

	@Override
	public List<GSTR1SummaryB2CConsolidated> getB2CConsolidatedMetadata() {
		List<GSTR1SummaryB2CConsolidated> b2CConsolidatedList = new ArrayList<>();
		try {
			b2CConsolidatedList = (List<GSTR1SummaryB2CConsolidated>)hibernateDao.loadAll(GSTR1SummaryB2CConsolidated.class);
		} catch (Exception e) {
			
			logger.error("Exception in getB2CConsolidatedMetadata"+ e);
		}
		return b2CConsolidatedList;
	}

}
