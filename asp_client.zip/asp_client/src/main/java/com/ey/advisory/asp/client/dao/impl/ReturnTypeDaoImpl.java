package com.ey.advisory.asp.client.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.ReturnTypeDao;
import com.ey.advisory.asp.client.domain.ReturnType;
import com.ey.advisory.asp.common.Constant;

@Repository
public class  ReturnTypeDaoImpl implements  ReturnTypeDao {

	private static final Logger logger = Logger
			.getLogger(ReturnTypeDaoImpl.class);
	private static final String CLASS_NAME = ReturnTypeDaoImpl.class
			.getName();
	
	@Autowired
	private HibernateDao  hibernateDao;

	@SuppressWarnings("unchecked")
	@Override
	public List<ReturnType> getFileUploadTypelist() {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " getFileUploadTypelist");
		}
		DetachedCriteria detachedCriteria =hibernateDao.createCriteria(ReturnType.class);
		List<ReturnType> returnTypeList = null;
		try {
			returnTypeList = (List<ReturnType>) hibernateDao.find(detachedCriteria);
			
		} catch (Exception e) {
			if(logger.isInfoEnabled())
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD + " getFileUploadTypelist" + e);
		}
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " getFileUploadTypelist");
		}
		return returnTypeList;
	}

}
