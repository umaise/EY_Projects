package com.ey.advisory.asp.client.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.jdbc.Work;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.InvoiceDao;
import com.ey.advisory.asp.client.domain.DataFlowStageModel;
import com.ey.advisory.asp.client.domain.FileUploadMasterClient;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.SystemCodeModel;
import com.ey.advisory.asp.client.domain.TblCrDrITCAInvoiceDetails;
import com.ey.advisory.asp.client.domain.TblEmailStatusDetails;
import com.ey.advisory.asp.client.domain.TblITCDInvoiceDetails;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.client.dto.TblErrorAction;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
@Repository
public class InvoiceDaoImpl implements InvoiceDao {

    @Autowired
    private HibernateDao  hibernateDao;

    private static final Logger LOGGER = Logger.getLogger(InvoiceDaoImpl.class);
    @Override
    @Transactional
    public boolean saveErrors(List<TblErrorAction> errorList) {

        for (Iterator iterator = errorList.iterator(); iterator.hasNext();) {
            TblErrorAction tblErrorAction = (TblErrorAction) iterator.next();
            hibernateDao.save(tblErrorAction);
        }
        return false;
    }

    public void setPersistance(HibernateDao persistance) {
        this.hibernateDao = persistance;
    }
    
  /*
    @Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean saveInvoiceStatus(Set<InvoiceProcessDto> invoiceList,Integer fileId) throws Exception {

        boolean saveStatus = false;
        //Iterator<InvoiceProcessDto> invoiceIterator=invoiceList.iterator();
        try {
	        	
	        	long startTime=System.currentTimeMillis();
	        	List<InvoiceProcessDto> tempList=new ArrayList(invoiceList);
	        	List<?> result = null;
	        	StringBuffer jsonRes = new StringBuffer();
	        	
	        	List<List<InvoiceProcessDto>> subLists=Lists.partition(tempList, Constant.SQL_BATCH_SIZE);
	        	
	        	for(List<InvoiceProcessDto> list:subLists){
	        		Gson gson = new Gson();
	        		String jsonArray=gson.toJson(list);
	        		Object[] obj = new Object[2];
	    			obj[0] = fileId;
	    			obj[1] = jsonArray;
	        		result = hibernateDao.executeNativeSql(
							" exec dbo.uspSaveGstr1BifurcationStatus ?,?", obj);
					if(result!=null && !result.isEmpty()){
						for(int i=0;i<result.size();i++){
							jsonRes.append(result.get((i)));
						}
					}
	        	}
	        	
	        	saveStatus=true;
	        	
	        	LOGGER.info("Total Time taken to update "+invoiceList.size()+" invoices : "+(System.currentTimeMillis()-startTime)+" Milli Seconds"); 

            
        } catch (Exception e) {
            LOGGER.error(e); 
            //ToDo add the custom exceptions for database
            throw new Exception(e);
        }
        
        return saveStatus;
    } */


    @Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean saveInvoiceStatus(Set<InvoiceProcessDto> invoiceList,Integer fileId) throws Exception {

        boolean saveStatus = false;
        Session session = hibernateDao.getSession();
        //Iterator<InvoiceProcessDto> invoiceIterator=invoiceList.iterator();
        try {
	        	
	        	Transaction tx = session.beginTransaction();
	        	long startTime=System.currentTimeMillis();
	        	session.doWork(new Work(){
		              public void execute(Connection connection) throws SQLException {
		            	  PreparedStatement  preparedStatement =null;
		            	  PreparedStatement  preparedStatementNew =null;
		            	  int i=0;
		  	        	  int[] count;
		            	    try{
		            	  		String sqlUpdate = "update etl.tblSalesStaging set Status=?, RecordType=?, SubCategory=?, OrgCRDocNo=?, OrgCRDocDate=? where FileID=? and InvOrder=?";
			                    preparedStatement = connection.prepareCall(sqlUpdate);
			                    
			                    for (InvoiceProcessDto invProcessDto : invoiceList){
			                    	i++;
			                    		preparedStatement.setString(1,invProcessDto.getStatus());
					                    preparedStatement.setString(2,invProcessDto.getTableType());
					                    preparedStatement.setString(3,invProcessDto.getSubCategory());
					                    preparedStatement.setString(4, invProcessDto.getOrgCRDocNo());
					                    java.sql.Date orgDate = null;
					                    if(invProcessDto.getOrgCRDocDate() != null){
					                       orgDate = new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(invProcessDto.getOrgCRDocDate()).getTime());
					                       preparedStatement.setDate(5,orgDate);
			                    		}else{
			                    			preparedStatement.setDate(5,null);
			                    		}
				                    	preparedStatement.setLong(6, fileId);
				                    	preparedStatement.setLong(7, invProcessDto.getInvOrder());
				                    
				                    preparedStatement.addBatch();
			                    	if ( i % Constant.SQL_BATCH_SIZE == 0 ) { 
			                    		count =preparedStatement .executeBatch();
			                    		LOGGER.info(count.length +" invoice updated for file Id : "+fileId);
			                    	}
			                    }
			                    
			                    count=preparedStatement .executeBatch();
			                    LOGGER.info(count.length +" invoice updated for file Id : "+fileId);
			                    
		            	  	} catch (ParseException e) {
		            	  		LOGGER.info("Invalid Date : "+e.getMessage());
								//e.printStackTrace();
							}finally{
		            	  		if(preparedStatement != null) {
		                            preparedStatement.close();
		                        }
		            	  	}
		                    
		                }
		            });
	        	
	        	tx.commit();
	        	session.close();
	        	LOGGER.info("Total Time taken to update "+invoiceList.size()+" invoices : "+(System.currentTimeMillis()-startTime)+" Milli Seconds"); 

            /* Query query  = session.getNamedQuery("OutwardInvoiceModel.updateStatus");
            while(invoiceIterator.hasNext()){
                InvoiceProcessDto invoice = invoiceIterator.next();
                query.setParameter("STATUS", invoice.getStatus());
                query.setParameter("TYPE", invoice.getTableType());
                query.setParameter("SUBCATEGORY", invoice.getSubCategory());
                query.setParameter("FILEID", fileId);
                query.setParameter("INVORDER", invoice.getInvOrder());
                query.executeUpdate();
            }
            session.close(); */
            saveStatus=true;
        } catch (Exception e) {
            LOGGER.error(e); 
            //ToDo add the custom exceptions for database
            throw new Exception(e);
        }finally{
        	if(session !=null && session.isOpen()){
        		session.close();
        	}
        }
        return saveStatus;
    }
    
    @Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean markTechErrorInvoiceStatus(Integer fileId) throws Exception {

        boolean saveStatus = false;
        Session session = hibernateDao.getSession();
        try {
        	
            Query query  = session.getNamedQuery("OutwardInvoiceModel.markTechError");
                query.setParameter("FILEID", fileId);
                query.executeUpdate();
            
            saveStatus=true;
        } catch (Exception e) {
            LOGGER.error(e); 
            //ToDo add the custom exceptions for database
            throw new Exception(e);
        }finally{
        	if(session !=null && session.isOpen()){
        		session.close();
        	}
        }
        return saveStatus;
    }
    
    @Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean gstr2MarkTechErrorInvoiceStatus(Integer fileId) throws Exception {

        boolean saveStatus = false;
        Session session = hibernateDao.getSession();
        try {
        	
            Query query  = session.getNamedQuery("InwardInvoiceModel.markTechError");
                query.setParameter("FILEID", fileId);
                query.executeUpdate();
            
            session.close();
            saveStatus=true;
        } catch (Exception e) {
            LOGGER.error(e); 
            //ToDo add the custom exceptions for database
            throw new Exception(e);
        }finally{
        	if(session !=null && session.isOpen()){
        		session.close();
        	}
        }
        return saveStatus;
    }

    @Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean saveSalesErrorInfo(Set<TblSalesErrorInfo> invoiceErrSet) throws Exception {
        boolean saveStatus = false;
        Session session = hibernateDao.getSession();
        try{
        	Transaction tx = session.beginTransaction();
        	long startTime=System.currentTimeMillis();
        	session.doWork(new Work(){
	              public void execute(Connection connection) throws SQLException {
	            	  PreparedStatement  preparedStatement =null;
	            	  	try{
	            	  		String sqlInsert = "insert into trans.tblSalesErrorInfo (Gstin,CreatedBy,ColumnID,ErrorDesc,ErrorInfoCode,IsProcessed,ProcessStatus,IncidenceLevel,IsError,"
		                    		+"CreateDate,invoiceKey,LineNum,SalesStagingID,FileId,TaxPeriod) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		                    preparedStatement = connection.prepareCall(sqlInsert);
		                    int i=0;
		                	int fileId=0;
		                    
		                    for (TblSalesErrorInfo tblErrorInfo : invoiceErrSet){
		                    	if(i==0){
		                    		fileId=tblErrorInfo.getFileId();
		                    	}
		                    	i++;
		                    	preparedStatement.setString(1,tblErrorInfo.getGstin());//Gstin
		                    	preparedStatement.setString(2,tblErrorInfo.getCreatedBy());//CreatedBy
		                    	preparedStatement.setString(3,tblErrorInfo.getErrorColumnId());//ColumnID
		                    	preparedStatement.setString(4,tblErrorInfo.getErrorDesc());//ErrorDesc
		                    	preparedStatement.setString(5,tblErrorInfo.getErrorInfoCode());//ErrorInfoCode
		                    	preparedStatement.setBoolean(6, tblErrorInfo.getIsProcessed());//IsProcessed
		                    	preparedStatement.setString(7, tblErrorInfo.getProcessStatus());//ProcessStatus
		                    	preparedStatement.setString(8,tblErrorInfo.getIncidenceLevel());//IncidenceLevel
		                    	preparedStatement.setString(9, Character.toString(tblErrorInfo.getIsError()));//IsError
		                    	preparedStatement.setTimestamp(10,new Timestamp(System.currentTimeMillis()));//CreateDate
		                    	preparedStatement.setString(11, tblErrorInfo.getInvoiceKey());//Invoice Key
		                    	preparedStatement.setInt(12, tblErrorInfo.getLineNo());//LineNum
		                    	preparedStatement.setInt(13, tblErrorInfo.getSalesStagingID());//SalesStagingID
		                    	preparedStatement.setInt(14, tblErrorInfo.getFileId());//FileId
		                    	preparedStatement.setString(15, tblErrorInfo.getTaxPeriod());//TaxPeriod
		                    	
			                    preparedStatement.addBatch();
		                    	if ( i % Constant.SQL_BATCH_SIZE == 0 ) { 
		                    		int[] count =preparedStatement .executeBatch();
		                    		LOGGER.info(count.length +" erros inserted for file Id : "+fileId);
		                    	}
		                    }
		                    
		                    int[] count =preparedStatement .executeBatch();
		                    LOGGER.info(count.length +" erros inserted for file Id : "+fileId);
		                    
	            	  	}finally{
	            	  		if(preparedStatement != null) {
	                            preparedStatement.close();
	                        }
	            	  	}
	                    
	                }
	            });
        	
        	tx.commit();
        	session.close();
        	LOGGER.info("Total Time taken to insert "+invoiceErrSet.size()+" error info records : "+(System.currentTimeMillis()-startTime)+" Milli Seconds");
        	
            /*for (TblSalesErrorInfo tblErrorInfo : invoiceErrSet) {
            	i++;
                if(tblErrorInfo!=null&& tblErrorInfo.getErrorInfoCode()!=null){
                    tblErrorInfo.setCreateDate(new Timestamp(System.currentTimeMillis()));
                    //hibernateDao.save(tblErrorInfo);
                    //TODO: Need to check this batch feature in Hibernate Template
                    session.save(tblErrorInfo);
                    if ( i % Constant.JDBC_BATCH_SIZE == 0 ) { 
                        session.flush();
                        session.clear();
                    }
                }
            }
            session.close();*/
            saveStatus=true;
        }
        catch(Exception e){
            LOGGER.error(e);
            //ToDo add the custom exceptions for database
            throw new Exception(e);
        }finally{
        	if(session !=null && session.isOpen()){
        		session.close();
        	}
        }
        return saveStatus;
    }

    @Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean savePurchaseErrorInfo(Set<TblPurchaseErrorInfo> invoice) throws Exception{
    	boolean saveStatus = false;
        Session session = hibernateDao.getSession();
        try{
        	int i=0;
            for (TblPurchaseErrorInfo tblErrorInfo : invoice) {
            	i++;
                if(tblErrorInfo!=null&& tblErrorInfo.getErrorInfoCode()!=null){
                    tblErrorInfo.setCreateDate(new Timestamp(System.currentTimeMillis()));
                    //hibernateDao.save(tblErrorInfo);
                    //TODO: Need to check this batch feature in Hibernate Template
                    session.save(tblErrorInfo);
                    if ( i % Constant.JDBC_BATCH_SIZE == 0 ) { 
                        session.flush();
                        session.clear();
                    }
                }
            }
            saveStatus=true;
        }
        catch(Exception e){
            LOGGER.error(e);
            //ToDo add the custom exceptions for database
            throw new Exception(e);
        }finally{
        	if(session !=null && session.isOpen()){
        		session.close();
        	}
        }
        return saveStatus;
    }
    @Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean saveIsdErrorInfo(Set<TblIsdErrorInfo> errorInfo) {
        boolean saveStatus = false;
        Session session = hibernateDao.getSession();
        try{
        	int i=0;
            for (TblIsdErrorInfo tblErrorInfo : errorInfo) {
            	i++;
                	LOGGER.info("ISD Error Info : "+tblErrorInfo+"Error Info Code : "+tblErrorInfo.getErrorInfoCode());
                    tblErrorInfo.setCreateDate(new Timestamp(System.currentTimeMillis()));
                    //hibernateDao.save(tblErrorInfo);
                    session.save(tblErrorInfo);
                    if ( i % Constant.JDBC_BATCH_SIZE == 0 ) { 
                        session.flush();
                        session.clear();
                    }
            }
            session.close();
            saveStatus=true;
        }
        catch(Exception e){
            LOGGER.error(e);
        }
        finally{
        	if(session !=null && session.isOpen()){
        		session.close();
        	}
        }
        return saveStatus;
    }

    @Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean saveTdsErrorInfo(Set<TblTdsErrorInfo> errorInfo) {
        boolean saveStatus = false;
        try{

            for (TblTdsErrorInfo tblErrorInfo : errorInfo) {
                if(tblErrorInfo!=null&& tblErrorInfo.getErrorInfoCode()!=null && tblErrorInfo.getErrorColumnName()!=null ){
                    tblErrorInfo.setCreateDate(new Timestamp(System.currentTimeMillis()));
                    hibernateDao.save(tblErrorInfo);
                }
            }

            saveStatus=true;
        }
        catch(Exception e){
            LOGGER.error(e);
        }
        return saveStatus;
    }
    @Override
    public boolean saveGstr2InvoiceStatus(Set<InvoiceProcessDto> invoice, Integer fileId) {
        boolean saveStatus = false;
        Session session = hibernateDao.getSession();
        Iterator<InvoiceProcessDto> invoiceIterator=invoice.iterator();
        try {
            Query query  = session.getNamedQuery("InwardInvoiceModel.updateStatus");
            while(invoiceIterator.hasNext()){
                InvoiceProcessDto invoiceDto = invoiceIterator.next();
                query.setParameter("STATUS", invoiceDto.getStatus());
                query.setParameter("TYPE", invoiceDto.getTableType());
                query.setParameter("SUBCATEGORY", invoiceDto.getSubCategory());
                query.setParameter("FILEID", fileId);
                query.setParameter("INVORDER", invoiceDto.getInvOrder());
                query.setParameter("eligibilityIndicator", invoiceDto.getEligibilityIndicator());
                query.setParameter("availableCESS", invoiceDto.getAvailableCESS());
                query.setParameter("availableCGST", invoiceDto.getAvailableCGST());
                query.setParameter("availableIGST", invoiceDto.getAvailableIGST());
                query.setParameter("availableSGST", invoiceDto.getAvailableSGST());
                query.setParameter("LINENUMBER", invoiceDto.getLineNumber());
                query.executeUpdate();
            }
            saveStatus=true;
            session.close();
        } catch (Exception e) {
            LOGGER.error(e);
        } finally{
        	if(session !=null && session.isOpen()){
        		session.close();
        	}
        }
        return saveStatus;
    }

  

    @Override
    public boolean saveGstr7InvoiceStatus(Set<InvoiceProcessDto> invoice, Integer fileId) {
        boolean saveStatus = false;
        Session session = hibernateDao.getSession();
        Iterator<InvoiceProcessDto> invoiceIterator=invoice.iterator();
        try {

            Query query  = session.getNamedQuery("InwardInvoiceModelGstr7.updateStatus");
            while(invoiceIterator.hasNext()){
                InvoiceProcessDto invoiceDto = invoiceIterator.next();
                query.setParameter("STATUS", invoiceDto.getStatus());
                query.setParameter("TYPE", invoiceDto.getTableType());
                query.setParameter("FILEID", fileId);//Changed to Integer
                query.setParameter("INVORDER", invoiceDto.getInvOrder());
                query.executeUpdate();

            }
            saveStatus=true;
            session.close();
        } catch (Exception e) {
            LOGGER.error(e);
        }finally{
        	if(session !=null && session.isOpen()){
        		session.close();
        	}
        }
        return saveStatus;
    }
    @Override
    public void saveAfterReconStatus(String tableName, String fieldName, String status) {
        // TODO Auto-generated method stub

    }

    @Override
    public void getGstinWithPan(String key, String PAN) {
        if(LOGGER.isInfoEnabled()){
            LOGGER.info("in getGstinWithPan ");
        }

    }


    @Override
    public int getAffectedInvoiceCountForGstin(String gstin,String processType) {
        DetachedCriteria detachedCriteria;
        if("GSTR1".equals(processType))
            detachedCriteria =
            hibernateDao.createCriteria(TblSalesErrorInfo.class, "salesErrorInfo")
            .add(Restrictions.and(Restrictions.eq("salesErrorInfo.gstin", gstin),Restrictions.eq("salesErrorInfo.isProcessed", false)))
            .setProjection(Projections.countDistinct("salesErrorInfo.errorInfoID"));
        else if("GSTR6".equals(processType))
            detachedCriteria =
            hibernateDao.createCriteria(TblIsdErrorInfo.class, "isdErrorInfo")
            .add(Restrictions.and(Restrictions.eq("isdErrorInfo.gstin", gstin),Restrictions.eq("isdErrorInfo.isProcessed", false)))
            .setProjection(Projections.countDistinct("isdErrorInfo.errorInfoID"));
        else
        	detachedCriteria =
            hibernateDao.createCriteria(TblPurchaseErrorInfo.class, "purchaseErrorInfo")
            .add(Restrictions.and(Restrictions.eq("purchaseErrorInfo.gstin", gstin),Restrictions.eq("purchaseErrorInfo.isProcessed", false)))
            .setProjection(Projections.countDistinct("purchaseErrorInfo.errorInfoID"));

        List<Long> invoiceCountList=(List<Long>) hibernateDao.find(detachedCriteria);
        return invoiceCountList.get(0).intValue();
    }

    @Override
    public boolean saveMailStatusDetailsInfo(Set<String> gstinList, String returnType) {
        boolean result = false;
        for (String gstin : gstinList) {

            DetachedCriteria detachedCriteria =
                hibernateDao.createCriteria(TblEmailStatusDetails.class, "TblEmailStatusDetails")
                .add(Restrictions.eq("TblEmailStatusDetails.gstin", gstin))
                .add(Restrictions.eq("TblEmailStatusDetails.returnType", returnType));

            List<TblEmailStatusDetails> lstTblEmailStatusDetails = (List<TblEmailStatusDetails>) hibernateDao.find(detachedCriteria);
            if(lstTblEmailStatusDetails.isEmpty()) {
                TblEmailStatusDetails tblEmailStatusDetails = new TblEmailStatusDetails();
                tblEmailStatusDetails.setGstin(gstin);
                tblEmailStatusDetails.setReturnType(returnType);
                tblEmailStatusDetails.setEmailFlag(Boolean.TRUE);
                tblEmailStatusDetails.setRetryCount(Constant.MAILSTATUS_EMAIL_RETRY_COUNT_ZERO);

                hibernateDao.save(tblEmailStatusDetails);
            } else {
                for (TblEmailStatusDetails entity : lstTblEmailStatusDetails) {
                    entity.setEmailFlag(Boolean.TRUE);
                    hibernateDao.update(entity);
                }
            }
            result = true;
        }

        return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean updateFileUploadStatus(long fileId, String returnType,String stg) {
        String queryDataFlowStageModel = "FROM DataFlowStageModel e where e.returnType= ? and e.stageDesc=?";        
        List<DataFlowStageModel> dataFlowStageModelList = (List<DataFlowStageModel>) hibernateDao.find(queryDataFlowStageModel, returnType, stg);
        String stage = null;
        for (DataFlowStageModel dataFlowStageModel : dataFlowStageModelList) {
            stage = dataFlowStageModel.getStageCode();
        }

        String querySystemCodeModel = "FROM SystemCodeModel e where e.codeKey= ? and e.description=?";        
        List<SystemCodeModel> systemCodeModelList = (List<SystemCodeModel>) hibernateDao.find(querySystemCodeModel, Constant.SYSTEM_CODE_STATUS, Constant.SYSTEM_CODE_STATUS_PROCESSED);
        String processStatus = null;
        for (SystemCodeModel systemCodeModel : systemCodeModelList) {
            processStatus = systemCodeModel.getCode();
        }

        String queryFileUploadMasterClient = "FROM FileUploadMasterClient e where e.fileId=?";
        List<FileUploadMasterClient> FileUploadMasterClientList = (List<FileUploadMasterClient>) hibernateDao.find(queryFileUploadMasterClient, fileId);

        for (FileUploadMasterClient fileUploadMasterClient : FileUploadMasterClientList) {
            fileUploadMasterClient.setStatus(processStatus);
            fileUploadMasterClient.setStage(stage);
            hibernateDao.update(fileUploadMasterClient);
        }

        return true;
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public boolean timeoutAndUpdateFileUploadStatus(long fileId, String returnType,String stg) {
        String queryDataFlowStageModel = "FROM DataFlowStageModel e where e.returnType= ? and e.stageDesc=?";        
        List<DataFlowStageModel> dataFlowStageModelList = (List<DataFlowStageModel>) hibernateDao.find(queryDataFlowStageModel, returnType, stg);
        String stage = null;
        for (DataFlowStageModel dataFlowStageModel : dataFlowStageModelList) {
            stage = dataFlowStageModel.getStageCode();
        }

        String querySystemCodeModel = "FROM SystemCodeModel e where e.codeKey= ? and e.description=?";        
        List<SystemCodeModel> systemCodeModelList = (List<SystemCodeModel>) hibernateDao.find(querySystemCodeModel, Constant.SYSTEM_CODE_STATUS, Constant.SYSTEM_CODE_STATUS_ERROR);
        String processStatus = null;
        for (SystemCodeModel systemCodeModel : systemCodeModelList) {
            processStatus = systemCodeModel.getCode();
        }

        String queryFileUploadMasterClient = "FROM FileUploadMasterClient e where e.fileId=?";
        List<FileUploadMasterClient> FileUploadMasterClientList = (List<FileUploadMasterClient>) hibernateDao.find(queryFileUploadMasterClient, fileId);

        for (FileUploadMasterClient fileUploadMasterClient : FileUploadMasterClientList) {
            fileUploadMasterClient.setStatus(processStatus);
            fileUploadMasterClient.setStage(stage);
            hibernateDao.update(fileUploadMasterClient);
        }

        return true;
    }

    
    @SuppressWarnings("unchecked")
    @Override
    public boolean updateBifurcationFailStatus(long fileId, String returnType,String stg) {
        String queryDataFlowStageModel = "FROM DataFlowStageModel e where e.returnType= ? and e.stageDesc=?";        
        List<DataFlowStageModel> dataFlowStageModelList = (List<DataFlowStageModel>) hibernateDao.find(queryDataFlowStageModel, returnType, stg);
        String stage = null;
        for (DataFlowStageModel dataFlowStageModel : dataFlowStageModelList) {
            stage = dataFlowStageModel.getStageCode();
        }

        String querySystemCodeModel = "FROM SystemCodeModel e where e.codeKey= ? and e.description=?";        
       List<SystemCodeModel> systemCodeModelList = (List<SystemCodeModel>) hibernateDao.find(querySystemCodeModel, Constant.SYSTEM_CODE_STATUS, Constant.SYSTEM_CODE_STATUS_FAILED);
      //  List<SystemCodeModel> systemCodeModelList = (List<SystemCodeModel>) hibernateDao.find(querySystemCodeModel, Constant.SYSTEM_CODE_STATUS, stg);
        String processStatus = null;
        for (SystemCodeModel systemCodeModel : systemCodeModelList) {
            processStatus = systemCodeModel.getCode();
        }

        String queryFileUploadMasterClient = "FROM FileUploadMasterClient e where e.fileId=?";
        List<FileUploadMasterClient> FileUploadMasterClientList = (List<FileUploadMasterClient>) hibernateDao.find(queryFileUploadMasterClient, fileId);

        for (FileUploadMasterClient fileUploadMasterClient : FileUploadMasterClientList) {
            fileUploadMasterClient.setStatus(processStatus);
            fileUploadMasterClient.setStage(stage);
            hibernateDao.update(fileUploadMasterClient);
        }

        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean updateStageOneFailStatus(long fileId, String returnType,String stg) {
        String queryDataFlowStageModel = "FROM DataFlowStageModel e where e.returnType= ? and e.stageDesc=?";        
        List<DataFlowStageModel> dataFlowStageModelList = (List<DataFlowStageModel>) hibernateDao.find(queryDataFlowStageModel, returnType, stg);
        String stage = null;
        for (DataFlowStageModel dataFlowStageModel : dataFlowStageModelList) {
            stage = dataFlowStageModel.getStageCode();
        }

        String querySystemCodeModel = "FROM SystemCodeModel e where e.codeKey= ? and e.description=?";        
       List<SystemCodeModel> systemCodeModelList = (List<SystemCodeModel>) hibernateDao.find(querySystemCodeModel, Constant.SYSTEM_CODE_STATUS, Constant.SYSTEM_CODE_STATUS_FAILED);
      //  List<SystemCodeModel> systemCodeModelList = (List<SystemCodeModel>) hibernateDao.find(querySystemCodeModel, Constant.SYSTEM_CODE_STATUS, stg);
        String processStatus = null;
        for (SystemCodeModel systemCodeModel : systemCodeModelList) {
            processStatus = systemCodeModel.getCode();
        }

        String queryFileUploadMasterClient = "FROM FileUploadMasterClient e where e.fileId=?";
        List<FileUploadMasterClient> FileUploadMasterClientList = (List<FileUploadMasterClient>) hibernateDao.find(queryFileUploadMasterClient, fileId);

        for (FileUploadMasterClient fileUploadMasterClient : FileUploadMasterClientList) {
            fileUploadMasterClient.setStatus(processStatus);
            fileUploadMasterClient.setStage(stage);
            hibernateDao.update(fileUploadMasterClient);
        }

        return true;
    }
    
    @Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
	public List<InwardInvoiceModel> getInvoiceDocumentDetail(Set<InvoiceProcessDto> invoiceList){
    	List<InwardInvoiceModel> inward = null;
    	Iterator<InvoiceProcessDto> invoiceIterator=invoiceList.iterator();
        
    	DetachedCriteria detachedCriteria =	hibernateDao.createCriteria(InwardInvoiceModel.class);
    	  while(invoiceIterator.hasNext()){
              InvoiceProcessDto invoice = invoiceIterator.next();
              detachedCriteria.add(Restrictions.eq("originalDocumentNo", invoice.getDocNum()));
    	  }
    	  detachedCriteria.setProjection(Projections.property("eligibilityIndicator"));
    	  inward = (List<InwardInvoiceModel>) hibernateDao.find(detachedCriteria);
    	   
    	return inward;
	}
    

		@Override
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public List<InwardInvoiceModel> getCRTaxableDetail(Set<InvoiceProcessDto> invoiceList){
    	List<InwardInvoiceModel> inward = null;
    	Iterator<InvoiceProcessDto> invoiceIterator=invoiceList.iterator();
        
    	DetachedCriteria detachedCriteria =	hibernateDao.createCriteria(InwardInvoiceModel.class);
    	 while(invoiceIterator.hasNext()){
              InvoiceProcessDto invoice = invoiceIterator.next();
              detachedCriteria.add(Restrictions.eq("documentNo", invoice.getOriginalDocNo()));
              detachedCriteria.add(Restrictions.eq("documentType", "CR"));
    	 }
    	  ProjectionList proList = Projections.projectionList();
    	  proList.add(Projections.sum("taxableValue"));
    	  detachedCriteria.setProjection(proList);
    	  inward = (List<InwardInvoiceModel>) hibernateDao.find(detachedCriteria);
    	return inward;
	}
	
		@Override
	    @Transactional(propagation=Propagation.REQUIRES_NEW)
		//public List<InwardInvoiceModel> getDocumentDetails(Set<InvoiceProcessDto> invoiceList){
		public Integer getDocumentDetails(Set<InvoiceProcessDto> invoiceList){
	    	List<InwardInvoiceModel> inward = null;
	    	Iterator<InvoiceProcessDto> invoiceIterator=invoiceList.iterator();
	        
	    	DetachedCriteria detachedCriteria =	hibernateDao.createCriteria(InwardInvoiceModel.class);
	    	 while(invoiceIterator.hasNext()){
	              InvoiceProcessDto invoice = invoiceIterator.next();
	              detachedCriteria.add(Restrictions.eq("invoiceKey", invoice.getInvKey()));
	    	 }
	    	 detachedCriteria.setProjection(Projections.property("invoiceKey"));
	    	 detachedCriteria.setProjection(Projections.property("invoiceKey")).setResultTransformer(Criteria.ROOT_ENTITY);
	    	  inward = (List<InwardInvoiceModel>) hibernateDao.find(detachedCriteria);
	    	  
	    	
	    	return inward.size();
		}
		
		@Override
	    @Transactional(propagation=Propagation.REQUIRES_NEW)
		public Integer getDocumentDetails_CrDrInvDtl(Set<InvoiceProcessDto> invoiceList){
	    	List<TblCrDrITCAInvoiceDetails> inward = null;
	    	Iterator<InvoiceProcessDto> invoiceIterator=invoiceList.iterator();
	        
	    	DetachedCriteria detachedCriteria =	hibernateDao.createCriteria(TblCrDrITCAInvoiceDetails.class);
	    	 while(invoiceIterator.hasNext()){
	              InvoiceProcessDto invoice = invoiceIterator.next();
	              detachedCriteria.add(Restrictions.eq("invoiceKey", invoice.getInvKey()));
	    	 }
	    	 detachedCriteria.setProjection(Projections.property("invoiceKey"));
	    	 detachedCriteria.setProjection(Projections.property("invoiceKey")).setResultTransformer(Criteria.ROOT_ENTITY);
	    	  inward = (List<TblCrDrITCAInvoiceDetails>) hibernateDao.find(detachedCriteria);
	    	  
	    	
	    	return inward.size();
		}
		
		@Override
	    @Transactional(propagation=Propagation.REQUIRES_NEW)
		public Integer getDocumentDetails_ITCDInvDtl(Set<InvoiceProcessDto> invoiceList){
	    	List<TblITCDInvoiceDetails> inward = null;
	    	Iterator<InvoiceProcessDto> invoiceIterator=invoiceList.iterator();
	        
	    	DetachedCriteria detachedCriteria =	hibernateDao.createCriteria(TblITCDInvoiceDetails.class);
	    	 while(invoiceIterator.hasNext()){
	              InvoiceProcessDto invoice = invoiceIterator.next();
	              detachedCriteria.add(Restrictions.eq("invoiceKey", invoice.getInvKey()));
	    	 }
	    	 detachedCriteria.setProjection(Projections.property("invoiceKey"));
	    	 detachedCriteria.setProjection(Projections.property("invoiceKey")).setResultTransformer(Criteria.ROOT_ENTITY);
	    	  inward = (List<TblITCDInvoiceDetails>) hibernateDao.find(detachedCriteria);
	    	  
	    	
	    	return inward.size();
		}
		
		
		@Override
		@Transactional(propagation=Propagation.REQUIRES_NEW)
		public List<FileUploadMasterClient> getFileFromClientMaster(Long fileId){
			List<FileUploadMasterClient> clientFileLst=new ArrayList<FileUploadMasterClient>(); 
			try{
				String queryFileUploadMasterClient = "FROM FileUploadMasterClient e where e.fileId=?";
		        clientFileLst = (List<FileUploadMasterClient>) hibernateDao.find(queryFileUploadMasterClient, fileId);
			}catch(Exception e){
				LOGGER.error("Exception in getFileFromClientMaster : "+e);
			}
			return clientFileLst;
		}
}
