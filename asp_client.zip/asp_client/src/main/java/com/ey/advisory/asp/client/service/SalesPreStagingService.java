package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblSalesPreStaging;


public interface SalesPreStagingService {

 	List<TblSalesPreStaging> fetchAll();
 	
 	Long getTotalCount(Long fileId);
 	
 	List<TblSalesPreStaging> fetchPages(Long fileId, int firstResult, int pageSize);
 	
 	Long getDupCount(Long fileId);

	List<TblSalesPreStaging> fetchDupRecords(Long fileId, int firstResult, int pageSize);

	Long getTotalErrorCount(Long fileId);

	List<TblSalesPreStaging> fetchErrorRecords(Long fileId, int firstResult, int pageSize);
 	
}
