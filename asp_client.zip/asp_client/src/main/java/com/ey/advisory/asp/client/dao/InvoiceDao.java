package com.ey.advisory.asp.client.dao;

import java.util.List;
import java.util.Set;

import com.ey.advisory.asp.client.domain.FileUploadMasterClient;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.client.dto.TblErrorAction;
import com.ey.advisory.asp.dto.InvoiceProcessDto;

public interface InvoiceDao {
	boolean  saveErrors(List<TblErrorAction> errorList);
	public boolean saveInvoiceStatus(Set<InvoiceProcessDto> invoice,Integer fileId) throws Exception;
	public List<InwardInvoiceModel> getInvoiceDocumentDetail(Set<InvoiceProcessDto> invoice);
	
	public boolean saveSalesErrorInfo(Set<TblSalesErrorInfo> errorInfo) throws Exception ;
	public boolean savePurchaseErrorInfo(Set<TblPurchaseErrorInfo> errorInfo) throws Exception;
	public boolean saveIsdErrorInfo(Set<TblIsdErrorInfo> errorInfo);
	public boolean saveTdsErrorInfo(Set<TblTdsErrorInfo> errorInfo);
	public boolean saveGstr2InvoiceStatus(Set<InvoiceProcessDto> invoice, Integer fileId);
	public boolean saveGstr7InvoiceStatus(Set<InvoiceProcessDto> invoice, Integer fileId);
	public void saveAfterReconStatus(String tableName, String fieldName, String status);
	void getGstinWithPan(String key, String PAN);
	int getAffectedInvoiceCountForGstin(String gstin,String processType);
    public boolean saveMailStatusDetailsInfo(Set<String> gstinList, String returnType); 
    
    boolean updateFileUploadStatus(long fileId, String returnType,String stage);
    boolean updateBifurcationFailStatus(long fileId, String returnType,String stage);
    boolean updateStageOneFailStatus(long fileId, String returnType,String stage);
    
    boolean timeoutAndUpdateFileUploadStatus(long fileId, String returnType,String stage);
    boolean markTechErrorInvoiceStatus(Integer fileId) throws Exception;
    
    public List<FileUploadMasterClient> getFileFromClientMaster(Long fileId);
  
	List<InwardInvoiceModel> getCRTaxableDetail(
			Set<InvoiceProcessDto> invoiceList);
	Integer getDocumentDetails(
			Set<InvoiceProcessDto> invoiceList);
	public Integer getDocumentDetails_CrDrInvDtl(Set<InvoiceProcessDto> invoiceList);
	public Integer getDocumentDetails_ITCDInvDtl(Set<InvoiceProcessDto> invoiceList);
	boolean gstr2MarkTechErrorInvoiceStatus(Integer fileId) throws Exception;
}
