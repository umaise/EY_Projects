package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.EntityModelDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.TblDivision;
import com.ey.advisory.asp.client.dto.GroupDto;

@Repository
public class EntityModelDaoImpl implements EntityModelDao {

	@Autowired
	private HibernateDao hibernateDao;

	private static final Logger LOGGER = Logger.getLogger(EntityModelDaoImpl.class);

	@Override
	public List<EntityModel> fetchEntityDetails() {
		List<EntityModel> entityDetails = null;
		
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityModel.class);
		List<?> lst =hibernateDao.find(detachedCriteria);
		if(lst!=null) {
			entityDetails = (List<EntityModel>) lst;
		} else {
			entityDetails = new ArrayList<EntityModel>();
		}
		return entityDetails;


	}

	@Override
	public EntityModel getEntityDetails(String entityId) {
		List<EntityModel> entityDetails;
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityModel.class);
		hibernateDao.createCriteria(EntityModel.class);
		detachedCriteria.add(Restrictions.eq("entityID", Integer.parseInt(entityId)));
		entityDetails = (List<EntityModel>) hibernateDao.find(detachedCriteria);
		if (entityDetails != null && !entityDetails.isEmpty()) {
			EntityModel entity = entityDetails.get(0);
			return entity;
		}
		return null;
	}

	@Override
	public List<EntityModel> fetchEntitiesByGroupId(String groupId) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityModel.class);
		hibernateDao.createCriteria(EntityModel.class);
		detachedCriteria.add(Restrictions.eq("groupId", Long.valueOf(groupId)));
		detachedCriteria.add(Restrictions.or(Restrictions.eq("isActive", Boolean.TRUE),Restrictions.isNull("isActive")));
		List<EntityModel> response = (List<EntityModel>) hibernateDao.find(detachedCriteria);
		return response;
	}

	@Override
	public List<TblDivision> fetchDivisionByEntityId(Integer entityId) {
		List<TblDivision> entities = new ArrayList<>();
		return entities;
	}

	@Override
	public List<String> fetchGSTINIdByEntity(Integer entityID) {
		List<String> response = new ArrayList<>();
		return response;
	}

	@Override
	public JSONArray fetchDivAndGSTIn(String id, boolean flag) {
		if (id != null) {
			JSONArray response = null;
			return response;
		} else
			return null;
	}
	
	@Override
	public void saveUserInClientTables(JSONObject groupJson, int userId) {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in saveUserInClientTables ");
			}
	}


	@Override
	public JSONObject fetchClientSideUserTablesAsJson(int userId, List<GroupDto> groupIds) {
		JSONObject returnObj = new JSONObject();
		return returnObj;
	}


	@Override
	public void updateUserInClientTables(JSONObject groupJson, int userID) {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in updateUserInClientTables ");
			}
	}

	@Override
	public void deleteObject(JSONObject json) {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in deleteObject ");
			}
	}

	@Override
	public List<EntityModel> getEntityDetails(List<Integer> entityId) {
		LOGGER.info("getEntityDetails() entityId are" + entityId);

		ArrayList<EntityModel> entityDetails=null;

		try {
			if (entityId != null && !entityId.isEmpty()) {
				DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityModel.class);
				detachedCriteria.add(Restrictions.in("entityID", entityId));

				entityDetails = (ArrayList<EntityModel>) hibernateDao.find(detachedCriteria);
				LOGGER.info("getEntityDetails() entityDetails  for entityId " + entityId + " are" + entityDetails);
				if (entityDetails != null && !entityDetails.isEmpty()) {

					return entityDetails;
				}

			}
		} catch (Exception e) {

			LOGGER.error("getEntityDetails() failed  for entityId " + entityId + e);
		}

		return entityDetails;
	}
	
	@Override
	public String fetchEntityNameById(Integer entityID) {
		String entityName;
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityModel.class);
		hibernateDao.createCriteria(EntityModel.class);
		detachedCriteria.add(Restrictions.eq("entityID", entityID));
		detachedCriteria.setProjection(Projections.projectionList()
		        .add(Projections.property("entityName")));
		List<String> entityNameList = (List<String>) hibernateDao.find(detachedCriteria);
		if (entityNameList != null && !entityNameList.isEmpty()) {
			entityName = entityNameList.get(0);
			return entityName;
		}
		return null;
	}
	
	@Override
	public String isEntityExitsWithName(String entityName) {
		String output = "0";
		List<EntityModel> entityDetails;
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityModel.class);
		hibernateDao.createCriteria(EntityModel.class);
		detachedCriteria.add(Restrictions.eq("entityName", entityName.trim()));
		entityDetails = (List<EntityModel>) hibernateDao.find(detachedCriteria);
		if (entityDetails != null && !entityDetails.isEmpty()) {
			output = "1";
		}
		return output;
	}

	@Override
	public String saveEntityData(EntityModel entity) throws Exception {
		LOGGER.info("Entered saveEntityData");
		String result = "FAILED";
		try{
			EntityModel entityModel= hibernateDao.load(EntityModel.class, entity.getEntityID());
			entityModel.setCompanyHQ(entity.getCompanyHQ());
			entityModel.setEntityType(entity.getEntityType());
			hibernateDao.merge(entityModel);
			result = "SUCCESS";
		}catch(Exception e){
			LOGGER.error("Exception in saveEntityData"+e);
			throw new Exception(e.getMessage());
		}
		return result;
	}

	
	
}
