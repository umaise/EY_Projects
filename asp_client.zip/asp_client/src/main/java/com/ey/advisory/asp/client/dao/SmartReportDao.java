package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.SmartReport;
import com.ey.advisory.asp.client.dto.SmartReportDto;

public interface SmartReportDao {
	
	public String saveSmartReportDetails(SmartReportDto smartReportDto);
	
	public List<SmartReport> getSmartReportDetails(String status);
	public boolean updateSmartReportPathAndFileName(String reportId,String filePath,String fileName);
	public boolean updateSmartReportStatus(String reportId,String status);
	public boolean findByApi(String gstin, String retPeriod, String api);

	public SmartReport getSmartReportDetailsByReportId(String reportId);
	
	public String saveGSTR1FFB2B(String jsonStr, String gstin, String retPeriod, Integer chunkId);

}
