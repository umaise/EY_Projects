package com.ey.advisory.asp.client.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.client.domain.TblTdsErrorInfo;
import com.ey.advisory.asp.client.service.SalePurchaseService;
import com.ey.advisory.asp.master.dto.SupplyMetaData;
import com.ey.advisory.asp.master.dto.ErrorMasterDto;
import com.ey.advisory.asp.master.dto.PurchaseMetaData;
import com.ey.advisory.asp.common.Constant;

@Component
public class ErrorActionUtility {

	private final static Logger LOG = LoggerFactory.getLogger(ErrorActionUtility.class);

	@Autowired(required = false)
	RedisTemplate<String, Object> redisTemplate;

	@Autowired
	private SalePurchaseService salePurchaseService;

	@SuppressWarnings("unchecked")
	public  TblSalesErrorInfo getSalesTblErrorInfo(OutwardInvoiceModel outwardInvoiceModel, String errorInfoCode, String columnNames, String processStatus,
			boolean isProcessed,String incidenceLevel){

		String errorColumnId = null;

		if(errorInfoCode==null){
			errorInfoCode="";
		}

		if(processStatus==null){
			processStatus="";
		}

		try{
			errorColumnId = getSupplyColumnId(columnNames);

			Object errorMasterDto = (Object)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);
			ErrorMasterDto dto = new ErrorMasterDto();

			if(errorMasterDto==null) {
				errorMasterDto = refreshErrorMasterMap(errorInfoCode);
			}

			if (errorMasterDto != null) {
				BeanUtils.copyProperties(errorMasterDto, dto);
				if (dto.getErrorInfoDesc() == null) {
					dto.setErrorInfoDesc("");
				}
				return new TblSalesErrorInfo(outwardInvoiceModel.getId(),outwardInvoiceModel.getFileID(),outwardInvoiceModel.getInvoiceKey(), errorInfoCode,
						dto.getErrorInfoDesc(), errorColumnId,
						processStatus, isProcessed, outwardInvoiceModel.getsGSTIN(),incidenceLevel,dto.getIsError(), Integer.parseInt(outwardInvoiceModel.getLineNumber()), outwardInvoiceModel.getTaxperiod());

			}

		}catch(NullPointerException ne){
			LOG.error("Error fetching ErrorDescription from Redis: ", ne);
		}
		catch(Exception e){
			LOG.error("Error Building tblErrorAction for invoice Key: " +outwardInvoiceModel.getInvoiceKey(), e);
		}

		return new TblSalesErrorInfo(outwardInvoiceModel.getId(),outwardInvoiceModel.getFileID(),outwardInvoiceModel.getInvoiceKey(), errorInfoCode, Constant.UNKNOWN_ERROR, errorColumnId, processStatus, 
				isProcessed, outwardInvoiceModel.getsGSTIN(),incidenceLevel, Constant.ERROR_CODE_MASTER_FLAG,Integer.parseInt(outwardInvoiceModel.getLineNumber()), outwardInvoiceModel.getTaxperiod());
	}

	private String getSupplyColumnId(String columnNames) {
		String columnId = "";
		String[] parts ;
		if (columnNames != null && columnNames.contains(",")) {
			parts = columnNames.split(",");
		} else {
			parts = new String[1];
			parts[0] = columnNames;
		}
		if (parts != null) {
			for (int i = 0; i < parts.length; i++) {
				Object supplyMasterObject = (Object)redisTemplate.opsForHash().get(Constant.SUPPLY_METADATA, parts[i]);

				if (supplyMasterObject != null) {
					SupplyMetaData supplyMasterDto = new SupplyMetaData();
					BeanUtils.copyProperties(supplyMasterObject,
							supplyMasterDto);
					if (i == 0)
						columnId = columnId
						+ supplyMasterDto.getColumnOrderNo()
						.toString();
					else
						columnId = columnId
						+ ", "
						+ supplyMasterDto.getColumnOrderNo()
						.toString();
				}
			}
		}

		return columnId;
	}



	@SuppressWarnings("unchecked")
	public  TblPurchaseErrorInfo getPurchaseTblErrorInfo(InwardInvoiceModel inwardInvoiceModel,
			String errorInfoCode, String errorColumnName, String processStatus,
			boolean isProcessed,String incidenceLevel){
		String errorColumnId = null;
		if(errorInfoCode==null){
			errorInfoCode="";
		}

		if(errorColumnName==null){
			errorColumnName="";
		}
		if(processStatus==null){
			processStatus="";
		}
		try{
			errorColumnId = getPurchaseColumnId(errorColumnName);
			Object errorMasterDto = (Object)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);

			ErrorMasterDto dto = new ErrorMasterDto();

			if(errorMasterDto==null) {
				errorMasterDto = refreshErrorMasterMap(errorInfoCode);
			}
			if (errorMasterDto != null) {
				BeanUtils.copyProperties(errorMasterDto, dto);
				if (dto.getErrorInfoDesc() == null) {

					dto.setErrorInfoDesc("");
				}
				return new TblPurchaseErrorInfo(inwardInvoiceModel.getId(), (int)inwardInvoiceModel.getFileID(),inwardInvoiceModel.getInvoiceKey(),errorInfoCode,
						dto.getErrorInfoDesc(),errorColumnId, null,
						processStatus, isProcessed, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, dto.getIsError(), inwardInvoiceModel.getLineNumber(), inwardInvoiceModel.getTaxPeriod());

			}

		}catch(NullPointerException ne){
			LOG.error("Error fetching ErrorDescription from Redis: ", ne);
		}
		catch(Exception e){
			LOG.error("Error Building tblErrorAction for purchase staging Id: " + inwardInvoiceModel.getId(), e);
		}

		return new TblPurchaseErrorInfo(inwardInvoiceModel.getId(), (int)inwardInvoiceModel.getFileID(), inwardInvoiceModel.getInvoiceKey(),errorInfoCode, Constant.UNKNOWN_ERROR,errorColumnId, null, processStatus, 
				isProcessed,inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, Constant.ERROR_CODE_MASTER_FLAG, inwardInvoiceModel.getLineNumber(), inwardInvoiceModel.getTaxPeriod());
	}


	private String getPurchaseColumnId(String columnNames) {
		String columnId = "";
		String[] parts ;
		if (columnNames != null && columnNames.contains(",")) {
			parts = columnNames.split(",");
		} else {
			parts = new String[1];
			parts[0] = columnNames;
		}
		if (parts != null) {
			for (int i = 0; i < parts.length; i++) {
				Object purchaseMasterObject = (Object)redisTemplate.opsForHash().get(Constant.PURCHASE_METADATA, parts[i]);

				if (purchaseMasterObject != null) {
					PurchaseMetaData purchaseMasterDto = new PurchaseMetaData();
					BeanUtils.copyProperties(purchaseMasterObject,
							purchaseMasterDto);
					if (i == 0)
						columnId = columnId
						+ purchaseMasterDto.getColumnOrderNo()
						.toString();
					else
						columnId = columnId
						+ ", "
						+ purchaseMasterDto.getColumnOrderNo()
						.toString();
				}
			}
		}

		return columnId;
	}


	/*@SuppressWarnings("unchecked")
	public  TblIsdErrorInfo getIsdTblErrorInfo(InwardInvoiceModel inwardInvoiceModel,
			String errorInfoCode, String errorColumnName, String processStatus,
			boolean isProcessed,String incidenceLevel){
		String errorColumnId = null;
		if(errorInfoCode==null){
			errorInfoCode="";
		}

		if(errorColumnName==null){
			errorColumnName="";
		}
		if(processStatus==null){
			processStatus="";
		}
		try{
			errorColumnId = getPurchaseColumnId(errorColumnName);
			Object errorMasterDto = (Object)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);

			ErrorMasterDto dto = new ErrorMasterDto();
			if(errorMasterDto==null) {
				errorMasterDto = refreshErrorMasterMap(errorInfoCode);
			}

			if (errorMasterDto != null) {
				BeanUtils.copyProperties(errorMasterDto, dto);
				if (dto.getErrorInfoDesc() == null) {
					dto.setErrorInfoDesc("");
				}
				return new TblIsdErrorInfo(inwardInvoiceModel.getId(), (int)inwardInvoiceModel.getFileID(),errorInfoCode,
						dto.getErrorInfoDesc(),errorColumnId, errorColumnName,
						processStatus, isProcessed, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, dto.getIsError());


			}

		}catch(NullPointerException ne){
			LOG.error("Error fetching ErrorDescription from Redis: ", ne);
		}
		catch(Exception e){
			LOG.error("Error Building tblErrorAction for purchase staging Id: " + inwardInvoiceModel.getId(), e);
		}

		return new TblIsdErrorInfo(inwardInvoiceModel.getId(), (int)inwardInvoiceModel.getFileID(), errorInfoCode, Constant.UNKNOWN_ERROR,errorColumnId, errorColumnName, processStatus, 
				isProcessed,inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, Constant.ERROR_CODE_MASTER_FLAG);
	}
*/

	@SuppressWarnings("unchecked")
	public  TblIsdErrorInfo getIsdTblErrorInfo(InwardInvoiceModel inwardInvoiceModel,
			String errorInfoCode, String errorColumnName, String processStatus,
			boolean isProcessed,String incidenceLevel){
		String errorColumnId = null;
		if(errorInfoCode==null){
			errorInfoCode="";
		}

		if(errorColumnName==null){
			errorColumnName="";
		}
		if(processStatus==null){
			processStatus="";
		}
		try{
			errorColumnId = getPurchaseColumnId(errorColumnName);
			Object errorMasterDto = (Object)redisTemplate.opsForHash().get(Constant.ERROR_MASTER_LIST, errorInfoCode);

			ErrorMasterDto dto = new ErrorMasterDto();
			if(errorMasterDto==null) {
				errorMasterDto = refreshErrorMasterMap(errorInfoCode);
			}

			if (errorMasterDto != null) {
				BeanUtils.copyProperties(errorMasterDto, dto);
				if (dto.getErrorInfoDesc() == null) {
					dto.setErrorInfoDesc("");
				}
				return new TblIsdErrorInfo(inwardInvoiceModel.getId(), (int)inwardInvoiceModel.getFileID(), inwardInvoiceModel.getInvoiceKey(),errorInfoCode,
						dto.getErrorInfoDesc(),errorColumnId, null,
						processStatus, isProcessed, inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, dto.getIsError(),inwardInvoiceModel.getLineNumber());


			}

		}catch(NullPointerException ne){
			LOG.error("Error fetching ErrorDescription from Redis: ", ne);
		}
		catch(Exception e){
			LOG.error("Error Building tblErrorAction for purchase staging Id: " + inwardInvoiceModel.getId(), e);
		}

		return new TblIsdErrorInfo(inwardInvoiceModel.getId(), (int)inwardInvoiceModel.getFileID(), inwardInvoiceModel.getInvoiceKey(),errorInfoCode, Constant.UNKNOWN_ERROR,errorColumnId, errorColumnName, processStatus, 
				isProcessed,inwardInvoiceModel.getDocumentNo(), inwardInvoiceModel.getCGSTIN(),incidenceLevel, Constant.ERROR_CODE_MASTER_FLAG,inwardInvoiceModel.getLineNumber());
	}
	@SuppressWarnings("unchecked")
	private ErrorMasterDto refreshErrorMasterMap(String errorInfoCode) {
		ErrorMasterDto dto = null;
		LOG.info("ErrorCode : "+ errorInfoCode +" not found in Redis, Refreshing errormaster map...");
		try {
			dto = salePurchaseService.refreshErrorCodeMapInRedis(errorInfoCode);

		} catch (Exception e) {
			LOG.error("Error refreshing ErrorMasterMap in Redis", e);
		} 

		return dto;
	}
}