package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR2SummaryAdvancePaidDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR2SummaryAdvancePaid;
@Repository
public class GSTR2SummaryAdvancePaidDaoImpl implements GSTR2SummaryAdvancePaidDao{
	
	@Autowired
	private HibernateDao  hibernateDao;
	private static final Logger logger = Logger.getLogger(GSTR2SummaryAdvancePaidDaoImpl.class);

	@Override
	public List<GSTR2SummaryAdvancePaid> getAdvancePaidMetadata() {
		
		List<GSTR2SummaryAdvancePaid> advancePaidList = new ArrayList<>();
		try {
			advancePaidList = (List<GSTR2SummaryAdvancePaid>)hibernateDao.loadAll(GSTR2SummaryAdvancePaid.class);
		} catch (Exception e) {
			
			logger.error("Exception in getAdvancePaidMetadata "+ e);
		}
		return advancePaidList;
	}

}
