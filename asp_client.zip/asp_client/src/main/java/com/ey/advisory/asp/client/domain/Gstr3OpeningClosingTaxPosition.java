package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.apache.log4j.Logger;

@Entity
@Table(name="tblOpeningClosingTaxPosition", schema="gstr3")
public class Gstr3OpeningClosingTaxPosition implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(Gstr3OpeningClosingTaxPosition.class);

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="TaxPositionID" , unique=true, nullable=false)
	private BigInteger taxPositionID;
	
	@Column(name="GSTIN" , unique=true, nullable=false)
	private String gstin;
	
	@Column(name="LedgerTypeID" , unique=true, nullable=false)
	private BigInteger ledgerTypeID;
	
	@Column(name="LedgerEntryDate" , unique=true, nullable=false)
	private Date ledgerEntryDate;
	
	@Column(name="TaxPeriod" , unique=true, nullable=false)
	private String taxPeriod;
	
	@Column(name="IsActive", unique=true, nullable=true)
	private boolean isActive;
	
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    //@JoinColumn(name = "BankAccDetailID",referencedColumnName="BankAccDetailID", insertable=false,updatable=false )
	@PrimaryKeyJoinColumn
	private BankAccountDetails bankAccountDetails;
	
	

	
	
	public BankAccountDetails getBankAccountDetails() {
		return bankAccountDetails;
	}
	public void setBankAccountDetails(BankAccountDetails bankAccountDetails) {
		this.bankAccountDetails = bankAccountDetails;
	}
	public Gstr3OpeningClosingTaxPosition(){
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in Gstr3OpeningClosingTaxPosition ");
			}
		
	}
	public BigInteger getTaxPositionID() {
		return taxPositionID;
	}

	public void setTaxPositionID(BigInteger taxPositionID) {
		this.taxPositionID = taxPositionID;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public BigInteger getLedgerTypeID() {
		return ledgerTypeID;
	}

	public void setLedgerTypeID(BigInteger ledgerTypeID) {
		this.ledgerTypeID = ledgerTypeID;
	}

	public Date getLedgerEntryDate() {
		return ledgerEntryDate;
	}

	public void setLedgerEntryDate(Date ledgerEntryDate) {
		this.ledgerEntryDate = ledgerEntryDate;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	
	
}
