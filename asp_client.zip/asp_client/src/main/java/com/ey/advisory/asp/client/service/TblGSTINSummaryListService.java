package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblGSTINSummaryList;
import com.ey.advisory.asp.client.dto.FileDto;

public interface TblGSTINSummaryListService {
	public List<TblGSTINSummaryList> getGstinRtSummaryType(List<Integer> fileIdList);
	public String insertUpdateGstr12SummaryStatus(List<TblGSTINSummaryList> gstinList);
	void updateGstinSummaryList(TblGSTINSummaryList gstinData);
}
