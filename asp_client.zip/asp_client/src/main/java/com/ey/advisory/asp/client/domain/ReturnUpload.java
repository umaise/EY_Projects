package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Raghavan.Venket
 *
 */
@Entity
@Table(name = "tblReturnUpload", schema="trans")
public class ReturnUpload implements Serializable{
	 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public Long getLoadId() {
		return loadId;
	}

	public void setLoadId(Long loadId) {
		this.loadId = loadId;
	}

	

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public Long getMinInvoice() {
		return minInvoice;
	}

	public void setMinInvoice(Long minInvoice) {
		this.minInvoice = minInvoice;
	}

	public Long getMaxInnvoice() {
		return maxInnvoice;
	}

	public void setMaxInnvoice(Long maxInnvoice) {
		this.maxInnvoice = maxInnvoice;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getTrxId() {
		return TrxId;
	}

	public void setTrxId(String trxId) {
		TrxId = trxId;
	}

	public String getGspRefId() {
		return gspRefId;
	}

	public void setGspRefId(String gspRefId) {
		this.gspRefId = gspRefId;
	}

	public Boolean getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(Boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Timestamp getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}

	public Timestamp getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Timestamp updatedDt) {
		this.updatedDt = updatedDt;
	}


	public Long getTblGstnreStatus() {
		return filingId;
	}

	public void setTblGstnreStatus(Long tblGstnreStatus) {
		this.filingId = tblGstnreStatus;
	}

	public String getGstnStatus() {
		return gstnStatus;
	}

	public void setGstnStatus(String gstnStatus) {
		this.gstnStatus = gstnStatus;
	}
	
	@Id
	@Column(name="LoadId")
	private Long loadId;
	
	@Column(name="ReturnFilingId")
	private Long filingId;
	
	@Column(name="ReturnType")
	private String returnType;
	
	@Column(name="MinInvoice")
	private Long minInvoice;
	
	@Column(name="MaxInnvoice")
	private Long maxInnvoice;
	
	@Column(name="RefId")
	private String refId;
	
	@Column(name="TrxId")
	private String TrxId; 	
	
	@Column(name="GspRefId")
	private String gspRefId;
	
	@Column(name="IsSuccess")
	private Boolean isSuccess; 	
	
	@Column(name="IsActive")
	private Boolean isActive;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss.SSS")
	@Column(name="CreatedDt")
	private Timestamp createdDt;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss.SSS")
	@Column(name="UpdatedDt")
	private Timestamp updatedDt; 
	
	@Column(name="GstnStatus")
	private String gstnStatus;
	
	
	//newly added
	
	 @Column(name="errorDesc")
		private String errorDesc;


	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	

	
}	
