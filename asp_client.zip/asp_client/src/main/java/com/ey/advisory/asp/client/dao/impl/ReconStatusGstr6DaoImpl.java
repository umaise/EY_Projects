package com.ey.advisory.asp.client.dao.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.ReconStatusGstr6Dao;
import com.ey.advisory.asp.client.domain.ReconStatusGstr6;
import com.ey.advisory.asp.common.Constant;

@Repository
public class ReconStatusGstr6DaoImpl implements ReconStatusGstr6Dao {

	private static final Logger LOGGER = Logger.getLogger(ReconStatusGstr6DaoImpl.class);
	
	@Autowired
	HibernateDao hibernateDao;

	@Override
	public ReconStatusGstr6 getReconStatus(String gstin, String taxPeriod,Integer masterId) {
		List<ReconStatusGstr6> reconStatusList = null;
		Criteria criteria = hibernateDao.createNormalCriteria(ReconStatusGstr6.class);
		criteria.add(Restrictions.eq("gstin", gstin));
		criteria.add(Restrictions.eq("taxPeriod", taxPeriod));
		criteria.add(Restrictions.eq("isActive", true));
		criteria.add(Restrictions.eq("masterId", masterId));
		reconStatusList = criteria.list();
		if (reconStatusList != null && reconStatusList.size() > 0) {
			return reconStatusList.get(0);
		}
		return null;
	}

	/**
	 * This method is to get the matched recon records.
	 * 
	 */
	@Override
	public String getMatchedReconRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("Start of getMatchedReconRecords");
		
		String jsonResponse = null;

		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetGstr6ReconMatchRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getMatchedReconRecords");
		
		return jsonResponse;
		 
	}

	/**
	 * This method is to get the ASP matched recon records.
	 * 
	 */
	@Override
	public String getMatchedAspReconRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("Start of getMatchedAspReconRecords");
		
		String jsonResponse = null;

		
		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetGstr6ReconMatchedASPRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getMatchedAspReconRecords");
		return jsonResponse;
	}

	/**
	 * This method is to get the mis matched recon records.
	 * 
	 */
	@Override
	public String getMisMatchedReconRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("Start of getMisMatchedReconRecords");
		
		String jsonResponse = null;

		
		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetGstr6ReconMissmatchRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getMisMatchedReconRecords");
		return jsonResponse;
	}

	/**
	 * This method is to get the additional recon records.
	 * 
	 */
	@Override
	public String getAdditionalReconRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("Start of getAdditionalReconRecords");
		
		String jsonResponse = null;

		
		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetGstr6ReconAdditionalRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getAdditionalReconRecords");
		return jsonResponse;
		 
	}

	/**
	 * This method is to get the recon missing records.
	 * 
	 */
	@Override
	public String getReconMissingRecords(String gstin, String taxPeriod, int offset, int pageSize) {

		LOGGER.info("End of getReconMissingRecords");
		
		String jsonResponse = null;

		
		try {
			Object[] obj = new Object[4];
			obj[0] = gstin;
			obj[1] = taxPeriod;
			obj[2] = pageSize;
			obj[3] = offset;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetGstr6ReconMissingRpt ?,?,?,?", obj);
			if (result != null && !result.isEmpty()) {
				jsonResponse = (String) result.get(0);
			}
		} catch (Exception e) {
			
			LOGGER.error(e);
		}
		
		LOGGER.info("End of getReconMissingRecords");
		
		return jsonResponse;
	}

	@Override
	public void saveReconStatus(String gstin, String taxPeriod, Integer masterId) {
		LOGGER.info("Start of saveReconStatus in client");
		ReconStatusGstr6 reconStatus = null;
		try{
			reconStatus = new ReconStatusGstr6();
			reconStatus.setGstin(gstin);
			reconStatus.setTaxPeriod(taxPeriod);
			reconStatus.setMasterId(masterId);
			reconStatus.setReconStatus("ReconInitiated");
			reconStatus.setCreatedDate(new Date());
			reconStatus.setIsActive(true);
			hibernateDao.save(reconStatus);
			LOGGER.info("End of saveReconStatus in client");
		}catch(Exception e){
			LOGGER.info("Exception in saveReconStatus in client "+e);
		}
	}

	@Override
	public void updateReconStatus(String gstin, String taxPeriod,Integer masterId) {
		LOGGER.info("Start of updateReconStatus in client");
		ReconStatusGstr6 reconStatus = null;
		try{
			reconStatus = getReconStatus(gstin,taxPeriod,masterId);
			if(reconStatus != null){
				reconStatus.setIsActive(false);
				hibernateDao.update(reconStatus);
			}
			LOGGER.info("End of updateReconStatus in client");
		}catch(Exception e){
			LOGGER.info("Exception  in updateReconStatus in client "+e);
		}
	}

	@Override
	public ReconStatusGstr6 getActiveReconStatus(String gstin, String taxPeriod) {
		List<ReconStatusGstr6> reconStatusList = null;
		Criteria criteria = hibernateDao.createNormalCriteria(ReconStatusGstr6.class);
		criteria.add(Restrictions.eq("gstin", gstin));
		criteria.add(Restrictions.eq("taxPeriod", taxPeriod));
		criteria.add(Restrictions.eq("isActive", true));
		reconStatusList = criteria.list();
		if (reconStatusList != null && reconStatusList.size() > 0) {
			return reconStatusList.get(0);
		}
		return null;
	}

	@Override
	public ReconStatusGstr6 getReconStatus(String gstin, String taxPeriod) {
		List<ReconStatusGstr6> reconStatusList = null;
		Criteria criteria = hibernateDao.createNormalCriteria(ReconStatusGstr6.class);
		criteria.add(Restrictions.eq("gstin", gstin));
		criteria.add(Restrictions.eq("taxPeriod", taxPeriod));
		criteria.add(Restrictions.eq("isActive", true));
		reconStatusList = criteria.list();
		if (reconStatusList != null && reconStatusList.size() > 0) {
			return reconStatusList.get(0);
		}
		return null;
	}

	@Override
	public void updateReconStatus(String gstin, String taxPeriod,
			Integer masterId, String status) {
		LOGGER.info("Start of updateReconcilationStatus in client");
		ReconStatusGstr6 reconStatus = null;
		try{
			reconStatus = getReconStatus(gstin,taxPeriod,masterId);
			if(reconStatus != null){
				reconStatus.setReconStatus(status);
				
				if(status.equalsIgnoreCase("RECON_FAILED")){
					
					reconStatus.setIsAdditionalGenerated("Error");
					reconStatus.setIsMatchedASPGenerated("Error");
					reconStatus.setIsMatchedGenerated("Error");
					reconStatus.setIsMisMatchedGenerated("Error");
					reconStatus.setIsMissingGenerated("Error");
				}
				hibernateDao.update(reconStatus);
			}
			LOGGER.info("End of updateReconcilationStatus in client");
		}catch(Exception e){
			LOGGER.info("Exception  in updateReconcilationStatus in client "+e);
		}
	}

	@Override
	public void updateReconCompletionDate(String gstin, String taxPeriod,
			Integer masterId) {
			LOGGER.info("Start of updateReconCompletedDate in client");
			ReconStatusGstr6 reconStatus = null;
			try{
				reconStatus = getReconStatus(gstin,taxPeriod,masterId);
				if(reconStatus != null){
					Date now = new Date(); 
		        	Timestamp ts = new Timestamp(now.getTime());
					reconStatus.setReconCompleteDate(ts);
					hibernateDao.update(reconStatus);
				}
				LOGGER.info("End of updateReconCompletedDate in client");
			}catch(Exception e){
				LOGGER.info("Exception  in updateReconCompletedDate in client "+e);
			}
			
		}

	@Override
	public void updateReconReportStatus(String gstin, String taxPeriod,
			String reportType, String status) {
		LOGGER.info("Start of updateReconReportStatus in client");
		ReconStatusGstr6 reconStatus = null;
		try{
			reconStatus = getReconStatus(gstin,taxPeriod);
			if(reconStatus != null){
				
				if(reportType.equalsIgnoreCase(Constant.MISSING_REPORT)){
					
					reconStatus.setIsMissingGenerated(status);	
				}
				
				else if(reportType.equalsIgnoreCase(Constant.MATCHED_REPORT)){
					
					reconStatus.setIsMatchedGenerated(status);	
				}
				
				else if(reportType.equalsIgnoreCase(Constant.MIS_MATCHED_REPORT)){
					
					reconStatus.setIsMisMatchedGenerated(status);	
				}
				
				else if(reportType.equalsIgnoreCase(Constant.MATCHED_ASP_REPORT)){
					
					reconStatus.setIsMatchedASPGenerated(status);	
				}
				else if(reportType.equalsIgnoreCase(Constant.ADDITIONAL_REPORT)){
					
					reconStatus.setIsAdditionalGenerated(status);	
				}
				
				hibernateDao.update(reconStatus);
			}
			LOGGER.info("End of updateReconReportStatus in client");
		}catch(Exception e){
			LOGGER.info("Exception  in updateReconReportStatus in client "+e);
		}
		
	}
		
		
	}
	
