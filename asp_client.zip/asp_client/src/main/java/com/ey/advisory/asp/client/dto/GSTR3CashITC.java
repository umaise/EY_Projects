package com.ey.advisory.asp.client.dto;


public class GSTR3CashITC
{
    private Cash_bal cash_bal;

    private Itc_bal itc_bal;

    private String gstin;

    public Cash_bal getCash_bal ()
    {
        return cash_bal;
    }

    public void setCash_bal (Cash_bal cash_bal)
    {
        this.cash_bal = cash_bal;
    }

    public Itc_bal getItc_bal ()
    {
        return itc_bal;
    }

    public void setItc_bal (Itc_bal itc_bal)
    {
        this.itc_bal = itc_bal;
    }

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

   

}
			



class Itc_bal
{
private double cgst_bal;

private double sgst_bal;

private double igst_bal;

private double cess_bal;

public double getCgst_bal ()
{
return cgst_bal;
}

public void setCgst_bal (double cgst_bal)
{
this.cgst_bal = cgst_bal;
}

public double getSgst_bal ()
{
return sgst_bal;
}

public void setSgst_bal (double sgst_bal)
{
this.sgst_bal = sgst_bal;
}

public double getIgst_bal ()
{
return igst_bal;
}

public void setIgst_bal (double igst_bal)
{
this.igst_bal = igst_bal;
}

public double getCess_bal ()
{
return cess_bal;
}

public void setCess_bal (double cess_bal)
{
this.cess_bal = cess_bal;
}

}





class Cash_bal
{
private Cess cess;

private double cgst_tot_bal;

private double cess_tot_bal;

private Igst igst;

private double sgst_tot_bal;

private Cgst cgst;

private double igst_tot_bal;

private Sgst sgst;

public Cess getCess ()
{
return cess;
}

public void setCess (Cess cess)
{
this.cess = cess;
}

public double getCgst_tot_bal ()
{
return cgst_tot_bal;
}

public void setCgst_tot_bal (double cgst_tot_bal)
{
this.cgst_tot_bal = cgst_tot_bal;
}

public double getCess_tot_bal ()
{
return cess_tot_bal;
}

public void setCess_tot_bal (double cess_tot_bal)
{
this.cess_tot_bal = cess_tot_bal;
}

public Igst getIgst ()
{
return igst;
}

public void setIgst (Igst igst)
{
this.igst = igst;
}

public double getSgst_tot_bal ()
{
return sgst_tot_bal;
}

public void setSgst_tot_bal (double sgst_tot_bal)
{
this.sgst_tot_bal = sgst_tot_bal;
}

public Cgst getCgst ()
{
return cgst;
}

public void setCgst (Cgst cgst)
{
this.cgst = cgst;
}

public double getIgst_tot_bal ()
{
return igst_tot_bal;
}

public void setIgst_tot_bal (double igst_tot_bal)
{
this.igst_tot_bal = igst_tot_bal;
}

public Sgst getSgst ()
{
return sgst;
}

public void setSgst (Sgst sgst)
{
this.sgst = sgst;
}

}


class Igst
{
private double pen;

private double fee;

private double tx;

private double oth;

private double intr;

public double getPen ()
{
return pen;
}

public void setPen (double pen)
{
this.pen = pen;
}

public double getFee ()
{
return fee;
}

public void setFee (double fee)
{
this.fee = fee;
}

public double getTx ()
{
return tx;
}

public void setTx (double tx)
{
this.tx = tx;
}

public double getOth ()
{
return oth;
}

public void setOth (double oth)
{
this.oth = oth;
}

public double getIntr ()
{
return intr;
}

public void setIntr (double intr)
{
this.intr = intr;
}

}


class Cess
{
private double pen;

private double fee;

private double tx;

private double oth;

private double intr;

public double getPen ()
{
return pen;
}

public void setPen (double pen)
{
this.pen = pen;
}

public double getFee ()
{
return fee;
}

public void setFee (double fee)
{
this.fee = fee;
}

public double getTx ()
{
return tx;
}

public void setTx (double tx)
{
this.tx = tx;
}

public double getOth ()
{
return oth;
}

public void setOth (double oth)
{
this.oth = oth;
}

public double getIntr ()
{
return intr;
}

public void setIntr (double intr)
{
this.intr = intr;
}

}
	

class Cgst
{
private double pen;

private double fee;

private double tx;

private double oth;

private double intr;

public double getPen ()
{
return pen;
}

public void setPen (double pen)
{
this.pen = pen;
}

public double getFee ()
{
return fee;
}

public void setFee (double fee)
{
this.fee = fee;
}

public double getTx ()
{
return tx;
}

public void setTx (double tx)
{
this.tx = tx;
}

public double getOth ()
{
return oth;
}

public void setOth (double oth)
{
this.oth = oth;
}

public double getIntr ()
{
return intr;
}

public void setIntr (double intr)
{
this.intr = intr;
}
}


class Sgst
{
private double pen;

private double fee;

private double tx;

private double oth;

private double intr;

public double getPen ()
{
return pen;
}

public void setPen (double pen)
{
this.pen = pen;
}

public double getFee ()
{
return fee;
}

public void setFee (double fee)
{
this.fee = fee;
}

public double getTx ()
{
return tx;
}

public void setTx (double tx)
{
this.tx = tx;
}

public double getOth ()
{
return oth;
}

public void setOth (double oth)
{
this.oth = oth;
}

public double getIntr ()
{
return intr;
}

public void setIntr (double intr)
{
this.intr = intr;
}

 
}

