package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.SummaryFileLoadMaster;



public interface ClientSpCallService {
	
	 public String executeStoredProcedure(String storedProcSchema, String storedProcName,
				String inputParamsCount, List<String> inputParamsList) throws Exception;
	 public List executeStoredProcedureReturnList(String storedProcSchema,
				String storedProcName, String inputParamsCount,
				List<String> inputParamsList) throws Exception ;
	

	
}
