package com.ey.advisory.asp.client.dao.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.TblGSTINListDao;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.TblGSTINList;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatusPK;
import com.ey.advisory.asp.common.Constant;

@Repository
public class TblGSTINListDaoImpl implements TblGSTINListDao{
	private static final Logger logger = Logger.getLogger(TblGSTINListDaoImpl.class);
	private static final String CLASS_NAME = TblGSTINListDaoImpl.class.getName();
	
	@Autowired
	private HibernateDao  hibernateDao;
	
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.dao.TblGSTINListDao#insertUpdateGstr12FilingStatus(java.util.List)
	 */
	@Override
    public String insertUpdateGstr12FilingStatus(List<TblGSTINList> gstinList) {
         logger.info("*********** entering Job insertUpdateGstr12FilingStatus " + gstinList);
  
        try{
        	
        	 TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
 	         
 	         TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
         for(TblGSTINList gstinRec:gstinList)
         {
        	 DetachedCriteria detachedCriteria = hibernateDao
     				.createCriteria(TblGstinRetutnFilingStatus.class);
     		detachedCriteria
     				.add(Restrictions.eq("id.gstinId", gstinRec.getgSTIN()));
     		detachedCriteria.add(Restrictions.eq("id.taxPeriod", gstinRec.getTaxPeriod()));
     		detachedCriteria.add(Restrictions.eq("id.returnType", gstinRec.getReturnType()));
     		detachedCriteria.add(Restrictions.eq("status", Constant.SAVESTATE));
     		List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
     		if(null!=gstinRetutnFilingStatus && !gstinRetutnFilingStatus.isEmpty()){
     			//do nothing
     		}else
     		{
     			 //insert record for GSTIN 
     	         tblGstinRetutnFilingStatusPK.setGstinId(gstinRec.getgSTIN());
     	         tblGstinRetutnFilingStatusPK.setReturnType(gstinRec.getReturnType());
     	         tblGstinRetutnFilingStatusPK.setTaxPeriod(gstinRec.getTaxPeriod());            
     	         tblGstinRetutnFilingStatus.setStatus(Constant.SAVESTATE);
     	         tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
     	         tblGstinRetutnFilingStatus.setIsSuccess(Boolean.TRUE);
     	         hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
     		}
         }
   
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job insertUpdateGstr12FilingStatus "+e);
		} 
         return "Success";
    }
	
	
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.dao.TblGSTINListDao#updateGstinList(com.ey.advisory.asp.client.domain.TblGSTINList)
	 */
	@Override
	public void updateGstinList(TblGSTINList gstinData) {
		 logger.info("*********** entering method updateGstinList " + gstinData);
		 try{
			 gstinData.setIsChunkingInitiated(Boolean.TRUE);//to do (update the status column)
			 gstinData.setUpdatedDate(new Date());
		 hibernateDao.saveOrUpdate(gstinData);
		 }
		 catch(Exception ex){
			 logger.error("*********** ERROR in method updateGstinList "+ex);
		 }
	}
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#getGstinRtType(java.util.List)
	 * get the gstin based on entity level
	 */
	@Override
	public List<TblGSTINList> getGstinRtType(String returnType) {
		logger.info("*********** entering method getGstinRtType ");
        List<TblGSTINList> tblGSTINList = null;
        try
        {
               
               /* DetachedCriteria detachedCriteriasub = hibernateDao.createCriteria(EntityHierarchy.class);
               detachedCriteriasub.add(Restrictions.eq("entityID",Integer.parseInt(entityId)));
               ProjectionList projectionList=Projections.projectionList();
               projectionList.add(Projections.property("gSTIN"));
               detachedCriteriasub.setProjection(projectionList);*/
               
            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGSTINList.class);
            detachedCriteria.add(Restrictions.eq("isRoutingDone",Boolean.TRUE));
            detachedCriteria.add(Restrictions.eq("isChunkingInitiated",Boolean.FALSE));
            detachedCriteria.add(Restrictions.eq("returnType", returnType));
            detachedCriteria.addOrder(Order.asc("taxPeriod"));
            //detachedCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
/*               detachedCriteria.add(Subqueries.propertyIn("gSTIN", detachedCriteriasub));
*/               tblGSTINList = (List<TblGSTINList>) hibernateDao.find(detachedCriteria);
        }
        catch(Exception ex)
        {
               logger.error("*********** ERROR in Job getGstinRtType *********** "+ex);
        }
        return tblGSTINList;

	}
	
	@Override
	public List<TblGSTINList> getGstinRtType(String returnType, String gstin,String taxPeriod) {
		logger.info("*********** entering method getGstinRtType ");
        List<TblGSTINList> tblGSTINList = null;
        try
        {               
            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGSTINList.class);
            detachedCriteria.add(Restrictions.eq("isRoutingDone",Boolean.TRUE));
            detachedCriteria.add(Restrictions.eq("isChunkingInitiated",Boolean.FALSE));
            detachedCriteria.add(Restrictions.eq("returnType", returnType));
            detachedCriteria.add(Restrictions.eq("taxPeriod", taxPeriod));
            detachedCriteria.add(Restrictions.eq("gSTIN", gstin));
            detachedCriteria.addOrder(Order.asc("taxPeriod"));
            //detachedCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
               tblGSTINList = (List<TblGSTINList>) hibernateDao.find(detachedCriteria);
        }
        catch(Exception ex)
        {
               logger.error("*********** ERROR in Job getGstinRtType *********** "+ex);
        }
        return tblGSTINList;

	}
	
	/**
     * this method is used to save transaction id in database
     * 
     * @param gsptrnsId
     * @param gstnTransId
     * @param refId 
     * @param fileId
     */
    @SuppressWarnings("unchecked")
    public void updateGstnTranId(String transid, long chunkId) 
    {
        logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
            +Constant.LOGGER_METHOD+" updateGstnTranId()");
        List<String> inputParamsList = new ArrayList<>();
        try {
        	
        	inputParamsList.add(String.valueOf(chunkId));
        	inputParamsList.add("");
        	inputParamsList.add(null);
        	inputParamsList.add(transid);
        	hibernateDao.executeStoredProcedure(Constant.DBO_SCHEMA,Constant.SAVE_PROC, "4", inputParamsList);
                 	
        } catch (Exception exec) {
            logger.info(Constant.LOGGER_ERROR + CLASS_NAME
                +Constant.LOGGER_METHOD+" updateGstnTranId()" + exec);
        }
        logger.info(Constant.LOGGER_EXITING + CLASS_NAME
            +Constant.LOGGER_METHOD+" updateGstnTranId()");
    }


	@Override
	public void updateGstinList(int fileId) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " updateGstinList(fileId)");
		List<TblGSTINList> tblGSTINList = null;
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGSTINList.class);
			detachedCriteria.add(Restrictions.eq("fileId", fileId));
			tblGSTINList = (List<TblGSTINList>) hibernateDao.find(detachedCriteria);
			if (tblGSTINList != null) {
				TblGSTINList gstnData = tblGSTINList.get(0);
				gstnData.setIsRoutingDone(Boolean.TRUE);
				gstnData.setUpdatedDate(new Date());
				hibernateDao.update(gstnData);
			}
		} catch (Exception exec) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " updateGstinList(fileId)"
					+ exec);
		}
	}
	
		
	public void getGstinListForGstr2A(){
		
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " getGstinListForGstr2A()");
		List<TblGSTINList> tblGSTINList = null;
		try {
			
			ProjectionList projection1=Projections.projectionList();
			projection1.add(Projections.property("id.gstinId"));
			projection1.add(Projections.property("id.taxPeriod"));	
			
			DetachedCriteria criteria1 = DetachedCriteria.forClass(TblGstinRetutnFilingStatus.class)
	                .setProjection(Projections.distinct(projection1)).add(Restrictions.and(Restrictions.ne("status",Constant.FILED),
	                Restrictions.ne("id.returnType",Constant.GSTR2_RETURN_TYPE)));
			
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGSTINList.class);
			SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-dd");
		    Date currentDate = formatter.parse(new Date().toString());
			detachedCriteria.add(Restrictions.and(Restrictions.eq("returnType", Constant.GSTR2_RETURN_TYPE),
					Restrictions.le("updatedDate", currentDate), Property.forName("gSTIN").in(criteria1),
					Property.forName("taxPeriod").in(criteria1) ));
			
		
			tblGSTINList = (List<TblGSTINList>) hibernateDao.find(detachedCriteria);
			
			if (tblGSTINList != null) {
				TblGSTINList gstnData = tblGSTINList.get(0);
				gstnData.setIsRoutingDone(Boolean.TRUE);
				gstnData.setUpdatedDate(new Date());
				hibernateDao.update(gstnData);
			}
		} catch (Exception exec) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " updateGstinList(fileId)"
					+ exec);
		}
		
	}
	
}
