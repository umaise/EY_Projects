package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.apache.log4j.Logger;
import org.hibernate.validator.constraints.Length;


/**
 * The persistent class for the tblErrorInfo database table.
 * 
 */
@Entity
@Table(name="tblSalesErrorInfo" , schema="trans")
@NamedQuery(name="TblSalesErrorInfo.findAll", query="SELECT t FROM TblSalesErrorInfo t")
public class TblSalesErrorInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(TblSalesErrorInfo.class);

	private String gstin;
	private Integer errorInfoID;
	private Timestamp createDate;
	private String createdBy;
	private String errorColumnId;
	private String errorDesc;
	private String errorInfoCode;
	private boolean isProcessed;
	private String processStatus;
	private Timestamp updatedDate;
	private char isError;
	private String incidenceLevel;
	private String invoiceKey;
	private Integer lineNo;
	private Integer salesStagingID;
	private Integer fileId;
	private String taxPeriod;
	
	public TblSalesErrorInfo() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in TblSalesErrorInfo ");
			}
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ErrorInfoID")
	public Integer getErrorInfoID() {
		return this.errorInfoID;
	}

	public void setErrorInfoID(Integer errorInfoID) {
		this.errorInfoID = errorInfoID;
	}

	@Column(name="IsError")
	public char getIsError() {
		return isError;
	}

	public void setIsError(char isError) {
		this.isError = isError;
	}

	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	
	@Column(name="CreateDate")
	public Timestamp getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	@Column(name="CreatedBy")@Length(max = 50)
	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	
	@Column(name="ColumnID")@Length(max = 100)
	public String getErrorColumnId() {
		return errorColumnId;
	}

	public void setErrorColumnId(String errorColumnId) {
		this.errorColumnId = errorColumnId;
	}

	@Column(name="ErrorDesc")@Length(max = 500)
	public String getErrorDesc() {
		return this.errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	
	@Column(name="ErrorInfoCode")@Length(max = 10)
	public String getErrorInfoCode() {
		return this.errorInfoCode;
	}

	public void setErrorInfoCode(String errorInfoCode) {
		this.errorInfoCode = errorInfoCode;
	}

	@Column(name="IsProcessed")
	public boolean getIsProcessed() {
		return this.isProcessed;
	}

	public void setIsProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	@Column(name="ProcessStatus")@Length(max = 20)
	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	@Column(name="UpdatedDate")
	public Timestamp getUpdatedDate() {
		return this.updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Column(name="Gstin")
	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	
	@Column(name="IncidenceLevel")
	public String getIncidenceLevel() {
		return incidenceLevel;
	}

	public void setIncidenceLevel(String incidenceLevel) {
		this.incidenceLevel = incidenceLevel;
	}
	
	@Column(name="InvoiceKey")@Length(max = 90)
	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	@Column(name="LineNum")
	public Integer getLineNo() {
		return lineNo;
	}

	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}

	@Column(name="SalesStagingID")
	public Integer getSalesStagingID() {
		return salesStagingID;
	}

	public void setSalesStagingID(Integer salesStagingID) {
		this.salesStagingID = salesStagingID;
	}

	@Column(name="FileId")
	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	@Column(name="TaxPeriod")
	public String getTaxPeriod() {
        return taxPeriod;
    }

	public void setTaxPeriod(String taxPeriod) {
        this.taxPeriod = taxPeriod;
    }
	
	public TblSalesErrorInfo(Integer salesStagingID,Integer fileId,String invoiceKey, String errorInfoCode, String errorDesc, String errorColumnId,
			String processStatus, boolean isProcessed, String gstin,String incidenceLevel, char isError, Integer lineNo, String taxPeriod) {
		this.invoiceKey=invoiceKey;
		this.errorInfoCode=errorInfoCode;
		this.errorDesc=errorDesc;
		this.errorColumnId=errorColumnId;
		this.processStatus=processStatus;
		this.isProcessed=isProcessed;
		this.gstin=gstin;
		this.incidenceLevel=incidenceLevel;
		this.isError = isError;
		this.lineNo = lineNo;
		this.salesStagingID=salesStagingID;
		this.fileId=fileId;
		this.taxPeriod = taxPeriod;
	}
	
}