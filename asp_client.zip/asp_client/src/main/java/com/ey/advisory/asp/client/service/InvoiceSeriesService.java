package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblInvoiceSeries;

public interface InvoiceSeriesService {
	
	List<TblInvoiceSeries> fetchAll();
	Long getTotalRecordCount(Long fileId);
	List<TblInvoiceSeries> fetchTotalRecords(Long fileId, int firstResult, int pageSize);

}
