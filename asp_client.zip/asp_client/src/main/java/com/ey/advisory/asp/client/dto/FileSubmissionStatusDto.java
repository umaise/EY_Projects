package com.ey.advisory.asp.client.dto;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;

public class FileSubmissionStatusDto {
private BigInteger fIleSubmissionStatusUID ;
	
	private String refNo  ;
	
	private String gstin ;
	
	private String returnPeriod  ;
	
	private Date createdOn ;
	
	private boolean isFiled;

	public BigInteger getfIleSubmissionStatusUID() {
		return fIleSubmissionStatusUID;
	}

	public void setfIleSubmissionStatusUID(BigInteger fIleSubmissionStatusUID) {
		this.fIleSubmissionStatusUID = fIleSubmissionStatusUID;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getReturnPeriod() {
		return returnPeriod;
	}

	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public boolean isFiled() {
		return isFiled;
	}

	public void setFiled(boolean isFiled) {
		this.isFiled = isFiled;
	}
	
	
}
