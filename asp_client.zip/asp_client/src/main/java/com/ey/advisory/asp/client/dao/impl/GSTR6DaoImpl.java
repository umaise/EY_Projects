package com.ey.advisory.asp.client.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR6Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.FIleSubmissionStatusDetailsGstr6;
import com.ey.advisory.asp.client.domain.GSTR6FB2BInvoiceDetailsModel;
import com.ey.advisory.asp.client.domain.GSTR6TurnoverDetailsPriorFY;
import com.ey.advisory.asp.client.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.client.domain.ISDDeterminationMaster;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.ReconProcessDTO;
import com.ey.advisory.asp.client.domain.TblCrDrITCAInvoiceDetails;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatusPK;
import com.ey.advisory.asp.client.domain.TblTurnoverDetails;
import com.ey.advisory.asp.client.domain.TblTurnoverMaster;
import com.ey.advisory.asp.client.dto.Gstr6Dto;
import com.ey.advisory.asp.client.dto.PreGSTTurnOverDto;
import com.ey.advisory.asp.client.dto.PreGSTTurnOverWrapper;
import com.ey.advisory.asp.client.util.CommonUtillity;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.dto.LineItemDTO;


@Repository
public class GSTR6DaoImpl implements GSTR6Dao {
	private static final Logger log = Logger.getLogger(GSTR6DaoImpl.class);
	private static final String CLASS_NAME = GSTR6DaoImpl.class.getName();
    @Autowired
    private HibernateDao hibernateDao;	

    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> validateOriginalDocumentNo(String originalDocumentNo, String entityName, String columnName) {

        String queryStr = "FROM " + entityName + " e where e." + columnName + " = ?";
        return (List<T>) hibernateDao.find(queryStr, originalDocumentNo);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> validateOriginalDocNoDocDate(String docNum, Date documentDate, String entityName, String column1,
        String column2) {
/*
        String queryStr = "FROM " + entityName + " e where e." + column1 + " = ?   and e." + column2 + " = ?";
        return (List<T>) hibernateDao.find(queryStr, docNum,documentDate);*/

		String queryStr = "select a FROM " + entityName + " a, InvoiceKeyDetail b where a." + column1 + " = ? and b.isSuccessToGstn=1 and a.invoiceKey=b.invoiceKey";
		return (List<T>) hibernateDao.find(queryStr, docNum);
    }

    @Override
	public List<String> getGSTINListByPAN(String entityName, String custGSTINColumn, String gstinColumn,
			String invNumColumn, String invDateColumn, String custGSTIN, String PAN, String gstin, String invNum, Date invDate) {
		String queryStr = "Select e." + custGSTINColumn + " FROM " + entityName + " e WHERE e." + invNumColumn + " = ? AND e." 
			+ invDateColumn + " = ? AND e." + custGSTINColumn + " != ? AND e." + custGSTINColumn + " like ? AND e." + gstinColumn + " = ?" ;
		
		return (List<String>) hibernateDao.find(queryStr, invNum, invDate, custGSTIN, "%"+PAN+"%", gstin);
		
		
	}
    

    @Override
    
    public GSTR6FB2BInvoiceDetailsModel getReconInvoice(String entityName, String custGSTIN, String gstin, String invNum, Date invDate) {
    	 Session session = null;
    	 GSTR6FB2BInvoiceDetailsModel model = null;
    	try{
        session = hibernateDao.getSession();

        String queryStr = "FROM " + entityName + " e where e.cust_GSTIN = :custGSTIN and e.gstin = :gstin and e.doc_Num = :invNum and e.doc_Date = :invDate";
        Query query = session.createQuery(queryStr);
        query.setParameter("custGSTIN", custGSTIN);
        query.setParameter("gstin", gstin);
        query.setParameter("invNum", invNum);
        query.setParameter("invDate", invDate);
        model = (GSTR6FB2BInvoiceDetailsModel) query.uniqueResult();
    	}catch(Exception e){
        	log.error("Error Saving recon Invoice", e);
        }
    	finally{
    		if(session!=null){
    			session.close();
    		}
    	}
        return model;
    }

    @Override
    public void updateReconFilingStatus(Object model) {
    	try{
    		 hibernateDao.saveOrUpdate(model);
    	}catch(Exception e){
    		log.error("Error Saving recon Invoice", e);
    	}

    }

    @Override
    public void updateITCValues(Set<LineItemDTO> redisLineItemSet) {
        Session session = hibernateDao.getSession();
        Iterator<LineItemDTO> invoiceIterator=redisLineItemSet.iterator();
        try{
        while(invoiceIterator.hasNext()){
            LineItemDTO lineItemDto = invoiceIterator.next();
            switch (lineItemDto.getTableType()) {
                case Constant.B2B:
                    executeITCUpdate(session, "Gstr6B2BItemDetailsModel",
                        lineItemDto);
                    break;
                case Constant.B2BA:
                    executeITCUpdate(session, "Gstr6B2BAItemDetailsModel",
                        lineItemDto);
                    break;

                case Constant.CDN:
                    executeCDNITCUpdate(session, "GSTR6FCDN_InvoiceDetail",
                        lineItemDto);
                    break;
                case Constant.CDNA:
                    executeCDNITCUpdate(session, "GSTR6FCDNA_InvoiceDetail",
                        lineItemDto);
                    break;
                default:
                    break;
            }
        }
        }catch(Exception e){
        	log.error("Error Updating ITC values ", e);
        }finally {
			if(session != null){
				session.close();
			}
		}
        
    }

    private void executeITCUpdate(Session session, String entity, LineItemDTO lineItemDto){
        try {
			String queryStr = "update " +  entity + " e set e.itcIgstAmt = :ItcIgstAmt, e.itcSgstAmt = :ItcSgstAmt, e.itcCgstAmt = :ItcCgstAmt, e.itcCessAmt = :ItcCessAmt where e.gstr2B2BItemDetailsPK.lineNo = :lineNo and e.gstr2B2BItemDetailsPK.invoiceDetails.invoiceDetailsId = :Id ";
			Query query =	session.createQuery(queryStr);
			query.setParameter("ItcIgstAmt", lineItemDto.getItcIgstAmt());
			query.setParameter("ItcSgstAmt", lineItemDto.getItcSgstAmt());
			query.setParameter("ItcCgstAmt", lineItemDto.getItcCgstAmt());
			query.setParameter("ItcCessAmt", lineItemDto.getItcCessAmt());
			query.setParameter("Id", lineItemDto.getId());
			query.setParameter("lineNo", lineItemDto.getLineNo());
			query.executeUpdate();
		} catch (Exception e) {
			log.error("Error executeITCUpdate", e);
		}finally{
			if(session!=null){
				session.close();
			}
		}
    }

    private void executeCDNITCUpdate(Session session, String entity, LineItemDTO lineItemDto){
        try {
			String queryStr = "update " +  entity + " e set e.itcIgstAmt = :ItcIgstAmt, e.itcSgstAmt = :ItcSgstAmt, e.itcCgstAmt = :ItcCgstAmt, e.itcCessAmt = :ItcCessAmt where e.id = :Id ";
			Query query =	session.createQuery(queryStr);
			query.setParameter("ItcIgstAmt", lineItemDto.getItcIgstAmt());
			query.setParameter("ItcSgstAmt", lineItemDto.getItcSgstAmt());
			query.setParameter("ItcCgstAmt", lineItemDto.getItcCgstAmt());
			query.setParameter("ItcCessAmt", lineItemDto.getItcCessAmt());
			query.setParameter("Id", lineItemDto.getId());
			query.executeUpdate();
		} catch (Exception e) {
			log.error("Error executeITCUpdate", e);
		}finally{
			if(session!=null){
				session.close();
			}
		}

    }

	@Override
	public <T> T getReconInvoice(String entityName, String custGSTINColumn, String gstinColumn, String invNumColumn,
			String invDateColumn, String custGSTIN, String gstin, String invNum, Date invDate) {
		T reconInvoice = null;
		Session session = null;
		try{
			String queryStr = "FROM " + entityName + " e WHERE e." + invNumColumn + " = ? AND e." 
					+ invDateColumn + " = ? AND e." + custGSTINColumn + " = ? AND e." + gstinColumn + " = ?" ;
			
			session = hibernateDao.getSession();
			
			Query query = session.createQuery(queryStr);
			query.setParameter(0, invNum);
			query.setParameter(1, invDate);
			query.setParameter(2, custGSTIN);
			query.setParameter(3, gstin);
			reconInvoice = (T) query.uniqueResult();
			
		}catch(Exception e){
			log.error("Error Getting Recon Invoice", e);
		}finally {
			if(session != null){
				session.close();
			}
		}
		
			return reconInvoice;
	}

	@Override
	public <T> T getReconInvoice(String entityName, String invoiceIdColumn, Long invoiceDetailsId) {
		T reconInvoice = null;
		Session session = null;
		try{
			String queryStr = "FROM " + entityName + " e WHERE e." + invoiceIdColumn + " = :invoiceId";
			
			session = hibernateDao.getSession();
			Query query = session.createQuery(queryStr);
			query.setParameter("invoiceId", invoiceDetailsId);
			reconInvoice = (T) query.uniqueResult();
		}catch(Exception e){
			log.error("Error Getting Recon Invoice", e);
		}finally {
			if(session != null){
				session.close();
			}
		}
			return reconInvoice;
	}
	
	@Override
	public <T> T getDRInvoice(String entityName, String invoiceIdColumn, String invoiceDetailsId,String gstinColumn,String gstinVAlue) {
		T reconInvoice = null;
		Session session = null;
		try{
			String queryStr = "FROM " + entityName + " e WHERE e." + invoiceIdColumn + " = :invoiceId"+" and e."+ gstinColumn +" = :gstinVAlue";
			
			session = hibernateDao.getSession();
			Query query = session.createQuery(queryStr);
			query.setParameter("invoiceId", invoiceDetailsId);
			query.setParameter("gstinVAlue", gstinVAlue);
			if(query.list()!=null && !query.list().isEmpty()){
			reconInvoice = (T) query.list().get(0);
			}
		}catch(Exception e){
			log.error("Error Getting Recon Invoice", e);
		}finally {
			if(session != null){
				session.close();
			}
		}
			return reconInvoice;
	}
	
	@Override
	public ItemMaster fetchHsnSacDetails(String hsnSac) {
		
		DetachedCriteria criteria= hibernateDao.createCriteria(ItemMaster.class);
		
		criteria.add(Restrictions.eq("hsn", hsnSac));
		 List<ItemMaster> itemregHsn = (List<ItemMaster>) hibernateDao.find(criteria);
		 
		 if(itemregHsn!=null && (!itemregHsn.isEmpty())){
			 
			 return itemregHsn.get(0);
			 
		 }
		 
		 return null;
		
	}

	@Override
	public GlobalGSTRatesMasterI fetchHsnSacDetailsFromGlobal(String hsnSac) {
DetachedCriteria criteria= hibernateDao.createCriteria(GlobalGSTRatesMasterI.class);
		
		criteria.add(Restrictions.eq("hsn_sac", hsnSac));
		
 List<GlobalGSTRatesMasterI> globalregHsn = (List<GlobalGSTRatesMasterI>) hibernateDao.find(criteria);
		 
		 if(globalregHsn!=null && (!globalregHsn.isEmpty())){
			 
			 return globalregHsn.get(0);
			 
		 }
		return null;
	}
	
	@Override
	public List<FIleSubmissionStatusDetailsGstr6> getFileGstr6Status(Gstr6Dto gstr6Dto){
		  List<FIleSubmissionStatusDetailsGstr6> fIleSubmissionStatus1 = null;
		  try{
			if(gstr6Dto != null){
			  DetachedCriteria detachedCriteria =	hibernateDao.createCriteria(FIleSubmissionStatusDetailsGstr6.class);
		      detachedCriteria.add(Restrictions.eq("gstin", gstr6Dto.getGstin()));
		      detachedCriteria.add(Restrictions.eq("returnPeriod", gstr6Dto.getRtPeriod()));
		      detachedCriteria.setProjection(Projections.property("isFiled"));
		      fIleSubmissionStatus1 = (List<FIleSubmissionStatusDetailsGstr6>) hibernateDao.find(detachedCriteria);
		      if(fIleSubmissionStatus1.isEmpty()){
		    	 // return (List<FIleSubmissionStatusDetailsGstr6>) new FIleSubmissionStatusDetailsGstr6() ;
		    	  fIleSubmissionStatus1=new ArrayList<>();
		    	  return fIleSubmissionStatus1;
		      }
			}
		  }catch(Exception e){
			  log.error(e);
		  }
		return fIleSubmissionStatus1;
	}
	
	@Override
	public List<String> fetchISDDistributionListForGstin(JSONObject jsonObj){
		jsonObj.put(Constant.ENTITY, 34);
		String queryStr = "select distinct(a.gSTIN) from EntityHierarchy a, TblGstinDetailsDomain b"+
							" where a.entityID='"+jsonObj.get(Constant.ENTITY).toString()+"' and a.gSTIN not in ('"+String.valueOf(jsonObj.get(Constant.GSTIN_CODE))+"') and a.gSTIN = b.gstinId and b.typeOfReg!='ISD'";
		Session session = null;
		try{
			session = hibernateDao.getSession();
			Query query = session.createQuery(queryStr);
	    	List entityGstins=query.list();
	    	return entityGstins;
	    }catch(Exception e){
	    	 log.error(Constant.LOGGER_ERROR+" "+Constant.LOGGER_METHOD,e);
	    	 return null;
	    }finally {
			if(session != null){
				session.close();
			}
		}
	}
	

	/*@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Object getErrorReportDetails(JSONObject jsonObj) {
		List<String> errorsXml  = new ArrayList<>();		
		try {        
			List<String> inputList=new ArrayList<>();
			inputList.add(((String) jsonObj.get(Constant.ENTITY)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.ENTITY) );
			inputList.add(((String) jsonObj.get(Constant.CIRCLE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.CIRCLE) );
			inputList.add(((String) jsonObj.get(Constant.GSTIN_CODE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.GSTIN_CODE) );
			inputList.add(((String) jsonObj.get(Constant.SUB_DIVISION)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.SUB_DIVISION) );
			inputList.add(((String) jsonObj.get(Constant.PROFIT_CENTER)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.PROFIT_CENTER) );
			inputList.add(((String) jsonObj.get(Constant.BUSINESS_UNIT)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.BUSINESS_UNIT) );
			inputList.add(((String) jsonObj.get(Constant.PLANT_CODE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.PLANT_CODE) );
			inputList.add(((String) jsonObj.get(Constant.FROM_TAXPERIOD)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.FROM_TAXPERIOD) );
			inputList.add(((String) jsonObj.get(Constant.TO_TAXPERIOD)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.TO_TAXPERIOD) );					
			errorsXml = hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.GSTR6_ERROR_REPORT_PROC_NAME, String.valueOf(inputList.size()), inputList);
			
			
		} catch (Exception e) {
			
			log.error("Exception in getErrorReportDetails"+ e);
		}
		return errorsXml.get(0);
	}
	*/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Object getErrorReportDetails(JSONObject jsonObj) {
		List<String> errorsXml  = new ArrayList<>();		
		String procName="";
		try {        
			List<String> inputList=new ArrayList<>();
			inputList.add(((String) jsonObj.get(Constant.ENTITY)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.ENTITY) );
			inputList.add(((String) jsonObj.get(Constant.CIRCLE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.CIRCLE) );
			inputList.add(((String) jsonObj.get(Constant.GSTIN_CODE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.GSTIN_CODE) );
			inputList.add(((String) jsonObj.get(Constant.SUB_DIVISION)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.SUB_DIVISION) );
			inputList.add(((String) jsonObj.get(Constant.PROFIT_CENTER)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.PROFIT_CENTER) );
			inputList.add(((String) jsonObj.get(Constant.BUSINESS_UNIT)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.BUSINESS_UNIT) );
			inputList.add(((String) jsonObj.get(Constant.PLANT_CODE)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.PLANT_CODE) );
			inputList.add(((String) jsonObj.get(Constant.FROM_TAXPERIOD)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.FROM_TAXPERIOD) );
			inputList.add(((String) jsonObj.get(Constant.TO_TAXPERIOD)).equalsIgnoreCase("null") ? null :(String) jsonObj.get(Constant.TO_TAXPERIOD) );					
				
				//inputList.add(((String) jsonObj.get("slctText")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("slctText") );
				//inputList.add(((String) jsonObj.get("fileId")).equalsIgnoreCase("null") ? "0" :(String) jsonObj.get("fileId") );
				//errorsXml = hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.GSTR6_ERROR_REPORT_PROC_NAME, String.valueOf(inputList.size()), inputList);	
				
				String processType = String.valueOf(jsonObj.get(Constant.PROCESS_TYPE));
				if(processType.equalsIgnoreCase(Constant.GSTR6_ERROR_REPORT)){
					inputList.add(((String) jsonObj.get("slctText")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("slctText") );
					inputList.add(((String) jsonObj.get("fileId")).equalsIgnoreCase("null") ? "0" :(String) jsonObj.get("fileId") );
					procName=Constant.GSTR6_ERROR_REPORT_PROC_NAME;
					
				}else if(processType.equalsIgnoreCase(Constant.RECTIFICATION_GSTR6))
				{	
					inputList.add(((String) jsonObj.get("slctText")).equalsIgnoreCase("null") ? "1" :(String) jsonObj.get("slctText") );
					inputList.add(((String) jsonObj.get("fileId")).equalsIgnoreCase("null") ? "0" :(String) jsonObj.get("fileId") );
					procName=Constant.GSTR6_RECTIFICATION_REPORT_PROC_NAME;				
				}							
				errorsXml = hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, procName, String.valueOf(inputList.size()), inputList);
				
				
			} catch (Exception e) {
				
				log.error("Exception in getErrorReportDetails"+ e);
			}
			return errorsXml.get(0);
		}
		
	
@Override
	public List<String> updateInvoiceMappedRows(JSONObject jsonObj){
		Session session = null;
		List response = null;
		
		String status="Failed";
		try {
			StringBuilder queryString = new StringBuilder("exec ");
			queryString.append(Constant.SAVE_DETERMINATION_SCHEMA);
			queryString.append(".");
			queryString.append(Constant.GSTR6_SAVE_DETERMINATION);
			queryString.append(" ? ");
			session = hibernateDao.getSession();
			SQLQuery query = session.createSQLQuery(queryString.toString());
			query.setString(0,  String.valueOf(jsonObj));
			//query.setString(1,  String.valueOf(jsonObj.get(Constant.FROM_TAXPERIOD)));
			
			 response = query.list();
			if(response!=null){
				return response;
				//status="Success";
			}
			
	
	    }catch(Exception e){
	    	 log.error(Constant.LOGGER_ERROR+" "+Constant.LOGGER_METHOD,e);
	    	 return response;
	    }finally {
			if(session != null){
				session.close();
			}
		}
		return response;
	}
	
	@Override
	public int checkFinalInvUploadCompleted(String taxperiod,String gstin){
		if(log.isInfoEnabled())	
			log.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : checkFinalInvUploadCompleted");
		int count =0;
		  try{
			if(taxperiod != null && gstin!=null){
			  DetachedCriteria detachedCriteria =	hibernateDao.createCriteria(ISDDeterminationMaster.class);
		      detachedCriteria.add(Restrictions.eq("isdgstin", gstin));
		      detachedCriteria.add(Restrictions.eq("taxPeriod", taxperiod));
		      detachedCriteria.add(Restrictions.eq("isFinalupload", "1"));
		       count =  hibernateDao.find(detachedCriteria).size();
		      
			}
			return count;
		  }catch(Exception e){
			  log.error(e);
			  return count;
		  }
		
	}
	
	public String getInvoiceMappingDetails(String gstinId,String taxPeriod) {
		List<String> invoiceMappingXml  = new ArrayList<>();	
		String invoiceMapping = "";
		try {        
			List<String> inputList=new ArrayList<>();
			inputList.add(null != gstinId ? (gstinId.equalsIgnoreCase("null") ? null : gstinId) : null);
			inputList.add(null != taxPeriod ? (taxPeriod.equalsIgnoreCase("null") ? null : taxPeriod) : null);
			invoiceMappingXml = hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.GSTR6_INVOICE_REPORT_PROC_NAME, String.valueOf(inputList.size()), inputList);			
		} catch (Exception e) {
			
			log.error("Exception in getErrorReportDetails"+ e);
		}
		if(!CommonUtillity.isEmpty(invoiceMappingXml)){
			invoiceMapping = invoiceMappingXml.get(0);
		}
		return invoiceMapping;
	}
	
	public String getDeterminationReport(String gstinId,String taxPeriod) {
		List<String> determinationReportXml  = new ArrayList<>();	
		String dterminationReport="";
		try {        
			List<String> inputList=new ArrayList<>();
			inputList.add(null != gstinId ? (gstinId.equalsIgnoreCase("null") ? null : gstinId) : null);
			inputList.add(null != taxPeriod ? (taxPeriod.equalsIgnoreCase("null") ? null : taxPeriod) : null);
			determinationReportXml = hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.GSTR6_DETERMINATION_REPORT_PROC_NAME, String.valueOf(inputList.size()), inputList);			
		} catch (Exception e) {
			log.error("Exception in getDeterminationReport"+ e);
		}
		if(!CommonUtillity.isEmpty(determinationReportXml)){
			dterminationReport= determinationReportXml.get(0);
		}
		return dterminationReport;
	}
	
	@Override
	public int checkHsnSac(String hsnSac) {

		List<GlobalGSTRatesMasterI> hsnList = null;
		String hsnRecord = ""; int count=0;
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GlobalGSTRatesMasterI.class);

		detachedCriteria.add(Restrictions.eq("hsnsac", hsnSac));
		hsnList = (List<GlobalGSTRatesMasterI>) hibernateDao.find(detachedCriteria);
		if(hsnList.isEmpty())
			count=0;
		else 
			count=1;
		if(count==1){
			for (GlobalGSTRatesMasterI gstRateMaster : hsnList) {
				hsnRecord += gstRateMaster.getHSNorSAC();
			}
			if (hsnRecord.equals("HSN")) 
				count=0;			
		}	
		return count;
	}
	
	
	@Override
	public List<String> saveDeterminationRowsData(JSONObject jsonObj){
		List response = new ArrayList<>();
		try {
			List<?> result = null;
			Object[] obj = new Object[1];
			obj[0] = String.valueOf(jsonObj);
				result = hibernateDao.executeNativeSql(
						" exec dbo.uspgstr6SummaryUpdate ?",obj);
				if(result!=null){
					response.add(result.get(0));
				}
			
		}catch(Exception e){
	    	 log.error(Constant.LOGGER_ERROR+" "+Constant.LOGGER_METHOD+ " saveDeterminationRowsData" , e);
	    	 return response;
	    }
		return response ;
	}
	@Override
	public List<String> submitDeterminationRowsData(JSONObject jsonObj){
		List response = new ArrayList<>();
		try {
			List<?> result = null;
			Object[] obj = new Object[1];
			obj[0] = String.valueOf(jsonObj);
				result = hibernateDao.executeNativeSql(
						" exec dbo.uspgstr6SummarySubmit ?",obj);
				if(result!=null){
					response.add(result.get(0));
				}
		}catch(Exception e){
	    	 log.error(Constant.LOGGER_ERROR+" "+Constant.LOGGER_METHOD+ " submitDeterminationRowsData" , e);
	    	 return response;
	    }
		return response ;
	} 
	
	@Override
	public String getDetSummaryDownload(JSONObject jsonObj) {
		
		List<String> detSummaryXml  = new ArrayList<>();	
		String determinationSumm = "";
		try {        
			List<String> inputList=new ArrayList<>();		
			inputList.add(((String) jsonObj.get("GstnId")).equalsIgnoreCase("null") ? null :(String) jsonObj.get("GstnId") );
			inputList.add(((String) jsonObj.get("TaxPeriod")).equalsIgnoreCase("null") ? null :(String) jsonObj.get("TaxPeriod") );
			inputList.add(((String) jsonObj.get("TabId")).equalsIgnoreCase("null") ? null :(String) jsonObj.get("TabId") );
			
			detSummaryXml = hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.GSTR6_DOWNLOAD_DETSUMM_PROC_NAME, String.valueOf(inputList.size()), inputList);

		} catch (Exception e) {
			
			log.error("Exception in getErrorReportDetails"+ e);
		}
		if(!CommonUtillity.isEmpty(detSummaryXml)){
			determinationSumm = detSummaryXml.get(0);
		}
		return determinationSumm;
	}

	
	@Override
	public Object getPreGSTTurnOverDataFromDB(String gstinId,String finYear) {	
		//String result="";
		List<?> result = null;
		Object[] obj = new Object[2];
		obj[0] = gstinId;
		obj[1] = finYear;
		try {
			result = hibernateDao.executeNativeSql(
					" exec dbo.uspgstr6TurnOverSummary_PreGST ?,?",obj);
			if(result!=null){
				 return result.get(0); 
				//	return "[{\"GSTN\":\"37GSPAD0501G5ZA\",\"GSTNUserName\":\"Uname\",   \"Email\":\"abc@ey.com\",   \"Statecode\":\"02\",   \"IsUnregistredEntity\":\"N\",   \"Turnover\": [               {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY12\" 			   }, 			  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY13\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY14\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY15\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY16\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY17\" 			   } 			  ] },   {\"GSTN\":\"37GSPAD0501G5ZB\",   \"GSTNUserName\":\"Uname\",   \"Email\":\"abc@ey.com\",   \"Statecode\":\"02\",   \"IsUnregistredEntity\":\"N\",   \"Turnover\": [  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY12\" 			   }, 			  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY13\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY14\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY15\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY16\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY17\" 			   }] },   {\"GSTN\":\"UnRegistered Entity_1\",   \"GSTNUserName\":\"NA\",   \"Email\":\"abc@ey.com\",   \"Statecode\":\"02\",   \"IsUnregistredEntity\":\"Y\",   \"Turnover\": [  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY12\" 			   }, 			  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY13\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY14\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY15\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY16\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY17\" 			   }] }]";
			}
	    }catch(Exception e){
	    	log.error("Error in fetching turnover details from DB . Method:getPreGSTTurnOverDataFromDB" , e);
	    	 return null;
	    }
		return null;
	}
	
	@Override
	public Object getDistributionTuroverTab1FromDB(String gstinId,String taxPeriod) {	
		//String result="";
		List<?> result = null;
		Object[] obj = new Object[1];
		obj[0] = gstinId;
		//obj[1] = taxPeriod;
		try {
			result = hibernateDao.executeNativeSql(
					" exec dbo.uspgstr6TurnOverSummary ?",obj);
			if(result!=null){
				 return result.get(0); 
				//	return "[{\"GSTN\":\"37GSPAD0501G5ZA\",\"GSTNUserName\":\"Uname\",   \"Email\":\"abc@ey.com\",   \"Statecode\":\"02\",   \"IsUnregistredEntity\":\"N\",   \"Turnover\": [               {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY12\" 			   }, 			  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY13\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY14\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY15\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY16\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY17\" 			   } 			  ] },   {\"GSTN\":\"37GSPAD0501G5ZB\",   \"GSTNUserName\":\"Uname\",   \"Email\":\"abc@ey.com\",   \"Statecode\":\"02\",   \"IsUnregistredEntity\":\"N\",   \"Turnover\": [  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY12\" 			   }, 			  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY13\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY14\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY15\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY16\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY17\" 			   }] },   {\"GSTN\":\"UnRegistered Entity_1\",   \"GSTNUserName\":\"NA\",   \"Email\":\"abc@ey.com\",   \"Statecode\":\"02\",   \"IsUnregistredEntity\":\"Y\",   \"Turnover\": [  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY12\" 			   }, 			  {\"TurnoverValue\":\"4567890123.45\", 			  \"FYYear\":\"FY13\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY14\" 			  }, 			  {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY15\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY16\" 			  }, 			   {\"TurnoverValue\":\"4567890123.45\", 			   \"FYYear\":\"FY17\" 			   }] }]";
			}
	    }catch(Exception e){
	    	log.error("Error in fetching turnover details from DB . getDistributionTuroverTab1FromDB" , e);
	    	 return null;
	    }
		return null;
	}
	
	
	@Override
	public void saveNewEntityDetails(TblTurnoverMaster tblTurnoverMaster){
		if(log.isInfoEnabled())	
			log.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : saveNewEntityDetails");
		Session session = null;
		try{
			 			
			   session = hibernateDao.getSession();
				String queryStr = "insert into gstr6.TblTurnoverMaster(ISDGSTN,GSTN,Email,IsUnregistredEntity,StateCode,GSTNUserName,IsActive) VALUES(?,?,?,?,?,?,?)";

				SQLQuery query = session.createSQLQuery(queryStr);
				query.setParameter(0, tblTurnoverMaster.getIsdgstn());
				query.setParameter(1, tblTurnoverMaster.getGstin());
				query.setParameter(2, tblTurnoverMaster.getEmail());
				query.setParameter(3, tblTurnoverMaster.isUnregistredEntity());
				query.setParameter(4, tblTurnoverMaster.getStateCode());
				query.setParameter(5, tblTurnoverMaster.getGstnUserName());
				query.setParameter(6, tblTurnoverMaster.isActive());
				query.executeUpdate();
			
			//hibernateDao.save(tblTurnoverMaster);
		} catch (Exception e) {
			log.info(Constant.LOGGER_ERROR + " Method : saveNewEntityDetails", e);
		} finally {
			if(session != null  && session.isOpen()){
				session.close();
			}
		}
		
		
	}
	
	@Override
	public void saveNewTurnoverData(TblTurnoverDetails tblTurnoverDetails){
		if(log.isInfoEnabled())	
			log.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : saveNewTurnoverData");
		Session session = null;
		try{		
			   session = hibernateDao.getSession();
				String queryStr = "insert into gstr6.TblTurnoverDetails(TurnoverMasterID,TaxPeriod,IsFreezed,Amount) VALUES(?,?,?,?)";

				SQLQuery query = session.createSQLQuery(queryStr);
				query.setParameter(0, tblTurnoverDetails.getTurnoverMasterID());
				query.setParameter(1, tblTurnoverDetails.getTaxPeriod());
				query.setParameter(2, tblTurnoverDetails.isFreezed());
				query.setParameter(3, tblTurnoverDetails.getAmount());
				query.executeUpdate();
		} catch (Exception e) {
			log.info(Constant.LOGGER_ERROR + " Method : saveNewTurnoverData", e);
		} finally {
			if(session != null  && session.isOpen()){
				session.close();
			}
		}
	}
}
