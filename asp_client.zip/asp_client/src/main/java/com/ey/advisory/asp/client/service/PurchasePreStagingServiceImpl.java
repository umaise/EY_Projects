package com.ey.advisory.asp.client.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.TblPurchasePreStaging;
import com.ey.advisory.asp.common.Constant;

@Service
public class PurchasePreStagingServiceImpl implements PurchasePreStagingService{
	
	 @Autowired
	  HibernateDao hibernateDao;

	    private static final Logger logger = Logger.getLogger(PurchasePreStagingServiceImpl.class);

	@Override
	public List<TblPurchasePreStaging> fetchAll() {
		return hibernateDao.loadAllByNamedQuery("TblPurchasePreStaging.findAll");
	}

	@Override
	public Long getTotalCount(Long fileId) {
		 Long count = null;
		  try { 
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblPurchasePreStaging.class);
			  criteriaCount.add(Restrictions.eq("fileID", fileId));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + PurchasePreStagingServiceImpl.class.getName()
	                + " Method : getStageInfo()" + exe);
	        }
	
		return count;
	}

	@Override
	public List<TblPurchasePreStaging> fetchPages(Long fileId, int firstResult,
			int pageSize) {
		List<TblPurchasePreStaging>  purchasePreStagingList = null;
		  try {
			  Criteria criteria = hibernateDao.createNormalCriteria(TblPurchasePreStaging.class);
			  criteria.add(Restrictions.eq("fileID", fileId));
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("id"));
			  purchasePreStagingList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + PurchasePreStagingServiceImpl.class.getName()
	                + " Method : fetchPages()" + exe);
	        }
	
		return purchasePreStagingList;
	}
	
	@Override
	public Long getDupCount(Long fileId) {
		 Long count = null;
		  try { 
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblPurchasePreStaging.class);
			  criteriaCount.add(Restrictions.eq("fileID", fileId));
			  criteriaCount.add(Restrictions.eq("duplicateStatus", "D"));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + PurchasePreStagingServiceImpl.class.getName()
	                + " Method : getDupCount()" + exe);
	        }
	
		return count;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<TblPurchasePreStaging> fetchDupRecords(Long fileId, int firstResult, int pageSize) {
		List<TblPurchasePreStaging>  purPreStagingList = null;
		  try {
			  Criteria criteria = hibernateDao.createNormalCriteria(TblPurchasePreStaging.class);
			  criteria.add(Restrictions.eq("fileID", fileId));
			  criteria.add(Restrictions.eq("duplicateStatus", "D"));
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("id"));
			  purPreStagingList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + PurchasePreStagingServiceImpl.class.getName()
	                + " Method : fetchDupRecords()" + exe);
	        }
	
		return purPreStagingList;
	}

	@Override
	public Long getTotalErrorCount(Long fileId) {
		 Long count = null;
		  try { 
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblPurchasePreStaging.class);
			  criteriaCount.add(Restrictions.eq("fileID", fileId));
			  criteriaCount.add(Restrictions.isNull("duplicateStatus"));
			  criteriaCount.add(Restrictions.eq("isError", "1"));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + PurchasePreStagingServiceImpl.class.getName()
	                + " Method : getTotalErrorCount()" + exe);
	        }
	
		return count;
	}

	@Override
	public List<TblPurchasePreStaging> fetchErrorRecords(Long fileId, int firstResult, int pageSize) {
		List<TblPurchasePreStaging>  purPreStagingList = null;
		  try {
			  Criteria criteria = hibernateDao.createNormalCriteria(TblPurchasePreStaging.class);
			  criteria.add(Restrictions.eq("fileID", fileId));
			  criteria.add(Restrictions.isNull("duplicateStatus"));
			  criteria.add(Restrictions.eq("isError", "1"));
			  
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("id"));
			  purPreStagingList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + PurchasePreStagingServiceImpl.class.getName()
	                + " Method : fetchDupRecords()" + exe);
	        }
	
		return purPreStagingList;
	}

}
