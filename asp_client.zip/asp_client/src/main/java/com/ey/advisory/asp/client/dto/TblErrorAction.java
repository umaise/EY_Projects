package com.ey.advisory.asp.client.dto;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the tblErrorAction database table.
 * 
 */

public class TblErrorAction implements Serializable {
	private static final long serialVersionUID = 1L;

	private int errorActionID;

	private String actionCode;

	private String createdBy;


	private String descrpt;

	private String docNum;

	private String errorCode;

	private String gstinid;

	private String updatedBy;


	public TblErrorAction(String actionCode, String errorCode, String docNum, String gstin) {
		this.actionCode = actionCode;
		this.errorCode = errorCode;
		this.docNum = docNum;
		this.gstinid = gstin;
	}

	public int getErrorActionID() {
		return this.errorActionID;
	}

	public void setErrorActionID(int errorActionID) {
		this.errorActionID = errorActionID;
	}

	public String getActionCode() {
		return this.actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getDescrpt() {
		return this.descrpt;
	}

	public void setDescrpt(String descrpt) {
		this.descrpt = descrpt;
	}

	public String getDocNum() {
		return this.docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	public String getErrorCode() {
		return this.errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getGstinid() {
		return this.gstinid;
	}

	public void setGstinid(String gstinid) {
		this.gstinid = gstinid;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


}