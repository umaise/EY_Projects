package com.ey.advisory.asp.client.service.gstr2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GSTR2SummaryAdvanceAdjustedDao;
import com.ey.advisory.asp.client.domain.GSTR2SummaryAdvanceAdjusted;

@Service
public class GSTR2SummaryAdvanceAdjustedServiceImpl implements GSTR2SummaryAdvanceAdjustedService {

	@Autowired
	private GSTR2SummaryAdvanceAdjustedDao advanceAdjustedDao;
	
	@Override
	public List<GSTR2SummaryAdvanceAdjusted> getAdvanceAdjustedMetadata() {
		return advanceAdjustedDao.getAdvanceAdjustedMetadata();
	}

	
	
	

}
