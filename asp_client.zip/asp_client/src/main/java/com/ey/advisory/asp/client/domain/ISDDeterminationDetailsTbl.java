package com.ey.advisory.asp.client.domain;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblISDDeterminationDetails",schema="gstr6")
public class ISDDeterminationDetailsTbl implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "InvoiceKey")
	private String invoiceKey;
	
	@Column(name = "InvoiceRefKey")
	private Long invoiceRefKey;
	
	@Column(name = "RecordType")
	private String recordType;
	
	@Column(name = "GSTIN")
	private String isdgstin;
	
	@Column(name = "IsDistribuited")
	private String isDistribuited;
	
	@Column(name = "Mapping")
	private String mapping;
	
	@Column(name = "CreatedDate")
	private String createdDate;
	
	@Column(name = "CreatedBy")
	private String createdBy;
	
	@Column(name = "IsDeleted")
	private String isDeleted;
	
	@Column(name = "IsActive")
	private String isActive;
	
	@Column(name = "UpdatedDate")
	private String updatedDate;
	
	@Column(name = "UpdatedBy")
	private String updatedBy;
	
	@Column(name = "ISDDeterminationMasterID")
	private Long isdDeterminationMasterID;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public Long getInvoiceRefKey() {
		return invoiceRefKey;
	}

	public void setInvoiceRefKey(Long invoiceRefKey) {
		this.invoiceRefKey = invoiceRefKey;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getIsdgstin() {
		return isdgstin;
	}

	public void setIsdgstin(String isdgstin) {
		this.isdgstin = isdgstin;
	}

	public String getIsDistribuited() {
		return isDistribuited;
	}

	public void setIsDistribuited(String isDistribuited) {
		this.isDistribuited = isDistribuited;
	}

	public String getMapping() {
		return mapping;
	}

	public void setMapping(String mapping) {
		this.mapping = mapping;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Long getIsdDeterminationMasterID() {
		return isdDeterminationMasterID;
	}

	public void setIsdDeterminationMasterID(Long isdDeterminationMasterID) {
		this.isdDeterminationMasterID = isdDeterminationMasterID;
	}

	
	
}
