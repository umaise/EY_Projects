/**
 * 
 */
package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Uma.Chandranaik
 *
 */
@Entity
@Table(name="tblgstr3CashLedgerDetails", schema="gstr3")
public class CashLedgerDetails  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private Long cashID;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "MasterLedgerID")
	private CashITCLedgerMaster masterId;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "AccountHeadID")
	private Gstr3AccountHead accHeadId;
	
	@Column(name="IsActive")
	private boolean isActive;
	
	@Column(name="Tax")
	private BigDecimal tax;
	
	@Column(name="Interest")
	private BigDecimal interest;
	
	@Column(name="Penalty")
	private BigDecimal penalty;
	
	@Column(name="Fee")
	private BigDecimal fee;
	
	@Column(name="Others")
	private BigDecimal others;
	
	@Column(name="Total")
	private BigDecimal total;

	public Long getCashID() {
		return cashID;
	}

	public void setCashID(Long cashID) {
		this.cashID = cashID;
	}

	public CashITCLedgerMaster getMasterId() {
		return masterId;
	}

	public void setMasterId(CashITCLedgerMaster masterId) {
		this.masterId = masterId;
	}

	public Gstr3AccountHead getAccHeadId() {
		return accHeadId;
	}

	public void setAccHeadId(Gstr3AccountHead accHeadId) {
		this.accHeadId = accHeadId;
	}

	public BigDecimal getTax() {
		return tax;
	}

	public void setTax(BigDecimal tax) {
		this.tax = tax;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public BigDecimal getPenalty() {
		return penalty;
	}

	public void setPenalty(BigDecimal penalty) {
		this.penalty = penalty;
	}

	public BigDecimal getFee() {
		return fee;
	}

	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}

	public BigDecimal getOthers() {
		return others;
	}

	public void setOthers(BigDecimal others) {
		this.others = others;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	

}
