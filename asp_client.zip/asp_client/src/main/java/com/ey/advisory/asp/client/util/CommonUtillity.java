package com.ey.advisory.asp.client.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.DynamicSmartReportDto;

public class CommonUtillity {

	private static List<SimpleDateFormat> patternList; 

	static DateFormat dateFormat = new SimpleDateFormat(Constant.DATE_FORMAT_YYYY_MM_DD);
	private static final Logger LOGGER = Logger.getLogger(CommonUtillity.class);

	static {
		patternList = new ArrayList<>(); 
		patternList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"));
		patternList.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		patternList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"));
		patternList.add(new SimpleDateFormat("yyyy-MM-dd"));
		patternList.add(new SimpleDateFormat("MMyyyy"));
		patternList.add(new SimpleDateFormat("MM-yyyy"));
		patternList.add(new SimpleDateFormat("MM.yyyy"));		
	}

	public static Date getDate(Object data) throws ParseException {

		return dateFormat.parse(data.toString());
	}

	public static <T> Iterable<T> nullSafeList(Iterable<T> inputList){

		return inputList == null ? Collections.<T>emptyList() : inputList;

	}

	public static Date convertStringToDate(final String pattern, final String dateString) throws ParseException{

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.parse(dateString);
	}


	public static String convertStringToDate(String pattern, Date date){

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(date);

	}

	public static Date getDateByPattern(String dateStr) throws ParseException{

		for(SimpleDateFormat sdf : patternList){
			try{
				if(dateStr != null && !dateStr.isEmpty()){
					return sdf.parse(dateStr);
				}
			}catch(ParseException pe){
//				LOGGER.error(Constant.LOGGER_ERROR  + " Method : getDateByPattern", pe);
			}
		}
		throw new ParseException("Unknown Date Format for " + dateStr, 0);
	}

	public static String amountConversion(String amt)
	{
		if(amt==null)
			return "0.00";

//		DecimalFormat numberFormat = new DecimalFormat("0.00");
//		return numberFormat.format(Double.parseDouble(amt)/Math.pow(10,Constant.CURRENY_VALUE));
//		
		int amtLength=amt.length();
		int currencyValue=Constant.CURRENY_VALUE;

		String abs="";
		if(amt.charAt(0)=='-'){
			abs=String.valueOf(amt.charAt(0));
			amt=amt.substring(1,amtLength);
			amtLength=amt.length();
		}
		
		if(amt.contains("."))
		{
			amt=amt.substring(0,amt.indexOf("."));
			amtLength=amt.length();
		}

		if(amtLength==currencyValue-1)
			return abs+"0.0"+amt.charAt(0);
		else if(amtLength==currencyValue)
			return abs+"0."+amt.charAt(0)+amt.charAt(1);
		else if(amtLength>currencyValue)
		{
			String postDecimal="."+amt.substring(amtLength-currencyValue,amtLength-currencyValue+2);
			String preDecimal=amt.substring(0,amtLength-currencyValue);
			return abs+preDecimal+postDecimal;
		}
		else
		{
			return "0.00";
		}
	}

	public static String getCommaSeparated(String amt)
	{
		/*DecimalFormat myFormatter = new DecimalFormat("##,##,##0.00");
		return myFormatter.format(Double.parseDouble(amt));*/
		 
		String abs="";
		if(amt.charAt(0)=='-'){
			abs=String.valueOf(amt.charAt(0));
			amt=amt.substring(1,amt.length());
		}
		
		if(!amt.contains("."))
			amt+=".00";

		String[] splitamt=amt.split("\\.");
		amt=splitamt[0];
		int amtLength=amt.length();int ctr=0;
		String formatAmt=amt;
		StringBuffer buffer =new StringBuffer();
		if(amtLength>3)
		{
			for(int i=amtLength-1;i>=0;i--)
			{
				if(ctr<4)
				{
					if(ctr%3==0)
						buffer.append(",");
				}
				else
				{
					if(ctr%2!=0)
						buffer.append(",");
				}
				buffer.append(amt.charAt(i));
				ctr++;
			}
			formatAmt=buffer.reverse().toString();
			if(formatAmt.charAt(formatAmt.length()-1)==',')
				formatAmt=formatAmt.substring(0,formatAmt.length()-1);
		}
		return abs+formatAmt+"."+splitamt[1];
	}

	//Object null check
	public static boolean isEmpty(Object obj) {
		if (obj == null) {
			return true;
		}
		return false;
	}

	//Collection null check
	public static boolean isEmpty(Collection<?> value) {
		if (value == null || value.isEmpty()) {
			return true;
		}
		return false;
	}

	//String null or empty check
	public static boolean isEmpty(String value) {
		if (value == null || value.isEmpty()) {
			return true;
		}
		return false;
	}

	public static List<String> cptyGstr1SupplyType(){
		List<String> applicableSupplyTypes = new ArrayList<>();
		applicableSupplyTypes.add(Constant.B2B);
		applicableSupplyTypes.add(Constant.B2BA);
		applicableSupplyTypes.add(Constant.CR);
		applicableSupplyTypes.add(Constant.DR);
		applicableSupplyTypes.add(Constant.RCR);
		applicableSupplyTypes.add(Constant.RDR);
		return applicableSupplyTypes;
	}

	public static List<String> cptyGstr2SupplyType(){
		List<String> applicableSupplyTypes = new ArrayList<>();
		applicableSupplyTypes.add(Constant.B2B);
		applicableSupplyTypes.add(Constant.B2BA);
		applicableSupplyTypes.add(Constant.CR);
		applicableSupplyTypes.add(Constant.DR);
		applicableSupplyTypes.add(Constant.RCR);
		applicableSupplyTypes.add(Constant.RDR);
		applicableSupplyTypes.add(Constant.SEZG);
		return applicableSupplyTypes;
	}
	
	
	public static DynamicSmartReportDto convertXmltoSmartReportDetails(
			String xml) {

		DynamicSmartReportDto dto = null;
		try {
			
				JAXBContext jaxbContext = JAXBContext
						.newInstance(DynamicSmartReportDto.class);
				InputStream stream = new ByteArrayInputStream(
						xml.getBytes(StandardCharsets.UTF_8));
				Unmarshaller jaxbUnmarshaller = jaxbContext
						.createUnmarshaller();
				dto = (DynamicSmartReportDto) jaxbUnmarshaller
						.unmarshal(stream);
		} catch (JAXBException e) {
			LOGGER.error("JAXBException while converting the XML to OutwardSmartReportDto , Exception is "+e);
		}catch (Exception e) {
			LOGGER.error("Exception while converting the XML to OutwardSmartReportDto , Exception is "+e);
		}
		return dto;
		
	}
	
	public static String getFormatedDate(Date timestamp){
		String formatedDate = "";
		if(timestamp !=  null){
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		formatedDate = timeFormat.format(timestamp) + " on "+dateFormat.format(timestamp);
		}
		return formatedDate;
	}
	
	public static String formatCommasWithSpaces(String fieldValue){
		
		if(fieldValue == null) return "";
		
		return fieldValue.replaceAll(",", " ");
		
	}
	
	public static String convertEpochtoDate(long epochSec){
		DateTimeFormatter format = 
			    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		String dateTime = Instant.ofEpochSecond(epochSec)
		        .atZone(ZoneId.of("Asia/Calcutta"))
		        .format(format);
		return dateTime;
	}
}
