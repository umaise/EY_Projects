/**
 * 
 */
package com.ey.advisory.asp.client.service;

import java.util.Map;

import com.ey.advisory.asp.client.dto.ClientRegistrationDTO;
import com.ey.advisory.asp.client.dto.CommonSearchDto;
import com.ey.advisory.asp.client.dto.ResultPage;

/**
 * @author Shivani.Aggarwal
 *
 */
public interface EntityRegistrationService {

	ResultPage<ClientRegistrationDTO> fetchRegistrationDataPag(CommonSearchDto stringList);

	void deleteRegistrationData(String gstin) throws Exception;

	void updateRegistrationData(ClientRegistrationDTO clientRegistrationDTO) throws Exception;

	void addRegistrationData(ClientRegistrationDTO clientRegistrationDTO) throws Exception;

	Map<Long, String> fetchGroupEntityLevelUsers(String entityCode) throws Exception;

	Map<Long, String> fetchGSTINRegisteredContacts(String gstin);

}
