package com.ey.advisory.asp.client.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR1Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.common.Constant;

@Repository
public class GSTR1DaoImpl implements GSTR1Dao {

	private static final Logger log = Logger.getLogger(GSTR1DaoImpl.class);
	
	@Autowired
	private HibernateDao hibernateDao;

	@Override
	public <T> List<T> validateOriginalDocumentNo(String originalDOcumentNo, String entityName, String columnName) {

		if(originalDOcumentNo==null || originalDOcumentNo.trim().isEmpty()){
			return null;
		}
		String queryStr = "FROM " + entityName + " e where e." + columnName + " = ?";
		return (List<T>) hibernateDao.find(queryStr, originalDOcumentNo);

	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> validateOriginalDocumentNoForCR(String originalDOcumentNo, String entityName, String columnName, String origDocType) {
		
		if(originalDOcumentNo==null || originalDOcumentNo.trim().isEmpty()){
			return null;
		}
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
		
		detachedCriteria.add(Restrictions.eq(columnName, originalDOcumentNo));
//		detachedCriteria.add(Restrictions.isNotNull("tableType"));
		detachedCriteria.add(Restrictions.ne("itemStatus", Constant.BUS_RULE_ERROR));
		detachedCriteria.add(Restrictions.in("tableType",new String[]{"B2B","B2CS","B2CSA","B2CL"}));
		detachedCriteria.add(Restrictions.eq("documentType", origDocType));		
		detachedCriteria.setProjection(Projections.projectionList().add(Projections.property("documentNo"),"documentNo").add(Projections.property("taxableValue"),"taxableValue")
			    .add(Projections.property("taxperiod"),"taxperiod").add(Projections.property("originalDocumentNo"),"originalDocumentNo").add(Projections.property("originalDocumentDate"),"originalDocumentDate"))
			    .setResultTransformer(Transformers.aliasToBean(OutwardInvoiceModel.class));
		
		return (List<T>) hibernateDao.find(detachedCriteria);
	}

	@Override
	public <T> List<T> validateOriginalDocumentNoForRCRRDR(String originalDOcumentNo, String entityName, String columnName, String origDocType) {

		if(originalDOcumentNo==null || originalDOcumentNo.trim().isEmpty()){
			return null;
		}
		String queryStr = "select a FROM " + entityName + " a, InvoiceKeyDetail b where a." + columnName + " = ? and a.tableType IS NOT NULL and a.itemStatus <> ?"
				+" and documentType = ? and b.isSuccessToGstn=1 and a.invoiceKey=b.invoiceKey";

		return (List<T>) hibernateDao.find(queryStr, originalDOcumentNo, Constant.BUS_RULE_ERROR, origDocType);
	}

	@Override
	public <T> List<T> validateOriginalDocumentNoInGSTN(String originalDocumentNo, String entityName, String columnName) {

		//		String queryStr = "select b.InvoiceKey from "+ entityName +" as a INNER JOIN InvoiceKeyDetail as b"+
		//				  " ON a.invoiceKey=b.invoiceKey and a."+columnName+"= ? and b.isSuccessToGstn=1";

		if(originalDocumentNo==null || originalDocumentNo.trim().isEmpty()){
			return null;
		}
		if(originalDocumentNo==null || originalDocumentNo.trim().isEmpty()){
			return null;
		}
		
		String queryStr = "select a FROM " + entityName + " a, InvoiceKeyDetail b where a." + columnName + " = ? and b.isSuccessToGstn=1 and a.invoiceKey=b.invoiceKey";
		return (List<T>) hibernateDao.find(queryStr, originalDocumentNo);

	}

	@Override
	public <T> List<T> isValidAmendment(String originalDocumentNo, String entityName, String columnName){

		if(originalDocumentNo==null || originalDocumentNo.trim().isEmpty()){
			return null;
		}
		String queryStr = "FROM " + entityName + " e where e." + columnName + " = ?";

		return (List<T>) hibernateDao.find(queryStr, originalDocumentNo);
	}

	@Override
	public <T> List<T> isValidAmendmentGSTN(String originalDocumentNo, String entityName, String columnName){

		if(originalDocumentNo==null || originalDocumentNo.trim().isEmpty()){
			return null;
		}
		String queryStr = "select a FROM " + entityName + " a, InvoiceKeyDetail b where a." + columnName + " = ? and b.isSuccessToGstn=1 and a.invoiceKey=b.invoiceKey"; 

		return (List<T>) hibernateDao.find(queryStr, originalDocumentNo);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T getEntityByColumn(String entityName, String colunName, Object columnValue) {

		String queryStr = "FROM" + entityName + "e where e." + colunName + " = :columnValue";
		
		Session session = null;
		Query query = null;
		try {
		session = hibernateDao.getSession();
		query = session.createQuery(queryStr);
		query.setParameter("columnValue", columnValue);
		} catch(Exception e) {
			log.error(e);
		} finally {
			if(session!=null  && session.isOpen()) {
				session.close();
			}
		}
		return (T) query.uniqueResult();

	}

	@Override
	public <T> List<T> validateOriginalDocNoDocDate(String docNum, Date documentDate, String entityName, String column1,
			String column2) {

		String queryStr = "FROM " + entityName + " e where e." + column1 + " = ? and e." + column2 + " = ?";

		return (List<T>) hibernateDao.find(queryStr, docNum, documentDate);
	}

	@Override
	public <T> List<T> validateOriginalDocNoDocDateForCRDR(String docNum, Date documentDate, String entityName, String column1,
			String column2) {

		String queryStr = "FROM " + entityName + " e where e." + column1 + " = ? and e." + column2 + " = ? and tableType IS NOT NULL and itemStatus <> ?";

		return (List<T>) hibernateDao.find(queryStr, docNum, documentDate, Constant.BUS_RULE_ERROR);
	}

	@Override
	public boolean isInvoicePresentInGSTN(String invoiceKey) {

		String queryStr = "FROM InvoiceKeyDetail e where e.invoiceKey = ? and e.isSuccessToGstn=1";

		return hibernateDao.find(queryStr, invoiceKey).isEmpty();
	}

	@Override
	public Object fetchHsnSacDetails(String hsnSac, String hsnsacTableClass, String columnName) {

		String queryStr= "from " +hsnsacTableClass +" where " + columnName +" like ?";

		List<Object> hsnRecord = (List<Object>) hibernateDao.find(queryStr, hsnSac+"%");
		
		if(hsnRecord!=null && (!hsnRecord.isEmpty())){
			return hsnRecord.get(0);
		}
		return null;
	}

/*	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> validateOriginalDocumentNoForCR(String originalDOcumentNo, String entityName, String columnName, String origDocType) {

		if(originalDOcumentNo==null || originalDOcumentNo.trim().isEmpty()){
			return null;
		}
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
		detachedCriteria.add(Restrictions.eq(columnName, originalDOcumentNo));
		detachedCriteria.add(Restrictions.isNotNull("tableType"));
		detachedCriteria.add(Restrictions.ne("itemStatus", Constant.BUS_RULE_ERROR));
		detachedCriteria.add(Restrictions.eq("documentType", origDocType));
		return (List<T>) hibernateDao.find(detachedCriteria);

		//String queryStr = "FROM " + entityName + " e where e." + columnName + " = ? and tableType IS NOT NULL and itemStatus <> ?";
		//		return (List<T>) hibernateDao.find(queryStr, originalDOcumentNo, Constant.BUS_RULE_ERROR);
	}*/

}
