package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@SuppressWarnings("serial")
@Entity
@Table(name="tblB2BItemDetails", schema="gstr6F")
public class GSTR6FB2BItemDetailsModel implements Serializable{
    
    @EmbeddedId
    GSTR6FB2BItemDetailsPK gstr6FB2BItemDetailsPK;
    
    @Column(name="CGSTAmt")
    private Double CGST_Amt;

    @Column(name="CGSTRt")
    private Double CGST_Rt;

    @Column(name="HSNSC")
    private String hsnSc;

    @Column(name="IGSTAmt")
    private Double IGST_Amt;

    @Column(name="IGSTRt")
    private Double IGST_Rate;
    
    @Column(name="SGSTAmt")
    private Double SGST_Amt;

    @Column(name="SGSTRt")
    private Double SGST_Rate;
    
    @Column(name="CessAmt")
    private Double cess_Amt;
    
    @Column(name="CessRt")
    private Double cess_Rate;  
    
    @Column(name="ItcIgstAmt")
    private Double itcIgstAmt;
    
    @Column(name="ItcCgstAmt")
    private Double itcCgstAmt;
    
    @Column(name="ItcSgstAmt")
    private Double itcSgstAmt;
    
    @Column(name="ItcCessAmt")
    private Double itcCessAmt;

	public GSTR6FB2BItemDetailsPK getGstr6FB2BItemDetailsPK() {
		return gstr6FB2BItemDetailsPK;
	}

	public void setGstr6FB2BItemDetailsPK(GSTR6FB2BItemDetailsPK gstr6Fb2bItemDetailsPK) {
		gstr6FB2BItemDetailsPK = gstr6Fb2bItemDetailsPK;
	}

	public Double getCGST_Amt() {
		return CGST_Amt;
	}

	public void setCGST_Amt(Double cGST_Amt) {
		CGST_Amt = cGST_Amt;
	}

	public Double getCGST_Rt() {
		return CGST_Rt;
	}

	public void setCGST_Rt(Double cGST_Rt) {
		CGST_Rt = cGST_Rt;
	}

	public String getHsnSc() {
		return hsnSc;
	}

	public void setHsnSc(String hsnSc) {
		this.hsnSc = hsnSc;
	}

	public Double getIGST_Amt() {
		return IGST_Amt;
	}

	public void setIGST_Amt(Double iGST_Amt) {
		IGST_Amt = iGST_Amt;
	}

	public Double getIGST_Rate() {
		return IGST_Rate;
	}

	public void setIGST_Rate(Double iGST_Rate) {
		IGST_Rate = iGST_Rate;
	}

	public Double getSGST_Amt() {
		return SGST_Amt;
	}

	public void setSGST_Amt(Double sGST_Amt) {
		SGST_Amt = sGST_Amt;
	}

	public Double getSGST_Rate() {
		return SGST_Rate;
	}

	public void setSGST_Rate(Double sGST_Rate) {
		SGST_Rate = sGST_Rate;
	}

	public Double getCess_Amt() {
		return cess_Amt;
	}

	public void setCess_Amt(Double cess_Amt) {
		this.cess_Amt = cess_Amt;
	}

	public Double getCess_Rate() {
		return cess_Rate;
	}

	public void setCess_Rate(Double cess_Rate) {
		this.cess_Rate = cess_Rate;
	}

	public Double getItcIgstAmt() {
		return itcIgstAmt;
	}

	public void setItcIgstAmt(Double itcIgstAmt) {
		this.itcIgstAmt = itcIgstAmt;
	}

	public Double getItcCgstAmt() {
		return itcCgstAmt;
	}

	public void setItcCgstAmt(Double itcCgstAmt) {
		this.itcCgstAmt = itcCgstAmt;
	}

	public Double getItcSgstAmt() {
		return itcSgstAmt;
	}

	public void setItcSgstAmt(Double itcSgstAmt) {
		this.itcSgstAmt = itcSgstAmt;
	}

	public Double getItcCessAmt() {
		return itcCessAmt;
	}

	public void setItcCessAmt(Double itcCessAmt) {
		this.itcCessAmt = itcCessAmt;
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((gstr6FB2BItemDetailsPK == null) ? 0 : gstr6FB2BItemDetailsPK.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        GSTR6FB2BItemDetailsModel other = (GSTR6FB2BItemDetailsModel) obj;
        if (gstr6FB2BItemDetailsPK == null) {
            if (other.gstr6FB2BItemDetailsPK != null)
                return false;
        }
        else if (!gstr6FB2BItemDetailsPK.equals(other.gstr6FB2BItemDetailsPK))
            return false;
        return true;
    }
    
	    
}
