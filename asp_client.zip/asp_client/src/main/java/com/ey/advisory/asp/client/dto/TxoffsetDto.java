package com.ey.advisory.asp.client.dto;

public class TxoffsetDto {
	
	private PdcashDto pdcash; 
	private PditcDto pditc;
	
	public PdcashDto getPdcash() {
		return pdcash;
	}
	public void setPdcash(PdcashDto pdcash) {
		this.pdcash = pdcash;
	}
	public PditcDto getPditc() {
		return pditc;
	}
	public void setPditc(PditcDto pditc) {
		this.pditc = pditc;
	}
	
	
}
