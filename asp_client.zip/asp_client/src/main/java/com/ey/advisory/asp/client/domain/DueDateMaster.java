package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblGstinReturnMaster",schema="master")
public class DueDateMaster implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ReturnId")
	private Long returnId;
	
	
	@Column(name = "GstinId")
	private String gstnId;
	
	//@Column(name = "")
	//private String type;  //Clarification required about this field
	
	@Column(name = "ReturnType")
	private String applicableReturn; 
	
	@Column(name = "ClientMandatedDate")
	private Long dueDates;
	
	//Column 'GstnMandatedDate' is for anticipated future use. When such a field will be asked to be added, this column mapping will be created here as well
	
	@Column(name = "GstnMandatedDate")
	private Long gstnMandatedDate;
	
	public Long getGstnMandatedDate() {
		return gstnMandatedDate;
	}
	public void setGstnMandatedDate(Long gstnMandatedDate) {
		this.gstnMandatedDate = gstnMandatedDate;
	}
	public String getApplicableReturn() {
		return applicableReturn;
	}
	
	public Long getReturnId() {
		return returnId;
	}
	public void setReturnId(Long returnId) {
		this.returnId = returnId;
	}
	public String getGstnId() {
		return gstnId;
	}
	public void setGstnId(String gstnId) {
		this.gstnId = gstnId;
	}
	public void setApplicableReturn(String applicableReturn) {
		this.applicableReturn = applicableReturn;
	}
	public Long getDueDates() {
		return dueDates;
	}
	public void setDueDates(Long dueDates) {
		this.dueDates = dueDates;
	}
	

}
