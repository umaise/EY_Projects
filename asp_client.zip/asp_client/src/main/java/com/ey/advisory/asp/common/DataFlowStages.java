package com.ey.advisory.asp.common;

public enum DataFlowStages {
	
	BIFURCATE("BIF"),BR_STAGE1("BS1"),BR_STAGE2("BS2"),ETL_STAGE1("ES1"),
	ETL_STAGE2("ES2"),FILED("FLD"),GSTN_SAVE("SAVE"),GSTN_SUBMIT("SMT"),FILE_UPLOADED("ULD"),Failed("FLD"),In_Progress("INP"),
	Processed("PSD"),Processed_With_Errors("PWE"),Started("STD"),Uploaded("ULD"),DUPLICATE("DUP");
	
	private String stage; 
	
	private DataFlowStages(String stage)
	{ 
		this.stage = stage; 
		}

	public String getStage() {
		return stage;
	}

}
