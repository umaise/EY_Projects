package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.SystemCodeModel;
import com.ey.advisory.asp.common.Constant;

public class SystemCodesServiceImpl implements SystemCodesService{
    
    @Autowired
    private HibernateDao hibernateDao;

    private static final Logger logger = Logger.getLogger(SystemCodesServiceImpl.class);

    @SuppressWarnings("unchecked")
    @Override
    public Map<String, String> getSystemCodeInfo(String codeKey) {
        
        List<SystemCodeModel> systemCodeModelList = new ArrayList<>();
        
        Map<String, String> stageInfo = new HashMap<>();

        try {
            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(SystemCodeModel.class);
            detachedCriteria.add(Restrictions.eq("codeKey", codeKey));
            systemCodeModelList = (List<SystemCodeModel>) hibernateDao.find(detachedCriteria);
        }
        catch (Exception exe) {
            logger.error(Constant.LOGGER_ERROR + SystemCodesServiceImpl.class.getName()
                + " Method : getSystemCodeInfo()",exe);
        }
        
        for(SystemCodeModel systemCodeModel : systemCodeModelList){
            stageInfo.put(systemCodeModel.getCode(), systemCodeModel.getDescription());
        }
        
        return stageInfo;
    }

}
