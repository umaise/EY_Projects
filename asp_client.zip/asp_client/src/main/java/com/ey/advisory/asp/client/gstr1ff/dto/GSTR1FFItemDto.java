package com.ey.advisory.asp.client.gstr1ff.dto;

import java.math.BigDecimal;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class GSTR1FFItemDto {
	
	
	@JsonProperty("iamt")
	private BigDecimal iamt;
	@JsonProperty("camt")
	private BigDecimal camt;
	@JsonProperty("samt")
	private BigDecimal samt;
	@JsonProperty("csamt")
	private BigDecimal cess;
	@JsonProperty("txval")
	private BigDecimal item_Txval;
	@JsonProperty("rt")
	private BigDecimal rate;
	public BigDecimal getIamt() {
		return iamt;
	}
	public void setIamt(BigDecimal iamt) {
		this.iamt = iamt;
	}
	public BigDecimal getCamt() {
		return camt;
	}
	public void setCamt(BigDecimal camt) {
		this.camt = camt;
	}
	public BigDecimal getSamt() {
		return samt;
	}
	public void setSamt(BigDecimal samt) {
		this.samt = samt;
	}
	public BigDecimal getCess() {
		return cess;
	}
	public void setCess(BigDecimal cess) {
		this.cess = cess;
	}
	public BigDecimal getItem_Txval() {
		return item_Txval;
	}
	public void setItem_Txval(BigDecimal item_Txval) {
		this.item_Txval = item_Txval;
	}
	public BigDecimal getRate() {
		return rate;
	}
	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}
	
	
	
	

}
