package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the tblExportAInvoice database table.
 * 
 */
@Entity
@Table(name="tblExportAInvoice", schema="gstr1")
public class GSTR1EXPA_InvoiceDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private long id;

	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="ExpBillDate")
	private Date expBillDate;

	@Column(name="ExpBillNo")
	private String expBillNo;

	@Column(name="ExpType")
	private String expType;

	@Column(name="FileID")
	private long fileID;

	@Column(name="Flag")
	private String flag;

	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="OrgInvDate")
	private Date orgInvDate;

	@Column(name="OrgInvNum")
	private String orgInvNum;

	@Column(name="InvDate")
	private Date invDate;

	@Column(name="InvNum")
	private String invNum;

	@Column(name="InvValue")
	private BigDecimal invValue;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="OrderDt")
	private Date orderDt;

	@Column(name="OrderNo")
	private String orderNo;

	@Column(name="PortCode")
	private String portCode;

	@Column(name="ProvAsses")
	private String provAsses;

	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;

	@Column(name="TaxPeriod")
	private String taxPeriod;

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public Date getExpBillDate() {
		return this.expBillDate;
	}

	public Date getOrgInvDate() {
		return orgInvDate;
	}

	public void setOrgInvDate(Date orgInvDate) {
		this.orgInvDate = orgInvDate;
	}

	public String getOrgInvNum() {
		return orgInvNum;
	}

	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public void setExpBillDate(Date expBillDate) {
		this.expBillDate = expBillDate;
	}

	public String getExpBillNo() {
		return this.expBillNo;
	}

	public void setExpBillNo(String expBillNo) {
		this.expBillNo = expBillNo;
	}

	public String getExpType() {
		return this.expType;
	}

	public void setExpType(String expType) {
		this.expType = expType;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Date getInvDate() {
		return this.invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getInvNum() {
		return this.invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public BigDecimal getInvValue() {
		return this.invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public Date getOrderDt() {
		return this.orderDt;
	}

	public void setOrderDt(Date orderDt) {
		this.orderDt = orderDt;
	}

	public String getOrderNo() {
		return this.orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getPortCode() {
		return this.portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getProvAsses() {
		return this.provAsses;
	}

	public void setProvAsses(String provAsses) {
		this.provAsses = provAsses;
	}

	public BigDecimal getTaxablevalue() {
		return this.taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

}