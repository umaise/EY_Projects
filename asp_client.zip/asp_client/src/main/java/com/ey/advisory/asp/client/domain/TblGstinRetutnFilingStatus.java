package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;

/**
 * The persistent class for the tblGstinRetutnFilingStatus database table.
 * 
 * @author Siddharth Pahuja
 * @version 1.0
 * @since 23-03-2017
 */
@Entity
@Table(name = "tblGstinReturnFilingStatus", schema = Constant.MASTER_SCHEMA)
@NamedQuery(name = "TblGstinRetutnFilingStatus.findAll", query = "SELECT t FROM TblGstinRetutnFilingStatus t")
public class TblGstinRetutnFilingStatus implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(TblGstinRetutnFilingStatus.class);
  

	@Column(name = "GstnStatus")
	private String gstnStatus;
	
	@Column(name = "ErrorDesc")
    private String errorDesc;
	
	
	
	@Column(name = "Status")
	String status;
	@Column(name = "SubmitRefId")
	String submitRefId;
	@Column(name = "SubmitTranId")
	String submitTranId;
	@Column(name = "FileAckNum")
	String fileAckNum;
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "gstinId", column = @Column(name = "GstinId")),
			@AttributeOverride(name = "taxPeriod", column = @Column(name = "TaxPeriod")),
			@AttributeOverride(name = "returnType", column = @Column(name = "ReturnType")) })
	private TblGstinRetutnFilingStatusPK id;

	@Column(name = "FileDate")
	private Timestamp fileDate;

	@Column(name = "IsSuccess")
	Boolean isSuccess;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FilingId", unique = true, updatable = false, insertable = false)
	private Long filingId;

	@Column(name = "SubmitDate")
	private Timestamp submitDate;
	
	@Column(name = "SummaryStatus")
	private String summaryStatus;
	
	 @Column(name = "DeletedOn")
	private Timestamp deletedOn;
		    		  
	@Column(name = "WorkFlowStatus")
	private String workFlowStatus;
	
	@Column(name = "updatedDate")
	private Timestamp updatedDate;

	public TblGstinRetutnFilingStatus() {

		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in TblGstinRetutnFilingStatus ");
			}
	}

	public TblGstinRetutnFilingStatusPK getId() {
		return this.id;
	}

	public void setId(TblGstinRetutnFilingStatusPK id) {
		this.id = id;

	}

	public Timestamp getFileDate() {
		return this.fileDate;
	}

	public void setFileDate(Timestamp fileDate) {
		this.fileDate = fileDate;
	}

	public Long getFilingId() {
		return this.filingId;
	}

	public void setFilingId(Long filingId) {
		this.filingId = filingId;
	}

	public Timestamp getSubmitDate() {
		return this.submitDate;
	}

	public void setSubmitDate(Timestamp submitDate) {
		this.submitDate = submitDate;
	}

	public String getSubmitRefId() {
		return submitRefId;
	}

	public void setSubmitRefId(String submitRefId) {
		this.submitRefId = submitRefId;
	}

	public String getSubmitTranId() {
		return submitTranId;
	}

	public void setSubmitTranId(String submitTranId) {
		this.submitTranId = submitTranId;
	}

	public String getFileAckNum() {
		return fileAckNum;
	}

	public void setFileAckNum(String fileAckNum) {
		this.fileAckNum = fileAckNum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(Boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getSummaryStatus() {
		return summaryStatus;
	}

	public void setSummaryStatus(String summaryStatus) {
		this.summaryStatus = summaryStatus;
	}

	public Timestamp getDeletedOn() {
		return deletedOn;
	}

	public void setDeletedOn(Timestamp deletedOn) {
		this.deletedOn = deletedOn;
	}

	public String getWorkFlowStatus() {
		return workFlowStatus;
	}

	public void setWorkFlowStatus(String workFlowStatus) {
		this.workFlowStatus = workFlowStatus;
	}
	public String getGstnStatus() {
		return gstnStatus;
	}

	public void setGstnStatus(String gstnStatus) {
		this.gstnStatus = gstnStatus;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	
}