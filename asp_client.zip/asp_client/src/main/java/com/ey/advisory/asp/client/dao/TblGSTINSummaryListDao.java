package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblGSTINSummaryList;
import com.ey.advisory.asp.client.dto.FileDto;

public interface TblGSTINSummaryListDao {
	public String insertUpdateGstr12SummaryStatus(List<TblGSTINSummaryList> gstinList);
	public void updateGstinSummaryList(TblGSTINSummaryList gstinData );
	public List<TblGSTINSummaryList> getGstinRtSummaryType(List<Integer> fileIdList);
}
