/**
 * 
 */
package com.ey.advisory.asp.client.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.SignAuthDao;
import com.ey.advisory.asp.client.domain.ClientCommunication;

/**
 * @author Nitesh.Tripathi
 *
 */
@Service
public class SignAuthServiceImpl implements SignAuthService{

	private static final Logger LOGGER = Logger.getLogger(SignAuthServiceImpl.class);
	
	@Autowired
	private SignAuthDao signAuthDao;
	
	@Override
	public List<ClientCommunication> fetchAuthorizedSignatureGstins(Long userId) {
		
		 List<ClientCommunication> authSignList = signAuthDao.fetchAuthorizedSignatureGstins(userId);
		 
		 return authSignList;
		
	}
	
	@Override
	public Set<String> fetchAuthorizedSignatureGstinsSet(Long userId) {
		
		 Set<String> authSignGstins = new HashSet<String>();
		 
		 List<ClientCommunication> authSignList = fetchAuthorizedSignatureGstins(userId);
		 if(authSignList != null){
			 
			 for(ClientCommunication clientComm:authSignList){
				 authSignGstins.add(clientComm.getGstin());
			 }
			 
		 }
		 
		 
		 return authSignGstins;
		
	}
}
