package com.ey.advisory.asp.client.dto;

import java.math.BigInteger;

import com.google.api.client.util.DateTime;


public class ReturnSubmissionStatus {
	

	private BigInteger returnSubmissionStatusUID;

	private String gstin ;

	private String rtPeriod;

	private String debitNum ;

	private DateTime createdOn ;
	
	
	public BigInteger getReturnSubmissionStatusUID() {
		return returnSubmissionStatusUID;
	}
	public void setReturnSubmissionStatusUID(BigInteger returnSubmissionStatusUID) {
		this.returnSubmissionStatusUID = returnSubmissionStatusUID;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getRtPeriod() {
		return rtPeriod;
	}
	public void setRtPeriod(String rtPeriod) {
		this.rtPeriod = rtPeriod;
	}
	public String getDebitNum() {
		return debitNum;
	}
	public void setDebitNum(String debitNum) {
		this.debitNum = debitNum;
	}
	public DateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(DateTime createdOn) {
		this.createdOn = createdOn;
	}
	
	

}
