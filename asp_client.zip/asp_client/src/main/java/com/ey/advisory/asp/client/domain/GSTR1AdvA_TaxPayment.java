package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the GSTR1AdvA_TaxPayment database table.
 * 
 */
@Entity
@Table(name = "tblAdvATaxPayment", schema = "gstr1")
public class GSTR1AdvA_TaxPayment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	private long GSTR1AdvA_TaxPayment_ID;

	@Column(name = "Flag")
	private String flag;

	@Column(name = "ChkSum")
	private String chkSum;

	@Column(name = "OrgCustGSTIN")
	private String orgCustGSTIN;


	@Column(name = "OrgCustName")
	private String orgCustName;


	@Column(name = "OrgDocNum")
	private String org_DocNum;

	@Column(name = "OrgDocDate")
	private String org_DocDate;

	@Column(name = "CustGSTIN")
	private String cust_GSTIN;

	@Column(name = "CustName")
	private String cust_Name;

	@Column(name = "RecpStateCd")
	private String recp_StateCDE;

	@Column(name = "DocNum")
	private String doc_Num;

	@Column(name = "DocDate")
	private String doc_Date;

	@Column(name = "AdvAmt")
	private Double adv_Amt;

	@Column(name = "TaxableValue")
	private Double taxableValue;

	@Column(name = "TaxPeriod")
	private String taxPeriod;

	@Column(name = "Gstin")
	private String gstin;

	@Column(name = "FileID")
	private Long fileId;

	@Column(name = "IsDelete")
	private Boolean isDelete;

	public long getGSTR1AdvA_TaxPayment_ID() {
		return GSTR1AdvA_TaxPayment_ID;
	}

	public void setGSTR1AdvA_TaxPayment_ID(long gSTR1AdvA_TaxPayment_ID) {
		GSTR1AdvA_TaxPayment_ID = gSTR1AdvA_TaxPayment_ID;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getChkSum() {
		return chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getOrgCustGSTIN() {
		return orgCustGSTIN;
	}

	public void setOrgCustGSTIN(String orgCustGSTIN) {
		this.orgCustGSTIN = orgCustGSTIN;
	}

	public String getOrgCustName() {
		return orgCustName;
	}

	public void setOrgCustName(String orgCustName) {
		this.orgCustName = orgCustName;
	}

	public String getOrg_DocNum() {
		return org_DocNum;
	}

	public void setOrg_DocNum(String org_DocNum) {
		this.org_DocNum = org_DocNum;
	}

	public String getOrg_DocDate() {
		return org_DocDate;
	}

	public void setOrg_DocDate(String org_DocDate) {
		this.org_DocDate = org_DocDate;
	}

	public String getCust_GSTIN() {
		return cust_GSTIN;
	}

	public void setCust_GSTIN(String cust_GSTIN) {
		this.cust_GSTIN = cust_GSTIN;
	}

	public String getCust_Name() {
		return cust_Name;
	}

	public void setCust_Name(String cust_Name) {
		this.cust_Name = cust_Name;
	}

	public String getRecp_StateCDE() {
		return recp_StateCDE;
	}

	public void setRecp_StateCDE(String recp_StateCDE) {
		this.recp_StateCDE = recp_StateCDE;
	}

	public String getDoc_Num() {
		return doc_Num;
	}

	public void setDoc_Num(String doc_Num) {
		this.doc_Num = doc_Num;
	}

	public String getDoc_Date() {
		return doc_Date;
	}

	public void setDoc_Date(String doc_Date) {
		this.doc_Date = doc_Date;
	}

	public Double getAdv_Amt() {
		return adv_Amt;
	}

	public void setAdv_Amt(Double adv_Amt) {
		this.adv_Amt = adv_Amt;
	}

	public Double getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public Boolean getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Boolean isDelete) {
		this.isDelete = isDelete;
	}

}