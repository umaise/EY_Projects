/**
 * 
 */
package com.ey.advisory.asp.client.service;

/**
 * @author Shivani.Aggarwal
 *
 */
public interface ClientOnBoardingUpdateService {
	
}
