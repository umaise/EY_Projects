package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.ReturnType;

@FunctionalInterface
public interface ReturnTypeDao {

	List<ReturnType> getFileUploadTypelist();
		
		
	

}
