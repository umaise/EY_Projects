package com.ey.advisory.asp.exception;

public class ServiceLayerException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public ServiceLayerException(Throwable exceThrowable){
		super(exceThrowable);
	}
	
	public ServiceLayerException(String message,Throwable exceThrowable){
		super(message,exceThrowable);
	}
}
