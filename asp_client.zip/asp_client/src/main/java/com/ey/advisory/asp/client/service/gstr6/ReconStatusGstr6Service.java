package com.ey.advisory.asp.client.service.gstr6;

import com.ey.advisory.asp.client.domain.ReconStatusGstr6;

public interface ReconStatusGstr6Service {
	
	public ReconStatusGstr6 getReconStatus(String gstin,String taxPeriod,Integer masterId);
	
	public void saveReconStatus(String gstin,String taxPeriod,Integer masterId);
	
	public void updateReconStatus(String gstin, String taxPeriod,Integer masterId);
	
	public ReconStatusGstr6 getActiveReconStatus(String gstin,String taxPeriod);

	public ReconStatusGstr6 getReconStatus(String gstin,String taxPeriod);
	
	public void updateReconStatus(String gstin, String taxPeriod,Integer masterId,String status);

	public void updateReconCompletionDate(String gstin, String taxPeriod,Integer masterId);

}
