package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;

@Entity
@Table(name = "tblFileUpload",schema="etl")
public class TblFileUploadStatus implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3800162191283758373L;
	private static final Logger LOGGER = Logger.getLogger(TblFileUploadStatus.class);
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FileId")
	private Integer fileId;
	@Column(name = "UserId")
	private long userId;
	@Column(name = "FName")
	private String fName;
	@Column(name = "FileType")
	private String fileType;
	@Column(name = "FilePath")
	private	String filePath;
	@Column(name = "Content")
	private	String dataType;
	@Column(name = "EntityId")
	private Integer entityId;
	@Column(name = "Gstin")
	private	String gstin;
	@Column(name = "MapId")
	private	Integer mapId;
	@Column(name = "Status")
	private String status;
	@Column(name = "Stage")
	private String stage;
	@Column(name = "UploadDt")
	private	Date uploadDt;
	@Column(name = "UpdatedDt")
	private	Date updatedDt;
	@Column(name = "ErrorDesc")
	private	String errorDesc;
	@Column(name = "TotalErrorInvoices")
	private Integer totalErrorInvoices;
	@Column(name = "TotalInvoices")
	private Integer totalInvoices;
	@Column(name = "IsMagic")
	private Boolean isMagic;
	
	@Transient
	private String uiDate;
	
	@Transient
	private Boolean isLiveDashboard;
	
	public TblFileUploadStatus(){
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in TblFileUploadStatus ");
			}
	}
	
	public TblFileUploadStatus(Integer fileId, String fName, String dataType,
			String uiDate,String status, Boolean isLiveDashboard) {
		super();
		this.fileId = fileId;
		this.fName = fName;
		this.dataType = dataType;
		this.status = status;
		this.uiDate = uiDate;
		this.isLiveDashboard = isLiveDashboard;
	}
	public Integer getFileId() {
		return fileId;
	}
	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public Integer getEntityId() {
		return entityId;
	}
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public Integer getMapId() {
		return mapId;
	}
	public void setMapId(Integer mapId) {
		this.mapId = mapId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public Date getUploadDt() {
		return uploadDt;
	}
	public void setUploadDt(Date uploadDt) {
		this.uploadDt = uploadDt;
	}
	public Date getUpdatedDt() {
		return updatedDt;
	}
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public Integer getTotalErrorInvoices() {
		return totalErrorInvoices;
	}
	public void setTotalErrorInvoices(Integer totalErrorInvoices) {
		this.totalErrorInvoices = totalErrorInvoices;
	}
	public Integer getTotalInvoices() {
		return totalInvoices;
	}
	public void setTotalInvoices(Integer totalInvoices) {
		this.totalInvoices = totalInvoices;
	}
	public Boolean getIsMagic() {
		return isMagic;
	}
	public void setIsMagic(Boolean isMagic) {
		this.isMagic = isMagic;
	}
	
	
	public String getUiDate() {
		return uiDate;
	}
	public void setUiDate(String uiDate) {
		this.uiDate = uiDate;
	}
	@Override
	public String toString() {
		return "TblFileUploadStatus [fileId=" + fileId + ", userId=" + userId
				+ ", fName=" + fName + ", fileType=" + fileType + ", filePath="
				+ filePath + ", dataType=" + dataType + ", entityId="
				+ entityId + ", gstin=" + gstin + ", mapId=" + mapId
				+ ", status=" + status + ", stage=" + stage + ", uploadDt="
				+ uploadDt + ", updatedDt=" + updatedDt + ", errorDesc="
				+ errorDesc + ", totalErrorInvoices=" + totalErrorInvoices
				+ ", totalInvoices=" + totalInvoices + ", isMagic=" + isMagic
				+ ", uiDate=" + uiDate + ", isLiveDashboard=" + isLiveDashboard+ "]";
	}

	public Boolean getIsLiveDashboard() {
		return isLiveDashboard;
	}

	public void setIsLiveDashboard(Boolean isLiveDashboard) {
		this.isLiveDashboard = isLiveDashboard;
	}

	
	
	
	
}
