package com.ey.advisory.asp.client.dto;

import java.util.List;

public class GstrReconMailDetailDto {
	
	private String clientLegalName;
	private int invoiceCount;
	private String returnType;
	private String gstin;
	private List<String> mailList;
	private List<String> mobileNumbersList;
	public String getClientLegalName() {
		return clientLegalName;
	}
	public void setClientLegalName(String clientLegalName) {
		this.clientLegalName = clientLegalName;
	}
	public int getInvoiceCount() {
		return invoiceCount;
	}
	public void setInvoiceCount(int invoiceCount) {
		this.invoiceCount = invoiceCount;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public List<String> getMailList() {
		return mailList;
	}
	public void setMailList(List<String> mailList) {
		this.mailList = mailList;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public List<String> getMobileNumbersList() {
		return mobileNumbersList;
	}
	public void setMobileNumbersList(List<String> mobileNumbersList) {
		this.mobileNumbersList = mobileNumbersList;
	}
	
	
	

}
