package com.ey.advisory.returnfiling.service;

import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;

public interface ReturnFilingClientService {

	TblGstinRetutnFilingStatus getReturnFilingDetails(String taxPeriod, String gstin, String type, String filed);
	
}
