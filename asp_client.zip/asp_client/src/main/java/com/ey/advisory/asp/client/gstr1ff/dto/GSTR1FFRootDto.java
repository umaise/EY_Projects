package com.ey.advisory.asp.client.gstr1ff.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GSTR1FFRootDto {

	private List<GSTR1FFB2BDto> b2b;

	public List<GSTR1FFB2BDto> getB2b() {
		return this.b2b;
	}

	public void setB2b(List<GSTR1FFB2BDto> b2b) {
		this.b2b = b2b;
	}

	/*private List<GSTR1FFB2BADto> b2ba;

	public List<GSTR1FFB2BADto> getB2ba() {
		return this.b2ba;
	}

	public void setB2ba(List<GSTR1FFB2BADto> b2ba) {
		this.b2ba = b2ba;
	}

	private List<GSTR1FFB2CLDto> b2cl;

	public List<GSTR1FFB2CLDto> getB2cl() {
		return b2cl;
	}

	public void setB2cl(List<GSTR1FFB2CLDto> b2cl) {
		this.b2cl = b2cl;
	}

	private List<GSTR1FFB2CLADto> b2cla;

	public List<GSTR1FFB2CLADto> getB2cla() {
		return b2cla;
	}

	public void setB2cla(List<GSTR1FFB2CLADto> b2cla) {
		this.b2cla = b2cla;
	}

	private List<GSTR1FFB2CSDto> b2cs;

	public List<GSTR1FFB2CSDto> getB2cs() {
		return this.b2cs;
	}

	public void setB2cs(List<GSTR1FFB2CSDto> b2cs) {
		this.b2cs = b2cs;
	}*/

}
