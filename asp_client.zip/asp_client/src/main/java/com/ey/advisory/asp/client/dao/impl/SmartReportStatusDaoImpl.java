package com.ey.advisory.asp.client.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.SmartReportStatusDao;
import com.ey.advisory.asp.client.domain.SmartReport;
import com.ey.advisory.asp.common.Constant;

@Repository
public class SmartReportStatusDaoImpl implements SmartReportStatusDao{

	@Autowired
	private HibernateDao  hibernateDao;
	
	private static final Logger LOGGER = Logger.getLogger(SmartReportStatusDaoImpl.class);
	private static final String CLASS_NAME = SmartReportStatusDaoImpl.class.getName();
	
	@SuppressWarnings("unchecked")
	@Override
	public List<SmartReport> getSmartReportData(int offset,int pageSize) {
		List<SmartReport> list = null;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getSmartReportData : Params : offset " + offset + " pageSize " + pageSize);
		}
		try{
		DetachedCriteria criteria = hibernateDao.createCriteria(SmartReport.class);
		criteria.addOrder(Order.desc("createdDate")); 
		list = (List<SmartReport>) hibernateDao.findByCriteria(criteria, offset, pageSize);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getSmartReportData");
		}
		}catch(Exception e){
			if (LOGGER.isDebugEnabled()) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getSmartReportData ",e);
			}
		}
		return list;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<SmartReport> getSearchSmartReportData(String requestId, String fileCategory,int offset,int pageSize) {
		List<SmartReport> list = null;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getSearchSmartReportData : Params : requestId " + requestId + " fileCategory " + fileCategory);
		}
		try{
		DetachedCriteria criteria = hibernateDao.createCriteria(SmartReport.class);
		criteria.add(Restrictions.or(Restrictions.like("reportId", "%"+requestId),(Restrictions.like("reportId", requestId+"%"))));
		criteria.add(Restrictions.eq("fileCategory", fileCategory));
		criteria.addOrder(Order.desc("reportId"));
		list = (List<SmartReport>) hibernateDao.findByCriteria(criteria, offset, pageSize);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getSearchSmartReportData");
		}
		}catch(Exception e){
			if (LOGGER.isDebugEnabled()) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getSearchSmartReportData ",e);
			}
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void updateCancelStatus(String requestId, String fileCategory) {
		List<SmartReport> report = null;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " updateCancelStatus : Params : requestId " + requestId + " fileCategory " + fileCategory);
		}
		try{
		DetachedCriteria criteria = hibernateDao.createCriteria(SmartReport.class);
		criteria.add(Restrictions.eq("reportId", requestId ));
		criteria.add(Restrictions.eq("fileCategory", fileCategory));
		report = (List<SmartReport>)hibernateDao.find(criteria);
		if(!report.isEmpty()){
		report.get(0).setReportId(requestId);
		report.get(0).setFileCategory(fileCategory);
		report.get(0).setStatus("Cancelled");
		hibernateDao.saveOrUpdate(report.get(0));
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " updateCancelStatus");
		}
		}catch(Exception e){
			if (LOGGER.isDebugEnabled()) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " updateCancelStatus ",e);
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public SmartReport getFileDetails(String requestId, String fileCategory) {
		List<SmartReport> report = null;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getFileDetails : Params : requestId " + requestId + " fileCategory " + fileCategory);
		}
		try{
		DetachedCriteria criteria = hibernateDao.createCriteria(SmartReport.class);
		criteria.add(Restrictions.eq("reportId", requestId ));
		criteria.add(Restrictions.eq("fileCategory", fileCategory));
		report = (List<SmartReport>)hibernateDao.find(criteria);
		if(!report.isEmpty()){
			return report.get(0);
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getFileDetails");
		}
		}catch(Exception e){
			if (LOGGER.isDebugEnabled()) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getFileDetails ",e);
			}
		}
		return null;
	}

}
