package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblB2CSummary;

public interface B2ConsolidatedService {
	
	List<TblB2CSummary> fetchAll();
	Long getTotalRecordCount(Long fileId);
	List<TblB2CSummary> fetchTotalRecords(Long fileId, int firstResult, int pageSize);

}
