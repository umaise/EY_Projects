package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;

public interface TblGstinRetutnFilingStatusService {
	public String insertGstr2AFilingStatus( List<String> outputParamList);
	public List<TblGstinRetutnFilingStatus> loadDataFromTblGSTinReturnFillingStatus();
	public String validateSavedStatus(String gstinId, String tax, String returnType);
	public boolean insertGstr3BSubmitStatus(String gstin,String taxPeriod);
	public boolean getGstr3BStatus(String gstin,String taxPeriod);
	public boolean saveAllGstinReturnFilingStatus(List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatusList);
	public TblGstinRetutnFilingStatus getStatusFor2A(String gstinId,String taxPeriod, String status);
	/**
	 * Method to insert status for gstr2a
	 * @param outputParamList
	 * @return
	 */
	public String updateGstr2AStatus( List<String> outputParamList);
	/**
	 * Method to insert status for gstr2a
	 * @param outputParamList
	 * @return
	 */
	public String insertGstr2AEntry( List<String> outputParamList);
	/**
	 * Method to insert status for gstr2a
	 * @param outputParamList
	 * @return
	 */
	public String updateGstr1FFStatus( List<String> outputParamList);
	/**
	 * Method to insert status for gstr1ff
	 * @param outputParamList
	 * @return
	 */
	public String getStatusFor1FF(String gstinId, String taxPeriod, String api);
	public String insertGstr1FFEntry( List<String> outputParamList);
	public TblGstinRetutnFilingStatus fetchGstrReturnDetails(String gstinId, String taxPeriod, String returnType);
	public TblGstinRetutnFilingStatus getStatusForReconReport(String gstinId,String taxPeriod, String status);
	
	public TblGstinRetutnFilingStatus getStatusFor6A(String gstinId, String taxPeriod, String status);
	public String insertGstr6AEntry( List<String> outputParamList);
	public String updateGstr6AStatus( List<String> outputParamList);
}
