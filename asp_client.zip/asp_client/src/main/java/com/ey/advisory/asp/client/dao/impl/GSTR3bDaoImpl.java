package com.ey.advisory.asp.client.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR3bDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.common.Constant;
@Repository
public class GSTR3bDaoImpl implements GSTR3bDao{
	@Autowired
	private HibernateDao hibernateDao;
	
	private static final Logger LOGGER = Logger.getLogger(GSTR3bDaoImpl.class);
	private static final String CLASS_NAME = GSTR3bDaoImpl.class.getName();
	
	public  String getGSTR3bSummaryDetails(JSONObject jsonObj) {
		Object resultXml=null;
		Object[] obj = new Object[2];
        obj[0] = jsonObj.get(Constant.GSTIN);
        obj[1] = jsonObj.get(Constant.TAXPERIOD);
        StringBuilder stringBuilder = new StringBuilder();
        String summaryXml = "";
		try {
			 List<?> result = hibernateDao.executeNativeSql(" exec dbo.uspGetgstr3BCalculation ?, ? ", obj);
			if (result != null && !result.isEmpty()) {
				for(int i=0;i<result.size();i++){
					resultXml = (Object) result.get(i);
					stringBuilder.append(resultXml);
				}
			}
			summaryXml = String.valueOf(stringBuilder);
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " getGSTR3bSummaryDetails summaryXml "+summaryXml);
		} catch (Exception e) {
			
			LOGGER.error("Exception in getGSTR3bSummaryDetails"+ e);
		}
		return summaryXml;
	}

	@Override
	public void freezeRecordsFor3b() {
		// TODO Auto-generated method stub
		
	}
	
}
