package com.ey.advisory.asp.client.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GstinFinancialsDetailsDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.TblGstinFinancialDetails;
import com.ey.advisory.asp.common.Constant;

@Service
public class GstinFinancialsDetailsDaoImpl implements GstinFinancialsDetailsDao {

	@Autowired
	HibernateDao hibernateDao;
	
	private static final Logger logger = Logger.getLogger(GstinFinancialsDetailsDaoImpl.class);
	private static final String CLASS_NAME = GstinFinancialsDetailsDaoImpl.class.getName();

	@SuppressWarnings("unchecked")
	@Override
	public Double getTurnOverforEntity(String entityId) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD +"getTurnOverforEntity()");
		Double turnOver = 0.00;
		 DetachedCriteria detachedCriteriasub = hibernateDao.createCriteria(EntityHierarchy.class);
		 detachedCriteriasub.add(Restrictions.eq("entityID",Integer.parseInt(entityId)));
		 ProjectionList projectionListSub=Projections.projectionList();
		 projectionListSub.add(Projections.property("gSTIN"));
		 detachedCriteriasub.setProjection(Projections.distinct(projectionListSub));
		 
		DetachedCriteria criteria = hibernateDao.createCriteria(TblGstinFinancialDetails.class);
		criteria.add(Subqueries.propertyIn("gstin", detachedCriteriasub));
		criteria.add(Restrictions.eq("financialPeriod", Constant.QUARTER1));
		ProjectionList projectionList=Projections.projectionList();
	    projectionList.add(Projections.sum("quarterTurnOvrAmt"));
	    criteria.setProjection(projectionList);
	    
	    List<Double> gstinFinancialList =null;
		try {
			gstinFinancialList = (List<Double>) hibernateDao.find(criteria);
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+Constant.LOGGER_METHOD +"getTurnOverforEntity()"+e);
		}
	    if(gstinFinancialList!=null && !gstinFinancialList.isEmpty()){
	    	//String taxPeriod = retPeriod == null ? "092016" : retPeriod.getTaxPeriodMMYYYY();
	    	turnOver = gstinFinancialList.get(0)==null? 0.00 : gstinFinancialList.get(0);
	    }
	    logger.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD +"getTurnOverforEntity()");
		return turnOver;    
	}
}
