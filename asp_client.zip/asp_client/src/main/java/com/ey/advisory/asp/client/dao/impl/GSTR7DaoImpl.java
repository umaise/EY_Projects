package com.ey.advisory.asp.client.dao.impl;

import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.client.dao.GSTR7Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;

public class GSTR7DaoImpl implements  GSTR7Dao{
	
	private static final Logger log = Logger.getLogger(GSTR7DaoImpl.class);
	private static final String CLASS_NAME = GSTR7DaoImpl.class.getName();

	@Autowired
    private HibernateDao hibernateDao;	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<InwardInvoiceModel> getDupInvoice(String entityName,String supplierGSTIN, String contractNumber, String documentNo, Date documentDate) {
		List<InwardInvoiceModel> inwardInvoiceModel = null;
		Session session = hibernateDao.getSession();

		String queryStr = "FROM " + entityName + " e where e.SupplierGSTIN = :supplierGSTIN and e.ContractNumber=:contractNumber and e.documentNo = :documentNo and e.DocumentDate = :documentDate";
		Query query = session.createQuery(queryStr);
		query.setParameter("supplierGSTIN", supplierGSTIN);
		query.setParameter("contractNumber", contractNumber);
		query.setParameter("documentNo", documentNo);
		query.setParameter("documentDate", documentDate);
		try{
			inwardInvoiceModel = (List<InwardInvoiceModel>) query.list();
		}
		catch (Exception e) {
			log.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getDupInvoice " + e);
		}
		finally{
			if(session!= null && session.isOpen()){
				session.close();
			}
		}
		return inwardInvoiceModel;
	}
	
	@Override
	public List<InwardInvoiceModel> getTaxableVal(String entityName, String supplierGSTIN, String contractNumber,Date contractdate) {
		List<InwardInvoiceModel> inwardInvoiceModel = null;
		Session session = hibernateDao.getSession();

		String queryStr = "FROM " + entityName + " e where e.SupplierGSTIN = :supplierGSTIN and e.ContractNumber=:contractNumber and e.ContractDate = :contractdate";
		Query query = session.createQuery(queryStr);
		query.setParameter("supplierGSTIN", supplierGSTIN);
		query.setParameter("contractNumber", contractNumber);
		query.setParameter("contractdate", contractdate);
		try{
			inwardInvoiceModel =  (List<InwardInvoiceModel>) query.list();
		}
		catch (Exception e) {
			log.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getItcBalance " + e);
		}
		finally{
			if(session!= null && session.isOpen()){
				session.close();
			}
		}
		return inwardInvoiceModel;
	}

}
