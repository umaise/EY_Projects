package com.ey.advisory.asp.client.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.SummaryJsonChunkDao;
import com.ey.advisory.asp.client.domain.SummaryJsonChunk;
import com.ey.advisory.asp.common.Constant;

@Service
public class SummaryJsonChunkServiceImpl implements SummaryJsonChunkService {
	private static final Logger logger = Logger
			.getLogger(SummaryJsonChunkServiceImpl.class);
	private static final String CLASS_NAME = SummaryJsonChunkServiceImpl.class
			.getName();
	
	@Autowired
	SummaryJsonChunkDao summaryJsonChunkDao;
	
	@Override
	public void saveSummaryJsonChunkData(List<SummaryJsonChunk> summJsonChunk) {
		
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " saveSummaryJsonChunkData");
		}
		
		summaryJsonChunkDao.saveSummaryJsonChunkData(summJsonChunk);
		
	}
	
	@Override
	public String updateSummaryJsonChunk(String status, int summaryFileId, String chunkSeries) {
		
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " updateSummaryJsonChunk");
		}
		return summaryJsonChunkDao.updateSummaryJsonChunk(status, summaryFileId, chunkSeries);
	}

	

}
