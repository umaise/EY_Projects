package com.ey.advisory.asp.client.service.gstr2;

import java.net.URL;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

public interface GSTR2AService {
	
	/**
	 * Method to update the status once gstr2a is done
	 * @param gstin
	 * @param retPeriod
	 * @return
	 * @throws Exception
	 */
	public String updateGSTR2AStatus(String gstin, String retPeriod, String status);
	
	/**
	 * Method to update the status once gstr2a is done
	 * @param gstin
	 * @param retPeriod
	 * @return
	 * @throws Exception
	 */
	public String insertGSTR2AStatus(String gstin, String retPeriod, String status) throws Exception;
	

	/**
	 * method to process GETB2B for GSTR2A
	 * @param gstin
	 * @param retPeriod
	 * @param groupCode
	 * @param b2b
	 * @return
	 * @throws Exception 
	 */
	public String saveGSTR2AData(String gstin, String retPeriod, String groupCode, String invType, String jsonResponse,String chunkId) throws Exception;

	public String processRecievedResponse(String b2bRespJSON, String gstin, String retPeriod, String groupCode,
			String invType, String hitCount) throws ParseException, Exception; 
	
	
	
	/**
	 * Method to fetch gstin's for GSTR2A
	 * @param gstin
	 * @param txPrd
	 * @param returnType
	 * @return
	 * @throws Exception 
	 *//*
	public List<Object[]> getDetailsforGstr2A(String gstin, String txPrd, String returnType) throws Exception;*/
	
	/**
	 * To generate GSTR2FRecon report.
	 * 
	 * @param gstin
	 * @param taxPeriod
	 * @param template_Dir 
	 */
	public void generateGSTR2FReconReport(String groupCode, String gstin, String taxPeriod, URL template_Dir);

	public String scheduleSimpleTrigger(String resourceURL,
			String inputData, String est, String invoiceType, String gstin, String token, 
			String retPeriod, String hitCount); 
	public List<String> getErrorReportDetails(JSONObject obj);
}
