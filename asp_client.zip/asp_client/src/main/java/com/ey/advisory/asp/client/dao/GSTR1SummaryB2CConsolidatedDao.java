package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR1SummaryB2CConsolidated;

@FunctionalInterface
public interface GSTR1SummaryB2CConsolidatedDao {

	public List<GSTR1SummaryB2CConsolidated> getB2CConsolidatedMetadata(); 
}
