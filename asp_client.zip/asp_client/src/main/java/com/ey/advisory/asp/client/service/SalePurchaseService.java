package com.ey.advisory.asp.client.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.client.dto.SalePurchasedto;
import com.ey.advisory.asp.master.dto.ErrorMasterDto;

public interface SalePurchaseService {
	
	public Map getSalePurchaseList(List<String> GSTIN,String taxPeriod,String flag,String Type) throws ParseException;
	
	public List<SalePurchasedto> getSaleListForChart(List<String> parameterList) throws ParseException;
	
	public List<SalePurchasedto> getPurchaseListForChart(List<String> parameterList) throws ParseException;
	

	/**
     * load the Doc type and Supply type metadata to redis
     * @param typeOfDoc
     * @return
     */
    public void loadDocTypeMetaData(String groupCode);
    
    public void loadBifurcationMetaData(String groupCode);

	public ErrorMasterDto refreshErrorCodeMapInRedis(String errorInfoCode);
}
