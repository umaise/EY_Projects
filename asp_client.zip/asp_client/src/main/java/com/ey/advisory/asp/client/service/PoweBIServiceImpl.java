package com.ey.advisory.asp.client.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonProcessingException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.util.GSTNRestClientUtility;

@Service
public class PoweBIServiceImpl implements PowerBIService {

	private static final Logger logger = Logger.getLogger(PoweBIServiceImpl.class);
	
	@Autowired
	private GSTNRestClientUtility gstnRestClientUtility;
	
	@Override
	public Map<String, String> getBIAccessToken(String uriAccess, String uriEmbed, HashMap<String, String> paramMap,
			String embedURLConfig) throws JsonProcessingException, UnsupportedEncodingException {

		String body = "";
		String respBody = "";
		String embedToken = "";
		String grpID = "";
		String reportID = "";

		Map<String, String> hmConfig = new HashMap<>();
		try {
			body = getBIAccessBody(paramMap);
			respBody = gstnRestClientUtility.executeRestCallBIPost(body, HttpMethod.POST, uriAccess,
					getHeadersPBIAccessToken());
			JSONObject jsonObjectVal = null;
			jsonObjectVal = (JSONObject) new JSONParser().parse(respBody);
			String accessToken = (String) jsonObjectVal.get("access_token");

			// get embed token
			if (logger.isDebugEnabled()){
				logger.debug("access token receieved..");
			}
			grpID = splitURL(embedURLConfig, "groupId");
			reportID = splitURL(embedURLConfig, "reportId");

			embedToken = getBIEmbedToken(accessToken, uriEmbed, grpID, reportID);
			if (logger.isDebugEnabled()) 
				logger.debug("Preparing config object for powerBI..");
			
			hmConfig = getBIConfig(embedToken, grpID, reportID, embedURLConfig);
			if (logger.isDebugEnabled())  
				logger.debug("Config object for powerBI is ready..");

		} catch (Exception e) {
			if (logger.isDebugEnabled()) 
				logger.debug("Error in PoweBIServiceImpl.getBIAccessToken() : " + e);
			logger.error("Error in PoweBIServiceImpl.getBIAccessToken() : " + e);
		}
		return hmConfig;
	}
	private Map<String, String> getBIConfig(String embedTokenResp, String grpID, String reportID, String embedURLConfig)
			throws ParseException {

		Map<String, String> embedConfig = new HashMap<>();
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject;
		jsonObject = (JSONObject) jsonParser.parse(embedTokenResp);
		String embedToken = (String) jsonObject.get("token");

		embedConfig.put("type", "report");
		embedConfig.put("id", reportID);
		embedConfig.put("embedUrl", embedURLConfig);
		embedConfig.put("accessToken", embedToken);
		
		return embedConfig;
	}

	public String splitURL(String url, String parameter) {
		HashMap<String, String> urlMap = new HashMap<String, String>();
		String queryString = StringUtils.substringAfter(url, "?");
		for (String param : queryString.split("&")) {
			urlMap.put(StringUtils.substringBefore(param, "="), StringUtils.substringAfter(param, "="));
		}
		return urlMap.get(parameter);
	}
	
	private String getBIEmbedToken(String accessToken, String uriEmbed, String grpID, String reportID) {

		HashMap<String, String> paramMap = new HashMap<String, String>();
		String body = "";
		String respBody = "";
		String uri = uriEmbed + grpID + "/reports/" + reportID + "/GenerateToken";
		try {
			paramMap.put("accessLevel", "View");
			body = getBIAccessBody(paramMap);
			respBody = gstnRestClientUtility.executeRestCallBIPost(body, HttpMethod.POST, uri,
					getHeadersPBIEmbedToken(accessToken));
			if (logger.isInfoEnabled()) {
				logger.info("Successfully received embed token..");
			}
			

		} catch (Exception e) {
			if (logger.isInfoEnabled()) {
				logger.info("Exception in PoweBIServiceImpl.getBIEmbedToken().." + e);
			}
			logger.error("Exception in PoweBIServiceImpl.getBIEmbedToken().." + e);
		}
		return respBody;
	}

	private static String getBIAccessBody(HashMap<String, String> params)
			throws JsonProcessingException, UnsupportedEncodingException {

		StringBuilder result = new StringBuilder();
		boolean first = true;
		for (Map.Entry<String, String> entry : params.entrySet()) {
			if (first)
				first = false;
			else
				result.append("&");
			result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
			result.append("=");
			result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
		}
		return result.toString();
	}

	public HttpHeaders getHeadersPBIAccessToken() {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/x-www-form-urlencoded");
		return headers;
	}

	public HttpHeaders getHeadersPBIEmbedToken(String accessToken) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/x-www-form-urlencoded");
		headers.add("Authorization", "Bearer " + accessToken);
		return headers;
	}
}

