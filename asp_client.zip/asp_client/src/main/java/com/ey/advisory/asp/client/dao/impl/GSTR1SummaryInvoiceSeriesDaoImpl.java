package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR1SummaryInvoiceSeriesDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR1SummaryInvoiceSeries;
@Repository
public class GSTR1SummaryInvoiceSeriesDaoImpl implements GSTR1SummaryInvoiceSeriesDao{

	@Autowired
	private HibernateDao  hibernateDao;
	
	private static final Logger logger = Logger.getLogger(GSTR1SummaryInvoiceSeriesDaoImpl.class);
	
	@Override
	public List<GSTR1SummaryInvoiceSeries> getInvoiceSeriesMetadata() {
		List<GSTR1SummaryInvoiceSeries> invoiceSeriesList = new ArrayList<>();
		try {
			invoiceSeriesList = (List<GSTR1SummaryInvoiceSeries>)hibernateDao.loadAll(GSTR1SummaryInvoiceSeries.class);
		} catch (Exception e) {
			
			logger.error("Exception in getInvoiceSeriesMetadata "+e);
		}
		return invoiceSeriesList;
	}

}
