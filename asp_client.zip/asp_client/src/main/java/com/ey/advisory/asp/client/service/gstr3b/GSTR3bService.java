package com.ey.advisory.asp.client.service.gstr3b;

import org.json.simple.JSONObject;

public interface GSTR3bService {
	public String getGSTR3bSummaryDetails(JSONObject obj);
}
