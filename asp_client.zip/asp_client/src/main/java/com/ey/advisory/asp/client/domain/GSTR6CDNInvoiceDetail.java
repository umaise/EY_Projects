package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;


/**
 * The persistent class for the tblCDNInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblCDNInvoiceDetails", schema="gstr6")
public class GSTR6CDNInvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR6CDNInvoiceDetail.class);

	@Id
	@Column(name="ID")
	private long id;

	@Column(name="CessAmt")
	private Double cessAmt;

	@Column(name="CessRt")
	private Double cessRt;

	@Column(name="CGSTAmt")
	private Double CGSTAmt;

	@Column(name="CGSTRt")
	private Double CGSTRt;

	@Column(name="Chksum")
	private String chksum;

	@Column(name="CustGSTIN")
	private String custGSTIN;

	@Column(name="CustName")
	private String custName;

	@Column(name="DBChkSum")
	private int DBChkSum;

	@Column(name="DiffValue")
	private Double diffValue;

	@Column(name="FileID")
	private long fileID;

	@Column(name="Flag")
	private String flag;

	@Column(name="Gstin")
	private String gstin;

	@Column(name="IGSTAmt")
	private Double IGSTAmt;

	@Column(name="IGSTRt")
	private Double IGSTRt;

	@Column(name="InvDate")
	private Date invDate;

	@Column(name="InvNum")
	private String invNum;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="ItcCessAmt")
	private Double itcCessAmt;

	@Column(name="ItcCgstAmt")
	private Double itcCgstAmt;

	@Column(name="ItcEligiblity")
	private String itcEligiblity;

	@Column(name="ItcIgstAmt")
	private Double itcIgstAmt;

	@Column(name="ItcSgstAmt")
	private Double itcSgstAmt;

	@Column(name="NoteDate")
	private Date noteDate;

	@Column(name="NoteNum")
	private String noteNum;

	@Column(name="NoteTyp")
	private String noteTyp;

	@Column(name="Reason")
	private String reason;

	@Column(name="RevChrg")
	private String revChrg;

	@Column(name="SGSTAmt")
	private Double SGSTAmt;

	@Column(name="SGSTRt")
	private Double SGSTRt;

	@Column(name="TaxableValue")
	private Double taxableValue;

	@Column(name="TaxPeriod")
	private String taxPeriod;

	@Column(name="TcCessAmt")
	private Double tcCessAmt;

	@Column(name="TcCgstAmt")
	private Double tcCgstAmt;

	@Column(name="TcIgstAmt")
	private Double tcIgstAmt;

	@Column(name="TcSgstAmt")
	private Double tcSgstAmt;

	public GSTR6CDNInvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR6CDNInvoiceDetail ");
			}
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Double getCessAmt() {
		return this.cessAmt;
	}

	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}

	public Double getCessRt() {
		return this.cessRt;
	}

	public void setCessRt(Double cessRt) {
		this.cessRt = cessRt;
	}

	public Double getCGSTAmt() {
		return this.CGSTAmt;
	}

	public void setCGSTAmt(Double CGSTAmt) {
		this.CGSTAmt = CGSTAmt;
	}

	public Double getCGSTRt() {
		return this.CGSTRt;
	}

	public void setCGSTRt(Double CGSTRt) {
		this.CGSTRt = CGSTRt;
	}

	public String getChksum() {
		return this.chksum;
	}

	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	public String getCustGSTIN() {
		return this.custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getCustName() {
		return this.custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public int getDBChkSum() {
		return this.DBChkSum;
	}

	public void setDBChkSum(int DBChkSum) {
		this.DBChkSum = DBChkSum;
	}

	public Double getDiffValue() {
		return this.diffValue;
	}

	public void setDiffValue(Double diffValue) {
		this.diffValue = diffValue;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Double getIGSTAmt() {
		return this.IGSTAmt;
	}

	public void setIGSTAmt(Double IGSTAmt) {
		this.IGSTAmt = IGSTAmt;
	}

	public Double getIGSTRt() {
		return this.IGSTRt;
	}

	public void setIGSTRt(Double IGSTRt) {
		this.IGSTRt = IGSTRt;
	}

	public Date getInvDate() {
		return this.invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getInvNum() {
		return this.invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public Double getItcCessAmt() {
		return this.itcCessAmt;
	}

	public void setItcCessAmt(Double itcCessAmt) {
		this.itcCessAmt = itcCessAmt;
	}

	public Double getItcCgstAmt() {
		return this.itcCgstAmt;
	}

	public void setItcCgstAmt(Double itcCgstAmt) {
		this.itcCgstAmt = itcCgstAmt;
	}

	public String getItcEligiblity() {
		return this.itcEligiblity;
	}

	public void setItcEligiblity(String itcEligiblity) {
		this.itcEligiblity = itcEligiblity;
	}

	public Double getItcIgstAmt() {
		return this.itcIgstAmt;
	}

	public void setItcIgstAmt(Double itcIgstAmt) {
		this.itcIgstAmt = itcIgstAmt;
	}

	public Double getItcSgstAmt() {
		return this.itcSgstAmt;
	}

	public void setItcSgstAmt(Double itcSgstAmt) {
		this.itcSgstAmt = itcSgstAmt;
	}

	public Date getNoteDate() {
		return this.noteDate;
	}

	public void setNoteDate(Date noteDate) {
		this.noteDate = noteDate;
	}

	public String getNoteNum() {
		return this.noteNum;
	}

	public void setNoteNum(String noteNum) {
		this.noteNum = noteNum;
	}

	public String getNoteTyp() {
		return this.noteTyp;
	}

	public void setNoteTyp(String noteTyp) {
		this.noteTyp = noteTyp;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRevChrg() {
		return this.revChrg;
	}

	public void setRevChrg(String revChrg) {
		this.revChrg = revChrg;
	}

	public Double getSGSTAmt() {
		return this.SGSTAmt;
	}

	public void setSGSTAmt(Double SGSTAmt) {
		this.SGSTAmt = SGSTAmt;
	}

	public Double getSGSTRt() {
		return this.SGSTRt;
	}

	public void setSGSTRt(Double SGSTRt) {
		this.SGSTRt = SGSTRt;
	}

	public Double getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public Double getTcCessAmt() {
		return this.tcCessAmt;
	}

	public void setTcCessAmt(Double tcCessAmt) {
		this.tcCessAmt = tcCessAmt;
	}

	public Double getTcCgstAmt() {
		return this.tcCgstAmt;
	}

	public void setTcCgstAmt(Double tcCgstAmt) {
		this.tcCgstAmt = tcCgstAmt;
	}

	public Double getTcIgstAmt() {
		return this.tcIgstAmt;
	}

	public void setTcIgstAmt(Double tcIgstAmt) {
		this.tcIgstAmt = tcIgstAmt;
	}

	public Double getTcSgstAmt() {
		return this.tcSgstAmt;
	}

	public void setTcSgstAmt(Double tcSgstAmt) {
		this.tcSgstAmt = tcSgstAmt;
	}

}