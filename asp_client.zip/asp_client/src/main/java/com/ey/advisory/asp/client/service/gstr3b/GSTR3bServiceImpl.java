package com.ey.advisory.asp.client.service.gstr3b;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GSTR3bDao;

@Service
public class GSTR3bServiceImpl implements GSTR3bService{
	@Autowired
	GSTR3bDao gstr3bDao;
	@Override
    public String getGSTR3bSummaryDetails(JSONObject jsonObj){
    	return	 gstr3bDao.getGSTR3bSummaryDetails(jsonObj);
    }
}
