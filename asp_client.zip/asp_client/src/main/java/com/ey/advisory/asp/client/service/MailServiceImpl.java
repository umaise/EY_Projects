package com.ey.advisory.asp.client.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.apache.velocity.app.VelocityEngine;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.ey.advisory.asp.client.dto.Mail;
import com.ey.advisory.asp.client.util.AuthenticationUtility;

@Service
public class MailServiceImpl implements MailService {

	@Autowired
	private VelocityEngine velocityEngine;
	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	AuthenticationUtility authenticationUtility;
	private static final Logger logger = Logger.getLogger(MailServiceImpl.class);
	@Override
	public String sendMail(Mail emailObject) {

		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@SuppressWarnings("deprecation")
			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				if(logger.isInfoEnabled()){
				logger.info("********** enter into  prepare() " + mimeMessage);
				}
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage,
						true);
				message.setTo(emailObject.getTo());
				message.setCc(emailObject.getCc());
				message.setBcc(emailObject.getBcc());
				message.setFrom(emailObject.getFrom());
				message.setSubject(emailObject.getSubject());
				if(logger.isInfoEnabled()){
				logger.info("********** inside try BCC list ***** "+emailObject.getBcc());
				}
				String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "/mailTemplates/"+emailObject.getTemplateName()+"",emailObject.getVelocityDataMap());
				if(logger.isInfoEnabled()){
				logger.info("********** text ***** " + text);
				}
				message.setText(text, true);
				if (emailObject.getAttachedFile() != null) {
					if(logger.isInfoEnabled()){
					logger.info("********** inside if ***** " + emailObject.getAttachedFile());
					}
					message.addAttachment(emailObject.getAttachedFile()
							.getName(), emailObject.getAttachedFile());
				}
			}
		};
		try {
			if(logger.isInfoEnabled()){
			logger.info("********** inside try before send ***** " +preparator);
			}
			mailSender.send(preparator);
			if(logger.isInfoEnabled()){
			logger.info("********** inside try aftr send ***** ");
			}

		} catch (MailException me) {
			logger.error("********** inside error***** ",me);
			return "Failed";
		}
		return "Success";

	}

	@Override
	public void fileGSTR1(String toAddress, String gstin, String taxPeriod) throws Exception {
		String subjectGSTR1 = "ACKNOWLEDGEMENT: GSTR1 filed succesfully for GSTIN : "
				+ gstin + " for the Period : " + taxPeriod;
		String bodyGSTR1 = "<html><BODY><p>Dear Tax Payer,</p><p>We acknowledge receipt of your GSTR1 filing request for GSTIN <b>"
				+ gstin
				+ "</b> for the Period <b>"
				+taxPeriod
				+ " </b> with our Portal. Your GSTR1 is underway and will be successfully returned to you.</p></BODY></html>";
		sendEmail(toAddress, subjectGSTR1, bodyGSTR1);
	}

	@Override
	public void fileGSTR2(String toAddress, String gstin,String taxPeriod) throws Exception {
		String subjectGSTR2 = "ACKNOWLEDGEMENT: GSTR2 filed succesfully for GSTIN : "
				+ gstin + " for the Period : " + taxPeriod;
		String bodyGSTR2 = "<html><BODY><p>Dear Tax Payer,</p><p>We acknowledge receipt of your GSTR2 filing request for GSTIN <b>"
				+ gstin
				+ "</b> for the Period <b>"
				+taxPeriod
				+ " </b> with our Portal. Your GSTR2 is underway and will be successfully returned to you.</p></BODY></html>";
		sendEmail(toAddress, subjectGSTR2, bodyGSTR2);
	}
	
	private void sendEmail(String toAddress, String subject, String body)
			throws Exception {
		authenticationUtility.executeRestCallGSTNPost(
				fileGstrReqPayload(toAddress, subject, body),"",false, "");
	}

	private String fileGstrReqPayload(String toAddress, String subject,
			String body) throws JsonGenerationException, JsonMappingException,
			IOException {
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("From", "EY_GST@in.ey.com");
		paramMap.put("To", toAddress);
		paramMap.put("Subject", subject);
		paramMap.put("Body", body);
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	@Override
	public void fileGSTR3(String toAddress, String gstin, String month,
		String year) throws Exception {
		String subjectGSTR3 = "ACKNOWLEDGEMENT: GSTR2 filed succesfully for GSTIN : "
				+ gstin + " for the Period : " + month + "/" + year;
		String bodyGSTR3 = "<html><BODY><p>Dear Tax Payer,</p><p>We acknowledge receipt of your GSTR3 filing request for GSTIN <b>"
				+ gstin
				+ "</b> for the Period <b>"
				+ month
				+ "/"
				+ year
				+ " </b> with our Portal. Your GSTR3 is underway and will be successfully returned to you.</p></BODY></html>";
		sendEmail(toAddress, subjectGSTR3, bodyGSTR3);
	}
	
	@Override
	public void fileGSTR6(String toAddress, String gstin,String taxPeriod) throws Exception {
		String subjectGSTR6 = "ACKNOWLEDGEMENT: GSTR6 filed succesfully for GSTIN : "
				+ gstin + " for the Period : " + taxPeriod;
		String bodyGSTR6 = "<html><BODY><p>Dear Tax Payer,</p><p>We acknowledge receipt of your GSTR6 filing request for GSTIN <b>"
				+ gstin
				+ "</b> for the Period <b>"
				+taxPeriod
				+ " </b> with our Portal. Your GSTR6 is underway and will be successfully returned to you.</p></BODY></html>";
		sendEmail(toAddress, subjectGSTR6, bodyGSTR6);
	}
	
	@Override
	public void fileGSTR7(String toAddress, String gstin,String taxPeriod) throws Exception {
		String subjectGSTR7 = "ACKNOWLEDGEMENT: GSTR7 filed succesfully for GSTIN : "
				+ gstin + " for the Period : " + taxPeriod;
		String bodyGSTR7 = "<html><BODY><p>Dear Tax Payer,</p><p>We acknowledge receipt of your GSTR filing request for GSTIN <b>"
				+ gstin
				+ "</b> for the Period <b>"
				+taxPeriod
				+ " </b> with our Portal. Your GSTR7 is underway and will be successfully returned to you.</p></BODY></html>";
		sendEmail(toAddress, subjectGSTR7, bodyGSTR7);
	}
	
}
