package com.ey.advisory.asp.client.dto;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.google.api.client.util.DateTime;

@Entity
@Table(name="ReturnSubmissionStatus", schema="gstr3")
public class FIleSubmissionStatus {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="FIleSubmissionStatusUID")
	private BigInteger fIleSubmissionStatusUID ;
	@Column(name="RefNo")
	private String refNo  ;
	@Column(name="GSTIN")
	private String gstin ;
	@Column(name="ReturnPeriod")
	private String returnPeriod  ;
	@Column(name="CreatedOn")
	private DateTime createdOn ;
	public BigInteger getfIleSubmissionStatusUID() {
		return fIleSubmissionStatusUID;
	}
	public void setfIleSubmissionStatusUID(BigInteger fIleSubmissionStatusUID) {
		this.fIleSubmissionStatusUID = fIleSubmissionStatusUID;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public DateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(DateTime createdOn) {
		this.createdOn = createdOn;
	}
	
	
	

}
