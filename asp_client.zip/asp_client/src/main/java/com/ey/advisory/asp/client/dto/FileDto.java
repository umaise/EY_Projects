package com.ey.advisory.asp.client.dto;

import java.util.List;

public class FileDto {
	
	private Integer SummaryFileID;

	public Integer getSummaryFileID() {
		return SummaryFileID;
	}

	public void setSummaryFileID(Integer summaryFileID) {
		SummaryFileID = summaryFileID;
	}

}
