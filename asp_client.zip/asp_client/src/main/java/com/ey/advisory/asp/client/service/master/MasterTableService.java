package com.ey.advisory.asp.client.service.master;

import java.util.List;

import com.ey.advisory.asp.client.domain.MasterTable;



@FunctionalInterface
public interface MasterTableService {
	public List<Object> getMasterTableDetails(MasterTable masterTableDto);
}
