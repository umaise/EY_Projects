package com.ey.advisory.asp.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GSTR3IntrLiabDto {

	private GSTR3RateDto intr_liab_fwd_usr;
	private GSTR3RateDto del_pymt_tx_usr;
	private GSTR3RateDto oth_itc_rvl_usr;
	
	@JsonProperty("intr_liab_fwd_usr")
	public GSTR3RateDto getIntr_liab_fwd_usr() {
		return intr_liab_fwd_usr;
	}
	public void setIntr_liab_fwd_usr(GSTR3RateDto intr_liab_fwd_usr) {
		this.intr_liab_fwd_usr = intr_liab_fwd_usr;
	}
	
	@JsonProperty("del_pymt_tx_usr")
	public GSTR3RateDto getDel_pymt_tx_usr() {
		return del_pymt_tx_usr;
	}
	public void setDel_pymt_tx_usr(GSTR3RateDto del_pymt_tx_usr) {
		this.del_pymt_tx_usr = del_pymt_tx_usr;
	}
	
	@JsonProperty("oth_itc_rvl_usr")
	public GSTR3RateDto getOth_itc_rvl_usr() {
		return oth_itc_rvl_usr;
	}
	public void setOth_itc_rvl_usr(GSTR3RateDto oth_itc_rvl_usr) {
		this.oth_itc_rvl_usr = oth_itc_rvl_usr;
	}
}
