package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;

@Entity
@Table(name="tblOpeningClosingTaxPositionAmount", schema="gstr3")
/*@NamedQuery(name = "Gstr3OpeningClosingTaxPositionAmount findAll",  query = "SELECT * FROM [gstr3].[tblOpeningClosingTaxPositionAmount] t1 "
		+ "join [gstr3].[tblOpeningClosingTaxPosition] t2 on t1.TaxPositionID=t2.TaxPositionID" 
		+" where t1.TaxPositionID=(select TOP 1 t1.TaxPositionID from [gstr3].[tblOpeningClosingTaxPosition] t1 order by t1.LedgerEntryDate  desc) order by t2.LedgerEntryDate  desc"
		)*/
public class Gstr3OpeningClosingTaxPositionAmount implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(Gstr3OpeningClosingTaxPositionAmount.class);
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="TaxPositionAmountID" , unique=true, nullable=false)
	private BigInteger taxPositionAmountID;
	
	@Column(name="TaxPositionID" , unique=true, nullable=false)
	private BigInteger taxPositionID;
	
	@Column(name="TaxHeadID" , unique=true, nullable=false)
	private BigInteger taxHeadID;
	
	@Column(name="TaxSubHeadID" , unique=true, nullable=false)
	private BigInteger taxSubHeadID;
	
	@Column(name="Amount" , unique=true, nullable=false)
	private BigDecimal amount;

	public BigInteger getTaxPositionAmountID() {
		return taxPositionAmountID;
	}

	public void setTaxPositionAmountID(BigInteger taxPositionAmountID) {
		this.taxPositionAmountID = taxPositionAmountID;
	}

	public BigInteger getTaxPositionID() {
		return taxPositionID;
	}

	public void setTaxPositionID(BigInteger taxPositionID) {
		this.taxPositionID = taxPositionID;
	}

	public BigInteger getTaxHeadID() {
		return taxHeadID;
	}

	public void setTaxHeadID(BigInteger taxHeadID) {
		this.taxHeadID = taxHeadID;
	}

	public BigInteger getTaxSubHeadID() {
		return taxSubHeadID;
	}

	public void setTaxSubHeadID(BigInteger taxSubHeadID) {
		this.taxSubHeadID = taxSubHeadID;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
	public Gstr3OpeningClosingTaxPositionAmount(){
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in Gstr3OpeningClosingTaxPositionAmount ");
			}
	}

}
