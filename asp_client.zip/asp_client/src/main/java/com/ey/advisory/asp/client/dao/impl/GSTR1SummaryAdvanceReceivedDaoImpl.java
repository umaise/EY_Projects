package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR1SummaryAdvanceReceivedDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR1SummaryAdvanceReceived;

@Repository
public class GSTR1SummaryAdvanceReceivedDaoImpl implements GSTR1SummaryAdvanceReceivedDao{
	
	@Autowired
	private HibernateDao  hibernateDao;
	
	private static final Logger logger = Logger.getLogger(GSTR1SummaryAdvanceReceivedDaoImpl.class);

	@Override
	public List<GSTR1SummaryAdvanceReceived> getAdvanceReceivedMetadata() {
		List<GSTR1SummaryAdvanceReceived> advanceReceivedList = new ArrayList<>();
		try {
			advanceReceivedList = (List<GSTR1SummaryAdvanceReceived>)hibernateDao.loadAll(GSTR1SummaryAdvanceReceived.class);
		} catch (Exception e) {
			logger.error("Exception in  GSTR1SummaryAdvanceReceivedDaoImpl"+ e);
		}
		return advanceReceivedList;
	}

}
