package com.ey.advisory.asp.client.service;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.UserAccessMapping;
import com.ey.advisory.asp.client.domain.UserClient;
import com.ey.advisory.asp.client.dto.EntityHierarchyDTO;

public interface UserAccessMapHierarchy {
	
	public List<EntityHierarchy> fetchUserHierarchy(String accessLevel,String property, Object Value);
	
	public void updateUserAccessMappingbyEH(EntityHierarchy oldEntityHier, EntityHierarchy newEntityHier);

	public Map<Long, String> fetchUserAccessMap(EntityHierarchyDTO entityHierarchyDTO);

	public void saveUserAccessMapping(UserClient userClient);
	
	public void deleteUserAccessMapping(UserClient userClient) throws Exception;
	
	public List<UserAccessMapping> fetchUserAccessMap(int userId,String searchText) throws Exception;

	public List<String> fetchAccessLevelByUserId(Integer inputParams) throws Exception;
	
	public List<UserAccessMapping> fetchUserHierarchy(String accessLevel, String Value);
}
