package com.ey.advisory.asp.client.service.gstr3;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.Gstr3Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.InvoiceDao;
import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.domain.CashITCUtilization;
import com.ey.advisory.asp.client.domain.CashUtilizationTransaction;
import com.ey.advisory.asp.client.domain.FIleSubmissionStatusDetails;
import com.ey.advisory.asp.client.domain.Gstr3AccountHead;
import com.ey.advisory.asp.client.domain.Gstr3RefundDetails;
import com.ey.advisory.asp.client.domain.Gstr3TurnoverDetails;
import com.ey.advisory.asp.client.domain.ReturnSubmissionStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.dto.AuthDetailsDto;
import com.ey.advisory.asp.client.dto.DashBoardMapDto;
import com.ey.advisory.asp.client.dto.GSTR3RootDTO;
import com.ey.advisory.asp.client.dto.Gstr3Dto;
import com.ey.advisory.asp.client.dto.IntroffsetDto;
import com.ey.advisory.asp.client.dto.LfeeoffsetDto;
import com.ey.advisory.asp.client.dto.MapGstinDto;
import com.ey.advisory.asp.client.dto.PdcashDto;
import com.ey.advisory.asp.client.dto.PditcDto;
import com.ey.advisory.asp.client.dto.SetoffLiabilityDBDto;
import com.ey.advisory.asp.client.dto.SetoffLiabilityDto;
import com.ey.advisory.asp.client.dto.SubmitGSTR3Dto;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.client.dto.TxoffsetDto;
import com.ey.advisory.asp.client.service.CommonApiService;
import com.ey.advisory.asp.client.util.AuthenticationUtility;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.GSTR3InterestLiablityDto;
import com.ey.advisory.asp.exception.DataException;
import com.ey.advisory.asp.exception.ServiceLayerException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@PropertySource("classpath:RestConfig.properties")
public class Gstr3ServiceImpl implements Gstr3Service {

	@Autowired
	private Environment env;
	
	@Autowired
	HibernateDao hibernateDao;
	
	@Autowired
	private ReturnFilingDao returnFilingDoa;

	@Autowired
	AuthenticationUtility authenticationUtility;

	@Autowired
	private InvoiceDao invoiceDao;

	// Added as a part of Sprint 1 to make GSTN call via gsp
	@Resource(name = "${api.call}")
	private CommonApiService commonApiService;

	@Autowired
	private Gstr3Dao gstr3Dao;
	
	private  Map<String,String> stateColorMap; //from sessionInputGstinList
	private  Map<String,String> gstinReturnStateMap; //from sessionInputGstinList
	private  List<String> parentSessionList;// from sessionInputGstinList
	private String gstins;
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	private static final Logger LOGGER = Logger.getLogger(Gstr3ServiceImpl.class);
	private static final String CLASS_NAME = Gstr3ServiceImpl.class.getName();

	@Override
	public String getCashLedgerSummary(Gstr3Dto gstr3Dto) throws Exception{
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getCashLedgerSummary");
		AuthDetailsDto authDetails = authenticationUtility.validateAuthToken("");
		String result = commonApiService.getCashLedgerSummary(gstr3Dto);
		String jsonDataValue = "";
		try {
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result, authDetails);
			
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getCashLedgerSummary");
			throw e;
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getCashLedgerSummary");
		return jsonDataValue;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.service.gstr3.Gstr3Service#gstr3Summary(java.
	 * lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public String gstr3Summary(String gstin, String month, String year) {
		LOGGER.info("Entering " + CLASS_NAME + " Method : gstr3Summary");
		String jsonDataValue = "";

		AuthDetailsDto authDetails = authenticationUtility.validateAuthToken("");
		String result = commonApiService.gstr3Summary("04AABFN9870CMZT", "03", "2017");

		try {
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result, authDetails);
			LOGGER.info("Exiting " + CLASS_NAME + " Method : gstr3Summary");
			return jsonDataValue;
		} catch (Exception e) {
			LOGGER.error("Exiting " + CLASS_NAME + " Method : gstr3Summary",e);
			return e.getMessage();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.service.gstr3.Gstr3Service#sendGSTR3Data(int,
	 * java.lang.String)
	 */
	@Override
	public String sendGSTR3Data(int fileId, String jsonGstr3Data) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : sendGSTR3Data");
		String result = null;
		try {
			AuthDetailsDto authDetails = authenticationUtility.validateAuthToken(jsonGstr3Data);
			result = commonApiService.sendGSTR3Data(authDetails);
			authenticationUtility.getPayloadForGSTN(result, authDetails);
		} catch (Exception exec) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : sendGSTR3Data" ,exec);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : sendGSTR3Data");
		return "Successful transaction";
	}

	/**
	 * this method is used to save transaction id in database
	 * 
	 * @param gsptrnsId
	 * @param gstnTransId
	 * @param fileId
	 */
	@Override
	public String signfileGstr3(String gstin, String month, String year) {

		LOGGER.info("Entering " + CLASS_NAME + " Method : signfileGstr3");
		String jsonDataValue = "";

		AuthDetailsDto authDetails = authenticationUtility
				.validateAuthToken("");
		String result = commonApiService.signfileGstr3(gstin, month, year);

		try {
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result,
					authDetails);
			LOGGER.info("Exiting " + CLASS_NAME + " Method : signfileGstr3");
			return jsonDataValue;
		} catch (Exception e) {
			LOGGER.error("Exiting " + CLASS_NAME + " Method : signfileGstr3",e);
			return e.getMessage();
		}

	}

	/**
	 * @param gspackNo
	 * @param ackNo
	 * @param fileId
	 * @return
	 */

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.service.gstr3.Gstr3Service#gstr3RetStatus(java
	 * .lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public String gstr3RetStatus(String gstin, String month, String year) {
		LOGGER.info("Entering " + CLASS_NAME + " Method : gstr3RetStatus");
		String jsonDataValue = "";

		AuthDetailsDto authDetails = authenticationUtility.validateAuthToken("");
		String result = commonApiService.gstr3RetStatus("04AABFN9870CMZT", "03", "2017");

		try {
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result, authDetails);
			LOGGER.info("Exiting " + CLASS_NAME + " Method : gstr3RetStatus");
			return jsonDataValue;
		} catch (Exception e) {
			LOGGER.error("Exiting " + CLASS_NAME + " Method : gstr3RetStatus",e);
			return e.getMessage();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.client.service.gstr3.Gstr3Service#generateReturns(
	 * int, java.lang.String)
	 */
	@Override
	public String generateReturns(int fileId, String jsonGstr3Data) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : sendGSTR3Data");
		String result = null;
		try {
			AuthDetailsDto authDetails = authenticationUtility.validateAuthToken(jsonGstr3Data);
			result = commonApiService.generateReturns(authDetails);
			 authenticationUtility.getPayloadForGSTN(result, authDetails);
		} catch (Exception exec) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : sendGSTR3Data" ,exec);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : sendGSTR3Data");
		return "Successful transaction";
	}

	@Override
	public String getItcLedgerSummary(Gstr3Dto gstr3Dto) throws Exception{
		AuthDetailsDto authDetails = authenticationUtility.validateAuthToken("");
		String result = commonApiService.getItcLedgerSummary(gstr3Dto);
		String jsonDataValue = "";
		try {
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result, authDetails);
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getItcLedgerSummary" ,e);
			throw e;
		}

		return jsonDataValue;
	}

	@Override
	public String getGstr3Summary(Gstr3Dto gstr3Dto) {
		AuthDetailsDto authDetails = authenticationUtility.validateAuthToken("");
		String result = commonApiService.getGstr3Summary(gstr3Dto);
		String jsonDataValue = "";
		try {
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result, authDetails);
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getGstr3Summary",e);
		}

		return jsonDataValue;
	}


	/**
	 * GSTN call via GSP and get the Liability ledger details.
	 */
	@Override
	public String getLiabilityLedgerDetail(String gstn, String rtPeriod, String liabilityType) throws Exception {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getLiabilityLedgerDetail");
		String jsonDataValue = "";
		try {
			AuthDetailsDto authDetails = authenticationUtility.validateAuthToken("");
			String result = commonApiService.getLiabilityLedgerDetail(gstn, rtPeriod, liabilityType);
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result, authDetails);
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getLiabilityLedgerDetail");
			throw e;
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getLiabilityLedgerDetail");
		return jsonDataValue;
	}

	@Override
	public String utilizeCash(String cashUtilJson) throws Exception {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : utilizeCash");
		String jsonDataValue = "";
		String result = "";
		try {
			AuthDetailsDto authDetails = authenticationUtility.validateAuthToken(cashUtilJson);
			result = commonApiService.utilizeCash(authDetails);
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result, authDetails);
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : utilizeCash");
			throw e;
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : utilizeCash");
		return jsonDataValue;
	}

	@Override
	public String utilizeItc(String itcJson) throws Exception {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : utilizeITC");
		String itcUtilizeRes = "";
		String result = "";
		try {
			AuthDetailsDto authDetails = authenticationUtility.validateAuthToken(itcJson);
			result = commonApiService.utilizeItc(authDetails);
			itcUtilizeRes = authenticationUtility.getPayloadForGSTN(result, authDetails);
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : utilizeITC");
			throw e;
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : utilizeITC");
		return itcUtilizeRes;
	}

	@Override
	public String saveTurnoverDetials(Gstr3TurnoverDetails gstr3TurnoverDetails) {
		String gstr3saveTurnOverDetails = null;
		if(gstr3TurnoverDetails != null){
		gstr3saveTurnOverDetails = gstr3Dao.saveTurnoverDetials(gstr3TurnoverDetails);
		}
		return gstr3saveTurnOverDetails;
	}
	
	
	
	@Override
	public TblGstinRetutnFilingStatus getGStrReturnFilingDetails(String gstnID, String taxPeriod, String returnType) {

		return returnFilingDoa.fetchGstrReturnDetails(gstnID,taxPeriod,returnType);

	}
	@Override
	public String saveGstr3CashLegderDetails(String gstn,String jsonCashGstr3Data, String rtPeriod) {
		String gstr3cashLegerData=gstr3Dao.saveGstr3CashLegderDetails(gstn,jsonCashGstr3Data,rtPeriod);
		return gstr3cashLegerData;
		
	}

	@Override
	public String saveGstr3ITCLegderDetails(String gstn,String jsonITCGstr3Data, String rtPeriod) {
		String gstr3ITCLegerData=gstr3Dao.saveGstr3ITCLegderDetails(gstn, jsonITCGstr3Data, rtPeriod);
		return gstr3ITCLegerData;
	}

	@Override
	public String saveGstr3LiabilityLedgerDetail(String gstn,String rtPeriod,String jsonGstr3Data) {
		String gstr3LiabilityData=gstr3Dao.saveGstr3LiabilityLedgerDetail(gstn, rtPeriod, jsonGstr3Data);
		return gstr3LiabilityData;
	}

	@Override
	public Gstr3TurnoverDetails getTurnoverDetials(Gstr3Dto gstr3Dto) {
		return gstr3Dao.getTurnoverDetials(gstr3Dto);
	}

	@Override
	public List<String> getCashAutoFill(String gstn, String rtDate) {
		// TODO Auto-generated method stub
		return gstr3Dao.getCashAutoFill(gstn, rtDate);
	}
	
	@Override
	public String fileGSTR3(SummaryDto summarydto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : fileGSTR3");
		String acknowledge = "";
		try {

			AuthDetailsDto authDetails = authenticationUtility
					.validateAuthToken("");
			SummaryDto finalDto = authenticationUtility.encryptPayloadData(
					summarydto, authDetails);
			String jsonDataValue = authenticationUtility
					.executeRestCallGSTNPost(authenticationUtility
							.fileGstrReqPayload(finalDto, Constant.RETSUBMIT),
							Constant.RETURNS, true, Constant.GSTR3);
			authDetails = authenticationUtility.getRek(jsonDataValue,
					authDetails);
			acknowledge = authenticationUtility.getPayloadForGSTN(
					jsonDataValue, authDetails);
		} catch (Exception ex) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : fileGSTR3",ex);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : fileGSTR3");
		return acknowledge;
	}

	@Override
	public String saveCashUtilizationTransaction(Gstr3Dto gstr3Dto) throws Exception{
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME+ " Method : saveCashUtilizationTransaction");
		String message="";
		try {
			message = gstr3Dao.saveCashUtilizationTransaction(gstr3Dto);
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME+ " Method : saveCashUtilizationTransaction");
			throw e;
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : saveCashUtilizationTransaction");
		return message;
	} 

	
	@Override
    public String saveReturnSubmissionStatus(ReturnSubmissionStatus rtSubmissionStatus) throws Exception{
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME+ " Method : saveReturnSubmissionStatus");
		String message="";
		try {
			message =  gstr3Dao.saveReturnSubmissionStatus(rtSubmissionStatus);
		} catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME+ " Method : saveReturnSubmissionStatus");
			throw e;
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : saveReturnSubmissionStatus");
		return message;
    }

	@Override
	public DashBoardMapDto getDashBoardMapDto(List<MapGstinDto> sessionInputGstinList) {
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME+ " Method : getDashBoardMapDto"); 
			
		String context=getCurrentContext();
		
		Map<String,List<String>> stateGstinMap= iterateSessionInputList(sessionInputGstinList,context);
		LOGGER.info("Availble gstins for current user: " +gstins); 
		
		String taxperiod=sessionInputGstinList.get(0).getTaxPeriod();
		LOGGER.info("TaxPeriod for return filing table : " + taxperiod); 
		List<MapGstinDto> dbGstinList=getGstinReturnStatus(gstins,context,taxperiod);
			
		Map<String,MapGstinDto> gstinMap=getGstinSummary(taxperiod);
		
		Map<String,List<MapGstinDto>> getGstinSummaryMap=getGstinSummaryMap(gstinMap, stateGstinMap);
		
		DashBoardMapDto dashboardDto=new DashBoardMapDto();
		dashboardDto.setStateGSTINMap(getGstinSummaryMap);
		dashboardDto.setStateColorMap(iterateDbGstinList(dbGstinList,context));
		
		return dashboardDto;
	}
	
	private String getCurrentContext()
	{
		int currentDay= Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		String context="";
		if(currentDay>=Constant.GSTR1_START && currentDay<=Constant.GSTR1_END)
			context=Constant.GSTIN_PERIOD1_CONTEXT;
		else if(currentDay>=Constant.GSTR2_START && currentDay<=Constant.GSTR2_END)
			context=Constant.GSTIN_PERIOD2_CONTEXT;
		else if(currentDay>=Constant.GSTR3_START && currentDay<=Constant.GSTR3_END)
			context=Constant.GSTIN_PERIOD3_CONTEXT;
		else if(currentDay>Constant.GSTR3_END)
			context=Constant.GSTIN_PERIOD4_CONTEXT;
		
		return context;
	}
	
	private List<MapGstinDto> getGstinReturnStatus(String gstins,String context,String taxPeriod)
	{
		LOGGER.info("Entering getGstinReturnStatus() : "); 
		
		Object[] obj = new Object[5];
		obj[0]=gstins;
		obj[1]=env.getProperty(context+1);
		obj[2]= taxPeriod==null?null:taxPeriod;
		obj[3]=env.getProperty(context+2);
		obj[4]= taxPeriod;
		
		
		List<MapGstinDto> dbGstinList=null;
		List<Object[]> result = (List<Object[]>) hibernateDao.executeNativeSql(" exec dbo.uspGetGSTINRetFilingStatus ?, ?, ? ,?, ?",obj);

		if(result!=null && !result.isEmpty())
		{
			dbGstinList=new ArrayList<>();
			String stateName;
			for(Object[] arr:result)
			{
				LOGGER.info("Return result== 0"+arr[0].toString()+" 1="+arr[1].toString()+" 2="+arr[2].toString()); 
				stateName=arr[1].toString();
				stateName=stateName.replaceAll(" ", "_");
				dbGstinList.add(new MapGstinDto(arr[0].toString(),stateName ,arr[2].toString().toUpperCase()));
			}
		}else
		{
			LOGGER.info("result== "+result); 
		}
			return dbGstinList;
	}
	
	private Map<String,List<String>> iterateSessionInputList(List<MapGstinDto> sessionInputGstinList,String context)
	{
		parentSessionList=new LinkedList<>();
		gstinReturnStateMap=new HashMap<>();
		stateColorMap=new HashMap<>();
		Map<String,List<String>> stateGstinMap=new HashMap<>();
		List<String> stateGstinList;
		StringBuffer gstinBuffer=new StringBuffer();
		for (MapGstinDto gstin : sessionInputGstinList) {
			gstinBuffer.append(gstin.toString()).append(",");
			stateColorMap.put(gstin.getStateCode(), Constant.COLOR_COMPLETED);
			
			parentSessionList.add(gstin+env.getProperty(context+1));
			gstinReturnStateMap.put(gstin+env.getProperty(context+1), gstin.getStateCode());
		
			if(env.getProperty(context+2)!=null)
			{
				parentSessionList.add(gstin+env.getProperty(context+2));
				gstinReturnStateMap.put(gstin+env.getProperty(context+2), gstin.getStateCode());
			}
			
			if(stateGstinMap.containsKey(gstin.getStateCode()))
				stateGstinMap.get(gstin.getStateCode()).add(gstin.getGstin());
			else
			{
				stateGstinList=new ArrayList<>();
				stateGstinList.add(gstin.getGstin());
				stateGstinMap.put(gstin.getStateCode(),stateGstinList);
			}
		}
		gstins=gstinBuffer.toString();
		return stateGstinMap;
	}
	
	private Map<String, String> iterateDbGstinList(List<MapGstinDto> dbGstinList,String context)
	{
		List<String> dbChildList=new LinkedList<>();
		if(dbGstinList!=null && !dbGstinList.isEmpty())
		{
				for (MapGstinDto gstin : dbGstinList) {
				dbChildList.add(gstin.gstinReturnString());
				}
		}parentSessionList.removeAll(dbChildList);
			
		String returnType,state;
		for (String returnGstinKey : parentSessionList) {
			returnType=returnGstinKey.substring(Constant.GSTIN_LENGTH,returnGstinKey.length());
			state=gstinReturnStateMap.get(returnGstinKey);
			if(returnType.equals(env.getProperty(context+1)))
			{
				stateColorMap.put(state, Constant.COLOR_DELAYED);
			}
			else
			{
				if(!stateColorMap.get(state).equals(Constant.COLOR_DELAYED))
				{
					stateColorMap.put(state, Constant.COLOR_PENDING);
				}
			}
		}
		return stateColorMap;
	}

	private String getPrevTaxPeriod(String currTaxPeriod)
	{
		int month=Integer.parseInt(currTaxPeriod.substring(0,2));
		int year=Integer.parseInt(currTaxPeriod.substring(2,currTaxPeriod.length()));
			
		Calendar cal=Calendar.getInstance();
		cal.set(year, month-1,1);
		cal.add(Calendar.MONTH, -1);
		month=cal.get(Calendar.MONTH);
		year=cal.get(Calendar.YEAR);
		
		return String.format("%02d", month+1)+year;
	}
	
	private String getCurrentTaxPeriod(String taxperiod)
	{
        LOGGER.info("currentTaxperiod= "+taxperiod);
		int currentDay= Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		if(currentDay>Constant.GSTR3_END)
		{
			int month=Integer.parseInt(taxperiod.substring(0,2));
			int year=Integer.parseInt(taxperiod.substring(2,taxperiod.length()));
			Calendar cal=Calendar.getInstance();
			cal.set(year, month-1,1);
			cal.add(Calendar.MONTH, 1);
			month=cal.get(Calendar.MONTH);
			year=cal.get(Calendar.YEAR);
			
			LOGGER.info("activeTaxperiod "+String.format("%02d", month+1)+year);
			return String.format("%02d", month+1)+year;
			
		}
	    LOGGER.info("activeTaxperiod "+taxperiod);
		return taxperiod;
	}
	
	@SuppressWarnings("unchecked")
	private Map<String,MapGstinDto> getGstinSummary(String taxperiod) 
	{
		Map<String,MapGstinDto> gstinMap=new HashMap<>();
		String[] strArray = gstins.split(",");
		List<String> typeOfReg=null;
		for(String gstin :strArray)
		{
			if(gstin.trim().length()>1){
				typeOfReg= gstr3Dao.checkISDGstin(gstin);
				if(typeOfReg.contains(Constant.ISD))
					gstinMap.put(gstin, new MapGstinDto(gstin, "0", "0", "0","0",Constant.ISD));
				else
				gstinMap.put(gstin, new MapGstinDto(gstin, "0", "0", "0","0"));
			}	
		}
		
		Object[] obj = new Object[2];
		obj[0]=gstins;
		obj[1]=taxperiod;
		List<Object[]> result = null;
		try{
			
		  result = (List<Object[]>) hibernateDao.executeNativeSql("exec dbo.uspGetGSTINOutwardInwardSummary ?,?",obj);
		if(result!=null && !result.isEmpty())
		{
			String currentGstin,currentMode;
			for(Object[] arr :result)
			{
				currentGstin=arr[0].toString();
				currentMode=arr[1].toString();
				if(("INWARD").equalsIgnoreCase(currentMode))
					gstinMap.get(currentGstin).setInwardSupply(arr[2].toString());
				else if(("OUTWARD").equalsIgnoreCase(currentMode))
					gstinMap.get(currentGstin).setOutwardSupply(arr[2].toString());
				else if(("TAX_PAYABLE").equalsIgnoreCase(currentMode))
					gstinMap.get(currentGstin).setTaxableAmt(arr[2].toString());
				else if(("ITC").equalsIgnoreCase(currentMode))
					gstinMap.get(currentGstin).setItcValue(arr[2].toString());
				
				LOGGER.info("Return result== 0="+currentGstin+" 1="+currentMode+" 2="+arr[2].toString());
			}
		}else{
			LOGGER.error("Return result== "+null);
		}
		}catch(Throwable e){
			LOGGER.error("Return result== exception "+e,e);
		}
		return gstinMap;
	}
	
	private Map<String,List<MapGstinDto>> getGstinSummaryMap(Map<String,MapGstinDto> gstinMap,Map<String,List<String>> stateGstinMap)
	{
		LOGGER.info("Entering getGstinSummaryMap()");
		Map<String,List<MapGstinDto>> gstinSummaryMap=new HashMap<>();
		List<MapGstinDto> gstinSummaryList;
		List<String> gstinList;
		String state;
		for(Map.Entry<String, List<String>> entry :stateGstinMap.entrySet())
		{
			state=entry.getKey();
			gstinList=entry.getValue();
			LOGGER.info("state= "+state + " ,GstinLIst=  "+gstinList);
			if(gstinList!=null && !gstinList.isEmpty())
			{
				gstinSummaryList=new ArrayList<>();
				for(String gstin:gstinList)
				{
					LOGGER.info("gstinMap=  "+gstinMap.get(gstin)!=null?gstinMap.get(gstin).getMapGstinData():"null");
					gstinSummaryList.add(gstinMap.get(gstin));
				}
				gstinSummaryMap.put(state, gstinSummaryList);
			}
			else
			{
				gstinSummaryMap.put(state, null);
			}
		}
		return gstinSummaryMap;
	}
	
	@Override
	public Object[] getFileGstr3Status(Gstr3Dto gstr3Dto) {
		 List<FIleSubmissionStatusDetails> fIleSubmissionStatusList= gstr3Dao.getFileGstr3Status(gstr3Dto);
		
		return fIleSubmissionStatusList.toArray(); 
	}

	@Override
	public List<CashUtilizationTransaction> getCashUtilizationTransaction(Gstr3Dto gstr3Dto) {
		List<CashUtilizationTransaction> cashUtilTrnxList = gstr3Dao.getCashUtilizationTransaction(gstr3Dto); 
		return cashUtilTrnxList;
	}
	
	@Override
	@Transactional
	public String saveGstr3FileSubmStatus(FIleSubmissionStatusDetails fIleSubmissionStatusDetails){
		
		gstr3Dao.saveFileStatus(fIleSubmissionStatusDetails);
		 return "success";
		
	}
	
	@Override
	public List<ReturnSubmissionStatus> getITCCashDetials(Gstr3Dto gstr3Dto){
		
		return gstr3Dao.getITCCashDetials(gstr3Dto);
		
	}

	@Override
	public String getLiabilityPosition(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getLiabilityPosition");
		return gstr3Dao.getLiabilityPosition(gstr3Dto);
	}
	
	@Override
	public String getLiabilityDetails(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getLiabilityPosition");
		return gstr3Dao.getLiabilityDetails(gstr3Dto);
	}
	
	@Override
	public String getCashPosition(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getCashPosition");
		return gstr3Dao.getCashPosition(gstr3Dto);
	}

	@Override
	public String getITCPosition(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getITCPosition");
		return gstr3Dao.getITCPosition(gstr3Dto);
	}

	@Override
	public boolean isPreviousTaxPeriodFiled(Gstr3Dto gstr3Dto) {
		return gstr3Dao.isPreviousTaxPeriodFiled(gstr3Dto);
	}

	@Override
	public String getConsCashTransaction(Gstr3Dto gstr3Dto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getConsCashTransaction");
		return gstr3Dao.getConsCashTransaction(gstr3Dto);
	}
	
	@Override
	public String getDebitNo(Gstr3RefundDetails gstr3RefundDetails) {
		String inputData="{\"gstin\":\"68ABCDE2752F2Z1\",\"name\":\"KamathFoods\",\"add\":\"C56,Bangalore,Karnataka\",\"fp_fm\":\"062016\",\"fp_fy\":\"2015-16\",\"tod\":"
				+ "{\"gt\":100000,\"et\":25100,\"nil_edt\":500560,\"ngt\":10085,\"ntt\":45126.2},\"out_s\":[{\"intr_sup_reg\":[{\"ty\":\"G\",\"state_cd\":\"02\",\"txrt\":10,\"val\":10000,\"iamt\":200}]"
				+ ",\"itra_sup_reg\":[{\"ty\":\"S\",\"txrt\":10,\"val\":10000,\"camt\":200,\"samt\":220}],\"intr_sup_con\":[{\"ty\":\"G\",\"state_cd\":\"02\",\"txrt\":10,\"val\":10000,\"iamt\":200}],"
				+ "\"intra_sup_con\":[{\"ty\":\"G\",\"txrt\":10,\"val\":10000,\"camt\":200,\"samt\":200}],\"exp\":[{\"ty\":\"G\",\"txval\":10000,\"iamt\":100,\"camt\":200,\"samt\":302,\"ex_ty\":\"WPAY\"},"
				+ "{\"ty\":\"G\",\"txval\":10000,\"iamt\":100,\"camt\":200,\"samt\":302,\"ex_ty\":\"WOPAY\"},{\"ty\":\"S\",\"txval\":10000,\"iamt\":100,\"camt\":200,\"samt\":302,\"ex_ty\":\"WPAY\"},"
				+ "{\"ty\":\"S\",\"txval\":10000,\"iamt\":100,\"camt\":200,\"samt\":302,\"ex_ty\":\"WOPAY\"}],\"rev_inv\":[{\"ty\":\"S\",\"mon\":\"2\",\"state_cd\":\"02\",\"doc_ty\":\"I\",\"num\":"
				+ "\"74108526053\",\"dt\":\"25-10-2016\",\"diff_val\":10000,\"iamt\":4563.2,\"camt\":7412,\"samt\":200}],"
				+ "\"ttl\":[{\"ty\":\"G\",\"mon\":\"2\",\"val\":74108526053,\"iamt\":4563,\"camt\":1234.89,\"samt\":1234.5},"
				+ "{\"ty\":\"S\",\"mon\":\"2\",\"val\":74108526053,\"iamt\":4563,\"camt\":1234.89,\"samt\":1234.5}]}],"
				+ "\"in_s\":{\"intr_sup_rec\":[{\"ty\":\"GI\",\"state_cd\":\"01\",\"txrt\":10,\"val\":852369,\"iamt\":100.32,\"tc_i\":200}],"
				+ "\"itra_sup_rec\":[{\"ty\":\"CG\",\"txrt\":100,\"val\":9008,\"camt\":1236,\"samt\":200,\"tc_c\":200,\"tc_s\":200}],"
				+ "\"imp\":{\"ty\":\"None\",\"aval\":10000,\"iamt\":200,\"tc_i\":0},"
				+ "\"rev_inv\":[{\"mon\":\"2\",\"gstin\":\"07ABCDE1234F105\",\"state_cd\":\"03\",\"ty\":\"S\",\"sub_ty\":\"Services\",\"hsn_sc\":\"151222410\",\"doc_ty\":\"D\",\"num\":\"19081\","
				+ "\"dt\":\"25-10-2016\",\"diff_val\":1000,\"iamt\":200,\"camt\":200,\"samt\":400,\"tc_i\":100,\"tc_c\":101,\"tc_s\":102}],"
				+ "\"ttl\":[{\"ty\":\"S\",\"mon\":\"2\",\"val\":10000,\"camt\":201,\"samt\":220,\"iamt\":210}],"
				+ "\"itc_rev\":[{\"desc\":\"DescriptionaboutITCReversal\",\"rsn\":\"ReasonforITCReversal\",\"iamt\":200,\"iint\":10,\"camt\":200,\"cint\":10,\"samt\":236,\"sint\":12}]},"
				+ "\"ttl\":[{\"ty\":\"S\",\"mon\":\"2\",\"val\":74108526053,\"camt\":200,\"samt\":100,\"iamt\":234}],\"tds_rcd\":[{\"gstin\":\"07561460ADXJK\",\"irt\":10,\"itx\":200.03,\"crt\":20,\"ctx\":500.02,\"srt\":22,\"stx\":789.2}],"
				+ "\"itc_rcd\":[{\"desc\":\"CG\",\"irt\":10,\"itx\":200.03,\"crt\":20,\"ctx\":500.02,\"srt\":22,\"stx\":789.2},"
				+ "{\"desc\":\"GI\",\"irt\":10,\"itx\":200.03,\"crt\":20,\"ctx\":500.02,\"srt\":22,\"stx\":789.2},{\"desc\":\"S\",\"irt\":10,\"itx\":200.03,\"crt\":20,\"ctx\":500.02,\"srt\":22,\"stx\":789.2}],"
				+ "\"pay_det\":{\"tctp\":{\"pay\":900,\"csh_dbno\":10002,\"csh_iamt\":100,\"csh_camt\":2003.5,\"csh_samt\":789.302,\"itc_dbno\":15963.5,\"itc_iamt\":100,\"itc_camt\":2003.5,\"itc_samt\":789.302},"
				+ "\"tptp\":{\"pay\":900,\"csh_dbno\":10002,\"csh_iamt\":100,\"csh_camt\":2003.5,\"csh_samt\":789.302,\"itc_dbno\":15963.5,\"itc_iamt\":100,\"itc_camt\":2003.5,\"itc_samt\":789.302},"
				+ "\"txli\":{\"pay\":900,\"csh_dbno\":10002,\"csh_iamt\":100,\"csh_camt\":2003.5,\"csh_samt\":789.302,\"itc_dbno\":15963.5,\"itc_iamt\":100,\"itc_camt\":2003.5,\"itc_samt\":789.302},"
				+ "\"intr\":{\"pay\":900,\"csh_dbno\":10002,\"csh_iamt\":100,\"csh_camt\":2003.5,\"csh_samt\":789.302,\"itc_dbno\":15963.5,\"itc_iamt\":100,\"itc_camt\":2003.5,\"itc_samt\":789.302},"
				+ "\"lfee\":{\"pay\":900,\"csh_dbno\":10002,\"csh_iamt\":100,\"csh_camt\":2003.5,\"csh_samt\":789.302,\"itc_dbno\":15963.5,\"itc_iamt\":100,\"itc_camt\":2003.5,\"itc_samt\":789.302},"
				+ "\"pnlty\":{\"pay\":900,\"csh_dbno\":10002,\"csh_iamt\":100,\"csh_camt\":2003.5,\"csh_samt\":789.302,\"itc_dbno\":15963.5,\"itc_iamt\":100,\"itc_camt\":2003.5,\"itc_samt\":789.302},"
				+ "\"othrs\":{\"pay\":900,\"csh_dbno\":10002,\"csh_iamt\":100,\"csh_camt\":2003.5,\"csh_samt\":789.302,\"itc_dbno\":15963.5,\"itc_iamt\":100,\"itc_camt\":2003.5,\"itc_samt\":789.302}},"
				+ "\"rf_clm\":{\"rfd_tc\":{\"itc_camt\":36644422.56,\"itc_samt\":315.46,\"itc_iamt\":791.07},\"ex_tp\":{\"ex_tp_rfd\":{\"ex_rf_camt\":7441.36,\"ex_rf_samt\":3.42,\"ex_rf_iamt\":1.61},"
				+ "\"ex_tp_adj\":{\"ex_cl_camt\":7441.36,\"ex_cl_samt\":3.42,\"ex_cl_iamt\":1.61}},\"rfd_cl\":{\"rf_cl_camt\":109145.12,\"rf_cl_samt\":44833.75,\"rf_cl_iamt\":3565502.38},"
				+ "\"bnk_num\":{\"b_camt\":258434857.27,\"b_samt\":37.08,\"b_iamt\":334.84}}}";
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : utilizeCash");
		String jsonDataValue = "";
		String result = "";
		try {
			AuthDetailsDto authDetails = authenticationUtility.validateAuthToken(inputData);
			result = commonApiService.sendGSTR3Data(authDetails);
			jsonDataValue = authenticationUtility.getPayloadForGSTN(result, authDetails);
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : utilizeCash",e);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : utilizeCash");
		
		return jsonDataValue;
	}
	
	
	@Override
    public String saveRefundDetails(Gstr3RefundDetails gstr3RefundDetails) {
         String s= gstr3Dao.saveRefundDetails(gstr3RefundDetails);
          return  s;
    }

	@Override
	public String autoFillItc(Gstr3Dto gstr3Dto) {
		return gstr3Dao.autoFillItc(gstr3Dto);
	}

	@Override
	public String saveItc(Gstr3Dto gstr3Dto) {
		return gstr3Dao.saveItc(gstr3Dto);
	}

	@Override
	public String submitItc(Gstr3Dto gstr3Dto) {
		return gstr3Dao.submitItc(gstr3Dto);
	}

	@Override
	public String getItcBalance(Gstr3Dto gstr3Dto) {
		return gstr3Dao.getItcBalance(gstr3Dto);
	}
	@Override
    public Gstr3RefundDetails getRefundDetail(Gstr3RefundDetails gstr3RefundDetails) {
         
          return  gstr3Dao.getRefundDetail(gstr3RefundDetails);
    }

	/*Method to get saved interest liability from db*/
	@Override
	public String getInterestLiabilitySaved(Gstr3Dto gstr3Dto) {
		// TODO Auto-generated method stub
		return gstr3Dao.getInterestLiabilitySaved(gstr3Dto);
	}
	
	@Override
	public String getSummaryJSON(Gstr3Dto gstr3Dto) throws ServiceLayerException {
		String status = Constant.FAILED;
		try {
			status = gstr3Dao.getSummaryJSON(gstr3Dto);
		} catch (DataException e) {
			throw new ServiceLayerException(e.getMessage(), e);
		}
		return status;
	} 
	public String saveGstr3Details(int masterId,GSTR3RootDTO dto) throws ServiceLayerException {
		String status = Constant.FAILED;
		try {
			status = gstr3Dao.saveGstr3Details(masterId, dto);
		} catch (DataException e) {
			throw new ServiceLayerException(e.getMessage(), e);
		}
		return status;
	}

	@Override
	public boolean fetchRecordfromDB(Gstr3Dto gstr3Dto) throws ServiceLayerException {
		boolean status = false;
		try {
			status = gstr3Dao.fetchRecordfromDB(gstr3Dto);

		} catch (DataException e) {
			throw new ServiceLayerException(e);
		}
		return status;
	}

	@Override
	public int findMasterDetails(Gstr3Dto gstr3Dto) throws ServiceLayerException {
		int id = 0;
		try {
			id = gstr3Dao.findMasterDetails(gstr3Dto);
		} catch (DataException e) {
			throw new ServiceLayerException(e.getMessage(), e);
		}
		return id;
	}
	@Override
	public String saveInterestLiability(GSTR3InterestLiablityDto dto) {
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : saveInterestLiability ");
		
		boolean saveStatus = gstr3Dao.saveInterestLiability(dto);
		if(saveStatus){
			return "success";
		}
		return "error";
	}

	@Override
	public boolean updateInterestLiabilitySubmit(String refId,Gstr3Dto gstr3Dto) {
		
		return gstr3Dao.updateInterestLiabilitySubmit(refId,gstr3Dto);
	} 
	@Override
	public String saveCashItcBalance(String cashITCJson,String gstin, String taxPeriod) {
		
		return gstr3Dao.saveCashItcBalance(cashITCJson,gstin,taxPeriod);
	}

	@Override
	public String saveEditedCashItcDetails(String cashITCJson) {
		// TODO Auto-generated method stub
		return gstr3Dao.saveEditedCashItcDetails(cashITCJson);
	}

	@Override
	public List<CashITCUtilization> getEditedCashItcDetails(String gstinId, String taxPeriod) {
		// TODO Auto-generated method stub
		return gstr3Dao.getEditedCashItcDetails(gstinId, taxPeriod);
	}
	
	@Override
	public String updateActiveStatus(Gstr3Dto gstr3dto) {
		return gstr3Dao.updateActiveStatus(gstr3dto);
	}
	
	@Override
	public Map<String, String> isSubmitGSTR3FormSection(Gstr3Dto gstr3Dto) throws ServiceLayerException{
		Map<String, String> map =new HashMap<String, String>();
		try{
		map =  gstr3Dao.isSubmitGSTR3FormSection(gstr3Dto);
		}
		catch(DataException e){
			throw new ServiceLayerException(e);	
			}
	return map;
	} 
	
	@Override
	public boolean updateSetoffLiabilitySubmit(String refId, Gstr3Dto gstr3dto) {
		 return gstr3Dao.updateSetoffLiabilitySubmit(refId, gstr3dto);	
	}

	@Override
	public boolean updateGstr3Submit(String gstin, String taxperiod) {
		return gstr3Dao.updateGstr3Submit(gstin, taxperiod);	
	}	
	
	@Override
    public String getSetoffLiabilityJsonSaved(Gstr3Dto gstr3Dto) {
          
          if (LOGGER.isInfoEnabled()) {
                LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " getSetoffLiabilityJsonSaved for GSTIN " + gstr3Dto.getGstin() + " taxperiod " + gstr3Dto.getRtPeriod());
          }
          
          String setoffLiabilityJson = " ";
          
          SetoffLiabilityDto setoffLiabilityDto = new SetoffLiabilityDto();
          
          SetoffLiabilityDBDto integratedSetoff = new SetoffLiabilityDBDto();
          SetoffLiabilityDBDto centralSetoff = new SetoffLiabilityDBDto();
          SetoffLiabilityDBDto stateSetoff = new SetoffLiabilityDBDto();
          SetoffLiabilityDBDto cessSetoff = new SetoffLiabilityDBDto();
          
          
          TxoffsetDto tx_offset = new TxoffsetDto();            
          PdcashDto pdcash = new PdcashDto();
          PditcDto pditcDto = new PditcDto();
          IntroffsetDto intr_offset = new IntroffsetDto();
          LfeeoffsetDto lfee_offset = new LfeeoffsetDto();            
          

          List<CashITCUtilization> cashITCUtilizations = gstr3Dao.getEditedCashItcDetails(gstr3Dto.getGstin(),
                      gstr3Dto.getRtPeriod());
          
          for(CashITCUtilization utilization : cashITCUtilizations){
                
                Gstr3AccountHead achead = utilization.getAccHeadId();
                
                if(achead.getTaxHead().equals("IGST")){
                      integratedSetoff.setITCIgstAmt(utilization.getITCIgstAmt());
                      integratedSetoff.setITCCgstAmt(utilization.getITCCgstAmt());
                      integratedSetoff.setITCSgstAmt(utilization.getITCSgstAmt());
                      integratedSetoff.setITCCessAmt(utilization.getITCCessAmt());
                      integratedSetoff.setCashTaxPaid(utilization.getCashTaxPaid());
                      integratedSetoff.setCashIntrestPaid(utilization.getCashIntrestPaid());
                      integratedSetoff.setCashLateFeePaid(utilization.getCashLateFeePaid());              
                }
                
                if(achead.getTaxHead().equals("CGST")){
                      centralSetoff.setITCIgstAmt(utilization.getITCIgstAmt());
                      centralSetoff.setITCCgstAmt(utilization.getITCCgstAmt());
                      centralSetoff.setITCSgstAmt(utilization.getITCSgstAmt());
                      centralSetoff.setITCCessAmt(utilization.getITCCessAmt());
                      centralSetoff.setCashTaxPaid(utilization.getCashTaxPaid());
                      centralSetoff.setCashIntrestPaid(utilization.getCashIntrestPaid());
                      centralSetoff.setCashLateFeePaid(utilization.getCashLateFeePaid());                 
                }
                if(achead.getTaxHead().equals("SGST")){
                      stateSetoff.setITCIgstAmt(utilization.getITCIgstAmt());
                      stateSetoff.setITCCgstAmt(utilization.getITCCgstAmt());
                      stateSetoff.setITCSgstAmt(utilization.getITCSgstAmt());
                      stateSetoff.setITCCessAmt(utilization.getITCCessAmt());
                      stateSetoff.setCashTaxPaid(utilization.getCashTaxPaid());
                      stateSetoff.setCashIntrestPaid(utilization.getCashIntrestPaid());
                      stateSetoff.setCashLateFeePaid(utilization.getCashLateFeePaid());             
                }
                
                if(achead.getTaxHead().equals("CESS")){
                      cessSetoff.setITCIgstAmt(utilization.getITCIgstAmt());
                      cessSetoff.setITCCgstAmt(utilization.getITCCgstAmt());
                      cessSetoff.setITCSgstAmt(utilization.getITCSgstAmt());
                      cessSetoff.setITCCessAmt(utilization.getITCCessAmt());
                      cessSetoff.setCashTaxPaid(utilization.getCashTaxPaid());
                      cessSetoff.setCashIntrestPaid(utilization.getCashIntrestPaid());
                      cessSetoff.setCashLateFeePaid(utilization.getCashLateFeePaid());                  
                }
          }     
          
          
          pdcash.setIpd(integratedSetoff.getCashTaxPaid());
          pdcash.setCpd(centralSetoff.getCashTaxPaid());
          pdcash.setSpd(stateSetoff.getCashTaxPaid());
          pdcash.setCspd(cessSetoff.getCashTaxPaid());
          
          tx_offset.setPdcash(pdcash);
          
          pditcDto.setI_pdi(integratedSetoff.getITCIgstAmt());
          pditcDto.setI_pdc(integratedSetoff.getITCCgstAmt());
          pditcDto.setI_pds(integratedSetoff.getITCSgstAmt());
          pditcDto.setC_pdi(centralSetoff.getITCIgstAmt());
          pditcDto.setC_pdc(centralSetoff.getITCCgstAmt());
          pditcDto.setS_pdi(stateSetoff.getITCIgstAmt());
          pditcDto.setS_pds(stateSetoff.getITCSgstAmt());
          pditcDto.setCs_pdcs(cessSetoff.getITCSgstAmt());
                      
          tx_offset.setPditc(pditcDto);
          
          intr_offset.setI_pdint(integratedSetoff.getCashIntrestPaid());
          intr_offset.setC_pdint(centralSetoff.getCashIntrestPaid());
          intr_offset.setS_pdint(stateSetoff.getCashIntrestPaid());
          intr_offset.setCs_pdint(cessSetoff.getCashIntrestPaid());
          
          lfee_offset.setC_pdlfee(centralSetoff.getCashLateFeePaid());
          lfee_offset.setS_pdlfee(stateSetoff.getCashLateFeePaid());
          
          setoffLiabilityDto.setTx_offset(tx_offset);
          setoffLiabilityDto.setIntr_offset(intr_offset);
          setoffLiabilityDto.setLfee_offset(lfee_offset); 
          
          ObjectMapper mapper=new ObjectMapper();
          
          try {
                setoffLiabilityJson = mapper.writeValueAsString(setoffLiabilityDto);
                System.out.println(setoffLiabilityDto);         
                
          } catch (Exception exception) {                       
                LOGGER.error(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD
                            + " getSetoffLiabilityJsonSaved", exception);
          }     
          
          if(LOGGER.isDebugEnabled())
                LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getSetoffLiabilityJsonSaved for GSTIN " + gstr3Dto.getGstin() + " taxperiod " + gstr3Dto.getRtPeriod());
          
          return setoffLiabilityJson;
    }

	@Override
	public String getsubmitGstr3toGstnJson(Gstr3Dto gstr3dto) {
		
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " getsubmitGstr3toGstnJson for GSTIN " + gstr3dto.getGstin() + " taxperiod " + gstr3dto.getRtPeriod());
		}
		
		String submitGstr3Json = " ";
		SubmitGSTR3Dto submitgstr3Dto = new SubmitGSTR3Dto();

		submitgstr3Dto.setGstin(gstr3dto.getGstin());
		submitgstr3Dto.setTaxperiod(gstr3dto.getRtPeriod());

		ObjectMapper mapper = new ObjectMapper();

		try {
			submitGstr3Json = mapper.writeValueAsString(submitgstr3Dto);
		} catch (Exception exception) {
			LOGGER.error(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD
					+ " getsubmitGstr3toGstnJson", exception);
		}
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getsubmitGstr3toGstnJson for GSTIN " + gstr3dto.getGstin() + " taxperiod " + gstr3dto.getRtPeriod());
		
		return submitGstr3Json;
	} 
	
	@Override
	public boolean insertGstr3GenerateData(String refId, Gstr3Dto gstr3dto) {
		return gstr3Dao.insertGstr3GenerateData(refId, gstr3dto);
	}
	

	@Override
	public Map<String,Boolean> isGtsr1AndGstr2Filed(Gstr3Dto gstr3dto) {
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " isGtsr1AndGstr2Filed");
		}
		return gstr3Dao.isGtsr1AndGstr2Filed(gstr3dto);
	} 
	
	@Override
	public boolean isGSTR3Generated(Gstr3Dto gstr3Dto) {
		return gstr3Dao.isGSTR3Generated(gstr3Dto);
	}
}
