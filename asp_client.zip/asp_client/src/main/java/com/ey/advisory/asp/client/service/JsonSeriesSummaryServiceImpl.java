package com.ey.advisory.asp.client.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.JsonSeriesSummaryDao;
import com.ey.advisory.asp.client.domain.JsonSeriesofSummaryData;
import com.ey.advisory.asp.common.Constant;



@Service
public class JsonSeriesSummaryServiceImpl implements JsonSeriesSummaryService {
	private static final Logger logger = Logger
			.getLogger(JsonSeriesSummaryServiceImpl.class);
	private static final String CLASS_NAME = JsonSeriesSummaryServiceImpl.class
			.getName();

	@Autowired
	JsonSeriesSummaryDao jsonSeriesSummaryDao;
	
	@Override
	public List<JsonSeriesofSummaryData> getJsonSeriesSummaryMetadata(){
		
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ Constant.LOGGER_METHOD + " getJsonSeriesSummaryMetadata");
		}
		return jsonSeriesSummaryDao.getJsonSeriesSummaryMetadata();
		
		
	}

}
