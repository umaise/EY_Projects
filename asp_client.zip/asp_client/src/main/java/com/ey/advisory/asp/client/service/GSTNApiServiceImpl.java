package com.ey.advisory.asp.client.service;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.client.dto.AuthDetailsDto;
import com.ey.advisory.asp.client.dto.Gstr3Dto;
import com.ey.advisory.asp.client.util.AuthenticationUtility;
import com.ey.advisory.asp.client.util.GSTNRestUtility;
import com.ey.advisory.asp.common.Constant;

@Component(value = "GSTN")
@PropertySource("classpath:GSTNConfig.properties")
public class GSTNApiServiceImpl implements CommonApiService {
	
	private static final Logger LOGGER = Logger.getLogger(GSTNApiServiceImpl.class);
	private static final String CLASS_NAME = GSTNApiServiceImpl.class.getName();

	@Autowired
	private Environment env;

	@Autowired
	private GSTNRestUtility gstnRestUtility;

	@Autowired
	AuthenticationUtility authenticationUtility;
	HttpHeaders httpHeaders = new HttpHeaders();
	
	/*********************GSTR1 related method *****************************************************/
	
	@Override
	public String gstr1Summary(String gstinId, String month, String year) {
		 httpHeaders = new HttpHeaders();

		String resource = env.getProperty("restapi.host") + env.getProperty("restapi.return") + Constant.GSTR1
				+ "?action=" + Constant.RETSUM + "&ret_period=" + month + year + "&gstin=" + gstinId;
		return gstnRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);

	}
	
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.gstr1.CommonApiService#sendGSTR1Data(com.ey.advisory.asp.client.dto.AuthDetailsDto)
	 * To call GSP for saving gstr1 data and get response of transaction Id
	 */
	@Override
	public String sendGSTR1Data(AuthDetailsDto authDetails) {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING+ CLASS_NAME + " Method : sendGSTR1Data");
		}
		try {
		String resource = env.getProperty("restapi.host")+env.getProperty("restapi.return")+Constant.GSTR1;
		
			String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.RETSAVE);
			return 	gstnRestUtility.executeRestCall(httpHeaders, inputData,resource, HttpMethod.PUT);
		} catch (IOException e) {
			LOGGER.error(Constant.LOGGER_ERROR+ CLASS_NAME + " Method : sendGSTR1Data",e);
			return e.getMessage();
		}
	}

	@Override
	public String gstr3Summary(String gstinId, String month, String year) {
		// TODO Auto-generated method stub
		return null;
	}

	

	@Override
	public String sendGSTR3Data(AuthDetailsDto authDetails) {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING+ CLASS_NAME + " Method : sendGSTR2Data");
		}
		try {
		String resource = env.getProperty("restapi.host")+env.getProperty("restapi.return")+Constant.GSTR3;
		
			String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.RETSAVE);
			return 	gstnRestUtility.executeRestCall(httpHeaders, inputData,resource, HttpMethod.PUT);
		} catch (IOException e) {
			LOGGER.error(Constant.LOGGER_ERROR+ CLASS_NAME + " Method : sendGSTR2Data",e);
			return e.getMessage();
		}
	}

	@Override
	public String gstr3RetStatus(String gstinId, String month, String year) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String generateReturns(AuthDetailsDto authDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCashLedgerSummary(Gstr3Dto gstr3Dto) {
		 httpHeaders = new HttpHeaders();
		String resource = env.getProperty("restapi.host") + env.getProperty("restapi.ledgers") + Constant.GSTR3
				+ "?action=" + Constant.CASHSUM + "&gstin=" + gstr3Dto.getGstin() + "&fr_dt=" + gstr3Dto.getFromDate()
				+ "&to_dt=" + gstr3Dto.getToDate();
		return gstnRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}

	@Override
	public String getItcLedgerSummary(Gstr3Dto gstr3Dto) {
		 httpHeaders = new HttpHeaders();
		String resource = env.getProperty("restapi.host") + env.getProperty("restapi.ledgers") + Constant.GSTR3
				+ "?action=" + Constant.ITCSUM + "&gstin=" + gstr3Dto.getGstin() + "&fr_dt=" + gstr3Dto.getFromDate()
				+ "&to_dt=" + gstr3Dto.getToDate();
		return gstnRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}

	@Override
	public String getGstr3Summary(Gstr3Dto gstr3Dto) {
		 httpHeaders = new HttpHeaders();
		String resource = env.getProperty("restapi.host") + env.getProperty("restapi.return") + Constant.GSTR3
				+ "?action=" + Constant.RETDET + "&gstin=" + gstr3Dto.getGstin() + "&ret_period="
				+ gstr3Dto.getRtPeriod();
		return gstnRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}

	@Override
	public String getLiabilityLedgerDetail(String gstn, String rtPeriod, String liabilityType) {
		 httpHeaders = new HttpHeaders();
		StringBuilder uri = new StringBuilder(
				"?action=" + Constant.TAX + "&gstin=" + gstn + "&rt_period=" + rtPeriod + "&liab_typ=" + liabilityType);
		String resource = env.getProperty("gsp-restapi.host") + env.getProperty("gsp-getLiabilityLedgerDetail")
				+ uri.toString();
		return gstnRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}

	@Override
	public String utilizeCash(AuthDetailsDto authDetails) {
		 httpHeaders = new HttpHeaders();
		httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		try {
			String resource = env.getProperty("restapi.host") + env.getProperty("restapi.ledger");
			String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.UTLCSH);
			return gstnRestUtility.executeRestCall(httpHeaders, inputData, resource, HttpMethod.POST);
		} catch (IOException e) {
			LOGGER.error(e);
			return e.getMessage();
		}

	}

	@Override
	public String utilizeItc(AuthDetailsDto authDetails) {
		 httpHeaders = new HttpHeaders();
		httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		try {
			String resource = env.getProperty("restapi.host") + env.getProperty("restapi.ledger");
			String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.UTLITC);
			return gstnRestUtility.executeRestCall(httpHeaders, inputData, resource, HttpMethod.POST);
		} catch (IOException e) {
			LOGGER.error(e);
			return e.getMessage();
		}

	}
	/*********************GSTR2 related method *****************************************************/
	
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.gstr1.CommonApiService#sendGSTR2Data(com.ey.advisory.asp.client.dto.AuthDetailsDto)
	 * To call GSP for saving gstr2 data and get response of transaction Id
	 */
	@Override
	public String sendGSTR2Data(AuthDetailsDto authDetails) {
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Constant.LOGGER_ENTERING+ CLASS_NAME + " Method : sendGSTR2Data");
		}
		try {
		String resource = env.getProperty("restapi.host")+env.getProperty("restapi.return")+Constant.GSTR2;
		
			String inputData = authenticationUtility.gstrReqPayload(authDetails, Constant.RETSAVE);
			return 	gstnRestUtility.executeRestCall(httpHeaders, inputData,resource, HttpMethod.PUT);
		} catch (IOException e) {
			LOGGER.error(Constant.LOGGER_ERROR+ CLASS_NAME + " Method : sendGSTR2Data",e);
			return e.getMessage();
		}
	}

	@Override
	public String gstr2Summary(String gstinId, String month, String year) {
		httpHeaders = new HttpHeaders();

		String resource = env.getProperty("restapi.host") + env.getProperty("restapi.return") + Constant.GSTR2
				+ "?action=" + Constant.RETSUM + "&ret_period=" + month + year + "&gstin=" + gstinId;
		return gstnRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);

	}

	@Override
	public String signfileGstr3(String gstinId, String month, String year) {
		 httpHeaders = new HttpHeaders();
		String resource = env.getProperty("restapi.host")+env.getProperty("restapi.return")+Constant.GSTR3+"?action="+Constant.RETDET+
				"&ret_period="+month+year+"&gstin="+gstinId;
		return 	gstnRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}
	
	@Override
	public String signfileGstr6(String gstinId, String month, String year) {
		 httpHeaders = new HttpHeaders();
		String resource = env.getProperty("restapi.host")+env.getProperty("restapi.return")+Constant.GSTR6+"?action="+Constant.RETDET+
				"&ret_period="+month+year+"&gstin="+gstinId;
		return 	gstnRestUtility.executeRestCall(httpHeaders, resource, HttpMethod.GET);
	}
	
	@Override
	public String gstr6Summary(String sectionSumm,String gstinId, String month, String year) {
		 httpHeaders = new HttpHeaders();

		String resource = env.getProperty("restapi.host-stub") + env.getProperty("restapi.return") + Constant.GSTR6
				+ "?action=" + sectionSumm + "&ret_period=102016"  + "&gstin=33GSPTN0481G1ZA"+"&action_required=Y" ;
		
		return gstnRestUtility.executeRestCallTest(httpHeaders, resource, HttpMethod.GET);

	}

}
