package com.ey.advisory.asp.client.service.gstr2;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR2SummaryItcReversal;

@FunctionalInterface
public interface GSTR2SummaryItcReversalService {
	
	public List<GSTR2SummaryItcReversal> getItcReversalMetadata(); 

}
