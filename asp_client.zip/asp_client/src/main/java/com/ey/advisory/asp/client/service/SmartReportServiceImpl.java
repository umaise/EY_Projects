package com.ey.advisory.asp.client.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.SmartReportDao;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.SmartReport;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.dto.SmartReportDto;
import com.ey.advisory.asp.client.util.CommonUtillity;
import com.ey.advisory.asp.client.util.GSTNRestClientUtility;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.DynamicSmartReportDto;

@Service
public class SmartReportServiceImpl implements SmartReportService{
	
	@Autowired
	private SmartReportDao smartReportDao;
	
	@Autowired
	private TblGstinRetutnFilingStatusService tblGstinRetutnFilingStatusService;
	
	@Autowired
	Environment env;

	@Autowired
	HibernateDao hibernateDao;
			
	@Autowired
	GSTNRestClientUtility restClientUtility;
	
	private static final Logger LOGGER = Logger.getLogger(SmartReportServiceImpl.class);
	private static final String CLASS_NAME = SmartReportServiceImpl.class.getName();

	@Override
	public String saveSmartReportDetails(SmartReportDto smartReportDto) {
		return smartReportDao.saveSmartReportDetails(smartReportDto);		
	}

	@Override
	public List<SmartReport> getSmartReportDetails(String status) {
		return smartReportDao.getSmartReportDetails(status);
	}
	
	@Override
	public SmartReport getSmartReportDetailsByReportId(String reportId){
		return smartReportDao.getSmartReportDetailsByReportId(reportId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OutwardInvoiceModel> getOutwardSuppliesData(
			DynamicSmartReportDto requestDetails,int offset,int pageSize) throws Exception {
		List<OutwardInvoiceModel> revisedCreditList = null;
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getOutwardSuppliesData");
		}
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
			detachedCriteria.createAlias("invoiceKeyDetail", "invoiceKeyDetail");
			detachedCriteria.add(Restrictions.eq("taxperiod", requestDetails.getWhereConditions().getReturnPeriod().concat(requestDetails.getWhereConditions().getFinancialYear())));
			detachedCriteria.add(Restrictions.in("documentType",requestDetails.getWhereConditions().getDocType().split(",")));
			detachedCriteria.add(Restrictions.in("supplyType", requestDetails.getWhereConditions().getSupType().split(",")));
			detachedCriteria.add(Restrictions.eq("isError", false));
			detachedCriteria.add(Restrictions.eq("isDuplicate", false));
			detachedCriteria.add(Restrictions.eq("itemStatus", "GSTR1_BR_STG1"));
			// If the type of report = "RecordsSavedToGSTN" then set the isSuccessToGsntn to true
			// Otherwise false. This selection is made by the user through the Request Report page.
			String typeOfReport = requestDetails.getWhereConditions().getTypeOfReport();
			if("RecordsSavedToGSTN".equals(typeOfReport)){
				detachedCriteria.add(Restrictions.eq("invoiceKeyDetail.isSuccessToGstn", true));
			}else{
		
				Disjunction or = Restrictions.disjunction();
				or.add(Restrictions.eq("invoiceKeyDetail.isSuccessToGstn",false));
				or.add(Restrictions.isNull("invoiceKeyDetail.isSuccessToGstn"));
		        detachedCriteria.add(or);
			}
			detachedCriteria.add(Restrictions.eq("invoiceKeyDetail.isActive", true));
			detachedCriteria.add(Restrictions.in("sGSTIN", requestDetails.getWhereConditions().getRecpGstin().split(",")));
			Date startDate = (Date) format.parse(requestDetails.getWhereConditions().getStartDate());
			Date endDate = (Date) format.parse(requestDetails.getWhereConditions().getEndDate());
			detachedCriteria.add(Restrictions.between("documentDate",startDate , endDate));
			 ProjectionList projectionList=Projections.projectionList();
			 for(String property:requestDetails.getSelectedColumns().getColumn()){
				 projectionList.add(Projections.property(property),property);
			 }
			detachedCriteria.setProjection(Projections.distinct(projectionList));
			
			detachedCriteria.setResultTransformer(Transformers.aliasToBean(OutwardInvoiceModel.class));
			detachedCriteria.addOrder(Order.asc("documentNo"));
			revisedCreditList = (List<OutwardInvoiceModel>) hibernateDao.findByCriteria(detachedCriteria, offset, pageSize);
			
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getOutwardSuppliesData : OutwardInvoiceModel size "+revisedCreditList.size());
			}
			}catch(Exception e){
			if (LOGGER.isDebugEnabled()) {
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getOutwardSuppliesData ",e);
			}
			
			throw e;
			}
		return revisedCreditList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<InwardInvoiceModel> getInwardSuppliesData(
			DynamicSmartReportDto requestDetails,int offset,int pageSize) {
		
		List<InwardInvoiceModel> revisedCreditList = null;
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getInwardSuppliesData");
		}
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(InwardInvoiceModel.class);
			
			if( null != requestDetails.getWhereConditions().getReconResponse()  && !requestDetails.getWhereConditions().getReconResponse().trim().isEmpty()){
				detachedCriteria.createAlias("reconResult", "reconResult");
			}
			else{
				detachedCriteria.createAlias("gstr2InvoiceKeyDetail", "gstr2InvoiceKeyDetail");
				
			}
			detachedCriteria.add(Restrictions.eq("taxPeriod", requestDetails.getWhereConditions().getReturnPeriod().concat(requestDetails.getWhereConditions().getFinancialYear())));
			detachedCriteria.add(Restrictions.in("documentType",requestDetails.getWhereConditions().getDocType().split(",")));
			detachedCriteria.add(Restrictions.in("supplyType", requestDetails.getWhereConditions().getSupType().split(",")));
			detachedCriteria.add(Restrictions.in("cGSTIN", requestDetails.getWhereConditions().getRecpGstin().split(",")));
			detachedCriteria.add(Restrictions.in("eligibilityIndicator", requestDetails.getWhereConditions().getEligibilityIndtr().split(",")));
			if( null != requestDetails.getWhereConditions().getReconResponse()  && !requestDetails.getWhereConditions().getReconResponse().trim().isEmpty()){
				detachedCriteria.add(Restrictions.in("reconResult.eySuggestedResponse", requestDetails.getWhereConditions().getReconResponse().split(",")));
				detachedCriteria.add(Restrictions.eq("reconResult.isActive", true));
			}else{
				detachedCriteria.add(Restrictions.eq("gstr2InvoiceKeyDetail.isSuccessToGstn", true));
			}
			detachedCriteria.add(Restrictions.eq("isError", false));
			detachedCriteria.add(Restrictions.eq("isDuplicate", false));
			detachedCriteria.add(Restrictions.eq("itemStatus", "GSTR2_BR_STG1"));
			Date startDate = (Date) format.parse(requestDetails.getWhereConditions().getStartDate());
			Date endDate = (Date) format.parse(requestDetails.getWhereConditions().getEndDate());
			detachedCriteria.add(Restrictions.between("documentDate",startDate , endDate));
			 ProjectionList projectionList=Projections.projectionList();			 
				 for(String property:requestDetails.getSelectedColumns().getColumn()){
					 if(property.equalsIgnoreCase("eySuggestedResponse")){
						 projectionList.add(Projections.property("reconResult.eySuggestedResponse"),"eySuggestedResponse");
					 }
					 else if (property.equalsIgnoreCase("clientResponse")){
						 projectionList.add(Projections.property("reconResult.clientResponse"),"clientResponse");
					 }
					 else if (property.equalsIgnoreCase("reconReport")){
						 projectionList.add(Projections.property("reconResult.reconResponse"),"reconResponse");
					 }
					 else{
					 projectionList.add(Projections.property(property),property);
					 }
				 }
			detachedCriteria.setProjection(Projections.distinct(projectionList));
			detachedCriteria.setResultTransformer(Transformers.aliasToBean(InwardInvoiceModel.class));
			//detachedCriteria.addOrder(Order.asc("id"));
			revisedCreditList = (List<InwardInvoiceModel>) hibernateDao.findByCriteria(detachedCriteria, offset, pageSize);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getInwardSuppliesData : InwardInvoiceModel size "+revisedCreditList.size());
			}
			}catch(Exception e){
				if (LOGGER.isDebugEnabled()) {
					LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getInwardSuppliesData ",e);
				}
			}
		return revisedCreditList;
	}
	
	@Override
		public boolean updateSmartReportPathAndFileName(String reportId,String filePath,
				String fileName) {
			return smartReportDao.updateSmartReportPathAndFileName(reportId, filePath, fileName);
		}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<OutwardInvoiceModel> getStockTransferData(
			DynamicSmartReportDto requestDetails,String sGstin,int offset,int pageSize) throws Exception {
		List<OutwardInvoiceModel> stockTransferList = null;
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getStockTransferData");
		}
		try{
			String stateCode=sGstin.substring(0, 2);
			String pan=sGstin.substring(2, 12);
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(OutwardInvoiceModel.class);
			detachedCriteria.createAlias("invoiceKeyDetail", "invoiceKeyDetail");
			detachedCriteria.add(Restrictions.eq("taxperiod", requestDetails.getWhereConditions().getReturnPeriod().concat(requestDetails.getWhereConditions().getFinancialYear())));
			detachedCriteria.add(Restrictions.eq("sGSTIN",sGstin));
			detachedCriteria.add(Restrictions.or(Restrictions.ne("cGSTIN",""),Restrictions.isNotNull("cGSTIN")));
			
			//detachedCriteria.add(Restrictions.not(Restrictions.like("cGSTIN",stateCode,MatchMode.START)));
			detachedCriteria.add(Restrictions.like("cGSTIN",pan,MatchMode.ANYWHERE));
			detachedCriteria.add(Restrictions.eq("isError", false));
			detachedCriteria.add(Restrictions.eq("isDuplicate", false));
			// If the type of report = "RecordsSavedToGSTN" then set the isSuccessToGsntn to true
						// Otherwise false. This selection is made by the user through the Request Report page.
			String typeOfReport = requestDetails.getWhereConditions()
					.getTypeOfReport();
			if ("RecordsSavedToGSTN".equals(typeOfReport)) {
				detachedCriteria.add(Restrictions.eq("invoiceKeyDetail.isSuccessToGstn", true));
			} else {
				Disjunction or = Restrictions.disjunction();
				or.add(Restrictions.eq("invoiceKeyDetail.isSuccessToGstn", false));
				or.add(Restrictions.isNull("invoiceKeyDetail.isSuccessToGstn"));
				detachedCriteria.add(or);
			}
			detachedCriteria.add(Restrictions.eq("invoiceKeyDetail.isActive", true));
			Date startDate = (Date) format.parse(requestDetails.getWhereConditions().getStartDate());
			Date endDate = (Date) format.parse(requestDetails.getWhereConditions().getEndDate());
			detachedCriteria.add(Restrictions.between("documentDate",startDate , endDate));
			ProjectionList projectionList=Projections.projectionList();
			for(String property:requestDetails.getSelectedColumns().getColumn()){
				projectionList.add(Projections.property(property),property);
			}
			detachedCriteria.setProjection(Projections.distinct(projectionList));
			detachedCriteria.setResultTransformer(Transformers.aliasToBean(OutwardInvoiceModel.class));
			detachedCriteria.addOrder(Order.asc("documentNo"));
			stockTransferList = (List<OutwardInvoiceModel>) hibernateDao.findByCriteria(detachedCriteria, offset, pageSize);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getStockTransferData : OutwardInvoiceModel size "+stockTransferList.size());
			}
		}catch(Exception e){
			if (LOGGER.isDebugEnabled()) {
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getStockTransferData ",e);
			}
			
			throw e;
		}
		return stockTransferList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<InwardInvoiceModel> getRcmData(
			DynamicSmartReportDto requestDetails,String category,int offset,int pageSize) {
		List<InwardInvoiceModel> rcmList = null;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getRcmData");
		}
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(InwardInvoiceModel.class);
			if(category.equals("imps"))
				detachedCriteria = getIosData(detachedCriteria, requestDetails);
			if(category.equals("nots"))
				detachedCriteria = getNotifiedSuppliedData(detachedCriteria, requestDetails);
			if(category.equals("unreg"))
				detachedCriteria = getUnregisteredData(detachedCriteria, requestDetails);
			rcmList = (List<InwardInvoiceModel>) hibernateDao.findByCriteria(detachedCriteria, offset, pageSize);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getRcmData : InwardInvoiceModel size "+rcmList.size());
			}
		}catch(Exception e){
			if (LOGGER.isDebugEnabled()) {
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getRcmData ",e);
			}
		}
		return rcmList;
	}
	
	private DetachedCriteria getIosData(DetachedCriteria detachedCriteria, DynamicSmartReportDto requestDetails) {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getIosData");
		}
		try{
		detachedCriteria.createAlias("gstr2InvoiceKeyDetail", "gstr2InvoiceKeyDetail");
		detachedCriteria.add(Restrictions.eq("taxPeriod", requestDetails.getWhereConditions().getReturnPeriod().concat(requestDetails.getWhereConditions().getFinancialYear())));
		detachedCriteria.add(Restrictions.eq("documentType","SLF"));
		detachedCriteria.add(Restrictions.eq("supplyType", "IMP"));
		detachedCriteria.add(Restrictions.eq("reverseCharge","Y"));
		detachedCriteria.add(Restrictions.or(Restrictions.eq("SGSTIN", ""),Restrictions.isNull("SGSTIN")));
		detachedCriteria.add(Restrictions.or(Restrictions.eq("billOfEntry",""),Restrictions.isNull("billOfEntry")));
		detachedCriteria.add(Restrictions.isNull("billOfEntryDate"));
		detachedCriteria.add(Restrictions.eq("isError", false));
		detachedCriteria.add(Restrictions.eq("isDuplicate", false));
		detachedCriteria.add(Restrictions.eq("itemStatus", "GSTR2_BR_STG1"));
		detachedCriteria.add(Restrictions.eq("gstr2InvoiceKeyDetail.isSuccessToGstn", true));
		Date startDate = (Date) format.parse(requestDetails.getWhereConditions().getStartDate());
		Date endDate = (Date) format.parse(requestDetails.getWhereConditions().getEndDate());
		detachedCriteria.add(Restrictions.between("documentDate",startDate , endDate));
		ProjectionList projectionList=Projections.projectionList();
		for(String property:requestDetails.getSelectedColumns().getColumn()){
			projectionList.add(Projections.property(property),property);
		}
		detachedCriteria.setProjection(Projections.distinct(projectionList));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(InwardInvoiceModel.class));
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getIosData");
		}
	}catch(ParseException e){
		if (LOGGER.isDebugEnabled()) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getIosData ",e);
		}
	}
		return detachedCriteria;
		
	}
	
	private DetachedCriteria getNotifiedSuppliedData(DetachedCriteria detachedCriteria,DynamicSmartReportDto requestDetails){
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getNotifiedSuppliedData");
		}
		try {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		detachedCriteria.createAlias("gstr2InvoiceKeyDetail", "gstr2InvoiceKeyDetail");
		detachedCriteria.add(Restrictions.eq("taxPeriod", requestDetails.getWhereConditions().getReturnPeriod().concat(requestDetails.getWhereConditions().getFinancialYear())));
		detachedCriteria.add(Restrictions.eq("documentType","INV"));
		detachedCriteria.add(Restrictions.eq("supplyType", "TAX"));
		detachedCriteria.add(Restrictions.eq("reverseCharge","Y"));
		detachedCriteria.add(Restrictions.or(Restrictions.ne("SGSTIN",""),Restrictions.isNotNull("SGSTIN")));
		detachedCriteria.add(Restrictions.eq("isError", false));
		detachedCriteria.add(Restrictions.eq("isDuplicate", false));
		detachedCriteria.add(Restrictions.eq("gstr2InvoiceKeyDetail.isSuccessToGstn", true));
		detachedCriteria.add(Restrictions.eq("itemStatus", "GSTR2_BR_STG1"));
		Date startDate = (Date) format.parse(requestDetails.getWhereConditions().getStartDate());
		Date endDate = (Date) format.parse(requestDetails.getWhereConditions().getEndDate());
		detachedCriteria.add(Restrictions.between("documentDate",startDate , endDate));
		ProjectionList projectionList=Projections.projectionList();
		for(String property:requestDetails.getSelectedColumns().getColumn()){
			projectionList.add(Projections.property(property),property);
		}
		detachedCriteria.setProjection(Projections.distinct(projectionList));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(InwardInvoiceModel.class));
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getNotifiedSuppliedData");
		}
		} catch (ParseException e) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getNotifiedSuppliedData ",e);
			}
		}
		return detachedCriteria;
	}

	private DetachedCriteria getUnregisteredData(DetachedCriteria detachedCriteria,DynamicSmartReportDto requestDetails){
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering " + CLASS_NAME + Constant.LOGGER_METHOD + " getNotifiedSuppliedData");
		}
		try {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		detachedCriteria.createAlias("gstr2InvoiceKeyDetail", "gstr2InvoiceKeyDetail");
		detachedCriteria.add(Restrictions.eq("taxPeriod", requestDetails.getWhereConditions().getReturnPeriod().concat(requestDetails.getWhereConditions().getFinancialYear())));
		detachedCriteria.add(Restrictions.eq("documentType","SLF"));
		detachedCriteria.add(Restrictions.eq("supplyType", "TAX"));
		detachedCriteria.add(Restrictions.eq("reverseCharge","Y"));
		detachedCriteria.add(Restrictions.or(Restrictions.eq("SGSTIN",""),Restrictions.isNull("SGSTIN")));
		detachedCriteria.add(Restrictions.eq("isError", false));
		detachedCriteria.add(Restrictions.eq("isDuplicate", false));
		detachedCriteria.add(Restrictions.eq("itemStatus", "GSTR2_BR_STG1"));
		detachedCriteria.add(Restrictions.eq("gstr2InvoiceKeyDetail.isSuccessToGstn", true));
		Date startDate = (Date) format.parse(requestDetails.getWhereConditions().getStartDate());
		Date endDate = (Date) format.parse(requestDetails.getWhereConditions().getEndDate());
		detachedCriteria.add(Restrictions.between("documentDate",startDate , endDate));
		ProjectionList projectionList=Projections.projectionList();
		for(String property:requestDetails.getSelectedColumns().getColumn()){
			projectionList.add(Projections.property(property),property);
		}
		detachedCriteria.setProjection(Projections.distinct(projectionList));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(InwardInvoiceModel.class));
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting " + CLASS_NAME + Constant.LOGGER_METHOD + " getNotifiedSuppliedData");
		}
		} catch (ParseException e) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getNotifiedSuppliedData ",e);
			}
		}
		return detachedCriteria;
	}

	@Override
	public boolean updateSmartReportStatus(String reportId, String status) {
		return smartReportDao.updateSmartReportStatus(reportId, status);
	}

	public TblGstinRetutnFilingStatus findReportJobStatus(String gstin, String retPeriod, String api){
		boolean found = true;
		TblGstinRetutnFilingStatus returnFilingStatus = tblGstinRetutnFilingStatusService.fetchGstrReturnDetails(gstin, retPeriod, api);
		return returnFilingStatus;
	}
	
	public String getGSTR1FFStatus(String gstin, String retPeriod, String api){
		String status = null;
		try {
			status = tblGstinRetutnFilingStatusService.getStatusFor1FF(gstin, retPeriod, api);
		} catch (Exception e) {
			LOGGER.error("Exception in GSTR1FFServiceImpl.updateGSTR1FFStatus() : " + e);
		}
		return status;
	}
	
/*	@Override
	public String findGSTR1FFStatus(String gstin, String retPeriod, String api) {

		List<String> inputParams = new ArrayList<>();
		String updateResp = "";
		try {
			inputParams.add(retPeriod);
			inputParams.add(gstin);
			inputParams.add(api);
			updateResp = tblGstinRetutnFilingStatusService.findGstr1FFStatus(inputParams);

		} catch (Exception e) {
			LOGGER.error("Exception in GSTR1FFServiceImpl.updateGSTR1FFStatus() : " + e);
			//throw new Exception("Exception in GSTR1FFServiceImpl.updateGSTR1FFStatus() : " + e);
		}
		return updateResp;
	}
*/	
	@Override
	public String updateGSTR1FFStatus(String gstin, String retPeriod, String status) {
		
		List<String> inputParams = new ArrayList<>();
		String updateResp = "";
		try {
			inputParams.add(retPeriod);
			inputParams.add(gstin);
			inputParams.add(status);
			updateResp = tblGstinRetutnFilingStatusService.updateGstr1FFStatus(inputParams);
			
		} catch (Exception e) {
			LOGGER.error("Exception in GSTR1FFServiceImpl.updateGSTR1FFStatus() : " + e);
			//throw new Exception("Exception in GSTR1FFServiceImpl.updateGSTR1FFStatus() : " + e);
		}
		return updateResp;
	}
	
	@Override
	public String insertGSTR1FFStatus(String gstin, String retPeriod, String status) throws Exception {

		List<String> inputParams = new ArrayList<>();
		String updateResp = "";
		try {
			
			inputParams.add(retPeriod);
			inputParams.add(gstin);
			inputParams.add(status);
			updateResp = tblGstinRetutnFilingStatusService.insertGstr1FFEntry(inputParams);

		} catch (Exception e) {
			LOGGER.error("Exception in GSTR1FFServiceImpl.updateGSTR1FFStatus() : " + e);
			throw new Exception("Exception in GSTR1FFServiceImpl.updateGSTR1FFStatus() : " + e);
		}
		return updateResp;
	}

	@Override
	public String saveGSTR1FFData(String gstin, String retPeriod, String groupCode, String action, String respJSON,
			Integer chunkId) throws Exception {
		String saveResult = "";
		try {
			if (action != null && !action.isEmpty()) {

				if (action.equalsIgnoreCase(Constant.B2B)) {
					saveResult = smartReportDao.saveGSTR1FFB2B(respJSON, gstin, retPeriod, chunkId);
				} else if (action.equalsIgnoreCase(Constant.B2BA)) {
					 
				} else if (action.equalsIgnoreCase(Constant.CDN_INV)) {
				 
				} else if (action.equalsIgnoreCase(Constant.CDNA_INV)) {
					 
				}
			}
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " processGSTR1FFData() : ", e);
			throw new Exception(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " processGSTR1FFData() : ",
					e);
		}
		return saveResult;
	}
	
	@Override
	public String processRecievedResponse(String respJSON, String gstin, String retPeriod, String groupCode,
			String action, String hitCount) throws Exception {
		LOGGER.info("Inside processRecievedResponse for invoiceType "+action);
		String resourceURL = env.getProperty(Constant.BATCH_API_HOST)
				+ env.getProperty(Constant.SCHEDULE_TENANT_SIMPLE_TRIGGER);
		JSONObject returnType;
		String saveJsonResp = "";
		String finalReturnType = null;
		String returnTypeString = "";
		if (respJSON != null && !CommonUtillity.isEmpty(respJSON)) {
			returnType = checkReturnType(respJSON);
			LOGGER.info("Inside processRecievedResponse with return Type"+returnType);
			if (returnType != null && returnType.get("returnType") != null) {
				returnTypeString = returnType.get("returnType").toString();
				if (returnTypeString.equalsIgnoreCase(Constant.TOKEN_RECEIVED)) {
					finalReturnType = Constant.TOKEN_RECEIVED;
					LOGGER.info("Inside processRecievedResponse with returnTypeString"+returnTypeString);
					String est = (String) returnType.get("est");
					String token = (String) returnType.get("token");
					LOGGER.info("Inside processRecievedResponse , Before hitting batch ");
					String batchResp = scheduleSimpleTrigger(resourceURL,
							groupCode, est, action, gstin, token, retPeriod, hitCount);
					if (Constant.JOB_TRIGGERED.equalsIgnoreCase(batchResp)) {
						LOGGER.info("Rest call to batch is successfull for" + action + " .. ");
						String updateResult = updateGSTR1FFStatus(gstin, retPeriod, Constant.TOKEN_RECEIVED);

						if (Constant.SUCCESS.equalsIgnoreCase(updateResult)) {
							LOGGER.info("Status updated successfully in the Table for " + action + ".");
						} else {
							LOGGER.error("Could not update status in the Table for  " + action + "..!!");
						}
					} else {
						finalReturnType = batchResp;
						LOGGER.error("Rest call to batch is failed for " + action + "  " + batchResp + "  ..!! ");

					}
				} else if (returnTypeString.equalsIgnoreCase(Constant.RECONSTATE)) {
					if (!CommonUtillity.isEmpty(respJSON)) {
						int chunkId = 1;
						saveJsonResp = saveGSTR1FFData(gstin, retPeriod, groupCode, action, respJSON,
								chunkId);
						if (!CommonUtillity.isEmpty(saveJsonResp) && saveJsonResp.equalsIgnoreCase("Success")) {
							finalReturnType = Constant.RECONSTATE;
						} else {
							finalReturnType = "Failed to save "+action;
						}
					}
				} else if (returnTypeString.equalsIgnoreCase("Error")) {
					finalReturnType = "Invalid Response from GSTN";
				} else {
					finalReturnType = "Unexpected Error";
				}
			}
		}
		return finalReturnType;
	}

	@Override
	public String scheduleSimpleTrigger(String resourceURL,
			 String groupCode, String est, String action, String gstin, String token,
			String retPeriod, String hitCount) {
		String batchResp = restClientUtility.executePOSTRestCall(resourceURL, getHeaders(),
				getInputData(groupCode, est, action, gstin, token, retPeriod, hitCount), HttpMethod.POST);
		return batchResp;
	}

	@SuppressWarnings("unchecked")
	private JSONObject checkReturnType(String b2bRespJSON) throws ParseException {
		JSONObject jsonObjectVal = null;
		try {
			jsonObjectVal = (JSONObject) new JSONParser().parse(b2bRespJSON);
			if (jsonObjectVal != null) {
				if (jsonObjectVal.get("b2b") != null && jsonObjectVal.get("est") == null) {
					jsonObjectVal.put("returnType", Constant.RECONSTATE);

				} else if (jsonObjectVal.get("cdn") != null && jsonObjectVal.get("est") == null) {
					jsonObjectVal.put("returnType", Constant.RECONSTATE);

				} else if (jsonObjectVal.get("b2b") == null && jsonObjectVal.get("cdn") == null
						&& jsonObjectVal.get("est") != null) {
					jsonObjectVal.put("est", jsonObjectVal.get("est"));
					jsonObjectVal.put("token", jsonObjectVal.get("token"));
					jsonObjectVal.put("returnType", Constant.TOKEN_RECEIVED);

				} else { // TODO
					jsonObjectVal.put("error", "Invalid Response from GSTN");
					jsonObjectVal.put("returnType", "Error");
				}
			}

		} catch (org.json.simple.parser.ParseException e) {
			LOGGER.error("Exception in checkReturnType() : " + e);
		}
		return jsonObjectVal;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		return headers;
	}
	

	@SuppressWarnings("unchecked")
	private String getInputData(String groupCode, String est, String action, String gstin, String token,
			String taxPeriod, String hitCount) {

		String params = "jobName,groupCode,gstin,taxPeriod,token,invoiceType,hitCount";

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("jobName", Constant.GSTR1FF_TOKEN_JOB);
		jsonObject.put("groupCode", groupCode);
		jsonObject.put("taxPeriod", taxPeriod);
		jsonObject.put("token", token);
		jsonObject.put("gstin", gstin);
		jsonObject.put("action", action);
		jsonObject.put("timeInterval", est);
		jsonObject.put("priority", 5);
		jsonObject.put("repeatCount", 0);
		jsonObject.put("params", params);
		jsonObject.put("hitCount", hitCount);
		return jsonObject.toString();
	}

	@Override
	public String saveGSTR1FFData(String gstinId, String rtPeriod, String groupCode,  String  invType, String  json, String  chunkId){
		String response = null;
		
		return response;
	}
}
