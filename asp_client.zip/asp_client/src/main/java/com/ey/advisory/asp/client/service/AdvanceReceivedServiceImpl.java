package com.ey.advisory.asp.client.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.TblAdvanceReceived;
import com.ey.advisory.asp.common.Constant;


@Service
public class AdvanceReceivedServiceImpl implements AdvanceReceivedService {

    @Autowired
    HibernateDao hibernateDao;

    private static final Logger logger = Logger.getLogger(AdvanceReceivedServiceImpl.class);
    
    
    @Override
	public List<TblAdvanceReceived> fetchAll() {
		return hibernateDao.loadAllByNamedQuery("TblAdvanceReceived.findAll");
	}

	@Override
	public Long getTotalRecordCount(Long fileId) {
		  Long count = null;
		  try { 
			  
			  if(logger.isInfoEnabled())
				  logger.info(Constant.LOGGER_ENTERING + AdvanceReceivedServiceImpl.class.getName()
						  + " Method : getTotalRecordCount()");
			  
			  Criteria criteriaCount = hibernateDao.createNormalCriteria(TblAdvanceReceived.class);
			  criteriaCount.add(Restrictions.eq("summaryFileID", fileId));
			  criteriaCount.add(Restrictions.eq("isActive", Boolean.TRUE));
			  criteriaCount.setProjection(Projections.rowCount());
			  count = (Long) (criteriaCount).uniqueResult();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + AdvanceReceivedServiceImpl.class.getName()
	                + " Method : getTotalRecordCount()" + exe);
	        }
	
		return count;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TblAdvanceReceived> fetchTotalRecords(Long fileId, int firstResult, int pageSize) {
		List<TblAdvanceReceived>  tblAdvReceList = null;
		  try {
			  if(logger.isInfoEnabled())
				  logger.info(Constant.LOGGER_ENTERING + AdvanceReceivedServiceImpl.class.getName()
						  + " Method : fetchTotalRecords()");
			  
			  Criteria criteria = hibernateDao.createNormalCriteria(TblAdvanceReceived.class);
			  criteria.add(Restrictions.eq("summaryFileID", fileId));
			  criteria.add(Restrictions.eq("isActive", Boolean.TRUE));
			  criteria.setFirstResult(firstResult);
			  criteria.setMaxResults(pageSize);
			  criteria.addOrder(Order.asc("advRecID"));
			  tblAdvReceList = criteria.list();
	        }
	        catch (Exception exe) {
	        	if(logger.isInfoEnabled())
	            logger.info(Constant.LOGGER_ERROR + AdvanceReceivedServiceImpl.class.getName()
	                + " Method : fetchPages()" + exe);
	        }
	
		return tblAdvReceList;
	}


}
