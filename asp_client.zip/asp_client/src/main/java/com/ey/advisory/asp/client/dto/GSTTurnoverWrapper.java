package com.ey.advisory.asp.client.dto;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.client.domain.TblTurnoverDetails;

public class GSTTurnoverWrapper {
	
	private List<Map<String,String>> dataRows;

	public void setDataRows(List<Map<String, String>> dataRows) {
		this.dataRows = dataRows;
	}

}
