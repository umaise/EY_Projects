package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.EntityHeirarchyDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.dto.CommonSearchDto;
import com.ey.advisory.asp.client.dto.ResultPage;
import com.ey.advisory.asp.common.Constant;

@Repository
public class EntityHeirarchyDaoImpl implements EntityHeirarchyDao {
	
	@Autowired
	HibernateDao hibernateDao;

	private static final Logger logger = Logger.getLogger(EntityHeirarchyDaoImpl.class);
	private static final String CLASS_NAME = EntityHeirarchyDaoImpl.class.getName();

	@SuppressWarnings("unchecked")
	@Override
	public List<EntityHierarchy> getEntityNames(String groupId) {
		if (logger.isInfoEnabled())
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " getEntityNames()");
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("groupID", Long.parseLong(groupId)));
		List<EntityHierarchy> entities = null;
		try {
			entities = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getEntityNames()" + e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD + " getEntityNames()");
		return entities;
	}

	@Override
	public ResultPage<EntityHierarchy> fetchHierarchyListPagination(CommonSearchDto searchDto) {

		logger.info("Entered fetchHierarchyList");
		List<EntityHierarchy> entityHierarchyList = null;
		ResultPage<EntityHierarchy> result = new ResultPage<EntityHierarchy>();
		int pagenum = Integer.parseInt(searchDto.getPageNum()) - 1;
		int recordnum = Integer.parseInt(searchDto.getRownumInPerPage());
		String tag = searchDto.getSearchText();
		String orderBy = searchDto.getOrderBy();
		if (orderBy == null || orderBy.trim().length() <= 0) {
			orderBy = "entityName";
		}
		try {
			Criteria criteria = hibernateDao.createNormalCriteria(EntityHierarchy.class);
			criteria.setFirstResult((pagenum * recordnum));
			criteria.setMaxResults(recordnum);
			if (tag != null && tag.trim().length() > 0) {
				String tagtemp = tag.trim() + "%";
				criteria = getCriteria(criteria, tagtemp);
			}
			criteria.addOrder(Order.asc(orderBy)).addOrder(Order.asc("hierarchyId"));
			entityHierarchyList = criteria.list();

			criteria = hibernateDao.createNormalCriteria(EntityHierarchy.class);
			if (tag != null && tag.trim().length() > 0) {
				String tagtemp = tag.trim() + "%";
				criteria = getCriteria(criteria, tagtemp);
			}
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			criteria.setProjection(Projections.rowCount());
			Long resultCount = (Long) criteria.uniqueResult();

			result.setResultList(entityHierarchyList);
			result.setRecordsNum(recordnum);
			result.setPageNum(pagenum);
			result.setTotalRecords(resultCount);

		} catch (Exception e) {
			logger.error("Exception in fetchHierarchyList" + e);
		}

		return result;
	}

	private Criteria getCriteria(Criteria criteria, String tag) {
		criteria.add(Restrictions.disjunction().add(Restrictions.ilike("entityName", tag, MatchMode.ANYWHERE))
				.add(Restrictions.ilike("subDivName", tag, MatchMode.ANYWHERE))
				.add(Restrictions.ilike("circleName", tag, MatchMode.ANYWHERE))
				.add(Restrictions.ilike("gSTIN", tag, MatchMode.ANYWHERE))
				.add(Restrictions.ilike("profitCenterName", tag, MatchMode.ANYWHERE))
				.add(Restrictions.ilike("businessUnitName", tag, MatchMode.ANYWHERE))
				.add(Restrictions.ilike("plantCode", tag, MatchMode.ANYWHERE)));
		return criteria;
	}

	@Override
	public Boolean checkIfDuplicateEntryExists(EntityHierarchy entityHierarchyDTO) {
		Boolean alreadyExists = false;
		List<EntityHierarchy> entities = null;
		String entityName = entityHierarchyDTO.getEntityName();
		if (entityHierarchyDTO.getEntityName() == null) {
			entityName = hibernateDao.load(EntityModel.class, entityHierarchyDTO.getEntityID()).getEntityName();
		}
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eqOrIsNull("circleName", entityHierarchyDTO.getCircleName()));
		detachedCriteria.add(Restrictions.eq("entityName", entityName));
		detachedCriteria.add(Restrictions.eq("gSTIN", entityHierarchyDTO.getgSTIN()));
		detachedCriteria.add(Restrictions.eqOrIsNull("subDivName", entityHierarchyDTO.getSubDivName()));
		detachedCriteria.add(Restrictions.eqOrIsNull("profitCenterName", entityHierarchyDTO.getProfitCenterName()));
		detachedCriteria.add(Restrictions.eqOrIsNull("businessUnitName", entityHierarchyDTO.getBusinessUnitName()));
		detachedCriteria.add(Restrictions.eqOrIsNull("plantCode", entityHierarchyDTO.getPlantCode()));
		try {
			entities = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		} catch (Exception e) {
			entities = null;
			logger.info(
					Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " checkIfDuplicateEntryExists()" + e);
		}
		if (entities != null && entities.size() > 0) {
			alreadyExists = true;
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD + " checkIfDuplicateEntryExists()");
		return alreadyExists;
	}

	@Override
	public List fetchGstinList(String entityId) {
		List<String> gstinList = null;
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
			detachedCriteria.add(Restrictions.eq("entityID", Integer.parseInt(entityId)));
			detachedCriteria.setProjection(Projections.projectionList().add(Projections.property("gSTIN")));
			gstinList = (List<String>) hibernateDao.find(detachedCriteria);
			if (gstinList != null && !gstinList.isEmpty()) {
				return gstinList;
			}
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " fetchGstinList()" + e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD + " fetchGstinList()");

		return gstinList;
	}

	@Override
	public List<EntityHierarchy> fetchByGSTIN(String gstin) {
		List<EntityHierarchy> entityHierarchyList = null;
		try {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("gSTIN", gstin));
		entityHierarchyList = (List<EntityHierarchy>)hibernateDao.find(detachedCriteria);
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " fetchByGSTIN()" + e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD + " fetchByGSTIN()");
		
		return entityHierarchyList;
	}


	public List<EntityHierarchy> fetchUserHierarchy(String accessLevel, String property, Object Value) {

		List<EntityHierarchy> result = new ArrayList<EntityHierarchy>();
		if (Value != null) {
			String str = (String) Value;
			int i = str.indexOf("->");
			if (i > 0) {
				DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
				detachedCriteria = getRestrictions(accessLevel, property, str, detachedCriteria);
				result = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);

			} else {
				result = fetchUserHierarchy(property, Value);
			}
		}

		return result;
	}

	public List<EntityHierarchy> fetchUserHierarchy(String property, Object Value) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq(property, Value));
		List<EntityHierarchy> response = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		return response;
	}
	
	
	

	
	
	private DetachedCriteria getRestrictions(String accessLevel, String property, String Value,
			DetachedCriteria detachedCriteria) {

		String[] values = Value.split("->");
		
		switch (accessLevel) {

		case "L5":
			if (values.length > 7 && !values[7].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("plantCode", values[7].trim()));
			}
		case "L4C":
			if (values.length > 6 && !values[6].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("businessUnitCode", values[6].trim()));
			}else if (values.length > 6 && values[6].trim().equalsIgnoreCase("null")){
				detachedCriteria.add(Restrictions.isNull("businessUnitCode"));
			}
		case "L4B":
			if (values.length > 5 && !values[5].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("profitCenterCode", values[5].trim()));
			}else if (values.length > 5 && values[5].trim().equalsIgnoreCase("null")){
				detachedCriteria.add(Restrictions.isNull("profitCenterCode"));
			}
		case "L4A":
			if (values.length > 4 && !values[4].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("subDivCode", values[4].trim()));
			}else if (values.length > 4 && values[4].trim().equalsIgnoreCase("null")){
				detachedCriteria.add(Restrictions.isNull("subDivCode"));
			}
		case "L3B":
			if (values.length > 3 && !values[3].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("gSTIN", values[3].trim()));
			}
		case "L3A":
			if (values.length > 2 && !values[2].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("circleCode", values[2].trim()));
			}else if (values.length > 2 && values[2].trim().equalsIgnoreCase("null")){
				detachedCriteria.add(Restrictions.isNull("circleCode"));
			}
		case "L2":
			if (values.length > 1 && !values[1].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("entityCode", values[1].trim()));
				detachedCriteria.add(Restrictions.eq("groupCode", values[0].trim()));
			}
			break;

		default:
			logger.error("Invalid access level " + accessLevel);
			break;

		}

		return detachedCriteria;
	}

	@Override
	public List<EntityHierarchy> fetchEntityHierarchyList(String entityCode) throws Exception {
		List<EntityHierarchy> hierarchyList = null;
		try {
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
			detachedCriteria.add(Restrictions.eq("entityCode", entityCode));
			hierarchyList = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
			if (hierarchyList != null && !hierarchyList.isEmpty()) {
				return hierarchyList;
			}
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " fetchEntityHierarchyList()" + e);
			throw new Exception(e);
		}
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD + " fetchEntityHierarchyList()");

		return hierarchyList;
	}

	@Override
	public ResultPage<EntityHierarchy> fetchByHierarchyIdList(Map<Integer,String> hierarchyMap,
			CommonSearchDto searchDto) throws Exception {
		List<EntityHierarchy> hierarchyList =new ArrayList<>();
		ResultPage<EntityHierarchy> result = new ResultPage<EntityHierarchy>();
		int pagenum = Integer.parseInt(searchDto.getPageNum()) - 1;
		int recordnum = Integer.parseInt(searchDto.getRownumInPerPage());
		List<Integer> hierarchyIdList = new ArrayList<Integer>(hierarchyMap.keySet());
		if(hierarchyIdList!=null && hierarchyIdList.size()>0){
			try {
				DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
				detachedCriteria.add(Restrictions.in("hierarchyId", hierarchyIdList));
				hierarchyList = (List<EntityHierarchy>) hibernateDao.findByCriteria(detachedCriteria, (pagenum*recordnum), recordnum);
			} catch (Exception e) {
				logger.info(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " fetchByHierarchyIdList()" + e);
				hierarchyList =new ArrayList<>();
				throw new Exception(e);
			}
		}
		result.setRecordsNum(recordnum);
		result.setPageNum(pagenum);
		
		for(EntityHierarchy hierarchy: hierarchyList){
			hierarchy.setAccessLevel(hierarchyMap.get(hierarchy.getHierarchyId()));
		}
		
		result.setResultList(hierarchyList);
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD + " fetchByHierarchyIdList()");
		return result;
	}
	
	@Override
	public List<EntityHierarchy> fetchValues(String txt, String values){
		
		List<EntityHierarchy> ehList = new ArrayList<EntityHierarchy>();
		
		if(txt != null && values != null){
			
			String[] str = values.split("#");
			
			if(txt.equalsIgnoreCase("entity")){
				
				ehList = fetchRegionList(str[0]);
				
			}else if(txt.equalsIgnoreCase("region")){
				
				ehList = fetchGstinList(str[0],str[1]);
				
			}else if(txt.equalsIgnoreCase("gstin")){
				
				ehList = fetchSubDivList(str[0],str[1],str[2]);
				
			}else if(txt.equalsIgnoreCase("subDiv")){
				
				ehList = fetchPCList(str[0],str[1],str[2],str[3]);
				
			}else if(txt.equalsIgnoreCase("pc")){
				
				ehList = fetchBUList(str[0],str[1],str[2],str[3],str[4]);
				
            }else if(txt.equalsIgnoreCase("bu")){
				
            	ehList = fetchPlantCodeList(str[0],str[1],str[2],str[3],str[4],str[5]);
            }
		}
		
		return ehList;
		
	}
	
	public List<EntityHierarchy> fetchRegionList(String entityCode) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("entityCode", entityCode));		
		detachedCriteria.setProjection(Projections.projectionList()
			      .add(Projections.property("circleCode"), "circleCode")
			      .add(Projections.property("circleName"), "circleName"));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(EntityHierarchy.class));
		
		List<EntityHierarchy> response = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		return response;
	}
	
	public List<EntityHierarchy> fetchGstinList(String entityCode,String circleCode) {
		
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("entityCode", entityCode));
		if( circleCode != null && (!circleCode.equalsIgnoreCase("null"))){
			
			detachedCriteria.add(Restrictions.eq("circleCode", circleCode));
		}else{

			detachedCriteria.add(Restrictions.isNull("circleCode"));
		}
		
		detachedCriteria.setProjection(Projections.projectionList()
			      .add(Projections.property("gSTIN"), "gSTIN"));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(EntityHierarchy.class));
		
		List<EntityHierarchy> response = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		return response;
	}
	
	public List<EntityHierarchy> fetchSubDivList(String entityCode,String circleCode,String gstin) {
		
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("entityCode", entityCode));		
		detachedCriteria.add(Restrictions.eq("gSTIN", gstin));	
		if(circleCode != null && (!circleCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("circleCode", circleCode));
			
		}else{
			detachedCriteria.add(Restrictions.isNull("circleCode"));
		}
		detachedCriteria.setProjection(Projections.projectionList()
			      .add(Projections.property("subDivCode"), "subDivCode")
			      .add(Projections.property("subDivName"), "subDivName"));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(EntityHierarchy.class));
		
		List<EntityHierarchy> response = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		return response;
	}
	
   public List<EntityHierarchy> fetchPCList(String entityCode,String circleCode,String gstin,String subDivCode) {
		
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("entityCode", entityCode));		
		detachedCriteria.add(Restrictions.eq("gSTIN", gstin));	
		if(circleCode != null && (!circleCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("circleCode", circleCode));
		}else{
			detachedCriteria.add(Restrictions.isNull("circleCode"));
		}
		if(subDivCode != null && (!subDivCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("subDivCode", subDivCode));
		}else{
			detachedCriteria.add(Restrictions.isNull("subDivCode"));
		}
		detachedCriteria.setProjection(Projections.projectionList()
			      .add(Projections.property("profitCenterCode"), "profitCenterCode")
			      .add(Projections.property("profitCenterName"), "profitCenterName"));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(EntityHierarchy.class));
		
		List<EntityHierarchy> response = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		return response;
	}
   
   public List<EntityHierarchy> fetchBUList(String entityCode,String circleCode,String gstin,String subDivCode,String profitCenterCode) {
		
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("entityCode", entityCode));		
		detachedCriteria.add(Restrictions.eq("gSTIN", gstin));	
		if(circleCode != null && (!circleCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("circleCode", circleCode));
		}else{
			detachedCriteria.add(Restrictions.isNull("circleCode"));
		}
		if(subDivCode != null && (!subDivCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("subDivCode", subDivCode));
		}else{
			detachedCriteria.add(Restrictions.isNull("subDivCode"));
		}
		if(profitCenterCode != null && (!profitCenterCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("profitCenterCode", profitCenterCode));
		}else{
			detachedCriteria.add(Restrictions.isNull("profitCenterCode"));
		}
		detachedCriteria.setProjection(Projections.projectionList()
			      .add(Projections.property("businessUnitCode"), "businessUnitCode")
			      .add(Projections.property("businessUnitName"), "businessUnitName"));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(EntityHierarchy.class));
		
		List<EntityHierarchy> response = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		return response;
	}
   
   public List<EntityHierarchy> fetchPlantCodeList(String entityCode,String circleCode,String gstin,String subDivCode,String profitCenterCode, String businessUnitCode) {
		
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("entityCode", entityCode));		
		detachedCriteria.add(Restrictions.eq("gSTIN", gstin));	
		if(circleCode != null && (!circleCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("circleCode", circleCode));
		}else{
			detachedCriteria.add(Restrictions.isNull("circleCode"));
		}
		if(subDivCode != null && (!subDivCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("subDivCode", subDivCode));
		}else{
			detachedCriteria.add(Restrictions.isNull("subDivCode"));
		}
		if(profitCenterCode != null && (!profitCenterCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("profitCenterCode", profitCenterCode));
		}else{
			detachedCriteria.add(Restrictions.isNull("profitCenterCode"));
		}
		if(businessUnitCode != null && (!businessUnitCode.equalsIgnoreCase("null"))){

			detachedCriteria.add(Restrictions.eq("businessUnitCode", businessUnitCode));
		}else{
			detachedCriteria.add(Restrictions.isNull("businessUnitCode"));
		}
		detachedCriteria.setProjection(Projections.projectionList()
			      .add(Projections.property("plantCode"), "plantCode"));
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(EntityHierarchy.class));
		
		List<EntityHierarchy> response = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		return response;
	}
   
   public List<EntityHierarchy> fetchUserHierarchyUserTab(Integer accessLevelId, String accessLevel, String property, Object Value) {

		List<EntityHierarchy> result = new ArrayList<EntityHierarchy>();
		List<EntityHierarchy> resultOut = new ArrayList<EntityHierarchy>();
		if (Value != null) {
			
			if(accessLevel.equalsIgnoreCase("L1")){
				
				DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
				detachedCriteria.add(Restrictions.eq("groupCode", Value.toString()));		
				detachedCriteria.setProjection(Projections.projectionList()
					      .add(Projections.distinct(Projections.projectionList().add(Projections.property("groupCode"), "groupCode")))
					      .add(Projections.property("groupName"), "groupName")
					      .add(Projections.property("groupID"), "groupID"));
					      
				
				detachedCriteria.setResultTransformer(Transformers.aliasToBean(EntityHierarchy.class));
				result = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
				
			}else{
			
					String str = (String) Value;
					int i = str.indexOf("->");
					if (i > 0) {
						DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
						detachedCriteria = getRestrictionsUserTab(accessLevel, property, str, detachedCriteria);
						result = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		
					} else {
						result = fetchUserHierarchyUserTab(property, Value);
					}
			}
		}
		
		for(int i =0;i<result.size();i++){
			EntityHierarchy eh = result.get(i);
			eh.setAccessLevel(accessLevel);
			eh.setAccessLevelId(accessLevelId);
			resultOut.add(eh);
		}

		return resultOut;
	}
   
	public List<EntityHierarchy> fetchUserHierarchyUserTab(String property, Object Value) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria = getRestrictionsUserTab_1(property,Value.toString(),detachedCriteria);
		List<EntityHierarchy> response = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		return response;
	}
	
	public DetachedCriteria getRestrictionsUserTab_1(String property, String Value,
			DetachedCriteria detachedCriteria){
		
        ProjectionList prjList = Projections.projectionList();
        
		switch (property) {

		case "plantCode":
			
				detachedCriteria.add(Restrictions.eq("plantCode", Value));
			    prjList.add(Projections.property("plantCode"), "plantCode");
			
		case "businessUnitCode":
			
            if(property.equalsIgnoreCase("businessUnitCode")){
            	detachedCriteria.add(Restrictions.eq("businessUnitCode", Value));
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("businessUnitCode"), "businessUnitCode")));
				
			}else{
			    prjList.add(Projections.property("businessUnitCode"), "businessUnitCode");
			}
       
            prjList.add(Projections.property("businessUnitName"), "businessUnitName");
			
		case "profitCenterCode":
			
            if(property.equalsIgnoreCase("profitCenterCode")){
            	detachedCriteria.add(Restrictions.eq("profitCenterCode", Value));
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("profitCenterCode"), "profitCenterCode")));
			}else{
			   prjList.add(Projections.property("profitCenterCode"), "profitCenterCode");
			}
            
            prjList.add(Projections.property("profitCenterName"), "profitCenterName");
            
		case "subDivCode":
			
            if(property.equalsIgnoreCase("subDivCode")){
            	detachedCriteria.add(Restrictions.eq("subDivCode", Value));
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("subDivCode"), "subDivCode")));
				
			}else{
			     prjList.add(Projections.property("subDivCode"), "subDivCode");
			}
            prjList.add(Projections.property("subDivName"), "subDivName");
            
		case "gSTIN":
			
            if(property.equalsIgnoreCase("gSTIN")){
            	detachedCriteria.add(Restrictions.eq("gSTIN", Value));
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("gSTIN"), "gSTIN")));
				
			}else{
			    prjList.add(Projections.property("gSTIN"), "gSTIN");
			}
            
		case "circleCode":
			
            if(property.equalsIgnoreCase("circleCode")){
            	detachedCriteria.add(Restrictions.eq("circleCode", Value));
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("circleCode"), "circleCode")));
				
			}else{
		    	prjList.add(Projections.property("circleCode"), "circleCode");
			}
            prjList.add(Projections.property("circleName"), "circleName");
            
            
		case "entityCode":
			
			if(property.equalsIgnoreCase("entityCode")){
				detachedCriteria.add(Restrictions.eq("entityCode", Value));
				prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("entityCode"), "entityCode")));
				
			}else{
				prjList.add(Projections.property("entityCode"), "entityCode");
			}
			prjList.add(Projections.property("entityID"), "entityID");
			prjList.add(Projections.property("entityName"), "entityName");
			
		case "groupCode":
			
			if(property.equalsIgnoreCase("groupCode")){
				detachedCriteria.add(Restrictions.eq("groupCode", Value));
				prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("groupCode"), "groupCode")));
				
			}else{
				prjList.add(Projections.property("groupCode"), "groupCode");
			}

			prjList.add(Projections.property("groupID"), "groupID");
			prjList.add(Projections.property("groupName"), "groupName");
			
			break;

		default:
			logger.error("Invalid property level " + property);
			break;

		}
		detachedCriteria.setProjection(prjList);
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(EntityHierarchy.class));

		return detachedCriteria;
		
	}
	
	public DetachedCriteria getRestrictionsUserTab(String accessLevel, String property, String Value,
			DetachedCriteria detachedCriteria){
		
        String[] values = Value.split("->");
        ProjectionList prjList = Projections.projectionList();
		switch (accessLevel) {

		case "L5":
			if (values.length > 7 && !values[7].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("plantCode", values[7].trim()));
				
			}
			
			prjList.add(Projections.property("plantCode"), "plantCode");
			
			
		case "L4C":
			if (values.length > 6 && !values[6].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("businessUnitCode", values[6].trim()));
			}else if (values.length > 6 && values[6].trim().equalsIgnoreCase("null")){
				detachedCriteria.add(Restrictions.isNull("businessUnitCode"));
			}
			
            if(accessLevel.equalsIgnoreCase("L4C")){
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("businessUnitCode"), "businessUnitCode")));
				
			}else{
			    prjList.add(Projections.property("businessUnitCode"), "businessUnitCode");
			}
            prjList.add(Projections.property("businessUnitName"), "businessUnitName");
			
		case "L4B":
			if (values.length > 5 && !values[5].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("profitCenterCode", values[5].trim()));
			}else if (values.length > 5 && values[5].trim().equalsIgnoreCase("null")){
				detachedCriteria.add(Restrictions.isNull("profitCenterCode"));
			}
            if(accessLevel.equalsIgnoreCase("L4B")){
				
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("profitCenterCode"), "profitCenterCode")));
			}else{
			   prjList.add(Projections.property("profitCenterCode"), "profitCenterCode");
			}
            
            prjList.add(Projections.property("profitCenterName"), "profitCenterName");
            
		case "L4A":
			if (values.length > 4 && !values[4].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("subDivCode", values[4].trim()));
			}else if (values.length > 4 && values[4].trim().equalsIgnoreCase("null")){
				detachedCriteria.add(Restrictions.isNull("subDivCode"));
			}
            if(accessLevel.equalsIgnoreCase("L4A")){
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("subDivCode"), "subDivCode")));
				
			}else{
			     prjList.add(Projections.property("subDivCode"), "subDivCode");
			}
            prjList.add(Projections.property("subDivName"), "subDivName");
		case "L3B":
			if (values.length > 3 && !values[3].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("gSTIN", values[3].trim()));
			}
            if(accessLevel.equalsIgnoreCase("L3B")){
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("gSTIN"), "gSTIN")));
				
			}else{
			    prjList.add(Projections.property("gSTIN"), "gSTIN");
			}
		case "L3A":
			if (values.length > 2 && !values[2].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("circleCode", values[2].trim()));
			}else if (values.length > 2 && values[2].trim().equalsIgnoreCase("null")){
				detachedCriteria.add(Restrictions.isNull("circleCode"));
			}
            if(accessLevel.equalsIgnoreCase("L3A")){
            	prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("circleCode"), "circleCode")));
				
			}else{
		    	prjList.add(Projections.property("circleCode"), "circleCode");
			}
            prjList.add(Projections.property("circleName"), "circleName");
            
            
		case "L2":
			if (values.length > 1 && !values[1].trim().equalsIgnoreCase("null")) {
				detachedCriteria.add(Restrictions.eq("entityCode", values[1].trim()));
				detachedCriteria.add(Restrictions.eq("groupCode", values[0].trim()));
			}
			if(accessLevel.equalsIgnoreCase("L2")){
				prjList.add(Projections.distinct(Projections.projectionList().add(Projections.property("entityCode"), "entityCode")));
				
			}else{
				prjList.add(Projections.property("entityCode"), "entityCode");
			}
			prjList.add(Projections.property("entityID"), "entityID");
			prjList.add(Projections.property("entityName"), "entityName");
			prjList.add(Projections.property("groupID"), "groupID");
			prjList.add(Projections.property("groupCode"), "groupCode");
			prjList.add(Projections.property("groupName"), "groupName");
			break;

		default:
			logger.error("Invalid access level " + accessLevel);
			break;

		}
		detachedCriteria.setProjection(prjList);
		detachedCriteria.setResultTransformer(Transformers.aliasToBean(EntityHierarchy.class));
		return detachedCriteria;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EntityHierarchy> getGstinsByEntityId(String entityCode) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("entityCode", entityCode));
		List<EntityHierarchy> entities = null;
		try {
			entities = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return entities;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EntityHierarchy> getGstinsByGroupCode(String groupCode) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("groupCode", groupCode));
		List<EntityHierarchy> entities = null;
		try {
			entities = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return entities;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EntityHierarchy> getEntityHierarchyByEntityID(Integer entityID) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("entityID", entityID));
		List<EntityHierarchy> entities = null;
		try{
			entities = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		} catch(Exception e) {
			logger.error("Could Not Fetch Entities Based on Entity ID: " + entityID , e);
			throw new RuntimeException("Could not fetch entities based on entityId: " + entityID, e);
		}
		return entities;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EntityHierarchy> getEntityHierarchyByCircleCode(String circleCode) {
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(EntityHierarchy.class);
		detachedCriteria.add(Restrictions.eq("circleCode", circleCode));
		List<EntityHierarchy> entities = null;
		try{
			entities = (List<EntityHierarchy>) hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			logger.error("Could Not Fetch Entities Based on Circle Code: " + circleCode , e);
			throw new RuntimeException("Could not fetch entities based on circleCode: " + circleCode, e);			
		}
		return entities;
	}

}
