package com.ey.advisory.asp.client.service;

public interface GstinFinancialsDetailsService {
	
	public Double getTurnOverforEntity(String entityId);

}
