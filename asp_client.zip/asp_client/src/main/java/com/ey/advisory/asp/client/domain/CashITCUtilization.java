/**
 * 
 */
package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Uma.Chandranaik
 *
 */
@Entity
@Table(name="tblgstr3CashITCUtilization", schema="gstr3")
public class CashITCUtilization implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private Long cashItcUtilID;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "MasterID")
	private CashITCLedgerMaster masterId;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "AccountHeadID")
	private Gstr3AccountHead accHeadId;
	
	@Column(name="ITCIgstAmt")
	private BigDecimal ITCIgstAmt;
	
	@Column(name="ITCCgstAmt")
	private BigDecimal ITCCgstAmt;
	
	@Column(name="ITCSgstAmt")
	private BigDecimal ITCSgstAmt;
	
	@Column(name="ITCCessAmt")
	private BigDecimal ITCCessAmt;
	
	@Column(name="CashTaxPaid")
	private BigDecimal cashTaxPaid;
	
	@Column(name="CashIntrestPaid")
	private BigDecimal cashIntrestPaid;

	@Column(name="CashLateFeePaid")
	private BigDecimal CashLateFeePaid;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
	@Column(name="CreatedDate")
	private String createdDate;
	
	@Column(name="IsActive")
	private boolean isActive;


	public Long getCashItcUtilID() {
		return cashItcUtilID;
	}

	public void setCashItcUtilID(Long cashItcUtilID) {
		this.cashItcUtilID = cashItcUtilID;
	}



	public BigDecimal getITCIgstAmt() {
		return ITCIgstAmt;
	}

	public void setITCIgstAmt(BigDecimal iTCIgstAmt) {
		ITCIgstAmt = iTCIgstAmt;
	}

	public BigDecimal getITCCgstAmt() {
		return ITCCgstAmt;
	}

	public void setITCCgstAmt(BigDecimal iTCCgstAmt) {
		ITCCgstAmt = iTCCgstAmt;
	}



	public BigDecimal getITCCessAmt() {
		return ITCCessAmt;
	}

	public void setITCCessAmt(BigDecimal iTCCessAmt) {
		ITCCessAmt = iTCCessAmt;
	}

	public BigDecimal getCashTaxPaid() {
		return cashTaxPaid;
	}

	public void setCashTaxPaid(BigDecimal cashTaxPaid) {
		this.cashTaxPaid = cashTaxPaid;
	}

	public BigDecimal getCashIntrestPaid() {
		return cashIntrestPaid;
	}

	public void setCashIntrestPaid(BigDecimal cashIntrestPaid) {
		this.cashIntrestPaid = cashIntrestPaid;
	}

	public BigDecimal getCashLateFeePaid() {
		return CashLateFeePaid;
	}

	public void setCashLateFeePaid(BigDecimal cashLateFeePaid) {
		CashLateFeePaid = cashLateFeePaid;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public CashITCLedgerMaster getMasterId() {
		return masterId;
	}

	public void setMasterId(CashITCLedgerMaster masterId) {
		this.masterId = masterId;
	}

	public BigDecimal getITCSgstAmt() {
		return ITCSgstAmt;
	}

	public void setITCSgstAmt(BigDecimal iTCSgstAmt) {
		ITCSgstAmt = iTCSgstAmt;
	}

	public Gstr3AccountHead getAccHeadId() {
		return accHeadId;
	}

	public void setAccHeadId(Gstr3AccountHead accHeadId) {
		this.accHeadId = accHeadId;
	}


	
	
	
}
