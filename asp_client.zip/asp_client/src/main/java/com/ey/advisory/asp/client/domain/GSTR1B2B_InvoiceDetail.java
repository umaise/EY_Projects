package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the GSTR1B2B_InvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2BInvoiceDetails",schema="gstr1")
public class GSTR1B2B_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR1B2B_InvoiceDetail.class);

	@Id
	@Column(name="ID")
	private long GSTR1B2B_InvoiceDetails_ID;

	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="CustGSTIN")
	private String custGSTIN;

	@Column(name="Etin")
	private String etin;

	@Column(name="FileID")
	private long fileID;

	@Column(name="Gstin")
	private String gstin;

	@Column(name="InvDate")
	private Date inv_Date;

	@Column(name="InvNum")
	private String inv_Num;

	@Column(name="InvValue")
	private BigDecimal invValue;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="POS")
	private String pos;

	@Column(name="RevChrg")
	private String revChrg;

	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;

	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="InvoiceKey")
	private String invoiceKey;


	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	//bi-directional many-to-one association to GSTR1B2B_ItemDetail
	@OneToMany(mappedBy="gstr1b2bInvoiceDetail")
	private List<GSTR1B2B_ItemDetail> gstr1b2bItemDetails;
	

	public GSTR1B2B_InvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR1B2B_InvoiceDetail ");
			}
	}

	public long getGSTR1B2B_InvoiceDetails_ID() {
		return this.GSTR1B2B_InvoiceDetails_ID;
	}

	public void setGSTR1B2B_InvoiceDetails_ID(long GSTR1B2B_InvoiceDetails_ID) {
		this.GSTR1B2B_InvoiceDetails_ID = GSTR1B2B_InvoiceDetails_ID;
	}	

	
	public List<GSTR1B2B_ItemDetail> getGstr1b2bItemDetails() {
		return this.gstr1b2bItemDetails;
	}

	public void setGstr1b2bItemDetails(List<GSTR1B2B_ItemDetail> gstr1b2bItemDetails) {
		this.gstr1b2bItemDetails = gstr1b2bItemDetails;
	}

	public GSTR1B2B_ItemDetail addGstr1b2bItemDetail(GSTR1B2B_ItemDetail gstr1b2bItemDetail) {
		getGstr1b2bItemDetails().add(gstr1b2bItemDetail);
		gstr1b2bItemDetail.setGstr1b2bInvoiceDetail(this);

		return gstr1b2bItemDetail;
	}

	public GSTR1B2B_ItemDetail removeGstr1b2bItemDetail(GSTR1B2B_ItemDetail gstr1b2bItemDetail) {
		getGstr1b2bItemDetails().remove(gstr1b2bItemDetail);
		gstr1b2bItemDetail.setGstr1b2bInvoiceDetail(null);

		return gstr1b2bItemDetail;
	}	


	public String getChkSum() {
		return chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getCustGSTIN() {
		return custGSTIN;
	}

	public void setCustGSTIN(String custGSTIN) {
		this.custGSTIN = custGSTIN;
	}

	public String getEtin() {
		return etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	public long getFileID() {
		return fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Date getInvDate() {
		return inv_Date;
	}

	public void setInvDate(Date invDate) {
		this.inv_Date = invDate;
	}

	public String getInvNum() {
		return inv_Num;
	}

	public void setInvNum(String invNum) {
		this.inv_Num = invNum;
	}

	public BigDecimal getInvValue() {
		return invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public boolean isDelete() {
		return isDelete;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getRevChrg() {
		return revChrg;
	}

	public void setRevChrg(String revChrg) {
		this.revChrg = revChrg;
	}

	public BigDecimal getTaxablevalue() {
		return taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	
}