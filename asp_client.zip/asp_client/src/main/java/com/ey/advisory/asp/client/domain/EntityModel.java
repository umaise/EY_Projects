package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.google.gson.annotations.SerializedName;

/**
 * @author Nisha.Kumari
 *
 */
@Entity
@Table(name = "tblEntity", schema="master")
public class EntityModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EntityID", nullable=false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@SerializedName("EntityID")
	private Integer entityID;
	
	@Column(name="EntityName")
	@SerializedName("EntityName")
	private String entityName;
	
	@Column(name="IsActive")
	@SerializedName("IsActive")
	private Boolean isActive;
	
	@Column(name="PAN")
	@SerializedName("PAN")
	private String pan;
	
	@Column(name="GrossTurnover")
	@SerializedName("GrossTurnover")
	private BigDecimal grossTurnOver;
	
	@Column(name="GroupID")
	@SerializedName("GroupID")
	private Long groupId;
	
	@Column(name="CreatedBy")
	@SerializedName("CreatedBy")
	private String createdBy; 	
	
	@Column(name="CreatedDate")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@SerializedName("CreatedDate")
	private Date createdDate;
	
	@Column(name="UpdatedBy")
	@SerializedName("UpdatedBy")
	private String updatedBy; 	
	
	@Column(name="UpdatedDate")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@SerializedName("UpdatedDate")
	private Date updatedDate;
	
	@Column(name="EntityCode",insertable=false,updatable=false)
	@SerializedName("EntityCode")
	private String entityCode;
	
	@Column(name="EntityType")
	@SerializedName("EntityType")
	private String entityType;
	
	@Column(name="CompanyHQ")
	@SerializedName("CompanyHQ")
	private String companyHQ;

	
	/**
	 * @return the entityType
	 */
	public String getEntityType() {
		return entityType;
	}

	/**
	 * @return the companyHQ
	 */
	public String getCompanyHQ() {
		return companyHQ;
	}

	/**
	 * @param entityType the entityType to set
	 */
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	/**
	 * @param companyHQ the companyHQ to set
	 */
	public void setCompanyHQ(String companyHQ) {
		this.companyHQ = companyHQ;
	}

	public Integer getEntityID() {
		return entityID;
	}

	public void setEntityID(Integer entityID) {
		this.entityID = entityID;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public BigDecimal getGrossTurnOver() {
		return grossTurnOver;
	}

	public void setGrossTurnOver(BigDecimal grossTurnOver) {
		this.grossTurnOver = grossTurnOver;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getEntityCode() {
		return entityCode;
	}

	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}

	public EntityModel() {
		super();
		// TODO Auto-generated constructor stub
	}

}	
