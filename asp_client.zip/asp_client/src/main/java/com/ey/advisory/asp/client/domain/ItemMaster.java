package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "tblItemMaster", schema="master")
public class ItemMaster implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ItemID")
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private int itemId;

	@Column(name="RGSTIN")
	private String receiverGSTIN;
	
	@Column(name="ItemCode")
	private String itemCode;
	
	@Column(name="Description")
	private String desc;
	
	@Column(name="Category")
	private String category;
	
	@Column(name="HSNSAC")
	private String hsn;
	
	@Column(name="NonCreditable")
	private Character nonCreditable;
	
	@Column(name="ReverseCharge")
	private Character reverseChange;
	
	@Column(name="IsTDS")
	private Character tds;
	
	@Column(name="IsExempt")
	private Character exempt;
	
	@Column(name="NotificationNumber")
	private Integer circularNumber;
	
	@Column(name="NotificationDate")
	private Date circularDate;
	
	@Column(name="SerialNumber")
	private String serialNumber;
	
	@Column(name="IGSTRt")
	private Double igst;
	
	@Column(name="CGSTRt")
	private Double cgst;
	
	@Column(name="SGSTRt")
	private Double sgst;
	
	@Column(name="UTGSTRt")
	private Double utgst;
	
	@Column(name="CESSRt")
	private Double cess;
	
	@Column(name="CESSRtAdValerom")
	private Double cESSRtAdValerom;
	
	@Column(name="CESSRtAdValerom1")
	private Double cESSRtAdValerom1;
	
	@Column(name="ADD1")
	private String aDD1;
	
	@Column(name="ADD2")
	private String aDD2;
	
	@Column(name="ADD3")
	private String aDD3;
	
	@Column(name="ADD4")
	private String aDD4;
	
	@Column(name="ADD5")
	private String aDD5;
	
	
	public Double getcESSRtAdValerom() {
		return cESSRtAdValerom;
	}
	public void setcESSRtAdValerom(Double cESSRtAdValerom) {
		this.cESSRtAdValerom = cESSRtAdValerom;
	}
	public Double getCESSRtAdValerom1() {
		return cESSRtAdValerom1;
	}
	public void setCESSRtAdValerom1(Double cESSRtAdValerom1) {
		this.cESSRtAdValerom1 = cESSRtAdValerom1;
	}
	public String getaDD1() {
		return aDD1;
	}
	public void setaDD1(String aDD1) {
		this.aDD1 = aDD1;
	}
	public String getaDD2() {
		return aDD2;
	}
	public void setaDD2(String aDD2) {
		this.aDD2 = aDD2;
	}
	public String getaDD3() {
		return aDD3;
	}
	public void setaDD3(String aDD3) {
		this.aDD3 = aDD3;
	}
	public String getaDD4() {
		return aDD4;
	}
	public void setaDD4(String aDD4) {
		this.aDD4 = aDD4;
	}
	public String getaDD5() {
		return aDD5;
	}
	public void setaDD5(String aDD5) {
		this.aDD5 = aDD5;
	}

	
	
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	
	public String getReceiverGSTIN() {
		return receiverGSTIN;
	}
	public void setReceiverGSTIN(String receiverGSTIN) {
		this.receiverGSTIN = receiverGSTIN;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getHsn() {
		return hsn;
	}
	public void setHsn(String hsn) {
		this.hsn = hsn;
	}
	
	public Character getNonCreditable() {
        return nonCreditable;
    }
    public void setNonCreditable(Character nonCreditable) {
        this.nonCreditable = nonCreditable;
    }
    public Character getReverseChange() {
        return reverseChange;
    }
    public void setReverseChange(Character reverseChange) {
        this.reverseChange = reverseChange;
    }
    public Character getTds() {
        return tds;
    }
    public void setTds(Character tds) {
        this.tds = tds;
    }
    public Character getExempt() {
        return exempt;
    }
    public void setExempt(Character exempt) {
        this.exempt = exempt;
    }
    public Integer getCircularNumber() {
		return circularNumber;
	}
	public void setCircularNumber(Integer circularNumber) {
		this.circularNumber = circularNumber;
	}
	
	
	
	public Date getCircularDate() {
		return circularDate;
	}
	public void setCircularDate(Date circularDate) {
		this.circularDate = circularDate;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public Double getIgst() {
		return igst;
	}
	public void setIgst(Double igst) {
		this.igst = igst;
	}
	public Double getCgst() {
		return cgst;
	}
	public void setCgst(Double cgst) {
		this.cgst = cgst;
	}
	public Double getSgst() {
		return sgst;
	}
	public void setSgst(Double sgst) {
		this.sgst = sgst;
	}
	public Double getUtgst() {
		return utgst;
	}
	public void setUtgst(Double utgst) {
		this.utgst = utgst;
	}
	public Double getCess() {
		return cess;
	}
	public void setCess(Double cess) {
		this.cess = cess;
	}
	

}
