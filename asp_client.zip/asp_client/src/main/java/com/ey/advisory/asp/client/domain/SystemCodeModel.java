package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the tblSystemCodes database table.
 * 
 */
@Entity
@Table(name="tblSystemCodes", schema ="dbo")
public class SystemCodeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CodeId")
	private long codeId;

	@Column(name="Code")
	private String code;

	@Column(name="CodeKey")
	private String codeKey;

	@Column(name="CodeOrder")
	private int codeOrder;

	@Column(name="Description")
	private String description;

	public long getCodeId() {
		return this.codeId;
	}

	public void setCodeId(long codeId) {
		this.codeId = codeId;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCodeKey() {
		return this.codeKey;
	}

	public void setCodeKey(String codeKey) {
		this.codeKey = codeKey;
	}

	public int getCodeOrder() {
		return this.codeOrder;
	}

	public void setCodeOrder(int codeOrder) {
		this.codeOrder = codeOrder;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}