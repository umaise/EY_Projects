package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblCustomerMaster",schema="master")
public class CustomerMaster implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "CustomerID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long customerId;
	
	@Column(name = "SGSTIN")
	private String sgstin;
	
	@Column(name = "CGSTIN")
	private String cgstin;
	
	@Column(name = "CustCode")
	private String custCode;
	
	@Column(name = "CustName")
	private String custName;
	
	@Column(name = "CustAddress")
	private String custAddress;
	
	@Column(name = "CustCategory")
	private String custCategory;
	
	@Column(name = "CustLocationCode")
	private String custLocationCode;
	
	@Column(name = "CategoryOfService")
	private String categoryOfService;
	
	@Column(name = "HSNSAC")
	private String hsnsac;
	
	@Column(name = "POS")
	private String pos;
	
	@Column(name = "Info")
	private String info;
	
	@Column(name = "PrimaryContactName")
	private String primaryContactName;
	
	@Column(name = "PrimaryeMailID")
	private String primaryeMailId;
	
	@Column(name = "PrimaryMobNum")
	private String primaryMobNum;
	
	@Column(name = "SecondaryContactName")
	private String secondaryContactName;
	
	@Column(name = "SecondaryeMailID")
	private String secondaryeMailId;
	
	@Column(name = "SecondaryMobNum")
	private String secondaryMobNum;
	
	@Column(name = "IsExempt")
	private Character isExempt;
	
	@Column(name = "NotificationNum")
	private String notificationNum;
	
	@Column(name = "NotificationDate")
	private Date notificationDate;
	
	@Column(name = "SerialNum")
	private String serialNum;
	
	@Column(name = "IGSTRt")
	private BigDecimal igstrt;
	
	@Column(name = "CGSTRt")
	private BigDecimal cgstrt;
	
	@Column(name = "SGSTRt")
	private BigDecimal sgstrt;
	
	@Column(name = "CESSRt")
	private BigDecimal cessrt;
	
	@Column(name = "IsTDS")
	private Character isTds;

	@Column(name = "ADD1")    		  
	private String add1;
	
	@Column(name = "ADD2")
	private String add2;
	
	@Column(name = "ADD3")
	private String add3;
	
	@Column(name = "ADD4")
	private BigDecimal add4;
	
	@Column(name = "ADD5")
	private BigDecimal add5;

	
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getSgstin() {
		return sgstin;
	}
	public void setSgstin(String sgstin) {
		this.sgstin = sgstin;
	}
	public String getCgstin() {
		return cgstin;
	}
	public void setCgstin(String cgstin) {
		this.cgstin = cgstin;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public String getCustCategory() {
		return custCategory;
	}
	public void setCustCategory(String custCategory) {
		this.custCategory = custCategory;
	}
	public String getCustLocationCode() {
		return custLocationCode;
	}
	public void setCustLocationCode(String custLocationCode) {
		this.custLocationCode = custLocationCode;
	}
	public String getCategoryOfService() {
		return categoryOfService;
	}
	public void setCategoryOfService(String categoryOfService) {
		this.categoryOfService = categoryOfService;
	}
	public String getHsnsac() {
		return hsnsac;
	}
	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getPrimaryContactName() {
		return primaryContactName;
	}
	public void setPrimaryContactName(String primaryContactName) {
		this.primaryContactName = primaryContactName;
	}
	public String getPrimaryeMailId() {
		return primaryeMailId;
	}
	public void setPrimaryeMailId(String primaryeMailId) {
		this.primaryeMailId = primaryeMailId;
	}
	public String getPrimaryMobNum() {
		return primaryMobNum;
	}
	public void setPrimaryMobNum(String primaryMobNum) {
		this.primaryMobNum = primaryMobNum;
	}
	public String getSecondaryContactName() {
		return secondaryContactName;
	}
	public void setSecondaryContactName(String secondaryContactName) {
		this.secondaryContactName = secondaryContactName;
	}
	public String getSecondaryeMailId() {
		return secondaryeMailId;
	}
	public void setSecondaryeMailId(String secondaryeMailId) {
		this.secondaryeMailId = secondaryeMailId;
	}
	public String getSecondaryMobNum() {
		return secondaryMobNum;
	}
	public void setSecondaryMobNum(String secondaryMobNum) {
		this.secondaryMobNum = secondaryMobNum;
	}
	public Character getIsExempt() {
		return isExempt;
	}
	public void setIsExempt(Character isExempt) {
		this.isExempt = isExempt;
	}
	public String getNotificationNum() {
		return notificationNum;
	}
	public void setNotificationNum(String notificationNum) {
		this.notificationNum = notificationNum;
	}
	public Date getNotificationDate() {
		return notificationDate;
	}
	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}
	public String getSerialNum() {
		return serialNum;
	}
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}
	public BigDecimal getIgstrt() {
		return igstrt;
	}
	public void setIgstrt(BigDecimal igstrt) {
		this.igstrt = igstrt;
	}
	public BigDecimal getCgstrt() {
		return cgstrt;
	}
	public void setCgstrt(BigDecimal cgstrt) {
		this.cgstrt = cgstrt;
	}
	public BigDecimal getSgstrt() {
		return sgstrt;
	}
	public void setSgstrt(BigDecimal sgstrt) {
		this.sgstrt = sgstrt;
	}
	public BigDecimal getCessrt() {
		return cessrt;
	}
	public void setCessrt(BigDecimal cessrt) {
		this.cessrt = cessrt;
	}
	public String getAdd1() {
		return add1;
	}
	public void setAdd1(String add1) {
		this.add1 = add1;
	}
	public String getAdd2() {
		return add2;
	}
	public Character getIsTds() {
		return isTds;
	}
	public void setIsTds(Character isTds) {
		this.isTds = isTds;
	}
	public void setAdd2(String add2) {
		this.add2 = add2;
	}
	public String getAdd3() {
		return add3;
	}
	public void setAdd3(String add3) {
		this.add3 = add3;
	}
	public BigDecimal getAdd4() {
		return add4;
	}
	public void setAdd4(BigDecimal add4) {
		this.add4 = add4;
	}
	public BigDecimal getAdd5() {
		return add5;
	}
	public void setAdd5(BigDecimal add5) {
		this.add5 = add5;
	}
	@Override
	public String toString() {
		return "CustomerMaster [customerId=" + customerId + ", sgstin="
				+ sgstin + ", cgstin=" + cgstin + ", custCode=" + custCode
				+ ", custName=" + custName + ", custAddress=" + custAddress
				+ ", custCategory=" + custCategory + ", custLocationCode="
				+ custLocationCode + ", categoryOfService=" + categoryOfService
				+ ", hsnsac=" + hsnsac + ", pos=" + pos + ", info=" + info
				+ ", primaryContactName=" + primaryContactName
				+ ", primaryeMailId=" + primaryeMailId + ", primaryMobNum="
				+ primaryMobNum + ", secondaryContactName="
				+ secondaryContactName + ", secondaryeMailId="
				+ secondaryeMailId + ", secondaryMobNum=" + secondaryMobNum
				+ ", isExempt=" + isExempt + ", notificationNum="
				+ notificationNum + ", notificationDate=" + notificationDate
				+ ", serialNum=" + serialNum + ", igstrt=" + igstrt
				+ ", cgstrt=" + cgstrt + ", sgstrt=" + sgstrt + ", cessrt="
				+ cessrt + ", isTds=" + isTds + ", add1=" + add1 + ", add2="
				+ add2 + ", add3=" + add3 + ", add4=" + add4 + ", add5=" + add5
				+ "]";
	}

	
}
