package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;


/**
 * The persistent class for the tblB2BInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2BInvoiceDetails", schema=Constant.GSTR2_SCHEMA)
public class GSTR2B2B_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR2B2B_InvoiceDetail.class);

	@Id
	@Column(name="ID")
	private long id;

	@Column(name="SGSTIN")
	private String SGSTIN;
	
	@Column(name="Flag")
	private String flag;
	
	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="InvNum")
	private String invNum;
	
	@Column(name="InvDate")
	private Date invDate;

	@Column(name="InvValue")
	private BigDecimal invValue;
	
	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;
	
	@Column(name="POS")
	private String pos;
	
	@Column(name="RevChrg")
	private String revChrg;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="DbChkSum")
	private int dbChkSum;

	@Column(name="FileID")
	private long fileID;

	@Column(name="InvoiceKey")
	private String invoiceKey;
	
	@Column(name="SubCategory")
	private String subCategory;

	

	

	public GSTR2B2B_InvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR2B2B_InvoiceDetail ");
			}
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public int getDbChkSum() {
		return this.dbChkSum;
	}

	public void setDbChkSum(int dbChkSum) {
		this.dbChkSum = dbChkSum;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Date getInvDate() {
		return this.invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getInvNum() {
		return this.invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public BigDecimal getInvValue() {
		return this.invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public String getPos() {
		return this.pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getRevChrg() {
		return this.revChrg;
	}

	public void setRevChrg(String revChrg) {
		this.revChrg = revChrg;
	}

	public BigDecimal getTaxablevalue() {
		return this.taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getSGSTIN() {
		return SGSTIN;
	}

	public void setSGSTIN(String sGSTIN) {
		SGSTIN = sGSTIN;
	}

	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	
}