package com.ey.advisory.asp.client.dto;

import java.math.BigDecimal;

public class IntroffsetDto {
	
	private BigDecimal i_pdint;
	private BigDecimal c_pdint;
	private BigDecimal s_pdint;
	private BigDecimal cs_pdint;
	
	public BigDecimal getI_pdint() {
		return i_pdint;
	}
	public void setI_pdint(BigDecimal i_pdint) {
		this.i_pdint = i_pdint;
	}
	public BigDecimal getC_pdint() {
		return c_pdint;
	}
	public void setC_pdint(BigDecimal c_pdint) {
		this.c_pdint = c_pdint;
	}
	public BigDecimal getS_pdint() {
		return s_pdint;
	}
	public void setS_pdint(BigDecimal s_pdint) {
		this.s_pdint = s_pdint;
	}
	public BigDecimal getCs_pdint() {
		return cs_pdint;
	}
	public void setCs_pdint(BigDecimal cs_pdint) {
		this.cs_pdint = cs_pdint;
	}
	
	
	
}
