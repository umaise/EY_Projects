package com.ey.advisory.asp.client.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.TblBifurcationCodes;
import com.ey.advisory.asp.client.domain.TblDocandSupplyType;
import com.ey.advisory.asp.client.domain.TblErrorMaster;
import com.ey.advisory.asp.client.dto.ParentSalePurchaseDto;
import com.ey.advisory.asp.client.dto.SalePurchasedto;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import com.ey.advisory.asp.master.dto.ErrorMasterDto;

@Service
public class SalePurchaseServiceImpl implements SalePurchaseService {

	@Autowired
	HibernateDao hibernateDao;


	@Autowired (required = false)
	RedisTemplate redisTemplate;

	private static final Logger logger = Logger.getLogger(SalePurchaseServiceImpl.class);
	private static final String CLASS_NAME = SalePurchaseServiceImpl.class.getName();

	@Override
	public Map getSalePurchaseList(List<String> GSTIN,String sessionTaxPeriod, String flag,String Type) throws ParseException { 
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getSalePurchaseList()");
		}

		List<Object[]> listItem;
		SalePurchasedto salePurchasedto = new SalePurchasedto();
		List<String> finalList;
		List<String> parameterList = new ArrayList();
		List<SalePurchasedto> listDto = new ArrayList<>();
		StringBuilder gString= new StringBuilder();
		String taxPeriod=getTaxPeriod1(sessionTaxPeriod);
		parameterList.add("");
		parameterList.add(flag);
		parameterList.add(taxPeriod);
		SalePurchaseServiceImpl ob = new SalePurchaseServiceImpl();
		finalList=GSTIN;
		getDates(parameterList, salePurchasedto);

		for (int i = 0; i < finalList.size(); i++) {
			if (i == 0) {
				gString.append(finalList.get(i));
			} else {
				gString.append(","+finalList.get(i));
			}
		}
		String gSTINString= gString.toString();
		Map map = new LinkedHashMap<>();
		try {

			List<String> inputList = new ArrayList<>();
			inputList.add(gSTINString);
			inputList.add(sessionTaxPeriod);
			inputList.add(flag);

			if(logger.isInfoEnabled()){
				logger.info("Input Params: " + inputList.toString());
			}

			if(Type.equalsIgnoreCase(Constant.OUTWARD_TYPE)){
				if(logger.isInfoEnabled()){
					logger.info("Proc being called: " + Constant.PROC_USPOUTWARDSUPPLY);
				}
				listItem =(List<Object[]>) hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.PROC_USPOUTWARDSUPPLY, "3", inputList);
			}else{
				if(logger.isInfoEnabled()){
					logger.info("Proc being called: " + Constant.PROC_USPINWARDSUPPLY);		
				}
				listItem =(List<Object[]>) hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.PROC_USPINWARDSUPPLY, "3", inputList);
			}

			for(Object[] obj:listItem){
				SalePurchasedto dto = new SalePurchasedto();
				dto.setSupplyType(obj[0].toString());
				dto.setSupplyCategory(obj[1].toString());
				dto.setValue(ob.toDouble(obj[2]));
				dto.setValueIncludingTax(ob.toDouble(obj[3]));
				dto.setIGSTRate(ob.toDouble(obj[4]));
				dto.setIGSTAmount(ob.toDouble(obj[5]));
				dto.setCGSTRate(ob.toDouble(obj[6]));
				dto.setCGSTAmount(ob.toDouble(obj[7]));
				dto.setSGSTRate(ob.toDouble(obj[8]));
				dto.setSGSTAmount(ob.toDouble(obj[9]));
				dto.setCessRate(ob.toDouble(obj[10]));
				dto.setCessAmount(ob.toDouble(obj[11]));
				dto.setTranType(obj[12].toString());
				listDto.add(dto);
			}
			map = resultToMap(listDto);

			map.put("fromDate", salePurchasedto.getFromDate());
			map.put("toDate", salePurchasedto.getToDate());
			return map;

		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getSalePurchaseList()",e);
		}
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getSalePurchaseList()");
		}
		return map;
	}


	public  Double toDouble(Object o ){
		if(o!= null){
			return Double.valueOf(o.toString());
		}
		return 0.0;
	}

	public static Map resultToMap(List<SalePurchasedto> l){

		Map<String,List<ParentSalePurchaseDto>> m = new LinkedHashMap();
		List<ParentSalePurchaseDto> list = new ArrayList<>();
		/*List<SalePurchasedto> jWSublist = new ArrayList<>();*/
		List<SalePurchasedto> compSchemeSublist = new ArrayList<>();
		List<SalePurchasedto> strSublist = new ArrayList<>();
		List<SalePurchasedto> sezSublist = new ArrayList<>();
		List<SalePurchasedto> tpSublist = new ArrayList<>();
		List<SalePurchasedto> nilRateSublist = new ArrayList<>();
		List<SalePurchasedto> expImpSublist = new ArrayList<>();
		List<SalePurchasedto> extSublist = new ArrayList<>();
		List<SalePurchasedto> dxpSublist = new ArrayList<>();



		for(SalePurchasedto obj : l ){
			if(obj.getSupplyType().equals(Constant.DEEMED_EXPORTS)){
				dxpSublist.add(obj);	
			}else if(obj.getSupplyType().equals(Constant.STOCK_TRANSFER)){
				strSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.SEZ)){
				sezSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.EXPORTS) /*|| obj.getSupplyType().equals(Constant.EXPORT_WITHOUT_PAYMENT)*/ || obj.getSupplyType().equals(Constant.IMPORTS) ){
				expImpSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.THIRDPARTY_SALES_OR_PURCHASE)){
				tpSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.NIL)){
				nilRateSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.EXEMPT)){
				extSublist.add(obj);
			}else if(obj.getSupplyType().equals(Constant.COMPOSITION_SCHEME)){
				compSchemeSublist.add(obj);	
			}

		}

		ParentSalePurchaseDto obj1 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.THIRDPARTY_SALES_OR_PURCHASE,tpSublist);
		ParentSalePurchaseDto obj2 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.STOCK_TRANSFER,strSublist);
		ParentSalePurchaseDto obj3 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.SEZ,sezSublist);
		ParentSalePurchaseDto obj4 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.EXPORTS_OR_IMPORTS,expImpSublist);
		ParentSalePurchaseDto obj5 = new ParentSalePurchaseDto(Constant.TAXABLE,Constant.DEEMED_EXPORTS,dxpSublist);
		ParentSalePurchaseDto obj6 = new ParentSalePurchaseDto(Constant.NON_TAXABLE,Constant.NIL,nilRateSublist);
		ParentSalePurchaseDto obj7 = new ParentSalePurchaseDto(Constant.NON_TAXABLE,Constant.EXEMPT,extSublist);
		ParentSalePurchaseDto obj8 = new ParentSalePurchaseDto(Constant.NON_TAXABLE,Constant.COMPOSITION_SCHEME,compSchemeSublist);

		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.add(obj4);
		list.add(obj5);
		list.add(obj6);
		list.add(obj7);
		list.add(obj8);
		m.put("Supply", list);
		return m;

	}


	public String toString(List<String> Param){
		List<String> finalParamList = new ArrayList<>();
		String finalString="";
		for(String s:Param){
			String str = "'"+s+"'";
			finalParamList.add(str);
		}
		if(!finalParamList.isEmpty()){
			finalString = finalParamList.toString().substring(1, finalParamList.toString().length()-1);
		}

		return finalString;

	}


	@Override
	public List<SalePurchasedto> getSaleListForChart(List<String> parameterList) throws ParseException {
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getSaleListForChart()");
		}

		List<Object[]> listItem=null;

		SalePurchaseServiceImpl ob = new SalePurchaseServiceImpl();
		List<SalePurchasedto> salePurchasedTolist = new ArrayList<>();

		try {
			listItem =(List<Object[]>) hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.PROC_USPSALES_CHART, "3", parameterList);
			for(Object[] obj:listItem){
				SalePurchasedto dto = new SalePurchasedto();
				dto.setSupplyCategory(obj[0].toString());
				dto.setValue(ob.toDouble(obj[1]));
				dto.setIGSTAmount(ob.toDouble(obj[2]));
				dto.setCGSTAmount(ob.toDouble(obj[3]));
				dto.setSGSTAmount(ob.toDouble(obj[4]));
				dto.setTranType(obj[5].toString()); //TRANSTYPE
				salePurchasedTolist.add(dto);
			}
		} catch (Exception e) {
			salePurchasedTolist = new ArrayList<>();
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getSaleListForChart()",e);
		}
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getSaleListForChart()");
		}
		return salePurchasedTolist;
	}

	@Override
	public List<SalePurchasedto> getPurchaseListForChart(List<String> parameterList) throws ParseException {
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getPurchaseListForChart()");
		}
		List<Object[]> listItem=null;
		List<SalePurchasedto> salePurchasedTolist = new ArrayList<>();
		SalePurchaseServiceImpl ob = new SalePurchaseServiceImpl();
		try {
			listItem =(List<Object[]>) hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.PROC_USPPURCHASE_CHART, "3", parameterList);

			for(Object[] obj:listItem){
				SalePurchasedto dto = new SalePurchasedto();
				dto.setSupplyCategory(obj[0].toString());
				dto.setValue(ob.toDouble(obj[1]));
				dto.setIGSTAmount(ob.toDouble(obj[2]));
				dto.setCGSTAmount(ob.toDouble(obj[3]));
				dto.setSGSTAmount(ob.toDouble(obj[4]));
				salePurchasedTolist.add(dto);
			}
		} catch (Exception e) {
			salePurchasedTolist = new ArrayList<>();
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getPurchaseListForChart()",e);
		}
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getPurchaseListForChart()");
		}
		return salePurchasedTolist;
	}

	public void getDates(List<String> parameterList,SalePurchasedto salePurchasedto) throws ParseException{

		DateFormat yearFormat = new SimpleDateFormat("yyyy");
		DateFormat monthFormat = new SimpleDateFormat("MM");
		SimpleDateFormat sdf = new SimpleDateFormat("MMyyyy");
		String fromDate;
		String flag = parameterList.get(1);
		String taxPeriod = parameterList.get(2);
		if(("M").equals(flag)){
			fromDate=taxPeriod;
		}else{
			Date d = sdf.parse(taxPeriod);
			Integer month = Integer.valueOf(monthFormat.format(d));
			if(month<=3){
				fromDate="04"+String.valueOf(Integer.valueOf(yearFormat.format(d))-1);
			}else{
				fromDate="04"+String.valueOf(Integer.valueOf(yearFormat.format(d)));
			}
		}

		String fromMonth = Month.of(Integer.valueOf(fromDate.substring(0, 2))).name();
		String fromYear = fromDate.substring(2, 6);
		String toMonth = Month.of(Integer.valueOf(taxPeriod.substring(0, 2))).name();
		String toYear = taxPeriod.substring(2, 6);
		fromMonth =  fromMonth.substring(0, 1).toUpperCase() +fromMonth.substring(1).toLowerCase();
		toMonth =  toMonth.substring(0, 1).toUpperCase() +toMonth.substring(1).toLowerCase();
		salePurchasedto.setFromDate(fromMonth + " " + fromYear);
		salePurchasedto.setToDate(toMonth + " " + toYear);

	}

	public String getTaxPeriod(){
		String previousMonth;
		DateFormat todayDate = new SimpleDateFormat("dd");
		DateFormat year = new SimpleDateFormat("yyyy");
		DateFormat month = new SimpleDateFormat("MM");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		if(Integer.valueOf(todayDate.format(date))<=20){
			cal.add(Calendar.MONTH, -2);
			Date d = cal.getTime();
			previousMonth=month.format(d)+year.format(d);
		}else{
			cal.add(Calendar.MONTH, -1);
			Date d = cal.getTime();
			previousMonth=month.format(d)+year.format(d);
		}
		return previousMonth;
	}

	public String getTaxPeriod1(String SessionTaxPeriod) throws ParseException{
		String previousMonth;
		SimpleDateFormat sdf = new SimpleDateFormat("MMyyyy");
		DateFormat todayDate = new SimpleDateFormat("dd");
		DateFormat year = new SimpleDateFormat("yyyy");
		DateFormat month = new SimpleDateFormat("MM");

		Date sessionDate = sdf.parse(SessionTaxPeriod);
		Calendar cal = Calendar.getInstance();
		cal.setTime(sessionDate);
		Date date = new Date();
		if(Integer.valueOf(todayDate.format(date))<=20){
			cal.add(Calendar.MONTH, -1);
			Date d = cal.getTime();
			previousMonth=month.format(d)+year.format(d);
		}else{
			Date d = cal.getTime();
			previousMonth=month.format(d)+year.format(d);
		}
		return previousMonth;
	}

	public List<String> getEligibleGSTIN(List<String> GSTIN, String taxPeriod){
		List<String> listItem=new ArrayList<>();
		String GStinString ="";

		try{
			String strQuery="  select distinct [GstinId] from [master].[tblGstinReturnFilingStatus] "+
					"where gstinid in( ? ) and UPPER(returnType)= ? and TaxPeriod= ? ";
			if(GSTIN!=null && !GSTIN.isEmpty()){
				GStinString = GSTIN.toString().substring(1, GSTIN.toString().length()-1);
			}
			listItem = (List<String>) hibernateDao.executeNativeSql(strQuery,new Object[]{GStinString,"GSTR3",taxPeriod});

		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getEligibleGSTIN()",e);
		}
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getEligibleGSTIN()");
		}
		return listItem;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void loadDocTypeMetaData(String groupCode) {
		List<TblDocandSupplyType> list = hibernateDao
				.loadAll(TblDocandSupplyType.class);
		Map<String, TblDocandSupplyType> docTypeMap ;
		Map<String, TblDocandSupplyType> supplyTypeMap ;
		if (list != null && !list.isEmpty()) {
			docTypeMap = new HashMap<>();
			supplyTypeMap = new HashMap<>();
			for (TblDocandSupplyType tblDocandSupplyType : list) {
				if (tblDocandSupplyType.getTypeOfDoc().equalsIgnoreCase(
						Constant.DOC_TYPE)) {
					docTypeMap.put(tblDocandSupplyType.getTypeCode(),
							tblDocandSupplyType);
				} else if (tblDocandSupplyType.getTypeOfDoc().equalsIgnoreCase(
						Constant.SUPPLY_TYPE)) {
					supplyTypeMap.put(tblDocandSupplyType.getTypeCode(),
							tblDocandSupplyType);
				}
			}
			redisTemplate.opsForHash().put(groupCode + "_" + Constant.REDIS_CACHE,
					Constant.DOC_TYPE, docTypeMap);
			redisTemplate.opsForHash().put(groupCode + "_" + Constant.REDIS_CACHE,
					Constant.SUPPLY_TYPE, supplyTypeMap);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void loadBifurcationMetaData(String groupCode) {

		List<TblBifurcationCodes> list = (List<TblBifurcationCodes>)hibernateDao
				.loadAll(TblBifurcationCodes.class);

		Map<String, TblBifurcationCodes> tableTypeMap ;
		Map<String, TblBifurcationCodes> subCategoryMap ;
		if (list != null && !list.isEmpty()) {
			tableTypeMap = new HashMap<>();
			subCategoryMap = new HashMap<>();
			for (TblBifurcationCodes tblBifurcationCodes : list) {
				if (tblBifurcationCodes.getBifurcationLevel().equalsIgnoreCase(
						Constant.CATEGORY)) {
					tableTypeMap.put(tblBifurcationCodes.getReturnType().trim()+"_"+tblBifurcationCodes.getCode(),tblBifurcationCodes);
				} else if (tblBifurcationCodes.getBifurcationLevel().equalsIgnoreCase(
						Constant.SUB_CATEGORY)) {
					subCategoryMap.put(tblBifurcationCodes.getReturnType().trim()+"_"+tblBifurcationCodes.getCode(),tblBifurcationCodes);
				}
			}
			redisTemplate.opsForHash().put(groupCode + "_" + Constant.REDIS_CACHE,
					Constant.CATEGORY, tableTypeMap);
			redisTemplate.opsForHash().put(groupCode + "_" + Constant.REDIS_CACHE,
					Constant.SUB_CATEGORY, subCategoryMap);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public ErrorMasterDto refreshErrorCodeMapInRedis(String errorInfoCode) {

		ErrorMasterDto errorMasterDto = null;
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD+" refreshErrorCodeMapInRedis");
		try {
			DetachedCriteria criteria = hibernateDao.createCriteria(TblErrorMaster.class);
			criteria.add(Restrictions.eq("errorInfoCode", errorInfoCode));

			List<TblErrorMaster> errorRecord = (List<TblErrorMaster>) hibernateDao.find(criteria);

			if(errorRecord!=null && (!errorRecord.isEmpty())){
				TblErrorMaster record = errorRecord.get(0);
				errorMasterDto = new ErrorMasterDto();
				errorMasterDto.setErrorInfoCode(errorInfoCode);
				errorMasterDto.setErrorInfoDesc(record.getErrorInfoDesc());
			}
		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD + " refreshErrorCodeMapInRedis", e);
		}
		
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME + Constant.LOGGER_METHOD+" refreshErrorCodeMapInRedis");
		return errorMasterDto;
	}

}
