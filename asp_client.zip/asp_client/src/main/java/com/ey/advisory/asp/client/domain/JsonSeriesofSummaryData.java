package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblJsonSeriesofSummaryData", schema="metadata")
public class JsonSeriesofSummaryData implements Serializable {
	

	private static final long serialVersionUID = -6860563108070667392L;

	@Id
	@Column(name="JsonSeriesofSummaryDataID")
	private Integer jsonSeriesofSummaryDataID;
	
	@Column(name="MinValue")
	private Integer minValue;
	
	@Column(name="MaxValue")
	private Integer maxValue;
	
	@Column(name="SeriesID")
	private String seriesID;
	
	@Column(name="Descr")
	private Integer descr;
	
	@Column(name="CreatedDate")
	private Date createdDate;
	
	@Column(name="CreatedBy")
	private String createdBy;
	
	@Column(name="UpdatedDate")
	private Date updatedDate;
	
	@Column(name="UpdatedBy")
	private String updatedBy;

	/**
	 * @return the jsonSeriesofSummaryDataID
	 */
	public Integer getJsonSeriesofSummaryDataID() {
		return jsonSeriesofSummaryDataID;
	}

	/**
	 * @param jsonSeriesofSummaryDataID the jsonSeriesofSummaryDataID to set
	 */
	public void setJsonSeriesofSummaryDataID(Integer jsonSeriesofSummaryDataID) {
		this.jsonSeriesofSummaryDataID = jsonSeriesofSummaryDataID;
	}

	

	/**
	 * @return the seriesID
	 */
	public String getSeriesID() {
		return seriesID;
	}

	/**
	 * @param seriesID the seriesID to set
	 */
	public void setSeriesID(String seriesID) {
		this.seriesID = seriesID;
	}

	/**
	 * @return the descr
	 */
	public Integer getDescr() {
		return descr;
	}

	/**
	 * @param descr the descr to set
	 */
	public void setDescr(Integer descr) {
		this.descr = descr;
	}

	
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the minValue
	 */
	public Integer getMinValue() {
		return minValue;
	}

	/**
	 * @param minValue the minValue to set
	 */
	public void setMinValue(Integer minValue) {
		this.minValue = minValue;
	}

	/**
	 * @return the maxValue
	 */
	public Integer getMaxValue() {
		return maxValue;
	}

	/**
	 * @param maxValue the maxValue to set
	 */
	public void setMaxValue(Integer maxValue) {
		this.maxValue = maxValue;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	
}
