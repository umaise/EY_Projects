package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblFileUploadStatus;
import com.ey.advisory.asp.client.dto.FileSearchDTO;

public interface TblFileUploadStatusService {
	
	public List<TblFileUploadStatus> getFileUploadStatusDetails(String fileId);
	public List<TblFileUploadStatus> getUploadedFiles(FileSearchDTO searchDto);
	public String getLastUploadedDate();

}
