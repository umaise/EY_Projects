/**
 * 
 */
package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.dao.ReturnUploadDao;
import com.ey.advisory.asp.client.domain.DueDateMaster;
import com.ey.advisory.asp.client.domain.InvoiceKeyDetail;
import com.ey.advisory.asp.client.domain.ReturnUpload;
import com.ey.advisory.asp.client.domain.SummaryReturnUpload;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.dto.Gstr3Dto;
import com.ey.advisory.asp.client.dto.TechReconDTO;
import com.ey.advisory.asp.client.dto.TransactionIDPolling;
import com.ey.advisory.asp.client.service.gstr1.Gstr1Service;
import com.ey.advisory.asp.common.Constant;

/**
 * @author Sadhana.Holla
 *
 */
@Service
public class GSTINDetailsServiceImpl implements GSTINDetailsService{
	

	@Autowired
	Gstr1Service gstr1Service;
	
	@Autowired
	private HibernateDao hibernateDao; 
	
	@Autowired
	ReturnUploadDao returnUploadDao;
	
	@Autowired
	ReturnFilingDao returnFilingDao;
	
	@Autowired(required = false)
	private RedisTemplate<String, Object> redisTemplate;

	private static final Logger logger = Logger.getLogger(GSTINDetailsServiceImpl.class);
	private static final String CLASS_NAME = GSTINDetailsServiceImpl.class.getName();

	@Override
	public Map<String,TblGstinDetailsDomain> fetchGstinDetails(){
		Map<String,TblGstinDetailsDomain> gstinMap = null;
		
		List<TblGstinDetailsDomain> gstinDetails = (List<TblGstinDetailsDomain>) hibernateDao.loadAll(TblGstinDetailsDomain.class);
		
		if(gstinDetails !=null){
			gstinMap = new HashMap<>();
		for(TblGstinDetailsDomain gstin:gstinDetails){
			gstinMap.put(gstin.getGstinId(), gstin);
			
			
		}
		}
		return gstinMap;
	}
	@Override 
	public TblGstinDetailsDomain fetchGstinDetails(String gstinId){
		
		
		
		DetachedCriteria detachedCriteria =
				hibernateDao.createCriteria(TblGstinDetailsDomain.class);
		
		 detachedCriteria.add(Restrictions.eq("gstinId", gstinId));
		 
		 List<TblGstinDetailsDomain> gstinDetails = (List<TblGstinDetailsDomain>) hibernateDao.find(detachedCriteria);
		 TblGstinDetailsDomain gstinDomain = null;
		 if(gstinDetails!=null && !gstinDetails.isEmpty() ){
			 gstinDomain = gstinDetails.get(0);
		 }
		
		return gstinDomain;
		
		
	}
	@Override
	public List fetchGstinDetailsForUser(String userId){
		
		List<String> inputList = new ArrayList<>();
		inputList.add(userId);
		List resultList = new ArrayList();
		
		try {
			  resultList = hibernateDao.executeStoredProcedureReturnList(Constant.DBO_SCHEMA, Constant.PROC_USPGETGSTINID, "1", inputList);
		} catch (Exception e) {
			logger.error(e);
		}
		
		return resultList;
		
	}
	
	@Override
public List<DueDateMaster> fetchGstinReturnTypes(List<String> gstins){
		
		
		List<DueDateMaster> resultList = new ArrayList<>();
		
		try {
			 DetachedCriteria criteria = hibernateDao.createCriteria(DueDateMaster.class);
			 criteria.add(Restrictions.in("gstnId",gstins));
			 resultList = (List<DueDateMaster>)hibernateDao.find(criteria);
		} catch (Exception e) {
			logger.error(e);
		}
		
		return resultList;
		
	}

	@Override
	public String getLedgerDetails(Gstr3Dto gstr3dto) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getLedgerDetails()");
		}
		String ledgerdetails= "";
		List<String> inputList = new ArrayList<>();
		inputList.add(gstr3dto.getGstin());
		inputList.add(gstr3dto.getRtPeriod());
		if(logger.isInfoEnabled()){
		logger.info("Input Params: " + inputList.toString());
		}
		try {
			if(logger.isInfoEnabled()){
			logger.info("Proc being called: " + Constant.LEDGER_BALANCE_PROC_NAME);
			}
			ledgerdetails=hibernateDao.executeStoredProcedure(Constant.GSTR3_PROC_SCHEMA, Constant.LEDGER_BALANCE_PROC_NAME, "2", inputList);
		
		} catch (Exception e) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getLedgerDetails()",e);
		}
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getLedgerDetails()");
		}
		return ledgerdetails;
	}
	
	@Override
    public List<TblGstinDetailsDomain> fetchGstinDetails(List<String> gstinId){
		
		
		DetachedCriteria detachedCriteria =
				hibernateDao.createCriteria(TblGstinDetailsDomain.class);
		
		 detachedCriteria.add(Restrictions.in("gstinId", gstinId));
		 
		 List<TblGstinDetailsDomain> gstinDetails = (List<TblGstinDetailsDomain>) hibernateDao.find(detachedCriteria);
		 
		
	
		return gstinDetails;
		
		
	}
    
    @Override
   	public List<Object> getGstinUserName(String gstinId) {
   		List<Object> gstinUserName=null;
   	    try {
   			DetachedCriteria detachedCriteria = hibernateDao
   					.createCriteria(TblGstinDetailsDomain.class);
   			detachedCriteria.add(Restrictions.eq("gstinId", gstinId));
   			ProjectionList projList = Projections.projectionList();
   			projList.add(Projections.property("gSTNUserName"), "gSTNUserName");
   			projList.add(Projections.property("stateCode"), "stateCode");
   			projList.add(Projections.property("regMobileNumber"), "regMobileNumber");
   			detachedCriteria.setProjection(Projections.distinct(projList));
   			gstinUserName = (List<Object>) hibernateDao.find(detachedCriteria);		
   		} catch (Exception exec) {
   			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
   					+ " Method : getGstinUserName()" ,exec);
   		}
   	    return gstinUserName;
   	}
    // Transaction ID Polling starts 
    
    @Override
	public List<TransactionIDPolling> getTransactionIDPollingList(boolean isSummary) {
    	List<TransactionIDPolling> transactionIDPollingList = null;
    	try{
    		logger.info("Executing getTransactionIDPollingList of "+CLASS_NAME);
    	if(isSummary){
    		List<SummaryReturnUpload> summaryReturnUploads = returnUploadDao.getSummaryReturnUpload();
    		transactionIDPollingList = getTransactionIDPollingDetailsForSummary(summaryReturnUploads);	
    	}else{
    		List<ReturnUpload> returnUploadList = returnUploadDao.getReturnUpload();
    		transactionIDPollingList = getTransactionIDPollingDetails(returnUploadList);	
    	} 
    	}
    	catch(Exception e){
    		logger.error(Constant.LOGGER_ERROR + CLASS_NAME
   					+ " Method : getTransactionIDPollingList()" ,e);
    	}
			return transactionIDPollingList;	
    	
	}
    
    @Override
   	public List<TransactionIDPolling> getTransactionPollingSubmitList(boolean isSummary) {
       	List<TransactionIDPolling> transactionIDPollingList = null;
       	try{
       		logger.info("Going to pick submit Refids");
       	if(isSummary){
       		List<SummaryReturnUpload> summaryReturnUploads = returnUploadDao.getSummaryReturnUpload();
       		transactionIDPollingList = getTransactionIDPollingDetailsForSummary(summaryReturnUploads);	
       	}else{
       		List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatus = returnUploadDao.gettblGstinRetutnFilingStatus();
       		transactionIDPollingList = getTransactionPollingSubmitDetails(tblGstinRetutnFilingStatus);	
       	}
       	}
       	catch(Exception e){
       		logger.error("Exception getTransactionPollingSubmitList "+ CLASS_NAME +e);
       	}
   			return transactionIDPollingList;
   	}
    
   
	@SuppressWarnings("unchecked")
	private List<TransactionIDPolling> getTransactionIDPollingDetails( List<ReturnUpload> returnUploadList){
		logger.info("Executing getTransactionIDPollingDetails");
		List<TransactionIDPolling> transactionIDPollingList = new ArrayList<>();
		Set<Long> filingIdSet = new HashSet<>();
		HashMap<Long,ArrayList<String>> filingIdGstinTrx = new HashMap<>();
		try{
		returnUploadList.forEach(item -> {
			
			TransactionIDPolling transactionIDPolling = new TransactionIDPolling();
			transactionIDPolling.setFilingId(item.getTblGstnreStatus());
			//transactionIDPolling.setTrxId(item.getTrxId());
			transactionIDPolling.setLoadId(item.getLoadId());
			transactionIDPolling.setRefId(item.getRefId());
			transactionIDPolling.setReturnType(item.getReturnType());
		
			
		    List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatusList = null;
		    
		   if( !filingIdSet.contains(item.getTblGstnreStatus())){
			   ArrayList<String> list = new ArrayList<>();
			   DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			   detachedCriteria.add(Restrictions.eq(Constant.FILING_ID, item.getTblGstnreStatus()));
			   tblGstinRetutnFilingStatusList =  (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
			   filingIdSet.add(item.getTblGstnreStatus());
			   transactionIDPolling.setGstinId( tblGstinRetutnFilingStatusList.get(0).getId().getGstinId());
			   transactionIDPolling.setTaxPeriod( tblGstinRetutnFilingStatusList.get(0).getId().getTaxPeriod());
			   list.add(tblGstinRetutnFilingStatusList.get(0).getId().getGstinId());
			   list.add( tblGstinRetutnFilingStatusList.get(0).getId().getTaxPeriod());
			   filingIdGstinTrx.put(item.getTblGstnreStatus(), list);
			   transactionIDPollingList.add(transactionIDPolling);
		   }else{
			   ArrayList<String> gstinTrnx = filingIdGstinTrx.get(item.getTblGstnreStatus());
			   transactionIDPolling.setGstinId(gstinTrnx.get(0));
			   transactionIDPolling.setTaxPeriod(gstinTrnx.get(1));
			   transactionIDPollingList.add(transactionIDPolling);
		   }
		});
		}catch(Exception e){
			logger.error("Exception occured while setting values to transactionIDPollingDTO "+e);
		}
		return transactionIDPollingList;
	}

	
	
//submit call
	
	@SuppressWarnings("unchecked")
	private List<TransactionIDPolling> getTransactionPollingSubmitDetails( List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatusList){
		List<TransactionIDPolling> transactionIDPollingList = new ArrayList<>();
		Set<Long> filingIdSet = new HashSet<>();
		HashMap<Long,ArrayList<String>> filingIdGstinTrx = new HashMap<>();
		try{
		tblGstinRetutnFilingStatusList.forEach(item -> {
			logger.info("Executing getTransactionPollingSubmitDetails");
			TransactionIDPolling transactionIDPolling = new TransactionIDPolling();
			transactionIDPolling.setFilingId(item.getFilingId());
			//transactionIDPolling.setTrxId(item.getTrxId());
			//transactionIDPolling.setLoadId(item.getLoadId());
			transactionIDPolling.setRefId(item.getSubmitRefId());
			transactionIDPolling.setReturnType(item.getId().getReturnType());
			transactionIDPolling.setGstinId(item.getId().getGstinId() );
			transactionIDPolling.setTaxPeriod( item.getId().getTaxPeriod());
			transactionIDPollingList.add(transactionIDPolling);
			  
		});
		}catch(Exception e){
			logger.error("Exception while setting transactionIDPollingDTO for getstatus submit "+e);
		}
		return transactionIDPollingList;
	}	
	
	
	
	
	
	@SuppressWarnings("unchecked")
	private List<TransactionIDPolling> getTransactionIDPollingDetailsForSummary( List<SummaryReturnUpload> returnUploadList){
		List<TransactionIDPolling> transactionIDPollingList = new ArrayList<>();
		Set<Long> filingIdSet = new HashSet<>();
		HashMap<Long,ArrayList<String>> filingIdGstinTrx = new HashMap<>();
		returnUploadList.forEach(item -> {
			
			TransactionIDPolling transactionIDPolling = new TransactionIDPolling();
			transactionIDPolling.setFilingId(item.getTblGstnreStatus());
			transactionIDPolling.setTrxId(item.getTrxId());
			transactionIDPolling.setLoadId(item.getLoadId());
			transactionIDPolling.setRefId(item.getRefId());
			transactionIDPolling.setReturnType(item.getReturnType());
			
		    List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatusList = null;
		    
		   if( !filingIdSet.contains(item.getTblGstnreStatus())){
			   ArrayList<String> list = new ArrayList<>();
			   DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			   detachedCriteria.add(Restrictions.eq(Constant.FILING_ID, item.getTblGstnreStatus()));
			   tblGstinRetutnFilingStatusList =  (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
			   filingIdSet.add(item.getTblGstnreStatus());
			   transactionIDPolling.setGstinId( tblGstinRetutnFilingStatusList.get(0).getId().getGstinId());
			   transactionIDPolling.setTaxPeriod( tblGstinRetutnFilingStatusList.get(0).getId().getTaxPeriod());
			   list.add(tblGstinRetutnFilingStatusList.get(0).getId().getGstinId());
			   list.add( tblGstinRetutnFilingStatusList.get(0).getId().getTaxPeriod());
			   filingIdGstinTrx.put(item.getTblGstnreStatus(), list);
			   transactionIDPollingList.add(transactionIDPolling);
		   }else{
			   ArrayList<String> gstinTrnx = filingIdGstinTrx.get(item.getTblGstnreStatus());
			   transactionIDPolling.setGstinId(gstinTrnx.get(0));
			   transactionIDPolling.setTaxPeriod(gstinTrnx.get(1));
			   transactionIDPollingList.add(transactionIDPolling);
		   }
		});
		return transactionIDPollingList;
	}

	@Override
	public void updateGstnStatusToReturnUpload(Long filingId, String trxId, String refId, Long loadId, String status, String errorMsg,String gstin,String gstnStatus,String errorDesc, boolean isSummary) {
		try{
			logger.info("Executing updateGstnStatusToReturnUpload "+CLASS_NAME);
		if(isSummary){
			SummaryReturnUpload summaryReturnUpload = returnUploadDao.getSummaryReturnUpload(filingId, trxId, refId, loadId);
			summaryReturnUpload.setGstnStatus(status);
			hibernateDao.saveOrUpdate(summaryReturnUpload);
		}else{
			ReturnUpload returnUpload = returnUploadDao.getReturnUpload(filingId, trxId, refId, loadId);
			
			returnUpload.setGstnStatus(status);
			returnUpload.setErrorDesc(errorMsg);
			if(status.equalsIgnoreCase(Constant.PROCESSED_WITH_ERROR) || status.equalsIgnoreCase(Constant.ERROR) || status.equalsIgnoreCase(Constant.ERRORSTATUS)){
				logger.info("Calling SP to reset flags for failed chunks");
				gstr1Service.updateGstnTranId(null, null, gstin, null, loadId,gstnStatus,errorDesc); 
			}
			hibernateDao.saveOrUpdate(returnUpload);
		}
		}catch(Exception e){
			logger.error("Exception occured while updating RefIds gstnstatus "+e );
		}
}

	@Override
	public void updateReturnFilingStatusForSave(List<Long> transactionIDPollingList) {
		
		logger.info(" Inside updateReturnFilingStatusForSave "+CLASS_NAME);
		DetachedCriteria subCriteriaReturnFiling = DetachedCriteria.forClass(TblGstinRetutnFilingStatus.class);
		subCriteriaReturnFiling.add(Property.forName(Constant.STATUS).ne(Constant.SAVED)); 
		subCriteriaReturnFiling.setProjection(Projections.property(Constant.FILING_ID)); 
		DetachedCriteria criteria = DetachedCriteria.forClass(ReturnUpload.class);
		criteria.add(Restrictions.in(Constant.LoadId, transactionIDPollingList));
		criteria.add(Restrictions.isNotNull(Constant.GSTN_STATUS));
		criteria.add(Property.forName(Constant.FILING_ID).in(subCriteriaReturnFiling));			
		ProjectionList projList = Projections.projectionList();
		projList.add(Projections.property(Constant.FILING_ID));
		criteria.setProjection(Projections.distinct(projList));
		
		List<Long> returnUploadList = (List<Long>) hibernateDao.getHibernateTemplate().findByCriteria(criteria);
		try{
		if(returnUploadList!=null && !returnUploadList.isEmpty()){
			returnUploadList.forEach(item -> {
				DetachedCriteria detachedCriteria = DetachedCriteria.forClass(ReturnUpload.class);
				detachedCriteria.add(Restrictions.eq(Constant.FILING_ID, item));
				detachedCriteria.add(Restrictions.in(Constant.LoadId, transactionIDPollingList));
				ProjectionList projectionList = Projections.projectionList();
				projectionList.add(Projections.property(Constant.GSTN_STATUS));
				detachedCriteria.setProjection(Projections.distinct(projectionList));
				List<String> gstnStatusList = (List<String>) hibernateDao.getHibernateTemplate().findByCriteria(detachedCriteria);
				if(!(null==gstnStatusList && gstnStatusList.isEmpty())){
					if(gstnStatusList.contains(Constant.REC) && gstnStatusList.size() == 1){
						returnFilingDao.updateReturnFilingStatusForSave(item, Constant.IN_PROGRESS);
					}else if(gstnStatusList.contains(Constant.INPROGRESS) && gstnStatusList.size() == 1){
						returnFilingDao.updateReturnFilingStatusForSave(item, Constant.IN_PROGRESS);
					}else if(gstnStatusList.contains(Constant.ERROR) && gstnStatusList.size() == 1){
						returnFilingDao.updateReturnFilingStatusForSave(item, Constant.SAVED_E);
					}else if(gstnStatusList.contains(Constant.PROCESSED_) && gstnStatusList.size() == 1){
						returnFilingDao.updateReturnFilingStatusForSave(item, Constant.SAVED_P);
					}else if(gstnStatusList.contains(Constant.PROCESSED_WITH_ERROR) && gstnStatusList.size() == 1){
						returnFilingDao.updateReturnFilingStatusForSave(item, Constant.SAVED_PE);
					}else if((gstnStatusList.contains(Constant.ERROR) || gstnStatusList.contains(Constant.PROCESSED_WITH_ERROR) ||
							gstnStatusList.contains(Constant.PROCESSED_)) && gstnStatusList.size() > 1){
						returnFilingDao.updateReturnFilingStatusForSave(item, Constant.SAVED_PE);
					}
				}
			});
		}}
		catch(Exception e)
		{
			logger.info(" Exception in updateReturnFilingStatusForSave " + e);
		}
		
	}
	

	public void updateGstnStatusToTblReturnFillingstatus(Long filingId, String trxId, String refId, Long loadId, String status, String errorMsg, boolean isSummary) {
		try{
			logger.info("Executing updateGstnStatusToTblReturnFillingstatus "+CLASS_NAME);
		if(isSummary){
			SummaryReturnUpload summaryReturnUpload = returnUploadDao.getSummaryReturnUpload(filingId, trxId, refId, loadId);
			summaryReturnUpload.setGstnStatus(status);
			hibernateDao.saveOrUpdate(summaryReturnUpload);
		}else{
		
			TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus = returnUploadDao.gettblGstinRetutnFilingStatus(filingId, trxId, refId);
		
			tblGstinRetutnFilingStatus.setGstnStatus(status);	
			tblGstinRetutnFilingStatus.setErrorDesc(errorMsg);			
			hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
		}
		}catch(Exception e){
			logger.error("Exception updateGstnStatusToTblReturnFillingstatus "+e);
		}
}
	
	 @Override
		public void updateReturnFilingStatus(){
	 
		 logger.info("Inside updateReturnFilingStatus()");	
   		DetachedCriteria criteria = DetachedCriteria.forClass(TblGstinRetutnFilingStatus.class);
			criteria.add(Property.forName(Constant.STATUS).eq(Constant.SUBMITSUCESS));
			criteria.add(Restrictions.or(Restrictions.isNotNull(Constant.GSTN_STATUS), 
	                Restrictions.ne(Constant.GSTN_STATUS, "")));
			List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatusList = (List<TblGstinRetutnFilingStatus>) hibernateDao.getHibernateTemplate().findByCriteria(criteria);
			if(tblGstinRetutnFilingStatusList!=null && !tblGstinRetutnFilingStatusList.isEmpty()){
				tblGstinRetutnFilingStatusList.forEach(item -> {
					if(item.getGstnStatus().contains(Constant.REC)){
						returnFilingDao.updateReturnFilingStatus(item.getFilingId(), Constant.IN_PROGRESS);
					    }else if(item.getGstnStatus().contains(Constant.INPROGRESS)){
							returnFilingDao.updateReturnFilingStatus(item.getFilingId(), Constant.IN_PROGRESS);
						}else if(item.getGstnStatus().contains(Constant.ERROR)){
							returnFilingDao.updateReturnFilingStatus(item.getFilingId(), Constant.SUBMIT_E);
						}else if(item.getGstnStatus().contains(Constant.PROCESSED_)){
							returnFilingDao.updateReturnFilingStatus(item.getFilingId(), Constant.SUBMIT_P);
						}else if(item.getGstnStatus().contains(Constant.PROCESSED_WITH_ERROR)){
							returnFilingDao.updateReturnFilingStatus(item.getFilingId(), Constant.SUBMIT_PE);
						}else if((item.getGstnStatus().contains(Constant.ERROR) || item.getGstnStatus().contains(Constant.PROCESSED_WITH_ERROR) ||
								item.getGstnStatus().contains(Constant.PROCESSED_))){
							returnFilingDao.updateReturnFilingStatus(item.getFilingId(), Constant.SUBMIT_PE);
						}
				});
			}
		}
	 
	 @SuppressWarnings("unchecked")
	@Override
	public void updateReturnFilingStatusForSummary(){
			
			DetachedCriteria subCriteriaReturnFiling = DetachedCriteria.forClass(TblGstinRetutnFilingStatus.class);
			subCriteriaReturnFiling.add(Property.forName(Constant.STATUS).ne(Constant.SAVED)); 
			subCriteriaReturnFiling.setProjection(Projections.property(Constant.FILING_ID)); 
			
			DetachedCriteria subCriteria = DetachedCriteria.forClass(SummaryReturnUpload.class);
			subCriteria.add(Property.forName(Constant.GSTN_STATUS).isNull()); 
			subCriteria.setProjection(Projections.property(Constant.FILING_ID)); 

			DetachedCriteria criteria = DetachedCriteria.forClass(SummaryReturnUpload.class);
			criteria.add(Restrictions.isNotNull(Constant.GSTN_STATUS));
			criteria.add(Property.forName(Constant.FILING_ID).notIn(subCriteria));
			criteria.add(Property.forName(Constant.FILING_ID).in(subCriteriaReturnFiling));		
			
			ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property(Constant.FILING_ID));
			criteria.setProjection(Projections.distinct(projList));
			
			List<Long> returnUploadList = (List<Long>) hibernateDao.getHibernateTemplate().findByCriteria(criteria);
			if(returnUploadList!=null && !returnUploadList.isEmpty()){
				returnUploadList.forEach(item -> {
					DetachedCriteria detachedCriteria = DetachedCriteria.forClass(SummaryReturnUpload.class);
					detachedCriteria.add(Restrictions.eq(Constant.FILING_ID, item));
					ProjectionList projectionList = Projections.projectionList();
					projectionList.add(Projections.property(Constant.GSTN_STATUS));
					detachedCriteria.setProjection(Projections.distinct(projectionList));
					List<String> gstnStatusList = (List<String>) hibernateDao.getHibernateTemplate().findByCriteria(detachedCriteria);
					if(gstnStatusList.isEmpty()){
						if(gstnStatusList.contains(Constant.ERROR) && gstnStatusList.size() == 1){
							returnFilingDao.updateReturnFilingStatus(item, Constant.SUBMIT_E);
						}else if(gstnStatusList.contains(Constant.PROCESSED_) && gstnStatusList.size() == 1){
							returnFilingDao.updateReturnFilingStatus(item, Constant.SUBMIT_P);
						}else if(gstnStatusList.contains(Constant.PROCESSED_WITH_ERROR) && gstnStatusList.size() == 1){
							returnFilingDao.updateReturnFilingStatus(item, Constant.SUBMIT_PE);
						}else if((gstnStatusList.contains(Constant.ERROR) || gstnStatusList.contains(Constant.PROCESSED_WITH_ERROR) ||
								gstnStatusList.contains(Constant.PROCESSED_)) && gstnStatusList.size() > 1){
							returnFilingDao.updateReturnFilingStatus(item, Constant.SUBMIT_PE);
						}
					}
				});
			}
		}
		 
	//Transaction ID Polling ends
	 
	 @SuppressWarnings("unchecked")
		@Override
		public List<Object[]> fetchAllActiveGstinList() {
			
			List<Object[]> gstinList = null;
			try{
				DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGstinDetailsDomain.class);
				detachedCriteria.add(Restrictions.eq("isActive", true));
				detachedCriteria.setProjection(Projections.projectionList()
					        .add(Projections.property("gstinId"))
					        .add(Projections.property("entityID")));
				gstinList = (List<Object[]>) hibernateDao.find(detachedCriteria);
				}catch(Exception e){
					logger.error("Error fetching fetchAllActiveGstinList " + e);
				}
			return gstinList;
		}
	@SuppressWarnings("unchecked")
	@Override
	public List<TblGstinDetailsDomain> getGstinDetailsByEntity(Integer entityId) {
		List<TblGstinDetailsDomain> gstinList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGstinDetailsDomain.class);
			detachedCriteria.add(Restrictions.eq("entityID", entityId));
			gstinList = (List<TblGstinDetailsDomain>) hibernateDao.find(detachedCriteria);
			}catch(Exception e){
				logger.error("Error fetching getGstinDetailsByEntity " + e);
			}
		return gstinList;
	}
	
	
	@Override
	public List<ReturnUpload> getChunkStatusAfterSave(String gstin,String taxperiod,String returnType) {
		List<ReturnUpload> returnUploadList =null;
		try{
			logger.info("Inside getChunkStatusAfterSave of "+CLASS_NAME);
    	 returnUploadList = returnUploadDao.getReturnUpload(gstin,taxperiod,returnType);
	      }catch(Exception e){
		          logger.error("Error fetching getChunkStatusAfterSave " + e);	
	     }
		return returnUploadList;
    	
    	
	}
	@Override
	public Object getChunkStatusAfterSave(String gstin,String taxperiod,String returnType, String refId) {
		Object returnUploadList =null;
		try{
			logger.info("Inside getChunkStatusAfterSave of "+CLASS_NAME);
    	 returnUploadList = returnUploadDao.getReturnUpload(gstin,taxperiod,returnType,refId);
	      }catch(Exception e){
		          logger.error("Error fetching getChunkStatusAfterSave " + e);	
	     }
		return returnUploadList;
    	
    	
	}
	@Override
	public List<TechReconDTO> getTechReconDTOList() {
		
		List<TechReconDTO> finalTechReconList = new ArrayList<TechReconDTO>();
		
		List<Object> invoiceKeyDetailList=returnUploadDao.getInvoiceKeyDetailList();
		try{
			logger.info("Inside getTechReconDTOList()");
		if(!(invoiceKeyDetailList==null ||invoiceKeyDetailList.isEmpty())){
		for(Object invoiceKeyDetail :invoiceKeyDetailList){
			 TechReconDTO techReconDTO=new TechReconDTO();        
			 techReconDTO.setGstin((String)((Object[])invoiceKeyDetail)[0]);
		     techReconDTO.setTaxPeriod((String)((Object[])invoiceKeyDetail)[1]);
		     techReconDTO.setAction((String)((Object[])invoiceKeyDetail)[2]);
			 techReconDTO.setLoadId((Long)((Object[])invoiceKeyDetail)[3]);  
			
			 finalTechReconList.add(techReconDTO);
			 }
		}}
		catch(Exception e){
			logger.info("Exception in " + CLASS_NAME + " Method : getTechReconDTOList()" + e.getMessage());
		}
		return finalTechReconList;
	}
}
