package com.ey.advisory.asp.client.dto;

public class SalePurchasedto {
	
	private String SupplyType;
	
	private Double Value;
	
	private Double IGSTRate;
	
	private Double IGSTAmount;
	
	private Double CGSTRate;
	
	private Double CGSTAmount;
	
	private Double SGSTRate;
	
	private Double UTGSTAmount;
	
	private Double UTGSTRate;

	private Double SGSTAmount;
	
	private Double CessRate;
	
	private Double CessAmount;
	
	private Double ValueIncludingTax;
	
	private String supplyCategory;
	
	private String tranType;
	
	private String fromDate;
	
	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	private String toDate;

	public String getSupplyCategory() {
		return supplyCategory;
	}

	public void setSupplyCategory(String supplyCategory) {
		this.supplyCategory = supplyCategory;
	}

	public String getSupplyType() {
		return SupplyType;
	}

	public void setSupplyType(String supplyType) {
		SupplyType = supplyType;
	}

	public Double getValue() {
		return Value;
	}

	public void setValue(Double value) {
		Value = value;
	}

	public Double getIGSTRate() {
		return IGSTRate;
	}

	public void setIGSTRate(Double iGSTRate) {
		IGSTRate = iGSTRate;
	}

	public Double getIGSTAmount() {
		return IGSTAmount;
	}

	public void setIGSTAmount(Double iGSTAmount) {
		IGSTAmount = iGSTAmount;
	}

	public Double getCGSTRate() {
		return CGSTRate;
	}

	public void setCGSTRate(Double cGSTRate) {
		CGSTRate = cGSTRate;
	}

	public Double getCGSTAmount() {
		return CGSTAmount;
	}

	public void setCGSTAmount(Double cGSTAmount) {
		CGSTAmount = cGSTAmount;
	}

	public Double getSGSTRate() {
		return SGSTRate;
	}

	public void setSGSTRate(Double sGSTRate) {
		SGSTRate = sGSTRate;
	}

	public Double getSGSTAmount() {
		return SGSTAmount;
	}

	public void setSGSTAmount(Double sGSTAmount) {
		SGSTAmount = sGSTAmount;
	}

	public Double getUTGSTAmount() {
		return UTGSTAmount;
	}

	public void setUTGSTAmount(Double uTGSTAmount) {
		UTGSTAmount = uTGSTAmount;
	}

	public Double getUTGSTRate() {
		return UTGSTRate;
	}

	public void setUTGSTRate(Double uTGSTRate) {
		UTGSTRate = uTGSTRate;
	}

	public Double getCessRate() {
		return CessRate;
	}

	public void setCessRate(Double cessRate) {
		CessRate = cessRate;
	}

	public Double getCessAmount() {
		return CessAmount;
	}

	public void setCessAmount(Double cessAmount) {
		CessAmount = cessAmount;
	}
	
	public Double getValueIncludingTax() {
		return ValueIncludingTax;
	}

	public void setValueIncludingTax(Double valueIncludingTax) {
		ValueIncludingTax = valueIncludingTax;
	}

	public String getTranType() {
		return tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}


	

}
