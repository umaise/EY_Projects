package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.InwardInvoiceModel;


public interface PurchaseStagingService {

	Long getDupCount(Long fileId);
	
	Long getProcessedCount(Long fileId);
	
	public Long getTotalErrorCount(Long fileId);
	
	List<InwardInvoiceModel> fetchDupRecords(Long fileId, int firstResult, int pageSize);
	
	List<InwardInvoiceModel> getProcessedRecords(Long fileId, int firstResult, int pageSize);
	
	public List<InwardInvoiceModel> fetchErrorRecords(Long fileId,int firstResult, int pageSize);
}
