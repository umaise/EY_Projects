package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.InvoiceKeyDetail;
import com.ey.advisory.asp.client.domain.ReturnUpload;
import com.ey.advisory.asp.client.domain.SummaryReturnUpload;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;

public interface ReturnUploadDao {


	

	Boolean validateSavedStatusAgainstInvoiceKey(String gstinId, String rtPeriod, String retType);
	
	List<ReturnUpload> getReturnUpload();
	
	List<SummaryReturnUpload> getSummaryReturnUpload();
	
	ReturnUpload getReturnUpload(Long filingId, String trxId, String refId, Long loadId);
	
	
	SummaryReturnUpload getSummaryReturnUpload(Long filingId, String trxId, String refId, Long loadId);
	
	
	//public TblGstinRetutnFilingStatus gettblGstinRetutnFilingStatus(Long filingId, String trxId, String refId);

	TblGstinRetutnFilingStatus gettblGstinRetutnFilingStatus(Long filingId, String trxId, String refId);
	
	List<TblGstinRetutnFilingStatus> gettblGstinRetutnFilingStatus();
	
	List<ReturnUpload> getReturnUpload(String gstin,String taxperiod,String returnType);
	Object getReturnUpload(String gstin,String taxperiod,String returnType, String refId);
	
	public List<Object> getInvoiceKeyDetailList();

}
