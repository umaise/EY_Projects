package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;

public interface SaleStagingService {
	
	 public List<String> getDataCount(String applicableState, String returnType,
				String fileData, String isProccessed, String jobStatus,
				List<String> fileIds,String recordType, String groupCode);
	public List<String> getLineItemList(String applicableState,
			String returnType, String string, String recordType,
			String datalevel);
	List<OutwardInvoiceModel> getTotalRecords(Long fileId, int firstResult, int pageSize);
	
	List<OutwardInvoiceModel> getProcessedRecords(Long fileId, int firstResult, int pageSize);
	
	List<OutwardInvoiceModel> fetchDupRecords(Long fileId, int firstResult, int pageSize);
	
	Long getProcessedCount(Long fileId);
	
	Long getDupCount(Long fileId);
	
	public List<OutwardInvoiceModel> fetchErrorRecords(Long fileId,int firstResult, int pageSize);
	
	public Long getTotalErrorCount(Long fileId);
}
