package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblGSTR2AdvanceAdj;

public interface GSTR2AdvanceAdjustedService {
	
	List<TblGSTR2AdvanceAdj> fetchAll();
	Long getTotalRecordCount(Long fileId);
	List<TblGSTR2AdvanceAdj> fetchTotalRecords(Long fileId, int firstResult, int pageSize);

}
