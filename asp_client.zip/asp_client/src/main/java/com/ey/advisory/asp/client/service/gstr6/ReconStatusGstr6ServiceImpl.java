package com.ey.advisory.asp.client.service.gstr6;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.ReconStatusDao;
import com.ey.advisory.asp.client.dao.ReconStatusGstr6Dao;
import com.ey.advisory.asp.client.domain.ReconStatus;
import com.ey.advisory.asp.client.domain.ReconStatusGstr6;

@Service
public class ReconStatusGstr6ServiceImpl implements ReconStatusGstr6Service{
	
	@Autowired
	private ReconStatusGstr6Dao reconStatusDao;
	

	@Override
	public ReconStatusGstr6 getReconStatus(String gstin, String taxPeriod, Integer masterId) {
		return reconStatusDao.getReconStatus(gstin, taxPeriod, masterId);
	}


	@Override
	public void saveReconStatus(String gstin, String taxPeriod, Integer masterId) {
		reconStatusDao.saveReconStatus(gstin, taxPeriod, masterId);
	}


	@Override
	public void updateReconStatus(String gstin, String taxPeriod, Integer masterId) {
		reconStatusDao.updateReconStatus(gstin, taxPeriod, masterId);
	}

	@Override
	public ReconStatusGstr6 getActiveReconStatus(String gstin, String taxPeriod) {
		return reconStatusDao.getActiveReconStatus(gstin, taxPeriod);
	}
	
	@Override
	public ReconStatusGstr6 getReconStatus(String gstin, String taxPeriod) {
		return reconStatusDao.getReconStatus(gstin, taxPeriod);
	}
	
	@Override
	public void updateReconStatus(String gstin, String taxPeriod,Integer masterId,String status){
		reconStatusDao.updateReconStatus(gstin, taxPeriod, masterId, status);
	}

	@Override
	public void updateReconCompletionDate(String gstin, String taxPeriod, Integer masterId) {
		reconStatusDao.updateReconCompletionDate(gstin, taxPeriod, masterId);
	}
}
