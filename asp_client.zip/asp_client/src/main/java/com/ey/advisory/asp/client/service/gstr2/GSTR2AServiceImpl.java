package com.ey.advisory.asp.client.service.gstr2;

import java.io.File;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.aspose.cells.Cell;
import com.aspose.cells.CellArea;
import com.aspose.cells.Cells;
import com.aspose.cells.CellsHelper;
import com.aspose.cells.Column;
import com.aspose.cells.LoadOptions;
import com.aspose.cells.MemorySetting;
import com.aspose.cells.ProtectionType;
import com.aspose.cells.Range;
import com.aspose.cells.Row;
import com.aspose.cells.Style;
import com.aspose.cells.Validation;
import com.aspose.cells.ValidationCollection;
import com.aspose.cells.ValidationType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.ReconStatusDao;
import com.ey.advisory.asp.client.dao.ReportDao;
import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.domain.ReconStatus;
import com.ey.advisory.asp.client.dto.GSTR2FInvoiceDto;
import com.ey.advisory.asp.client.dto.GSTR2FReconDto;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.TblGstinListService;
import com.ey.advisory.asp.client.service.TblGstinRetutnFilingStatusService;
import com.ey.advisory.asp.client.util.CommonUtillity;
import com.ey.advisory.asp.client.util.GSTNRestClientUtility;
import com.ey.advisory.asp.common.Constant;
import com.google.gson.Gson;

@Service
public class GSTR2AServiceImpl implements GSTR2AService {
	@Autowired
	HibernateDao hibernateDao;

	@Autowired
	ClientSpCallService clientSpCallService;

	@Autowired
	Environment env;

	@Autowired
	GSTNRestClientUtility restClientUtility;

	@Autowired
	TblGstinRetutnFilingStatusService tblGstinRetutnFilingStatusService;

	@Autowired
	TblGstinListService gstinListService;
	
	@Autowired
	ReconStatusDao reconStatusDao;

	@Autowired
	ReturnFilingDao returnFilingDao;
	@Autowired
	ReportDao reportDao;

	private static final Logger LOGGER = Logger.getLogger(GSTR2AServiceImpl.class);
	private static final String CLASS_NAME = GSTR2AServiceImpl.class.getName();

	@Override
	public String updateGSTR2AStatus(String gstin, String retPeriod, String status) {

		List<String> inputParams = new ArrayList<>();
		String updateResp = "";
		try {
			inputParams.add(retPeriod);
			inputParams.add(gstin);
			inputParams.add(status);
			updateResp = tblGstinRetutnFilingStatusService.updateGstr2AStatus(inputParams);

		} catch (Exception e) {
			LOGGER.error("Exception in GSTR2AServiceImpl.updateGSTR2AStatus() : " + e);
			//throw new Exception("Exception in GSTR2AServiceImpl.updateGSTR2AStatus() : " + e);
		}
		return updateResp;
	}
	
	@Override
	public String insertGSTR2AStatus(String gstin, String retPeriod, String status) throws Exception {

		List<String> inputParams = new ArrayList<>();
		String updateResp = "";
		try {
			
			inputParams.add(retPeriod);
			inputParams.add(gstin);
			inputParams.add(status);
			updateResp = tblGstinRetutnFilingStatusService.insertGstr2AEntry(inputParams);

		} catch (Exception e) {
			LOGGER.error("Exception in GSTR2AServiceImpl.updateGSTR2AStatus() : " + e);
			throw new Exception("Exception in GSTR2AServiceImpl.updateGSTR2AStatus() : " + e);
		}
		return updateResp;
	}

	@Override
	public String saveGSTR2AData(String gstin, String retPeriod, String groupCode, String invType, String respJSON,
			String chunkId) throws Exception {
		String saveResult = "";
		try {
			if (invType != null && !invType.isEmpty()) {

				if (invType.equalsIgnoreCase(Constant.B2B)) {
					saveResult = saveGSTR2ADataInProc(gstin, retPeriod, respJSON, chunkId,
							env.getProperty("gstr2A.spSchemaName"),
							env.getProperty("saveGstr2AB2bData.storedProcName"));
				} else if (invType.equalsIgnoreCase(Constant.B2BA)) {
					saveResult = saveGSTR2ADataInProc(gstin, retPeriod, respJSON, chunkId,
							env.getProperty("gstr2A.spSchemaName"),
							env.getProperty("saveGstr2AB2bData.storedProcName"));
				} else if (invType.equalsIgnoreCase(Constant.CDN_INV)) {
					saveResult = saveGSTR2ADataInProc(gstin, retPeriod, respJSON, chunkId,
							env.getProperty("gstr2A.spSchemaName"),
							env.getProperty("saveGstr2ACdnData.storedProcName"));
				} else if (invType.equalsIgnoreCase(Constant.CDNA_INV)) {
					saveResult = saveGSTR2ADataInProc(gstin, retPeriod, respJSON, chunkId,
							env.getProperty("gstr2A.spSchemaName"),
							env.getProperty("saveGstr2ACdnaData.storedProcName"));
				}
			}
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " processGSTR2AData() : ", e);
			throw new Exception(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " processGSTR2AData() : ",
					e);
		}
		return saveResult;
	}

	private String saveGSTR2ADataInProc(String gstin, String retPeriod, String respJSON, String chunkId,
			String spSchemaName, String spName) throws Exception {

		List<String> inputParams = new ArrayList<>();
		String procResult = "";
		try {
			inputParams.add(gstin);
			inputParams.add(retPeriod);
			inputParams.add(respJSON);
			inputParams.add(chunkId);

			procResult = clientSpCallService.executeStoredProcedure(spSchemaName, spName,
					String.valueOf(inputParams.size()), inputParams);
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " saveB2BData : ", e);
			throw new Exception(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " saveB2BData : ", e);
		}
		return procResult;

	}

	@Override
	public String processRecievedResponse(String respJSON, String gstin, String retPeriod, String groupCode,
			String invoiceType, String hitCount) throws Exception {
		LOGGER.info("Inside processRecievedResponse for invoiceType "+invoiceType);
		String resourceURL = env.getProperty(Constant.BATCH_API_HOST)
				+ env.getProperty(Constant.SCHEDULE_TENANT_SIMPLE_TRIGGER);
		JSONObject returnType;
		String saveJsonResp = "";
		String finalReturnType = null;
		String returnTypeString = "";
		if (respJSON != null && !CommonUtillity.isEmpty(respJSON)) {
			returnType = checkReturnType(respJSON);
			LOGGER.info("Inside processRecievedResponse with return Type"+returnType);
			if (returnType != null && returnType.get("returnType") != null) {
				returnTypeString = returnType.get("returnType").toString();
				if (returnTypeString.equalsIgnoreCase(Constant.TOKEN_RECEIVED)) {
					finalReturnType = Constant.TOKEN_RECEIVED;
					LOGGER.info("Inside processRecievedResponse with returnTypeString"+returnTypeString);
					String est = (String) returnType.get("est");
					String token = (String) returnType.get("token");
					LOGGER.info("Inside processRecievedResponse , Before hitting batch ");
					String batchResp = scheduleSimpleTrigger(resourceURL,
							groupCode, est, invoiceType, gstin, token, retPeriod, hitCount);
					if (Constant.JOB_TRIGGERED.equalsIgnoreCase(batchResp)) {
						LOGGER.info("Rest call to batch is successfull for" + invoiceType + " .. ");
						String updateResult = updateGSTR2AStatus(gstin, retPeriod, Constant.TOKEN_RECEIVED);

						if (Constant.SUCCESS.equalsIgnoreCase(updateResult)) {
							LOGGER.info("Status updated successfully in the Table for " + invoiceType + ".");
						} else {
							LOGGER.error("Could not update status in the Table for  " + invoiceType + "..!!");
						}
					} else {
						finalReturnType = batchResp;
						LOGGER.error("Rest call to batch is failed for " + invoiceType + "  " + batchResp + "  ..!! ");

					}
				} else if (returnTypeString.equalsIgnoreCase(Constant.RECONSTATE)) {
					if (!CommonUtillity.isEmpty(respJSON)) {
						int chunkId = 1;
						saveJsonResp = saveGSTR2AData(gstin, retPeriod, groupCode, invoiceType, respJSON,
								String.valueOf(chunkId));
						if (!CommonUtillity.isEmpty(saveJsonResp) && saveJsonResp.equalsIgnoreCase("Success")) {
							finalReturnType = Constant.RECONSTATE;
						} else {
							finalReturnType = "Failed to save "+invoiceType;
						}
					}
				} else if (returnTypeString.equalsIgnoreCase("Error")) {
					finalReturnType = "Invalid Response from GSTN";
				} else {
					finalReturnType = "Unexpected Error";
				}
			}
		}
		return finalReturnType;
	}

	@Override
	public String scheduleSimpleTrigger(String resourceURL,
			 String groupCode, String est, String invoiceType, String gstin, String token,
			String retPeriod, String hitCount) {
		String batchResp = restClientUtility.executePOSTRestCall(resourceURL, getHeaders(),
				getInputData(groupCode, est, invoiceType, gstin, token, retPeriod, hitCount), HttpMethod.POST);
		return batchResp;
	}

	@SuppressWarnings("unchecked")
	private JSONObject checkReturnType(String b2bRespJSON) throws ParseException {
		JSONObject jsonObjectVal = null;
		try {
			jsonObjectVal = (JSONObject) new JSONParser().parse(b2bRespJSON);
			if (jsonObjectVal != null) {
				if (jsonObjectVal.get("b2b") != null && jsonObjectVal.get("est") == null) {
					jsonObjectVal.put("returnType", Constant.RECONSTATE);

				} else if (jsonObjectVal.get("cdn") != null && jsonObjectVal.get("est") == null) {
					jsonObjectVal.put("returnType", Constant.RECONSTATE);

				} else if (jsonObjectVal.get("b2b") == null && jsonObjectVal.get("cdn") == null
						&& jsonObjectVal.get("est") != null) {
					jsonObjectVal.put("est", jsonObjectVal.get("est"));
					jsonObjectVal.put("token", jsonObjectVal.get("token"));
					jsonObjectVal.put("returnType", Constant.TOKEN_RECEIVED);

				} else { // TODO
					jsonObjectVal.put("error", "Invalid Response from GSTN");
					jsonObjectVal.put("returnType", "Error");
				}
			}

		} catch (ParseException e) {
			LOGGER.error("Exception in checkReturnType() : " + e);
			throw e;
		}
		return jsonObjectVal;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		return headers;
	}

	@SuppressWarnings("unchecked")
	private String getInputData(String groupCode, String est, String invType, String gstin, String token,
			String taxPeriod, String hitCount) {

		String params = "jobName,groupCode,gstin,taxPeriod,token,invoiceType,hitCount";

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("jobName", Constant.FILEDETAIL_JOB);
		jsonObject.put("groupCode", groupCode);
		jsonObject.put("taxPeriod", taxPeriod);
		jsonObject.put("token", token);
		jsonObject.put("gstin", gstin);
		jsonObject.put("invoiceType", invType);
		jsonObject.put("timeInterval", est);
		jsonObject.put("priority", 5);
		jsonObject.put("repeatCount", 0);
		jsonObject.put("params", params);
		jsonObject.put("hitCount", hitCount);
		return jsonObject.toString();
	}

	/**
	 * This method is to generate GSTR2FRecon reports.
	 * 
	 */
	@Override
	public void generateGSTR2FReconReport(String groupCode, String gstin, String taxPeriod,URL template_Dir) {

		LOGGER.info("Start of generateGSTR2FReconReport method");

		int offset = Integer.valueOf(env.getProperty("recon.report.offset.page.number"));
		int pageSize = Integer.valueOf(env.getProperty("recon.report.page.size"));

		try {

			

			String updatedDate = null;

			updatedDate = getUpdatedDate(gstin, taxPeriod);

			LOGGER.info("updatedDate is " + updatedDate);

			if (null != updatedDate) {
				
				/*
				 * Generate matched recon report
				 */

				try {
					
								
					generateReconReport(gstin, taxPeriod, offset, pageSize, Constant.MATCHED_REPORT, groupCode,
							updatedDate,template_Dir);

				}catch (Exception e) {

					LOGGER.error("Error occured while generating matched reports",e);
				}
				
				
				try {
				/*
				 * Generate matched asp recon report
				 */
				generateReconReport(gstin, taxPeriod, offset, pageSize, Constant.MATCHED_ASP_REPORT, groupCode,
						updatedDate,template_Dir);
				
				}catch (Exception e) {

					LOGGER.error("Error occured while generating matched asp reports",e);
				}

				try {
				/*
				 * Generate mis matched recon report
				 */
				generateReconReport(gstin, taxPeriod, offset, pageSize, Constant.MIS_MATCHED_REPORT, groupCode,
						updatedDate,template_Dir);
				
				}catch (Exception e) {

					LOGGER.error("Error occured while generating mis matched reports",e);
				}

				try {
				/*
				 * Generate additional recon report
				 */
				generateReconReport(gstin, taxPeriod, offset, pageSize, Constant.ADDITIONAL_REPORT, groupCode,
						updatedDate,template_Dir);
				}catch (Exception e) {

					LOGGER.error("Error occured while generating additional reports",e);
				}

				try {
				/*
				 * Generate missing recon report
				 */
				generateReconReport(gstin, taxPeriod, offset, pageSize, Constant.MISSING_REPORT, groupCode,
						updatedDate,template_Dir);
				}catch (Exception e) {

					LOGGER.error("Error occured while generating missing reports",e);
				}
			}

			LOGGER.info("End of generateGSTR2FReconReport method");

		} catch (Exception e) {

			LOGGER.error("Error occured while generating the report",e);
		}

	}

	private String getUpdatedDate(String gstin, String taxPeriod) {

		LOGGER.info("Getting updated date");

		ReconStatus reconStatus = reconStatusDao.getReconStatus(gstin, taxPeriod);

		String updateDate = null;

		if (null != reconStatus && null != reconStatus.getReconCompleteDate()) {

			updateDate = reconStatus.getReconCompleteDate().toString();

			updateDate = updateDate.replace(" ", "_");

			updateDate = updateDate.replace(":", "");

			updateDate = updateDate.replace(".", "");

			return updateDate;
		}

		return updateDate;

	}

	/**
	 * This method is to generate recon reports based on the report type.
	 * 
	 * 
	 * @param gstin
	 * @param taxPeriod
	 * @param offset
	 * @param pageSize
	 * @param reportType
	 * @param template_Dir2 
	 * @throws Exception
	 */
	private void generateReconReport(String gstin, String taxPeriod, int offset, int pageSize, String reportType,
			String groupCode, String updatedDate, URL template_Dir) throws Exception {

		LOGGER.info(
				"Inside generateReconReport(String gstin, String taxPeriod, int offset, int pageSize, String reportType,String groupCode, String updatedDate) method ");

		int initialRow = Integer.valueOf(env.getProperty("recon.report.template.initial.row"));
		int listSize = 0;

		String filePath = groupCode + File.separator + env.getProperty(Constant.FOLDER_STRUCT_RECON_REPORT);
		String filefolder = env.getProperty("sharedPath") + filePath;
		//String filefolder = "C:\\GST_Azure\\Recon reports\\ReconReportOutput\\";

		LOGGER.info("filefolder"+filefolder);
		
		String reconReportData = "";
		List<Integer> rowCount = new ArrayList<Integer>();

        LoadOptions opt=new LoadOptions();
        opt.setMemorySetting(MemorySetting.MEMORY_PREFERENCE);


		createReconReports(gstin, taxPeriod, offset, pageSize, reportType, updatedDate, template_Dir, initialRow,
				listSize, filefolder, rowCount, opt);

	}

	private void createReconReports(String gstin, String taxPeriod, int offset, int pageSize, String reportType,
			String updatedDate, URL template_Dir, int initialRow, int listSize, String filefolder,
			List<Integer> rowCount, LoadOptions opt) {
		String reconReportData;
		switch (reportType) {

		case Constant.MATCHED_REPORT: {
			generateReconMatchedReport(gstin, taxPeriod, offset, pageSize, reportType, updatedDate, template_Dir,
					initialRow, listSize, filefolder, rowCount, opt);

		}

			break;

		case Constant.MATCHED_ASP_REPORT: {
			generateReconmatchedAspReport(gstin, taxPeriod, offset, pageSize, reportType, updatedDate, template_Dir,
					initialRow, listSize, filefolder, rowCount, opt);

		}

			break;

		case Constant.MIS_MATCHED_REPORT: {
		
				genrateReconMismatchReport(gstin, taxPeriod, offset, pageSize, reportType, updatedDate, template_Dir,
						initialRow, listSize, filefolder, rowCount, opt);

		}

			break;

		case Constant.ADDITIONAL_REPORT: {

			generateReconadditionalReport(gstin, taxPeriod, offset, pageSize, reportType, updatedDate, template_Dir,
					initialRow, listSize, filefolder, rowCount, opt);

		}
		
			break;

		case Constant.MISSING_REPORT: {


			generateReconmissingReport(gstin, taxPeriod, offset, pageSize, reportType, updatedDate, template_Dir,
					initialRow, listSize, filefolder, rowCount, opt);

		}

			break;

		}
	}

	private void generateReconmissingReport(String gstin, String taxPeriod, int offset, int pageSize, String reportType,
			String updatedDate, URL template_Dir, int initialRow, int listSize, String filefolder,
			List<Integer> rowCount, LoadOptions opt) {
		String reconReportData;
		Workbook workbook=null;
			try {
			LOGGER.info("MISSING_REPORT");

			/*
			 * Get Json string from SP
			 */

			List<GSTR2FInvoiceDto> invocieDtoList = null;

			
			LOGGER.info("template_Dir"+template_Dir);
			
			String path = template_Dir.getPath() + "Recon-Missing_Records.xlsx";
			
			LOGGER.info("path"+path);
			
			workbook = new Workbook(path, opt);		
		    workbook.getSettings().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);                
			Worksheet sheet = workbook.getWorksheets().get(2); 
		    sheet.getCells().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);
			sheet.autoFitColumns();
			sheet.autoFitRows();
			Cells summaryCells = workbook.getWorksheets().get(reportType).getCells();
			String[] invoiceHeaders = env.getProperty(Constant.RECON_INVOICE_MISSING_HEADER).split(",");
			String[] itemHeaders = env.getProperty(Constant.RECON_LINEITEM_MISSING_HEADER).split(",");
			
			LOGGER.info("invoiceHeaders"+invoiceHeaders);
			
			LOGGER.info("itemHeaders"+itemHeaders);
			
			LOGGER.info("Workbook will be created");
			

			while ((reconReportData = reconStatusDao.getReconMissingRecords(gstin, taxPeriod, offset, pageSize)) != null
					&& !reconReportData.trim().isEmpty()) {

				
				
				// reconReportData =
				// reconStatusDao.getReconMissingRecords(gstin, taxPeriod,
				// offset, pageSize);

				if (null != reconReportData) {
					
					
					
					LOGGER.info("reconReportData"+reconReportData);
					
					GSTR2FReconDto recondDto = convertStringToMatchedReconDto(reconReportData);

					// Generate report
					invocieDtoList = recondDto.getB2bInvoices();
					listSize = invocieDtoList.size();
					for (GSTR2FInvoiceDto newModel : invocieDtoList) {

						List<GSTR2FInvoiceDto> invocieDtoListNew = new ArrayList<GSTR2FInvoiceDto>();
						if(!columnEnabling(taxPeriod)){
							newModel.setSuggestedResp("");
							newModel.setClientRes("");
						}else{
							newModel.setClientRes(env.getProperty(Constant.RECON_INVOICE_MISSING_DEFAULT));
							newModel.setSuggestedResp(env.getProperty(Constant.RECON_INVOICE_MISSING_DEFAULT));
						}
						invocieDtoListNew.add(newModel);
						rowCount.add(initialRow);

						summaryCells.importCustomObjects(invocieDtoListNew, invoiceHeaders, false, initialRow, 0,
								invocieDtoListNew.size(), true, "yyyy-mm-dd", true);

						createNamedRange(workbook.getWorksheets().get(2),initialRow,newModel.getInvKey().toString());
						if (newModel.getItemDetails() != null && newModel.getItemDetails().size() > 0) {

							summaryCells.importCustomObjects(newModel.getItemDetails(), itemHeaders, false,
									initialRow + 1, 26, newModel.getItemDetails().size(), true, "yyyy-mm-dd", true);
							initialRow += newModel.getItemDetails().size() + 1;

						}
						
						else{
							initialRow++;
							
						}
					}

				}

				// Increase the offset

				offset ++;

				if (listSize < pageSize) {
					break;
				}
			}
			
			createDropDown(workbook.getWorksheets().get(2), reportType ,rowCount);
			
			/*
			 * Create protected sheet
			 */
			sheet.protect(ProtectionType.ALL);

			if(columnEnabling(taxPeriod)){
				int rows = sheet.getCells().getRows().getCount();			
				String cellname=CellsHelper.cellIndexToName(rows-1, 2);				
				// Get the range of cells, which we want to unlock
				Range rangeUnlocked = sheet.getCells().createRange("C3:"+cellname);
				// Add a new style
				/*int styleIndex = workbook.getStyles().add();
				Style styleUnlocked = workbook.getStyles().get(styleIndex);*/
				
				Cell cell = sheet.getCells().get("C3");
				
				Style styleUnlocked = cell.getStyle();
				
				// Unlock cells
				styleUnlocked.setLocked(false);
				rangeUnlocked.setStyle(styleUnlocked);
			}
			
			applyColorSheet(summaryCells, sheet, workbook, initialRow);
			/*
			 * Save the report
			 */
			String fileName = "Missing_" + gstin + "_" + taxPeriod + "_" + updatedDate + ".xlsx";
			// "Matched_"+obj.get("gstinId").toString()+obj.get("taxPeriod").toString()+"_"+reconStatus.getUpdatedDate()+".xlsx";
			File folder = new File(filefolder);
			
			LOGGER.info("Workbook total row " + initialRow);
			
			if (workbook != null && initialRow > 2) {
				
				LOGGER.info("Workbook will be created");
				
				if (!folder.exists()) {
					if (!folder.mkdirs()) {
						LOGGER.info("File Path doesn't exists and could not find mounting path");
					} else {
						workbook.save(filefolder.concat(fileName));
						reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MISSING_REPORT, "True");
						LOGGER.info(
								"Created directory and Report has been generated and saved in file share" + filefolder);
					}
				} else {
					workbook.save(filefolder.concat(fileName));
					reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MISSING_REPORT, "True");
					LOGGER.info(
							"Directory already Exists, Report has been generated and saved in file share" + filefolder);
				}
			}
			
			else{
				
				reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MISSING_REPORT, "No Data");
				
				
			}
			if(workbook!=null){
				workbook.dispose();
			}
			sheet.dispose();
		} catch (Exception e) {
			
			reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MISSING_REPORT, "Error");
			LOGGER.error("Exception in generating Missing report" + e);
		}finally{
			if(workbook!=null){
				workbook.dispose();
			}
		}
	}

	private void generateReconadditionalReport(String gstin, String taxPeriod, int offset, int pageSize,
			String reportType, String updatedDate, URL template_Dir, int initialRow, int listSize, String filefolder,
			List<Integer> rowCount, LoadOptions opt) {
		String reconReportData;
		Workbook workbook=null;
		try {
			LOGGER.info("ADDITIONAL_REPORT");

			/*
			 * Get Json string from SP
			 */

			List<GSTR2FInvoiceDto> invocieDtoList = null;

			
			LOGGER.info("template_Dir"+template_Dir);
			
			
			String path = template_Dir.getPath() + "Recon-Additional_Records.xlsx";
			
			LOGGER.info("path"+path);
			
			workbook = new Workbook(path, opt);		
		    workbook.getSettings().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);                
			Worksheet sheet = workbook.getWorksheets().get(2); 
		    sheet.getCells().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);
			sheet.autoFitColumns();
			sheet.autoFitRows();
			Cells summaryCells = workbook.getWorksheets().get(reportType).getCells();
			String[] invoiceHeaders = env.getProperty(Constant.RECON_INVOICE_ADDITIONAL_HEADER).split(",");
			String[] itemHeaders = env.getProperty(Constant.RECON_LINEITEM_ADDITIONAL_HEADER).split(",");
			
			LOGGER.info("invoiceHeaders"+invoiceHeaders);
			
			LOGGER.info("itemHeaders"+itemHeaders);

			LOGGER.info("Workbook will be created");	
			
			while ((reconReportData = reconStatusDao.getAdditionalReconRecords(gstin, taxPeriod, offset,
					pageSize)) != null && !reconReportData.trim().isEmpty()) {
				
				
			
				if (null != reconReportData) {
					
					

					LOGGER.info("reconReportData"+reconReportData);
					
					GSTR2FReconDto recondDto = convertStringToMatchedReconDto(reconReportData);

					// Generate report
					invocieDtoList = recondDto.getB2bInvoices();
					listSize = invocieDtoList.size();
					for (GSTR2FInvoiceDto newModel : invocieDtoList) {

						List<GSTR2FInvoiceDto> invocieDtoListNew = new ArrayList<GSTR2FInvoiceDto>();
						if(!columnEnabling(taxPeriod)){
							newModel.setSuggestedResp("");
							newModel.setClientRes("");
						}else{
							newModel.setClientRes(env.getProperty(Constant.RECON_INVOICE_ADDITIONAL_DEFAULT));
							newModel.setSuggestedResp(env.getProperty(Constant.RECON_INVOICE_ADDITIONAL_DEFAULT));
						}
						invocieDtoListNew.add(newModel);
						rowCount.add(initialRow);
						summaryCells.importCustomObjects(invocieDtoListNew, invoiceHeaders, false, initialRow, 0,
								invocieDtoListNew.size(), true, "yyyy-mm-dd", true);						
						createNamedRange(sheet,initialRow,newModel.getInvKey().toString());
						
				    							
						if (newModel.getItemDetails() != null && newModel.getItemDetails().size() > 0) {

							summaryCells.importCustomObjects(newModel.getItemDetails(), itemHeaders, false,
									initialRow + 1, 13, newModel.getItemDetails().size(), true, "yyyy-mm-dd", true);
							initialRow += newModel.getItemDetails().size() + 1;

						}
						else{
							
							initialRow++;
						}
					}

				}

				// Increase the offset

				offset ++;
				
				if (listSize < pageSize) {
					break;
				}
			}
			
			createDropDown(sheet, reportType,rowCount);
			
			/*
			 * Create protected sheet
			 */
			sheet.protect(ProtectionType.ALL);

			if(columnEnabling(taxPeriod)){
				int rows = sheet.getCells().getRows().getCount();			
				String cellname=CellsHelper.cellIndexToName(rows-1, 2);				
				// Get the range of cells, which we want to unlock
				Range rangeUnlocked = sheet.getCells().createRange("C3:"+cellname);
				// Add a new style
				/*int styleIndex = workbook.getStyles().add();
				Style styleUnlocked = workbook.getStyles().get(styleIndex);*/
				
				Cell cell = sheet.getCells().get("C3");
				
				Style styleUnlocked = cell.getStyle();
				
				// Unlock cells
				styleUnlocked.setLocked(false);
				rangeUnlocked.setStyle(styleUnlocked);
			}
			
			applyColorSheet(summaryCells, sheet, workbook, initialRow);
			
			/*
			 * Save the report
			 */
			String fileName = "Additional_" + gstin + "_" + taxPeriod + "_" + updatedDate + ".xlsx";
			// "Matched_"+obj.get("gstinId").toString()+obj.get("taxPeriod").toString()+"_"+reconStatus.getUpdatedDate()+".xlsx";
			File folder = new File(filefolder);
			if (workbook != null && initialRow > 2) {
				
				LOGGER.info("Workbook will be created");
				
				if (!folder.exists()) {
					if (!folder.mkdirs()) {
						LOGGER.info("File Path doesn't exists and could not find mounting path");
					} else {
						workbook.save(filefolder.concat(fileName));
						reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.ADDITIONAL_REPORT, "True");
						LOGGER.info(
								"Created directory and Report has been generated and saved in file share" + filefolder);
					}
				} else {
					workbook.save(filefolder.concat(fileName));
					reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.ADDITIONAL_REPORT, "True");
					LOGGER.info(
							"Directory already Exists, Report has been generated and saved in file share" + filefolder);
				}
			}
			
			else{
				
				reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.ADDITIONAL_REPORT, "No Data");
			}
			
			sheet.dispose();
		} catch (Exception e) {
			
			reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.ADDITIONAL_REPORT, "Error");
			LOGGER.error("Exception in generating Additional report" + e);
		}finally{
			if(workbook!=null){
				workbook.dispose();
			}
		}
	}

	private void genrateReconMismatchReport(String gstin, String taxPeriod, int offset, int pageSize, String reportType,
			String updatedDate, URL template_Dir, int initialRow, int listSize, String filefolder,
			List<Integer> rowCount, LoadOptions opt) {
		String reconReportData;
		Workbook workbook=null;
		try {
		LOGGER.info("MIS_MATCHED_REPORT");

		/*
		 * Get Json string from SP
		 */

		List<GSTR2FInvoiceDto> invocieDtoList = null;

		
		LOGGER.info("template_Dir"+template_Dir);
		
		String path = template_Dir.getPath() + "Recon-Mismatch_Records.xlsx";
		
		LOGGER.info("path"+path);
		
		workbook = new Workbook(path, opt);		
		workbook.getSettings().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);                
		Worksheet sheet = workbook.getWorksheets().get(2); 
		sheet.getCells().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);
		sheet.autoFitColumns();
		sheet.autoFitRows();
		Cells summaryCells = workbook.getWorksheets().get(reportType).getCells();
		String[] invoiceHeaders = env.getProperty(Constant.RECON_INVOICE_MISMATCH_HEADER).split(",");
		String[] itemHeaders = env.getProperty(Constant.RECON_LINEITEM_MISMATCH_HEADER).split(",");
		
		LOGGER.info("invoiceHeaders"+invoiceHeaders);
		
		LOGGER.info("itemHeaders"+itemHeaders);

		LOGGER.info("Workbook will be created");
		
		while ((reconReportData = reconStatusDao.getMisMatchedReconRecords(gstin, taxPeriod, offset,
				pageSize)) != null && !reconReportData.trim().isEmpty()) {
			
			

			if (null != reconReportData) {
				
				

				LOGGER.info("reconReportData"+reconReportData);
				
				GSTR2FReconDto recondDto = convertStringToMatchedReconDto(reconReportData);

				// Generate report
				invocieDtoList = recondDto.getB2bInvoices();
				listSize = invocieDtoList.size();
				for (GSTR2FInvoiceDto newModel : invocieDtoList) {

					List<GSTR2FInvoiceDto> invocieDtoListNew = new ArrayList<GSTR2FInvoiceDto>();
					if(!columnEnabling(taxPeriod)){
						newModel.setSuggestedResp("");
						newModel.setClientRes("");
					}else{
						newModel.setClientRes(env.getProperty(Constant.RECON_INVOICE_MISMATCH_DEFAULT));
						newModel.setSuggestedResp(env.getProperty(Constant.RECON_INVOICE_MISMATCH_DEFAULT));
					}
					invocieDtoListNew.add(newModel);
					rowCount.add(initialRow);

					summaryCells.importCustomObjects(invocieDtoListNew, invoiceHeaders, false, initialRow, 0,
							invocieDtoListNew.size(), true, "yyyy-mm-dd", true);

					
					createNamedRange(workbook.getWorksheets().get(2),initialRow,newModel.getInvKey().toString());
					if (newModel.getItemDetails() != null && newModel.getItemDetails().size() > 0) {

						summaryCells.importCustomObjects(newModel.getItemDetails(), itemHeaders, false,
								initialRow + 1, 30, newModel.getItemDetails().size(), true, "yyyy-mm-dd", true);
						initialRow += newModel.getItemDetails().size() + 1;

					}
					else{
						
						initialRow++;
					}
				}

			}

			// Increase the offset

			offset ++;

			if (listSize < pageSize) {
				break;
			}
		}
		createDropDown(workbook.getWorksheets().get(2), reportType ,rowCount);
		/*
		 * Create protected sheet
		 */
		sheet.protect(ProtectionType.ALL);
		if(columnEnabling(taxPeriod)){
			int rows = sheet.getCells().getRows().getCount();			
			String cellname=CellsHelper.cellIndexToName(rows-1, 2);				
			// Get the range of cells, which we want to unlock
			Range rangeUnlocked = sheet.getCells().createRange("C3:"+cellname);
			// Add a new style
			/*int styleIndex = workbook.getStyles().add();
			Style styleUnlocked = workbook.getStyles().get(styleIndex);*/
			
			Cell cell = sheet.getCells().get("C3");
			
			Style styleUnlocked = cell.getStyle();
			
			// Unlock cells
			styleUnlocked.setLocked(false);
			rangeUnlocked.setStyle(styleUnlocked);
		}
		
		applyColorSheet(summaryCells, sheet, workbook, initialRow);
		
		String fileName = "Mismatch_" + gstin + "_" + taxPeriod + "_" + updatedDate + ".xlsx";
		// "Matched_"+obj.get("gstinId").toString()+obj.get("taxPeriod").toString()+"_"+reconStatus.getUpdatedDate()+".xlsx";
		File folder = new File(filefolder);
		if (workbook != null && initialRow > 2) {
			
			LOGGER.info("Workbook will be generated");
			
			if (!folder.exists()) {
				if (!folder.mkdirs()) {
					LOGGER.info("File Path doesn't exists and could not find mounting path");
				} else {
					workbook.save(filefolder.concat(fileName));
					reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MIS_MATCHED_REPORT, "True");
					LOGGER.info(
							"Created directory and Report has been generated and saved in file share" + filefolder);
				}
			} else {
				workbook.save(filefolder.concat(fileName));
				reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MIS_MATCHED_REPORT, "True");
				LOGGER.info(
						"Directory already Exists, Report has been generated and saved in file share" + filefolder);
			}
		}
		
		else{
			reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MIS_MATCHED_REPORT, "No Data");
			
		}
		sheet.dispose();
} catch (Exception e) {
	reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MIS_MATCHED_REPORT, "Error");
		LOGGER.error("Exception in generating MisMatched report" + e);
}finally{
		if(workbook!=null){
			workbook.dispose();
		}
}
	}

	private void generateReconmatchedAspReport(String gstin, String taxPeriod, int offset, int pageSize,
			String reportType, String updatedDate, URL template_Dir, int initialRow, int listSize, String filefolder,
			List<Integer> rowCount, LoadOptions opt) {
		String reconReportData;
		Workbook workbook=null;

		try {
			LOGGER.info("MATCHED_ASP_REPORT");

			/*
			 * Get Json string from SP
			 */

			List<GSTR2FInvoiceDto> invocieDtoList = null;

			
			LOGGER.info("template_Dir"+template_Dir);
			
			String path = template_Dir.getPath() + "Recon-Matched_Records_ASP.xlsx";
			
			LOGGER.info("path"+path);
			
			workbook = new Workbook(path, opt);		
		    workbook.getSettings().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);                
			Worksheet sheet = workbook.getWorksheets().get(2); 
		    sheet.getCells().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);
			sheet.autoFitColumns();
			sheet.autoFitRows();
			Cells summaryCells = workbook.getWorksheets().get(reportType).getCells();
			String[] invoiceHeaders = env.getProperty(Constant.RECON_INVOICE_MATCHASP_HEADER).split(",");
			String[] itemHeaders = env.getProperty(Constant.RECON_LINEITEM_MATCHASP_HEADER).split(",");
			
			LOGGER.info("invoiceHeaders"+invoiceHeaders);
			
			LOGGER.info("itemHeaders"+itemHeaders);

			LOGGER.info("Workbook is getting created");

			
			
			while ((reconReportData = reconStatusDao.getMatchedAspReconRecords(gstin, taxPeriod, offset,
					pageSize)) != null && !reconReportData.trim().isEmpty()) {

				if (null != reconReportData) {
					

					LOGGER.info("reconReportData"+reconReportData);
					
					GSTR2FReconDto recondDto = convertStringToMatchedReconDto(reconReportData);

					// Generate report
					invocieDtoList = recondDto.getB2bInvoices();
					listSize = invocieDtoList.size();
					

					for (GSTR2FInvoiceDto newModel : invocieDtoList) {

						List<GSTR2FInvoiceDto> invocieDtoListNew = new ArrayList<GSTR2FInvoiceDto>();
						if(!columnEnabling(taxPeriod)){
							newModel.setSuggestedResp("");
							newModel.setClientRes("");
						}else{
							newModel.setClientRes(env.getProperty(Constant.RECON_INVOICE_MATCHASP_DEFAULT));
							newModel.setSuggestedResp(env.getProperty(Constant.RECON_INVOICE_MATCHASP_DEFAULT));
						}
						invocieDtoListNew.add(newModel);
						rowCount.add(initialRow);

						summaryCells.importCustomObjects(invocieDtoListNew, invoiceHeaders, false, initialRow, 0,
								invocieDtoListNew.size(), true, "yyyy-mm-dd", true);

						
						createNamedRange(workbook.getWorksheets().get(2),initialRow,newModel.getInvKey().toString());
						if (newModel.getItemDetails() != null && newModel.getItemDetails().size() > 0) {

							summaryCells.importCustomObjects(newModel.getItemDetails(), itemHeaders, false,
									initialRow + 1, 30, newModel.getItemDetails().size(), true, "yyyy-mm-dd", true);
							initialRow += newModel.getItemDetails().size() + 1;

						}
						
						else{
							
							initialRow++;
						}
					}
				}
				// Increase the offset

				offset ++;
				
				if (listSize < pageSize) {
					break;
				}
			}
			/*
			 * Save the report
			 */
			createDropDown(workbook.getWorksheets().get(2), reportType ,rowCount);
			/*
			 * Create protected sheet
			 */
			sheet.protect(ProtectionType.ALL);

			if(columnEnabling(taxPeriod)){
				int rows = sheet.getCells().getRows().getCount();			
				String cellname=CellsHelper.cellIndexToName(rows-1, 2);				
				// Get the range of cells, which we want to unlock
				Range rangeUnlocked = sheet.getCells().createRange("C3:"+cellname);
				// Add a new style
				/*int styleIndex = workbook.getStyles().add();
				Style styleUnlocked = workbook.getStyles().get(styleIndex);*/
				
				Cell cell = sheet.getCells().get("C3");
				
				Style styleUnlocked = cell.getStyle();
				
				// Unlock cells
				styleUnlocked.setLocked(false);
				rangeUnlocked.setStyle(styleUnlocked);
			}
			
			applyColorSheet(summaryCells, sheet, workbook, initialRow);
			
			String fileName = "Matched_Asp_" + gstin + "_" + taxPeriod + "_" + updatedDate + ".xlsx";
			// "Matched_"+obj.get("gstinId").toString()+obj.get("taxPeriod").toString()+"_"+reconStatus.getUpdatedDate()+".xlsx";
			File folder = new File(filefolder);
			if (workbook != null && initialRow > 2) {
				
				LOGGER.info("Workbook will be created");
				
				if (!folder.exists()) {
					if (!folder.mkdirs()) {
						LOGGER.info("File Path doesn't exists and could not find mounting path");
					} else {
						workbook.save(filefolder.concat(fileName));
						reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MATCHED_ASP_REPORT, "True");
						LOGGER.info(
								"Created directory and Report has been generated and saved in file share" + filefolder);
					}
				} else {
					workbook.save(filefolder.concat(fileName));
					reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MATCHED_ASP_REPORT, "True");
					LOGGER.info(
							"Directory already Exists, Report has been generated and saved in file share" + filefolder);
				}
			}
			
			else{
				
				reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MATCHED_ASP_REPORT, "No Data");
			}
			if(workbook!=null){
				workbook.dispose();
			}
			sheet.dispose();
		} catch (Exception e) {
			
			reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MATCHED_ASP_REPORT, "Error");
			LOGGER.error("Exception in generating MatchedAsp report" + e);
		}finally{
			if(workbook!=null){
				workbook.dispose();
			}
		}
	}

	private void generateReconMatchedReport(String gstin, String taxPeriod, int offset, int pageSize, String reportType,
			String updatedDate, URL template_Dir, int initialRow, int listSize, String filefolder,
			List<Integer> rowCount, LoadOptions opt) {
		String reconReportData;
		Workbook workbook = null;

		try {
			LOGGER.info("MATCHED_REPORT");

			/*
			 * Get Json string from SP
			 */
			List<GSTR2FInvoiceDto> invocieDtoList = null;


			LOGGER.info("template_Dir"+template_Dir);
			String path = template_Dir.getPath() + "Recon-Matched_Records.xlsx";
			
			LOGGER.info("path"+path);

			workbook = new Workbook(path, opt);		
		    workbook.getSettings().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);                
			Worksheet sheet = workbook.getWorksheets().get(2); 
		    sheet.getCells().setMemorySetting(MemorySetting.MEMORY_PREFERENCE);
			sheet.autoFitColumns();
			sheet.autoFitRows();
			Cells summaryCells = workbook.getWorksheets().get(reportType).getCells();
			String[] invoiceHeaders = env.getProperty(Constant.RECON_INVOICE_MATCH_HEADER).split(",");
			String[] itemHeaders = env.getProperty(Constant.RECON_LINEITEM_MATCH_HEADER).split(",");

			LOGGER.info("invoiceHeaders"+invoiceHeaders);
			
			LOGGER.info("itemHeaders"+itemHeaders);
			
			LOGGER.info("Workbook has been created");
			
			while ((reconReportData = reconStatusDao.getMatchedReconRecords(gstin, taxPeriod, offset, pageSize)) != null
					&& !reconReportData.trim().isEmpty()) {

				if (null != reconReportData) {
					
					

					LOGGER.info("reconReportData is started converting"+reconReportData);
					
					GSTR2FReconDto recondDto = convertStringToMatchedReconDto(reconReportData);

					// Generate report
					invocieDtoList = recondDto.getB2bInvoices();
					listSize = invocieDtoList.size();

					for (GSTR2FInvoiceDto newModel : invocieDtoList) {

						List<GSTR2FInvoiceDto> invocieDtoListNew = new ArrayList<GSTR2FInvoiceDto>();
						if(!columnEnabling(taxPeriod)){
							newModel.setSuggestedResp("");
							newModel.setClientRes("");
						}else{
							newModel.setClientRes(env.getProperty(Constant.RECON_INVOICE_MATCH_DEFAULT));
							newModel.setSuggestedResp(env.getProperty(Constant.RECON_INVOICE_MATCH_DEFAULT));
						}
						
						invocieDtoListNew.add(newModel);

						summaryCells.importCustomObjects(invocieDtoListNew, invoiceHeaders, false, initialRow, 0,
								invocieDtoListNew.size(), true, "yyyy-mm-dd", true);
						rowCount.add(initialRow);
						
						createNamedRange(workbook.getWorksheets().get(2),initialRow,newModel.getInvKey().toString());					
				    	
						if (newModel.getItemDetails() != null && newModel.getItemDetails().size() > 0) {

							summaryCells.importCustomObjects(newModel.getItemDetails(), itemHeaders, false,
									initialRow + 1, 27, newModel.getItemDetails().size(), true, "yyyy-mm-dd", true);
							initialRow += newModel.getItemDetails().size() + 1;

						}
						
						else{
							
							initialRow++;
						}
					}

				}

				// Increase the offset

				offset ++;

				if (listSize < pageSize) {
					break;
				}
			}
			/*
			 * Save the report
			 */
			createDropDown(workbook.getWorksheets().get(2), reportType ,rowCount);
			/*
			 * Create protected sheet
			 */
			sheet.protect(ProtectionType.ALL);

			if(columnEnabling(taxPeriod)){
				int rows = sheet.getCells().getRows().getCount();			
				String cellname=CellsHelper.cellIndexToName(rows-1, 2);				
				// Get the range of cells, which we want to unlock
				Range rangeUnlocked = sheet.getCells().createRange("C3:"+cellname);
				// Add a new style
				/*int styleIndex = workbook.getStyles().add();
				Style styleUnlocked = workbook.getStyles().get(styleIndex);*/
				
				Cell cell = sheet.getCells().get("C3");
				
				Style styleUnlocked = cell.getStyle();
				
				// Unlock cells
				styleUnlocked.setLocked(false);
				rangeUnlocked.setStyle(styleUnlocked);
			}
			
			applyColorSheet(summaryCells, sheet, workbook, initialRow);
			
			
			String fileName = "Matched_" + gstin + "_" + taxPeriod + "_" + updatedDate + ".xlsx";
			// "Matched_"+obj.get("gstinId").toString()+obj.get("taxPeriod").toString()+"_"+reconStatus.getUpdatedDate()+".xlsx";
			File folder = new File(filefolder);
			if (workbook != null && initialRow > 2) {
				
				LOGGER.info("Workbook is creating with db records");
				
				if (!folder.exists()) {
					if (!folder.mkdirs()) {
						LOGGER.info("File Path doesn't exists and could not find mounting path");
					} else {
						workbook.save(filefolder.concat(fileName));
						reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MATCHED_REPORT, "True");
						LOGGER.info(
								"Created directory and Report has been generated and saved in file share" + filefolder);
					}
				} else {
					workbook.save(filefolder.concat(fileName));
					reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MATCHED_REPORT, "True");
					LOGGER.info(
							"Directory already Exists, Report has been generated and saved in file share" + filefolder);
				}
			}
			else{
				
				reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MATCHED_REPORT, "No Data");
			}
			sheet.dispose();	
		} catch (Exception e) {
			reconStatusDao.updateReconReportStatus(gstin, taxPeriod,Constant.MATCHED_REPORT, "Error");
			LOGGER.error("Exception in generating Matched report" + e);
		}finally{
			if(workbook!=null){
				workbook.dispose();
			}
		}
	}

	/**
	 * This method is to convert String object to MatchedReconDto ojbect.
	 * 
	 * @param reconReportData
	 * @return
	 */
	private GSTR2FReconDto convertStringToMatchedReconDto(String reconReportData) {

		Gson gson = new Gson();
		return gson.fromJson(reconReportData, GSTR2FReconDto.class);
	}

	/**
	 * This method is to create drop down.
	 * 
	 * @param sheet
	 * @param rowNum
	 * @param reportType
	 */
	void createDropDown(Worksheet sheet, String reportType,List<Integer> rowNums) {
		ValidationCollection validations = sheet.getValidations();

		for(int i:rowNums){
		CellArea area = new CellArea();
		area.StartRow = i;
		area.StartColumn = 2;
		area.EndRow = i;
		area.EndColumn = 2;

		// Create a validation object adding to the collection list.
		int index = validations.add(area);
		Validation validation = validations.get(index);
		// Set the validation type.
		validation.setType(ValidationType.LIST);
		// Set the in cell drop down.
		validation.setInCellDropDown(true);
		// Set the Value1.
		if (reportType.equals(Constant.MATCHED_REPORT)) {
			validation.setValue1(env.getProperty(Constant.RECON_INVOICE_MATCH_DROPDOWN));
		} else if (reportType.equals(Constant.MATCHED_ASP_REPORT)) {
			validation.setValue1(env.getProperty(Constant.RECON_INVOICE_MATCHASP_DROPDOWN));
		} else if (reportType.equals(Constant.ADDITIONAL_REPORT)) {
			validation.setValue1(env.getProperty(Constant.RECON_INVOICE_ADDITIONAL_DROPDOWN));
		} else if (reportType.equals(Constant.MIS_MATCHED_REPORT)) {
			validation.setValue1(env.getProperty(Constant.RECON_INVOICE_MATCHASP_DROPDOWN));
		} else if (reportType.equals(Constant.MISSING_REPORT)) {
			validation.setValue1(env.getProperty(Constant.RECON_INVOICE_MISSING_DROPDOWN));
		}

	}
	}
	/**
	 * This method is to create named range.
	 * 
	 * @param sheet
	 * @param rowNum
	 * @param reportType
	 */
	void createNamedRange(Worksheet sheet,int rowNums,String invoiceKey) {
		Cells cells = sheet.getCells();
		
			String cellname=CellsHelper.cellIndexToName(rowNums, 2);
			Range namedRange =cells.createRange(cellname,cellname);
			Cell c=sheet.getCells().get(cellname);
			if(!invoiceKey.equals("") && invoiceKey.length()>0 && invoiceKey!=null)
			namedRange.setName("RECON_"+Pattern.compile("[^A-Za-z0-9]").matcher(invoiceKey).replaceAll(""));
			 
	}
	
	boolean columnEnabling(String taxPeriod) throws java.text.ParseException{
		Date currDate=new Date();	
		Calendar cal=Calendar.getInstance();		
		Date date1=new SimpleDateFormat("MMyyyy").parse(taxPeriod);  
		cal.setTime(date1); 
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DATE, Constant.RECON_DATE);		
		return currDate.after(cal.getTime());
	}
	
	private void applyColorSheet(Cells cells, Worksheet sheet, Workbook workbook,int rowCount) {
		
		/*if(rowCount<=2){
			rowCount=4;
		}
        
        int columnCount = sheet.getCells().getColumns().getCount();
               
        Range cellRange = cells.createRange(2,0,rowCount-2,columnCount);// cells.createRange(0, listSize, true);

        // Add FormatConditions to the instance of Worksheet
        int index = sheet.getConditionalFormattings().add();

        // Access the newly added FormatConditions via its index
        FormatConditionCollection conditionCollection = sheet.getConditionalFormattings().get(index);

        // Define a CellsArea on which conditional formatting will be applicable
        CellArea area = CellArea.createCellArea(2, 0, rowCount-1, columnCount-1);

        // Add area to the instance of FormatConditions
        conditionCollection.addArea(area);

        // Add a condition to the instance of FormatConditions. For this case, the condition type is expression, which is based on
        // some formula
        index = conditionCollection.addCondition(FormatConditionType.EXPRESSION);

        // Access the newly added FormatCondition via its index
        FormatCondition formatCondirion = conditionCollection.get(0);

        // Set the formula for the FormatCondition. Formula uses the Excel's built-in functions as discussed earlier in this
        // article
        formatCondirion.setFormula1("=MOD(ROW(),2)=0");
        formatCondirion.setFormula1("=MOD(ROW(),1)=0");
        Style borderStyle = workbook.getDefaultStyle();
        
        borderStyle.setBorder(BorderType.BOTTOM_BORDER, CellBorderType.THIN,Color.getBlack());
        borderStyle.setBorder(BorderType.LEFT_BORDER, CellBorderType.THIN,Color.getBlack());
        borderStyle.setBorder(BorderType.TOP_BORDER, CellBorderType.THIN,Color.getBlack());
        borderStyle.setBorder(BorderType.RIGHT_BORDER, CellBorderType.THIN,Color.getBlack());
        //borderStyle.setBackgroundColor(Color.fromArgb(214, 214, 194));
        StyleFlag borderStyleFlag = new StyleFlag();
        borderStyleFlag.setBorders(true);
        cellRange.applyStyle(borderStyle, borderStyleFlag);

        // Set the background color and patter for the FormatCondition's Style
         //formatCondirion.getStyle().setBackgroundColor(Color.fromArgb(214, 214, 194));
         formatCondirion.getStyle().setBackgroundColor(Color.getLightGray());*/
        

		/*
		 * Invoice and items styles copied from the templates
		 */
		Range templateRange = cells.createRange("A3", "AR3");
		
		if(rowCount<=2){
			rowCount=4;
		}
		
		int columnCount = sheet.getCells().getColumns().getCount();
        
        Range cellRange = cells.createRange(2,0,rowCount-2,columnCount);
        
        cellRange.copyStyle(templateRange);
        
        /*
         * Set the cell width for amount field to avoid # issue.
         */
        for(int columnIndex=22;columnIndex<=43;columnIndex++){
        	 Column col  = sheet.getCells().getColumns().get(columnIndex);
             col.setWidth(15);
        }
        
        for(int index=2;index<=rowCount;index++){
          	 Column col  = sheet.getCells().getColumns().get(index);
          	 Row r=sheet.getCells().getRows().get(index);
             r.setHeight(15);
          }
          
        //Delete last empty row
        sheet.getCells().deleteRow(rowCount);
	
	}
	@Override
	public List<String> getErrorReportDetails(JSONObject jsonObj){
	
		List<String> errorData= (List<String>)reportDao.getGstr2AReportDetails(jsonObj);
		
		return	errorData;
	} 
}
