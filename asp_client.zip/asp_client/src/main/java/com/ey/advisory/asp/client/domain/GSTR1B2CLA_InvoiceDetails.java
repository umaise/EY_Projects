package com.ey.advisory.asp.client.domain;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the tblB2CLAInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2CLAInvoiceDetails", schema="gstr1")
public class GSTR1B2CLA_InvoiceDetails implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	public String getOrgInvNum() {
		return orgInvNum;
	}

	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	public Date getOrgInvDate() {
		return orgInvDate;
	}

	public void setOrgInvDate(Date orgInvDate) {
		this.orgInvDate = orgInvDate;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Date getOrderDt() {
		return orderDt;
	}

	public void setOrderDt(Date orderDt) {
		this.orderDt = orderDt;
	}

	public String getEtin() {
		return etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) 
	@Column(name="ID")
	private long id;
	
	@Column(name="CustStateCd")
	private String stateCd;
	
	@Column(name="Flag")
	private Character flag;

	@Column(name="ChkSum")
	private String chkSum;
	
	@Column(name="Custname")
	private String custName;
	
	@Column(name="InvNum")
	private String invNum;
	
	@Column(name="InvDate")
	private Date invDate;
	
	@Column(name="InvValue")
	private BigDecimal invValue;
	
	@Column(name="TaxableValue")
	private BigDecimal taxableValue;
	
	@Column(name="POS")
	private String pos;
	
	@Column(name="Rchrg")
	private String rchrg;
	
	@Column(name="ProvAsses")
	private String provAsses;
	
	@Column(name="OrgInvNum")
	private String orgInvNum;
	
	@Column(name="OrgInvDate")
	private Date orgInvDate;
	
	@Column(name="OrderNo")
	private String orderNo;
	
	@Column(name="OrderDt")
	private Date orderDt;
	
	@Column(name="Etin")
	private String etin;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="FileID")
	private long fileId;
	
	@Column(name="IsDelete")
	private boolean isDelete;
	
	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStateCd() {
		return this.stateCd;
	}

	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}

	public Character getFlag() {
		return this.flag;
	}

	public void setFlag(Character flag) {
		this.flag = flag;
	}

	public String getCustName() {
		return this.custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getInvNum() {
		return this.invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public Date getInvDate() {
		return this.invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public BigDecimal getInvValue() {
		return this.invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public BigDecimal getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(BigDecimal taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getPos() {
		return this.pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getRchrg() {
		return rchrg;
	}

	public void setRchrg(String rchrg) {
		this.rchrg = rchrg;
	}

	public String getProvAsses() {
		return this.provAsses;
	}

	public void setProvAsses(String provAsses) {
		this.provAsses = provAsses;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public long getFileId() {
		return this.fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}
	

}
