package com.ey.advisory.asp.client.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.google.gson.annotations.SerializedName;

public class OutwardInvoiceDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@SerializedName("uk")
	private String redisKey;
	@SerializedName("gstr1")
	private List<OutwardInvoiceModel> lineItemList;
	private String invStatus;
	private String tableType;
	private Set<TblSalesErrorInfo> errorList;
	private String groupCode;
	private boolean skipAmendmentCheck;
	private boolean isMultipleSupplyType;
	
	public List<OutwardInvoiceModel> getLineItemList() {
		return lineItemList;
	}
	public void setLineItemList(List<OutwardInvoiceModel> lineItemList) {
		this.lineItemList = lineItemList;
	}
	public String getInvStatus() {
		return invStatus;
	}
	public void setInvStatus(String invStatus) {
		this.invStatus = invStatus;
	}
	public String getTableType() {
		return tableType;
	}
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	public Set<TblSalesErrorInfo> getErrorList() {
		return errorList;
	}
	public void setErrorList(Set<TblSalesErrorInfo> errorList) {
		this.errorList = errorList;
	}
	public String getRedisKey() {
		return redisKey;
	}
	public void setRedisKey(String redisKey) {
		this.redisKey = redisKey;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
    public boolean isSkipAmendmentCheck() {
        return skipAmendmentCheck;
    }
    public void setSkipAmendmentCheck(boolean skipAmendmentCheck) {
        this.skipAmendmentCheck = skipAmendmentCheck;
    }
    public boolean isMultipleSupplyType() {
		return isMultipleSupplyType;
	}
	public void setMultipleSupplyType(boolean isMultipleSupplyType) {
		this.isMultipleSupplyType = isMultipleSupplyType;
	}
	

}
