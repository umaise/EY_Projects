package com.ey.advisory.asp.client.dto;

import java.lang.reflect.InvocationTargetException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.ey.advisory.asp.common.Constant;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
 
/**
 * 
 * Root DTO for GSTR3.
 *
 */
public class GSTR3RootDTO {

	/*First thing first LOGGER*/
	private static final Logger LOGGER = Logger.getLogger(GSTR3RootDTO.class);
	private static final String CLASS_NAME = GSTR3RootDTO.class.getName();
	
	private String gstin;
	private ISup i_sup;
	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	private String ret_period;

	public String getRetPeriod() {
		return this.ret_period;
	}

	public void setRetPeriod(String ret_period) {
		this.ret_period = ret_period;
	}

	private ArrayList<Tod> tod;

	public ArrayList<Tod> getTod() {
		return this.tod;
	}

	public void setTod(ArrayList<Tod> tod) {
		this.tod = tod;
	}

	private Osup osup;

	public Osup getOsup() {
		return this.osup;
	}

	public void setOsup(Osup osup) {
		this.osup = osup;
	}

 

	public ISup getI_sup() {
		return i_sup;
	}

	public void setI_sup(ISup i_sup) {
		this.i_sup = i_sup;
	}

	public String getRet_period() {
		return ret_period;
	}

	public void setRet_period(String ret_period) {
		this.ret_period = ret_period;
	}

	public ItcCr getItc_cr() {
		return itc_cr;
	}

	public void setItc_cr(ItcCr itc_cr) {
		this.itc_cr = itc_cr;
	}

	public TcsCr getTcs_cr() {
		return tcs_cr;
	}

	public void setTcs_cr(TcsCr tcs_cr) {
		this.tcs_cr = tcs_cr;
	}

	public TdsCr getTds_cr() {
		return tds_cr;
	}

	public void setTds_cr(TdsCr tds_cr) {
		this.tds_cr = tds_cr;
	}

	public IntrLiab getIntr_liab() {
		return intr_liab;
	}

	public void setIntr_liab(IntrLiab intr_liab) {
		this.intr_liab = intr_liab;
	}

	public LtFee getLt_fee() {
		return lt_fee;
	}

	public void setLt_fee(LtFee lt_fee) {
		this.lt_fee = lt_fee;
	}

	public TxOffset getTx_offset() {
		return tx_offset;
	}

	public void setTx_offset(TxOffset tx_offset) {
		this.tx_offset = tx_offset;
	}

	public ArrayList<IntrOffset> getIntr_offset() {
		return intr_offset;
	}

	public void setIntr_offset(ArrayList<IntrOffset> intr_offset) {
		this.intr_offset = intr_offset;
	}

	public ArrayList<LfeeOffset> getLfee_offset() {
		return lfee_offset;
	}

	public void setLfee_offset(ArrayList<LfeeOffset> lfee_offset) {
		this.lfee_offset = lfee_offset;
	}

	public LdgDebitEntries getLdg_debit_entries() {
		return ldg_debit_entries;
	}

	public void setLdg_debit_entries(LdgDebitEntries ldg_debit_entries) {
		this.ldg_debit_entries = ldg_debit_entries;
	}

	private ItcCr itc_cr;

	public ItcCr getItcCr() {
		return this.itc_cr;
	}

	public void setItcCr(ItcCr itc_cr) {
		this.itc_cr = itc_cr;
	}

	private Mis mis;

	public Mis getMis() {
		return this.mis;
	}

	public void setMis(Mis mis) {
		this.mis = mis;
	}

	private Ttxl ttxl;

	public Ttxl getTtxl() {
		return this.ttxl;
	}

	public void setTtxl(Ttxl ttxl) {
		this.ttxl = ttxl;
	}

	private TcsCr tcs_cr;

	public TcsCr getTcsCr() {
		return this.tcs_cr;
	}

	public void setTcsCr(TcsCr tcs_cr) {
		this.tcs_cr = tcs_cr;
	}

	private TdsCr tds_cr;

	public TdsCr getTdsCr() {
		return this.tds_cr;
	}

	public void setTdsCr(TdsCr tds_cr) {
		this.tds_cr = tds_cr;
	}

	private IntrLiab intr_liab;

	public IntrLiab getIntrLiab() {
		return this.intr_liab;
	}

	public void setIntrLiab(IntrLiab intr_liab) {
		this.intr_liab = intr_liab;
	}

	private LtFee lt_fee;

	public LtFee getLtFee() {
		return this.lt_fee;
	}

	public void setLtFee(LtFee lt_fee) {
		this.lt_fee = lt_fee;
	}

	private TxOffset tx_offset;

	public TxOffset getTxOffset() {
		return this.tx_offset;
	}

	public void setTxOffset(TxOffset tx_offset) {
		this.tx_offset = tx_offset;
	}

	private ArrayList<IntrOffset> intr_offset;

	public ArrayList<IntrOffset> getIntrOffset() {
		return this.intr_offset;
	}

	public void setIntrOffset(ArrayList<IntrOffset> intr_offset) {
		this.intr_offset = intr_offset;
	}

	private ArrayList<LfeeOffset> lfee_offset;

	public ArrayList<LfeeOffset> getLfeeOffset() {
		return this.lfee_offset;
	}

	public void setLfeeOffset(ArrayList<LfeeOffset> lfee_offset) {
		this.lfee_offset = lfee_offset;
	}

	private Refclm refclm;

	public Refclm getRefclm() {
		return this.refclm;
	}

	public void setRefclm(Refclm refclm) {
		this.refclm = refclm;

	}

	private LdgDebitEntries ldg_debit_entries;

	public LdgDebitEntries getLdgDebitEntries() {
		return this.ldg_debit_entries;
	}

	public void setLdgDebitEntries(LdgDebitEntries ldg_debit_entries) {
		this.ldg_debit_entries = ldg_debit_entries;
	}

	// Method to populate the DTO
	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		

		List<Map<String, Object>> listT3 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_3);
		this.tod = new ArrayList<Tod>();
		Tod tods = new Tod();
		for (Map<String, Object> map : listT3) {

			if (map.get(Constant.GROUP).equals(Constant.TABLE_3_1)) {

				if (map.get(Constant.TURNOVER) != null)
					tods.setTxbleTo(Double.valueOf(map.get(Constant.TURNOVER)
							.toString()));
			} else if (map.get(Constant.GROUP).equals(Constant.TABLE_3_2)) {

				if (map.get(Constant.TURNOVER) != null)
					tods.setZrspTo(Double.valueOf(map.get(Constant.TURNOVER)
							.toString()));
			} else if (map.get(Constant.GROUP).equals(Constant.TABLE_3_3)) {

				if (map.get(Constant.TURNOVER) != null)
					tods.setZrswpTo(Double.valueOf((String) map.get(
							Constant.TURNOVER).toString()));
			} else if (map.get(Constant.GROUP).equals(Constant.TABLE_3_4)) {

				if (map.get(Constant.TURNOVER) != null)
					tods.setExpTo(Double.valueOf(map.get(Constant.TURNOVER)
							.toString()));
			} else if (map.get(Constant.GROUP).equals(Constant.TABLE_3_6)) {

				if (map.get(Constant.TURNOVER) != null)
					tods.setNilTo(Double.valueOf(map.get(Constant.TURNOVER)
							.toString()));
			} else if (map.get(Constant.GROUP).equals(Constant.TABLE_3_5)) {

				if (map.get(Constant.TURNOVER) != null)
					tods.setExmptdTo(Double.valueOf(map.get(Constant.TURNOVER)
							.toString()));
			} else if (map.get(Constant.GROUP).equals(Constant.TABLE_3_7)) {

				if (map.get(Constant.TURNOVER) != null)
					tods.setNonTo(Double.valueOf(map.get(Constant.TURNOVER)
							.toString()));
			}
			else if (map.get(Constant.GROUP).equals(Constant.TABLE_3_8)) {

				if (map.get(Constant.TURNOVER) != null)
					tods.setNet_to(Double.valueOf(map.get(Constant.TURNOVER)
							.toString()));
			}
			/*
			 * else if (map.get(Constant.GROUP).equals(Constant.TABLE_3_8)) {
			 * 
			 * if(map.get(Constant) != null)
			 * tods.setTxbleTo(Double.valueOf(map.get
			 * (Constant.TAXABLE_TO).toString())); }
			 */

		}
		tod.add(tods);

		if (osup == null)
			osup = new Osup();
		osup.populateRootDTO(mapGroupByTableType);
		if (i_sup == null)
			i_sup = new ISup();
		i_sup.populateRootDTO(mapGroupByTableType);

		
		if (itc_cr == null)
			itc_cr = new ItcCr();
		itc_cr.populateRootDTO(mapGroupByTableType);
		if (mis == null)
			mis = new Mis();
		mis.populateRootDTO(mapGroupByTableType);
		if (ttxl == null)
			ttxl = new Ttxl();
		
		ttxl.populateRootDTO(mapGroupByTableType);
		if (tcs_cr == null) {
			tcs_cr = new TcsCr();
		}
		tcs_cr.populateRootDTO(mapGroupByTableType);
		if (tds_cr == null)
			tds_cr = new TdsCr();
		tds_cr.populateRootDTO(mapGroupByTableType);
		if (intr_liab == null)
			intr_liab = new IntrLiab();
		intr_liab.populateRootDTO(mapGroupByTableType);
		if (lt_fee == null)
			lt_fee = new LtFee();
		lt_fee.populateRootDTO(mapGroupByTableType);
		if (tx_offset == null)
			tx_offset = new TxOffset();
		tx_offset.populateRootDTO(mapGroupByTableType);
		
		
		//populating the list
		this.intr_offset = new ArrayList<IntrOffset>();
		this.lfee_offset = new ArrayList<LfeeOffset>();
		
		List<Map<String, Object>> listT13 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_13);
		if(listT13 != null)
		for (Map<String, Object> map : listT13) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_13_1_D)) {
				
				IntrOffset intr_offsets=new IntrOffset();
				intr_offsets.populateRootDTO(map);
				this.intr_offset.add(intr_offsets);
				
			}
			
			else if (map.get(Constant.GROUP).equals(Constant.TABLE_13_2_D)) {
				LfeeOffset lfeeoffsets=new LfeeOffset();
				lfeeoffsets.populateRootDTO(map);
				this.lfee_offset.add(lfeeoffsets);
			}
		}		
		
		if (refclm == null)
			refclm = new Refclm();		
		refclm.populateRootDTO(mapGroupByTableType);
		if(ldg_debit_entries == null)
			ldg_debit_entries=new LdgDebitEntries();
		ldg_debit_entries.populateRootDTO(mapGroupByTableType);

	}

	// Method to Insert
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {
		List<String> list = new ArrayList<String>();
		
      if(this.tod != null){
		for(Tod tdetail:tod){
			list.addAll(tdetail.fetchInsertScripts(masterID, tileMap));
		} 
      }
		
      if(this.osup != null)
		list.addAll(this.osup.fetchInsertScripts(masterID, tileMap));
		
		if(this.i_sup != null)
		list.addAll(this.i_sup.fetchInsertScripts(masterID, tileMap));
		
		if(this.itc_cr != null)
		list.addAll(this.itc_cr.fetchInsertScripts(masterID, tileMap));

		if(this.mis != null)
		list.addAll(this.mis.fetchInsertScripts(masterID, tileMap));
		
		if(this.ttxl != null)
		list.addAll(this.ttxl.fetchInsertScripts(masterID, tileMap));

		if(this.tcs_cr != null)
		list.addAll(this.tcs_cr.fetchInsertScripts(masterID, tileMap));
		
		if(this.tds_cr != null)
		list.addAll(this.tds_cr.fetchInsertScripts(masterID, tileMap));
		
		if(this.intr_liab != null)
		list.addAll(this.intr_liab.fetchInsertScripts(masterID, tileMap));
		
		if(this.lt_fee != null)
		list.addAll(this.lt_fee.fetchInsertScripts(masterID, tileMap));
		
		if(this.tx_offset != null)
		list.addAll(this.tx_offset.fetchInsertScripts(masterID, tileMap));

		
		if(this.intr_offset != null)
		for (IntrOffset intr_Offset : intr_offset) {
			intr_Offset.fetchInsertScripts(masterID, tileMap);
		}
		
		if(this.lfee_offset != null)
		for (LfeeOffset lfee_Offset : lfee_offset) {
			lfee_Offset.fetchInsertScripts(masterID, tileMap);
		}

		if(this.refclm != null)
		list.addAll(this.refclm.fetchInsertScripts(masterID, tileMap)); 

		if(this.ldg_debit_entries != null)
		list.addAll(this.ldg_debit_entries
				.fetchInsertScripts(masterID, tileMap));

		return list;
	}
	
	
	@Override
	public String toString() {
		return "GSTR3RootDTO [gstin=" + gstin + ", i_sup=" + i_sup
				+ ", ret_period=" + ret_period + ", tod=" + tod + ", osup="
				+ osup + ", itc_cr=" + itc_cr + ", mis=" + mis + ", ttxl="
				+ ttxl + ", tcs_cr=" + tcs_cr + ", tds_cr=" + tds_cr
				+ ", intr_liab=" + intr_liab + ", lt_fee=" + lt_fee
				+ ", tx_offset=" + tx_offset + ", intr_offset=" + intr_offset
				+ ", lfee_offset=" + lfee_offset + ", refclm=" + refclm
				+ ", ldg_debit_entries=" + ldg_debit_entries + "]";
	}


	public static class DTOUtil{
		
		/**
		 * Parses the JSON body and populates the DTO 
		 * 
		 * @param jsonBody
		 * @return dto object
		 * @throws SecurityException 
		 * @throws NoSuchMethodException 
		 * @throws InvocationTargetException 
		 * @throws IllegalArgumentException 
		 * @throws IllegalAccessException 
		 * @throws InstantiationException 
		 */
		public static Object parseJsonToDTO(String jsonBodyString, Class clazz)
				throws InstantiationException, IllegalAccessException,
				IllegalArgumentException, InvocationTargetException,
				NoSuchMethodException, SecurityException {
			Gson gson = new Gson();
			 Object obj = clazz.getConstructor().newInstance();
			try {
			 	obj = gson.fromJson(jsonBodyString, clazz);
			} catch (JsonSyntaxException e) {
				//TODO log exception
				LOGGER.error(Constant.LOGGER_EXITING
						+ CLASS_NAME
						+ " Error Encountered while parsing JSON to DTO Method : parseJsonToDTO");
			}
			return obj;
			
		}
		
		/**
		 * Parses the DTO values and creates corresponding Json string
		 * 
		 * @param dto
		 * @return
		 */
		
		public static String parseDTOtoJson(Object dto){
			Gson gson = new Gson();
			String jsonInString = null;
			try {
				jsonInString = gson.toJson(dto);
				
			} catch (Exception e) {
				//TODO log exception
			}
			return jsonInString;
		}
			
		public static String doDynamicCalculation(String message, String cashITCJSON){

			try {

			GSTR3RootDTO gstr3RootDTO = null;
				gstr3RootDTO = (GSTR3RootDTO) parseJsonToDTO(message,
						GSTR3RootDTO.class);
			
				/*********************
				 * TOD**************** Calculate Gross Turnover, Net Taxable
				 */
					((Tod) gstr3RootDTO.getTod().get(0))
							.setGnet_to(gstr3RootDTO.getTod().get(0).getNetTo()); // tod_0_gnet_to
				 
				  /*tod_0_net_txble  == tod-0-non_to*/		
				
					((Tod) gstr3RootDTO.getTod().get(0))
							.setNet_txble(((Tod) gstr3RootDTO.getTod().get(0))
									.getGnet_to()
									
									- gstr3RootDTO.getTod().get(0).getNon_to());
				
	/*			Calculate Gross Turnover, Net Taxable
					((Tod) gstr3RootDTO.getTod().get(0))
							.setGnet_to(gstr3RootDTO.getTod().get(0).getNetTo());
				
					((Tod) gstr3RootDTO.getTod().get(0))
							.setNet_txble(((Tod) gstr3RootDTO.getTod().get(0))
									.getNet_to()
									- gstr3RootDTO.getTod().get(0).getNetTo());
				
				Calculate Gross Turnover, Net Taxable
					((Tod) gstr3RootDTO.getTod().get(0))
							.setGnet_to(gstr3RootDTO.getTod().get(0).getNetTo());
				
					((Tod) gstr3RootDTO.getTod().get(0))
							.setNet_txble(((Tod) gstr3RootDTO.getTod().get(0))
									.getNet_to()
									- gstr3RootDTO.getTod().get(0).getNetTo());
				
				Calculate Gross Turnover, Net Taxable
					((Tod) gstr3RootDTO.getTod().get(0))
							.setGnet_to(gstr3RootDTO.getTod().get(0).getNetTo());
				
					((Tod) gstr3RootDTO.getTod().get(0))
							.setNet_txble(((Tod) gstr3RootDTO.getTod().get(0))
									.getNet_to()
									- gstr3RootDTO.getTod().get(0).getNetTo());
	*/			
			/*	Calculate Gross Turnover, Net Taxable
					((Tod) gstr3RootDTO.getTod().get(0))
							.setGnet_to(gstr3RootDTO.getTod().get(0).getNetTo());
				
					((Tod) gstr3RootDTO.getTod().get(0))
							.setNet_txble(((Tod) gstr3RootDTO.getTod().get(0))
									.getNet_to()
									- gstr3RootDTO.getTod().get(0).getNetTo());
				
				Calculate Gross Turnover, Net Taxable
					((Tod) gstr3RootDTO.getTod().get(0))
							.setGnet_to(gstr3RootDTO.getTod().get(0).getNetTo());
				
					((Tod) gstr3RootDTO.getTod().get(0))
							.setNet_txble(((Tod) gstr3RootDTO.getTod().get(0))
									.getNet_to()
									- gstr3RootDTO.getTod().get(0).getNetTo());
				
				Calculate Gross Turnover, Net Taxable
					((Tod) gstr3RootDTO.getTod().get(0))
							.setGnet_to(gstr3RootDTO.getTod().get(0).getNetTo());
				
					((Tod) gstr3RootDTO.getTod().get(0))
							.setNet_txble(((Tod) gstr3RootDTO.getTod().get(0))
									.getNet_to()
									- gstr3RootDTO.getTod().get(0).getNetTo());
			*/
			
			/*TOD OVER*/
			
			/*Outward Supplies */
			
			/*Main Section Details */
			double osup_ttl_igst = 0.00;
			double osup_ttl_cgst = 0.00;
			double osup_ttl_sgst = 0.00;
			double osup_ttl_cess = 0.00;
			double osup_ttl_igst_amendments = 0.00;
			double osup_ttl_cgst_amendments = 0.00;
			double osup_ttl_sgst_amendments = 0.00;
			double osup_ttl_cess_amendments = 0.00;
			
			/*Taxable Supply Essential Inter*/
			String txr;
			double ttl_inter_outwards = 0.00;
			double ttl_intra_outwards = 0.00;
			
			double ttl_inter_amendments = 0.00;
			double ttl_intra_amendments = 0.00;
			

			Map<String, Map<String, Double[]>> custom_4a_tiles = new HashMap<String, Map<String, Double[]>>();
			Map<String, Double[]> custom_4a_outwards_taxsup = new HashMap<String, Double[]>();
			Map<String, Double[]> custom_4a_outwards_ecomm = new HashMap<String, Double[]>();
			Map<String, Double[]> custom_4a_outwards_rev_sup = new HashMap<String, Double[]>();
			Map<String, Double[]> custom_4a_outwards_zr_sup_wp = new HashMap<String, Double[]>();
			
			Map<String, Double[]> custom_4a_amendments_taxsup = new HashMap<String, Double[]>();
			Map<String, Double[]> custom_4a_amendments_ecomm = new HashMap<String, Double[]>();
			Map<String, Double[]> custom_4a_amendments_rev_sup = new HashMap<String, Double[]>();
			Map<String, Double[]> custom_4a_amendments_zr_sup_wp = new HashMap<String, Double[]>();
			
			custom_4a_tiles.put("outwards_tax_sup", custom_4a_outwards_taxsup); 
			custom_4a_tiles.put("outwards_ecomm", custom_4a_outwards_ecomm); 
			custom_4a_tiles.put("outwards_rev_sup", custom_4a_outwards_rev_sup); 
			custom_4a_tiles.put("outwards_zr_sup_wp", custom_4a_outwards_zr_sup_wp); 
			
			custom_4a_tiles.put("amendments_tax_sup", custom_4a_amendments_taxsup); 
			custom_4a_tiles.put("amendments_ecomm", custom_4a_amendments_ecomm); 
			custom_4a_tiles.put("amendments_rev_sup", custom_4a_amendments_rev_sup); 
			custom_4a_tiles.put("amendments_zr_sup_wp", custom_4a_amendments_zr_sup_wp); 
			
			ArrayList<TaxSup> TaxSupList =  gstr3RootDTO.getOsup().getInter().getTaxSup();
			ArrayList<TaxSup4> TaxSup4List =  gstr3RootDTO.getOsup().getIntra().getTaxSup();
			
			Double[] temp = new Double[2];
			
			for(Iterator iterator = TaxSupList.iterator(); iterator
					.hasNext();) {
				TaxSup taxSup  = (TaxSup) iterator.next();
				temp = (Double[]) custom_4a_outwards_taxsup.get(taxSup.getTx_r());
				
				osup_ttl_igst = osup_ttl_igst + taxSup.getIamt();
				osup_ttl_cgst = osup_ttl_cgst + taxSup.getCamt();
				osup_ttl_sgst = osup_ttl_sgst + taxSup.getSamt();
				osup_ttl_cess = osup_ttl_cess + taxSup.getCess();
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[0] = temp[0] + taxSup.getTxval();
				ttl_inter_outwards = ttl_inter_outwards + temp[0];
				if(custom_4a_outwards_taxsup.containsKey(taxSup.getTx_r())){
					custom_4a_outwards_taxsup.put(taxSup.getTx_r(), temp);  
				} else {
					custom_4a_outwards_taxsup.put(taxSup.getTx_r(), temp);
				}
			}
			temp = new Double[2];
			for(Iterator iterator = TaxSup4List.iterator(); iterator
					.hasNext();) {
				TaxSup4 tmp  = (TaxSup4) iterator.next();
				osup_ttl_igst = osup_ttl_igst + tmp.getIamt();
				osup_ttl_cgst = osup_ttl_cgst + tmp.getCamt();
				osup_ttl_sgst = osup_ttl_sgst + tmp.getSamt();
				osup_ttl_cess = osup_ttl_cess + tmp.getCess();
				temp = (Double[]) custom_4a_outwards_taxsup.get(Double.valueOf(tmp.getTx_r()).toString());
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[1] = temp[1] + tmp.getTxval();
				ttl_intra_outwards = ttl_intra_outwards + temp[1];
				if(custom_4a_outwards_taxsup.containsKey(Double.valueOf(tmp.getTx_r()).toString())){
					custom_4a_outwards_taxsup.put(Double.valueOf(tmp.getTx_r()).toString(), temp);  
				} else {
					custom_4a_outwards_taxsup.put(Double.valueOf(tmp.getTx_r()).toString(), temp);
				}
			}
			
			
			ArrayList<EcommSup> EcommSupList =  gstr3RootDTO.getOsup().getInter().getEcommSup();
			ArrayList<EcommSup4> EcommSup4List =  gstr3RootDTO.getOsup().getIntra().getEcommSup();
			
			temp = new Double[2];
			
			for(Iterator iterator = EcommSupList.iterator(); iterator
					.hasNext();) {
				EcommSup tmp  = (EcommSup) iterator.next();
				osup_ttl_igst = osup_ttl_igst + tmp.getIamt();
				osup_ttl_cgst = osup_ttl_cgst + tmp.getCamt();
				osup_ttl_sgst = osup_ttl_sgst + tmp.getSamt();
				osup_ttl_cess = osup_ttl_cess + tmp.getCess();
				temp = (Double[]) custom_4a_outwards_ecomm.get(Double.valueOf(tmp.getTx_r()).toString());
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[0] = temp[0] + tmp.getTxval();
				ttl_inter_outwards = ttl_inter_outwards + temp[0];
				if(custom_4a_outwards_ecomm.containsKey(Double.valueOf(tmp.getTx_r()).toString())){
					custom_4a_outwards_ecomm.put(Double.valueOf(tmp.getTx_r()).toString(), temp);  
				} else {
					custom_4a_outwards_ecomm.put(Double.valueOf(tmp.getTx_r()).toString(), temp);
				}
			}
			temp = new Double[2];
			for(Iterator iterator = EcommSup4List.iterator(); iterator
					.hasNext();) {
				EcommSup4 tmp  = (EcommSup4) iterator.next();
				temp = (Double[]) custom_4a_outwards_ecomm.get(Double.valueOf(tmp.getTx_r()).toString());
				osup_ttl_igst = osup_ttl_igst + tmp.getIamt();
				osup_ttl_cgst = osup_ttl_cgst + tmp.getCamt();
				osup_ttl_sgst = osup_ttl_sgst + tmp.getSamt();
				osup_ttl_cess = osup_ttl_cess + tmp.getCess();
				
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[1] = temp[1] + tmp.getTxval();
				ttl_intra_outwards = ttl_intra_outwards + temp[1];
				if(custom_4a_outwards_taxsup.containsKey(Double.valueOf(tmp.getTx_r()).toString())){
					custom_4a_outwards_ecomm.put(Double.valueOf(tmp.getTx_r()).toString(), temp);  
				} else {
					custom_4a_outwards_ecomm.put(Double.valueOf(tmp.getTx_r()).toString(), temp);
				}
			}
			temp = new Double[2];
			RevSup RevSup =  gstr3RootDTO.getOsup().getInter().getRevSup();
			osup_ttl_igst = osup_ttl_igst + RevSup.getIamt();
			osup_ttl_cgst = osup_ttl_cgst + RevSup.getCamt();
			osup_ttl_sgst = osup_ttl_sgst + RevSup.getSamt();
			osup_ttl_cess = osup_ttl_cess + RevSup.getCess();
			
			RevSup2 RevSup2 =  gstr3RootDTO.getOsup().getIntra().getRevSup();
			osup_ttl_igst = osup_ttl_igst + RevSup2.getIamt();
			osup_ttl_cgst = osup_ttl_cgst + RevSup2.getCamt();
			osup_ttl_sgst = osup_ttl_sgst + RevSup2.getSamt();
			osup_ttl_cess = osup_ttl_cess + RevSup2.getCess();
			
			temp[0] = RevSup.getTxval();
			temp[1] = RevSup2.getTxval();
			custom_4a_outwards_rev_sup.put(RevSup.getTx_r(), temp);
			ttl_inter_outwards = ttl_inter_outwards + RevSup.getTxval();
			ttl_intra_outwards = ttl_intra_outwards + RevSup2.getTxval();
		
			// Expectation is to have only Object, as per current JSON
			//RevSup RevSup =  gstr3RootDTO.getOsup().getInter().getRevSup();
			ArrayList<ZrSupWp> ZrSupWpList =  gstr3RootDTO.getOsup().getInter().getZrSupWp();
			
			temp = new Double[2];
			
			for(Iterator iterator = ZrSupWpList.iterator(); iterator
					.hasNext();) {
				ZrSupWp tmp  = (ZrSupWp) iterator.next();
				osup_ttl_igst = osup_ttl_igst + tmp.getIamt();
				osup_ttl_cgst = osup_ttl_cgst + tmp.getCamt();
				osup_ttl_sgst = osup_ttl_sgst + tmp.getSamt();
				osup_ttl_cess = osup_ttl_cess + tmp.getCess();
					temp = (Double[]) custom_4a_outwards_zr_sup_wp.get(Double.valueOf(tmp.getTx_r()).toString());
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[0] = temp[0] + tmp.getTxval();
				ttl_inter_outwards = ttl_inter_outwards + temp[0];
				if(custom_4a_outwards_zr_sup_wp.containsKey(Double.valueOf(tmp.getTx_r()).toString())){
					custom_4a_outwards_zr_sup_wp.put(Double.valueOf(tmp.getTx_r()).toString(), temp);  
				} else {
					custom_4a_outwards_zr_sup_wp.put(Double.valueOf(tmp.getTx_r()).toString(), temp);
				}
			}
			
			gstr3RootDTO.getOsup().setCustom_4a_tiles(custom_4a_tiles);
			gstr3RootDTO.getOsup().setTtl_inter_outwards(ttl_inter_outwards);
			gstr3RootDTO.getOsup().setTtl_intra_outwards(ttl_intra_outwards);
			
			/*Outward Supply Ends*/
			
			
			/*Amendment to Outwards*/
			
			ArrayList<TaxSup2> TaxSupAmendList =  gstr3RootDTO.getOsup().getOutAmend().getInter().getTaxSup();
			ArrayList<TaxSup3> TaxSupAmend3List =  gstr3RootDTO.getOsup().getOutAmend().getIntra().getTaxSup();
			
			temp = new Double[2];
			
			for(Iterator iterator = TaxSupAmendList.iterator(); iterator
					.hasNext();) {
				TaxSup2 taxSup  = (TaxSup2) iterator.next();
				osup_ttl_igst_amendments = osup_ttl_igst_amendments + taxSup.getIamt();
				osup_ttl_cgst_amendments = osup_ttl_cgst_amendments + taxSup.getCamt();
				osup_ttl_sgst_amendments = osup_ttl_sgst_amendments + taxSup.getSamt();
				osup_ttl_cess_amendments = osup_ttl_cess_amendments + taxSup.getCsamt();
				temp = (Double[]) custom_4a_amendments_taxsup.get(Double.valueOf(taxSup.getTx_r()).toString());
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[0] = temp[0] + taxSup.getDiffVal();
				ttl_inter_amendments = ttl_inter_amendments + temp[0];
				if(custom_4a_amendments_taxsup.containsKey(Double.valueOf(taxSup.getTx_r()))){
					custom_4a_amendments_taxsup.put(Double.valueOf(taxSup.getTx_r()).toString(), temp);  
				} else {
					custom_4a_amendments_taxsup.put(Double.valueOf(taxSup.getTx_r()).toString(), temp);
				}
			}
			temp = new Double[2];
			for(Iterator iterator = TaxSupAmend3List.iterator(); iterator
					.hasNext();) {
				TaxSup3 tmp  = (TaxSup3) iterator.next();
				osup_ttl_igst_amendments = osup_ttl_igst_amendments  + tmp.getIamt();
				osup_ttl_cgst_amendments = osup_ttl_cgst_amendments + tmp.getCamt();
				osup_ttl_sgst_amendments = osup_ttl_sgst_amendments + tmp.getSamt();
				osup_ttl_cess_amendments = osup_ttl_cess_amendments + tmp.getCsamt();
				temp = (Double[]) custom_4a_amendments_taxsup.get(Double.valueOf(Double.valueOf(tmp.getTx_r()).toString()));
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[1] = temp[1] + tmp.getDiffVal();
				ttl_intra_amendments = ttl_intra_amendments + temp[1];
				if(custom_4a_amendments_taxsup.containsKey(Double.valueOf(Double.valueOf(tmp.getTx_r()).toString()))){
					custom_4a_amendments_taxsup.put((Double.valueOf(tmp.getTx_r()).toString()), temp);  
				} else {
					custom_4a_amendments_taxsup.put((Double.valueOf(tmp.getTx_r()).toString()), temp);
				}
			}
			
			
			ArrayList<EcommSup2> EcommSup2List =  gstr3RootDTO.getOsup().getOutAmend().getInter().getEcommSup();
			ArrayList<EcommSup3> EcommSup3List =  gstr3RootDTO.getOsup().getOutAmend().getIntra().getEcommSup();
			temp = new Double[2];
			
			
			
			for(Iterator iterator = EcommSup2List.iterator(); iterator
					.hasNext();) {
				EcommSup2 tmp  = (EcommSup2) iterator.next();
				osup_ttl_igst_amendments = osup_ttl_igst_amendments + tmp.getIamt();
				osup_ttl_cgst_amendments = osup_ttl_cgst_amendments + tmp.getCamt();
				osup_ttl_sgst_amendments = osup_ttl_sgst_amendments + tmp.getSamt();
				osup_ttl_cess_amendments = osup_ttl_cess_amendments + tmp.getCsamt();
				temp = (Double[]) custom_4a_amendments_ecomm.get(Double.valueOf(tmp.getTx_r()).toString());
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[0] = temp[0] + tmp.getDiffVal();
				ttl_inter_amendments = ttl_inter_amendments + temp[0];
				if(custom_4a_amendments_ecomm.containsKey(Double.valueOf(tmp.getTx_r()).toString())){
					custom_4a_amendments_ecomm.put(Double.valueOf(tmp.getTx_r()).toString(), temp);  
				} else {
					custom_4a_amendments_ecomm.put(Double.valueOf(tmp.getTx_r()).toString(), temp);
				}
			}
			
			temp = new Double[2];
			for(Iterator iterator = EcommSup3List.iterator(); iterator
					.hasNext();) {
				EcommSup3 tmp  = (EcommSup3) iterator.next();
				osup_ttl_igst_amendments = osup_ttl_igst_amendments + tmp.getIamt();
				osup_ttl_cgst_amendments = osup_ttl_cgst_amendments + tmp.getCamt();
				osup_ttl_sgst_amendments = osup_ttl_sgst_amendments + tmp.getSamt();
				osup_ttl_cess_amendments = osup_ttl_cess_amendments + tmp.getCsamt();
				temp = (Double[]) custom_4a_amendments_ecomm.get(Double.valueOf(tmp.getTx_r()).toString());
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[1] = temp[1] + tmp.getDiffVal();
				ttl_intra_amendments = ttl_intra_amendments + temp[1];
				if(custom_4a_amendments_ecomm.containsKey(Double.valueOf(tmp.getTx_r()).toString())){
					custom_4a_amendments_ecomm.put(Double.valueOf(tmp.getTx_r()).toString(), temp);  
				} else {
					custom_4a_amendments_ecomm.put(Double.valueOf(tmp.getTx_r()).toString(), temp);
				}
			}
			
			ArrayList<ZrSupWp2> ZrSupWp2List =  gstr3RootDTO.getOsup().getOutAmend().getInter().getZrSupWp();
			
			temp = new Double[2];
			
			for(Iterator iterator = ZrSupWp2List.iterator(); iterator
					.hasNext();) {
				ZrSupWp2 tmp  = (ZrSupWp2) iterator.next();
				osup_ttl_igst_amendments = osup_ttl_igst_amendments + tmp.getIamt();
				osup_ttl_cgst_amendments = osup_ttl_cgst_amendments + tmp.getCamt();
				osup_ttl_sgst_amendments = osup_ttl_sgst_amendments + tmp.getSamt();
				osup_ttl_cess_amendments = osup_ttl_cess_amendments + tmp.getCsamt();
				temp = (Double[]) custom_4a_amendments_zr_sup_wp.get(Double.valueOf(tmp.getTx_r()).toString());
				if(temp == null)
				{	
					temp = new Double[2];
					temp[0] = 0.00; 
					temp[1] = 0.00; 
				}
				temp[0] = temp[0] + tmp.getDiffVal();
				ttl_inter_amendments = ttl_inter_amendments + temp[0];
				if(custom_4a_amendments_zr_sup_wp.containsKey(Double.valueOf(tmp.getTx_r()).toString())){
					custom_4a_amendments_zr_sup_wp.put(Double.valueOf(tmp.getTx_r()).toString().toString(), temp);  
				} else {
					custom_4a_amendments_zr_sup_wp.put(Double.valueOf(tmp.getTx_r()).toString().toString(), temp);
				}
			}
			gstr3RootDTO.getOsup().setTtl_inter_amendments(ttl_inter_amendments);
			gstr3RootDTO.getOsup().setTtl_intra_amendments(ttl_intra_amendments);
			gstr3RootDTO.getOsup().setTttl_sup_outwards(ttl_inter_outwards + ttl_intra_outwards);
			gstr3RootDTO.getOsup().setTttl_sup_amendments(ttl_inter_amendments + ttl_intra_amendments);
			gstr3RootDTO.getOsup().setOsup_ttl_igst(osup_ttl_igst);
			gstr3RootDTO.getOsup().setOsup_ttl_cgst(osup_ttl_cgst);
			gstr3RootDTO.getOsup().setOsup_ttl_sgst(osup_ttl_sgst);
			gstr3RootDTO.getOsup().setOsup_ttl_cess(osup_ttl_cess);
			gstr3RootDTO.getOsup().setOsup_ttl_igst_amendments(osup_ttl_igst_amendments);
			gstr3RootDTO.getOsup().setOsup_ttl_cgst_amendments(osup_ttl_cgst_amendments);
			gstr3RootDTO.getOsup().setOsup_ttl_sgst_amendments(osup_ttl_sgst_amendments);
			gstr3RootDTO.getOsup().setOsup_ttl_cess_amendments(osup_ttl_cess_amendments);
			gstr3RootDTO.getOsup().setTttl_sup_amendments(ttl_inter_amendments + ttl_intra_amendments);
						
			/*Outward Supply Amenedments Ends*/
			
			/*Reverse Charge On Inward Supplies*/
			try {
					ArrayList<InterDet> isuPIntreList = gstr3RootDTO.getI_sup()
							.getTxpyRc().getInterDet();
					ArrayList<IntraDet> isuPIntraList = gstr3RootDTO.getI_sup()
							.getTxpyRc().getIntraDet();
				double nettaxInter = 0.00;
				double nettaxIntra = 0.00;
				
				double netIamtInter = 0.00;
				double netIamtIntra = 0.00;
				
				double netCessInter = 0.00;
				double netCessIntra = 0.00;
				
				double nettaxInterAmnd = 0.00;
				double nettaxIntraAmnd = 0.00;
				
				double netIamtInterAmnd = 0.00;
				double netIamtIntraAmnd = 0.00;
				
				double netCessInterAmnd = 0.00;
				double netCessIntraAmnd = 0.00;
				
				double netCamtIntra=0.00;
				double netSamtIntra=0.00;
				
				double netCamtIntraAmnd = 0.00;
				double netSamtIntraAmnd = 0.00;
				
			
				
				
					for (Iterator iterator = isuPIntreList.iterator(); iterator
							.hasNext();) {
					InterDet interDet = (InterDet) iterator.next();
					nettaxInter = nettaxInter + interDet.getTxval();
					netIamtInter = netIamtInter + interDet.getIamt();
					netCessInter = netCessInter + interDet.getCess();
				}
				
					for (Iterator iterator = isuPIntraList.iterator(); iterator
							.hasNext();) {
					IntraDet intraDet = (IntraDet) iterator.next();
					nettaxIntra = nettaxIntra + intraDet.getTxval();
					netCamtIntra=netCamtIntra+intraDet.getCamt();
					netSamtIntra=netSamtIntra+intraDet.getSamt();
					netCessIntra = netCessIntra + intraDet.getCess();
				}
				
					gstr3RootDTO.getI_sup().getTxpyRc()
							.setNetCessInter(netCessInter);
					gstr3RootDTO.getI_sup().getTxpyRc()
							.setNetIamtIntra(netIamtIntra);
					gstr3RootDTO.getI_sup().getTxpyRc()
							.setNetIamtInter(netIamtInter);
					/*gstr3RootDTO.getI_sup().getTxpyRc()
							.setNetIamtIntra(netIamtIntra);*/
					gstr3RootDTO.getI_sup().getTxpyRc()
							.setNettaxInter(nettaxInter);
					gstr3RootDTO.getI_sup().getTxpyRc()
							.setNettaxIntra(nettaxIntra);
				
					gstr3RootDTO.getI_sup().getTxpyRc()
					.setNetCamtIntra(netCamtIntra);
					gstr3RootDTO.getI_sup().getTxpyRc()
					.setNetSamtIntra(netSamtIntra);
					gstr3RootDTO.getI_sup().getTxpyRc()
					.setNetCessIntra(netCessIntra);
				
					ArrayList<InterDet2> isuPIntreListAmend = gstr3RootDTO
							.getI_sup().getTxamendRc().getInterDet();
					ArrayList<IntraDet2> isuPIntraListAmend = gstr3RootDTO
							.getI_sup().getTxamendRc().getIntraDet();
				
					for (Iterator iterator = isuPIntreListAmend.iterator(); iterator
							.hasNext();) {
					InterDet2 interDet = (InterDet2) iterator.next();
					nettaxInterAmnd = nettaxInterAmnd + interDet.getTxval();
						netIamtInterAmnd = netIamtInterAmnd
								+ interDet.getIamt();
						netCessInterAmnd = netCessInterAmnd
								+ interDet.getCess();
				}
				
					for (Iterator iterator = isuPIntraListAmend.iterator(); iterator
							.hasNext();) {
					IntraDet2 intraDet = (IntraDet2) iterator.next();
					nettaxIntraAmnd = nettaxIntraAmnd + intraDet.getTxval();
					netCamtIntraAmnd=netCamtIntraAmnd+intraDet.getCamt();
					netSamtIntraAmnd=netSamtIntraAmnd+intraDet.getSamt();
					//netIamtIntra = netIamtIntraAmnd + intraDet.getIamt();
						netCessIntraAmnd = netCessIntraAmnd
								+ intraDet.getCess();
				}
				
					gstr3RootDTO.getI_sup().getTxamendRc()
							.setNetCessIntra(netCessIntraAmnd);
					gstr3RootDTO.getI_sup().getTxamendRc()
					.setNetCessInter(netCessInterAmnd);
					
				
					gstr3RootDTO.getI_sup().getTxamendRc()
							.setNetIamtInter(netIamtInterAmnd);
					
					gstr3RootDTO.getI_sup().getTxamendRc()
							.setNetCamtIntra(netCamtIntraAmnd);
					gstr3RootDTO.getI_sup().getTxamendRc()
							.setNetSamtIntra(netSamtIntraAmnd);
					
					gstr3RootDTO.getI_sup().getTxamendRc()
							.setNettaxIntra(nettaxIntraAmnd);
					gstr3RootDTO.getI_sup().getTxamendRc()
					.setNettaxInter(nettaxInterAmnd);
				
					double netDiffvalue = nettaxInter + nettaxIntra
							+ nettaxInterAmnd + nettaxIntraAmnd;
				
					double ttlrevcharge = netIamtInter+netCessInter+netCamtIntra+netSamtIntra+netCessIntra+netIamtInterAmnd+netCessInterAmnd+netCamtIntraAmnd+netSamtIntraAmnd+netCessIntraAmnd;
					
					
					 gstr3RootDTO.getI_sup().setTtl_rev_chg(ttlrevcharge);
				 gstr3RootDTO.getI_sup().setNet_diff(netDiffvalue);
			} catch (Exception e) {
				// TODO Auto-generated catch block
					LOGGER.error(Constant.LOGGER_EXITING
							+ CLASS_NAME
							+ " Error Encountered while calculating Dynamic Fields for Reverse Charge On Inward Supplies, GSTR3, Method : doDynamicCalculation, Error: "
							+ e.getMessage() + ", Local Error Message: "
							+ e.getLocalizedMessage());
			}
			 // As of now now net_diff present in json
			 
			/*Reverse Charge On Inward Supplies*/
			 
			 /*Input Tax Credit*/
			 
			 double itc_rc_net_itc_Iamt = 0.00;
			 double itc_rc_net_itc_Camt = 0.00;
			 double itc_rc_net_itc_Samt = 0.00;
			 double itc_rc_net_itc_Cess = 0.00;
			
			 /*Reverse Charge On Inward Supplies*/
				ArrayList<ItcDet> itcCrItcDet = gstr3RootDTO.getItc_cr()
						.getItcDet();
				for (Iterator iterator = itcCrItcDet.iterator(); iterator
						.hasNext();) {
				ItcDet itcDet = (ItcDet) iterator.next();
					itc_rc_net_itc_Iamt = itc_rc_net_itc_Iamt
							+ itcDet.getIItc();
					itc_rc_net_itc_Camt = itc_rc_net_itc_Camt
							+ itcDet.getCItc();
					itc_rc_net_itc_Samt = itc_rc_net_itc_Samt
							+ itcDet.getSItc();
					itc_rc_net_itc_Cess = itc_rc_net_itc_Cess
							+ itcDet.getCsItc();
			}
				gstr3RootDTO.getItc_cr().setTtl_itc(
						itc_rc_net_itc_Iamt + itc_rc_net_itc_Camt
								+ itc_rc_net_itc_Samt + itc_rc_net_itc_Cess);
				gstr3RootDTO.getItc_cr().setItc_rc_net_itc_Iamt(
						itc_rc_net_itc_Iamt);
				gstr3RootDTO.getItc_cr().setItc_rc_net_itc_Camt(
						itc_rc_net_itc_Camt);
				gstr3RootDTO.getItc_cr().setItc_rc_net_itc_Samt(
						itc_rc_net_itc_Samt);
				gstr3RootDTO.getItc_cr().setItc_rc_net_itc_Cess(
						itc_rc_net_itc_Cess);
			
			 /*Input Tax Credit Ends*/
			
			 
			 /*Addition and Reduction*/
			
			/*Total Deifferential Value Yet to be calculated, not mentioned*/
			
			double netDiffValAddNRed = 0.00;
			double cgstValAddNRed = 0.00;
			double sgstValAddNRed = 0.00;
			double igstValAddNRed = 0.00;
			
			ItcRvl itcrvl = gstr3RootDTO.getMis().getItcRvl();
			ItcRclm itcrclm=gstr3RootDTO.getMis().getItcRclm();
			
			ItcRvlRclm rvlrclm=new ItcRvlRclm();
			
			double totIgst=0.00;
			double totCgst=0.00;
			double totSgst=0.00;
			double totCess=0.00;
			if(itcrclm != null && itcrvl != null){
				 totIgst = Double.valueOf(itcrvl.getIamt()-Double.valueOf(itcrclm.getIamt()));
				 totCgst = Double.valueOf(itcrvl.getCamt()-Double.valueOf(itcrclm.getCamt()));
				 totSgst = Double.valueOf(itcrvl.getSamt()-Double.valueOf(itcrclm.getSamt()));
				 totCess = Double.valueOf(itcrvl.getCess()-Double.valueOf(itcrclm.getCess()));			
				
			}
			else if(itcrclm != null){
				 totIgst = totIgst-Double.valueOf(itcrclm.getIamt());
				 totCgst = totCgst-Double.valueOf(itcrclm.getCamt());
				 totSgst = totSgst-Double.valueOf(itcrclm.getSamt());
				 totCess = totCess-Double.valueOf(itcrclm.getCess());
			}
			else if(itcrvl != null){
				 totIgst = Double.valueOf(itcrvl.getIamt());
				 totCgst = Double.valueOf(itcrvl.getCamt());
				 totSgst = Double.valueOf(itcrvl.getSamt());
				 totCess = Double.valueOf(itcrvl.getCess());
			}
			rvlrclm.setIamt(totIgst);
			rvlrclm.setCamt(totCgst);
			rvlrclm.setSamt(totSgst);
			rvlrclm.setCess(totCess);
			gstr3RootDTO.getMis().setItcRvlRclm(rvlrclm);
			double integratedTax = Double.valueOf(gstr3RootDTO.getMis().getItc_clm().getIamt()) +
					Double.valueOf(gstr3RootDTO.getMis().getTax_liab().getIamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getRclm_cn().getIamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getRclm_idn().getIamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getNeg_tax_liab().getIamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getAdv_tx().getIamt() ) +
					Double.valueOf(gstr3RootDTO.getMis().getItcRvlRclm().getIamt()) ;
			double centralTax = Double.valueOf(gstr3RootDTO.getMis().getItc_clm().getCamt()) +
					Double.valueOf(gstr3RootDTO.getMis().getTax_liab().getCamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getRclm_cn().getCamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getRclm_idn().getCamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getNeg_tax_liab().getCamt()) -
					Double.valueOf(gstr3RootDTO.getMis().getAdv_tx().getCamt() ) +
					Double.valueOf(gstr3RootDTO.getMis().getItcRvlRclm().getCamt());
			double stateTax = Double.valueOf(gstr3RootDTO.getMis().getItc_clm().getSamt()) +
					Double.valueOf(gstr3RootDTO.getMis().getTax_liab().getSamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getRclm_cn().getSamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getRclm_idn().getSamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getNeg_tax_liab().getSamt() ) -
					Double.valueOf(gstr3RootDTO.getMis().getAdv_tx().getSamt() ) +
					Double.valueOf(gstr3RootDTO.getMis().getItcRvlRclm().getSamt());
			double cessTax = Double.valueOf(gstr3RootDTO.getMis().getItc_clm().getCess()) +
					Double.valueOf(gstr3RootDTO.getMis().getTax_liab().getCess() ) -
					Double.valueOf(gstr3RootDTO.getMis().getRclm_cn().getCess() ) -
					Double.valueOf(gstr3RootDTO.getMis().getRclm_idn().getCess() ) -
					Double.valueOf(gstr3RootDTO.getMis().getNeg_tax_liab().getCess() ) -
					Double.valueOf(gstr3RootDTO.getMis().getAdv_tx().getCess() ) +
					Double.valueOf(gstr3RootDTO.getMis().getItcRvlRclm().getCess());

			gstr3RootDTO.getMis().setNetITax(integratedTax);
			gstr3RootDTO.getMis().setNetSTax(stateTax);
			gstr3RootDTO.getMis().setNetCTax(centralTax);
			gstr3RootDTO.getMis().setNetCess(cessTax);
			
			
			
			 /*Addition and Reduction Ends*/
			
			/*Taxes*/
			
			double taxIntTtlCombined = 0.00;
			double taxStateTtlCombined = 0.00;
			double taxCentTtlCombined = 0.00;
			double taxCessTtlCombined = 0.00;
			double taxIntTtlCombinedUtil = 0.00;
			double taxStateTtlCombinedUtil = 0.00;
			double taxCentTtlCombinedUtil = 0.00;
			double taxCessTtlCombinedUtil = 0.00;
				ArrayList<TtlDtl> taxInward = gstr3RootDTO.getTtxl().getTtlIn()
						.getTtlDtl();
			
			double taxInwardInteTtl = 0.00;
			double taxInwardStateTtl = 0.00;
			double taxInwardCentTtl = 0.00;
			double taxInwardCessTtl = 0.00;
			
				for (Iterator iterator = taxInward.iterator(); iterator
						.hasNext();) {
				TtlDtl ttlDtl = (TtlDtl) iterator.next();
				taxInwardInteTtl = taxInwardInteTtl + ttlDtl.getIamt();
				taxInwardStateTtl = taxInwardStateTtl + ttlDtl.getSamt();
				taxInwardCentTtl = taxInwardCentTtl + ttlDtl.getCamt();
				taxInwardCessTtl = taxInwardCessTtl + ttlDtl.getCsamt();
			}
				gstr3RootDTO.getTtxl().getTtlIn()
						.setTtl_In_ITtl(taxInwardInteTtl);
				gstr3RootDTO.getTtxl().getTtlIn()
						.setTtl_In_CTtl(taxInwardStateTtl);
				gstr3RootDTO.getTtxl().getTtlIn()
						.setTtl_In_STtl(taxInwardCentTtl);
				gstr3RootDTO.getTtxl().getTtlIn()
						.setTtl_In_CessTtl(taxInwardCessTtl);
			
			
			taxIntTtlCombined = taxIntTtlCombined + taxInwardInteTtl;
			taxStateTtlCombined = taxStateTtlCombined + taxInwardStateTtl;
			taxCentTtlCombined = taxCentTtlCombined + taxInwardCentTtl;
			taxCessTtlCombined = taxCessTtlCombined + taxInwardCessTtl;
			
				ArrayList<TtlDtl2> taxInwardRev = gstr3RootDTO.getTtxl()
						.getTtlOut().getTtlDtl();
			
			double taxInwardRevInteTtl = 0.00;
			double taxInwardRevStateTtl = 0.00;
			double taxInwardRevCentTtl = 0.00;
			double taxInwardRevCessTtl = 0.00;
			
				for (Iterator iterator = taxInwardRev.iterator(); iterator
						.hasNext();) {
				TtlDtl2 ttlDtl = (TtlDtl2) iterator.next();
					taxInwardRevInteTtl = taxInwardRevInteTtl
							+ ttlDtl.getIamt();
					taxInwardRevStateTtl = taxInwardRevStateTtl
							+ ttlDtl.getSamt();
					taxInwardRevCentTtl = taxInwardRevCentTtl
							+ ttlDtl.getCamt();
					taxInwardRevCessTtl = taxInwardRevCessTtl
							+ ttlDtl.getCsamt();
			}
			
				gstr3RootDTO.getTtxl().getTtlOut()
						.setTtl_In_ITtl(taxInwardRevInteTtl);
				gstr3RootDTO.getTtxl().getTtlOut()
						.setTtl_In_CTtl(taxInwardRevStateTtl);
				gstr3RootDTO.getTtxl().getTtlOut()
						.setTtl_In_STtl(taxInwardRevCentTtl);
				gstr3RootDTO.getTtxl().getTtlOut()
						.setTtl_In_CessTtl(taxInwardRevCessTtl);
			
			taxIntTtlCombined = taxIntTtlCombined + taxInwardRevInteTtl;
				taxStateTtlCombined = taxStateTtlCombined
						+ taxInwardRevStateTtl;
			taxCentTtlCombined = taxCentTtlCombined + taxInwardRevCentTtl;
			taxCessTtlCombined = taxCessTtlCombined + taxInwardRevCessTtl;
			
				ArrayList<TtlDtl3> taxInCr = gstr3RootDTO.getTtxl()
						.getTtlItcrv().getTtlDtl();
			
			double taxInwardCrInteTtl = 0.00;
			double taxInwardCrStateTtl = 0.00;
			double taxInwardCrCentTtl = 0.00;
			double taxInwardCrCessTtl = 0.00;
			
			for (Iterator iterator = taxInCr.iterator(); iterator.hasNext();) {
				TtlDtl3 ttlDtl = (TtlDtl3) iterator.next();
				taxInwardCrInteTtl = taxInwardCrInteTtl + ttlDtl.getIamt();
					taxInwardCrStateTtl = taxInwardCrStateTtl
							+ ttlDtl.getSamt();
				taxInwardCrCentTtl = taxInwardCrCentTtl + ttlDtl.getCamt();
				taxInwardCrCessTtl = taxInwardCrCessTtl + ttlDtl.getCsamt();
			}
			
				gstr3RootDTO.getTtxl().getTtlItcrv()
						.setTtl_In_ITtl(taxInwardCrInteTtl);
				gstr3RootDTO.getTtxl().getTtlItcrv()
						.setTtl_In_CTtl(taxInwardCrStateTtl);
				gstr3RootDTO.getTtxl().getTtlItcrv()
						.setTtl_In_STtl(taxInwardCrCentTtl);
				gstr3RootDTO.getTtxl().getTtlItcrv()
						.setTtl_In_CessTtl(taxInwardCrCessTtl);
			
			taxIntTtlCombined = taxIntTtlCombined + taxInwardCrInteTtl;
			taxStateTtlCombined = taxStateTtlCombined + taxInwardCrStateTtl;
			taxCentTtlCombined = taxCentTtlCombined + taxInwardCrCentTtl;
			taxCessTtlCombined = taxCessTtlCombined + taxInwardCrCessTtl;
			
				ArrayList<TtlDtl4> taxInwardOth = gstr3RootDTO.getTtxl()
						.getTtlOth().getTtlDtl();
			
			double taxInwardOthInteTtl = 0.00;
			double taxInwardOthStateTtl = 0.00;
			double taxInwardOthCentTtl = 0.00;
			double taxInwardOthCessTtl = 0.00;
			
				for (Iterator iterator = taxInwardOth.iterator(); iterator
						.hasNext();) {
				TtlDtl4 ttlDtl = (TtlDtl4) iterator.next();
					taxInwardOthInteTtl = taxInwardOthInteTtl
							+ ttlDtl.getIamt();
					taxInwardOthStateTtl = taxInwardOthStateTtl
							+ ttlDtl.getSamt();
					taxInwardOthCentTtl = taxInwardOthCentTtl
							+ ttlDtl.getCamt();
					taxInwardOthCessTtl = taxInwardOthCessTtl
							+ ttlDtl.getCsamt();
			}
				
			taxIntTtlCombined = taxIntTtlCombined + taxInwardOthInteTtl;
				taxStateTtlCombined = taxStateTtlCombined
						+ taxInwardOthStateTtl;
			taxCentTtlCombined = taxCentTtlCombined + taxInwardOthCentTtl;
			taxCessTtlCombined = taxCessTtlCombined + taxInwardOthCessTtl;
			
				gstr3RootDTO.getTtxl().getTtlOth()
						.setTtl_In_ITtl(taxInwardOthInteTtl);
				gstr3RootDTO.getTtxl().getTtlOth()
						.setTtl_In_CTtl(taxInwardOthStateTtl);
				gstr3RootDTO.getTtxl().getTtlOth()
						.setTtl_In_STtl(taxInwardOthCentTtl);
				gstr3RootDTO.getTtxl().getTtlOth()
						.setTtl_In_CessTtl(taxInwardOthCessTtl);
				taxIntTtlCombinedUtil = taxIntTtlCombined;
				taxStateTtlCombinedUtil = taxStateTtlCombined;
				taxCentTtlCombinedUtil = taxCentTtlCombined;
				taxCessTtlCombinedUtil = taxCessTtlCombined;
				gstr3RootDTO.getTtxl().setTaxIntTtlCombinedUtil(taxIntTtlCombinedUtil);
				gstr3RootDTO.getTtxl().setTaxStateTtlCombinedUtil(taxStateTtlCombinedUtil);
				gstr3RootDTO.getTtxl().setTaxCentTtlCombinedUtil(taxCentTtlCombinedUtil);
				gstr3RootDTO.getTtxl().setTaxCessTtlCombinedUtil(taxCessTtlCombinedUtil);
				
				
				taxCentTtlCombined = taxCentTtlCombined + gstr3RootDTO.getLtFee().getCamt();
				taxStateTtlCombined = taxStateTtlCombined + gstr3RootDTO.getLtFee().getSamt();
				
				taxIntTtlCombined = taxIntTtlCombined +gstr3RootDTO.getIntr_liab().getTot_intr_liab().getIamt();
				taxCentTtlCombined = taxCentTtlCombined +gstr3RootDTO.getIntr_liab().getTot_intr_liab().getCamt();
				taxStateTtlCombined = taxStateTtlCombined +gstr3RootDTO.getIntr_liab().getTot_intr_liab().getSamt();
				taxCessTtlCombined = taxCessTtlCombined +gstr3RootDTO.getIntr_liab().getTot_intr_liab().getCess();
				
			gstr3RootDTO.getTtxl().setTtl_in_I_Cmbd(taxIntTtlCombined);
			gstr3RootDTO.getTtxl().setTtl_in_C_Cmbd(taxCentTtlCombined);
			gstr3RootDTO.getTtxl().setTtl_in_S_Cmbd(taxStateTtlCombined);
			gstr3RootDTO.getTtxl().setTtl_in_Cess_Cmbd(taxCessTtlCombined);
				gstr3RootDTO.getTtxl().setTtl_pybl(
						taxIntTtlCombined + taxCentTtlCombined
								+ taxStateTtlCombined + taxCessTtlCombined);
			
			
				
			
			if(cashITCJSON != null){
			
			JSONObject jsonObj = (JSONObject) new JSONParser()
			.parse(cashITCJSON);
		
			//System.out.println(jsonObj.get("cashItcReserved").toString());
			JSONObject cashITCJSONObj =(JSONObject) new JSONParser().parse(jsonObj.get("cashItcReserved").toString());
				
			GSTR3CashITC gstr3CashITC = (GSTR3CashITC) parseJsonToDTO(cashITCJSONObj.toString(), GSTR3CashITC.class);
			double ttl_cash_bal = gstr3CashITC.getCash_bal().getIgst_tot_bal() + gstr3CashITC.getCash_bal().getCgst_tot_bal() + gstr3CashITC.getCash_bal().getSgst_tot_bal() + gstr3CashITC.getCash_bal().getCess_tot_bal() +
			gstr3CashITC.getCash_bal().getIgst().getFee()+gstr3CashITC.getCash_bal().getIgst().getIntr()+gstr3CashITC.getCash_bal().getIgst().getOth()+gstr3CashITC.getCash_bal().getIgst().getOth()+gstr3CashITC.getCash_bal().getIgst().getTx()+
			gstr3CashITC.getCash_bal().getCgst().getFee()+gstr3CashITC.getCash_bal().getCgst().getIntr()+gstr3CashITC.getCash_bal().getCgst().getOth()+gstr3CashITC.getCash_bal().getCgst().getOth()+gstr3CashITC.getCash_bal().getCgst().getTx()+
			gstr3CashITC.getCash_bal().getSgst().getFee()+gstr3CashITC.getCash_bal().getSgst().getIntr()+gstr3CashITC.getCash_bal().getSgst().getOth()+gstr3CashITC.getCash_bal().getSgst().getOth()+gstr3CashITC.getCash_bal().getSgst().getTx()+
			gstr3CashITC.getCash_bal().getCess().getFee()+gstr3CashITC.getCash_bal().getCess().getIntr()+gstr3CashITC.getCash_bal().getCess().getOth()+gstr3CashITC.getCash_bal().getCess().getOth()+gstr3CashITC.getCash_bal().getCess().getTx();
			
			gstr3RootDTO.getTtxl().setTtl_csh_paid(ttl_cash_bal);
			gstr3RootDTO.getTtxl().setTtl_itc_avlbl(gstr3CashITC.getItc_bal().getIgst_bal() + gstr3CashITC.getItc_bal().getCgst_bal() + gstr3CashITC.getItc_bal().getCgst_bal() + gstr3CashITC.getItc_bal().getSgst_bal() +gstr3CashITC.getItc_bal().getCess_bal() );
			}
			
			/*Taxes Ends*/
			
			/*TDS & TCS */
			
				gstr3RootDTO.getTds_cr().setTtl_tds(
						gstr3RootDTO.getTds_cr().getTds_det().getItx()
								+ gstr3RootDTO.getTds_cr().getTds_det()
										.getCtx()
								+ gstr3RootDTO.getTds_cr().getTds_det()
										.getStx());
				gstr3RootDTO.getTcs_cr().setTtl_tcs(
						gstr3RootDTO.getTcs_cr().getTcs_det().getItx()
								+ gstr3RootDTO.getTcs_cr().getTcs_det()
										.getCtx()
								+ gstr3RootDTO.getTcs_cr().getTcs_det()
										.getStx());
			
			/*TDS & TCS Ends*/
			

			/*Interest Liability and Late Fee*/
				double ttl_intr_liab = gstr3RootDTO.getIntr_liab()
						.getTot_intr_liab().getIamt()
						+ gstr3RootDTO.getIntr_liab().getTot_intr_liab()
								.getCamt()
						+ gstr3RootDTO.getIntr_liab().getTot_intr_liab()
								.getSamt()
						+ gstr3RootDTO.getIntr_liab().getTot_intr_liab()
								.getCess();
			gstr3RootDTO.getIntr_liab().setTtl_intr_liab(ttl_intr_liab);
			 
				gstr3RootDTO.getLt_fee().setTtl_lt_fee(
						gstr3RootDTO.getLt_fee().getCamt()
								+ gstr3RootDTO.getLt_fee().getSamt());
			/*Interest Liability and Late Fee Ends*/
			
				gstr3RootDTO.getLdg_debit_entries().setTtl_txs_paid(
						gstr3RootDTO.getLdg_debit_entries()
										.getPdcash().getIpd()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPdcash().getCpd()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPdcash().getSpd()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPdcash().getCspd()
								/*+ gstr3RootDTO.getLdg_debit_entries()
										.getPdcash().getI_intr_pd()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPdcash().getC_intr_pd()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPdcash().getS_intr_pd()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPdcash().getCs_intr_pd()*/
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPditc().getIPdi()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPditc().getIPdc()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPditc().getIDs()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPditc().getCPdi()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPditc().getCPdc()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPditc().getSPdi()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPditc().getSPds()
								+ gstr3RootDTO.getLdg_debit_entries()
										.getPditc().getCsPdcs()
								/*+ gstr3RootDTO.getLdg_debit_entries()
										.getPditc().getIDs()*/);
			
			message = (String)parseDTOtoJson(gstr3RootDTO);
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				LOGGER.error(Constant.LOGGER_EXITING
						+ CLASS_NAME
						+ " Error Encountered while calculating Dynamic Fields, GSTR3, Method : doDynamicCalculation");
			}
			LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
					+ " Method : getGSTR3JSON");
		
			
			
			
			return message;
		}
	}

}
class Tod {
	private double txble_to;

	private double gnet_to;
	
	private double net_txble;
	
	public double getNet_txble() {
		return net_txble;
	}

	public void setNet_txble(double net_txble) {
		this.net_txble = net_txble;
	}

	public double getTxble_to() {
		return txble_to;
	}

	public void setTxble_to(double txble_to) {
		this.txble_to = txble_to;
	}

	public double getGnet_to() {
		return gnet_to;
	}

	public void setGnet_to(double gnet_to) {
		this.gnet_to = gnet_to;
	}

	public double getZrsp_to() {
		return zrsp_to;
	}

	public void setZrsp_to(double zrsp_to) {
		this.zrsp_to = zrsp_to;
	}

	public double getZrswp_to() {
		return zrswp_to;
	}

	public void setZrswp_to(double zrswp_to) {
		this.zrswp_to = zrswp_to;
	}

	public double getExp_to() {
		return exp_to;
	}

	public void setExp_to(double exp_to) {
		this.exp_to = exp_to;
	}

	public double getNil_to() {
		return nil_to;
	}

	public void setNil_to(double nil_to) {
		this.nil_to = nil_to;
	}

	public double getExmptd_to() {
		return exmptd_to;
	}

	public void setExmptd_to(double exmptd_to) {
		this.exmptd_to = exmptd_to;
	}

	public double getNon_to() {
		return non_to;
	}

	public void setNon_to(double non_to) {
		this.non_to = non_to;
	}

	public double getNet_to() {
		return net_to;
	}

	public void setNet_to(double net_to) {
		this.net_to = net_to;
	}

	public double getTxbleTo() {
		return this.txble_to;
	}

	public void setTxbleTo(double txble_to) {
		this.txble_to = txble_to;
	}

	private double zrsp_to;

	public double getZrspTo() {
		return this.zrsp_to;
	}

	public void setZrspTo(double zrsp_to) {
		this.zrsp_to = zrsp_to;
	}

	private double zrswp_to;

	public double getZrswpTo() {
		return this.zrswp_to;
	}

	public void setZrswpTo(double zrswp_to) {
		this.zrswp_to = zrswp_to;
	}

	private double exp_to;

	public double getExpTo() {
		return this.exp_to;
	}

	public void setExpTo(double exp_to) {
		this.exp_to = exp_to;
	}

	private double nil_to;

	public double getNilTo() {
		return this.nil_to;
	}

	public void setNilTo(double nil_to) {
		this.nil_to = nil_to;
	}

	private double exmptd_to;

	public double getExmptdTo() {
		return this.exmptd_to;
	}

	public void setExmptdTo(double exmptd_to) {
		this.exmptd_to = exmptd_to;
	}

	private double non_to;

	public double getNonTo() {
		return this.non_to;
	}

	public void setNonTo(double non_to) {
		this.non_to = non_to;
	}

	private double net_to;

	public double getNetTo() {
		return this.net_to;
	}

	public void setNetTo(double net_to) {
		this.net_to = net_to;
	}

	public List<String> fetchInsertScripts(int masterID,
            Map<String, Integer> tileMap) {

     List<String> list = new ArrayList<String>();
     
     int tileID = tileMap.get(Constant.TABLE_3_1);
     String insertQuery = "insert into [gstr3].[tblgstr3TurnOverDetails]([GSTIN],[TaxPeriod],[MasterID],[TileID],[TurnOver],[IsActive]) values ("
                  + null
                  + ","
                  + null
                  + ","
                  + masterID
                  + ","
                  + tileID
                  + ","
                  + this.txble_to
                  + ","
                  + 1 + ")";

     
     list.add(insertQuery);
     
     
     tileID = tileMap.get(Constant.TABLE_3_2);
     insertQuery = "insert into [gstr3].[tblgstr3TurnOverDetails]([GSTIN],[TaxPeriod],[MasterID],[TileID],[TurnOver],[IsActive]) values ("
                         + null
                         + ","
                         + null
                         + ","
                         + masterID
                         + ","
                         + tileID
                         + ","
                         + this.zrsp_to
                         + ","
                         + 1 + ")";

            
            list.add(insertQuery);
            
            

            tileID = tileMap.get(Constant.TABLE_3_3);
            insertQuery = "insert into [gstr3].[tblgstr3TurnOverDetails]([GSTIN],[TaxPeriod],[MasterID],[TileID],[TurnOver],[IsActive]) values ("
                                + null
                                + ","
                                + null
                                + ","
                                + masterID
                                + ","
                                + tileID
                                 + ","
                                + this.zrswp_to
                                + ","
                                + 1 + ")";

                  
                  list.add(insertQuery);
                  
                  
                  tileID = tileMap.get(Constant.TABLE_3_4);
                  insertQuery = "insert into [gstr3].[tblgstr3TurnOverDetails]([GSTIN],[TaxPeriod],[MasterID],[TileID],[TurnOver],[IsActive]) values ("
                                       + null
                                       + ","
                                       + null
                                       + ","
                                       + masterID
                                       + ","
                                       + tileID
                                       + ","
                                       + this.exp_to
                                       + ","
                                       + 1 + ")";

                         
                         list.add(insertQuery);
                         
                         
                         tileID = tileMap.get(Constant.TABLE_3_5);
                         insertQuery = "insert into [gstr3].[tblgstr3TurnOverDetails]([GSTIN],[TaxPeriod],[MasterID],[TileID],[TurnOver],[IsActive]) values ("
                                              + null
                                              + ","
                                              + null
                                              + ","
                                              + masterID
                                              + ","
                                              + tileID
                                              + ","
                                              + this.exmptd_to
                                              + ","
                                              + 1 + ")";

                                
                                list.add(insertQuery);
                  
     
                                tileID = tileMap.get(Constant.TABLE_3_6);
                                insertQuery = "insert into [gstr3].[tblgstr3TurnOverDetails]([GSTIN],[TaxPeriod],[MasterID],[TileID],[TurnOver],[IsActive]) values ("
                                                     + null
                                                     + ","
                                                     + null
                                                     + ","
                                                     + masterID
                                                     + ","
                                                     + tileID
                                                     + ","
                                                     + this.nil_to
                                                     + ","
                                                     + 1 + ")";

                                       
                                       list.add(insertQuery);
                                       
                                       
                                       tileID = tileMap.get(Constant.TABLE_3_7);
                                       insertQuery = "insert into [gstr3].[tblgstr3TurnOverDetails]([GSTIN],[TaxPeriod],[MasterID],[TileID],[TurnOver],[IsActive]) values ("
                                                            + null
                                                            + ","
                                                            + null
                                                            + ","
                                                            + masterID
                                                            + ","
                                                            + tileID
                                                            + ","
                                                            + this.non_to
                                                            + ","
                                                            + 1 + ")";
                                       list.add(insertQuery);

                                       tileID = tileMap.get(Constant.TABLE_3_8);
                                       insertQuery = "insert into [gstr3].[tblgstr3TurnOverDetails]([GSTIN],[TaxPeriod],[MasterID],[TileID],[TurnOver],[IsActive]) values ("
                                                            + null
                                                            + ","
                                                            + null
                                                            + ","
                                                            + masterID
                                                            + ","
                                                            + tileID
                                                            + ","
                                                            + this.net_to
                                                            + ","
                                                            + 1 + ")";
                                              
                                              list.add(insertQuery);
     
     return list;
}

	@Override
	public String toString() {
		return "Tod [txble_to=" + txble_to + ", gnet_to=" + gnet_to
				+ ", net_txble=" + net_txble + ", zrsp_to=" + zrsp_to
				+ ", zrswp_to=" + zrswp_to + ", exp_to=" + exp_to + ", nil_to="
				+ nil_to + ", exmptd_to=" + exmptd_to + ", non_to=" + non_to
				+ ", net_to=" + net_to + "]";
	}

 
}

/*
 * Taxable Supply
 */
class TaxSup {
	
	private String tx_r;
	private double iamt;
	private double camt;
	private double samt;
	public double getCamt() {
		return camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	public double getSamt() {
		return samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double txval;
	private double cess;

	 
private double essen;
	
	private double merrit;
	
	private double stndrd;
	
	private double peak;
	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(int iamt) {
		this.iamt = iamt;
	}

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		int tileID = tileMap.get(Constant.TABLE_4_1_A);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.cess + "," + 1 + ")";

		List<String> list = new ArrayList<String>();
		list.add(insertQuery);
		return list;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.tx_r = (map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
		}

	@Override
	public String toString() {
		return "TaxSup [tx_r=" + tx_r + ", iamt=" + iamt + ", txval=" + txval
				+ ", cess=" + cess + ", essen=" + essen + ", merrit=" + merrit
				+ ", stndrd=" + stndrd + ", peak=" + peak + "]";
}

}

class RevSup {
	private String tx_r;
	private double iamt;
	private double camt;
	private double samt;
	public double getCamt() {
		return camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	public double getSamt() {
		return samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double txval;
	private double cess;

private double essen;
	
	private double merrit;
	
	private double stndrd;
	
	private double peak;

	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	public double getCess() {
		return this.cess;
	}

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
		this.tx_r =  (map.get(Constant.RATE).toString());
		if(map.get(Constant.TAXABLEVALUE) != null)
		this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
		if(map.get(Constant.IGST_AMOUNT) != null)
		this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
		if(map.get(Constant.CESS_AMOUNT) != null)
		this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_4_1_B);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "RevSup [tx_r=" + tx_r + ", iamt=" + iamt + ", txval=" + txval
				+ ", cess=" + cess + ", essen=" + essen + ", merrit=" + merrit
				+ ", stndrd=" + stndrd + ", peak=" + peak + "]";
}

}

class ZrSupWp {
	private String tx_r;

private double essen;
private double camt;
private double samt;
	public double getCamt() {
	return camt;
}

public void setCamt(double camt) {
	this.camt = camt;
}

public double getSamt() {
	return samt;
}

public void setSamt(double samt) {
	this.samt = samt;
}

	private double merrit;
	
	private double stndrd;
	
	private double peak;
	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
		this.tx_r = (map.get(Constant.RATE).toString());
		if(map.get(Constant.TAXABLEVALUE) != null)
		this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
		if(map.get(Constant.IGST_AMOUNT) != null)
		this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
		if(map.get(Constant.CESS_AMOUNT) != null)
		this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_4_1_C);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "ZrSupWp [tx_r=" + tx_r + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak + ", iamt="
				+ iamt + ", txval=" + txval + ", cess=" + cess + "]";
	}
	
}

class EcommSup {
	private String etin;
	private double essen;
	
	private double merrit;
	
	private double stndrd;
	
	private double peak;
	private double samt;
	private double camt;
	
	public double getSamt() {
		return samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	public double getCamt() {
		return camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getEtin() {
		return this.etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	private String tx_r;

	 

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.tx_r =  (map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
			if(map.get(Constant.EGSIN) != null)
			this.etin = map.get(Constant.EGSIN).toString();
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_4_1_D);

		String gstind = null;
		if (this.etin != null)
			gstind = "'" + this.etin + "'";

		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ gstind
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ null
				+ ","
				+ null
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "EcommSup [etin=" + etin + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak + ", tx_r="
				+ tx_r + ", iamt=" + iamt + ", txval=" + txval + ", cess="
				+ cess + "]";
	}
	
}

// Taxable Supply Inter State
class Inter {
	private ArrayList<TaxSup> tax_sup;

	public ArrayList<TaxSup> getTaxSup() {
		return this.tax_sup;
	}

	public void setTaxSup(ArrayList<TaxSup> tax_sup) {
		this.tax_sup = tax_sup;
	}

	private RevSup rev_sup;

	public RevSup getRevSup() {
		return this.rev_sup;
	}

	public void setRevSup(RevSup rev_sup) {
		this.rev_sup = rev_sup;
	}

	private ArrayList<ZrSupWp> zr_sup_wp;

	public ArrayList<ZrSupWp> getZrSupWp() {
		return this.zr_sup_wp;
	}

	public void setZrSupWp(ArrayList<ZrSupWp> zr_sup_wp) {
		this.zr_sup_wp = zr_sup_wp;
	}

	private ArrayList<EcommSup> ecomm_sup;

	public ArrayList<EcommSup> getEcommSup() {
		return this.ecomm_sup;
	}

	public void setEcommSup(ArrayList<EcommSup> ecomm_sup) {
		this.ecomm_sup = ecomm_sup;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {

		this.tax_sup = new ArrayList<TaxSup>();
		this.zr_sup_wp = new ArrayList<ZrSupWp>();
		this.ecomm_sup = new ArrayList<EcommSup>();
		List<Map<String, Object>> listT4 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_4);
		for (Map<String, Object> map : listT4) {
			if (map.get("SubGroup").equals(Constant.TABLE_4_1_A)) {
				TaxSup taxSup = new TaxSup();
				taxSup.populateRootDTO(map);				
				this.tax_sup.add(taxSup);
			} else if (map.get("SubGroup").equals(Constant.TABLE_4_1_B)) {
				this.rev_sup = new RevSup();
				this.rev_sup.populateRootDTO(map);
				// this.rev_sup.setCess(cess);
			} else if (map.get("SubGroup").equals(Constant.TABLE_4_1_C)) {
				ZrSupWp zeroSup = new ZrSupWp();
				zeroSup.populateRootDTO(map);				
				this.zr_sup_wp.add(zeroSup);
			} else if (map.get("SubGroup").equals(Constant.TABLE_4_1_D)) {
				EcommSup eCommSup = new EcommSup();
				eCommSup.populateRootDTO(map);				
				this.ecomm_sup.add(eCommSup);
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {
		List<String> list = new ArrayList<String>();
		
		if(this.tax_sup != null)
		for (TaxSup taxSup : this.tax_sup) {
			list.addAll(taxSup.fetchInsertScripts(masterID, tileMap));
		}

		if(this.rev_sup != null)
		list.addAll(this.rev_sup.fetchInsertScripts(masterID, tileMap));

		if(this.zr_sup_wp != null)
		for (ZrSupWp zrSup : this.zr_sup_wp) {
			list.addAll(zrSup.fetchInsertScripts(masterID, tileMap));
		}

		if(this.ecomm_sup != null)
		for (EcommSup ecomSup : this.ecomm_sup) {
			list.addAll(ecomSup.fetchInsertScripts(masterID, tileMap));
		}
		return list;
	}

	@Override
	public String toString() {
		return "Inter [tax_sup=" + tax_sup + ", rev_sup=" + rev_sup
				+ ", zr_sup_wp=" + zr_sup_wp + ", ecomm_sup=" + ecomm_sup + "]";
}

}

// 4.3.1.A Inter
class TaxSup2 {
	private String tx_r;
	private double camt;
	private double samt;
	private double cess;
	
private double essen;
	
	public double getCamt() {
	return camt;
}

public void setCamt(double camt) {
	this.camt = camt;
}

public double getSamt() {
	return samt;
}

public void setSamt(double samt) {
	this.samt = samt;
}

public double getCess() {
	return cess;
}

public void setCess(double cess) {
	this.cess = cess;
}

	private double merrit;
	
	private double stndrd;
	
	private double peak;


	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	public double getDiff_val() {
		return diff_val;
	}

	public void setDiff_val(double diff_val) {
		this.diff_val = diff_val;
	}

	private double diff_val;

	public double getDiffVal() {
		return this.diff_val;
	}

	public void setDiffVal(double diff_val) {
		this.diff_val = diff_val;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double csamt;

	public double getCsamt() {
		return this.csamt;
	}

	public void setCsamt(double csamt) {
		this.csamt = csamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
		this.tx_r = map.get(Constant.RATE).toString();
		if(map.get(Constant.TAXABLEVALUE) != null)
		this.diff_val = Double.valueOf(map.get(Constant.TAXABLEVALUE)
				.toString());
		if(map.get(Constant.IGST_AMOUNT) != null)
		this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
		if(map.get(Constant.CESS_AMOUNT) != null)
		this.csamt = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_4_3_1_A);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ null
				+ ","
				+ this.diff_val
				+ ","
				+ this.iamt
				+ ","
				+ null
				+ ","
				+ null
				+ "," + this.csamt + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}
	@Override
	public String toString() {
		return "TaxSup2 [tx_r=" + tx_r + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak
				+ ", diff_val=" + diff_val + ", iamt=" + iamt + ", csamt="
				+ csamt + "]";
	}	
}

// 4.3.1.B Zero rated supply Outward Amendment
class ZrSupWp2 {
	private String tx_r;
	public double getCamt() {
		return camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	public double getSamt() {
		return samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	public double getCess() {
		return cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	private double camt;
	private double samt;
	private double cess;
	

	 
private double essen;
	
	private double merrit;
	
	private double stndrd;
	
	private double peak;
	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	private double diff_val;

	public double getDiffVal() {
		return this.diff_val;
	}

	public void setDiffVal(double diff_val) {
		this.diff_val = diff_val;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double csamt;

	public double getCsamt() {
		return this.csamt;
	}

	public void setCsamt(double csamt) {
		this.csamt = csamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.tx_r = (map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.diff_val = Double.valueOf(map.get(Constant.TAXABLEVALUE)
					.toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.csamt = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());

	}

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	public double getDiff_val() {
		return diff_val;
	}

	public void setDiff_val(double diff_val) {
		this.diff_val = diff_val;
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_4_3_1_B);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ null
				+ ","
				+ this.diff_val
				+ ","
				+ this.iamt
				+ ","
				+ null
				+ ","
				+ null
				+ "," + this.csamt + "," + 1 + ")";
		list.add(insertQuery);

		return list;
	}

	@Override
	public String toString() {
		return "ZrSupWp2 [tx_r=" + tx_r + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak
				+ ", diff_val=" + diff_val + ", iamt=" + iamt + ", csamt="
				+ csamt + "]";
	}
}

// 4.3.1.C Inter State Outwrad supply amendment e-Commerce
class EcommSup2 {
	private String etin;
private double essen;
private double camt;
public double getCamt() {
	return camt;
}

public void setCamt(double camt) {
	this.camt = camt;
}

public double getSamt() {
	return samt;
}

public void setSamt(double samt) {
	this.samt = samt;
}

public double getCess() {
	return cess;
}

public void setCess(double cess) {
	this.cess = cess;
}

private double samt;
private double cess;

	private double merrit;
	
	private double stndrd;
	
	private double peak;
	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getEtin() {
		return this.etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	private String tx_r;

	 

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	public double getDiff_val() {
		return diff_val;
	}

	public void setDiff_val(double diff_val) {
		this.diff_val = diff_val;
	}

	private double diff_val;

	public double getDiffVal() {
		return this.diff_val;
	}

	public void setDiffVal(double diff_val) {
		this.diff_val = diff_val;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double csamt;

	public double getCsamt() {
		return this.csamt;
	}

	public void setCsamt(double csamt) {
		this.csamt = csamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.tx_r = map.get(Constant.RATE).toString();
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.diff_val = Double.valueOf(map.get(Constant.TAXABLEVALUE)
					.toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.csamt = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
			if(map.get(Constant.EGSIN) != null)
			this.etin = map.get(Constant.EGSIN).toString();
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		String gstind = null;
		if (this.etin != null)
			gstind = "'" + this.etin + "'";
		int tileID = tileMap.get(Constant.TABLE_4_3_1_C);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ gstind
				+ ","
				+ this.diff_val
				+ ","
				+ this.iamt
				+ ","
				+ null
				+ ","
				+ null + "," + this.csamt + "," + 1 + ")";
		list.add(insertQuery);

		return list;
	}

	@Override
	public String toString() {
		return "EcommSup2 [etin=" + etin + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak + ", tx_r="
				+ tx_r + ", diff_val=" + diff_val + ", iamt=" + iamt
				+ ", csamt=" + csamt + "]";
	}
}

// 4.3.1 Outward Supply Amendment
class Inter2 {
	private ArrayList<TaxSup2> tax_sup;
	private double ttl_inter;
	public ArrayList<TaxSup2> getTax_sup() {
		return tax_sup;
	}

	public void setTax_sup(ArrayList<TaxSup2> tax_sup) {
		this.tax_sup = tax_sup;
	}

	public double getTtl_inter() {
		return ttl_inter;
	}

	public void setTtl_inter(double ttl_inter) {
		this.ttl_inter = ttl_inter;
	}

	public ArrayList<ZrSupWp2> getZr_sup_wp() {
		return zr_sup_wp;
	}

	public void setZr_sup_wp(ArrayList<ZrSupWp2> zr_sup_wp) {
		this.zr_sup_wp = zr_sup_wp;
	}

	public ArrayList<EcommSup2> getEcomm_sup() {
		return ecomm_sup;
	}

	public void setEcomm_sup(ArrayList<EcommSup2> ecomm_sup) {
		this.ecomm_sup = ecomm_sup;
	}

	public ArrayList<TaxSup2> getTaxSup() {
		return this.tax_sup;
	}

	public void setTaxSup(ArrayList<TaxSup2> tax_sup) {
		this.tax_sup = tax_sup;
	}

	private ArrayList<ZrSupWp2> zr_sup_wp;

	public ArrayList<ZrSupWp2> getZrSupWp() {
		return this.zr_sup_wp;
	}

	public void setZrSupWp(ArrayList<ZrSupWp2> zr_sup_wp) {
		this.zr_sup_wp = zr_sup_wp;
	}

	private ArrayList<EcommSup2> ecomm_sup;

	public ArrayList<EcommSup2> getEcommSup() {
		return this.ecomm_sup;
	}

	public void setEcommSup(ArrayList<EcommSup2> ecomm_sup) {
		this.ecomm_sup = ecomm_sup;
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();
		
		if(this.tax_sup != null)
		for (TaxSup2 taxSup : this.tax_sup) {
			list.addAll(taxSup.fetchInsertScripts(masterID, tileMap));
		}

		if(this.zr_sup_wp != null)
		for (ZrSupWp2 zrSup : this.zr_sup_wp) {
			list.addAll(zrSup.fetchInsertScripts(masterID, tileMap));
		}

		if(this.ecomm_sup != null)
		for (EcommSup2 ecomSup : this.ecomm_sup) {
			list.addAll(ecomSup.fetchInsertScripts(masterID, tileMap));
		}
		return list;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.tax_sup = new ArrayList<TaxSup2>();
		this.zr_sup_wp = new ArrayList<ZrSupWp2>();
		this.ecomm_sup = new ArrayList<EcommSup2>();
		List<Map<String, Object>> listT4 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_4);
		for (Map<String, Object> map : listT4) {
			if (map.get("SubGroup").equals(Constant.TABLE_4_3_1_A)) {
				TaxSup2 taxSup2 = new TaxSup2();
				taxSup2.populateRootDTO(map);				
				this.tax_sup.add(taxSup2);
			} else if (map.get("SubGroup").equals(Constant.TABLE_4_3_1_B)) {
				ZrSupWp2 zrSup2 = new ZrSupWp2();
				zrSup2.populateRootDTO(map);		
				this.zr_sup_wp.add(zrSup2);
			} else if (map.get("SubGroup").equals(Constant.TABLE_4_3_1_C)) {
				EcommSup2 eCommSup2 = new EcommSup2();
				eCommSup2.populateRootDTO(map);		
				this.ecomm_sup.add(eCommSup2);
			}
		}

	}
}

// 4.3.2.A Intra state Taxable Supply Outward amendment
class TaxSup3 {
	private String tx_r;
	private double iamt;
	private double cess;
	
private double essen;
	
	private double merrit;
	
	private double stndrd;
	
	public double getIamt() {
		return iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	public double getCess() {
		return cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	private double peak;
	 
	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	public double getDiff_val() {
		return diff_val;
	}

	public void setDiff_val(double diff_val) {
		this.diff_val = diff_val;
	}

	private double diff_val;

	public double getDiffVal() {
		return this.diff_val;
	}

	public void setDiffVal(double diff_val) {
		this.diff_val = diff_val;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double csamt;

	public double getCsamt() {
		return this.csamt;
	}

	public void setCsamt(double csamt) {
		this.csamt = csamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
		this.tx_r = map.get(Constant.RATE).toString();
		if(map.get(Constant.TAXABLEVALUE) != null)
		this.diff_val = Double.valueOf(map.get(Constant.TAXABLEVALUE)
				.toString());
		if(map.get(Constant.CGST_AMOUNT) != null)
		this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
		if(map.get(Constant.SGST_AMOUNT) != null)
		this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
		if(map.get(Constant.CESS_AMOUNT) != null)
		this.csamt = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_4_3_2_A);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ null
				+ ","
				+ this.diff_val
				+ ","
				+ null
				+ ","
				+ this.camt
				+ ","
				+ this.samt + "," + this.csamt + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "TaxSup3 [tx_r=" + tx_r + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak
				+ ", diff_val=" + diff_val + ", camt=" + camt + ", samt="
				+ samt + ", csamt=" + csamt + "]";
	}	
}

// 4.3.2.B Intra State - Ecommerce outward amendment
class EcommSup3 {
	private String etin;
private double essen;
private double iamt;
private double cess;

	public double getIamt() {
	return iamt;
}

public void setIamt(double iamt) {
	this.iamt = iamt;
}

public double getCess() {
	return cess;
}

public void setCess(double cess) {
	this.cess = cess;
}

	private double merrit;
	
	private double stndrd;
	
	private double peak;
	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getEtin() {
		return this.etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	private String tx_r;

	 

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	public double getDiff_val() {
		return diff_val;
	}

	public void setDiff_val(double diff_val) {
		this.diff_val = diff_val;
	}

	private double diff_val;

	public double getDiffVal() {
		return this.diff_val;
	}

	public void setDiffVal(double diff_val) {
		this.diff_val = diff_val;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double csamt;

	public double getCsamt() {
		return this.csamt;
	}

	public void setCsamt(double csamt) {
		this.csamt = csamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.tx_r = map.get(Constant.RATE).toString();
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.diff_val = Double.valueOf(map.get(Constant.TAXABLEVALUE)
					.toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.csamt = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
			if(map.get(Constant.EGSIN) != null)
			this.etin = map.get(Constant.EGSIN).toString();
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		String gstind = null;
		if (this.etin != null)
			gstind = "'" + this.etin + "'";

		int tileID = tileMap.get(Constant.TABLE_4_3_2_B);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ gstind
				+ ","
				+ this.diff_val
				+ ","
				+ null
				+ ","
				+ this.camt
				+ ","
				+ this.samt + "," + this.csamt + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "EcommSup3 [etin=" + etin + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak + ", tx_r="
				+ tx_r + ", diff_val=" + diff_val + ", camt=" + camt
				+ ", samt=" + samt + ", csamt=" + csamt + "]";
	}	
}

// 4.3.2 Intra State outward supply
class Intra {
	private ArrayList<TaxSup3> tax_sup;
	private double ttl_Intra;
	public ArrayList<TaxSup3> getTax_sup() {
		return tax_sup;
	}

	public void setTax_sup(ArrayList<TaxSup3> tax_sup) {
		this.tax_sup = tax_sup;
	}

 
	public double getTtl_Intra() {
		return ttl_Intra;
	}

	public void setTtl_Intra(double ttl_Intra) {
		this.ttl_Intra = ttl_Intra;
	}

	public ArrayList<EcommSup3> getEcomm_sup() {
		return ecomm_sup;
	}

	public void setEcomm_sup(ArrayList<EcommSup3> ecomm_sup) {
		this.ecomm_sup = ecomm_sup;
	}

	public ArrayList<TaxSup3> getTaxSup() {
		return this.tax_sup;
	}

	public void setTaxSup(ArrayList<TaxSup3> tax_sup) {
		this.tax_sup = tax_sup;
	}

	private ArrayList<EcommSup3> ecomm_sup;

	public ArrayList<EcommSup3> getEcommSup() {
		return this.ecomm_sup;
	}

	public void setEcommSup(ArrayList<EcommSup3> ecomm_sup) {
		this.ecomm_sup = ecomm_sup;
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();
		
		if(this.tax_sup != null)
		for (TaxSup3 taxSup : this.tax_sup) {
			list.addAll(taxSup.fetchInsertScripts(masterID, tileMap));
		}

		if(this.ecomm_sup != null)
		for (EcommSup3 ecomSup : this.ecomm_sup) {
			list.addAll(ecomSup.fetchInsertScripts(masterID, tileMap));
		}

		return list;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.tax_sup = new ArrayList<TaxSup3>();
		this.ecomm_sup = new ArrayList<EcommSup3>();
		List<Map<String, Object>> listT4 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_4);
		for (Map<String, Object> map : listT4) {
			if (map.get("SubGroup").equals(Constant.TABLE_4_3_2_A)) {
				TaxSup3 taxSup3 = new TaxSup3();
				taxSup3.populateRootDTO(map);				
				this.tax_sup.add(taxSup3);

			} else if (map.get("SubGroup").equals(Constant.TABLE_4_3_2_B)) {
				EcommSup3 eCommSup3 = new EcommSup3();
				eCommSup3.populateRootDTO(map);
				
				this.ecomm_sup.add(eCommSup3);
			}
		}
	}

	@Override
	public String toString() {
		return "Intra [tax_sup=" + tax_sup + ", ttl_Intra=" + ttl_Intra
				+ ", ecomm_sup=" + ecomm_sup + "]";
	}	
}

// 4.3 Outward Supply - Amendment
class OutAmend {
	private Inter2 inter;
	
	private double osup_ttl_igst_amnd;
	private double osup_ttl_cgst_amnd;
	private double osup_ttl_sgst_amnd;
	private double osup_ttl_cess_amnd;
	public double getOsup_ttl_igst_amnd() {
		return osup_ttl_igst_amnd;
	}

	public void setOsup_ttl_igst_amnd(double osup_ttl_igst_amnd) {
		this.osup_ttl_igst_amnd = osup_ttl_igst_amnd;
	}

	public double getOsup_ttl_cgst_amnd() {
		return osup_ttl_cgst_amnd;
	}

	public void setOsup_ttl_cgst_amnd(double osup_ttl_cgst_amnd) {
		this.osup_ttl_cgst_amnd = osup_ttl_cgst_amnd;
	}

	public double getOsup_ttl_sgst_amnd() {
		return osup_ttl_sgst_amnd;
	}

	public void setOsup_ttl_sgst_amnd(double osup_ttl_sgst_amnd) {
		this.osup_ttl_sgst_amnd = osup_ttl_sgst_amnd;
	}

	public double getOsup_ttl_cess_amnd() {
		return osup_ttl_cess_amnd;
	}

	public void setOsup_ttl_cess_amnd(double osup_ttl_cess_amnd) {
		this.osup_ttl_cess_amnd = osup_ttl_cess_amnd;
	}

	private double net_diff_amnd;
public double getNet_diff_amnd() {
		return net_diff_amnd;
	}

	public void setNet_diff_amnd(double net_diff_amnd) {
		this.net_diff_amnd = net_diff_amnd;
	}

private double ttl_inter;
	public Inter2 getInter() {
		return this.inter;
	}

	public double getTtl_inter() {
		return ttl_inter;
	}

	public void setTtl_inter(double ttl_inter) {
		this.ttl_inter = ttl_inter;
	}

	public void setInter(Inter2 inter) {
		this.inter = inter;
	}

	private Intra intra;

	public Intra getIntra() {
		return this.intra;
	}

	public void setIntra(Intra intra) {
		this.intra = intra;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.inter = new Inter2();
		this.intra = new Intra();
		this.inter.populateRootDTO(mapGroupByTableType);
		this.intra.populateRootDTO(mapGroupByTableType);
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if(this.inter != null)
		list.addAll(this.inter.fetchInsertScripts(masterID, tileMap));
		
		if(this.intra != null)
		list.addAll(this.intra.fetchInsertScripts(masterID, tileMap));
		return list;

	}

	@Override
	public String toString() {
		return "OutAmend [inter=" + inter + ", osup_ttl_igst_amnd="
				+ osup_ttl_igst_amnd + ", osup_ttl_cgst_amnd="
				+ osup_ttl_cgst_amnd + ", osup_ttl_sgst_amnd="
				+ osup_ttl_sgst_amnd + ", osup_ttl_cess_amnd="
				+ osup_ttl_cess_amnd + ", net_diff_amnd=" + net_diff_amnd
				+ ", ttl_inter=" + ttl_inter + ", intra=" + intra + "]";
	}	
}

class TaxSup4 {
	private String tx_r;

private double essen;
	private double iamt;
	public double getIamt() {
		return iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double merrit;
	
	private double stndrd;
	
	private double peak;

	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.tx_r = map.get(Constant.RATE).toString();
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_4_2_A);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ null
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "TaxSup4 [tx_r=" + tx_r + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak + ", camt="
				+ camt + ", txval=" + txval + ", samt=" + samt + ", cess="
				+ cess + "]";
	}	
}

// 4.2.B Intra State Reverse Supply
class RevSup2 {
	private String tx_r;
private double essen;
	
	private double merrit;
	
	private double stndrd;
	
	private double peak;
	 
	private double iamt;
	public double getIamt() {
		return iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.tx_r = map.get(Constant.RATE).toString();
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_4_2_B);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ null
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "RevSup2 [tx_r=" + tx_r + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak + ", camt="
				+ camt + ", txval=" + txval + ", samt=" + samt + ", cess="
				+ cess + "]";
}
}

// 4.2.C Intra State outward supply Ecommerce
class EcommSup4 {
	private String etin;
private double essen;
	
	private double merrit;
	/**
	 * 
	 */
	private double iamt;
	public double getIamt() {
		return iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double stndrd;
	
	private double peak;
	public double getEssen() {
		return essen;
	}

	public void setEssen(double essen) {
		this.essen = essen;
	}

	public double getMerrit() {
		return merrit;
	}

	public void setMerrit(double merrit) {
		this.merrit = merrit;
	}

	public double getStndrd() {
		return stndrd;
	}

	public void setStndrd(double stndrd) {
		this.stndrd = stndrd;
	}

	public double getPeak() {
		return peak;
	}

	public void setPeak(double peak) {
		this.peak = peak;
	}

	public String getEtin() {
		return this.etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	private String tx_r;	 

	public String getTx_r() {
		return tx_r;
	}

	public void setTx_r(String tx_r) {
		this.tx_r = tx_r;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.tx_r = (map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
			if(map.get(Constant.EGSIN) != null)
			this.etin = map.get(Constant.EGSIN).toString();

	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		String gstind = null;
		if (this.etin != null)
			gstind = "'" + this.etin + "'";

		int tileID = tileMap.get(Constant.TABLE_4_2_C);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.tx_r
				+ ","
				+ gstind
				+ ","
				+ this.txval
				+ ","
				+ null
				+ ","
				+ this.camt
				+ ","
				+ this.samt + "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "EcommSup4 [etin=" + etin + ", essen=" + essen + ", merrit="
				+ merrit + ", stndrd=" + stndrd + ", peak=" + peak + ", tx_r="
				+ tx_r + ", camt=" + camt + ", txval=" + txval + ", samt="
				+ samt + ", cess=" + cess + "]";
}

}

class Intra2 {
	private ArrayList<TaxSup4> tax_sup;

	public ArrayList<TaxSup4> getTaxSup() {
		return this.tax_sup;
	}

	public void setTaxSup(ArrayList<TaxSup4> tax_sup) {
		this.tax_sup = tax_sup;
	}

	private RevSup2 rev_sup;

	public RevSup2 getRevSup() {
		return this.rev_sup;
	}

	public void setRevSup(RevSup2 rev_sup) {
		this.rev_sup = rev_sup;
	}

	private ArrayList<EcommSup4> ecomm_sup;

	public ArrayList<EcommSup4> getEcommSup() {
		return this.ecomm_sup;
	}

	public void setEcommSup(ArrayList<EcommSup4> ecomm_sup) {
		this.ecomm_sup = ecomm_sup;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.tax_sup = new ArrayList<TaxSup4>();
		this.ecomm_sup = new ArrayList<EcommSup4>();
		List<Map<String, Object>> listT4 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_4);
		for (Map<String, Object> map : listT4) {
			if (map.get("SubGroup").equals(Constant.TABLE_4_2_A)) {
				TaxSup4 taxSup = new TaxSup4();
				taxSup.populateRootDTO(map);				
				this.tax_sup.add(taxSup);
			} else if (map.get("SubGroup").equals(Constant.TABLE_4_2_B)) {
				this.rev_sup = new RevSup2();
				this.rev_sup.populateRootDTO(map);
				// this.rev_sup.setCess(cess);
			} else if (map.get("SubGroup").equals(Constant.TABLE_4_2_C)) {
				EcommSup4 eCommSup = new EcommSup4();
				eCommSup.populateRootDTO(map);		
				this.ecomm_sup.add(eCommSup);
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();
		
		if(this.tax_sup != null)
		for (TaxSup4 taxSup : this.tax_sup) {
			list.addAll(taxSup.fetchInsertScripts(masterID, tileMap));
		}
		
		if(this.rev_sup != null)
		list.addAll(this.rev_sup.fetchInsertScripts(masterID, tileMap));
		
		if(this.ecomm_sup != null)
		for (EcommSup4 zrSup : this.ecomm_sup) {
			list.addAll(zrSup.fetchInsertScripts(masterID, tileMap));
		}
		return list;

	}

	@Override
	public String toString() {
		return "Intra2 [tax_sup=" + tax_sup + ", rev_sup=" + rev_sup
				+ ", ecomm_sup=" + ecomm_sup + "]";
}
}

/*
 * 4. Outward Supply
 */
class Osup {
	
	private Inter inter;
	private double net_diff;
	private double osup_ttl_igst;
	private double osup_ttl_cgst;
	private double osup_ttl_sgst;
	private double osup_ttl_cess;
	private double osup_ttl_igst_amendments = 0.00;
	private double osup_ttl_cgst_amendments = 0.00;
	private double osup_ttl_sgst_amendments = 0.00;
	private double osup_ttl_cess_amendments = 0.00;
	public double getOsup_ttl_igst_amendments() {
		return osup_ttl_igst_amendments;
	}

	public void setOsup_ttl_igst_amendments(double osup_ttl_igst_amendments) {
		this.osup_ttl_igst_amendments = osup_ttl_igst_amendments;
	}

	public double getOsup_ttl_cgst_amendments() {
		return osup_ttl_cgst_amendments;
	}

	public void setOsup_ttl_cgst_amendments(double osup_ttl_cgst_amendments) {
		this.osup_ttl_cgst_amendments = osup_ttl_cgst_amendments;
	}

	public double getOsup_ttl_sgst_amendments() {
		return osup_ttl_sgst_amendments;
	}

	public void setOsup_ttl_sgst_amendments(double osup_ttl_sgst_amendments) {
		this.osup_ttl_sgst_amendments = osup_ttl_sgst_amendments;
	}

	public double getOsup_ttl_cess_amendments() {
		return osup_ttl_cess_amendments;
	}

	public void setOsup_ttl_cess_amendments(double osup_ttl_cess_amendments) {
		this.osup_ttl_cess_amendments = osup_ttl_cess_amendments;
	}

	private Map<String, Map<String, Double[]>> custom_4a_tiles = new HashMap<String, Map<String, Double[]>>();
	 
	private double ttl_inter_outwards;
	private double ttl_intra_outwards;
	private double ttl_inter_amendments;
	private double ttl_intra_amendments;
	
	private double tttl_sup_outwards;
	private double tttl_sup_amendments;
	
	 
	 

	 

	public double getTtl_intra_outwards() {
		return ttl_intra_outwards;
	}

	public void setTtl_intra_outwards(double ttl_intra_outwards) {
		this.ttl_intra_outwards = ttl_intra_outwards;
	}

	public double getTtl_intra_amendments() {
		return ttl_intra_amendments;
	}

	public void setTtl_intra_amendments(double ttl_intra_amendments) {
		this.ttl_intra_amendments = ttl_intra_amendments;
	}

	 

	public double getTttl_sup_outwards() {
		return tttl_sup_outwards;
	}

	public void setTttl_sup_outwards(double tttl_sup_outwards) {
		this.tttl_sup_outwards = tttl_sup_outwards;
	}

	public double getTttl_sup_amendments() {
		return tttl_sup_amendments;
	}

	public void setTttl_sup_amendments(double tttl_sup_amendments) {
		this.tttl_sup_amendments = tttl_sup_amendments;
	}

	public Map<String, Map<String, Double[]>> getCustom_4a_tiles() {
		return custom_4a_tiles;
	}

	public void setCustom_4a_tiles(
			Map<String, Map<String, Double[]>> custom_4a_tiles) {
		this.custom_4a_tiles = custom_4a_tiles;
	}

 

	 
	
	public double getTtl_inter_outwards() {
		return ttl_inter_outwards;
	}

	public void setTtl_inter_outwards(double ttl_inter_outwards) {
		this.ttl_inter_outwards = ttl_inter_outwards;
	}

	 
	public double getTtl_inter_amendments() {
		return ttl_inter_amendments;
	}

	public void setTtl_inter_amendments(double ttl_inter_amendments) {
		this.ttl_inter_amendments = ttl_inter_amendments;
	}

	private double ttl_intra;
	public double getNet_diff() {
		return net_diff;
	}

	public double getTtl_intra() {
		return ttl_intra;
	}

	public void setTtl_intra(double ttl_intra) {
		this.ttl_intra = ttl_intra;
	}

	public void setNet_diff(double net_diff) {
		this.net_diff = net_diff;
	}

	public double getOsup_ttl_igst() {
		return osup_ttl_igst;
	}

	public void setOsup_ttl_igst(double osup_ttl_igst) {
		this.osup_ttl_igst = osup_ttl_igst;
	}

	public double getOsup_ttl_cgst() {
		return osup_ttl_cgst;
	}

	public void setOsup_ttl_cgst(double osup_ttl_cgst) {
		this.osup_ttl_cgst = osup_ttl_cgst;
	}

	public double getOsup_ttl_sgst() {
		return osup_ttl_sgst;
	}

	public void setOsup_ttl_sgst(double osup_ttl_sgst) {
		this.osup_ttl_sgst = osup_ttl_sgst;
	}

	public double getOsup_ttl_cess() {
		return osup_ttl_cess;
	}

	public void setOsup_ttl_cess(double osup_ttl_cess) {
		this.osup_ttl_cess = osup_ttl_cess;
	}

	public OutAmend getOut_amend() {
		return out_amend;
	}

	public void setOut_amend(OutAmend out_amend) {
		this.out_amend = out_amend;
	}

	public Inter getInter() {
		return this.inter;
	}

	public void setInter(Inter inter) {
		this.inter = inter;
	}

	private OutAmend out_amend;

	public OutAmend getOutAmend() {
		return this.out_amend;
	}

	public void setOutAmend(OutAmend out_amend) {
		this.out_amend = out_amend;
	}

	private Intra2 intra;

	public Intra2 getIntra() {
		return this.intra;
	}

	public void setIntra(Intra2 intra) {
		this.intra = intra;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		inter = new Inter();
		intra = new Intra2();
		out_amend = new OutAmend();
		this.inter.populateRootDTO(mapGroupByTableType);
		this.intra.populateRootDTO(mapGroupByTableType);
		this.out_amend.populateRootDTO(mapGroupByTableType);
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {
		List<String> list = new ArrayList<String>();
		
		if(this.inter != null)
		list.addAll(this.inter.fetchInsertScripts(masterID, tileMap));
		
		if(this.intra != null)
		list.addAll(this.intra.fetchInsertScripts(masterID, tileMap));
		
		if(this.out_amend != null)
		list.addAll(this.out_amend.fetchInsertScripts(masterID, tileMap));

		return list;
	}

	@Override
	public String toString() {
		return "Osup [inter=" + inter + ", net_diff=" + net_diff
				+ ", osup_ttl_igst=" + osup_ttl_igst + ", osup_ttl_cgst="
				+ osup_ttl_cgst + ", osup_ttl_sgst=" + osup_ttl_sgst
				+ ", osup_ttl_cess=" + osup_ttl_cess + ", ttl_inter="
				+ ttl_inter_outwards + ", tttl_sup=" + tttl_sup_outwards + ", ttl_intra="
				+ ttl_intra + ", out_amend=" + out_amend + ", intra=" + intra
				+ "]";
	}
}

// 5.A.1 Inter State Inward Supply
class InterDet {
	private double txrt;

	public double getTxrt() {
		return this.txrt;
	}

	public void setTxrt(double txrt) {
		this.txrt = txrt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.txrt = Double.valueOf(map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_5_A_1);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.txrt
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "InterDet [txrt=" + txrt + ", txval=" + txval + ", cess=" + cess
				+ ", iamt=" + iamt + "]";
}
}

// Intra State Inward Supply 5.A.2
class IntraDet {
	private double txrt;

	public double getTxrt() {
		return this.txrt;
	}

	public void setTxrt(double txrt) {
		this.txrt = txrt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	public void populateRootDTO(Map<String, Object> map) {if(map.get(Constant.RATE) != null)
		this.txrt = Double.valueOf(map.get(Constant.RATE).toString());
		if(map.get(Constant.TAXABLEVALUE) != null)
		this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
		if(map.get(Constant.CGST_AMOUNT) != null)
		this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
		if(map.get(Constant.SGST_AMOUNT) != null)
		this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
		if(map.get(Constant.CESS_AMOUNT) != null)
		this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_5_A_2);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.txrt
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ null
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "IntraDet [txrt=" + txrt + ", txval=" + txval + ", cess=" + cess
				+ ", camt=" + camt + ", samt=" + samt + "]";
}
}

// 5A. Taxpay Receivable Inward supply
class TxpyRc {
	private ArrayList<InterDet> inter_det;
	private double netIgstInter;
	private double netCgstInter;
	private double netSgstInter;
	private double netIamtIntra;
	private double netIamtInter;
	private double nettaxInter;
	private double nettaxIntra;
	private double netCamtIntra;
	private double netSamtIntra;
	private double netCessIntra;
	public double getNetIamtIntra() {
		return netIamtIntra;
	}

	public void setNetIamtIntra(double netIamtIntra) {
		this.netIamtIntra = netIamtIntra;
	}

	public double getNetIamtInter() {
		return netIamtInter;
	}

	public void setNetIamtInter(double netIamtInter) {
		this.netIamtInter = netIamtInter;
	}

	 

	public double getNettaxInter() {
		return nettaxInter;
	}

	public void setNettaxInter(double nettaxInter) {
		this.nettaxInter = nettaxInter;
	}

	public double getNettaxIntra() {
		return nettaxIntra;
	}

	public void setNettaxIntra(double nettaxIntra) {
		this.nettaxIntra = nettaxIntra;
	}

	public double getNetSgstInter() {
		return netSgstInter;
	}

	public void setNetSgstInter(double netSgstInter) {
		this.netSgstInter = netSgstInter;
	}

	public double getNetCessInter() {
		return netCessInter;
	}

	public void setNetCessInter(double netCessInter) {
		this.netCessInter = netCessInter;
	}

	private double netCessInter;
	public ArrayList<InterDet> getInter_det() {
		return inter_det;
	}

	public void setInter_det(ArrayList<InterDet> inter_det) {
		this.inter_det = inter_det;
	}

	public double getNetIgstInter() {
		return netIgstInter;
	}

	public void setNetIgstInter(double netIgstInter) {
		this.netIgstInter = netIgstInter;
	}

	public double getNetCgstInter() {
		return netCgstInter;
	}

	public void setNetCgstInter(double netCgstInter) {
		this.netCgstInter = netCgstInter;
	}

 

	public ArrayList<IntraDet> getIntra_det() {
		return intra_det;
	}

	public void setIntra_det(ArrayList<IntraDet> intra_det) {
		this.intra_det = intra_det;
	}

	public ArrayList<InterDet> getInterDet() {
		return this.inter_det;
	}

	public void setInterDet(ArrayList<InterDet> inter_det) {
		this.inter_det = inter_det;
	}

	private ArrayList<IntraDet> intra_det;

	public ArrayList<IntraDet> getIntraDet() {
		return this.intra_det;
	}

	public void setIntraDet(ArrayList<IntraDet> intra_det) {
		this.intra_det = intra_det;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.inter_det = new ArrayList<InterDet>();
		this.intra_det = new ArrayList<IntraDet>();
		List<Map<String, Object>> listT5 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_5);
		for (Map<String, Object> map : listT5) {
			if (map.get("SubGroup").equals(Constant.TABLE_5_A_1)) {
				InterDet interDet = new InterDet();
				interDet.populateRootDTO(map);				
				this.inter_det.add(interDet);
			} else if (map.get("SubGroup").equals(Constant.TABLE_5_A_2)) {
				IntraDet intraDet = new IntraDet();
				intraDet.populateRootDTO(map);				
				this.intra_det.add(intraDet);
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();
		
		if(this.inter_det != null)
		for (InterDet taxSup : this.inter_det) {
			list.addAll(taxSup.fetchInsertScripts(masterID, tileMap));
		}

		if(this.intra_det != null)
		for (IntraDet zrSup : this.intra_det) {
			list.addAll(zrSup.fetchInsertScripts(masterID, tileMap));
		}

		return list;
	}

	@Override
	public String toString() {
		return "TxpyRc [inter_det=" + inter_det + ", netIgstInter="
				+ netIgstInter + ", netCgstInter=" + netCgstInter
				+ ", netSgstInter=" + netSgstInter + ", netIamtIntra="
				+ netIamtIntra + ", netIamtInter=" + netIamtInter
				+ ", nettaxInter=" + nettaxInter + ", nettaxIntra="
				+ nettaxIntra + ", netCessInter=" + netCessInter
				+ ", intra_det=" + intra_det + "]";
	}	

	public double getNetCamtIntra() {
		return netCamtIntra;
	}

	public void setNetCamtIntra(double netCamtIntra) {
		this.netCamtIntra = netCamtIntra;
	}

	public double getNetSamtIntra() {
		return netSamtIntra;
	}

	public void setNetSamtIntra(double netSamtIntra) {
		this.netSamtIntra = netSamtIntra;
	}

	public double getNetCessIntra() {
		return netCessIntra;
}

	public void setNetCessIntra(double netCessIntra) {
		this.netCessIntra = netCessIntra;
	}	
}

class InterDet2 {
	private double txrt;

	public double getTxrt() {
		return this.txrt;
	}

	public void setTxrt(double txrt) {
		this.txrt = txrt;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(int iamt) {
		this.iamt = iamt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.txrt = Double.valueOf(map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_5_B_1);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.txrt
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "InterDet2 [txrt=" + txrt + ", iamt=" + iamt + ", txval="
				+ txval + ", cess=" + cess + "]";
	}	
}

class IntraDet2 {
	private double txrt;

	public double getTxrt() {
		return this.txrt;
	}

	public void setTxrt(double txrt) {
		this.txrt = txrt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.txrt = Double.valueOf(map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_5_B_2);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.txrt
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ null
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "IntraDet2 [txrt=" + txrt + ", samt=" + samt + ", txval="
				+ txval + ", camt=" + camt + ", cess=" + cess + "]";
}
}

// 5B Tax amend Inward supply
class TxamendRc {
	private ArrayList<InterDet2> inter_det;
	private double netIgstInter;
	public double getNetCessIntra() {
		return netCessIntra;
	}

	public void setNetCessIntra(double netCessIntra) {
		this.netCessIntra = netCessIntra;
	}

	private double netCgstInter;
	private double netSgstInter;
	private double netIamtIntra;
	private double netIamtInter;
	private double nettaxInter;
	private double nettaxIntra;
	private double netCessIntra;
	private double netCessInter;
	private double netCamtIntra;
	private double netSamtIntra;
	public double getNetCamtIntra() {
		return netCamtIntra;
	}

	public void setNetCamtIntra(double netCamtIntra) {
		this.netCamtIntra = netCamtIntra;
	}

	public double getNetSamtIntra() {
		return netSamtIntra;
	}

	public void setNetSamtIntra(double netSamtIntra) {
		this.netSamtIntra = netSamtIntra;
	}

	
	public double getNetCessInter() {
		return netCessInter;
	}

	public void setNetCessInter(double netCessInter) {
		this.netCessInter = netCessInter;
	}

	public ArrayList<InterDet2> getInter_det() {
		return inter_det;
	}

	public void setInter_det(ArrayList<InterDet2> inter_det) {
		this.inter_det = inter_det;
	}

	public double getNetIgstInter() {
		return netIgstInter;
	}

	public void setNetIgstInter(double netIgstInter) {
		this.netIgstInter = netIgstInter;
	}

	public double getNetCgstInter() {
		return netCgstInter;
	}

	public void setNetCgstInter(double netCgstInter) {
		this.netCgstInter = netCgstInter;
	}

	public double getNetSgstInter() {
		return netSgstInter;
	}

	public void setNetSgstInter(double netSgstInter) {
		this.netSgstInter = netSgstInter;
	}

	public double getNetIamtIntra() {
		return netIamtIntra;
	}

	public void setNetIamtIntra(double netIamtIntra) {
		this.netIamtIntra = netIamtIntra;
	}

	public double getNetIamtInter() {
		return netIamtInter;
	}

	public void setNetIamtInter(double netIamtInter) {
		this.netIamtInter = netIamtInter;
	}

	public double getNettaxInter() {
		return nettaxInter;
	}

	public void setNettaxInter(double nettaxInter) {
		this.nettaxInter = nettaxInter;
	}

	public double getNettaxIntra() {
		return nettaxIntra;
	}

	public void setNettaxIntra(double nettaxIntra) {
		this.nettaxIntra = nettaxIntra;
	}

	public ArrayList<IntraDet2> getIntra_det() {
		return intra_det;
	}

	public void setIntra_det(ArrayList<IntraDet2> intra_det) {
		this.intra_det = intra_det;
	}

	public ArrayList<InterDet2> getInterDet() {
		return this.inter_det;
	}

	public void setInterDet(ArrayList<InterDet2> inter_det) {
		this.inter_det = inter_det;
	}

	private ArrayList<IntraDet2> intra_det;

	public ArrayList<IntraDet2> getIntraDet() {
		return this.intra_det;
	}

	public void setIntraDet(ArrayList<IntraDet2> intra_det) {
		this.intra_det = intra_det;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {		
		this.inter_det = new ArrayList<InterDet2>();
		this.intra_det = new ArrayList<IntraDet2>();
		List<Map<String, Object>> listT5 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_5);
		for (Map<String, Object> map : listT5) {
			if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_5_B_1)) {
				InterDet2 interDet2 = new InterDet2();
				interDet2.populateRootDTO(map);				
				this.inter_det.add(interDet2);
			} else if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_5_B_2)) {
				IntraDet2 intraDet2 = new IntraDet2();
				intraDet2.populateRootDTO(map);				
				this.intra_det.add(intraDet2);
			}
		}

	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();
		
		if(this.inter_det != null)
		for (InterDet2 interSup : this.inter_det) {
			list.addAll(interSup.fetchInsertScripts(masterID, tileMap));
		}

		if(this.intra_det != null)
		for (IntraDet2 intraSup : this.intra_det) {
			list.addAll(intraSup.fetchInsertScripts(masterID, tileMap));
		}

		return list;
	}

	@Override
	public String toString() {
		return "TxamendRc [inter_det=" + inter_det + ", netIgstInter="
				+ netIgstInter + ", netCgstInter=" + netCgstInter
				+ ", netSgstInter=" + netSgstInter + ", netIamtIntra="
				+ netIamtIntra + ", netIamtInter=" + netIamtInter
				+ ", nettaxInter=" + nettaxInter + ", nettaxIntra="
				+ nettaxIntra + ", netCessIntra=" + netCessIntra
				+ ", intra_det=" + intra_det + "]";
	}	
}

// Inward Supply
class ISup {
	private TxpyRc txpy_rc;
	private TxamendRc txamend_rc;
	private double ttl_rev_chg;
	private double net_diff;

	public double getNet_diff() {
		return net_diff;
	}

	public void setNet_diff(double net_diff) {
		this.net_diff = net_diff;
	}

	public TxpyRc getTxpy_rc() {
		return txpy_rc;
	}

	public void setTxpy_rc(TxpyRc txpy_rc) {
		this.txpy_rc = txpy_rc;
	}

	public TxamendRc getTxamend_rc() {
		return txamend_rc;
	}

	public void setTxamend_rc(TxamendRc txamend_rc) {
		this.txamend_rc = txamend_rc;
	}

	public double getTtl_rev_chg() {
		return ttl_rev_chg;
	}

	public void setTtl_rev_chg(double ttl_rev_chg) {
		this.ttl_rev_chg = ttl_rev_chg;
	}

	public TxpyRc getTxpyRc() {
		return this.txpy_rc;
	}

	public void setTxpyRc(TxpyRc txpy_rc) {
		this.txpy_rc = txpy_rc;
	}

	public TxamendRc getTxamendRc() {
		return this.txamend_rc;
	}

	public void setTxamendRc(TxamendRc txamend_rc) {
		this.txamend_rc = txamend_rc;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.txpy_rc = new TxpyRc();
		this.txamend_rc = new TxamendRc();
		this.txpy_rc.populateRootDTO(mapGroupByTableType);
		this.txamend_rc.populateRootDTO(mapGroupByTableType);
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if(this.txpy_rc != null)
		list.addAll(this.txpy_rc.fetchInsertScripts(masterID, tileMap));
		
		if(this.txamend_rc != null)
		list.addAll(this.txamend_rc.fetchInsertScripts(masterID, tileMap));
		return list;

	}

	@Override
	public String toString() {
		return "ISup [txpy_rc=" + txpy_rc + ", txamend_rc=" + txamend_rc
				+ ", ttl_rev_chg=" + ttl_rev_chg + "]";
	}	
}

// 6.1 ITC Received
class ItcDet {
	private String ty;

	public String getTy() {
		return this.ty;
	}

	public void setTy(String ty) {
		this.ty = ty;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double i_itc;

	public double getIItc() {
		return this.i_itc;
	}

	public void setIItc(double i_itc) {
		this.i_itc = i_itc;
	}

	private double c_itc;

	public double getCItc() {
		return this.c_itc;
	}

	public void setCItc(double c_itc) {
		this.c_itc = c_itc;
	}

	private double s_itc;

	public double getSItc() {
		return this.s_itc;
	}

	public void setSItc(double s_itc) {
		this.s_itc = s_itc;
	}

	private double cs_itc;

	public double getCsItc() {
		return this.cs_itc;
	}

	public void setCsItc(double cs_itc) {
		this.cs_itc = cs_itc;
	}

	private double itx;

	public double getItx() {
		return this.itx;
	}

	public void setItx(double itx) {
		this.itx = itx;
	}

	private double ctx;

	public double getCtx() {
		return this.ctx;
	}

	public void setCtx(double ctx) {
		this.ctx = ctx;
	}

	private double stx;

	public double getStx() {
		return this.stx;
	}

	public void setStx(double stx) {
		this.stx = stx;
	}

	private double cstx;

	public double getCstx() {
		return this.cstx;
	}

	public void setCstx(double cstx) {
		this.cstx = cstx;
	}

	public void populateRootDTO(Map<String, Object> map) {
		
		/*if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_I_A)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_T_A)) {
			this.ty = "GI";
		}
		if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_I_B)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_T_B)) {
			this.ty = "S";
		}
		if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_I_C)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_T_C)) {
			this.ty = "CG";
		}*/
		this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
		if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_T_A)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_T_B)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_T_C)) {
			if(map.get(Constant.IGST_AMOUNT) != null)
				this.itx = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
				if(map.get(Constant.CGST_AMOUNT) != null)
				this.ctx = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
				if(map.get(Constant.SGST_AMOUNT) != null)
				this.stx = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
				if(map.get(Constant.CESS_AMOUNT) != null)
				this.cstx = Double
						.valueOf(map.get(Constant.CESS_AMOUNT).toString());
		}
		if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_I_A)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_I_B)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_I_C)) {
			if(map.get(Constant.IGST_AMOUNT) != null)
				this.i_itc = Double.valueOf(map.get(Constant.IGST_AMOUNT)
						.toString());
				if(map.get(Constant.CGST_AMOUNT) != null)
				this.c_itc = Double.valueOf(map.get(Constant.CGST_AMOUNT)
						.toString());
				if(map.get(Constant.SGST_AMOUNT) != null)
				this.s_itc = Double.valueOf(map.get(Constant.SGST_AMOUNT)
						.toString());
				if(map.get(Constant.CESS_AMOUNT) != null)
				this.cs_itc = Double.valueOf(map.get(Constant.CESS_AMOUNT)
						.toString());		}

	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if (this.ty.equalsIgnoreCase("GI")) {
			int tileID = tileMap.get(Constant.TABLE_6_1_T_A);
			String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.txval
					+ ","
					+ this.itx
					+ ","
					+ this.ctx
					+ ","
					+ this.stx + "," + this.cstx + "," + 1 + ")";
			list.add(insertQuery);

			tileID = tileMap.get(Constant.TABLE_6_1_I_A);
			insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.txval
					+ ","
					+ this.i_itc
					+ ","
					+ this.c_itc
					+ ","
					+ this.s_itc + "," + this.cs_itc + "," + 1 + ")";
			list.add(insertQuery);
		} else if (this.ty.equalsIgnoreCase("S")) {
			int tileID = tileMap.get(Constant.TABLE_6_1_T_B);
			String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.txval
					+ ","
					+ this.itx
					+ ","
					+ this.ctx
					+ ","
					+ this.stx + "," + this.cstx + "," + 1 + ")";
			list.add(insertQuery);

			tileID = tileMap.get(Constant.TABLE_6_1_I_B);
			insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.txval
					+ ","
					+ this.i_itc
					+ ","
					+ this.c_itc
					+ ","
					+ this.s_itc + "," + this.cs_itc + "," + 1 + ")";
			list.add(insertQuery);
		} else if (this.ty.equalsIgnoreCase("CG")) {
			int tileID = tileMap.get(Constant.TABLE_6_1_T_C);
			String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.txval
					+ ","
					+ this.itx
					+ ","
					+ this.ctx
					+ ","
					+ this.stx + "," + this.cstx + "," + 1 + ")";
			list.add(insertQuery);

			tileID = tileMap.get(Constant.TABLE_6_1_I_C);
			insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.txval
					+ ","
					+ this.i_itc
					+ ","
					+ this.c_itc
					+ ","
					+ this.s_itc + "," + this.cs_itc + "," + 1 + ")";
			list.add(insertQuery);
		}

		return list;

	}

	@Override
	public String toString() {
		return "ItcDet [ty=" + ty + ", txval=" + txval + ", i_itc=" + i_itc
				+ ", c_itc=" + c_itc + ", s_itc=" + s_itc + ", cs_itc="
				+ cs_itc + ", itx=" + itx + ", ctx=" + ctx + ", stx=" + stx
				+ ", cstx=" + cstx + "]";
	}	
}

// 6.2 ITC amendment
class ItcDetAmm {
	private String ty;

	public String getTy() {
		return this.ty;
	}

	public void setTy(String ty) {
		this.ty = ty;
	}

	private double diff_val;

	public double getDiffVal() {
		return this.diff_val;
	}

	public void setDiffVal(double diff_val) {
		this.diff_val = diff_val;
	}

	private double i_itc;

	public double getIItc() {
		return this.i_itc;
	}

	public void setIItc(double i_itc) {
		this.i_itc = i_itc;
	}

	private double c_itc;

	public double getCItc() {
		return this.c_itc;
	}

	public void setCItc(double c_itc) {
		this.c_itc = c_itc;
	}

	private double s_itc;

	public double getSItc() {
		return this.s_itc;
	}

	public void setSItc(double s_itc) {
		this.s_itc = s_itc;
	}

	private double cs_itc;

	public double getCsItc() {
		return this.cs_itc;
	}

	public void setCsItc(double cs_itc) {
		this.cs_itc = cs_itc;
	}

	private double itx;

	public double getItx() {
		return this.itx;
	}

	public void setItx(double itx) {
		this.itx = itx;
	}

	private double ctx;

	public double getCtx() {
		return this.ctx;
	}

	public void setCtx(double ctx) {
		this.ctx = ctx;
	}

	private double stx;

	public double getStx() {
		return this.stx;
	}

	public void setStx(double stx) {
		this.stx = stx;
	}

	private double cstx;

	public double getCstx() {
		return this.cstx;
	}

	public void setCstx(double cstx) {
		this.cstx = cstx;
	}

	public void populateRootDTO(Map<String, Object> map) {
		/*if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_I_A)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_T_A)) {
			this.ty = "GI";
		}
		if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_I_B)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_T_B)) {
			this.ty = "S";
		}
		if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_I_C)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_T_C)) {
			this.ty = "CG";
		}*/
		this.diff_val = Double.valueOf(map.get(Constant.TAXABLEVALUE)
				.toString());

		if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_T_A)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_T_B)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_T_C)) {
			if(map.get(Constant.IGST_AMOUNT) != null)
				this.itx = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
				if(map.get(Constant.CGST_AMOUNT) != null)
				this.ctx = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
				if(map.get(Constant.SGST_AMOUNT) != null)
				this.stx = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
				if(map.get(Constant.CESS_AMOUNT) != null)
				this.cstx = Double
						.valueOf(map.get(Constant.CESS_AMOUNT).toString());
		}
		if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_I_A)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_I_B)
				|| map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_I_C)) {
			if(map.get(Constant.IGST_AMOUNT) != null)
				this.i_itc = Double.valueOf(map.get(Constant.IGST_AMOUNT)
						.toString());
				if(map.get(Constant.CGST_AMOUNT) != null)
				this.c_itc = Double.valueOf(map.get(Constant.CGST_AMOUNT)
						.toString());
				if(map.get(Constant.SGST_AMOUNT) != null)
				this.s_itc = Double.valueOf(map.get(Constant.SGST_AMOUNT)
						.toString());
				if(map.get(Constant.CESS_AMOUNT) != null)
				this.cs_itc = Double.valueOf(map.get(Constant.CESS_AMOUNT)
						.toString());
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if (this.ty.equalsIgnoreCase("GI")) {
			int tileID = tileMap.get(Constant.TABLE_6_2_T_A);
			String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.diff_val
					+ ","
					+ this.itx
					+ ","
					+ this.ctx
					+ ","
					+ this.stx + "," + this.cstx + "," + 1 + ")";
			list.add(insertQuery);

			tileID = tileMap.get(Constant.TABLE_6_2_I_A);
			insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.diff_val
					+ ","
					+ this.i_itc
					+ ","
					+ this.c_itc
					+ ","
					+ this.s_itc + "," + this.cs_itc + "," + 1 + ")";
			list.add(insertQuery);
		} else if (this.ty.equalsIgnoreCase("S")) {
			int tileID = tileMap.get(Constant.TABLE_6_2_T_B);
			String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.diff_val
					+ ","
					+ this.itx
					+ ","
					+ this.ctx
					+ ","
					+ this.stx + "," + this.cstx + "," + 1 + ")";
			list.add(insertQuery);

			tileID = tileMap.get(Constant.TABLE_6_2_I_B);
			insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.diff_val
					+ ","
					+ this.i_itc
					+ ","
					+ this.c_itc
					+ ","
					+ this.s_itc + "," + this.cs_itc + "," + 1 + ")";
			list.add(insertQuery);
		} else if (this.ty.equalsIgnoreCase("CG")) {
			int tileID = tileMap.get(Constant.TABLE_6_2_T_C);
			String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.diff_val
					+ ","
					+ this.itx
					+ ","
					+ this.ctx
					+ ","
					+ this.stx + "," + this.cstx + "," + 1 + ")";
			list.add(insertQuery);

			tileID = tileMap.get(Constant.TABLE_6_2_I_C);
			insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
					+ masterID
					+ ","
					+ tileID
					+ ","
					+ null
					+ ","
					+ null
					+ ","
					+ this.diff_val
					+ ","
					+ this.i_itc
					+ ","
					+ this.c_itc
					+ ","
					+ this.s_itc + "," + this.cs_itc + "," + 1 + ")";
			list.add(insertQuery);
		}

		return list;

	}

	@Override
	public String toString() {
		return "ItcDetAmm [ty=" + ty + ", diff_val=" + diff_val + ", i_itc="
				+ i_itc + ", c_itc=" + c_itc + ", s_itc=" + s_itc + ", cs_itc="
				+ cs_itc + ", itx=" + itx + ", ctx=" + ctx + ", stx=" + stx
				+ ", cstx=" + cstx + "]";
	}	
}

// 6. Input Tax Credit
class ItcCr {
	private ArrayList<ItcDet> itc_det;
private double ttl_itc;
private double itc_rc_net_itc_Iamt;
private double itc_rc_net_itc_Camt;
private double itc_rc_net_itc_Samt;
private double itc_rc_net_itc_Cess; 
//private Map<String, S>
public double getItc_rc_net_itc_cess() {
	return itc_rc_net_itc_cess;
}

public double getItc_rc_net_itc_Iamt() {
	return itc_rc_net_itc_Iamt;
}

public void setItc_rc_net_itc_Iamt(double itc_rc_net_itc_Iamt) {
	this.itc_rc_net_itc_Iamt = itc_rc_net_itc_Iamt;
}

public double getItc_rc_net_itc_Camt() {
	return itc_rc_net_itc_Camt;
}

public void setItc_rc_net_itc_Camt(double itc_rc_net_itc_Camt) {
	this.itc_rc_net_itc_Camt = itc_rc_net_itc_Camt;
}

public double getItc_rc_net_itc_Samt() {
	return itc_rc_net_itc_Samt;
}

public void setItc_rc_net_itc_Samt(double itc_rc_net_itc_Samt) {
	this.itc_rc_net_itc_Samt = itc_rc_net_itc_Samt;
}

public double getItc_rc_net_itc_Cess() {
	return itc_rc_net_itc_Cess;
}

public void setItc_rc_net_itc_Cess(double itc_rc_net_itc_Cess) {
	this.itc_rc_net_itc_Cess = itc_rc_net_itc_Cess;
}

public void setItc_rc_net_itc_cess(double itc_rc_net_itc_cess) {
	this.itc_rc_net_itc_cess = itc_rc_net_itc_cess;
}

private double  itc_rc_net_itc_cess;
	public ArrayList<ItcDet> getItcDet() {
		return this.itc_det;
	}

	public ArrayList<ItcDet> getItc_det() {
		return itc_det;
	}

	public void setItc_det(ArrayList<ItcDet> itc_det) {
		this.itc_det = itc_det;
	}

	public double getTtl_itc() {
		return ttl_itc;
	}

	public void setTtl_itc(double ttl_itc) {
		this.ttl_itc = ttl_itc;
	}

	public ArrayList<ItcDetAmm> getItc_det_amm() {
		return itc_det_amm;
	}

	public void setItc_det_amm(ArrayList<ItcDetAmm> itc_det_amm) {
		this.itc_det_amm = itc_det_amm;
	}

	public void setItcDet(ArrayList<ItcDet> itc_det) {
		this.itc_det = itc_det;
	}

	private ArrayList<ItcDetAmm> itc_det_amm;

	public ArrayList<ItcDetAmm> getItcDetAmm() {
		return this.itc_det_amm;
	}

	public void setItcDetAmm(ArrayList<ItcDetAmm> itc_det_amm) {
		this.itc_det_amm = itc_det_amm;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		
		this.itc_det = new ArrayList<ItcDet>();
        this.itc_det_amm = new ArrayList<ItcDetAmm>();
        List<Map<String, Object>> listT6 = mapGroupByTableType
                    .get(Constant.TABLE_TYPE_6);
        ItcDet itcDetCG = new ItcDet();
        ItcDet itcDetGI = new ItcDet();
        ItcDet itcDetS = new ItcDet();
        itcDetGI.setTy("GI");
        itcDetS.setTy("S");
        itcDetCG.setTy("CG");

        ItcDetAmm itcDetAmmCG = new ItcDetAmm();
        ItcDetAmm itcDetAmmGI = new ItcDetAmm();
        ItcDetAmm itcDetAmmS = new ItcDetAmm();
        itcDetAmmCG.setTy("CG");
        itcDetAmmGI.setTy("GI");
        itcDetAmmS.setTy("S");
        for (Map<String, Object> map : listT6) {
              // Group and sub group naming convention is incorrect in DB

              if (map.get(Constant.GROUP).equals(Constant.TABLE_6_1_I)
                          || map.get(Constant.GROUP).equals(Constant.TABLE_6_1_T)) {

                    if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_1_I_A)
                                || map.get(Constant.SUBGROUP).equals(
                                            Constant.TABLE_6_1_T_A)) {

                          itcDetGI.populateRootDTO(map);
                    } else if (map.get(Constant.SUBGROUP).equals(
                                Constant.TABLE_6_1_I_B)
                                || map.get(Constant.SUBGROUP).equals(
                                            Constant.TABLE_6_1_T_B)) {
                          itcDetS.populateRootDTO(map);

                    } else if (map.get(Constant.SUBGROUP).equals(
                                Constant.TABLE_6_1_I_C)
                                || map.get(Constant.SUBGROUP).equals(
                                            Constant.TABLE_6_1_T_C)) {
                          itcDetCG.populateRootDTO(map);

                    }

              }
              // For Amendments
              if (map.get(Constant.GROUP).equals(Constant.TABLE_6_2_I)
                          || map.get(Constant.GROUP).equals(Constant.TABLE_6_2_T)) {

                    if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_I_A)
                                || map.get(Constant.SUBGROUP).equals(
                                            Constant.TABLE_6_2_T_A)) {
                          itcDetAmmGI.setTy("GI");
                          itcDetAmmGI.populateRootDTO(map);
                    }
                    if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_I_B)
                                || map.get(Constant.SUBGROUP).equals(
                                            Constant.TABLE_6_2_T_B)) {
                          itcDetAmmS.setTy("S");
                          itcDetAmmS.populateRootDTO(map);
                    }
                    if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_6_2_I_C)
                                || map.get(Constant.SUBGROUP).equals(
                                            Constant.TABLE_6_2_T_C)) {
                          itcDetAmmCG.populateRootDTO(map);
                          itcDetAmmCG.setTy("CG");
                    }
              }
        }
        this.itc_det.add(itcDetGI);
        this.itc_det.add(itcDetS);
        this.itc_det.add(itcDetCG);
        this.itc_det_amm.add(itcDetAmmS);
        this.itc_det_amm.add(itcDetAmmGI);
        this.itc_det_amm.add(itcDetAmmCG);


	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();
		
		if(this.itc_det != null)
		for (ItcDet itsDet : this.itc_det) {
			list.addAll(itsDet.fetchInsertScripts(masterID, tileMap));
		}

		if(this.itc_det_amm != null)
		for (ItcDetAmm itcAmed : this.itc_det_amm) {
			list.addAll(itcAmed.fetchInsertScripts(masterID, tileMap));
		}
		return list;

	}

	@Override
	public String toString() {
		return "ItcCr [itc_det=" + itc_det + ", ttl_itc=" + ttl_itc
				+ ", itc_rc_net_itc_Iamt=" + itc_rc_net_itc_Iamt
				+ ", itc_rc_net_itc_Camt=" + itc_rc_net_itc_Camt
				+ ", itc_rc_net_itc_Samt=" + itc_rc_net_itc_Samt
				+ ", itc_rc_net_itc_Cess=" + itc_rc_net_itc_Cess
				+ ", itc_rc_net_itc_cess=" + itc_rc_net_itc_cess
				+ ", itc_det_amm=" + itc_det_amm + "]";
}
}

// 7.a Mismatch ITC Claimed
class ItcClm {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT7 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_7);
		for (Map<String, Object> map : listT7) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_7_A)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_7_A);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "ItcClm [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}	
}

// 7.b Mismatch Tax Liability
class TaxLiab {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT7 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_7);
		for (Map<String, Object> map : listT7) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_7_B)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_7_B);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "TaxLiab [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}	
}

// 7.c Mismatch Reclaim Invoice/Debit Notes
class RclmIdn {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT7 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_7);
		for (Map<String, Object> map : listT7) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_7_C)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_7_C);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "RclmIdn [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}	
}

// 7.d Mismatch Reclaim Credit Note
class RclmCn {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT7 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_7);
		for (Map<String, Object> map : listT7) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_7_D)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_7_D);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "RclmCn [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}
}

// 7.e Mismatch Negative Tax Liability
class NegTaxLiab {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT7 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_7);
		for (Map<String, Object> map : listT7) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_7_E)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_7_E);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "NegTaxLiab [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
}
}

// 7.f Mismatch Advance tax
class AdvTx {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT7 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_7);
		for (Map<String, Object> map : listT7) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_7_F)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					if(map.get(Constant.IGST_AMOUNT) != null)
						this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
								.toString());
						if(map.get(Constant.CGST_AMOUNT) != null)
						this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
								.toString());
						if(map.get(Constant.SGST_AMOUNT) != null)
						this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
								.toString());
						if(map.get(Constant.CESS_AMOUNT) != null)
						this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
								.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_7_F);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "AdvTx [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}	
}

// 7.g Mismatch ITC Reversal
class ItcRvl {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT7 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_7);
		for (Map<String, Object> map : listT7) {
			if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_7_G_A)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_7_G_A);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "ItcRvl [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
}
}

class ItcRclm {

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT7 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_7);
		for (Map<String, Object> map : listT7) {
			if (map.get(Constant.SUBGROUP).equals(Constant.TABLE_7_G_B)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_7_G_B);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "ItcRvl [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
}

}

class ItcRvlRclm{
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
}
}

// 7 Mismatch and other reasons
class Mis {
	private ItcClm itc_clm;

	 private double netITax;
	 private double netCTax;
	 private double netSTax;
	 private double netCess;

	public double getNetCTax() {
		return netCTax;
	}

	public void setNetCTax(double netCTax) {
		this.netCTax = netCTax;
	}

	public double getNetSTax() {
		return netSTax;
	}

	public void setNetSTax(double netSTax) {
		this.netSTax = netSTax;
	}

	public double getNetCess() {
		return netCess;
	}

	public void setNetCess(double netCess) {
		this.netCess = netCess;
	}

	public double getNetITax() {
		return netITax;
	}

	public void setNetITax(double netITax) {
		this.netITax = netITax;
	}

	public ItcClm getItc_clm() {
		return itc_clm;
	}

	public void setItc_clm(ItcClm itc_clm) {
		this.itc_clm = itc_clm;
	}

	public TaxLiab getTax_liab() {
		return tax_liab;
	}

	public void setTax_liab(TaxLiab tax_liab) {
		this.tax_liab = tax_liab;
	}

	public RclmIdn getRclm_idn() {
		return rclm_idn;
	}

	public void setRclm_idn(RclmIdn rclm_idn) {
		this.rclm_idn = rclm_idn;
	}

	public RclmCn getRclm_cn() {
		return rclm_cn;
	}

	public void setRclm_cn(RclmCn rclm_cn) {
		this.rclm_cn = rclm_cn;
	}

	public NegTaxLiab getNeg_tax_liab() {
		return neg_tax_liab;
	}

	public void setNeg_tax_liab(NegTaxLiab neg_tax_liab) {
		this.neg_tax_liab = neg_tax_liab;
	}

	public AdvTx getAdv_tx() {
		return adv_tx;
	}

	public void setAdv_tx(AdvTx adv_tx) {
		this.adv_tx = adv_tx;
	}

	public ItcRvl getItc_rvl() {
		return itc_rvl;
	}

	public void setItc_rvl(ItcRvl itc_rvl) {
		this.itc_rvl = itc_rvl;
	}

	private TaxLiab tax_liab;

	public TaxLiab getTaxLiab() {
		return this.tax_liab;
	}

	public void setTaxLiab(TaxLiab tax_liab) {
		this.tax_liab = tax_liab;
	}

	private RclmIdn rclm_idn;

	public RclmIdn getRclmIdn() {
		return this.rclm_idn;
	}

	public void setRclmIdn(RclmIdn rclm_idn) {
		this.rclm_idn = rclm_idn;
	}

	private RclmCn rclm_cn;

	public RclmCn getRclmCn() {
		return this.rclm_cn;
	}

	public void setRclmCn(RclmCn rclm_cn) {
		this.rclm_cn = rclm_cn;
	}

	private NegTaxLiab neg_tax_liab;

	public NegTaxLiab getNegTaxLiab() {
		return this.neg_tax_liab;
	}

	public void setNegTaxLiab(NegTaxLiab neg_tax_liab) {
		this.neg_tax_liab = neg_tax_liab;
	}

	private AdvTx adv_tx;

	public AdvTx getAdvTx() {
		return this.adv_tx;
	}

	public void setAdvTx(AdvTx adv_tx) {
		this.adv_tx = adv_tx;
	}

	private ItcRvl itc_rvl;

	public ItcRvl getItcRvl() {
		return this.itc_rvl;
	}

	public void setItcRvl(ItcRvl itc_rvl) {
		this.itc_rvl = itc_rvl;
	}

	private ItcRclm itc_rclm;
	
	public ItcRclm getItcRclm() {
		return this.itc_rclm;
	}

	public void setItcRclm(ItcRclm itcrclm) {
		this.itc_rclm = itcrclm;
	}
	
	private ItcRvlRclm itc_rvl_rclm;

	public ItcRvlRclm getItcRvlRclm() {
		return itc_rvl_rclm;
	}

	public void setItcRvlRclm(ItcRvlRclm itc_rvl_rclm) {
		this.itc_rvl_rclm = itc_rvl_rclm;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		
		this.itc_clm = new ItcClm();
		this.itc_clm.populateRootDTO(mapGroupByTableType);
		
		this.tax_liab =new TaxLiab();
		this.tax_liab.populateRootDTO(mapGroupByTableType);
		
		this.rclm_idn=new RclmIdn();
		this.rclm_idn.populateRootDTO(mapGroupByTableType);
		
		this.rclm_cn=new RclmCn();
		this.rclm_cn.populateRootDTO(mapGroupByTableType);
		
		this.neg_tax_liab=new NegTaxLiab();
		this.neg_tax_liab.populateRootDTO(mapGroupByTableType);
		
		this.adv_tx=new AdvTx();
		this.adv_tx.populateRootDTO(mapGroupByTableType);
		
		this.itc_rvl=new ItcRvl();
		this.itc_rvl.populateRootDTO(mapGroupByTableType);
		
		this.itc_rclm=new ItcRclm();
		this.itc_rclm.populateRootDTO(mapGroupByTableType);
		
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if(this.itc_clm != null)
		list.addAll(this.itc_clm.fetchInsertScripts(masterID, tileMap));
		
		if(this.tax_liab != null)
		list.addAll(this.tax_liab.fetchInsertScripts(masterID, tileMap));
		
		if(this.rclm_idn != null)
		list.addAll(this.rclm_idn.fetchInsertScripts(masterID, tileMap));
		
		if(this.rclm_cn != null)
		list.addAll(this.rclm_cn.fetchInsertScripts(masterID, tileMap));
		
		if(this.neg_tax_liab != null)
		list.addAll(this.neg_tax_liab.fetchInsertScripts(masterID, tileMap));
		
		if(this.adv_tx != null)
		list.addAll(this.adv_tx.fetchInsertScripts(masterID, tileMap));
		
		if(this.itc_rvl != null)
		list.addAll(this.itc_rvl.fetchInsertScripts(masterID, tileMap));

		if(this.itc_rclm != null)
			list.addAll(this.itc_rclm.fetchInsertScripts(masterID, tileMap));

		return list;
	}

	@Override
	public String toString() {
		return "Mis [itc_clm=" + itc_clm + ", netITax=" + netITax
				+ ", netCTax=" + netCTax + ", netSTax=" + netSTax
				+ ", netCess=" + netCess + ", tax_liab=" + tax_liab
				+ ", rclm_idn=" + rclm_idn + ", rclm_cn=" + rclm_cn
				+ ", neg_tax_liab=" + neg_tax_liab + ", adv_tx=" + adv_tx
				+ ", itc_rvl=" + itc_rvl + "]";
}
}

// T.8.B Total Tax Liability Inward Supply
class TtlDtl {
	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double csamt;

	public double getCsamt() {
		return this.csamt;
	}

	public void setCsamt(double csamt) {
		this.csamt = csamt;
	}

	private double intr_rt;

	public double getIntrRt() {
		return this.intr_rt;
	}

	public void setIntrRt(double intr_rt) {
		this.intr_rt = intr_rt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.intr_rt = Double.valueOf(map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.csamt = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());}
	
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_8_B);

		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.intr_rt
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt + "," + this.csamt + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	} 

	@Override
	public String toString() {
		return "TtlDtl [samt=" + samt + ", csamt=" + csamt + ", intr_rt="
				+ intr_rt + ", txval=" + txval + ", camt=" + camt + ", iamt="
				+ iamt + "]";
}
}

// T.8.B Total Tax Liability Inward Supply
class TtlIn {
	private ArrayList<TtlDtl> ttl_dtl;
private double ttl_In_ITtl;
private double ttl_In_CTtl;
private double ttl_In_STtl;
private double ttl_In_CessTtl;
	public ArrayList<TtlDtl> getTtl_dtl() {
	return ttl_dtl;
}

public void setTtl_dtl(ArrayList<TtlDtl> ttl_dtl) {
	this.ttl_dtl = ttl_dtl;
}

public double getTtl_In_ITtl() {
	return ttl_In_ITtl;
}

public void setTtl_In_ITtl(double ttl_In_ITtl) {
	this.ttl_In_ITtl = ttl_In_ITtl;
}

public double getTtl_In_CTtl() {
	return ttl_In_CTtl;
}

public void setTtl_In_CTtl(double ttl_In_CTtl) {
	this.ttl_In_CTtl = ttl_In_CTtl;
}

public double getTtl_In_STtl() {
	return ttl_In_STtl;
}

public void setTtl_In_STtl(double ttl_In_STtl) {
	this.ttl_In_STtl = ttl_In_STtl;
}

 

	public double getTtl_In_CessTtl() {
	return ttl_In_CessTtl;
}

public void setTtl_In_CessTtl(double ttl_In_CessTtl) {
	this.ttl_In_CessTtl = ttl_In_CessTtl;
}

	public ArrayList<TtlDtl> getTtlDtl() {
		return this.ttl_dtl;
	}

	public void setTtlDtl(ArrayList<TtlDtl> ttl_dtl) {
		this.ttl_dtl = ttl_dtl;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.ttl_dtl = new ArrayList<TtlDtl>();
		List<Map<String, Object>> listT8 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_8);
		for (Map<String, Object> map : listT8) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_8_B)) {
				TtlDtl ttlDtl = new TtlDtl();
				ttlDtl.populateRootDTO(map);
				
				this.ttl_dtl.add(ttlDtl);
			}
		}
	}
	
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if (ttl_dtl != null) {
			for (TtlDtl ttldtl : ttl_dtl) {
				list.addAll(ttldtl.fetchInsertScripts(masterID, tileMap));
			}
		}
		return list;
	}

	@Override
	public String toString() {
		return "TtlIn [ttl_dtl=" + ttl_dtl + ", ttl_In_ITtl=" + ttl_In_ITtl
				+ ", ttl_In_CTtl=" + ttl_In_CTtl + ", ttl_In_STtl="
				+ ttl_In_STtl + ", ttl_In_CessTtl=" + ttl_In_CessTtl + "]";
	}	
}

// T.8.A Total Tax Liability Outwrad Supply
class TtlDtl2 {
	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double csamt;

	public double getCsamt() {
		return this.csamt;
	}

	public void setCsamt(double csamt) {
		this.csamt = csamt;
	}

	private double intr_rt;

	public double getIntr_rt() {
		return intr_rt;
	}

	public void setIntr_rt(double intr_rt) {
		this.intr_rt = intr_rt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.intr_rt = Double.valueOf(map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE).toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.csamt = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());	}
	
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_8_A);

		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.intr_rt
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt + "," + this.csamt + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	} 

	@Override
	public String toString() {
		return "TtlDtl2 [samt=" + samt + ", csamt=" + csamt + ", intr_rt="
				+ intr_rt + ", txval=" + txval + ", camt=" + camt + ", iamt="
				+ iamt + "]";
	}	
}

// T.8.A Total Tax Liability Outwrad Supply
class TtlOut {
	private ArrayList<TtlDtl2> ttl_dtl;
	private double ttl_In_ITtl;
	private double ttl_In_CTtl;
	private double ttl_In_STtl;
	private double ttl_In_CessTtl;
	public ArrayList<TtlDtl2> getTtl_dtl() {
		return ttl_dtl;
	}

	public void setTtl_dtl(ArrayList<TtlDtl2> ttl_dtl) {
		this.ttl_dtl = ttl_dtl;
	}

	public double getTtl_In_ITtl() {
		return ttl_In_ITtl;
	}

	public void setTtl_In_ITtl(double ttl_In_ITtl) {
		this.ttl_In_ITtl = ttl_In_ITtl;
	}

	public double getTtl_In_CTtl() {
		return ttl_In_CTtl;
	}

	public void setTtl_In_CTtl(double ttl_In_CTtl) {
		this.ttl_In_CTtl = ttl_In_CTtl;
	}

	public double getTtl_In_STtl() {
		return ttl_In_STtl;
	}

	public void setTtl_In_STtl(double ttl_In_STtl) {
		this.ttl_In_STtl = ttl_In_STtl;
	}

	public double getTtl_In_CessTtl() {
		return ttl_In_CessTtl;
	}

	public void setTtl_In_CessTtl(double ttl_In_CessTtl) {
		this.ttl_In_CessTtl = ttl_In_CessTtl;
	}

	public ArrayList<TtlDtl2> getTtlDtl() {
		return this.ttl_dtl;
	}

	public void setTtlDtl(ArrayList<TtlDtl2> ttl_dtl) {
		this.ttl_dtl = ttl_dtl;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.ttl_dtl = new ArrayList<TtlDtl2>();
		List<Map<String, Object>> listT8 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_8);
		for (Map<String, Object> map : listT8) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_8_A)) {
				TtlDtl2 ttlDtl2 = new TtlDtl2();
				ttlDtl2.populateRootDTO(map);				
				this.ttl_dtl.add(ttlDtl2);
			}
		}
	}
		public List<String> fetchInsertScripts(int masterID,
				Map<String, Integer> tileMap) {

			List<String> list = new ArrayList<String>();

			if (ttl_dtl != null) {
				for (TtlDtl2 ttlst2 : ttl_dtl) {
					list.addAll(ttlst2.fetchInsertScripts(masterID, tileMap));
				}
			}
			return list;
		} 
	
	@Override
	public String toString() {
		return "TtlOut [ttl_dtl=" + ttl_dtl + ", ttl_In_ITtl=" + ttl_In_ITtl
				+ ", ttl_In_CTtl=" + ttl_In_CTtl + ", ttl_In_STtl="
				+ ttl_In_STtl + ", ttl_In_CessTtl=" + ttl_In_CessTtl + "]";
}
}

// T.8.B Total Tax Liability Tax Credit Reversal
class TtlDtl3 {
	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double csamt;

	public double getCsamt() {
		return this.csamt;
	}

	public void setCsamt(double csamt) {
		this.csamt = csamt;
	}

	private double intr_rt;

	public double getIntrRt() {
		return this.intr_rt;
	}

	public void setIntrRt(double intr_rt) {
		this.intr_rt = intr_rt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.intr_rt = Double.valueOf(map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE)
					.toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double
					.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.camt = Double
					.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.samt = Double
					.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.csamt = Double.valueOf(map.get(Constant.CESS_AMOUNT)
					.toString());
	}
	
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_8_C);

		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.intr_rt
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt + "," + this.csamt + "," + 1 + ")";
		list.add(insertQuery);

		return list;

} 

	@Override
	public String toString() {
		return "TtlDtl3 [samt=" + samt + ", csamt=" + csamt + ", intr_rt="
				+ intr_rt + ", txval=" + txval + ", camt=" + camt + ", iamt="
				+ iamt + "]";
}
}

// T.8.C Total Tax Liability Credit reversal
class TtlItcrv {
	private ArrayList<TtlDtl3> ttl_dtl;
	private double ttl_In_ITtl;
	private double ttl_In_CTtl;
	private double ttl_In_STtl;
	private double ttl_In_CessTtl;
	public ArrayList<TtlDtl3> getTtl_dtl() {
		return ttl_dtl;
	}

	public void setTtl_dtl(ArrayList<TtlDtl3> ttl_dtl) {
		this.ttl_dtl = ttl_dtl;
	}

	public double getTtl_In_ITtl() {
		return ttl_In_ITtl;
	}

	public void setTtl_In_ITtl(double ttl_In_ITtl) {
		this.ttl_In_ITtl = ttl_In_ITtl;
	}

	public double getTtl_In_CTtl() {
		return ttl_In_CTtl;
	}

	public void setTtl_In_CTtl(double ttl_In_CTtl) {
		this.ttl_In_CTtl = ttl_In_CTtl;
	}

	public double getTtl_In_STtl() {
		return ttl_In_STtl;
	}

	public void setTtl_In_STtl(double ttl_In_STtl) {
		this.ttl_In_STtl = ttl_In_STtl;
	}

	public double getTtl_In_CessTtl() {
		return ttl_In_CessTtl;
	}

	public void setTtl_In_CessTtl(double ttl_In_CessTtl) {
		this.ttl_In_CessTtl = ttl_In_CessTtl;
	}

	public ArrayList<TtlDtl3> getTtlDtl() {
		return this.ttl_dtl;
	}

	public void setTtlDtl(ArrayList<TtlDtl3> ttl_dtl) {
		this.ttl_dtl = ttl_dtl;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		
		this.ttl_dtl = new ArrayList<TtlDtl3>();
		List<Map<String, Object>> listT8 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_8);
		for (Map<String, Object> map : listT8) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_8_C)) {
				TtlDtl3 ttlDtl3 = new TtlDtl3();
				ttlDtl3.populateRootDTO(map);
				
				this.ttl_dtl.add(ttlDtl3);
			}
		}
	}
	
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if (ttl_dtl != null) {
			for (TtlDtl3 ttldt : ttl_dtl) {
				list.addAll(ttldt.fetchInsertScripts(masterID, tileMap));
			}
		}
		return list;
	} 

	@Override
	public String toString() {
		return "TtlItcrv [ttl_dtl=" + ttl_dtl + ", ttl_In_ITtl=" + ttl_In_ITtl
				+ ", ttl_In_CTtl=" + ttl_In_CTtl + ", ttl_In_STtl="
				+ ttl_In_STtl + ", ttl_In_CessTtl=" + ttl_In_CessTtl + "]";
	}	
}

// T.8.D Total Tax Liability Mismatch
class TtlDtl4 {
	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double csamt;

	public double getCsamt() {
		return this.csamt;
	}

	public void setCsamt(double csamt) {
		this.csamt = csamt;
	}

	private double intr_rt;

	public double getIntrRt() {
		return this.intr_rt;
	}

	public void setIntrRt(double intr_rt) {
		this.intr_rt = intr_rt;
	}

	private double txval;

	public double getTxval() {
		return this.txval;
	}

	public void setTxval(double txval) {
		this.txval = txval;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.RATE) != null)
			this.intr_rt = Double.valueOf(map.get(Constant.RATE).toString());
			if(map.get(Constant.TAXABLEVALUE) != null)
			this.txval = Double.valueOf(map.get(Constant.TAXABLEVALUE)
					.toString());
			if(map.get(Constant.IGST_AMOUNT) != null)
			this.iamt = Double
					.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.camt = Double
					.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.samt = Double
					.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.csamt = Double.valueOf(map.get(Constant.CESS_AMOUNT)
					.toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_8_D);

		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ this.intr_rt
				+ ","
				+ null
				+ ","
				+ this.txval
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt + "," + this.csamt + "," + 1 + ")";
		list.add(insertQuery);

		return list;

} 

	@Override
	public String toString() {
		return "TtlDtl4 [samt=" + samt + ", csamt=" + csamt + ", intr_rt="
				+ intr_rt + ", txval=" + txval + ", camt=" + camt + ", iamt="
				+ iamt + "]";
}
}

// T.8.D Total Tax Liability Mismatch
class TtlOth {
	private ArrayList<TtlDtl4> ttl_dtl;
	private double ttl_In_ITtl;
	private double ttl_In_CTtl;
	private double ttl_In_STtl;
	private double ttl_In_CessTtl;
	public ArrayList<TtlDtl4> getTtl_dtl() {
		return ttl_dtl;
	}

	public void setTtl_dtl(ArrayList<TtlDtl4> ttl_dtl) {
		this.ttl_dtl = ttl_dtl;
	}

	public double getTtl_In_ITtl() {
		return ttl_In_ITtl;
	}

	public void setTtl_In_ITtl(double ttl_In_ITtl) {
		this.ttl_In_ITtl = ttl_In_ITtl;
	}

	public double getTtl_In_CTtl() {
		return ttl_In_CTtl;
	}

	public void setTtl_In_CTtl(double ttl_In_CTtl) {
		this.ttl_In_CTtl = ttl_In_CTtl;
	}

	public double getTtl_In_STtl() {
		return ttl_In_STtl;
	}

	public void setTtl_In_STtl(double ttl_In_STtl) {
		this.ttl_In_STtl = ttl_In_STtl;
	}

	public double getTtl_In_CessTtl() {
		return ttl_In_CessTtl;
	}

	public void setTtl_In_CessTtl(double ttl_In_CessTtl) {
		this.ttl_In_CessTtl = ttl_In_CessTtl;
	}

	public ArrayList<TtlDtl4> getTtlDtl() {
		return this.ttl_dtl;
	}

	public void setTtlDtl(ArrayList<TtlDtl4> ttl_dtl) {
		this.ttl_dtl = ttl_dtl;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {		
		this.ttl_dtl = new ArrayList<TtlDtl4>();
		List<Map<String, Object>> listT8 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_8);
		for (Map<String, Object> map : listT8) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_8_D)) {
				TtlDtl4 ttlDtl4 = new TtlDtl4();
				ttlDtl4.populateRootDTO(map);
				
				this.ttl_dtl.add(ttlDtl4);
			}
		}
	}
	
	public List<String> fetchInsertScripts(int masterID,
					Map<String, Integer> tileMap) {

				List<String> list = new ArrayList<String>();

				if (ttl_dtl != null) {
					for (TtlDtl4 ttlst2 : ttl_dtl) {
						list.addAll(ttlst2.fetchInsertScripts(masterID, tileMap));
					}
				}
				return list;
	} 

	@Override
	public String toString() {
		return "TtlOth [ttl_dtl=" + ttl_dtl + ", ttl_In_ITtl=" + ttl_In_ITtl
				+ ", ttl_In_CTtl=" + ttl_In_CTtl + ", ttl_In_STtl="
				+ ttl_In_STtl + ", ttl_In_CessTtl=" + ttl_In_CessTtl + "]";
}
}

// 8. Total tax liability
class Ttxl {
	private TtlIn ttl_in;
private double ttl_in_I_Cmbd;
private double ttl_in_C_Cmbd;
private double ttl_in_S_Cmbd;
private double ttl_in_CessS_Cmbd;
private double ttl_pybl;
private double ttl_csh_paid;

private double taxIntTtlCombinedUtil = 0.00;
private double taxStateTtlCombinedUtil = 0.00;
private double taxCentTtlCombinedUtil = 0.00;
private double taxCessTtlCombinedUtil = 0.00;


public double getTaxIntTtlCombinedUtil() {
	return taxIntTtlCombinedUtil;
}

public void setTaxIntTtlCombinedUtil(double taxIntTtlCombinedUtil) {
	this.taxIntTtlCombinedUtil = taxIntTtlCombinedUtil;
}

public double getTaxStateTtlCombinedUtil() {
	return taxStateTtlCombinedUtil;
}

public void setTaxStateTtlCombinedUtil(double taxStateTtlCombinedUtil) {
	this.taxStateTtlCombinedUtil = taxStateTtlCombinedUtil;
}

public double getTaxCentTtlCombinedUtil() {
	return taxCentTtlCombinedUtil;
}

public void setTaxCentTtlCombinedUtil(double taxCentTtlCombinedUtil) {
	this.taxCentTtlCombinedUtil = taxCentTtlCombinedUtil;
}

public double getTaxCessTtlCombinedUtil() {
	return taxCessTtlCombinedUtil;
}

public void setTaxCessTtlCombinedUtil(double taxCessTtlCombinedUtil) {
	this.taxCessTtlCombinedUtil = taxCessTtlCombinedUtil;
}


private double ttl_itc_avlbl;
public double getTtl_in_Cess_Cmbd() {
	return ttl_in_Cess_Cmbd;
}

public void setTtl_in_Cess_Cmbd(double ttl_in_Cess_Cmbd) {
	this.ttl_in_Cess_Cmbd = ttl_in_Cess_Cmbd;
}

private double ttl_in_Cess_Cmbd;

	public double getTtl_itc_avlbl() {
	return ttl_itc_avlbl;
}

public void setTtl_itc_avlbl(double ttl_itc_avlbl) {
	this.ttl_itc_avlbl = ttl_itc_avlbl;
}

	public double getTtl_csh_paid() {
	return ttl_csh_paid;
}

public void setTtl_csh_paid(double ttl_csh_paid) {
	this.ttl_csh_paid = ttl_csh_paid;
}

	public double getTtl_in_CessS_Cmbd() {
	return ttl_in_CessS_Cmbd;
}

public void setTtl_in_CessS_Cmbd(double ttl_in_CessS_Cmbd) {
	this.ttl_in_CessS_Cmbd = ttl_in_CessS_Cmbd;
}

public double getTtl_pybl() {
	return ttl_pybl;
}

public void setTtl_pybl(double ttl_pybl) {
	this.ttl_pybl = ttl_pybl;
}

	public TtlIn getTtl_in() {
	return ttl_in;
}

public void setTtl_in(TtlIn ttl_in) {
	this.ttl_in = ttl_in;
}

public double getTtl_in_I_Cmbd() {
	return ttl_in_I_Cmbd;
}

public void setTtl_in_I_Cmbd(double ttl_in_I_Cmbd) {
	this.ttl_in_I_Cmbd = ttl_in_I_Cmbd;
}

public double getTtl_in_C_Cmbd() {
	return ttl_in_C_Cmbd;
}

public void setTtl_in_C_Cmbd(double ttl_in_C_Cmbd) {
	this.ttl_in_C_Cmbd = ttl_in_C_Cmbd;
}

public double getTtl_in_S_Cmbd() {
	return ttl_in_S_Cmbd;
}

public void setTtl_in_S_Cmbd(double ttl_in_S_Cmbd) {
	this.ttl_in_S_Cmbd = ttl_in_S_Cmbd;
}
 
public TtlOut getTtl_out() {
	return ttl_out;
}

public void setTtl_out(TtlOut ttl_out) {
	this.ttl_out = ttl_out;
}

public TtlItcrv getTtl_itcrv() {
	return ttl_itcrv;
}

public void setTtl_itcrv(TtlItcrv ttl_itcrv) {
	this.ttl_itcrv = ttl_itcrv;
}

public TtlOth getTtl_oth() {
	return ttl_oth;
}

public void setTtl_oth(TtlOth ttl_oth) {
	this.ttl_oth = ttl_oth;
}

	public TtlIn getTtlIn() {
		return this.ttl_in;
	}

	public void setTtlIn(TtlIn ttl_in) {
		this.ttl_in = ttl_in;
	}

	private TtlOut ttl_out;

	public TtlOut getTtlOut() {
		return this.ttl_out;
	}

	public void setTtlOut(TtlOut ttl_out) {
		this.ttl_out = ttl_out;
	}

	private TtlItcrv ttl_itcrv;

	public TtlItcrv getTtlItcrv() {
		return this.ttl_itcrv;
	}

	public void setTtlItcrv(TtlItcrv ttl_itcrv) {
		this.ttl_itcrv = ttl_itcrv;
	}

	private TtlOth ttl_oth;

	public TtlOth getTtlOth() {
		return this.ttl_oth;
	}

	public void setTtlOth(TtlOth ttl_oth) {
		this.ttl_oth = ttl_oth;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		
		this.ttl_out = new TtlOut();
		this.ttl_in = new TtlIn();
		this.ttl_itcrv = new TtlItcrv();
		this.ttl_oth = new TtlOth();
		
		this.ttl_out.populateRootDTO(mapGroupByTableType);
		this.ttl_in.populateRootDTO(mapGroupByTableType);
		this.ttl_itcrv.populateRootDTO(mapGroupByTableType);
		this.ttl_oth.populateRootDTO(mapGroupByTableType);
	}
	
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if (this.ttl_out != null)
			list.addAll(this.ttl_out.fetchInsertScripts(masterID, tileMap));

		if (this.ttl_in != null)
			list.addAll(this.ttl_in.fetchInsertScripts(masterID, tileMap));

		if (this.ttl_itcrv != null)
			list.addAll(this.ttl_itcrv.fetchInsertScripts(masterID, tileMap));

		if (this.ttl_oth != null)
			list.addAll(this.ttl_oth.fetchInsertScripts(masterID, tileMap));

		return list;
	} 

	@Override
	public String toString() {
		return "Ttxl [ttl_in=" + ttl_in + ", ttl_in_I_Cmbd=" + ttl_in_I_Cmbd
				+ ", ttl_in_C_Cmbd=" + ttl_in_C_Cmbd + ", ttl_in_S_Cmbd="
				+ ttl_in_S_Cmbd + ", ttl_in_CessS_Cmbd=" + ttl_in_CessS_Cmbd
				+ ", ttl_pybl=" + ttl_pybl + ", ttl_csh_paid=" + ttl_csh_paid
				+ ", ttl_itc_avlbl=" + ttl_itc_avlbl + ", ttl_in_Cess_Cmbd="
				+ ttl_in_Cess_Cmbd + ", ttl_out=" + ttl_out + ", ttl_itcrv="
				+ ttl_itcrv + ", ttl_oth=" + ttl_oth + "]";
}
}

// 9. TCS Credit
class TcsDet {
	private double itx;

	public double getItx() {
		return this.itx;
	}

	public void setItx(double itx) {
		this.itx = itx;
	}

	private double ctx;

	public double getCtx() {
		return this.ctx;
	}

	public void setCtx(double ctx) {
		this.ctx = ctx;
	}

	private double stx;

	public double getStx() {
		return this.stx;
	}

	public void setStx(double stx) {
		this.stx = stx;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT9 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_9);
		for (Map<String, Object> map : listT9) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_9_B)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.itx = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.ctx = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.stx = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_9_B);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.itx
				+ ","
				+ this.ctx
				+ ","
				+ this.stx
				+ ","
				+ null + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}
	@Override
	public String toString() {
		return "TcsDet [itx=" + itx + ", ctx=" + ctx + ", stx=" + stx + "]";
	}	
}

// 9.A TCS Credit
class TcsCr {
	private TcsDet tcs_det;
	private double ttl_tcs;

	public double getTtl_tcs() {
		return ttl_tcs;
	}

	public void setTtl_tcs(double ttl_tcs) {
		this.ttl_tcs = ttl_tcs;
	}

	public TcsDet getTcs_det() {
		return tcs_det;
	}

	public void setTcs_det(TcsDet tcs_det) {
		this.tcs_det = tcs_det;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.tcs_det=new TcsDet();
		this.tcs_det.populateRootDTO(mapGroupByTableType);
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if(this.tcs_det != null)
		list.addAll(this.tcs_det.fetchInsertScripts(masterID, tileMap));

		return list;
	}

	@Override
	public String toString() {
		return "TcsCr [tcs_det=" + tcs_det + ", ttl_tcs=" + ttl_tcs + "]";
	}	
}

// 9.B TDS Credit
class TdsDet {
	private double itx;

	public double getItx() {
		return this.itx;
	}

	public void setItx(double itx) {
		this.itx = itx;
	}

	private double ctx;

	public double getCtx() {
		return this.ctx;
	}

	public void setCtx(double ctx) {
		this.ctx = ctx;
	}

	private double stx;

	public double getStx() {
		return this.stx;
	}

	public void setStx(double stx) {
		this.stx = stx;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		
		List<Map<String, Object>> listT9 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_9);
		for (Map<String, Object> map : listT9) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_9_A)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.itx = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.ctx = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.stx = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_9_A);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.itx
				+ ","
				+ this.ctx
				+ ","
				+ this.stx
				+ ","
				+ null + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "TdsDet [itx=" + itx + ", ctx=" + ctx + ", stx=" + stx + "]";
}
}

// 9.B TDS Credit
class TdsCr {
	private TdsDet tds_det;

 private double ttl_tds;
 private double ttl_tcs;
 
	public TdsDet getTds_det() {
		return tds_det;
	}

	public double getTtl_tds() {
		return ttl_tds;
	}

	public void setTtl_tds(double ttl_tds) {
		this.ttl_tds = ttl_tds;
	}

	public double getTtl_tcs() {
		return ttl_tcs;
	}

	public void setTtl_tcs(double ttl_tcs) {
		this.ttl_tcs = ttl_tcs;
	}

	public void setTds_det(TdsDet tds_det) {
		this.tds_det = tds_det;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		// TODO Auto-generated method stub
		this.tds_det=new TdsDet();
		this.tds_det.populateRootDTO(mapGroupByTableType);
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if(this.tds_det != null)
		list.addAll(this.tds_det.fetchInsertScripts(masterID, tileMap));

		return list;
	}

	@Override
	public String toString() {
		return "TdsCr [tds_det=" + tds_det + ", ttl_tds=" + ttl_tds
				+ ", ttl_tcs=" + ttl_tcs + "]";
	}	
}

// 10.2 Interest Liability output
class OutLiabMis {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		// TODO Auto-generated method stub
		List<Map<String, Object>> listT10 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_10);
		for (Map<String, Object> map : listT10) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_10_2)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_10_2);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "OutLiabMis [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}	
}

// 10.3 Interest Liability - ITC Claimed
class ItcClmMis {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT10 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_10);
		for (Map<String, Object> map : listT10) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_10_3)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_10_3);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "ItcClmMis [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}	
}

// 10.4 Interest Liability - Other ITC Reversal
class OthItcRvl {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT10 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_10);
		for (Map<String, Object> map : listT10) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_10_4)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_10_4);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "OthItcRvl [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}	
}

// 10.5 Interest Liability - Excess Claim
class ExcClmRed {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT10 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_10);
		for (Map<String, Object> map : listT10) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_10_5)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_10_5);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "ExcClmRed [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
}
}

// 10.6 Interest Liability - Credit interest
class CrIntrMis {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT10 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_10);
		for (Map<String, Object> map : listT10) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_10_6)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_10_6);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "CrIntrMis [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
}
}

// 10.7 Interest Liability - Interest liability forward
class IntrLiabFwd {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT10 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_10);
		for (Map<String, Object> map : listT10) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_10_7)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_10_7);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "IntrLiabFwd [iamt=" + iamt + ", camt=" + camt + ", samt="
				+ samt + ", cess=" + cess + "]";
	}	
}

// 10.8 Interest Liability - Delay Payment
class DelPymtTx {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT10 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_10);
		for (Map<String, Object> map : listT10) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_10_8)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_10_8);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "DelPymtTx [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}	
}

// 10.9 Interest Liability - Total interest Liability
class TotIntrLiab {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT10 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_10);
		for (Map<String, Object> map : listT10) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_10_9)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.iamt = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cess = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_10_9);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.iamt
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ "," + this.cess + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "TotIntrLiab [iamt=" + iamt + ", camt=" + camt + ", samt="
				+ samt + ", cess=" + cess + "]";
}
}

// 10.10 User Entry - Yet to be added to Db
class UsrEntry {
	private double iamt;

	public double getIamt() {
		return this.iamt;
	}

	public void setIamt(double iamt) {
		this.iamt = iamt;
	}

	private double camt;

	public double getCamt() {
		return this.camt;
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	private double cess;

	public double getCess() {
		return this.cess;
	}

	public void setCess(double cess) {
		this.cess = cess;
	}
	// This method to be added after adding 10.10 in DB.
	/*
	 * public void populateRootDTO(Map<String, List<Map<String, Object>>>
	 * mapGroupByTableType) { // TODO Auto-generated method stub
	 * List<Map<String, Object>> listT10 = mapGroupByTableType.get("T10"); for
	 * (Map<String, Object> map : listT10) { // User Entry table Misiing in DB,
	 * Change the type accordingly if (map.get("Group").equals("T.10.9")) {
	 * this.iamt = Double.valueOf(map.get("IGSTAmt")); this.camt =
	 * Double.valueOf(map.get("CGSTAmt")); this.samt =
	 * Double.valueOf(map.get("SGSTAmt")); this.cess =
	 * Double.valueOf(map.get("CessAmt")); } } }
	 */

	@Override
	public String toString() {
		return "UsrEntry [iamt=" + iamt + ", camt=" + camt + ", samt=" + samt
				+ ", cess=" + cess + "]";
	}	
}

// 10. Interest Liability
class IntrLiab {
	private OutLiabMis out_liab_mis;
	private double ttl_intr_liab;
	public double getTtl_intr_liab() {
		return ttl_intr_liab;
	}

	public void setTtl_intr_liab(double ttl_intr_liab) {
		this.ttl_intr_liab = ttl_intr_liab;
	}

	public OutLiabMis getOut_liab_mis() {
		return out_liab_mis;
	}

	public void setOut_liab_mis(OutLiabMis out_liab_mis) {
		this.out_liab_mis = out_liab_mis;
	}

	public double getTot_intra_liab() {
		return tot_intra_liab;
	}

	public void setTot_intra_liab(double tot_intra_liab) {
		this.tot_intra_liab = tot_intra_liab;
	}

	public ItcClmMis getItc_clm_mis() {
		return itc_clm_mis;
	}

	public void setItc_clm_mis(ItcClmMis itc_clm_mis) {
		this.itc_clm_mis = itc_clm_mis;
	}

	public OthItcRvl getOth_itc_rvl() {
		return oth_itc_rvl;
	}

	public void setOth_itc_rvl(OthItcRvl oth_itc_rvl) {
		this.oth_itc_rvl = oth_itc_rvl;
	}

	public ExcClmRed getExc_clm_red() {
		return exc_clm_red;
	}

	public void setExc_clm_red(ExcClmRed exc_clm_red) {
		this.exc_clm_red = exc_clm_red;
	}

	public CrIntrMis getCr_intr_mis() {
		return cr_intr_mis;
	}

	public void setCr_intr_mis(CrIntrMis cr_intr_mis) {
		this.cr_intr_mis = cr_intr_mis;
	}

	public IntrLiabFwd getIntr_liab_fwd() {
		return intr_liab_fwd;
	}

	public void setIntr_liab_fwd(IntrLiabFwd intr_liab_fwd) {
		this.intr_liab_fwd = intr_liab_fwd;
	}

	public DelPymtTx getDel_pymt_tx() {
		return del_pymt_tx;
	}

	public void setDel_pymt_tx(DelPymtTx del_pymt_tx) {
		this.del_pymt_tx = del_pymt_tx;
	}

	public TotIntrLiab getTot_intr_liab() {
		return tot_intr_liab;
	}

	public void setTot_intr_liab(TotIntrLiab tot_intr_liab) {
		this.tot_intr_liab = tot_intr_liab;
	}

	public UsrEntry getUsr_entry() {
		return usr_entry;
	}

	public void setUsr_entry(UsrEntry usr_entry) {
		this.usr_entry = usr_entry;
	}

	private double tot_intra_liab;
	public OutLiabMis getOutLiabMis() {
		return this.out_liab_mis;
	}

	public void setOutLiabMis(OutLiabMis out_liab_mis) {
		this.out_liab_mis = out_liab_mis;
	}

	private ItcClmMis itc_clm_mis;

	public ItcClmMis getItcClmMis() {
		return this.itc_clm_mis;
	}

	public void setItcClmMis(ItcClmMis itc_clm_mis) {
		this.itc_clm_mis = itc_clm_mis;
	}

	private OthItcRvl oth_itc_rvl;

	public OthItcRvl getOthItcRvl() {
		return this.oth_itc_rvl;
	}

	public void setOthItcRvl(OthItcRvl oth_itc_rvl) {
		this.oth_itc_rvl = oth_itc_rvl;
	}

	private ExcClmRed exc_clm_red;

	public ExcClmRed getExcClmRed() {
		return this.exc_clm_red;
	}

	public void setExcClmRed(ExcClmRed exc_clm_red) {
		this.exc_clm_red = exc_clm_red;
	}

	private CrIntrMis cr_intr_mis;

	public CrIntrMis getCrIntrMis() {
		return this.cr_intr_mis;
	}

	public void setCrIntrMis(CrIntrMis cr_intr_mis) {
		this.cr_intr_mis = cr_intr_mis;
	}

	private IntrLiabFwd intr_liab_fwd;

	public IntrLiabFwd getIntrLiabFwd() {
		return this.intr_liab_fwd;
	}

	public void setIntrLiabFwd(IntrLiabFwd intr_liab_fwd) {
		this.intr_liab_fwd = intr_liab_fwd;
	}

	private DelPymtTx del_pymt_tx;

	public DelPymtTx getDelPymtTx() {
		return this.del_pymt_tx;
	}

	public void setDelPymtTx(DelPymtTx del_pymt_tx) {
		this.del_pymt_tx = del_pymt_tx;
	}

	private TotIntrLiab tot_intr_liab;

	public TotIntrLiab getTotIntrLiab() {
		return this.tot_intr_liab;
	}

	public void setTotIntrLiab(TotIntrLiab tot_intr_liab) {
		this.tot_intr_liab = tot_intr_liab;
	}

	private UsrEntry usr_entry;

	public UsrEntry getUsrEntry() {
		return this.usr_entry;
	}

	public void setUsrEntry(UsrEntry usr_entry) {
		this.usr_entry = usr_entry;
	}

	// usr_entry from the Response is missing in DB
	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		// TODO Auto-generated method stub
		this.out_liab_mis=new OutLiabMis();
		this.out_liab_mis.populateRootDTO(mapGroupByTableType);
		
		this.itc_clm_mis=new ItcClmMis();
		this.itc_clm_mis.populateRootDTO(mapGroupByTableType);
		
		this.oth_itc_rvl=new OthItcRvl();
		this.oth_itc_rvl.populateRootDTO(mapGroupByTableType);
		
		this.exc_clm_red=new ExcClmRed();
		this.exc_clm_red.populateRootDTO(mapGroupByTableType);
		
		this.cr_intr_mis=new CrIntrMis();
		this.cr_intr_mis.populateRootDTO(mapGroupByTableType);
		
		this.intr_liab_fwd=new IntrLiabFwd();
		this.intr_liab_fwd.populateRootDTO(mapGroupByTableType);
		
		this.del_pymt_tx=new DelPymtTx();
		this.del_pymt_tx.populateRootDTO(mapGroupByTableType);
		
		this.tot_intr_liab=new TotIntrLiab();
		this.tot_intr_liab.populateRootDTO(mapGroupByTableType);
		// this.usr_entry.populateRootDTO(mapGroupByTableType);
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if(this.out_liab_mis != null)
		list.addAll(this.out_liab_mis.fetchInsertScripts(masterID, tileMap));
		
		if(this.itc_clm_mis != null)
		list.addAll(this.itc_clm_mis.fetchInsertScripts(masterID, tileMap));
		
		if(this.oth_itc_rvl != null)
		list.addAll(this.oth_itc_rvl.fetchInsertScripts(masterID, tileMap));
		
		if(this.exc_clm_red!= null)
		list.addAll(this.exc_clm_red.fetchInsertScripts(masterID, tileMap));
		
		if(this.cr_intr_mis != null)
		list.addAll(this.cr_intr_mis.fetchInsertScripts(masterID, tileMap));
		
		if(this.intr_liab_fwd != null)
		list.addAll(this.intr_liab_fwd.fetchInsertScripts(masterID, tileMap));
		
		if(this.del_pymt_tx != null)
		list.addAll(this.del_pymt_tx.fetchInsertScripts(masterID, tileMap));
		
		if(this.tot_intr_liab != null)
		list.addAll(this.tot_intr_liab.fetchInsertScripts(masterID, tileMap));
		return list;

	}

	@Override
	public String toString() {
		return "IntrLiab [out_liab_mis=" + out_liab_mis + ", ttl_intr_liab="
				+ ttl_intr_liab + ", tot_intra_liab=" + tot_intra_liab
				+ ", itc_clm_mis=" + itc_clm_mis + ", oth_itc_rvl="
				+ oth_itc_rvl + ", exc_clm_red=" + exc_clm_red
				+ ", cr_intr_mis=" + cr_intr_mis + ", intr_liab_fwd="
				+ intr_liab_fwd + ", del_pymt_tx=" + del_pymt_tx
				+ ", tot_intr_liab=" + tot_intr_liab + ", usr_entry="
				+ usr_entry + "]";
}
}

class LtFee {
	private double camt;
private double ttl_lt_fee;
	public double getTtl_lt_fee() {
	return ttl_lt_fee;
}

public void setTtl_lt_fee(double ttl_lt_fee) {
	this.ttl_lt_fee = ttl_lt_fee;
}

	public double getCamt() {
		return this.camt;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT11 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_11);
		for (Map<String, Object> map : listT11) {
			if (map.get(Constant.TABLETYPE).equals(Constant.TABLE_11)) {
				if(map.get(Constant.CGST_AMOUNT) != null)
					this.camt = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.samt = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
			}
		}
	}

	public void setCamt(double camt) {
		this.camt = camt;
	}

	private double samt;

	public double getSamt() {
		return this.samt;
	}

	public void setSamt(double samt) {
		this.samt = samt;
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_11);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.camt
				+ ","
				+ this.samt
				+ ","
				+ null + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "LtFee [camt=" + camt + ", ttl_lt_fee=" + ttl_lt_fee + ", samt="
				+ samt + "]";
	}	
}

// 12.3 TAX Paid in cash
class Pdcash {
	private double ipd;

	public double getIpd() {
		return this.ipd;
	}

	public void setIpd(double ipd) {
		this.ipd = ipd;
	}

	private double cpd;

	public double getCpd() {
		return this.cpd;
	}

	public void setCpd(double cpd) {
		this.cpd = cpd;
	}

	private double spd;

	public double getSpd() {
		return this.spd;
	}

	public void setSpd(double spd) {
		this.spd = spd;
	}

	private double cspd;

	public double getCspd() {
		return this.cspd;
	}

	public void setCspd(double cspd) {
		this.cspd = cspd;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.IGST_AMOUNT) != null)
			this.ipd = Double.valueOf(map.get(Constant.IGST_AMOUNT).toString());
			if(map.get(Constant.CGST_AMOUNT) != null)
			this.cpd = Double.valueOf(map.get(Constant.CGST_AMOUNT).toString());
			if(map.get(Constant.SGST_AMOUNT) != null)
			this.spd = Double.valueOf(map.get(Constant.SGST_AMOUNT).toString());
			if(map.get(Constant.CESS_AMOUNT) != null)
			this.cspd = Double.valueOf(map.get(Constant.CESS_AMOUNT).toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_12_3);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.ipd
				+ ","
				+ this.cpd
				+ ","
				+ this.spd
				+ ","
				+ this.cspd + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "Pdcash [ipd=" + ipd + ", cpd=" + cpd + ", spd=" + spd
				+ ", cspd=" + cspd + "]";
	}	
}

// 12. Paid through ITC
class Pditc {
	private double i_pdi;

	public double getIPdi() {
		return this.i_pdi;
	}

	public void setIPdi(double i_pdi) {
		this.i_pdi = i_pdi;
	}

	private double i_pdc;

	public double getIPdc() {
		return this.i_pdc;
	}

	public void setIPdc(double i_pdc) {
		this.i_pdc = i_pdc;
	}

	private double i_pds;

	public double getIPds() {
		return this.i_pds;
	}

	public void setIPds(double i_pds) {
		this.i_pds = i_pds;
	}

	private double c_pdi;

	public double getCPdi() {
		return this.c_pdi;
	}

	public void setCPdi(double c_pdi) {
		this.c_pdi = c_pdi;
	}

	private double c_pdc;

	public double getCPdc() {
		return this.c_pdc;
	}

	public void setCPdc(double c_pdc) {
		this.c_pdc = c_pdc;
	}

	private double s_pdi;

	public double getSPdi() {
		return this.s_pdi;
	}

	public void setSPdi(double s_pdi) {
		this.s_pdi = s_pdi;
	}

	private double s_pds;

	public double getSPds() {
		return this.s_pds;
	}

	public void setSPds(double s_pds) {
		this.s_pds = s_pds;
	}

	private double cs_pdcs;

	public double getCsPdcs() {
		return this.cs_pdcs;
	}

	public void setCsPdcs(double cs_pdcs) {
		this.cs_pdcs = cs_pdcs;
	}

	private Integer i_ds;

	public Integer getIDs() {
		return this.i_ds;
	}

	public void setIDs(Integer i_ds) {
		this.i_ds = i_ds;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if (map.get(Constant.GROUP).equals(Constant.TABLE_12_4)) {
			if(map.get(Constant.IGST_AMOUNT) != null)
				this.i_pdi = Double.valueOf(map.get(Constant.IGST_AMOUNT)
						.toString());
				if(map.get(Constant.CGST_AMOUNT) != null)
				this.c_pdi = Double.valueOf(map.get(Constant.CGST_AMOUNT)
						.toString());
				if(map.get(Constant.SGST_AMOUNT) != null)
				this.s_pdi = Double.valueOf(map.get(Constant.SGST_AMOUNT)
						.toString());
		}
		if (map.get(Constant.GROUP).equals(Constant.TABLE_12_5)) {
			if(map.get(Constant.IGST_AMOUNT) != null)
				this.i_pdc = Double.valueOf(map.get(Constant.IGST_AMOUNT)
						.toString());
				if(map.get(Constant.CGST_AMOUNT) != null)
				this.c_pdc = Double.valueOf(map.get(Constant.CGST_AMOUNT)
						.toString());
		}
		if (map.get(Constant.GROUP).equals(Constant.TABLE_12_6)) {
			if(map.get(Constant.IGST_AMOUNT) != null)
				this.i_pds = Double.valueOf(map.get(Constant.IGST_AMOUNT)
						.toString());
				if(map.get(Constant.SGST_AMOUNT) != null)
				this.s_pds = Double.valueOf(map.get(Constant.SGST_AMOUNT)
						.toString());
		}
		if (map.get(Constant.GROUP).equals(Constant.TABLE_12_7)) {
			this.cs_pdcs = Double.valueOf(map.get(Constant.CESS_AMOUNT)
					.toString());
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_12_4);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.i_pdi
				+ ","
				+ this.c_pdi
				+ ","
				+ this.s_pdi
				+ "," + null + "," + 1 + ")";
		list.add(insertQuery);

		tileID = tileMap.get(Constant.TABLE_12_5);
		insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.i_pdc
				+ ","
				+ this.c_pdc
				+ ","
				+ null
				+ ","
				+ null + "," + 1 + ")";
		list.add(insertQuery);

		tileID = tileMap.get(Constant.TABLE_12_6);
		insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.i_pds
				+ ","
				+ null
				+ ","
				+ this.s_pds
				+ ","
				+ null + "," + 1 + ")";
		list.add(insertQuery);

		tileID = tileMap.get(Constant.TABLE_12_7);
		insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.cs_pdcs + "," + 1 + ")";
		list.add(insertQuery);

		return list;

	}

	@Override
	public String toString() {
		return "Pditc [i_pdi=" + i_pdi + ", i_pdc=" + i_pdc + ", i_pds="
				+ i_pds + ", c_pdi=" + c_pdi + ", c_pdc=" + c_pdc + ", s_pdi="
				+ s_pdi + ", s_pds=" + s_pds + ", cs_pdcs=" + cs_pdcs
				+ ", i_ds=" + i_ds + "]";
	}
}

// 12 Tax Payable and PAID
class TxOffset {
	private ArrayList<Pdcash> pdcash;

	public ArrayList<Pdcash> getPdcash() {
		return this.pdcash;
	}

	public void setPdcash(ArrayList<Pdcash> pdcash) {
		this.pdcash = pdcash;
	}

	private ArrayList<Pditc> pditc;

	public ArrayList<Pditc> getPditc() {
		return this.pditc;
	}

	public void setPditc(ArrayList<Pditc> pditc) {
		this.pditc = pditc;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {

        this.pdcash = new ArrayList<Pdcash>();
        this.pditc = new ArrayList<Pditc>();
        List<Map<String, Object>> listT5 = mapGroupByTableType
                    .get(Constant.TABLE_TYPE_12);
        Pditc pd_Itc = new Pditc();
        for (Map<String, Object> map : listT5) {
              if (map.get(Constant.GROUP).equals(Constant.TABLE_12_3)) {
                    Pdcash pd_cash = new Pdcash();
                    pd_cash.populateRootDTO(map);                   
                    this.pdcash.add(pd_cash);
              } else if (map.get(Constant.GROUP).equals(Constant.TABLE_12_4)
                          || map.get(Constant.GROUP).equals(Constant.TABLE_12_5)
                          || map.get(Constant.GROUP).equals(Constant.TABLE_12_6)
                          || map.get(Constant.GROUP).equals(Constant.TABLE_12_7)
                          || map.get(Constant.GROUP).equals(Constant.TABLE_12_8)) {                        
                    pd_Itc.populateRootDTO(map);                    
              }
        }
        this.pditc.add(pd_Itc);

	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();
		
		if(this.pdcash != null)
		for (Pdcash pdCash : this.pdcash) {
			list.addAll(pdCash.fetchInsertScripts(masterID, tileMap));
		}

		if(this.pditc !=null)
		for (Pditc pdItc : this.pditc) {
			list.addAll(pdItc.fetchInsertScripts(masterID, tileMap));
		}

		return list;
	}

	@Override
	public String toString() {
		return "TxOffset [pdcash=" + pdcash + ", pditc=" + pditc + "]";
}
}

// 13.1 Interest offset
class IntrOffset {
	private double i_pdint;

	public double getIPdint() {
		return this.i_pdint;
	}

	public void setIPdint(double i_pdint) {
		this.i_pdint = i_pdint;
	}

	private double c_pdint;

	public double getCPdint() {
		return this.c_pdint;
	}

	public void setCPdint(double c_pdint) {
		this.c_pdint = c_pdint;
	}

	private double s_pdint;

	public double getSPdint() {
		return this.s_pdint;
	}

	public void setSPdint(double s_pdint) {
		this.s_pdint = s_pdint;
	}

	private double cs_pdint;

	public double getCsPdint() {
		return this.cs_pdint;
	}

	public void setCsPdint(double cs_pdint) {
		this.cs_pdint = cs_pdint;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.IGST_AMOUNT) != null)
		this.i_pdint = Double.valueOf(map.get(Constant.IGST_AMOUNT)
				.toString());
		if(map.get(Constant.CGST_AMOUNT) != null)
		this.c_pdint = Double.valueOf(map.get(Constant.CGST_AMOUNT)
				.toString());
		if(map.get(Constant.SGST_AMOUNT) != null)
		this.s_pdint = Double.valueOf(map.get(Constant.SGST_AMOUNT)
				.toString());
		if(map.get(Constant.CESS_AMOUNT) != null)
		this.cs_pdint = Double.valueOf(map.get(Constant.CESS_AMOUNT)
				.toString());
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_13_1_D);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.i_pdint
				+ ","
				+ this.c_pdint
				+ ","
				+ this.s_pdint + "," + this.cs_pdint + "," + 1 + ")";
		list.add(insertQuery);

		return list;
	}

	@Override
	public String toString() {
		return "IntrOffset [i_pdint=" + i_pdint + ", c_pdint=" + c_pdint
				+ ", s_pdint=" + s_pdint + ", cs_pdint=" + cs_pdint + "]";
	}	
}

// 13.2 Late Fee Offset
class LfeeOffset {
	private double c_pdlfee;

	public double getCPdlfee() {
		return this.c_pdlfee;
	}

	public void setCPdlfee(double c_pdlfee) {
		this.c_pdlfee = c_pdlfee;
	}

	private double s_pdlfee;

	public double getSPdlfee() {
		return this.s_pdlfee;
	}

	public void setSPdlfee(double s_pdlfee) {
		this.s_pdlfee = s_pdlfee;
	}

	public void populateRootDTO(Map<String, Object> map) {
		if(map.get(Constant.CGST_AMOUNT) != null)
		this.c_pdlfee = Double.valueOf(map.get(Constant.CGST_AMOUNT)
				.toString());
		if(map.get(Constant.SGST_AMOUNT) != null)
		this.s_pdlfee = Double.valueOf(map.get(Constant.SGST_AMOUNT)
				.toString());
}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_13_2_D);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.c_pdlfee
				+ ","
				+ this.s_pdlfee
				+ "," + null + "," + 1 + ")";
		list.add(insertQuery);

		return list;
	}

	@Override
	public String toString() {
		return "LfeeOffset [c_pdlfee=" + c_pdlfee + ", s_pdlfee=" + s_pdlfee
				+ "]";
}
}

class Igrfclm {
	private double tax;

	public double getTax() {
		return this.tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	private double intr;

	public double getIntr() {
		return this.intr;
	}

	public void setIntr(double intr) {
		this.intr = intr;
	}

	private double pen;

	public double getPen() {
		return this.pen;
	}

	public void setPen(double pen) {
		this.pen = pen;
	}

	private double fee;

	public double getFee() {
		return this.fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	private double oth;

	public double getOth() {
		return this.oth;
	}

	public void setOth(double oth) {
		this.oth = oth;
	}

	public void populateRootDTO(Map<String, Object> map) {
        // Check for tables details........
        //List<Map<String, Object>> listT14 = mapGroupByTableType         .get(Constant.TABLE_TYPE_14);
        
       // for (Map<String, Object> map : listT14) {
              if(map.get(Constant.TAX) != null)
                    this.tax = Double.valueOf(map.get(Constant.TAX).toString());
              if(map.get(Constant.INTEREST) != null)
                          this.intr = Double.valueOf(map.get(Constant.INTEREST)
                                      .toString());
              if(map.get(Constant.PENALTY) != null)
                          this.pen = Double.valueOf(map.get(Constant.PENALTY)
                                      .toString());
              if(map.get(Constant.FEE) != null)
                          this.fee = Double.valueOf(map.get(Constant.FEE)
                                      .toString());
              if(map.get(Constant.OTHER) != null)
                          this.oth = Double.valueOf(map.get(Constant.OTHER)
                                      .toString());                 
        //}
        }

	
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		
		List<String> list=new ArrayList<String>();
	String insertQuery = "insert into [gstr3].[tblgstr3RefundClaim]([MasterID],[Tax],[Interest],[Penalty],[Fee],[Other],[DebitEntryNum],[AccountNumber],[IsActive],[CLAIMTYPE]) values ("
			+ masterID
			+ ","
			+ this.tax
			+ ","
			+ this.intr
			+ ","
			+ this.pen
			+ ","
			+ this.fee
			+ ","
			+ this.oth
			+ ","
			+ null
			+ ","
			+ null
			+ ","
			+ 1 + ",'igrfclm')";
	list.add(insertQuery);
	
	return list;
	} 

	@Override
	public String toString() {
		return "Igrfclm [tax=" + tax + ", intr=" + intr + ", pen=" + pen
				+ ", fee=" + fee + ", oth=" + oth + "]";
}
}

class Cgrfclm {
	private double tax;

	public double getTax() {
		return this.tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	private double intr;

	public double getIntr() {
		return this.intr;
	}

	public void setIntr(double intr) {
		this.intr = intr;
	}

	private double pen;

	public double getPen() {
		return this.pen;
	}

	public void setPen(double pen) {
		this.pen = pen;
	}

	private double fee;

	public double getFee() {
		return this.fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	private double oth;

	public double getOth() {
		return this.oth;
	}

	public void setOth(double oth) {
		this.oth = oth;
	}

	public void populateRootDTO(Map<String, Object> map) {
        // Check for tables details........
		// List<Map<String, Object>> listT14 = mapGroupByTableType
		// .get(Constant.TABLE_TYPE_14);
        
       // for (Map<String, Object> map : listT14) {
              if(map.get(Constant.TAX) != null)
                    this.tax = Double.valueOf(map.get(Constant.TAX).toString());
              if(map.get(Constant.INTEREST) != null)
                          this.intr = Double.valueOf(map.get(Constant.INTEREST)
                                      .toString());
              if(map.get(Constant.PENALTY) != null)
				this.pen = Double.valueOf(map.get(Constant.PENALTY).toString());
              if(map.get(Constant.FEE) != null)
				this.fee = Double.valueOf(map.get(Constant.FEE).toString());
              if(map.get(Constant.OTHER) != null)
				this.oth = Double.valueOf(map.get(Constant.OTHER).toString());
        //}
        }

	
 
public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		
		List<String> list=new ArrayList<String>();
	String insertQuery = "insert into [gstr3].[tblgstr3RefundClaim]([MasterID],[Tax],[Interest],[Penalty],[Fee],[Other],[DebitEntryNum],[AccountNumber],[IsActive],[CLAIMTYPE]) values ("
			+ masterID
			+ ","
			+ this.tax
			+ ","
			+ this.intr
			+ ","
			+ this.pen
			+ ","
			+ this.fee
			+ ","
			+ this.oth
			+ ","
			+ null
			+ ","
			+ null
				+ "," + 1 + ",'cgrfclm')";
	list.add(insertQuery);
	
	return list;
	} 

	@Override
	public String toString() {
		return "Cgrfclm [tax=" + tax + ", intr=" + intr + ", pen=" + pen
				+ ", fee=" + fee + ", oth=" + oth + "]";
	}

}

class Sgrfclm {
	private double tax;

	public double getTax() {
		return this.tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	private double intr;

	public double getIntr() {
		return this.intr;
	}

	public void setIntr(double intr) {
		this.intr = intr;
	}

	private double pen;

	public double getPen() {
		return this.pen;
	}

	public void setPen(double pen) {
		this.pen = pen;
	}

	private double fee;

	public double getFee() {
		return this.fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	private double oth;

	public double getOth() {
		return this.oth;
	}

	public void setOth(double oth) {
		this.oth = oth;
	}

	public void populateRootDTO(Map<String, Object> map) {
        // Check for tables details........
        //List<Map<String, Object>> listT14 = mapGroupByTableType         .get(Constant.TABLE_TYPE_14);
        
      //  for (Map<String, Object> map : listT14) {
              if(map.get(Constant.TAX) != null)
                    this.tax = Double.valueOf(map.get(Constant.TAX).toString());
              if(map.get(Constant.INTEREST) != null)
                          this.intr = Double.valueOf(map.get(Constant.INTEREST)
                                      .toString());
              if(map.get(Constant.PENALTY) != null)
                          this.pen = Double.valueOf(map.get(Constant.PENALTY)
                                      .toString());
              if(map.get(Constant.FEE) != null)
                          this.fee = Double.valueOf(map.get(Constant.FEE)
                                      .toString());
              if(map.get(Constant.OTHER) != null)
                          this.oth = Double.valueOf(map.get(Constant.OTHER)
                                      .toString());                 
        //}
        }

	
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		
		List<String> list=new ArrayList<String>();
	String insertQuery = "insert into [gstr3].[tblgstr3RefundClaim]([MasterID],[Tax],[Interest],[Penalty],[Fee],[Other],[DebitEntryNum],[AccountNumber],[IsActive],[CLAIMTYPE]) values ("
			+ masterID
			+ ","
			+ this.tax
			+ ","
			+ this.intr
			+ ","
			+ this.pen
			+ ","
			+ this.fee
			+ ","
			+ this.oth
			+ ","
			+ null
			+ ","
			+ null
			+ ","
			+ 1 + ",'sgrfclm')";
	list.add(insertQuery);
	
	return list;
	} 

	@Override
	public String toString() {
		return "Sgrfclm [tax=" + tax + ", intr=" + intr + ", pen=" + pen
				+ ", fee=" + fee + ", oth=" + oth + "]";
}
}

class Csrfclm {
	private double tax;

	public double getTax() {
		return this.tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	private double intr;

	public double getIntr() {
		return this.intr;
	}

	public void setIntr(double intr) {
		this.intr = intr;
	}

	private double pen;

	public double getPen() {
		return this.pen;
	}

	public void setPen(double pen) {
		this.pen = pen;
	}

	private double fee;

	public double getFee() {
		return this.fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	private double oth;

	public double getOth() {
		return this.oth;
	}

	public void setOth(double oth) {
		this.oth = oth;
	}

	public void populateRootDTO(Map<String, Object> map) {
        // Check for tables details........
        //List<Map<String, Object>> listT14 = mapGroupByTableType         .get(Constant.TABLE_TYPE_14);
        
        //for (Map<String, Object> map : listT14) {
              if(map.get(Constant.TAX) != null)
                    this.tax = Double.valueOf(map.get(Constant.TAX).toString());
              if(map.get(Constant.INTEREST) != null)
                          this.intr = Double.valueOf(map.get(Constant.INTEREST)
                                      .toString());
              if(map.get(Constant.PENALTY) != null)
                          this.pen = Double.valueOf(map.get(Constant.PENALTY)
                                      .toString());
              if(map.get(Constant.FEE) != null)
                          this.fee = Double.valueOf(map.get(Constant.FEE)
                                      .toString());
              if(map.get(Constant.OTHER) != null)
                          this.oth = Double.valueOf(map.get(Constant.OTHER)
                                      .toString());                 
       // }
        }

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		
		List<String> list=new ArrayList<String>();
	String insertQuery = "insert into [gstr3].[tblgstr3RefundClaim]([MasterID],[Tax],[Interest],[Penalty],[Fee],[Other],[DebitEntryNum],[AccountNumber],[IsActive],[CLAIMTYPE]) values ("
			+ masterID
			+ ","
			+ this.tax
			+ ","
			+ this.intr
			+ ","
			+ this.pen
			+ ","
			+ this.fee
			+ ","
			+ this.oth
			+ ","
			+ null
			+ ","
			+ null
			+ ","
			+ 1 + ",'csrfclm')";
	list.add(insertQuery);
	
	return list;
	} 

	@Override
	public String toString() {
		return "Csrfclm [tax=" + tax + ", intr=" + intr + ", pen=" + pen
				+ ", fee=" + fee + ", oth=" + oth + "]";
	}	
}

// 14 Refund Claim
class Refclm {
	private String gstin;

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	private String ret_period;

	public String getRetPeriod() {
		return this.ret_period;
	}

	public void setRetPeriod(String ret_period) {
		this.ret_period = ret_period;
	}

	private Igrfclm igrfclm;

	public Igrfclm getIgrfclm() {
		return this.igrfclm;
	}

	public void setIgrfclm(Igrfclm igrfclm) {
		this.igrfclm = igrfclm;
	}

	private Cgrfclm cgrfclm;

	public Cgrfclm getCgrfclm() {
		return this.cgrfclm;
	}

	public void setCgrfclm(Cgrfclm cgrfclm) {
		this.cgrfclm = cgrfclm;
	}

	private Sgrfclm sgrfclm;

	public Sgrfclm getSgrfclm() {
		return this.sgrfclm;
	}

	public void setSgrfclm(Sgrfclm sgrfclm) {
		this.sgrfclm = sgrfclm;
	}

	private Csrfclm csrfclm;

	public Csrfclm getCsrfclm() {
		return this.csrfclm;
	}

	public void setCsrfclm(Csrfclm csrfclm) {
		this.csrfclm = csrfclm;
	}

	private int bankacc;

	public int getBankacc() {
		return this.bankacc;
	}

	public void setBankacc(int bankacc) {
		this.bankacc = bankacc;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
        List<Map<String, Object>> listT14 = mapGroupByTableType
                    .get(Constant.TABLE_TYPE_14);
        for (Map<String, Object> map : listT14) {
              if(map.get(Constant.ACCOUNTNUMBER) != null){
            	  this.bankacc = Integer.valueOf(map.get(Constant.ACCOUNTNUMBER)
						.toString());
              }
              if (map.get(Constant.CLAIMTYPE).equals(Constant.CLAIM_INTEGRATED)) {
                    if (this.igrfclm == null)
                          this.igrfclm = new Igrfclm();
                    igrfclm.populateRootDTO(map);
              } else if (map.get(Constant.CLAIMTYPE).equals(
                          Constant.CLAIM_CENTRAL)) {
                    if (this.cgrfclm == null)
                          this.cgrfclm = new Cgrfclm();
                    cgrfclm.populateRootDTO(map);
              } else if (map.get(Constant.CLAIMTYPE).equals(Constant.CLAIM_STATE)) {
                    if (this.sgrfclm == null)
                          this.sgrfclm = new Sgrfclm();
                    sgrfclm.populateRootDTO(map);
              } else if (map.get(Constant.CLAIMTYPE).equals(Constant.CLAIM_CESS)) {
                    if (this.csrfclm == null)
                          this.csrfclm = new Csrfclm();
                    csrfclm.populateRootDTO(map);
              }
        }
  }

	
	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();
if(this.igrfclm != null)
	list.addAll(this.igrfclm.fetchInsertScripts(masterID,tileMap));

if(this.cgrfclm != null)
	list.addAll(this.cgrfclm.fetchInsertScripts(masterID,tileMap));

if(this.sgrfclm != null)
	list.addAll(this.sgrfclm.fetchInsertScripts(masterID,tileMap));

if(this.csrfclm != null)
	list.addAll(this.csrfclm.fetchInsertScripts(masterID,tileMap));
		
return list;

	}

	@Override
	public String toString() {
		return "Refclm [gstin=" + gstin + ", ret_period=" + ret_period
				+ ", igrfclm=" + igrfclm + ", cgrfclm=" + cgrfclm
				+ ", sgrfclm=" + sgrfclm + ", csrfclm=" + csrfclm
				+ ", bankacc=" + bankacc + "]";
} 

}

class Pdcash2 {
	private double ipd;
	private double i_intra_pd;

	public double getI_intra_pd() {
		return i_intra_pd;
	}

	public void setI_intra_pd(double i_intra_pd) {
		this.i_intra_pd = i_intra_pd;
	}

	public double getIpd() {
		return this.ipd;
	}

	public void setIpd(double ipd) {
		this.ipd = ipd;
	}

	private double cpd;

	public double getCpd() {
		return this.cpd;
	}

	public void setCpd(double cpd) {
		this.cpd = cpd;
	}

	private double spd;

	public double getSpd() {
		return this.spd;
	}

	public void setSpd(double spd) {
		this.spd = spd;
	}

	private double cspd;

	public double getCspd() {
		return this.cspd;
	}

	public void setCspd(double cspd) {
		this.cspd = cspd;
	}

	private double i_intr_pd;

	public double getI_intr_pd() {
		return i_intr_pd;
	}

	public void setI_intr_pd(double i_intr_pd) {
		this.i_intr_pd = i_intr_pd;
	}

	public double getC_intr_pd() {
		return c_intr_pd;
	}

	public void setC_intr_pd(double c_intr_pd) {
		this.c_intr_pd = c_intr_pd;
	}

	public double getS_intr_pd() {
		return s_intr_pd;
	}

	public void setS_intr_pd(double s_intr_pd) {
		this.s_intr_pd = s_intr_pd;
	}

	public double getCs_intr_pd() {
		return cs_intr_pd;
	}

	public void setCs_intr_pd(double cs_intr_pd) {
		this.cs_intr_pd = cs_intr_pd;
	}

	public double getC_lfee_pd() {
		return c_lfee_pd;
	}

	public void setC_lfee_pd(double c_lfee_pd) {
		this.c_lfee_pd = c_lfee_pd;
	}

	public double getS_lfee_pd() {
		return s_lfee_pd;
	}

	public void setS_lfee_pd(double s_lfee_pd) {
		this.s_lfee_pd = s_lfee_pd;
	}

	public double getIIntrPd() {
		return this.i_intr_pd;
	}

	public void setIIntrPd(double i_intr_pd) {
		this.i_intr_pd = i_intr_pd;
	}

	private double c_intr_pd;

	public double getCIntrPd() {
		return this.c_intr_pd;
	}

	public void setCIntrPd(double c_intr_pd) {
		this.c_intr_pd = c_intr_pd;
	}

	private double s_intr_pd;

	public double getSIntrPd() {
		return this.s_intr_pd;
	}

	public void setSIntrPd(double s_intr_pd) {
		this.s_intr_pd = s_intr_pd;
	}

	private double cs_intr_pd;

	public double getCsIntrPd() {
		return this.cs_intr_pd;
	}

	public void setCsIntrPd(double cs_intr_pd) {
		this.cs_intr_pd = cs_intr_pd;
	}

	private double c_lfee_pd;

	public double getCLfeePd() {
		return this.c_lfee_pd;
	}

	public void setCLfeePd(double c_lfee_pd) {
		this.c_lfee_pd = c_lfee_pd;
	}

	private double s_lfee_pd;

	public double getSLfeePd() {
		return this.s_lfee_pd;
	}

	public void setSLfeePd(double s_lfee_pd) {
		this.s_lfee_pd = s_lfee_pd;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT15 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_15);
		for (Map<String, Object> map : listT15) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_15_2)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.ipd = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.cpd = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.spd = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cspd = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
			if (map.get(Constant.GROUP).equals(Constant.TABLE_15_7)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.i_intr_pd = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.c_intr_pd = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.s_intr_pd = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
					if(map.get(Constant.CESS_AMOUNT) != null)
					this.cs_intr_pd = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
			if (map.get(Constant.GROUP).equals(Constant.TABLE_15_8)) {
				if(map.get(Constant.CGST_AMOUNT) != null)
					this.c_lfee_pd = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.s_lfee_pd = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
			}
		}
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_15_2);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.ipd
				+ ","
				+ this.cpd
				+ ","
				+ this.spd
				+ ","
				+ this.cspd + "," + 1 + ")";
		list.add(insertQuery);

		tileID = tileMap.get(Constant.TABLE_15_7);
		insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.i_intr_pd
				+ ","
				+ this.c_intr_pd
				+ ","
				+ this.s_intr_pd + "," + this.cs_intr_pd + "," + 1 + ")";
		list.add(insertQuery);

		tileID = tileMap.get(Constant.TABLE_15_8);
		insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.c_lfee_pd
				+ ","
				+ this.s_lfee_pd + "," + null + "," + 1 + ")";
		list.add(insertQuery);

		return list;
	}

	@Override
	public String toString() {
		return "Pdcash2 [ipd=" + ipd + ", i_intra_pd=" + i_intra_pd + ", cpd="
				+ cpd + ", spd=" + spd + ", cspd=" + cspd + ", i_intr_pd="
				+ i_intr_pd + ", c_intr_pd=" + c_intr_pd + ", s_intr_pd="
				+ s_intr_pd + ", cs_intr_pd=" + cs_intr_pd + ", c_lfee_pd="
				+ c_lfee_pd + ", s_lfee_pd=" + s_lfee_pd + "]";
	}	
}

class Pditc2 {
	private double i_pdi;

	public double getIPdi() {
		return this.i_pdi;
	}

	public void setIPdi(double i_pdi) {
		this.i_pdi = i_pdi;
	}

	private double i_pdc;

	public double getIPdc() {
		return this.i_pdc;
	}

	public void setIPdc(double i_pdc) {
		this.i_pdc = i_pdc;
	}

	private double i_ds;

	public double getIDs() {
		return this.i_ds;
	}

	public void setIDs(double i_ds) {
		this.i_ds = i_ds;
	}

	private double c_pdi;

	public double getCPdi() {
		return this.c_pdi;
	}

	public void setCPdi(double c_pdi) {
		this.c_pdi = c_pdi;
	}

	private double c_pdc;

	public double getCPdc() {
		return this.c_pdc;
	}

	public void setCPdc(double c_pdc) {
		this.c_pdc = c_pdc;
	}

	private double s_pdi;

	public double getSPdi() {
		return this.s_pdi;
	}

	public void setSPdi(double s_pdi) {
		this.s_pdi = s_pdi;
	}

	private double s_pds;

	public double getSPds() {
		return this.s_pds;
	}

	public void setSPds(double s_pds) {
		this.s_pds = s_pds;
	}

	private double cs_pdcs;

	public double getCsPdcs() {
		return this.cs_pdcs;
	}

	public void setCsPdcs(double cs_pdcs) {
		this.cs_pdcs = cs_pdcs;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		List<Map<String, Object>> listT15 = mapGroupByTableType
				.get(Constant.TABLE_TYPE_15);
		for (Map<String, Object> map : listT15) {
			if (map.get(Constant.GROUP).equals(Constant.TABLE_15_3)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.i_pdi = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.c_pdi = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.s_pdi = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
			}
			if (map.get(Constant.GROUP).equals(Constant.TABLE_15_4)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.i_pdc = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.CGST_AMOUNT) != null)
					this.c_pdc = Double.valueOf(map.get(Constant.CGST_AMOUNT)
							.toString());	
			}
			if (map.get(Constant.GROUP).equals(Constant.TABLE_15_5)) {
				if(map.get(Constant.IGST_AMOUNT) != null)
					this.i_ds = Double.valueOf(map.get(Constant.IGST_AMOUNT)
							.toString());
					if(map.get(Constant.SGST_AMOUNT) != null)
					this.s_pds = Double.valueOf(map.get(Constant.SGST_AMOUNT)
							.toString());
			}
			if (map.get(Constant.GROUP).equals(Constant.TABLE_15_6)) {
				if(map.get(Constant.CESS_AMOUNT) != null)
					this.cs_pdcs = Double.valueOf(map.get(Constant.CESS_AMOUNT)
							.toString());
			}
		}

	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		int tileID = tileMap.get(Constant.TABLE_15_3);
		String insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.i_pdi
				+ ","
				+ this.c_pdi
				+ ","
				+ this.s_pdi
				+ "," + null + "," + 1 + ")";
		list.add(insertQuery);

		tileID = tileMap.get(Constant.TABLE_15_4);
		insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.i_pdc
				+ ","
				+ this.c_pdc
				+ ","
				+ null
				+ ","
				+ null + "," + 1 + ")";
		list.add(insertQuery);

		tileID = tileMap.get(Constant.TABLE_15_5);
		insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.i_ds
				+ ","
				+ null
				+ ","
				+ this.s_pds
				+ ","
				+ null + "," + 1 + ")";
		list.add(insertQuery);

		tileID = tileMap.get(Constant.TABLE_15_6);
		insertQuery = "insert into [gstr3].[tblgetgstr3Details]([MasterID],[TileID],[Rate],[eGSIN],[TaxableValue],[IGSTAmt],[CGSTAmt],[SGSTAmt],[CessAmt],[IsActive]) values ("
				+ masterID
				+ ","
				+ tileID
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ null
				+ ","
				+ this.cs_pdcs + "," + 1 + ")";
		list.add(insertQuery);

		return list;
	}

	@Override
	public String toString() {
		return "Pditc2 [i_pdi=" + i_pdi + ", i_pdc=" + i_pdc + ", i_ds=" + i_ds
				+ ", c_pdi=" + c_pdi + ", c_pdc=" + c_pdc + ", s_pdi=" + s_pdi
				+ ", s_pds=" + s_pds + ", cs_pdcs=" + cs_pdcs + "]";
}
}

class LdgDebitEntries {
	private Pdcash2 pdcash;
	private double ttl_txs_paid;
	public double getTtl_txs_paid() {
		return ttl_txs_paid;
	}

	public void setTtl_txs_paid(double ttl_txs_paid) {
		this.ttl_txs_paid = ttl_txs_paid;
	}

	public Pdcash2 getPdcash() {
		return this.pdcash;
	}

	public void setPdcash(Pdcash2 pdcash) {
		this.pdcash = pdcash;
	}

	private Pditc2 pditc;

	public Pditc2 getPditc() {
		return this.pditc;
	}

	public void setPditc(Pditc2 pditc) {
		this.pditc = pditc;
	}

	public void populateRootDTO(
			Map<String, List<Map<String, Object>>> mapGroupByTableType) {
		this.pdcash=new Pdcash2();
		this.pdcash.populateRootDTO(mapGroupByTableType);
		
		this.pditc=new Pditc2();
		this.pditc.populateRootDTO(mapGroupByTableType);
	}

	public List<String> fetchInsertScripts(int masterID,
			Map<String, Integer> tileMap) {

		List<String> list = new ArrayList<String>();

		if(this.pdcash != null)
		list.addAll(this.pdcash.fetchInsertScripts(masterID, tileMap));

		if(this.pditc != null)
		list.addAll(this.pditc.fetchInsertScripts(masterID, tileMap));

		return list;
	}

	@Override
	public String toString() {
		return "LdgDebitEntries [pdcash=" + pdcash + ", ttl_txs_paid="
				+ ttl_txs_paid + ", pditc=" + pditc + "]";
	}	
}
