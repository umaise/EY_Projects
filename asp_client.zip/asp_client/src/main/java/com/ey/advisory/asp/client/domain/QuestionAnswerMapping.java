package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "tblQuestionAnswerMapping",schema=Constant.MASTER_SCHEMA)
public class QuestionAnswerMapping implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "QuestionAnsMapID")
    private long questionAnsMapID;
    
    @Column(name = "QuestionID")
    private String questionID;
    
    @Column(name = "AnswerID")
    private String answerID;
    
    @Column(name = "EntityID")
    private int entityID;
    
    @Column(name = "Description")
    private String description;
    
    @Column(name = "IsDeleted")
    private Boolean isDeleted;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
    @Column(name = "CreatedDate")
    private Date createdDate;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
    @Column(name = "UpdatedDate")
    private Date updatedDate;

    public long getQuestionAnsMapID() {
        return questionAnsMapID;
    }

    public void setQuestionAnsMapID(long questionAnsMapID) {
        this.questionAnsMapID = questionAnsMapID;
    }

    public int getEntityID() {
        return entityID;
    }

    public void setEntityID(int entityID) {
        this.entityID = entityID;
    }

    public String getQuestionID() {
        return questionID;
    }

    public void setQuestionID(String questionID) {
        this.questionID = questionID;
    }

    public String getAnswerID() {
        return answerID;
    }

    public void setAnswerID(String answerID) {
        this.answerID = answerID;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public String toString() {
        return "QuestionAnswerMapping [questionID=" + questionID + ", answerID=" + answerID + ", entityID=" + entityID
            + ", description=" + description + ", isDeleted=" + isDeleted + ", createdDate=" + createdDate
            + ", updatedDate=" + updatedDate + "]";
    }
    
}
