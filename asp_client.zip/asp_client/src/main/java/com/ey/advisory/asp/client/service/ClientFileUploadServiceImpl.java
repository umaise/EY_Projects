package com.ey.advisory.asp.client.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.InvoiceDao;
import com.ey.advisory.asp.client.domain.FileUploadMasterClient;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.InvoiceProcessDto;

@Service
public class ClientFileUploadServiceImpl implements ClientFileUploadService {

    @Autowired
    InvoiceDao invoiceDao;

    private static final Logger LOGGER = Logger.getLogger(ClientFileUploadServiceImpl.class);

    @Override
    public boolean updateFilejobStatus(String key) {
    	if(LOGGER.isInfoEnabled()){
        LOGGER.info("entering updateFilejobStatus - "+key);
    	}
        String[] split = key.split("_");
        long fileId = Long.parseLong(split[1]);

     
        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("key contains  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
        	}
        	if(key.contains(Constant.KEY_GSTR6)){
             	if(LOGGER.isInfoEnabled()){
                 LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR6));
             	}

             	 invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BR_STAGE1);
             	 

                 if(LOGGER.isInfoEnabled()){
                 LOGGER.info("After  updateFilejobStatus");
                 }

             }
            if(key.contains(Constant.KEY_GSTR2)){
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
            	}

                invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BR_STAGE1);

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("After  updateFilejobStatus");
                }

            } else{
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
            	}

                invoiceDao.updateFileUploadStatus(fileId, Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR1,Constant.DATA_FLOW_STAGES_BR_STAGE1);

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
                }
            }
        
       /* else if(split.length==3 && key.contains("")){

        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
        	}

            invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2,Constant.DATA_FLOW_STAGES_BR_STAGE1);

            if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
            }
        }*/
        if(LOGGER.isInfoEnabled()){
        LOGGER.info("exiting updateFilejobStatus - "+key);
        }
        return true;
    }

    @Override
    public boolean updateBifurcationjobStatus(String key) {
    	if(LOGGER.isInfoEnabled()){
        LOGGER.info("entering updateFilejobStatus - "+key);
    	}
        String[] split = key.split("_");
        long fileId = Long.parseLong(split[1]);
        Boolean result=false;

       
        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("key contains  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
        	}
        	if(key.contains(Constant.KEY_GSTR6)){
             	if(LOGGER.isInfoEnabled()){
                 LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR6));
             	}

             	 invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BIFURCATION);
             	 result=true;

                 if(LOGGER.isInfoEnabled()){
                 LOGGER.info("After  updateFilejobStatus");
                 }

             }
            if(key.contains(Constant.KEY_GSTR2)){
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
            	}

            	 invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BIFURCATION);
            	 result=true;

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("After  updateFilejobStatus");
                }

            } else{
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
            	}

                invoiceDao.updateFileUploadStatus(fileId, Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR1,Constant.DATA_FLOW_STAGES_BIFURCATION);

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
                }
            }
        
  /*      else if(split.length==3 && key.contains("")){

        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
        	}

            invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2,Constant.DATA_FLOW_STAGES_BIFURCATION);

            if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
            }
        }*/
        if(LOGGER.isInfoEnabled()){
        LOGGER.info("exiting updateFilejobStatus - "+key);
        }
        return true;
    }
    
    @Override
    public boolean timeoutAndUpdateBifurcationjobStatus(String key) {
    	if(LOGGER.isInfoEnabled()){
        LOGGER.info("entering updateFilejobStatus - "+key);
    	}
        String[] split = key.split("_");
        long fileId = Long.parseLong(split[1]);
        Boolean result=false;

      
        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("key contains  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
        	}
        	
        	if(key.contains(Constant.KEY_GSTR6)){
             	if(LOGGER.isInfoEnabled()){
                 LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR6));
             	}

             	 invoiceDao.timeoutAndUpdateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BIFURCATION);
             	 result=true;

                 if(LOGGER.isInfoEnabled()){
                 LOGGER.info("After  updateFilejobStatus");
                 }

             }

            if(key.contains(Constant.KEY_GSTR2)){
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
            	}

            	 invoiceDao.timeoutAndUpdateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BIFURCATION);
            	 result=true;

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("After  updateFilejobStatus");
                }

            } else{
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
            	}

                invoiceDao.timeoutAndUpdateFileUploadStatus(fileId, Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR1,Constant.DATA_FLOW_STAGES_BIFURCATION);

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
                }
            }
        /* else if(split.length==3 && key.contains("")){

        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
        	}

            invoiceDao.timeoutAndUpdateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2,Constant.DATA_FLOW_STAGES_BIFURCATION);

            if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
            }
        }*/
        if(LOGGER.isInfoEnabled()){
        LOGGER.info("exiting updateFilejobStatus - "+key);
        }
        return true;
    }

    @Override
    public boolean updateBifurcationjobFailStatus(String key) {
    	if(LOGGER.isInfoEnabled()){
        LOGGER.info("entering updateFilejobStatus - "+key);
    	}
        String[] split = key.split("_");
        long fileId = Long.parseLong(split[1]);
        Boolean result=false;

        
        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("key contains  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
        	}
        	if(key.contains(Constant.KEY_GSTR6)){
             	if(LOGGER.isInfoEnabled()){
                 LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR6));
             	}

             	 invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BIFURCATION);
             	 result=true;

                 if(LOGGER.isInfoEnabled()){
                 LOGGER.info("After  updateFilejobStatus");
                 }

             }
            if(key.contains(Constant.KEY_GSTR2)){
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
            	}

            	 invoiceDao.updateBifurcationFailStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BIFURCATION);
            	 result=true;

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("After  updateFilejobStatus");
                }

            } else{
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
            	}

                invoiceDao.updateBifurcationFailStatus(fileId, Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR1,Constant.DATA_FLOW_STAGES_BIFURCATION);

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
                }
            }
       /* 
        else if(split.length==3 && key.contains("")){

        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
        	}

            invoiceDao.updateBifurcationFailStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2,Constant.DATA_FLOW_STAGES_BIFURCATION);

            if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
            }
        }*/
        if(LOGGER.isInfoEnabled()){
        LOGGER.info("exiting updateFilejobStatus - "+key);
        }
        return true;
    }

    @Override
    public boolean updateStageOneFailStatus(String key) {
    	if(LOGGER.isInfoEnabled()){
        LOGGER.info("entering updateFilejobStatus - "+key);
    	}
        String[] split = key.split("_");
        long fileId = Long.parseLong(split[1]);
        Boolean result=false;

       
        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("key contains  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
        	}
        	
        	 if(key.contains(Constant.KEY_GSTR6)){
             	if(LOGGER.isInfoEnabled()){
                 LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR6));
             	}

             	 invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BR_STAGE1);
             	 result=true;

                 if(LOGGER.isInfoEnabled()){
                 LOGGER.info("After  updateFilejobStatus");
                 }

             }

            if(key.contains(Constant.KEY_GSTR2)){
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr2"+key.contains(Constant.KEY_GSTR2));
            	}

            	 invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2, Constant.DATA_FLOW_STAGES_BR_STAGE1);
            	 result=true;

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("After  updateFilejobStatus");
                }

            } else{
            	if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
            	}

                invoiceDao.updateFileUploadStatus(fileId, Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR1,Constant.DATA_FLOW_STAGES_BR_STAGE1);

                if(LOGGER.isInfoEnabled()){
                LOGGER.info("before  updateFilejobStatus gstr1");
                }
            }
        
       /* else if(split.length==3 && key.contains("")){

        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
        	}

            invoiceDao.updateFileUploadStatus(fileId,Constant.DATA_FLOW_STAGES_RETURNTYPE_GSTR2,Constant.DATA_FLOW_STAGES_BR_STAGE1);

            if(LOGGER.isInfoEnabled()){
            LOGGER.info("before  updateFilejobStatus gstrPipe2");
            }
        }*/
        if(LOGGER.isInfoEnabled()){
        LOGGER.info("exiting updateFilejobStatus - "+key);
        }
        return true;
    }

    /**
     * this method is used to update the Invoice status,type in database
     * 
     * @param InvoiceList
     * @param fileId
     * 
     * @return save status
     * @throws Exception 
     */
    @Override
    public boolean saveInvoiceStatus(Set<InvoiceProcessDto> invoice,Integer fileId) throws Exception {

        return invoiceDao.saveInvoiceStatus(invoice,fileId);
    }

    /**
     * this method is used to save the ErrorInfo of rules applied on staging
     * table in database
     * 
     * @param ErrorInfo
     *            List
     * @throws Exception 
     */
    @Override
    public boolean saveSalesErrorInfo(Set<TblSalesErrorInfo> errorInfo) throws Exception {
       return saveMailStatusDetailsInfo(errorInfo) && invoiceDao.saveSalesErrorInfo(errorInfo);
      //  return invoiceDao.saveSalesErrorInfo(errorInfo);
    }

    private boolean saveMailStatusDetailsInfo(Set<TblSalesErrorInfo> errorList) {

        Set<String> gstinList = new HashSet<>();
        for (TblSalesErrorInfo tblSalesErrorInfo : errorList) {
            gstinList.add(tblSalesErrorInfo.getGstin());
        }
        return invoiceDao.saveMailStatusDetailsInfo(gstinList, Constant.MAILSTATUS_RETURNTYPE_GSTR1);
    }
    
    public List<FileUploadMasterClient> getFileFromClientMaster(Long fileId){
    	return invoiceDao.getFileFromClientMaster(fileId);
    }
}
