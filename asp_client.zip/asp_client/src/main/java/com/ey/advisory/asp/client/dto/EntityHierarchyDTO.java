package com.ey.advisory.asp.client.dto;

import java.util.List;

public class EntityHierarchyDTO {

	
	private String groupCode;
	private String entityCode;
	private String gstin;
	private List<String> circleCodeList;
	private List<String> subDivCodeList;
	private List<String> profitCenterList;
	private List<String> businessCodeList;
	private List<String> plantCodeList;
	
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public String getEntityCode() {
		return entityCode;
	}
	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public List<String> getCircleCodeList() {
		return circleCodeList;
	}
	public void setCircleCodeList(List<String> circleCodeList) {
		this.circleCodeList = circleCodeList;
	}
	public List<String> getSubDivCodeList() {
		return subDivCodeList;
	}
	public void setSubDivCodeList(List<String> subDivCodeList) {
		this.subDivCodeList = subDivCodeList;
	}
	public List<String> getProfitCenterList() {
		return profitCenterList;
	}
	public void setProfitCenterList(List<String> profitCenterList) {
		this.profitCenterList = profitCenterList;
	}
	public List<String> getBusinessCodeList() {
		return businessCodeList;
	}
	public void setBusinessCodeList(List<String> businessCodeList) {
		this.businessCodeList = businessCodeList;
	}
	public List<String> getPlantCodeList() {
		return plantCodeList;
	}
	public void setPlantCodeList(List<String> plantCodeList) {
		this.plantCodeList = plantCodeList;
	}
	
}
