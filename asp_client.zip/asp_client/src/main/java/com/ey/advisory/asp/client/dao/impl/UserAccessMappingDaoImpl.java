package com.ey.advisory.asp.client.dao.impl;

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.UserAccessMappingDao;
import com.ey.advisory.asp.client.domain.UserAccessMapping;
@Repository
public class UserAccessMappingDaoImpl implements UserAccessMappingDao{
	
	@Autowired
	private HibernateDao hibernateDao;
	
	private static final Logger logger = Logger.getLogger(UserAccessMappingDaoImpl.class);

	@SuppressWarnings("unchecked")
	@Override
	public List<UserAccessMapping> getMappingsByUserId(Integer userId) {
		List<UserAccessMapping> mappings = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(UserAccessMapping.class);
			detachedCriteria.add(Restrictions.eq("userID", userId));
			detachedCriteria.addOrder(Order.asc("accessLevel"));
			mappings = (List<UserAccessMapping>) hibernateDao.find(detachedCriteria);
			}catch(Exception e){
				logger.error("Error fetching getGstinDetailsByEntity " + e);
			}
		return mappings;
	}

	
}
