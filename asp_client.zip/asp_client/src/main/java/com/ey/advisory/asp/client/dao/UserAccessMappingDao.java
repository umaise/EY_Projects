package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.UserAccessMapping;

public interface UserAccessMappingDao {

	public List<UserAccessMapping> getMappingsByUserId(Integer userId);
}
