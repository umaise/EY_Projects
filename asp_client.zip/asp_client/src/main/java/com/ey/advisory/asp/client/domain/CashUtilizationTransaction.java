package com.ey.advisory.asp.client.domain;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.google.api.client.util.DateTime;

@Entity
@Table(name="CashUtilizationTransaction", schema="gstr3")
public class CashUtilizationTransaction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CashUtilizationTransactionUID")
	private BigInteger cashUtilizationTransactionUID  ;
	@Column(name="GSTIN")
	private String gstin;
	@Column(name="CashData",nullable=false)
	private String cashData;
	@Column(name="ReturnPeriod")
	private String returnPeriod ;
	@Column(name="CreatedOn")
	private Date createdOn ;
	@Column(name="IsPrevious")
	private Boolean isPrevMonth  ;
	@Column(name="IsSubmitted")
	private Boolean isSubmitted;
	

	public Boolean getIsPrevMonth() {
		return isPrevMonth;
	}
	public void setIsPrevMonth(Boolean isPrevMonth) {
		this.isPrevMonth = isPrevMonth;
	}
	public BigInteger getCashUtilizationTransactionUID() {
		return cashUtilizationTransactionUID;
	}
	public void setCashUtilizationTransactionUID(
			BigInteger cashUtilizationTransactionUID) {
		this.cashUtilizationTransactionUID = cashUtilizationTransactionUID;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getCashData() {
		return cashData;
	}
	public void setCashData(String cashData) {
		this.cashData = cashData;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Boolean getIsSubmitted() {
		return isSubmitted;
	}
	public void setIsSubmitted(Boolean isSubmitted) {
		this.isSubmitted = isSubmitted;
	}
	
	

}
