package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR2Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR2B2BCLIAInvoiceDetails;
import com.ey.advisory.asp.client.domain.GlCodeMaster;
import com.ey.advisory.asp.client.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.client.domain.Gstr2B2BInvoiceDetailsModel;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.ReconProcessDTO;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.LineItemDTO;

@Repository
public class GSTR2DaoImpl implements GSTR2Dao {

	private static final Logger log = Logger.getLogger(GSTR2DaoImpl.class);

	@Autowired
	private HibernateDao hibernateDao;	

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> validateOriginalDocumentNo(String originalDocumentNo, String entityName, String columnName) {

		if(originalDocumentNo==null || originalDocumentNo.trim().isEmpty()){
			return null;
		}
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(InwardInvoiceModel.class);
		detachedCriteria.add(Restrictions.eq(columnName, originalDocumentNo));
//		detachedCriteria.add(Restrictions.isNotNull("tableType"));
		detachedCriteria.add(Restrictions.ne("itemStatus", Constant.BUS_RULE_ERROR));
//		detachedCriteria.add(Restrictions.eq("documentType", Constant.INV));
		detachedCriteria.add(Restrictions.in("tableType",new String[]{"B2B","B2BUR","IMPS","IMPG"}));
		return (List<T>) hibernateDao.find(detachedCriteria);
	}

	@Override
	public <T> List<T> validateOriginalDocumentNoInGSTN(String originalDocumentNo, String entityName, String columnName) {

		if(originalDocumentNo==null || originalDocumentNo.trim().isEmpty()){
			return null;
		}
		String queryStr = "select a FROM " + entityName + " a, GSTR2InvoiceKeyDetail b where a." + columnName + " = ? and b.isSuccessToGstn=1 and a.invoiceKey=b.invoiceKey";
		return (List<T>) hibernateDao.find(queryStr, originalDocumentNo);

	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> validateOriginalDocNoDocDate(String docNum, Date documentDate, String entityName, String column1,
			String column2) {

		if(docNum==null || docNum.trim().isEmpty() || documentDate == null){
			return null;
		}
		String queryStr = "FROM " + entityName + " e where e." + column1 + " = ? and e." + column2 + " = ?";
		return (List<T>) hibernateDao.find(queryStr, docNum, documentDate);
	}


	@Override
	public List<String> getGSTINListByPAN(String entityName, String custGSTINColumn, String gstinColumn,
			String invNumColumn, String invDateColumn, String custGSTIN, String PAN, String gstin, String invNum, Date invDate) {
		String queryStr = "Select e." + custGSTINColumn + " FROM " + entityName + " e WHERE e." + invNumColumn + " = ? AND e." 
				+ invDateColumn + " = ? AND e." + custGSTINColumn + " != ? AND e." + custGSTINColumn + " like ? AND e." + gstinColumn + " = ?" ;

		return (List<String>) hibernateDao.find(queryStr, invNum, invDate, custGSTIN, "%"+PAN+"%", gstin);

	}


	@Override
	public Gstr2B2BInvoiceDetailsModel getReconInvoice(String entityName, String custGSTIN, String gstin, String invNum, Date invDate) {
		Session session = null;
		Gstr2B2BInvoiceDetailsModel model = null;
		try{
		session = hibernateDao.getSession();

		String queryStr = "FROM " + entityName + " e where e.cust_GSTIN = :custGSTIN and e.gstin = :gstin and e.doc_Num = :invNum and e.doc_Date = :invDate";
		Query query = session.createQuery(queryStr);
		query.setParameter("custGSTIN", custGSTIN);
		query.setParameter("gstin", gstin);
		query.setParameter("invNum", invNum);
		query.setParameter("invDate", invDate);
		model = (Gstr2B2BInvoiceDetailsModel) query.uniqueResult();
		}catch(Exception e){
			log.error(e);
		}finally{
			if(session != null  && session.isOpen()){
				session.close();
			}
		}
		return model;
	}

	@Override
	public void updateReconFilingStatus(Object model) {
		try{
			hibernateDao.saveOrUpdate(model);
		}catch(Exception e){
			log.error("Error Saving recon Invoice", e);
		}

	}

	@Override
	public void updateITCValues(Set<LineItemDTO> redisLineItemSet) {
		Session session = hibernateDao.getSession();
		Iterator<LineItemDTO> invoiceIterator=redisLineItemSet.iterator();
		try{
			while(invoiceIterator.hasNext()){
				LineItemDTO lineItemDto = invoiceIterator.next();
				switch (lineItemDto.getTableType()) {
				case Constant.B2B:
					executeITCUpdate(session, "Gstr2B2BItemDetailsModel","gstr2B2BItemDetailsPK",
							lineItemDto);
					break;
				case Constant.B2BA:
					executeITCUpdate(session, "Gstr2B2BAItemDetailsModel","gstr2B2BAItemDetailsPK",
							lineItemDto);
					break;

				case Constant.CDN:
					executeCDNITCUpdate(session, "GSTR2FCDN_InvoiceDetail",
							lineItemDto);
					break;
				case Constant.CDNA:
					executeCDNITCUpdate(session, "GSTR2FCDNA_InvoiceDetail",
							lineItemDto);
					break;
				default:
					break;

				}
			}
		}catch(Exception e){
			log.error("Error Updating ITC values ", e);
		}finally {
			if(session != null  && session.isOpen()){
				session.close();
			}
		}

	}

	private void executeITCUpdate(Session session, String entity, String primarykey, LineItemDTO lineItemDto){
		String queryStr = "update " +  entity + " e set e.itcIgstAmt = :ItcIgstAmt, e.itcSgstAmt = :ItcSgstAmt, e.itcCgstAmt = :ItcCgstAmt, e.itcCessAmt = :ItcCessAmt where e.gstr2B2BItemDetailsPK.lineNo = :lineNo and e."+primarykey+".invoiceDetails.invoiceDetailsId = :Id ";
		Query query =	session.createQuery(queryStr);
		query.setParameter("ItcIgstAmt", lineItemDto.getItcIgstAmt());
		query.setParameter("ItcSgstAmt", lineItemDto.getItcSgstAmt());
		query.setParameter("ItcCgstAmt", lineItemDto.getItcCgstAmt());
		query.setParameter("ItcCessAmt", lineItemDto.getItcCessAmt());
		query.setParameter("Id", lineItemDto.getId());
		query.setParameter("lineNo", lineItemDto.getLineNo());
		query.executeUpdate();
	}

	private void executeCDNITCUpdate(Session session, String entity, LineItemDTO lineItemDto){
		String queryStr = "update " +  entity + " e set e.itcIgstAmt = :ItcIgstAmt, e.itcSgstAmt = :ItcSgstAmt, e.itcCgstAmt = :ItcCgstAmt, e.itcCessAmt = :ItcCessAmt where e.id = :Id ";
		Query query =	session.createQuery(queryStr);
		query.setParameter("ItcIgstAmt", lineItemDto.getItcIgstAmt());
		query.setParameter("ItcSgstAmt", lineItemDto.getItcSgstAmt());
		query.setParameter("ItcCgstAmt", lineItemDto.getItcCgstAmt());
		query.setParameter("ItcCessAmt", lineItemDto.getItcCessAmt());
		query.setParameter("Id", lineItemDto.getId());
		query.executeUpdate();

	}

	@Override
	public <T> T getReconInvoice(String entityName, String custGSTINColumn, String gstinColumn, String invNumColumn,
			String invDateColumn, String custGSTIN, String gstin, String invNum, Date invDate) {
		T reconInvoice = null;
		Session session = null;
		try{
			String queryStr = "FROM " + entityName + " e WHERE e." + invNumColumn + " = ? AND e." 
					+ invDateColumn + " = ? AND e." + custGSTINColumn + " = ? AND e." + gstinColumn + " = ?" ;

			session = hibernateDao.getSession();

			Query query = session.createQuery(queryStr);
			query.setParameter(0, invNum);
			query.setParameter(1, invDate);
			query.setParameter(2, custGSTIN);
			query.setParameter(3, gstin);
			reconInvoice = (T) query.uniqueResult();

		}catch(Exception e){
			log.error("Error Getting Recon Invoice", e);
		}finally {
			if(session != null  && session.isOpen()){
				session.close();
			}
		}

		return reconInvoice;
	}

	@Override
	public <T> T getReconInvoice(String entityName, String invoiceIdColumn, Long invoiceDetailsId) {
		T reconInvoice = null;
		Session session = null;
		try{
			String queryStr = "FROM " + entityName + " e WHERE e." + invoiceIdColumn + " = :invoiceId";

			session = hibernateDao.getSession();
			Query query = session.createQuery(queryStr);
			query.setParameter("invoiceId", invoiceDetailsId);
			reconInvoice = (T) query.uniqueResult();
		}catch(Exception e){
			log.error("Error Getting Recon Invoice", e);
		}finally {
			if(session != null  && session.isOpen()){
				session.close();
			}
		}
		return reconInvoice;
	}

	@Override
	public ItemMaster fetchHsnSacDetails(String hsnSac) {

		if(hsnSac==null || hsnSac.isEmpty()) {
			return null;
		}
		DetachedCriteria criteria= hibernateDao.createCriteria(ItemMaster.class);

		criteria.add(Restrictions.eq("hsn", hsnSac));
		List<ItemMaster> itemregHsn = (List<ItemMaster>) hibernateDao.find(criteria);

		if(itemregHsn!=null && (!itemregHsn.isEmpty())){
			return itemregHsn.get(0);
		}
		return null;
	}

	@Override
	public GlobalGSTRatesMasterI fetchHsnSacDetailsFromGlobal(String hsnSac) {
		
		if(hsnSac==null || hsnSac.isEmpty()) {
			return null;
		}
		DetachedCriteria criteria= hibernateDao.createCriteria(GlobalGSTRatesMasterI.class);
		criteria.add(Restrictions.eq("hsn_sac", hsnSac));
		List<GlobalGSTRatesMasterI> globalregHsn = (List<GlobalGSTRatesMasterI>) hibernateDao.find(criteria);
		
		if(globalregHsn!=null && (!globalregHsn.isEmpty())){
			return globalregHsn.get(0);
		}
		return null;
	}

	@Override
	public boolean isInvoiceNotPresentInGSTN(String invoiceKey) {
		String queryStr = "FROM GSTR2InvoiceKeyDetail e where e.invoiceKey = ? and e.isSuccessToGstn=1";

		return hibernateDao.find(queryStr, invoiceKey).isEmpty();
	}

	@Override
	public List<GSTR2B2BCLIAInvoiceDetails> getCreditListForInvoice(String originalDocumentNo,
			Date originalDocumentDate) {
		//String queryStr = "select a FROM GSTR2B2BCLIAInvoiceDetails a, InvoiceKeyDetail b where a.orgInvNum = ? and a.orgInvDate = ? and a.category = ? and b.isSuccessToGstn=1 and a.invoiceKey=b.invoiceKey";
		//return (List<GSTR2B2BCLIAInvoiceDetails>) hibernateDao.find(queryStr, originalDocumentNo, originalDocumentDate, Constant.CR);
		List<GSTR2B2BCLIAInvoiceDetails> creditList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR2B2BCLIAInvoiceDetails.class);
			detachedCriteria.add(Restrictions.eq("orgInvNum", originalDocumentNo));
			detachedCriteria.add(Restrictions.eq("orgInvDate", originalDocumentDate));
			detachedCriteria.add(Restrictions.eq("category", Constant.CR));
			creditList = (List<GSTR2B2BCLIAInvoiceDetails>) hibernateDao.find(detachedCriteria);
		}catch(Exception e){
			log.error("Error fetching Credit List for Invoice" + originalDocumentNo, e);
		}

		return creditList;

	}

	@Override
	public List<GSTR2B2BCLIAInvoiceDetails> getRevisedCreditList(GSTR2B2BCLIAInvoiceDetails credit) {
		/*String queryStr = "select a FROM GSTR2B2BCLIAInvoiceDetails a, InvoiceKeyDetail b where a.orgInvNum = ? and a.orgInvDate = ? and a.category = ? and b.isSuccessToGstn=1 and a.invoiceKey=b.invoiceKey";
		return (List<GSTR2B2BCLIAInvoiceDetails>) hibernateDao.find(queryStr, credit.getInvNum(), credit.getInvDate(), Constant.RCR);*/
		List<GSTR2B2BCLIAInvoiceDetails> revisedCreditList = null;
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR2B2BCLIAInvoiceDetails.class);
			detachedCriteria.add(Restrictions.eq("orgInvNum", credit.getInvNum()));
			detachedCriteria.add(Restrictions.eq("orgInvDate", credit.getInvDate()));
			detachedCriteria.add(Restrictions.eq("category", Constant.RCR));
			revisedCreditList = (List<GSTR2B2BCLIAInvoiceDetails>) hibernateDao.find(detachedCriteria);

		}catch(Exception e){
			log.error("Error fetching revised Credit List for credit" + credit.getInvNum(), e);
		}
		return revisedCreditList;
	}

	@Override
	public boolean isSingleInvoiceForCRDR(InwardInvoiceModel lineItem) {
		String queryStr = "select a FROM GSTR2B2BCLIAInvoiceDetails a, GSTR2InvoiceKeyDetail b "
				+ "where a.orgInvNum <> ? and a.invNum = ? and (a.category = ? or a.category = ?) and b.isSuccessToGstn=1 and a.invoiceKey=b.invoiceKey";
		return hibernateDao.find(queryStr, lineItem.getOriginalDocumentNo(), lineItem.getDocumentNo(), Constant.CR, Constant.DR).isEmpty();
	}

	@Override
	public String getITCComputationXML(String taxPeriod, String gstins) {
		try {
			Object[] obj = new Object[2];
			obj[0] = taxPeriod;
			obj[1] = gstins;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGetITCReversalDetermination ?,?",obj);
			if(result!=null && !result.isEmpty()){
				String xmlContent= (String) result.get(0);
				log.info("ITCReversalDeterminationXML= "+ xmlContent);
				return xmlContent;
			}
			log.info("ITCReversalDeterminationXML= "+ null);
		} catch (Exception e) {
			log.info(Constant.LOGGER_ERROR +" Method : getITCCompudationXML", e);
		}
		return null;
	}

	@Override
	public String getITCReversalXML(String taxPeriod, String gstins) {
		try {
			Object[] obj = new Object[2];
			obj[0] = taxPeriod;
			obj[1] = gstins;

			List<?> result = hibernateDao.executeNativeSql("exec dbo.uspGstr2ItcCreditSummary ?,?",obj);
			if(result!=null && !result.isEmpty()){
				String xmlContent= (String) result.get(0);
				log.info("ITCReversalXML= "+ xmlContent);
				return xmlContent;
			}
			log.info("ITCReversalXML= "+ null);
		} catch (Exception e) {
			log.info(Constant.LOGGER_ERROR +" Method : getITCCompudationXML", e);
		}
		return null;
	}

	@Override
	public GlCodeMaster getGLMasterByCode(String glCode) {
		GlCodeMaster glCodeMaster = null;

		DetachedCriteria criteria = hibernateDao.createCriteria(GlCodeMaster.class);
		criteria.add(Restrictions.eq("glCode", glCode));

		List<GlCodeMaster> masterList = (List<GlCodeMaster>) hibernateDao.find(criteria);
		if(masterList!= null && !masterList.isEmpty()){
			glCodeMaster = masterList.get(0);
		}

		return glCodeMaster;
	}

	@Override
	public void updateReconTaxLiability(String entityName, ReconProcessDTO processDTO) {
		Session session = null;
		try{
			session = hibernateDao.getSession();
			String queryStr = "update " +  entityName + " e set e.itemTxVal = :itemTxVal, e.igstAmt = :igstAmt, e.cgstAmt = :cgstAmt, e.sgstAmt = :sgstAmt, e.cessAmt = :cessAmt where  e.id = :id ";
			Query query = session.createQuery(queryStr);
			query.setParameter("itemTxVal", processDTO.getItemTxVal());
			query.setParameter("igstAmt", processDTO.getIgstAmt());
			query.setParameter("cgstAmt", processDTO.getCgstAmt());
			query.setParameter("sgstAmt", processDTO.getSgstAmt());
			query.setParameter("cessAmt", processDTO.getCessAmt());
			query.executeUpdate();
		}catch(Exception e){
			log.info(Constant.LOGGER_ERROR +" Method : updateReconTaxLiability", e);
		}finally{
			if(session != null){
				session.close();
			}
		}
		
	}

	@Override
	public void updateReconResult(Integer id, String reconFilingStatus) {
		Session session = null;
		try{
			session = hibernateDao.getSession();
			String queryStr = "update GSTR2FReconResult e set e.suggestedResponse = :suggestedResponse where  e.reconStatusID = :reconStatusID ";
			Query query = session.createQuery(queryStr);
			query.setParameter("suggestedResponse", reconFilingStatus);
			query.setParameter("reconStatusID", id);
			query.executeUpdate();
		}catch(Exception e){
			log.info(Constant.LOGGER_ERROR +" Method : updateReconTaxLiability", e);
		}finally{
			if(session != null){
				session.close();
			}
		}
		
	}

	@Override
	public void updateReconStatus(Integer id, String reconStatus) {
		Session session = null;
		try{
			session = hibernateDao.getSession();
			String queryStr = "update ReconStatus e set e.reconStatus = :reconStatus where  e.masterId = :masterId ";
			Query query = session.createQuery(queryStr);
			query.setParameter("reconStatus", reconStatus);
			query.setParameter("masterId", id);
			query.executeUpdate();
		}catch(Exception e){
			log.info(Constant.LOGGER_ERROR +" Method : updateReconTaxLiability", e);
		}finally{
			if(session != null){
				session.close();
			}
		}
		
	}

}
