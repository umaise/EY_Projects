package com.ey.advisory.asp.client.service;

import java.util.List;

import com.ey.advisory.asp.client.domain.TblGSTR2ItcReversal;

public interface GSTR2ItcReversalService {
	
	List<TblGSTR2ItcReversal> fetchAll();
	Long getTotalRecordCount(Long fileId);
	List<TblGSTR2ItcReversal> fetchTotalRecords(Long fileId, int firstResult, int pageSize);

}
