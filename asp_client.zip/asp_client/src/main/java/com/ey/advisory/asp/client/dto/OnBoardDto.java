package com.ey.advisory.asp.client.dto;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.client.domain.ClientCommunication;
import com.ey.advisory.asp.client.domain.CustomerMaster;
import com.ey.advisory.asp.client.domain.EntityEscalation;
import com.ey.advisory.asp.client.domain.EntityHierarchy;
import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.ProductMaster;
import com.ey.advisory.asp.client.domain.QuestionAnswerMapping;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.domain.UserClient;
import com.ey.advisory.asp.client.domain.VendorMaster;




public class OnBoardDto {
	
	private Integer draftId;
	private Long userID;
	private GroupDto clientGroup;
	private EntityModel clientEntity;
	private List<TblGstinDetailsDomain> clientGstinList;
	private List<EntityHierarchy> hierarchyList;
	private List<UserClient> clientUser;
	private List<ClientCommunication> communicationList;
	private List<EntityEscalation> escalationList;
	private List<ProductMaster> productMasterList;
    private List<ItemMaster> itemMasterList;
    private List<CustomerMaster> customerMasterList;
    private List<VendorMaster> vendorMasterList;
    private List<QuestionAnswerMapping> questionAnswerList;
    private Map<String,Long> userIdL1Map;
    
   	public Map<String, Long> getUserIdL1Map() {
   		return userIdL1Map;
   	}
   	public void setUserIdL1Map(Map<String, Long> userIdL1Map) {
   		this.userIdL1Map = userIdL1Map;
   	}
    
    
    public Integer getDraftId() {
		return draftId;
	}
	public void setDraftId(Integer draftId) {
		this.draftId = draftId;
	}
	public Long getUserID() {
		return userID;
	}
	public void setUserID(Long userID) {
		this.userID = userID;
	}
	public List<ProductMaster> getProductMasterList() {
        return productMasterList;
    }
    public void setProductMasterList(List<ProductMaster> productMasterList) {
        this.productMasterList = productMasterList;
    }
    public List<ItemMaster> getItemMasterList() {
        return itemMasterList;
    }
    public void setItemMasterList(List<ItemMaster> itemMasterList) {
        this.itemMasterList = itemMasterList;
    }
    public List<CustomerMaster> getCustomerMasterList() {
        return customerMasterList;
    }
    public void setCustomerMasterList(List<CustomerMaster> customerMasterList) {
        this.customerMasterList = customerMasterList;
    }
    public List<VendorMaster> getVendorMasterList() {
        return vendorMasterList;
    }
    public void setVendorMasterList(List<VendorMaster> vendorMasterList) {
        this.vendorMasterList = vendorMasterList;
    }
    public List<QuestionAnswerMapping> getQuestionAnswerList() {
        return questionAnswerList;
    }
    public void setQuestionAnswerList(List<QuestionAnswerMapping> questionAnswerList) {
        this.questionAnswerList = questionAnswerList;
    }
	
	
	public EntityModel getClientEntity() {
		return clientEntity;
	}
	public void setClientEntity(EntityModel clientEntity) {
		this.clientEntity = clientEntity;
	}
	public List<TblGstinDetailsDomain> getClientGstinList() {
		return clientGstinList;
	}
	public void setClientGstinList(List<TblGstinDetailsDomain> clientGstinList) {
		this.clientGstinList = clientGstinList;
	}
	public List<EntityHierarchy> getHierarchyList() {
		return hierarchyList;
	}
	public void setHierarchyList(List<EntityHierarchy> hierarchyList) {
		this.hierarchyList = hierarchyList;
	}
	
	public List<UserClient> getClientUser() {
		return clientUser;
	}
	public void setClientUser(List<UserClient> clientUser) {
		this.clientUser = clientUser;
	}
	public List<ClientCommunication> getCommunicationList() {
		return communicationList;
	}
	public void setCommunicationList(List<ClientCommunication> communicationList) {
		this.communicationList = communicationList;
	}
	public GroupDto getClientGroup() {
		return clientGroup;
	}
	public void setClientGroup(GroupDto clientGroup) {
		this.clientGroup = clientGroup;
	}
	public List<EntityEscalation> getEscalationList() {
		return escalationList;
	}
	public void setEscalationList(List<EntityEscalation> escalationList) {
		this.escalationList = escalationList;
	}
	
	
	

}
