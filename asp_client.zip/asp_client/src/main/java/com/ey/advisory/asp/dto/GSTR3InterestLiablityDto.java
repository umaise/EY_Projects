package com.ey.advisory.asp.dto;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GSTR3InterestLiablityDto {
	
	
	private String gstin;
	private String taxPeriod;
	
	GSTR3IntrLiabDto intr_liab;
	
	@JsonProperty("gstin")
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	
	@JsonProperty("taxPeriod")
	public String getTaxPeriod() {
		return taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	
	@JsonProperty("intr_liab")
	public GSTR3IntrLiabDto getIntr_liab() {
		return intr_liab;
	}
	public void setIntr_liab(GSTR3IntrLiabDto intr_liab) {
		this.intr_liab = intr_liab;
	}

}
