package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

public class ReconStatusKey implements Serializable {
	   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String gstin;
	private String taxPeriod;
	private String type;
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	}
	