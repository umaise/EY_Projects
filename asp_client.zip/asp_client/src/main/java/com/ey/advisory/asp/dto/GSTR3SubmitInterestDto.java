package com.ey.advisory.asp.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GSTR3SubmitInterestDto {

	GSTR3IntrLiabDto intr_liab;

	@JsonProperty("intr_liab")
	public GSTR3IntrLiabDto getIntr_liab() {
		return intr_liab;
	}

	public void setIntr_liab(GSTR3IntrLiabDto intr_liab) {
		this.intr_liab = intr_liab;
	}

}
