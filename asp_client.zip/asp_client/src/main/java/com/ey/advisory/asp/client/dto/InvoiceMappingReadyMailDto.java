package com.ey.advisory.asp.client.dto;

import java.util.List;

public class InvoiceMappingReadyMailDto {
	
	public List<String> mailList;
	
	public String returnType;
	
	public String gstin;

	public List<String> getMailList() {
		return mailList;
	}

	public void setMailList(List<String> mailList) {
		this.mailList = mailList;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

}
