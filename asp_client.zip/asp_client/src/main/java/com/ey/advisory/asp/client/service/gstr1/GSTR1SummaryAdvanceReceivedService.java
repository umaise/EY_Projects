package com.ey.advisory.asp.client.service.gstr1;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR1SummaryAdvanceReceived;

@FunctionalInterface
public interface GSTR1SummaryAdvanceReceivedService {

	public List<GSTR1SummaryAdvanceReceived> getAdvanceReceivedMetadata(); 
}
