package com.ey.advisory.asp.client.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class EntityModelDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	private String pan;
	private BigDecimal grossTurnOver;
	
	public EntityModelDTO(String pan, BigDecimal grossTurnOver) {

		this.pan = pan;
		this.grossTurnOver = grossTurnOver;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public BigDecimal getGrossTurnOver() {
		return grossTurnOver;
	}
	public void setGrossTurnOver(BigDecimal grossTurnOver) {
		this.grossTurnOver = grossTurnOver;
	}
	
}
