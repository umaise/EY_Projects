package com.ey.advisory.asp.client.service.gstr2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR2FB2B_InvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR2FCDNA_InvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR2FCDN_InvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR2InvoiceKeyDetail;
import com.ey.advisory.asp.client.domain.Gstr2B2BInvoiceDetailsModel;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.common.Constant;

@Service
public class Gstr2ReconDetailsServiceImpl implements Gstr2ReconDetailsService {

    @Autowired
    private HibernateDao hibernateDao;

    private static final Logger logger = Logger.getLogger(Gstr2ReconDetailsServiceImpl.class);
    
    @SuppressWarnings("unchecked")
    @Override
	public List<String> getGstnListForFileId(List<Integer> fileIdList) {
    	
    	List<String> gstinList = null;
    	
    	 try {
             DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR2InvoiceKeyDetail.class);
             detachedCriteria.add(Restrictions.in("fileId", fileIdList))
             .setProjection(Projections.distinct(Projections.property("gstin")));             
             gstinList = (List<String>) hibernateDao.find(detachedCriteria);
         }
         catch (Exception exe) {
             logger.error(Constant.LOGGER_ERROR + GSTR2InvoiceKeyDetail.class.getName()
                 + " Method : getGstnListForFileId()" ,exe);
         }
    	
    	return gstinList;
    	
    }
    

    @SuppressWarnings("unchecked")
    @Override
    public List<Gstr2B2BInvoiceDetailsModel> getGstr2B2BInvoiceDetails(String gstin, String taxPeriod) {
        List<Gstr2B2BInvoiceDetailsModel> gstr2B2BInvoiceDetailsModelList = new ArrayList<>();
        try {
            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(Gstr2B2BInvoiceDetailsModel.class);
            detachedCriteria.add(Restrictions.eq("isAccepted", 0));
            detachedCriteria.add(Restrictions.eq("gstin", gstin));
            detachedCriteria.add(Restrictions.eq("taxPeriod", taxPeriod));
            detachedCriteria.addOrder(Order.asc("doc_Num"));
            detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
            gstr2B2BInvoiceDetailsModelList = (List<Gstr2B2BInvoiceDetailsModel>) hibernateDao.find(detachedCriteria);
        }
        catch (Exception exe) {
            logger.error(Constant.LOGGER_ERROR + Gstr2B2BInvoiceDetailsModel.class.getName()
                + " Method : getInvoiceDetails()" ,exe);
        }
        return gstr2B2BInvoiceDetailsModelList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GSTR2FCDNA_InvoiceDetail> getCDNADetails(String gstin, String taxPeriod) {
        List<GSTR2FCDNA_InvoiceDetail> gstr2FCDNADetailsModelList = new ArrayList<>();
        try {
            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR2FCDNA_InvoiceDetail.class);
            detachedCriteria.add(Restrictions.eq("isAccepted", 0));
            detachedCriteria.add(Restrictions.eq("gstin", gstin));
            detachedCriteria.add(Restrictions.eq("taxPeriod", taxPeriod));
            detachedCriteria.addOrder(Order.asc("doc_Num"));
            detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
            gstr2FCDNADetailsModelList = (List<GSTR2FCDNA_InvoiceDetail>) hibernateDao.find(detachedCriteria);
        }
        catch (Exception exe) {
            logger.error(Constant.LOGGER_ERROR + GSTR2FCDNA_InvoiceDetail.class.getName()
                + " Method : getCDNAInvoiceDetails()", exe);
        }
        return gstr2FCDNADetailsModelList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GSTR2FCDN_InvoiceDetail> getCDNDetails(String gstin, String taxPeriod) {
        List<GSTR2FCDN_InvoiceDetail> gstr2FCDNDetailsModelList = new ArrayList<>();
        try {
            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR2FCDN_InvoiceDetail.class);
            detachedCriteria.add(Restrictions.eq("isAccepted", 0));
            detachedCriteria.add(Restrictions.eq("gstin", gstin));
            detachedCriteria.add(Restrictions.eq("taxPeriod", taxPeriod));
            detachedCriteria.addOrder(Order.asc("doc_Num"));
            gstr2FCDNDetailsModelList = (List<GSTR2FCDN_InvoiceDetail>) hibernateDao.find(detachedCriteria);
        }
        catch (Exception exe) {
            logger.error(Constant.LOGGER_ERROR + GSTR2FCDN_InvoiceDetail.class.getName()
                + " Method : getCDNInvoiceDetails()" ,exe);
        }
        return gstr2FCDNDetailsModelList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GSTR2FB2B_InvoiceDetail> getGSTR2B2BAInvoiceDetails(String gstin, String taxPeriod) {
        List<GSTR2FB2B_InvoiceDetail> gstr2B2BInvoiceDetailsModelList = new ArrayList<>();
        try {
            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(GSTR2FB2B_InvoiceDetail.class);
            detachedCriteria.add(Restrictions.eq("isAccepted", 0));
            detachedCriteria.add(Restrictions.eq("gstin", gstin));
            detachedCriteria.add(Restrictions.eq("taxPeriod", taxPeriod));
            detachedCriteria.addOrder(Order.asc("doc_Num"));
            detachedCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
            gstr2B2BInvoiceDetailsModelList = (List<GSTR2FB2B_InvoiceDetail>) hibernateDao.find(detachedCriteria);
        }
        catch (Exception exe) {
            logger.error(Constant.LOGGER_ERROR + GSTR2FB2B_InvoiceDetail.class.getName()
                + " Method : getInvoiceDetails()" ,exe);
        }
        return gstr2B2BInvoiceDetailsModelList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> Map<String, Set<TblPurchaseErrorInfo>> getTblPurchaseErrorInfo(String gstin, String taxPeriod, Class<T> classType) {
        List<TblPurchaseErrorInfo> getTblPurchaseErrorInfoList = new ArrayList<>();
        Map<String, Set<TblPurchaseErrorInfo>> reconInfoMap = new HashMap<>();
        String invoiceNum = null;
        try {
            DetachedCriteria criteria1 = DetachedCriteria.forClass(classType)
                .setProjection(Property.forName("doc_Num")).add(Restrictions.eq("taxPeriod", taxPeriod));
            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblPurchaseErrorInfo.class)
                .add(Restrictions.and(Restrictions.eq("gstin", gstin), Restrictions.eq("processStatus", "RECON"),
                    Property.forName("invoiceNum").in(criteria1)));
            getTblPurchaseErrorInfoList = (List<TblPurchaseErrorInfo>) hibernateDao.find(detachedCriteria);
            Set<TblPurchaseErrorInfo> tblPurchaseInfoSet ;
            for (TblPurchaseErrorInfo tblPurchaseErrorInfo : getTblPurchaseErrorInfoList) {
                invoiceNum = tblPurchaseErrorInfo.getInvoiceNum();
                if (reconInfoMap.get(invoiceNum) == null) {
                    tblPurchaseInfoSet = new HashSet<>();
                    tblPurchaseInfoSet.add(tblPurchaseErrorInfo);
                    reconInfoMap.put(invoiceNum, tblPurchaseInfoSet);
                }
                else {
                    tblPurchaseInfoSet = reconInfoMap.get(invoiceNum);
                    tblPurchaseInfoSet.add(tblPurchaseErrorInfo);
                }
            }
        }
        catch (Exception exe) {
            logger.error(Constant.LOGGER_ERROR + Gstr2ReconDetailsServiceImpl.class.getName()
                + " Method : getTblPurchaseErrorInfo()" ,exe);
        }
        return reconInfoMap;
    }

    @SuppressWarnings("unchecked")
    @Override
    public long getMaxNoOfReconErrorCode(String gstin, String taxPeriod, String status, String mismatchStatus) {

        List<Long> countArray = new ArrayList<>();
        DetachedCriteria criteria1 = null;
        DetachedCriteria criteria2 = null;
        DetachedCriteria criteria3 = null;
        DetachedCriteria criteria4 = null;

        try {
            if (mismatchStatus != null) {
                criteria1 = DetachedCriteria.forClass(Gstr2B2BInvoiceDetailsModel.class)
                    .setProjection(Property.forName("doc_Num"))
                    .add(Restrictions.and(
                        Restrictions.or(Restrictions.eq("status", status), Restrictions.eq("status", mismatchStatus)),
                        Restrictions.eq("isAccepted", 0), Restrictions.eq("taxPeriod", taxPeriod)));
                criteria2 = DetachedCriteria.forClass(GSTR2FB2B_InvoiceDetail.class)
                    .setProjection(Property.forName("doc_Num"))
                    .add(Restrictions.and(
                        Restrictions.or(Restrictions.eq("status", status), Restrictions.eq("status", mismatchStatus)),
                        Restrictions.eq("isAccepted", 0), Restrictions.eq("taxPeriod", taxPeriod)));
                criteria3 = DetachedCriteria.forClass(GSTR2FCDN_InvoiceDetail.class)
                    .setProjection(Property.forName("doc_Num"))
                    .add(Restrictions.and(
                        Restrictions.or(Restrictions.eq("status", status), Restrictions.eq("status", mismatchStatus)),
                        Restrictions.eq("isAccepted", 0), Restrictions.eq("taxPeriod", taxPeriod)));
                criteria4 = DetachedCriteria.forClass(GSTR2FCDNA_InvoiceDetail.class)
                    .setProjection(Property.forName("doc_Num"))
                    .add(Restrictions.and(
                        Restrictions.or(Restrictions.eq("status", status), Restrictions.eq("status", mismatchStatus)),
                        Restrictions.eq("isAccepted", 0), Restrictions.eq("taxPeriod", taxPeriod)));
            }
            else {
                criteria1 = DetachedCriteria.forClass(Gstr2B2BInvoiceDetailsModel.class)
                    .setProjection(Property.forName("doc_Num")).add(Restrictions.and(Restrictions.eq("status", status),
                        Restrictions.eq("isAccepted", 0), Restrictions.eq("taxPeriod", taxPeriod)));
                criteria2 = DetachedCriteria.forClass(GSTR2FB2B_InvoiceDetail.class)
                    .setProjection(Property.forName("doc_Num")).add(Restrictions.and(Restrictions.eq("status", status),
                        Restrictions.eq("isAccepted", 0), Restrictions.eq("taxPeriod", taxPeriod)));
                criteria3 = DetachedCriteria.forClass(GSTR2FCDN_InvoiceDetail.class)
                    .setProjection(Property.forName("doc_Num")).add(Restrictions.and(Restrictions.eq("status", status),
                        Restrictions.eq("isAccepted", 0), Restrictions.eq("taxPeriod", taxPeriod)));
                criteria4 = DetachedCriteria.forClass(GSTR2FCDNA_InvoiceDetail.class)
                    .setProjection(Property.forName("doc_Num")).add(Restrictions.and(Restrictions.eq("status", status),
                        Restrictions.eq("isAccepted", 0), Restrictions.eq("taxPeriod", taxPeriod)));
            }

            ProjectionList projectionList = Projections.projectionList();
            projectionList.add(Projections.countDistinct("errorInfoCode").as("erroCount"));
            projectionList.add(Projections.groupProperty("invoiceNum"));
            projectionList.add(Projections.groupProperty("gstin"));

            DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblPurchaseErrorInfo.class)
                .setProjection(projectionList)
                .add(Restrictions.and(Restrictions.eq("gstin", gstin), Restrictions.eq("processStatus", "RECON"),
                    Restrictions.or(Property.forName("invoiceNum").in(criteria1),
                        Property.forName("invoiceNum").in(criteria2), Property.forName("invoiceNum").in(criteria3),
                        Property.forName("invoiceNum").in(criteria4))

            ));

            List<Object[]> errorCodeDetailsResult = (List<Object[]>) hibernateDao.find(detachedCriteria);
            if (errorCodeDetailsResult != null && !errorCodeDetailsResult.isEmpty()) {
                for (Object[] errorCodeDetail : errorCodeDetailsResult) {
                    countArray.add((Long) errorCodeDetail[0]);
                }
            }
        }
        catch (Exception exe) {
            logger.error(Constant.LOGGER_ERROR + Gstr2ReconDetailsServiceImpl.class.getName()
                + " Method : getTblPurchaseErrorInfo()" ,exe);
        }

        long maxNoOfError = 1l;
        if (!countArray.isEmpty())
            maxNoOfError = Collections.max(countArray);
        return maxNoOfError;
    }

}
