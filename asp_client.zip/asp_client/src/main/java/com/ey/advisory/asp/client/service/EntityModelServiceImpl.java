package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.EntityModelDao;
import com.ey.advisory.asp.client.domain.EntityModel;
import com.ey.advisory.asp.client.domain.TblDivision;
import com.ey.advisory.asp.client.dto.EntityModelDTO;
import com.ey.advisory.asp.client.dto.GroupDto;

@Service
public class EntityModelServiceImpl implements EntityModelService{

	@Autowired
	private EntityModelDao entityModelDao;
	
	@Override
	public EntityModel getEntityDetails(String entityId) {
		return entityModelDao.getEntityDetails(entityId);
	}
	
	@Override
	public List<EntityModel> fetchEntitiesByGroupId(String groupId){
		return entityModelDao.fetchEntitiesByGroupId(groupId);
	}

	@Override
	public List<TblDivision> fetchDivisionByEntityId(Integer entityId) {
		return entityModelDao.fetchDivisionByEntityId(entityId);
	}

	@Override
	public List<String> fetchGSTINIdByEntity(Integer entityID) {
		return entityModelDao.fetchGSTINIdByEntity(entityID);
	}

	@Override
	public JSONArray fetchDivAndGSTIn(String id, boolean flag) {
		return entityModelDao.fetchDivAndGSTIn(id, flag);
	}
	
	@Override
	public void saveUserInClientTables(JSONObject groupJson,int userID){
		entityModelDao.saveUserInClientTables(groupJson, userID);
	}

	@Override
	public JSONObject fetchClientSideUserTablesAsJson(int userId,List<GroupDto> groupIds) {
		return entityModelDao.fetchClientSideUserTablesAsJson(userId, groupIds);
	}

	@Override
	public void updateUserInClientTables(JSONObject groupJson, int userID) {
		 entityModelDao.updateUserInClientTables(groupJson, userID);
		
	}
	@Override
	public void deleteObject(JSONObject json) {
		entityModelDao.deleteObject(json);
	}
	
    @Override
	public Map<String, EntityModelDTO> getEntityDetails() {

		Map<String, EntityModelDTO> entityMap = null;

		List<EntityModel> entityData = entityModelDao
				.fetchEntityDetails();
		if (entityData != null) {
			entityMap = new HashMap<>();
			for (EntityModel entityModel : entityData) {
				entityMap.put(entityModel.getPan(), new EntityModelDTO(entityModel.getPan(), entityModel.getGrossTurnOver()));
			}
		}

		return entityMap;

	}

    @Override
	public String fetchEntityNameById(Integer entityID) {
		return entityModelDao.fetchEntityNameById(entityID);
	}
    
	@Override
	public List<EntityModel> getEntityDetails(ArrayList<Integer> entityId) {
		// TODO Auto-generated method stub
		return entityModelDao.getEntityDetails(entityId);
	}
	
	@Override
	public String isEntityExitsWithName(String entityName){
		String output = entityModelDao.isEntityExitsWithName(entityName);
		return output;
	}

	@Override
	public String saveEntityData(EntityModel entity) throws Exception {
		String output = entityModelDao.saveEntityData(entity);
		return output;
	}
}
