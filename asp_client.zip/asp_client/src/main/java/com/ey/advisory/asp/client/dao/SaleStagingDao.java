package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;

public interface SaleStagingDao {

	List<String> getLineItemList(String applicableState, String returnType,
			String fileId, String recordType, String datalevel);

	List<String> getDataCount(String applicableState, String returnType,
			String fileData, String isProccessed, String jobStatus,
			List<String> fileIds, String recordType, String groupCode);

	List<OutwardInvoiceModel> fetchProcessedRecords(Long fileId,int firstResult, int pageSize);

	List<OutwardInvoiceModel> fetchTotalRecords(Long fileId,int firstResult, int pageSize);

	List<OutwardInvoiceModel> fetchDupRecords(Long fileId,int firstResult, int pageSize);

	Long getTotalCount(Long fileId);

	Long getTotalProcessedCount(Long fileId);

	Long getTotalDupCount(Long fileId);
	
	public List<OutwardInvoiceModel> fetchErrorRecords(Long fileId,int firstResult, int pageSize);
	
	public Long getTotalErrorCount(Long fileId);

}
