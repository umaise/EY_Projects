package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.SmartReport;
import com.ey.advisory.asp.dto.DynamicSmartReportDto;

public interface SmartReportStatusDao {

	public List<SmartReport>  getSmartReportData(int offset,int pageSize);

	public void updateCancelStatus(String requestId, String fileCategory);

	public List<SmartReport> getSearchSmartReportData(String requestId, String fileCategory, int offset,
			int pageSize);

	public SmartReport getFileDetails(String requestId, String fileCategory);

}
