package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name = "tblTaxPaidData",schema=Constant.GSTR1_SCHEMA) 
public class GSTR1TaxPaidData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private long GSTR1TaxPaidDataID;	
	
	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="DocDate")
	private Date doc_Date;

	@Column(name="DocNum")
	private String doc_Num;

	@Column(name="Flag")
	private String flag;
	
	@Column(name="InvNum")
	private String inv_Num;
	
	@Column(name="ValIncTax")
	private String valIncTax;

	@Column(name="Taxablevalue")
	private Double taxableValue;
	
	@Column(name="CGSTAmt")
	private Double CGST_Amt;

	@Column(name="CGSTRt")
	private Double CGST_Rt;
	
	@Column(name="IGSTAmt")
	private Double IGST_Amt;

	@Column(name="IGSTRt")
	private Double IGST_Rt;
	
	@Column(name="SGSTAmt")
	private Double SGST_Amt;

	@Column(name="SGSTRt")
	private Double SGST_Rt;
	
	@Column(name="CessRt")
	private Double cessRt;
	
	@Column(name="CessAmt")
	private Double cessAmt;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="Gstin")
	private String gstin;
	
	@Column(name="FileId")
	private Long fileId;
	
	@Column(name="IsDelete")
	private Boolean isDelete;

	public long getGSTR1TaxPaidDataID() {
		return GSTR1TaxPaidDataID;
	}

	public void setGSTR1TaxPaidDataID(long gSTR1TaxPaidDataID) {
		GSTR1TaxPaidDataID = gSTR1TaxPaidDataID;
	}

	public String getChkSum() {
		return chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public Date getDoc_Date() {
		return doc_Date;
	}

	public void setDoc_Date(Date doc_Date) {
		this.doc_Date = doc_Date;
	}

	public String getDoc_Num() {
		return doc_Num;
	}

	public void setDoc_Num(String doc_Num) {
		this.doc_Num = doc_Num;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getInv_Num() {
		return inv_Num;
	}

	public void setInv_Num(String inv_Num) {
		this.inv_Num = inv_Num;
	}

	public String getValIncTax() {
		return valIncTax;
	}

	public void setValIncTax(String valIncTax) {
		this.valIncTax = valIncTax;
	}

	public Double getTaxableValue() {
		return taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public Double getCGST_Amt() {
		return CGST_Amt;
	}

	public void setCGST_Amt(Double cGST_Amt) {
		CGST_Amt = cGST_Amt;
	}

	public Double getCGST_Rt() {
		return CGST_Rt;
	}

	public void setCGST_Rt(Double cGST_Rt) {
		CGST_Rt = cGST_Rt;
	}

	public Double getIGST_Amt() {
		return IGST_Amt;
	}

	public void setIGST_Amt(Double iGST_Amt) {
		IGST_Amt = iGST_Amt;
	}

	public Double getIGST_Rt() {
		return IGST_Rt;
	}

	public void setIGST_Rt(Double iGST_Rt) {
		IGST_Rt = iGST_Rt;
	}

	public Double getSGST_Amt() {
		return SGST_Amt;
	}

	public void setSGST_Amt(Double sGST_Amt) {
		SGST_Amt = sGST_Amt;
	}

	public Double getSGST_Rt() {
		return SGST_Rt;
	}

	public void setSGST_Rt(Double sGST_Rt) {
		SGST_Rt = sGST_Rt;
	}

	public Double getCessRt() {
		return cessRt;
	}

	public void setCessRt(Double cessRt) {
		this.cessRt = cessRt;
	}

	public Double getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Boolean getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Boolean isDelete) {
		this.isDelete = isDelete;
	}

}
