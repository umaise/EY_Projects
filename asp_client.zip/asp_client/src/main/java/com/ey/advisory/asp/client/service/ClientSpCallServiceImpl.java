package com.ey.advisory.asp.client.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.dao.TblGSTINSummaryListDao;

/**
 * @author Smruti.Pradhan
 *
 */
@Service
@Transactional
public class ClientSpCallServiceImpl implements ClientSpCallService{

	@Autowired
	HibernateDao hibernateDao;
	@Autowired
	ReturnFilingDao returnFilingDao;
	
	@Autowired
	TblGSTINSummaryListDao tblGSTINSummaryListDao;
	
	 
	
	@Override
	public String executeStoredProcedure(String storedProcSchema,
			String storedProcName, String inputParamsCount,
			List<String> inputParamsList) throws Exception {
		return hibernateDao.executeStoredProcedure(storedProcSchema, storedProcName, inputParamsCount, inputParamsList);
	}
	
	@Override
	public List executeStoredProcedureReturnList(String storedProcSchema,
			String storedProcName, String inputParamsCount,
			List<String> inputParamsList) throws Exception {
		return hibernateDao.executeStoredProcedureReturnList(storedProcSchema, storedProcName, inputParamsCount, inputParamsList);
	}
	

	
	
	
}
