/**
 * 
 */
package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Nitesh.Tripathi
 *
 */

@Entity
@Table(name = "tblGroup", schema = "master")
public class ClientGroupDomain implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="GroupID")
	private Long groupID;
	
	@Column(name="groupName")
	private String GroupName;
	
	@Column(name="pANCount")
	private Integer PANCount;
	
	@Column(name="tINCount")
	private Integer TINCount;
	
	@Column(name="isActive")
	private Boolean IsActive;
	
	@Column(name="createdBy")
	private String CreatedBy;
	
	@Column(name="createdDate")
	private Date CreatedDate;
	
	@Column(name="updatedBy")
	private String UpdatedBy;
	
	@Column(name="updatedDate")
	private Date UpdatedDate;
	
	@Column(name="account")
	private String Account;
	
	@Column(name="groupCode")
	private String GroupCode;
	
	@Column(name="pBIRefreshedAt")
	private Date PBIRefreshedAt;
	
	@Column(name="updatedDt")
	private Date UpdatedDt;
	
	@Column(name="createdDt")
	private Date CreatedDt;
	
	@Column(name="eyGrpCode")
	private String EyGrpCode;

	/**
	 * @return the groupID
	 */
	public Long getGroupID() {
		return groupID;
	}

	/**
	 * @param groupID the groupID to set
	 */
	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return GroupName;
	}

	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		GroupName = groupName;
	}

	/**
	 * @return the pANCount
	 */
	public Integer getPANCount() {
		return PANCount;
	}

	/**
	 * @param pANCount the pANCount to set
	 */
	public void setPANCount(Integer pANCount) {
		PANCount = pANCount;
	}

	/**
	 * @return the tINCount
	 */
	public Integer getTINCount() {
		return TINCount;
	}

	/**
	 * @param tINCount the tINCount to set
	 */
	public void setTINCount(Integer tINCount) {
		TINCount = tINCount;
	}

	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return IsActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		IsActive = isActive;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return CreatedBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return CreatedDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		CreatedDate = createdDate;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return UpdatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		UpdatedBy = updatedBy;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return UpdatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		UpdatedDate = updatedDate;
	}

	/**
	 * @return the account
	 */
	public String getAccount() {
		return Account;
	}

	/**
	 * @param account the account to set
	 */
	public void setAccount(String account) {
		Account = account;
	}

	/**
	 * @return the groupCode
	 */
	public String getGroupCode() {
		return GroupCode;
	}

	/**
	 * @param groupCode the groupCode to set
	 */
	public void setGroupCode(String groupCode) {
		GroupCode = groupCode;
	}

	/**
	 * @return the pBIRefreshedAt
	 */
	public Date getPBIRefreshedAt() {
		return PBIRefreshedAt;
	}

	/**
	 * @param pBIRefreshedAt the pBIRefreshedAt to set
	 */
	public void setPBIRefreshedAt(Date pBIRefreshedAt) {
		PBIRefreshedAt = pBIRefreshedAt;
	}

	/**
	 * @return the updatedDt
	 */
	public Date getUpdatedDt() {
		return UpdatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		UpdatedDt = updatedDt;
	}

	/**
	 * @return the createdDt
	 */
	public Date getCreatedDt() {
		return CreatedDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		CreatedDt = createdDt;
	}

	/**
	 * @return the eyGrpCode
	 */
	public String getEyGrpCode() {
		return EyGrpCode;
	}

	/**
	 * @param eyGrpCode the eyGrpCode to set
	 */
	public void setEyGrpCode(String eyGrpCode) {
		EyGrpCode = eyGrpCode;
	}

}
