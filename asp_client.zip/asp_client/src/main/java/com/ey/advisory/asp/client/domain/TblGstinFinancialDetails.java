package com.ey.advisory.asp.client.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.ey.advisory.asp.common.Constant;

@Entity
@Table(name="tblGstinFinancialDetails" , schema="master")
public class TblGstinFinancialDetails  {

	
	public TblGstinFinancialDetails() {
		super();
	}
	
	public TblGstinFinancialDetails(String gstin, Double quarterTurnOvrAmt) {
		super();
		this.gstin = gstin;
		this.quarterTurnOvrAmt = quarterTurnOvrAmt;
		this.financialPeriod= Constant.GSTIN_FINANCIAL_PERIOD;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="GSTINFinDetailID")
	private Integer financialDetailId;
	
	@Column(name="GSTIN")
	private String gstin;
	
	@Column(name="TurnoverAmount")
	private Double quarterTurnOvrAmt;
	
	@Column(name="FinancialPeriod")
	private String financialPeriod;
	
	public Integer getFinancialDetailId() {
		return financialDetailId;
	}

	public void setFinancialDetailId(Integer financialDetailId) {
		this.financialDetailId = financialDetailId;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Double getQuarterTurnOvrAmt() {
		return quarterTurnOvrAmt;
	}

	public void setQuarterTurnOvrAmt(Double quarterTurnOvrAmt) {
		this.quarterTurnOvrAmt = quarterTurnOvrAmt;
	}

	public String getFinancialPeriod() {
		return financialPeriod;
	}

	public void setFinancialPeriod(String financialPeriod) {
		this.financialPeriod = financialPeriod;
	}

	@Override
	public String toString() {
		return "TblGstinFinancialDetails [financialDetailId="
				+ financialDetailId + ", gstin=" + gstin
				+ ", quarterTurnOvrAmt=" + quarterTurnOvrAmt
				+ ", financialPeriod=" + financialPeriod + "]";
	}

	
}
