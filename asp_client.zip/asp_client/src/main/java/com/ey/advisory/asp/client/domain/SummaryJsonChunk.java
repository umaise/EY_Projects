package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * This entity class is to map the tblSummaryJsonChunk table with
 * SummaryJsonChunk object.
 * 
 * @author Prakash.Naik
 *
 */
@Entity
@Table(name = "tblSummaryJsonChunk", schema = "trans")
public class SummaryJsonChunk implements Serializable{
	
	private static final long serialVersionUID = 7273022110326917759L;

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "SummaryJsonChunkID")
	private int summaryJsonChunkID;

	@Column(name = "SummaryFileID")
	private int summaryFileID;

	@Column(name = "ChunkSeries")
	private String chunkSeries;

	@Column(name = "StatusOfChunk")
	private String statusOfChunk;

	@Column(name = "IsActive")
	private Boolean isActive;

	@Column(name = "CreatedDate")
	private Date CreatedDate;

	@Column(name = "UpdatedDate")
	private Date UpdatedDate;

	@Column(name = "UpdatedBy")
	private String updatedBy;
	
	@Column(name = "CreatedBy")
	private String createdBy;
	

	public int getSummaryJsonChunkID() {
		return summaryJsonChunkID;
	}

	public void setSummaryJsonChunkID(int summaryJsonChunkID) {
		this.summaryJsonChunkID = summaryJsonChunkID;
	}

	public int getSummaryFileID() {
		return summaryFileID;
	}

	public void setSummaryFileID(int summaryFileID) {
		this.summaryFileID = summaryFileID;
	}

	

	public String getStatusOfChunk() {
		return statusOfChunk;
	}

	public void setStatusOfChunk(String statusOfChunk) {
		this.statusOfChunk = statusOfChunk;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	
	/**
	 * @return the chunkSeries
	 */
	public String getChunkSeries() {
		return chunkSeries;
	}

	/**
	 * @param chunkSeries the chunkSeries to set
	 */
	public void setChunkSeries(String chunkSeries) {
		this.chunkSeries = chunkSeries;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return CreatedDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		CreatedDate = createdDate;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return UpdatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		UpdatedDate = updatedDate;
	}

}
