package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.Length;

import com.ey.advisory.asp.common.Constant;
import com.google.gson.annotations.SerializedName;

/**
 * The persistent class for the tblITCDInvoiceDetails database table.
 * @author  Nilanjan Karmakar
 * @version 1.0
 * @since   06-09-2017
 */
@Entity
@Table(name="tblITCDInvoiceDetails", schema=Constant.GSTR6_SCHEMA)



public class TblITCDInvoiceDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="ID")
    @SerializedName("ID")
    private int id;

    @Column(name="FileID")
    @SerializedName("FileID")
    private int fileID;

    @Column(name="SourceIdentifier")@Length(max = 25)
    @SerializedName("SourceIdentifier")
    private String sourceIdentifier;
    
    @Column(name="SourceFileName")@Length(max = 50)
    @SerializedName("SourceFileName")
    private String sourceFileName;
    
    @Column(name="GLAccountCode")@Length(max = 25)
    @SerializedName("GLAccountCode")
    private String gLAccountCode;
    
    @Column(name="Division")@Length(max = 20)
    @SerializedName("Division")
    private String division;

    @Column(name="SubDivision")@Length(max = 20)
    @SerializedName("SubDivision")
    private String subDivision;

    @Column(name="PlantCode")@Length(max = 20)
    @SerializedName("PlantCode")
    private String plantCode;

    @Column(name="TaxPeriod")
    @SerializedName("TaxPeriod")
    private String taxPeriod;

    @Column(name="DocumentType")@Length(max = 5)
    @SerializedName("DocumentType")
    private String documentType;

    @Column(name="SupplyType")@Length(max = 5)
    @SerializedName("SupplyType")
    private String supplyType;
    
    @Column(name="DocumentNo")@Length(max = 16)
    @SerializedName("DocumentNo")
    private String documentNo;
    
    @Temporal(TemporalType.DATE)
    @Column(name="DocumentDate")
    private Date documentDate;
    
    @Transient
    @SerializedName("DocumentDate")
    private String documentDateStr;

    @Column(name="SGSTIN")@Length(max = 15)
    @SerializedName("SGSTIN")
    private String SGSTIN;

    @Column(name="SupplierName")@Length(max = 40)
    @SerializedName("SupplierName")
    private String supplierName;

    @Column(name="POS")@Length(max = 2)
    @SerializedName("POS")
    private String pos;

    @Column(name="TaxableValue")
    @SerializedName("TaxableValue")
    private BigDecimal taxableValue;
    
    @Column(name="InvoiceValue")
    @SerializedName("InvoiceValue")
    private BigDecimal invoiceValue;

    @Column(name="InvoiceKey")
    @SerializedName("InvoiceKey")
    private String invoiceKey;

    @Column(name="SubCategory")
    @SerializedName("SubCategory")
    private String subCategory;
  	
	    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFileID() {
		return fileID;
	}

	public void setFileID(int fileID) {
		this.fileID = fileID;
	}

	public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getSubDivision() {
        return subDivision;
    }

    public void setSubDivision(String subDivision) {
        this.subDivision = subDivision;
    }

     public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getTaxPeriod() {
        return taxPeriod;
    }

    public void setTaxPeriod(String taxPeriod) {
        this.taxPeriod = taxPeriod;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getSupplyType() {
        return supplyType;
    }

    public void setSupplyType(String supplyType) {
        this.supplyType = supplyType;
    }

    public String getDocumentNo() {
        return documentNo;
    }

    public void setDocumentNo(String documentNo) {
        this.documentNo = documentNo;
    }

    public Date getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }

    public String getSGSTIN() {
        return SGSTIN;
    }

    public void setSGSTIN(String sGSTIN) {
        SGSTIN = sGSTIN;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getPos() {
        return pos;
    }

    public void setPos(String pos) {
        this.pos = pos;
    }

    public BigDecimal getTaxableValue() {
        return taxableValue;
    }

    public void setTaxableValue(BigDecimal taxableValue) {
        this.taxableValue = taxableValue;
    }

    public BigDecimal getInvoiceValue() {
        return invoiceValue;
    }

    public void setInvoiceValue(BigDecimal invoiceValue) {
        this.invoiceValue = invoiceValue;
    }

    public String getInvoiceKey() {
        return invoiceKey;
    }

    public void setInvoiceKey(String invoiceKey) {
        this.invoiceKey = invoiceKey;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public String getSourceFileName() {
        return sourceFileName;
    }

    public void setSourceFileName(String sourceFileName) {
        this.sourceFileName = sourceFileName;
    }

    public String getgLAccountCode() {
        return gLAccountCode;
    }

    public void setgLAccountCode(String gLAccountCode) {
        this.gLAccountCode = gLAccountCode;
    }

    public String getDocumentDateStr() {
		return documentDateStr;
	}

	public void setDocumentDateStr(String documentDateStr) {
		this.documentDateStr = documentDateStr;
	}
   
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TblITCDInvoiceDetails other = (TblITCDInvoiceDetails) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "tblCrDrITCAInvoiceDetails [id=" + id + ", fileID=" + fileID + ", sourceIdentifier=" + sourceIdentifier
				+ ", sourceFileName=" + sourceFileName + ", gLAccountCode=" + gLAccountCode + ", division=" + division
				+ ", subDivision=" + subDivision + ", plantCode=" + plantCode + ", taxPeriod=" + taxPeriod
				+ ", documentType=" + documentType + ", supplyType=" + supplyType + ", documentNo=" + documentNo
				+ ", documentDate=" + documentDate + ", documentDateStr=" + documentDateStr + ", SGSTIN=" + SGSTIN
				+ ", supplierName=" + supplierName + ", pos=" + pos + ", taxableValue=" + taxableValue
				+ ", invoiceValue=" + invoiceValue + ", invoiceKey=" + invoiceKey + ", subCategory=" + subCategory
				+ "]";
	}

	
	
	
}
