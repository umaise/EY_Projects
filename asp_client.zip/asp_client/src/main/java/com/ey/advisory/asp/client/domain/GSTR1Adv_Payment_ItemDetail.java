package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.ey.advisory.asp.common.Constant;


/**
 * The persistent class for the GSTR1Adv_Payment_ItemDetails database table.
 * 
 */
@Entity
@Table(name="tblAdvPaymentItemDetails", schema=Constant.GSTR1_SCHEMA)
public class GSTR1Adv_Payment_ItemDetail implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="AdvPaymentItemDetailsID")
	private Long id;
	
	@Column(name="CGSTAmt")
	private Double CGST_Amt;

	@Column(name="CGSTRt")
	private Double CGST_Rt;

	@Column(name="HSNSC")
	private String hsnSc;

	@Column(name="IGSTAmt")
	private Double IGST_Amt;

	@Column(name="IGSTRt")
	private Double IGST_Rate;

	@Column(name="ItemType")
	private String item_Type;
	
	@Column(name="ItemNo")
	private String item_No;

	@Column(name="SGSTAmt")
	private Double SGST_Amt;

	@Column(name="SGSTRt")
	private Double SGST_Rate;

	@Column(name="Taxablevalue")
	private Double taxableValue;

	@Column(name="ValIncTax")
	private Double val_Inc_Tax;
	
	@Column(name="CessRt")
	private Double cessRt;
	
	@Column(name="CessAmt")
	private Double cessAmt;

	@Column(name="AdvTaxPaymentID")
	private Long advTaxPaymentID;
	
	//bi-directional many-to-one association to GSTR1Adv_TaxPayment
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @JoinColumn(name = "AdvTaxPaymentID",referencedColumnName="ID", insertable=false,updatable=false )
	private GSTR1Adv_TaxPayment gstr1advTaxPayment;

	public Double getCGST_Amt() {
		return this.CGST_Amt;
	}

	public void setCGST_Amt(Double CGST_Amt) {
		this.CGST_Amt = CGST_Amt;
	}

	public String getHsnSc() {
		return this.hsnSc;
	}

	public void setHsnSc(String hsnSc) {
		this.hsnSc = hsnSc;
	}

	public Double getIGST_Amt() {
		return this.IGST_Amt;
	}

	public void setIGST_Amt(Double IGST_Amt) {
		this.IGST_Amt = IGST_Amt;
	}

	public Double getIGST_Rate() {
		return this.IGST_Rate;
	}

	public void setIGST_Rate(Double IGST_Rate) {
		this.IGST_Rate = IGST_Rate;
	}

	public String getItem_Type() {
		return this.item_Type;
	}

	public void setItem_Type(String item_Type) {
		this.item_Type = item_Type;
	}

	public Double getSGST_Amt() {
		return this.SGST_Amt;
	}

	public void setSGST_Amt(Double SGST_Amt) {
		this.SGST_Amt = SGST_Amt;
	}

	public Double getSGST_Rate() {
		return this.SGST_Rate;
	}

	public void setSGST_Rate(Double SGST_Rate) {
		this.SGST_Rate = SGST_Rate;
	}

	public Double getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public Double getVal_Inc_Tax() {
		return this.val_Inc_Tax;
	}

	public void setVal_Inc_Tax(Double val_Inc_Tax) {
		this.val_Inc_Tax = val_Inc_Tax;
	}

	public GSTR1Adv_TaxPayment getGstr1advTaxPayment() {
		return this.gstr1advTaxPayment;
	}

	public void setGstr1advTaxPayment(GSTR1Adv_TaxPayment gstr1advTaxPayment) {
		this.gstr1advTaxPayment = gstr1advTaxPayment;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Double getCGST_Rt() {
		return CGST_Rt;
	}

	public void setCGST_Rt(Double cGST_Rt) {
		CGST_Rt = cGST_Rt;
	}

	public String getItem_No() {
		return item_No;
	}

	public void setItem_No(String item_No) {
		this.item_No = item_No;
	}

	public Long getAdvTaxPaymentID() {
		return advTaxPaymentID;
	}

	public void setAdvTaxPaymentID(Long advTaxPaymentID) {
		this.advTaxPaymentID = advTaxPaymentID;
	}

	public Double getCessRt() {
		return cessRt;
	}

	public void setCessRt(Double cessRt) {
		this.cessRt = cessRt;
	}

	public Double getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}

}