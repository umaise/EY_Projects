package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblDocandSupplyType", schema="metadata")
public class TblDocandSupplyType implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="DocandSupplyTypeID")
	private Integer id;
	
	@Column(name="Code")
	private String typeCode;
	
	@Column(name="Value")
	private String typeValue;
	
	@Column(name="OrderID")
	private int orderID;
	
	@Column(name="TypeofDoc")
	private String typeOfDoc;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the typeCode
	 */
	public String getTypeCode() {
		return typeCode;
	}

	/**
	 * @param typeCode the typeCode to set
	 */
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	/**
	 * @return the typeValue
	 */
	public String getTypeValue() {
		return typeValue;
	}

	/**
	 * @param typeValue the typeValue to set
	 */
	public void setTypeValue(String typeValue) {
		this.typeValue = typeValue;
	}


	/**
	 * @return the typeOfDoc
	 */
	public String getTypeOfDoc() {
		return typeOfDoc;
	}

	/**
	 * @param typeOfDoc the typeOfDoc to set
	 */
	public void setTypeOfDoc(String typeOfDoc) {
		this.typeOfDoc = typeOfDoc;
	}

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }
	
	
	
		
}
