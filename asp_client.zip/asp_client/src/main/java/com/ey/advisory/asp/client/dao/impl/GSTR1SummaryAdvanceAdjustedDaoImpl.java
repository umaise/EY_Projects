package com.ey.advisory.asp.client.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.GSTR1SummaryAdvanceAdjustedDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.GSTR1SummaryAdvanceAdjusted;
@Repository
public class GSTR1SummaryAdvanceAdjustedDaoImpl implements GSTR1SummaryAdvanceAdjustedDao{
	
	@Autowired
	private HibernateDao  hibernateDao;
	
	private static final Logger logger = Logger.getLogger(GSTR1SummaryAdvanceAdjustedDaoImpl.class);

	@Override
	public List<GSTR1SummaryAdvanceAdjusted> getAdvanceAdjustedMetadata() {
		List<GSTR1SummaryAdvanceAdjusted> advanceAdjustedList = new ArrayList<>();
		try {
			 advanceAdjustedList = (List<GSTR1SummaryAdvanceAdjusted>)hibernateDao.loadAll(GSTR1SummaryAdvanceAdjusted.class);
		} catch (Exception e) {
			
			logger.error("Exception in GSTR1SummaryAdvanceAdjusted"+ e);
			
		}
		return advanceAdjustedList;
	}

}
