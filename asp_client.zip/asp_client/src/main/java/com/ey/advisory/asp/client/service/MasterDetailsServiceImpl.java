package com.ey.advisory.asp.client.service;

import java.sql.SQLDataException;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.CustomerMaster;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.ProductMaster;
import com.ey.advisory.asp.client.domain.QuestionAnswerMapping;
import com.ey.advisory.asp.client.domain.VendorMaster;
import com.ey.advisory.asp.client.dto.OnBoardDto;


@Service
@Transactional
public class MasterDetailsServiceImpl implements MasterDetailsService {
	
	@Autowired
	HibernateDao hibernateDao;
	
	private static final Logger LOGGER = Logger.getLogger(MasterDetailsServiceImpl.class);

	@Override
	public List<QuestionAnswerMapping> getQuestionAnswerList(String entityID)
			throws SQLDataException {
		
		try{
		DetachedCriteria detachedCriteria = hibernateDao.createCriteria(QuestionAnswerMapping.class);
		detachedCriteria.add(Restrictions.eq("entityID", Integer.parseInt(entityID)));
		List<QuestionAnswerMapping> questionAnswerList = (List<QuestionAnswerMapping>) hibernateDao.find(detachedCriteria);
		if(questionAnswerList.size() >=0 ){
			return questionAnswerList;
		}
		}catch(Exception e){
			LOGGER.error("Exception in getQuestionAnswerList"+e);
		}
		return null;
	}

	
	@Override
	public String saveEditClientData(OnBoardDto onBoardDto)
			throws SQLDataException {

		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Entering method saveEditClientData() of class MasterDeatilsServiceImpl ");
		}
		
		String response="FAILED";
		
		int submitStage=0;
		try
		{				
				List<QuestionAnswerMapping> questionAnswerList  = onBoardDto.getQuestionAnswerList();
				if(questionAnswerList!=null && !questionAnswerList.isEmpty())
	            {	
	                for (QuestionAnswerMapping questionAnswerMapping : questionAnswerList) {
	                		if(questionAnswerMapping.getDescription() != null){
	                			questionAnswerMapping.setDescription(questionAnswerMapping.getDescription());
	                		}
	                        questionAnswerMapping.setIsDeleted(Boolean.FALSE);
	                        questionAnswerMapping.setUpdatedDate(new Date());
	                        questionAnswerMapping.setCreatedDate(new Date());
	                        
	                       
	                }
	                hibernateDao.saveOrUpdateAll(questionAnswerList);
	                if(LOGGER.isInfoEnabled()){
						LOGGER.info("Question Answer Entity saved successfully" );
						
				    }
		     	}
	            submitStage=1;
				if(onBoardDto.getCustomerMasterList()!=null && !onBoardDto.getCustomerMasterList().isEmpty())
	            {
					List<CustomerMaster> customerMasterList = fetchCustomerMasterDetails();
					if(null != customerMasterList){
	                hibernateDao.saveOrUpdateAll(onBoardDto.getCustomerMasterList());
					}else {
						hibernateDao.deleteAll(customerMasterList);
						hibernateDao.saveOrUpdateAll(onBoardDto.getCustomerMasterList());
					}
	                submitStage=2;
	            }
		
				if(onBoardDto.getVendorMasterList()!=null && !onBoardDto.getVendorMasterList().isEmpty())
	            {
					List<VendorMaster> vendorMasterDetails = fetchVendorMasterDetails();
					if(null != vendorMasterDetails){
						 hibernateDao.saveOrUpdateAll(onBoardDto.getVendorMasterList());
					}else {
						hibernateDao.deleteAll(vendorMasterDetails);
						hibernateDao.saveOrUpdateAll(onBoardDto.getVendorMasterList());
					}
	               
	                submitStage=3;
	            }
	            
	            if(onBoardDto.getItemMasterList()!=null && !onBoardDto.getItemMasterList().isEmpty())
	            {
	            	List<ItemMaster> itemMasterList = fetchItemMasterDetails();
	            	if(null != itemMasterList){
	            		 hibernateDao.saveOrUpdateAll(onBoardDto.getItemMasterList());
	            	}else {
	            		hibernateDao.deleteAll(itemMasterList);
	            		 hibernateDao.saveOrUpdateAll(onBoardDto.getItemMasterList());
	            	}
	               
	                submitStage=4;
	            }
	            
				if(onBoardDto.getProductMasterList()!=null && !onBoardDto.getProductMasterList().isEmpty()){
					
					List<ProductMaster> productMasterList = fetchProductMasterDetails();
					if(null != productMasterList){
	                hibernateDao.saveOrUpdateAll(onBoardDto.getProductMasterList());
					}else {
						hibernateDao.deleteAll(productMasterList);
						hibernateDao.saveOrUpdateAll(onBoardDto.getProductMasterList());
					}
	                submitStage=5;
	            }
			
				response="Success";
				
			}catch(Exception e){
			LOGGER.error("Error while saving Edit Client Master Details =>" + e);
			response="FAILED"+submitStage;
		}
		return response;
	
	}

	
	@Override
	public List<ItemMaster> fetchItemMasterDetails() throws SQLDataException{
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(ItemMaster.class);
			
			List<ItemMaster> itemMasterList = (List<ItemMaster>) hibernateDao.find(detachedCriteria);
			if(itemMasterList.size() >=0 ){
				return itemMasterList;
			}
			}catch(Exception e){
				LOGGER.error("Exception in fetchItemMasterDetails "+ e);
			}
			return null;
	}


	@Override
	public List<VendorMaster> fetchVendorMasterDetails() throws SQLDataException {
		
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(VendorMaster.class);
			
			List<VendorMaster> vendorMasterList = (List<VendorMaster>) hibernateDao.find(detachedCriteria);
			if(vendorMasterList.size() >=0 ){
				return vendorMasterList;
			}
			}catch(Exception e){
				LOGGER.error("Exception in fetchVendorMasterDetails "+ e);
			}
			return null;
   }

	@Override
	public List<ProductMaster> fetchProductMasterDetails()  throws SQLDataException{
		
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(ProductMaster.class);
			
			List<ProductMaster> productMasterList = (List<ProductMaster>) hibernateDao.find(detachedCriteria);
			if(productMasterList.size() >=0 ){
				return productMasterList;
			}
			}catch(Exception e){
				LOGGER.error("Exception in fetchProductMasterDetails "+ e);
			}
			return null;
	}


	@Override
	public List<CustomerMaster> fetchCustomerMasterDetails() throws SQLDataException{
		
		try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(CustomerMaster.class);
			
			List<CustomerMaster> customerMasterList = (List<CustomerMaster>) hibernateDao.find(detachedCriteria);
			if(customerMasterList.size() >=0 ){
				return customerMasterList;
			}
			}catch(Exception e){
				LOGGER.error("Exception in fetchCustomerMasterDetails "+ e);
			}
			return null;
	}


	@Override
	public void deleteQuestionAnswer(
			List<QuestionAnswerMapping> questionAnswerList)
			throws SQLDataException {
	
		try{
			
			hibernateDao.deleteAll(questionAnswerList);
		
		}catch(Exception e){
			LOGGER.error("Exception in deleting the QuestionAnswerList "+ e);
		}
		
	}
	
	

}
