package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.google.api.client.util.DateTime;

@Entity
@Table(name="FIleSubmissionStatus", schema="gstr3")
//@NamedQuery(name = "FIleSubmissionStatus.findAll",  query = "SELECT t FROM FIleSubmissionStatus t where gstin= :GSTN and returnPeriod= :FYEAR")
public class FIleSubmissionStatusDetails implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="FIleSubmissionStatusUID")
	private BigInteger fIleSubmissionStatusUID ;
	
	@Column(name="RefNo")
	private String refNo  ;
	
	@Column(name="GSTIN")
	private String gstin ;
	
	@Column(name="ReturnPeriod")
	private String returnPeriod  ;
	
	@Column(name="CreatedOn")
	private Date createdOn ;
	
	@Column(name="isFiled")
	private boolean isFiled;
	
	public BigInteger getfIleSubmissionStatusUID() {
		return fIleSubmissionStatusUID;
	}
	public void setfIleSubmissionStatusUID(BigInteger fIleSubmissionStatusUID) {
		this.fIleSubmissionStatusUID = fIleSubmissionStatusUID;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public boolean isFiled() {
		return isFiled;
	}
	public void setFiled(boolean isFiled) {
		this.isFiled = isFiled;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getReturnPeriod() {
		return returnPeriod;
	}
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	
	
	

}
