package com.ey.advisory.asp.client.gstr1ff.dto;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class GSTR1FFB2BDto {

	 private String ctin;

	  public String getCtin() { return this.ctin; }

	  public void setCtin(String ctin) { this.ctin = ctin; }

	  private String cfs;

	  public String getCfs() { return this.cfs; }

	  public void setCfs(String cfs) { this.cfs = cfs; }

	  private List<GSTR1FFB2B_InvoiceDetails> inv;

	  public List<GSTR1FFB2B_InvoiceDetails> getInv() { return this.inv; }

	  public void setInv(List<GSTR1FFB2B_InvoiceDetails> inv) { this.inv = inv; }
}
