package com.ey.advisory.asp.client.dto;

public class SetoffLiabilityDto {
	
	private TxoffsetDto tx_offset;
	private IntroffsetDto intr_offset;
	private LfeeoffsetDto lfee_offset;
	
	public TxoffsetDto getTx_offset() {
		return tx_offset;
	}
	public void setTx_offset(TxoffsetDto tx_offset) {
		this.tx_offset = tx_offset;
	}
	public IntroffsetDto getIntr_offset() {
		return intr_offset;
	}
	public void setIntr_offset(IntroffsetDto intr_offset) {
		this.intr_offset = intr_offset;
	}
	public LfeeoffsetDto getLfee_offset() {
		return lfee_offset;
	}
	public void setLfee_offset(LfeeoffsetDto lfee_offset) {
		this.lfee_offset = lfee_offset;
	}	
	
}
