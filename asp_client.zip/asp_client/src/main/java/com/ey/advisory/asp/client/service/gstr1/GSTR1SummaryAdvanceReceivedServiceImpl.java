package com.ey.advisory.asp.client.service.gstr1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GSTR1SummaryAdvanceReceivedDao;
import com.ey.advisory.asp.client.domain.GSTR1SummaryAdvanceReceived;

@Service
public class GSTR1SummaryAdvanceReceivedServiceImpl implements GSTR1SummaryAdvanceReceivedService{
	
	@Autowired
	private GSTR1SummaryAdvanceReceivedDao advanceReceivedDao;

	@Override
	public List<GSTR1SummaryAdvanceReceived> getAdvanceReceivedMetadata() {
		return advanceReceivedDao.getAdvanceReceivedMetadata();
	}

}
