package com.ey.advisory.asp.client.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;

import com.ey.advisory.asp.client.domain.FIleSubmissionStatusDetailsGstr6;
import com.ey.advisory.asp.client.domain.GSTR6FB2BInvoiceDetailsModel;
import com.ey.advisory.asp.client.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.TblTurnoverDetails;
import com.ey.advisory.asp.client.domain.TblTurnoverMaster;
import com.ey.advisory.asp.client.dto.Gstr6Dto;
import com.ey.advisory.asp.client.dto.PreGSTTurnOverDto;
import com.ey.advisory.asp.client.dto.PreGSTTurnOverWrapper;
import com.ey.advisory.asp.dto.LineItemDTO;

public interface GSTR6Dao {
	<T> List<T> validateOriginalDocNoDocDate(String docNum, Date date, String entityName, String column1,String column2);
	<T> List<T> validateOriginalDocumentNo(String originalDocumentNo, String entityName, String columnName);
	public GSTR6FB2BInvoiceDetailsModel getReconInvoice(String entityName, String custGSTIN, String gstin, String invNum, Date invDate);
    public void updateReconFilingStatus(Object model);
	void updateITCValues(Set<LineItemDTO> redisLineItemSet);
	List<String> getGSTINListByPAN(String entityName, String custGSTINColumn, String gstinColumn,String invNumColumn, String invDateColumn, String custGSTIN, String PAN, String gstin, String invNum, Date invDate);
	public <T> T getReconInvoice(String entityName, String custGSTINColumn, String gstinColumn,String invNumColumn, String invDateColumn, String custGSTIN, String gstin, String invNum, Date invDate);
	public <T> T getReconInvoice(String entityName, String invoiceIdColumn, Long invoiceDetailsId);
	public GlobalGSTRatesMasterI fetchHsnSacDetailsFromGlobal(String hsnSac) ;
	public ItemMaster fetchHsnSacDetails(String hsnSac) ;
	public <T> T getDRInvoice(String entityName, String invoiceDocColumn, String invoiceDocNo,String gstinColumn,String gstinVAlue);
	public List<FIleSubmissionStatusDetailsGstr6> getFileGstr6Status(Gstr6Dto gstr6Dto);
	public List<String> fetchISDDistributionListForGstin(JSONObject jsonObj);
	public Object getErrorReportDetails(JSONObject obj);
	public List<String> updateInvoiceMappedRows(JSONObject jsonObj);
	public int checkFinalInvUploadCompleted(String taxperiod,String gstin);
	public Object getInvoiceMappingDetails(String gstinId,String taxPeriod);
	public Object getDeterminationReport(String gstinId,String taxPeriod);
	public int checkHsnSac(String hsnSac);	
	public List<String> saveDeterminationRowsData(JSONObject jsonObj);
	public List<String> submitDeterminationRowsData(JSONObject jsonObj);
	public String getDetSummaryDownload(JSONObject jsonObj); 
	public Object getPreGSTTurnOverDataFromDB(String gstinId,String finYear);
	public Object getDistributionTuroverTab1FromDB(String gstinId, String taxPeriod);
	public void saveNewEntityDetails(TblTurnoverMaster tblTurnoverMaster);
	public void saveNewTurnoverData(TblTurnoverDetails tblTurnoverDetails);
}
