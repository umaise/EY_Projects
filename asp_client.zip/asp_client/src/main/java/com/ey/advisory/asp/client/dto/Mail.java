package com.ey.advisory.asp.client.dto;

import java.io.File;
import java.util.Map;

public class Mail {
	
private String from;
	
	private String[] to;
	
	private String subject;
	
	private String body;
	
	private String cc;
	
	private String[] bcc;
	
	private File attachedFile;
	
	private String templateName;
	 
	private Map<String, Object> velocityDataMap;
	
	private String contentType;
	
	private boolean htmlContent;
	
	private boolean sendEmail;
	
	public String[] getTo() {
		return to;
	}

	public void setTo(String[] to) {
		this.to = to;
	}

	public String[] getBcc() {
		return bcc;
	}

	public void setBcc(String[] bcc) {
		this.bcc = bcc;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}
	  
	  public Mail() {
		    this.contentType = "text/html";
		  }
	
	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public boolean isHtmlContent() {
		return htmlContent;
	}

	public void setHtmlContent(boolean htmlContent) {
		this.htmlContent = htmlContent;
	}

	public boolean isSendEmail() {
		return sendEmail;
	}

	public void setSendEmail(boolean sendEmail) {
		this.sendEmail = sendEmail;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Map<String, Object> getVelocityDataMap() {
		return velocityDataMap;
	}

	public void setVelocityDataMap(Map<String, Object> velocityDataMap) {
		this.velocityDataMap = velocityDataMap;
	}

	public File getAttachedFile() {
		return attachedFile;
	}

	public void setAttachedFile(File attachedFile) {
		this.attachedFile = attachedFile;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}
	
	@Override
	public String toString() {
		return "Mail [from=" + from + ", to=" + to + ", subject=" + subject + ", body=" + body + "]";
	}

}
