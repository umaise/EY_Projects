/**
 * 
 */
package com.ey.advisory.asp.client.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.ClientGroupDao;
import com.ey.advisory.asp.client.domain.ClientGroupDomain;

/**
 * @author Nitesh.Tripathi
 *
 */
@Service
public class ClientGroupServiceImpl implements ClientGroupService {

	@Autowired
	private ClientGroupDao clientGroupDao;
	
	@Override
	public String getClientGroup(long groupId, String groupcode) {
		String output = clientGroupDao.getClientGroup(groupId, groupcode);
		return output;
	}

	@Override
	public List<ClientGroupDomain> getClientGroup() {
		
		return clientGroupDao.getClientGroup();
	}

}
