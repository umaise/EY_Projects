/**
 * 
 */
package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Smruti.Pradhan
 *
 */
@Entity
@Table(name = "tblPayloadStatus", schema="config")
public class PayloadStatus implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5326707148482714847L;
	private int id;
	private int fileId;
	private String docType;
	private String taxPayerGstin;
	private int inVoiceIdFrom;
	private int inVoiceIdTo;
	private Date createDtae;
	private Date updateDate;
	private String gsptransId;
	private String gstntransId;
	private String transactionStatus;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "FileID")
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	@Column(name = "DocType")
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	@Column(name = "TaxPayerGSTIN")
	public String getTaxPayerGstin() {
		return taxPayerGstin;
	}
	public void setTaxPayerGstin(String taxPayerGstin) {
		this.taxPayerGstin = taxPayerGstin;
	}
	@Column(name = "InvoiceFrom")
	public int getInVoiceIdFrom() {
		return inVoiceIdFrom;
	}
	public void setInVoiceIdFrom(int inVoiceIdFrom) {
		this.inVoiceIdFrom = inVoiceIdFrom;
	}
	@Column(name = "InvoiceTo")
	public int getInVoiceIdTo() {
		return inVoiceIdTo;
	}
	public void setInVoiceIdTo(int inVoiceIdTo) {
		this.inVoiceIdTo = inVoiceIdTo;
	}
	@Column(name = "CreatedDate ")
	public Date getCreateDtae() {
		return createDtae;
	}
	public void setCreateDtae(Date createDtae) {
		this.createDtae = createDtae;
	}
	@Column(name = "UpdatedDate")
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	@Column(name = "GSPTransactionID ")
	public String getGsptransId() {
		return gsptransId;
	}
	public void setGsptransId(String gsptransId) {
		this.gsptransId = gsptransId;
	}
	@Column(name = "GSTNTransactionID")
	public String getGstntransId() {
		return gstntransId;
	}
	public void setGstntransId(String gstntransId) {
		this.gstntransId = gstntransId;
	}
	@Column(name = "TransactionStatus")
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	@Override
	public String toString() {
		return "PayloadStatus [id=" + id + ", fileId=" + fileId + ", docType="
				+ docType + ", taxPayerGstin=" + taxPayerGstin
				+ ", inVoiceIdFrom=" + inVoiceIdFrom + ", inVoiceIdTo="
				+ inVoiceIdTo + ", createDtae=" + createDtae + ", updateDate="
				+ updateDate + ", gsptransId=" + gsptransId + ", gstntransId="
				+ gstntransId + ",transactionStatus=" + transactionStatus + "]";
	}
	
	
	
	

}
