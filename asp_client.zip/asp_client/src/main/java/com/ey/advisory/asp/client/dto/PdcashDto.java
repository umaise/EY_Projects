package com.ey.advisory.asp.client.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

public class PdcashDto {
	
	private BigDecimal ipd;
	private BigDecimal cpd;
	private BigDecimal spd;
	private BigDecimal cspd;
	public BigDecimal getIpd() {
		return ipd;
	}
	public void setIpd(BigDecimal ipd) {
		this.ipd = ipd;
	}
	public BigDecimal getCpd() {
		return cpd;
	}
	public void setCpd(BigDecimal cpd) {
		this.cpd = cpd;
	}
	public BigDecimal getSpd() {
		return spd;
	}
	public void setSpd(BigDecimal spd) {
		this.spd = spd;
	}
	public BigDecimal getCspd() {
		return cspd;
	}
	public void setCspd(BigDecimal cspd) {
		this.cspd = cspd;
	}
	
	
}
