package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="tblAdvanceAdjusted", schema="etl")
@NamedQuery(name = "TblAdvanceAdjusted.findAll", query = "SELECT t FROM TblAdvanceAdjusted t")
public class TblAdvanceAdjusted implements Serializable {
	
	private static final long serialVersionUID = 1;

	@Id
	@Column(name="AdvAdjID")
	private Long advAdjID;
	
	@Column(name="SupplierGSTIN")
	private String supplierGSTIN;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="OrgDetailsMonth")
	private String orgDetailsMonth;
	
	@Column(name="OrgDetailsPOS")
	private String orgDetailsPOS;
	
	@Column(name="OrgDetailsRate")
	private BigDecimal orgDetailsRate;
	
	@Column(name="SummaryFileID")
	private Long summaryFileID;
	
	@Column(name="OrgDetailsGrossAdvAdj")
	private BigDecimal orgDetailsGrossAdvAdj;
	
	@Column(name="NewDetailsPOS")
	private String newDetailsPOS;
	
	@Column(name="NewDetailsRate")
	private BigDecimal newDetailsRate;
	
	@Column(name="NewDetailsGrossAdvAdj")
	private BigDecimal newDetailsGrossAdvAdj;
	
	@Column(name="IGSTAmt")
	private BigDecimal igstAmt;
	
	@Column(name="CGSTAmt")
	private BigDecimal cgstAmt;
	
	@Column(name="SGSTAmt")
	private BigDecimal sgstAmt;
	
	@Column(name="CESSAmt")
	private BigDecimal cessAmt; 
	
	@Column(name="IsActive")
	private Boolean isActive;
	

	public Long getAdvAdjID() {
		return advAdjID;
	}

	public void setAdvAdjID(Long advAdjID) {
		this.advAdjID = advAdjID;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Long getSummaryFileID() {
		return summaryFileID;
	}

	public void setSummaryFileID(Long summaryFileID) {
		this.summaryFileID = summaryFileID;
	}

	public String getSupplierGSTIN() {
		return supplierGSTIN;
	}

	public void setSupplierGSTIN(String supplierGSTIN) {
		this.supplierGSTIN = supplierGSTIN;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getOrgDetailsMonth() {
		return orgDetailsMonth;
	}

	public void setOrgDetailsMonth(String orgDetailsMonth) {
		this.orgDetailsMonth = orgDetailsMonth;
	}

	public String getOrgDetailsPOS() {
		return orgDetailsPOS;
	}

	public void setOrgDetailsPOS(String orgDetailsPOS) {
		this.orgDetailsPOS = orgDetailsPOS;
	}

	public BigDecimal getOrgDetailsRate() {
		return orgDetailsRate;
	}

	public void setOrgDetailsRate(BigDecimal orgDetailsRate) {
		this.orgDetailsRate = orgDetailsRate;
	}

	public BigDecimal getOrgDetailsGrossAdvAdj() {
		return orgDetailsGrossAdvAdj;
	}

	public void setOrgDetailsGrossAdvAdj(BigDecimal orgDetailsGrossAdvAdj) {
		this.orgDetailsGrossAdvAdj = orgDetailsGrossAdvAdj;
	}

	public String getNewDetailsPOS() {
		return newDetailsPOS;
	}

	public void setNewDetailsPOS(String newDetailsPOS) {
		this.newDetailsPOS = newDetailsPOS;
	}

	public BigDecimal getNewDetailsRate() {
		return newDetailsRate;
	}

	public void setNewDetailsRate(BigDecimal newDetailsRate) {
		this.newDetailsRate = newDetailsRate;
	}

	public BigDecimal getNewDetailsGrossAdvAdj() {
		return newDetailsGrossAdvAdj;
	}

	public void setNewDetailsGrossAdvAdj(BigDecimal newDetailsGrossAdvAdj) {
		this.newDetailsGrossAdvAdj = newDetailsGrossAdvAdj;
	}

	public BigDecimal getIgstAmt() {
		return igstAmt;
	}

	public void setIgstAmt(BigDecimal igstAmt) {
		this.igstAmt = igstAmt;
	}

	public BigDecimal getCgstAmt() {
		return cgstAmt;
	}

	public void setCgstAmt(BigDecimal cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	public BigDecimal getSgstAmt() {
		return sgstAmt;
	}

	public void setSgstAmt(BigDecimal sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	public BigDecimal getCessAmt() {
		return cessAmt;
	}

	public void setCessAmt(BigDecimal cessAmt) {
		this.cessAmt = cessAmt;
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((advAdjID == null) ? 0 : advAdjID.hashCode());
		return result;
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TblAdvanceAdjusted other = (TblAdvanceAdjusted) obj;
		if (advAdjID == null) {
			if (other.advAdjID != null)
				return false;
		} else if (!advAdjID.equals(other.advAdjID))
			return false;
		return true;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public String toString() {
		return (supplierGSTIN != null ? supplierGSTIN : "") + ", "
				+ (taxPeriod != null ? taxPeriod : "") + ", "
				+ (orgDetailsMonth != null ? orgDetailsMonth : "") + ", "
				+ (orgDetailsPOS != null ? orgDetailsPOS : "") + ", "
				+ (orgDetailsRate != null ? orgDetailsRate : "") + ", "
				+ (orgDetailsGrossAdvAdj != null ? orgDetailsGrossAdvAdj : "") + ", "
				+ (newDetailsPOS != null ? newDetailsPOS : "") + ", "
				+ (newDetailsRate != null ? newDetailsRate : "") + ", "
				+ (newDetailsGrossAdvAdj != null ? newDetailsGrossAdvAdj : "") + ", "
				+ (igstAmt != null ? igstAmt : "") + ", "
				+ (cgstAmt != null ? cgstAmt : "") + ", "
				+ (sgstAmt != null ? sgstAmt : "") + ", "
				+ (cessAmt != null ? cessAmt : "");
	}

	
	/*@Override
	public String toString() {
		return supplierGSTIN + "," + taxPeriod + "," + orgDetailsMonth + "," + orgDetailsPOS
				+ "," + orgDetailsRate + ","+ orgDetailsGrossAdvAdj + "," + newDetailsPOS + "," + newDetailsRate
				+ "," + newDetailsGrossAdvAdj + "," + igstAmt + "," + cgstAmt+ "," + sgstAmt + "," 
				+ cessAmt;
	}*/

	
}
