package com.ey.advisory.asp.client.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.EntityRegistrationDao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.domain.ClientCommunication;
import com.ey.advisory.asp.client.domain.TblGstinDetailsDomain;
import com.ey.advisory.asp.client.domain.TblGstinFinancialDetails;
import com.ey.advisory.asp.client.domain.UserAccessMapping;
import com.ey.advisory.asp.client.dto.ClientRegistrationDTO;
import com.ey.advisory.asp.client.dto.CommonSearchDto;
import com.ey.advisory.asp.client.dto.ResultPage;
import com.ey.advisory.asp.common.Constant;

@Repository
public class EntityRegistrationDaoImpl implements EntityRegistrationDao{

	@Autowired
	HibernateDao hibernateDao;
	
	private static final Logger logger = Logger.getLogger(EntityRegistrationDaoImpl.class);
	private static final String CLASS_NAME = EntityRegistrationDaoImpl.class.getName();
	
	@Override
	public ResultPage<ClientRegistrationDTO> fetchRegistrationListPagination(CommonSearchDto searchDto) {
		
		ResultPage<ClientRegistrationDTO> result = new ResultPage<ClientRegistrationDTO>();
		Session session = hibernateDao.getSession();
		try {
			
			logger.info("Entered fetchRegistrationListPagination "+CLASS_NAME);
			List<Object[]> gstinDetailsDomainList = null;
			
			int pagenum = Integer.parseInt(searchDto.getPageNum())-1;
			int recordnum = Integer.parseInt(searchDto.getRownumInPerPage());
			String tag = searchDto.getSearchText();
			int offset = pagenum * recordnum;
			String queryStr = null;
			
			if(tag != null && tag.trim().length()>0){
				   String tagtemp = tag.trim()+"%";
				   queryStr = "select a.gstinId, a.entityID, a.gSTNUserName, a.turnOverAmount, a.typeOfReg, a.regdt, a.bankAccountNumber, b.quarterTurnOvrAmt,"+
							"c.pAuthUserId, c.sAuthUserId, c.pContactUserId, c.sContactUserId, a.isActive, a.updatedDate FROM TblGstinDetailsDomain a, TblGstinFinancialDetails b , "+
							"ClientCommunication c where a.entityID = :entityID  and b.gstin=a.gstinId and a.gstinId=c.gstin and "+
							"(a.gstinId like '"+tagtemp+"' or a.gSTNUserName like '"+tagtemp+"' or a.typeOfReg like '"+tagtemp+"' or a.bankAccountNumber like '"+tagtemp+
							"' or CONVERT(varchar(20), a.turnOverAmount) like '"+tagtemp+"' or CONVERT(varchar(20), b.quarterTurnOvrAmt) like '"+tagtemp+"' )"+
							"order by a.gstinId desc ";
				}
			else{
				queryStr = "select a.gstinId, a.entityID, a.gSTNUserName, a.turnOverAmount, a.typeOfReg, a.regdt, a.bankAccountNumber, b.quarterTurnOvrAmt,"+
							"c.pAuthUserId, c.sAuthUserId, c.pContactUserId, c.sContactUserId, a.isActive, a.updatedDate FROM TblGstinDetailsDomain a, TblGstinFinancialDetails b , "+
							"ClientCommunication c where a.entityID = :entityID  and b.gstin=a.gstinId and a.gstinId=c.gstin order by a.gstinId desc ";
			}
			Query query =session.createQuery(queryStr);
			query.setParameter("entityID", Integer.parseInt(searchDto.getEntityId()));
			int totalRecords = query.list().size();
			query.setFirstResult(offset);
			query.setMaxResults(recordnum);
			gstinDetailsDomainList = (List<Object[]>)query.list();
			result.setResultListArray(gstinDetailsDomainList);
			result.setRecordsNum(recordnum);
			result.setPageNum(pagenum);
			result.setTotalRecords(Long.valueOf(totalRecords));
		} catch (Exception e) {
			logger.error("Exception in fetchHierarchyList" + e);
		}
		finally{
            if(session !=null && session.isOpen()){
                   session.close();
            }
      }        
		return result;
	}
	
	@Override
	public void updateClientDetails(ClientRegistrationDTO clientRegistrationDTO) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " updateClientDetails()");
		List<ClientCommunication> resultList = null;
			 DetachedCriteria criteria = hibernateDao.createCriteria(ClientCommunication.class);
			 criteria.add(Restrictions.eq("gstin",clientRegistrationDTO.getGstinId()));
			 resultList = (List<ClientCommunication>)hibernateDao.find(criteria);
			 
			 ClientCommunication client = resultList.get(0);
			 client.setpAuthUserId(clientRegistrationDTO.getpAuthUserId());
			 client.setpContactUserId(clientRegistrationDTO.getpContactUserId());
			 client.setsAuthUserId(clientRegistrationDTO.getsAuthUserId());
			 client.setsContactUserId(clientRegistrationDTO.getsContactUserId());
			 hibernateDao.merge(client);
	}

	@Override
	public void updateBankAccNumber(ClientRegistrationDTO clientRegistrationDTO) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " updateBankAccNumber()");
		TblGstinDetailsDomain gstinDetailsDomain= hibernateDao.load(TblGstinDetailsDomain.class, clientRegistrationDTO.getGstinId());
		gstinDetailsDomain.setBankAccountNumber(clientRegistrationDTO.getBankAccountNumber());
		gstinDetailsDomain.setUpdatedDate(new Date());
		gstinDetailsDomain.setUpdatedBy(clientRegistrationDTO.getUpdatedBy());
		hibernateDao.merge(gstinDetailsDomain);
		
	}

	
	@Override
	public void addGSTINDetails(ClientRegistrationDTO clientRegistrationDTO) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " addGSTINDetails()");
		TblGstinDetailsDomain gstinDetailsDomain = new TblGstinDetailsDomain();
		gstinDetailsDomain.setBankAccountNumber(clientRegistrationDTO.getBankAccountNumber());
		gstinDetailsDomain.setEntityID(clientRegistrationDTO.getEntityID());
		gstinDetailsDomain.setGstinId(clientRegistrationDTO.getGstinId());
		gstinDetailsDomain.setgSTNUserName(clientRegistrationDTO.getgSTNUserName());
		gstinDetailsDomain.setIsActive(true);
		gstinDetailsDomain.setIsRegCertificate(true);
		gstinDetailsDomain.setTurnOverAmount(clientRegistrationDTO.getTurnOverAmount());
		gstinDetailsDomain.setRegdt(clientRegistrationDTO.getRegdt());
		gstinDetailsDomain.setStateCode(clientRegistrationDTO.getGstinId().substring(0, 2));
		gstinDetailsDomain.setTypeOfReg(clientRegistrationDTO.getTypeOfReg());
		gstinDetailsDomain.setCreatedDate(new Date());
		gstinDetailsDomain.setCreatedBy(clientRegistrationDTO.getCreatedBy());
		hibernateDao.save(gstinDetailsDomain);
		
	}

	@Override
	public void addGSTINFinancialDetails(ClientRegistrationDTO clientRegistrationDTO) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " addGSTINFinancialDetails()");
		TblGstinFinancialDetails gstinFinancialDetails = new TblGstinFinancialDetails();
		gstinFinancialDetails.setGstin(clientRegistrationDTO.getGstinId());
		gstinFinancialDetails.setQuarterTurnOvrAmt(clientRegistrationDTO.getQuarterTurnOvrAmt());
		gstinFinancialDetails.setFinancialPeriod("April-June(2017)");
		hibernateDao.save(gstinFinancialDetails);
	}

	@Override
	public void addClientDetails(ClientRegistrationDTO clientRegistrationDTO) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " addClientDetails()");
		ClientCommunication clientCommunication = new ClientCommunication();
		clientCommunication.setGstin(clientRegistrationDTO.getGstinId());
		clientCommunication.setpAuthUserId(clientRegistrationDTO.getpAuthUserId());
		clientCommunication.setpContactUserId(clientRegistrationDTO.getpContactUserId());
		clientCommunication.setsAuthUserId(clientRegistrationDTO.getsAuthUserId());
		clientCommunication.setsContactUserId(clientRegistrationDTO.getsContactUserId());
		 hibernateDao.save(clientCommunication);
		
	}

	@Override
	public Map<Long,String> fetchGroupEntityLevelUsers(String entityCode) {
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME + Constant.LOGGER_METHOD + " fetchGroupEntityLevelUsers()");
		Map<Long,String> userIdLevelMap = new HashMap<Long,String>();
		DetachedCriteria criteria = hibernateDao.createCriteria(UserAccessMapping.class);
		Criterion rest1= Restrictions.eq("accessLevel",Constant.L1_ACCESS_LEVEL);
		Criterion rest2= Restrictions.and(Restrictions.eq("accessLevel",Constant.L2_ACCESS_LEVEL),  Restrictions.eq("accessValue", entityCode));
		criteria.add(Restrictions.or(rest1, rest2));
		criteria.setProjection(Projections.projectionList().add(Projections.property("userID")).add(Projections.property("accessLevel")));
		List<Object[]> usersIdLevelList = (List<Object[]>)hibernateDao.find(criteria);
		
		if(usersIdLevelList!=null && usersIdLevelList.size()>0){
			for(Object[] userIdLevel: usersIdLevelList){
				userIdLevelMap.put(((Integer)userIdLevel[0]).longValue(), (String)userIdLevel[1]);
			}
		}
		return userIdLevelMap;
	}

}
