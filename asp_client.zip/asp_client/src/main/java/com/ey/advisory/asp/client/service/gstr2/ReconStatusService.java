package com.ey.advisory.asp.client.service.gstr2;

import com.ey.advisory.asp.client.domain.ReconStatus;

public interface ReconStatusService {
	
	public ReconStatus getReconStatus(String gstin,String taxPeriod,Integer masterId);
	
	public void saveReconStatus(String gstin,String taxPeriod,Integer masterId);
	
	public void updateReconStatus(String gstin, String taxPeriod,Integer masterId);
	
	public ReconStatus getActiveReconStatus(String gstin,String taxPeriod);

	public ReconStatus getReconStatus(String gstin,String taxPeriod);
	
	public void updateReconCompletionDate(String gstin, String taxPeriod,Integer masterId);
	
	public void updateReconStatus(String gstin, String taxPeriod,Integer masterId,String status); 


}
