package com.ey.advisory.asp.client.service.gstr1;

import java.util.List;

import com.ey.advisory.asp.client.domain.GSTR1SummaryB2CConsolidated;

@FunctionalInterface
public interface GSTR1SummaryB2CConsolidatedService {
	
	public List<GSTR1SummaryB2CConsolidated> getB2CConsolidatedMetadata(); 

}
