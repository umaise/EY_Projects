package com.ey.advisory.asp.client.util;

import java.io.IOException;
import java.net.Proxy.Type;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.annotation.Resource;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Configuration
@PropertySource("classpath:RestConfig.properties")
public class GSTNRestClientUtility {

	@Autowired
	@Resource(name="${restTemplate.proxy}")
	RestTemplate restTemplateProxy;
	
	@Autowired
	RestTemplate restTemplate;
	
	//for azure- digio connection 
	@Autowired
	RestTemplate restTemplatewithoutProxy;

	private static final Logger LOGGER = Logger
			.getLogger(GSTNRestClientUtility.class);
	private static final String CLASS_NAME = GSTNRestClientUtility.class
			.getName();

	SSLSocketFactory sslCont = null;

	public String executeRestCallGSTNPost(String body, HttpMethod method,
			String uri, HttpHeaders headers) throws JsonGenerationException,
			JsonMappingException, IOException {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Entering " + CLASS_NAME + " Method : executeRestCallGSTNPost");
		}
		ResponseEntity<String> response = null;

		HttpEntity<String> request = new HttpEntity<>(body, headers);
		try {
			response = restTemplate.exchange(uri, method, request, String.class);
		} catch (HttpClientErrorException hcee) {
			LOGGER.error(hcee);
			return hcee.getMessage();
		} catch (HttpStatusCodeException hsce) {
			LOGGER.error(hsce);
			return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error(e);
			return e.getMessage();
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting " + CLASS_NAME + " Method : executeRestCallGSTNPost");
		}
		return response.getBody();
	}

	public String executeRestCallBIPost(String body, HttpMethod method,
			String uri, HttpHeaders headers) throws JsonGenerationException,
			JsonMappingException, IOException {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Entering " + CLASS_NAME + " Method : executeRestCallGSTNPost");
		}
		ResponseEntity<String> response = null;

		HttpEntity<String> request = new HttpEntity<>(body, headers);
		try {
			response= restTemplatewithoutProxy.exchange(uri, method, request, String.class);
		} catch (HttpClientErrorException hcee) {
			LOGGER.error(hcee);
			return hcee.getMessage();
		} catch (HttpStatusCodeException hsce) {
			LOGGER.error(hsce);
			return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error(e);
			return e.getMessage();
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting " + CLASS_NAME + " Method : executeRestCallGSTNPost");
		}
		return response.getBody();
	}
	
	// POST
	public String executeRestCall(String uri, HttpHeaders httpHeaders,
			String inputData, HttpMethod httpMethod) {

		String result = "";
		HttpEntity<String> entity = new HttpEntity<>(inputData,
				httpHeaders);
		try {
			ResponseEntity<String> response = restTemplate.exchange(uri,
					httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpClientErrorException hcee) {
			LOGGER.error(hcee);
				return hcee.getMessage();
		}catch (HttpServerErrorException hsee) {
			LOGGER.error(hsee);
				return hsee.getMessage();
		}catch (HttpStatusCodeException hsce) {
			LOGGER.error(hsce);
			return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error(e);
			return e.getMessage();
		}

		return result;
	}
	// POST
		public String executePOSTRestCall(String uri, HttpHeaders httpHeaders,
				String inputData, HttpMethod httpMethod) {

			LOGGER.info("Entering " + CLASS_NAME + " Method : executeRestCall()  : ");
			String result = "";
			HttpEntity<String> entity = new HttpEntity<>(inputData,
					httpHeaders);
			try {
				ResponseEntity<String> response = restTemplatewithoutProxy.exchange(uri,
						httpMethod, entity, String.class);
				result = response.getBody();
			} catch (HttpClientErrorException hcee) {
				LOGGER.error(hcee);
					return hcee.getMessage();
			}catch (HttpServerErrorException hsee) {
				LOGGER.error(hsee);
					return hsee.getMessage();
			}catch (HttpStatusCodeException hsce) {
				LOGGER.error(hsce);
				return hsce.getResponseBodyAsString();
			} catch (RestClientException rce) {
				LOGGER.error(rce);
				return rce.getMessage();
			} catch (Exception e) {
				LOGGER.error(e);
				return e.getMessage();
			}
			LOGGER.info("Exiting " + CLASS_NAME + " Method : executeRestCallGSTNPost");

			return result;
		}
	// GET
	public String executeRestCall(String uri, HttpHeaders httpHeaders,
			HttpMethod httpMethod) {
		String result = "";
		HttpEntity<Object> entity = new HttpEntity<>(httpHeaders);
		try {
			ResponseEntity<String> response = restTemplate.exchange(uri,
					httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpClientErrorException hcee) {
			LOGGER.error(hcee);
				return hcee.getMessage();
		}catch (HttpStatusCodeException hsce) {
			LOGGER.error(hsce);
				return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error(e);
			return e.getMessage();
		}

		return result;
	}

	// Digio Rest Call -post
	public String executeRestCallTest(String uri, HttpHeaders httpHeaders,
			String inputData, HttpMethod httpMethod) {
		enableSSL();
		String result = "";
		HttpEntity<String> entity = new HttpEntity<>(inputData,
				httpHeaders);
		try {
			ResponseEntity<String> response = restTemplatewithoutProxy.exchange(uri,
					httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpClientErrorException hcee) {
			LOGGER.error(hcee);
			return hcee.getMessage();
		}catch (HttpStatusCodeException hsce) {
			LOGGER.error(hsce);
			return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error(e);
			return e.getMessage();
		}
		disableSsl();

		return result;
	}

	// Digio Rest call- get
	public String executeRestCallTest(String uri, HttpHeaders httpHeaders,
			HttpMethod httpMethod) {
		String result = "";
		enableSSL();
		HttpEntity<Object> entity = new HttpEntity<>(httpHeaders);

		try {
			ResponseEntity<String> response = restTemplatewithoutProxy.exchange(uri,
					httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpClientErrorException hcee) {
			LOGGER.error(hcee);
				return hcee.getMessage();
		}catch (HttpStatusCodeException hsce) {
			LOGGER.error(hsce);
				return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error(rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error(e);
			return e.getMessage();
		}
		disableSsl();
		return result;
	}

	private void enableSSL() {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			@Override
			public void checkClientTrusted(
					java.security.cert.X509Certificate[] x509Certificates,
					String s) throws CertificateException {
				if(LOGGER.isInfoEnabled()){
					LOGGER.info("in checkClientTrusted ");
					}
			}
			@Override
			public void checkServerTrusted(
					java.security.cert.X509Certificate[] x509Certificates,
					String s) throws CertificateException {
				if(LOGGER.isInfoEnabled()){
					LOGGER.info("in checkServerTrusted ");
					}
			}

			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return new java.security.cert.X509Certificate[0]; 
			}
		} };
		HostnameVerifier hostnameVerifier = new HostnameVerifier() {

			@Override
			public boolean verify(String hostname, SSLSession sslSession) {
				return true;
			}
		};
		sslCont = HttpsURLConnection.getDefaultSSLSocketFactory();
		SSLContext sslContext = null;
		try {
			sslContext = SSLContext.getInstance("TLSv1.2");
			sslContext.init(null, trustAllCerts,
					new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sslContext
					.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);
		} catch (KeyManagementException e) {
			LOGGER.error(e);
		} catch (NoSuchAlgorithmException e1) {
			LOGGER.error(e1);;
		}

	}

	public void disableSsl() {
		HttpsURLConnection.setDefaultSSLSocketFactory(sslCont);
	}

}
