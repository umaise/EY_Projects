package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.TblGSTINListDao;
import com.ey.advisory.asp.client.domain.TblGSTINList;
import com.ey.advisory.asp.common.Constant;
@Service
@Transactional
public class TblGstinServiceImpl implements TblGstinListService{
	
	@Autowired
	HibernateDao hibernateDao;	

	@Autowired
	TblGSTINListDao tblgstinlistDao;
	private static final Logger logger = Logger.getLogger(TblGstinServiceImpl.class);
	private static final String CLASS_NAME = TblGstinServiceImpl.class.getName();
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#getGstinRtType(java.util.List)
	 * get the gstin based on entity level
	 */
	@Override
	public List<TblGSTINList> getGstinRtType(String returnType) {
		 logger.info("*********** entering method getGstinRtType ");
		List<TblGSTINList> tblGSTINList = null;
		try
		{
			tblGSTINList=tblgstinlistDao.getGstinRtType(returnType);
			
		}
		catch(Exception ex)
		{
			logger.error("*********** ERROR in Job getGstinRtType *********** ",ex);
		}
		return tblGSTINList;
	}
	
	@Override
	public List<TblGSTINList> getGstinRtType(String returnType, String gstin ,String taxPeriod) {
		 logger.info("*********** entering method getGstinRtType ");
			List<TblGSTINList> tblGSTINList = null;
			try
			{
				tblGSTINList=tblgstinlistDao.getGstinRtType(returnType,gstin,taxPeriod);
				
			}
			catch(Exception ex)
			{
				logger.error("*********** ERROR in Job getGstinRtType *********** ",ex);
			}
			return tblGSTINList;
	}
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#insertUpdateGstr12FilingStatus(java.util.List)
	 * insert or update records in tblGstinRetutnFilingStatus table
	 */
	@Override
    public String insertUpdateGstr12FilingStatus(List<TblGSTINList> gstinList) {
         logger.info("*********** entering Job insertUpdateGstr12FilingStatus " + gstinList);
  
        try{
        	tblgstinlistDao.insertUpdateGstr12FilingStatus(gstinList);
   
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job insertUpdateGstr12FilingStatus ",e);
		} 
         return "Success";
    }
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#updateGstinList(com.ey.advisory.asp.client.domain.TblGSTINList)
	 * Update the Status of GSTIN after sending to NodeJs
	 */
	@Override
	public void updateGstinList(TblGSTINList gstinData) {
		 logger.info("*********** entering method updateGstinList " + gstinData);
		 try{
			 tblgstinlistDao.updateGstinList(gstinData);
			 }
		 catch(Exception ex){
			 logger.error("*********** ERROR in method updateGstinList ",ex);
		 }
	}
	/**
     * this method is used to save transaction id in database
     * 
     * @param gsptrnsId
     * @param gstnTransId
     * @param refId 
     * @param fileId
     */
    @SuppressWarnings("unchecked")
    @Override
    public void updateGstnTranId(String gsptrnsId, String transid,String gstinNum, String refId, long chunkId) 
    {
        logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
            +Constant.LOGGER_METHOD+" updateGstnTranId()");
      
        try {
        	updateGstnTranId( gsptrnsId,  transid, gstinNum,  refId,  chunkId) ;
        
        } catch (Exception exec) {
            logger.error(Constant.LOGGER_ERROR + CLASS_NAME
                +Constant.LOGGER_METHOD+" updateGstnTranId()" ,exec);
        }
        logger.info(Constant.LOGGER_EXITING + CLASS_NAME
            +Constant.LOGGER_METHOD+" updateGstnTranId()");
    }
    
	@Override
	public void updateGstinList(int fileId) {
		 logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
		            +Constant.LOGGER_METHOD+" updateGstinList(fileId)");
		 
		 try{
			 tblgstinlistDao.updateGstinList(fileId);
			 }
		 catch(Exception ex){
			 logger.error("*********** ERROR in method  for fileId ",ex);
		 }
		 
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Object[]> getGSTINListEligibleForGstr2A(){
		
		List<Object[]> listItem=new ArrayList<>();
		
		try{
		String strQuery=" select distinct gstinList.GSTIN,gstinList.taxPeriod,gstinList.fileId from  "
				+ "etl.tblGSTINList gstinList, master.tblGstinReturnFilingStatus returnFilingStatus "
				+ "where gstinList.GSTIN = returnFilingStatus.GstinId and gstinList.TaxPeriod = returnFilingStatus.TaxPeriod "
				+ "and returnFilingStatus.status<>'Filed' and returnFilingStatus.returnType='Gstr1' and gstinList.updatedDate < getdate()";
		
		listItem = (List<Object[]>) hibernateDao.executeNativeSql(strQuery,new Object[]{});;
		
		} catch (Exception e) {
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME + " Method : getGSTINListEligibleForGstr2A()",e);
			}
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : getGSTINListEligibleForGstr2A()");
		}
		return listItem;
	}
	
}
