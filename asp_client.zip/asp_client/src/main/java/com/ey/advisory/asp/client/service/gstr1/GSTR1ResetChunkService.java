package com.ey.advisory.asp.client.service.gstr1;

import java.util.List;

import org.json.simple.JSONObject;

/**
 * @author Sailendar.Bongani
 *
 */
public interface GSTR1ResetChunkService {

	String resetGSTR1Chunks(JSONObject jsonObject);

}
