package com.ey.advisory.asp.client.dao;

import java.util.List;
import java.util.Map;

import com.ey.advisory.asp.client.domain.BankAccountDetails;
import com.ey.advisory.asp.client.domain.CashITCUtilization;
import com.ey.advisory.asp.client.domain.CashUtilizationTransaction;
import com.ey.advisory.asp.client.domain.FIleSubmissionStatusDetails;
import com.ey.advisory.asp.client.domain.Gstr3RefundDetails;
import com.ey.advisory.asp.client.domain.Gstr3TurnoverDetails;
import com.ey.advisory.asp.client.domain.ReturnSubmissionStatus;
import com.ey.advisory.asp.client.dto.GSTR3RootDTO;
import com.ey.advisory.asp.client.dto.Gstr3Dto;
import com.ey.advisory.asp.dto.GSTR3InterestLiablityDto;
import com.ey.advisory.asp.exception.DataException;


public interface Gstr3Dao {
	
	public String  saveTurnoverDetials(Gstr3TurnoverDetails gstr3TurnoverDetails);
	public Gstr3TurnoverDetails getTurnoverDetials(Gstr3Dto gstr3Dto);
	public String saveGstr3CashLegderDetails(String gstn,String jsonCashGstr3Data, String rtPeriod);
	public String saveGstr3ITCLegderDetails(String gstn,String jsonITCGstr3Data, String rtPeriod);
	String saveGstr3LiabilityLedgerDetail(String gstn, String rtPeriod, String jsonGstr3Data);
	public String saveCashUtilizationTransaction(Gstr3Dto gstr3Dto);
	
	public List<String> getCashAutoFill(String gstn,String rtDate);
	
	public String saveReturnSubmissionStatus(ReturnSubmissionStatus rtSubmissionStatus);
	public boolean updateFileStatus(Gstr3TurnoverDetails gstr3TurnoverDetails);
	String saveFileStatus(FIleSubmissionStatusDetails fIleSubmissionStatus);
	List<ReturnSubmissionStatus> getITCCashDetials(Gstr3Dto gstr3Dto);
	List<ReturnSubmissionStatus> fetchITCCashDetails(Gstr3Dto gstr3Dto);
	

	List<FIleSubmissionStatusDetails> getFileGstr3Status(Gstr3Dto gstr3Dto);
	
	public List<CashUtilizationTransaction> getCashUtilizationTransaction(Gstr3Dto gstr3Dto);
	
	//View liabilitity,cash, itc details
	
	public String getLiabilityPosition(Gstr3Dto gstr3Dto);
	public String getLiabilityDetails(Gstr3Dto gstr3Dto);
	public String getCashPosition(Gstr3Dto gstr3Dto);
	public String getITCPosition(Gstr3Dto gstr3Dto);
	public boolean isPreviousTaxPeriodFiled(Gstr3Dto gstr3Dto);
	public String getConsCashTransaction(Gstr3Dto gstr3Dto);
	
	public String saveRefundDetails(Gstr3RefundDetails gstr3RefundDetails);
	List<BankAccountDetails> fetchBankAccDetails(String gstin);
	public String autoFillItc(Gstr3Dto gstr3Dto);
	public String saveItc(Gstr3Dto gstr3Dto);
	public String submitItc(Gstr3Dto gstr3Dto);
	public String getItcBalance(Gstr3Dto gstr3Dto);
	Gstr3RefundDetails getRefundDetail(Gstr3RefundDetails gstr3RefundDetails);
	public List<String> checkISDGstin(String gstin);
    public String getInterestLiabilitySaved(Gstr3Dto gstr3Dto);
    public String saveGstr3Details(int masterId,GSTR3RootDTO gstr3Dto) throws DataException;
	public String getSummaryJSON(Gstr3Dto gstr3dto) throws DataException;
	public boolean fetchRecordfromDB(Gstr3Dto gstr3Dto) throws DataException; 
	public int findMasterDetails(Gstr3Dto gstr3Dto) throws DataException;
	public boolean saveInterestLiability(GSTR3InterestLiablityDto dto);
	public boolean updateInterestLiabilitySubmit(String refId,Gstr3Dto gstr3Dto); 
	
	public String saveCashItcBalance(String cashITCJson,String gstin, String taxPeriod);
	public String saveEditedCashItcDetails(String cashITCJson);
	public List<CashITCUtilization> getEditedCashItcDetails(String gstinId, String taxPeriod);
	
	public String updateActiveStatus(Gstr3Dto gstr3dto);
	public Map<String, String> isSubmitGSTR3FormSection(Gstr3Dto gstr3Dto) throws DataException; 
	
	 public boolean updateSetoffLiabilitySubmit(String refId, Gstr3Dto gstr3dto);
	 public boolean updateGstr3Submit(String gstin, String taxperiod);
	 
	 public boolean insertGstr3GenerateData(String refId, Gstr3Dto gstr3dto);
	 public Map<String, Boolean> isGtsr1AndGstr2Filed(Gstr3Dto gstr3dto);
	 
	 public boolean isGSTR3Generated(Gstr3Dto gstr3Dto);
}
