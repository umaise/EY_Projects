/**
 * 
 */
package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Uma.Chandranaik
 *
 */
@Entity
@Table(name="tblCashITCLedgerMaster", schema="gstr3")
public class CashITCLedgerMaster  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private Long cashItcMasterId;

	@Column(name="GSTIN")
	private String GSTIN;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="IsActive")
	private boolean isActive;
	
	@Column(name="IsSaved")
	private boolean isSaved;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
	@Column(name="CreatedOn")
	private Date createdOn;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss") 
	@Column(name="ModifiedOn")
	private Date modifiedOn;

	public Long getCashItcMasterId() {
		return cashItcMasterId;
	}

	public void setCashItcMasterId(Long cashItcMasterId) {
		this.cashItcMasterId = cashItcMasterId;
	}

	public String getGSTIN() {
		return GSTIN;
	}

	public void setGSTIN(String gSTIN) {
		GSTIN = gSTIN;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public boolean isSaved() {
		return isSaved;
	}

	public void setSaved(boolean isSaved) {
		this.isSaved = isSaved;
	}
	
	
	
}
