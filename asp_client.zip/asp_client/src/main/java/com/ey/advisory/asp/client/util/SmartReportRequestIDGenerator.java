package com.ey.advisory.asp.client.util;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.client.domain.SmartReport;
import com.ey.advisory.asp.client.service.SmartReportService;

@Component
public class SmartReportRequestIDGenerator implements IdentifierGenerator{
	
	@Autowired
	private SmartReportService  smartReportService;
	
	private int defaultNumber = 1;

	@SuppressWarnings("unchecked")
	@Override
	public Serializable generate(SessionImplementor session, Object object)
			throws HibernateException {
		String reportId = "";
		String digits = "";
		SmartReport requestDetail=(SmartReport) object;
		
		try{
			
			Criteria detachedCriteria = session.getFactory().getCurrentSession().createCriteria(SmartReport.class);
			detachedCriteria.addOrder(Order.desc("createdDate"));
			detachedCriteria.setFirstResult(0);
			detachedCriteria.setMaxResults(1);
			List<SmartReport> revisedDebitList=(List<SmartReport>)(List<SmartReport>)detachedCriteria.list();
			if (revisedDebitList != null && revisedDebitList.size()>0) {
				reportId=revisedDebitList.get(0).getReportId();
				    String prefix = reportId.substring(0, 4);
				    String str[] = reportId.split(prefix);
				    digits = String.format("%05d", Integer.parseInt(str[1]) + 1);
				    reportId = requestDetail.getTaxPeriod().concat(digits);
				   } else {
				    digits = String.format("%05d", defaultNumber);
				    reportId = requestDetail.getTaxPeriod().concat(digits);
				   }

			}catch(Exception e){
				System.out.println("Exception " + e);
			}
	
		return reportId;
	}

}
