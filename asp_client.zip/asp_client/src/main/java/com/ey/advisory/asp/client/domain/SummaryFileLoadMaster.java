package com.ey.advisory.asp.client.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblSummaryFileLoad",schema="etl")
public class SummaryFileLoadMaster {

	@Id
	@Column(name = "SummaryFileID")
	private int summaryFileId;
	
	@Column(name="FileName")
	private String fileName;
	
	@Column(name="FilePath")
	private String filePath;
	
	@Column(name="Content")
	private String content;
	
	@Column(name="FileType")
	private String fileType; 
	
	@Column(name="IsActive")
	private Character isActive;
	
	@Column(name="IsDuplicate")
	private Character isDuplicate;
	
	@Column(name="FileHash")
	private String fileHash; 
	
	@Column(name="CountofRecInFile")
	private int countRec;
	
	@Column(name = "UploadDate")
	private	Date createdDate;
	
	@Column(name="CreatedBy")
	private String createdBy;
	
	@Column(name="UpdatedDate")
	private Date updatedDate;
	
	@Column(name="UpdatedBy")
	private String updatedBy;
	
	@Column(name = "Status")
	private String status;
	
	@Column(name="UserID")
	private int userid;

	public int getSummaryFileId() {
		return summaryFileId;
	}

	public void setSummaryFileId(int summaryFileId) {
		this.summaryFileId = summaryFileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Character getIsActive() {
		return isActive;
	}

	public void setIsActive(Character isActive) {
		this.isActive = isActive;
	}

	public Character getIsDuplicate() {
		return isDuplicate;
	}

	public void setIsDuplicate(Character isDuplicate) {
		this.isDuplicate = isDuplicate;
	}

	public String getFileHash() {
		return fileHash;
	}

	public void setFileHash(String fileHash) {
		this.fileHash = fileHash;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public int getCountRec() {
		return countRec;
	}

	public void setCountRec(int countRec) {
		this.countRec = countRec;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
	
}
