package com.ey.advisory.asp.client.service.gstr6;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
//import org.codehaus.plexus.util.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import redis.clients.jedis.exceptions.JedisConnectionException;

import com.ey.advisory.asp.client.dao.GSTR6Dao;
import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.InvoiceDao;
import com.ey.advisory.asp.client.dao.ReportDao;
import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.domain.FIleSubmissionStatusDetailsGstr6;
import com.ey.advisory.asp.client.domain.FileUploadMasterClient;
import com.ey.advisory.asp.client.domain.GSTR6CDNInvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR6FB2BAInvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR6FB2BInvoiceDetailsModel;
import com.ey.advisory.asp.client.domain.GSTR6FCDNAInvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR6FCDNInvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR6FDRB2BAInvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR6FDRB2BInvoiceDetails;
import com.ey.advisory.asp.client.domain.GSTR6FDRCDNAInvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR6FDRCDNInvoiceDetail;
import com.ey.advisory.asp.client.domain.GSTR6TurnoverDetailsPriorFY;
import com.ey.advisory.asp.client.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.MasterTable;
import com.ey.advisory.asp.client.domain.OutwardInvoiceModel;
import com.ey.advisory.asp.client.domain.ReconciliationDetailsDrDTO;
import com.ey.advisory.asp.client.domain.ReconciliationStatusDTO;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.client.domain.TblSalesErrorInfo;
import com.ey.advisory.asp.client.domain.TblTurnoverDetails;
import com.ey.advisory.asp.client.domain.TblTurnoverMaster;
import com.ey.advisory.asp.client.dto.AuthDetailsDto;
import com.ey.advisory.asp.client.dto.GSTTurnoverWrapper;
import com.ey.advisory.asp.client.dto.Gstr6Dto;
import com.ey.advisory.asp.client.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.client.dto.PreGSTTurnOverDto;
import com.ey.advisory.asp.client.dto.PreGSTTurnOverWrapper;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.client.service.ClientFileUploadService;
import com.ey.advisory.asp.client.service.ClientSpCallService;
import com.ey.advisory.asp.client.service.CommonApiService;
import com.ey.advisory.asp.client.service.InvoiceService;
import com.ey.advisory.asp.client.service.gstr2.Gstr2ServiceImpl;
import com.ey.advisory.asp.client.service.master.MasterTableService;
import com.ey.advisory.asp.client.util.AuthenticationUtility;
import com.ey.advisory.asp.client.util.CommonUtillity;
import com.ey.advisory.asp.client.util.ErrorActionUtility;
import com.ey.advisory.asp.client.util.GSTNRestClientUtility;
import com.ey.advisory.asp.common.Constant;
import com.ey.advisory.asp.dto.InvoiceProcessDto;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import redis.clients.jedis.exceptions.JedisConnectionException;


@Service
@PropertySource("classpath:RestConfig.properties")
@Transactional
public class Gstr6ServiceImpl implements Gstr6Service {
	@Autowired
    private ReportDao reportDao;

	@Autowired
	private GSTR6Dao gstr6Dao;

	@Autowired
	private InvoiceDao invoiceDao;

	@Autowired
	ErrorActionUtility errorActionUtility;

	@Autowired
	ClientSpCallService clientSpCallService;

	@Autowired
	private Environment env;

	@Autowired
	HibernateDao hibernateDao;
	
	 @Autowired
	 ClientFileUploadService clientFileUploadService;

	@Autowired
	AuthenticationUtility authenticationUtility;
	
	@Autowired
	private InvoiceService invoiceService;

	@Autowired(required = false)
	private RedisTemplate redisTemplate;

	@Autowired
	private MasterTableService masterTableService;

	@Resource(name = "${api.call}")
	private CommonApiService commonApiService;

	@Autowired
	private ReturnFilingDao returnFilingDao;	
	
	@Autowired
	GSTNRestClientUtility restClientUtility;
	
	@Autowired
	ReconStatusGstr6Service reconStatusService;
	

	private static final Logger LOGGER = Logger.getLogger(Gstr6ServiceImpl.class);
	private static final String CLASS_NAME = Gstr6ServiceImpl.class.getName();

	@Override
	public Map testServiceMethod(List<Object> GSTIN){
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("res" );
		}
		return null;
	}

	@Override
	public String signfileGstr6(String gstin, String month, String year) {

		LOGGER.info("Entering " + CLASS_NAME + " Method : signfileGstr3");
		String jsonDataValue = "";

		String result = commonApiService.signfileGstr6(gstin, month, year);

		try {
			jsonDataValue=fetchDecodedJsonFromStub(result);
			LOGGER.info("Exiting " + CLASS_NAME + " Method : signfileGstr3");
			return jsonDataValue;
		} catch (Exception e) {
			LOGGER.error("Exiting " + CLASS_NAME + " Method : signfileGstr3",e);
			return e.getMessage();
		}

	}

	@Override
	public String fileGSTR6(SummaryDto summarydto) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : fileGSTR6");
		String acknowledge = "";
		try {

			AuthDetailsDto authDetails = authenticationUtility
					.validateAuthToken("");
			SummaryDto finalDto = authenticationUtility.encryptPayloadData(
					summarydto, authDetails);
			String jsonDataValue = authenticationUtility
					.executeRestCallGSTNPost(authenticationUtility
							.fileGstrReqPayload(finalDto, Constant.RETSUBMIT),
							Constant.RETURNS, true, Constant.GSTR3);
			authDetails = authenticationUtility.getRek(jsonDataValue,
					authDetails);
			acknowledge = authenticationUtility.getPayloadForGSTN(
					jsonDataValue, authDetails);
			returnFilingDao.insertReturnFilingData(summarydto.getGstinId(),
					Constant.MAILSTATUS_RETURNTYPE_GSTR6, summarydto.getTaxPeriod(),
					acknowledge);
		} catch (Exception ex) {
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : fileGSTR6",ex);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : fileGSTR6");
		return acknowledge;
	}



	@Override
	public String getReturnFilingSuccess(String gstinId, String rtPeriod) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+" getReturnFilingSuccess");
		String isFilingAllowed = returnFilingDao.getReturnFilingSuccess(gstinId, Constant.GSTR_6, rtPeriod);
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getReturnFilingSuccess");
		return isFilingAllowed;
	}

	@Override
	public String GSTR6Summary(String gstinId, String month, String year) {
		LOGGER.info("Entering " + CLASS_NAME + " Method : gstr6Summary");
		String jsonDataValue = "";

		String result = commonApiService.gstr6Summary(Constant.RETSUM,gstinId, month, year);
		try {

			jsonDataValue=fetchDecodedJsonFromStub(result);
			LOGGER.info("Exiting " + CLASS_NAME + " Method : GSTR6Summary");
			return jsonDataValue;
		} catch (Exception e) {
			LOGGER.error("Exiting " + CLASS_NAME + " Method : GSTR6Summary",e);
			return e.getMessage();
		}
	}

	/*@Override
	public String getGSTR6SummaryfromDB(String gstinId, String rtPeriod) {
		LOGGER.info("Entering " + CLASS_NAME + " Method : getGSTR6SummaryfromDB");
		List<?> result = null;
		StringBuilder json = new StringBuilder();
		Object[] obj = new Object[2];
		obj[0] = gstinId.trim();
		obj[1] = rtPeriod.trim();
		try {

			result = hibernateDao.executeNativeSql(" exec gstr6.UspViewSummary ?, ? ", obj);
			if(result!=null && !result.isEmpty()){
				json = new StringBuilder();
				for(int i=0;i<result.size();i++){
					json.append(result.get(i));
				}
			}
		} catch (Exception e) {
			LOGGER.error(Constant.LOGGER_ERROR +" getGSTR6SummaryfromDB method of "+CLASS_NAME,e);
			return null;
		}
		LOGGER.info("Exiting " + CLASS_NAME + " Method : getGSTR6SummaryfromDB");
		return json.toString();
	}*/
	
	@Override
    public Object getGSTR6SummaryfromDB(String gstn, String taxPeriod) {
        LOGGER.info("Entering " + CLASS_NAME + " Method : getGSTR2SummaryfromDB");
        List<?> result = null;
        StringBuilder json = new StringBuilder();
        Object[] obj = new Object[2];
        obj[0] = gstn;
        obj[1] = taxPeriod;
        try {

            result = hibernateDao.executeNativeSql(
                " exec dbo.uspGetGSTR6SummaryDetails ?, ? ", obj);
            if(result!=null && !result.isEmpty()){
                json = new StringBuilder();
                for(int i=0;i<result.size();i++){
                    json.append(result.get(i));
                }
            }
        } catch (Exception e) {
        	LOGGER.error(e);
        }
        LOGGER.info("Exiting " + CLASS_NAME + " Method : getGSTR2SummaryfromDB");
        return json.toString();
    }

	@Override
	public TblGstinRetutnFilingStatus getGStrReturnFilingDetails(String gstinId, String rtPeriod, String gstr6) {
		return returnFilingDao.fetchGstrReturnDetails(gstinId, rtPeriod,gstr6);
	}

	private String fetchDecodedJsonFromStub(String json){
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject=null;
		String finalJsonData="";
		try {
			jsonObject = (JSONObject) jsonParser.parse(json);
		} catch (ParseException e1) {
			LOGGER.error(e1);
			return null;
		}
		LOGGER.error("Before Starting stubs" + jsonObject);
		try{
			if (jsonObject.containsKey(Constant.REK) && jsonObject.containsKey(Constant.DATA) && jsonObject.containsKey(Constant.STATUS_CD)) {
				String rek = (String) jsonObject.get(Constant.REK);
				String data = (String) jsonObject.get(Constant.DATA);
				String status_cd = (String) jsonObject.get(Constant.STATUS_CD);
				if ("1".equals(status_cd)) {
					String apiKey = authenticationUtility.getBusinessTypeDetailsFromGSTN(rek,Constant.SESSION_KEY.getBytes());
					finalJsonData = authenticationUtility.getBusinessTypeDetailsFromGSTN(data,apiKey.getBytes());
					LOGGER.info(finalJsonData);
				} 
			}
			return finalJsonData;
		}catch(Exception e){
			LOGGER.error(Constant.LOGGER_ERROR+Constant.LOGGER_METHOD+CLASS_NAME+"fetchDecodedJsonFromStub",e);
			return null;
		}
	}

	@Override
	public boolean saveGstr6InvoiceStatus(Set<InvoiceProcessDto> invoice,Integer fileId) {
		return invoiceDao.saveGstr2InvoiceStatus(invoice,fileId);
	}


	@Override
	public boolean saveIsdErrorInfo(Set<TblIsdErrorInfo> errorInfo) {
		return invoiceDao.saveIsdErrorInfo(errorInfo);
	}
	private boolean saveMailStatusDetailsInfo(Set<TblIsdErrorInfo> errorList) {

		Set<String> gstinList = new HashSet<>();
		boolean status = Boolean.TRUE;
		for (TblIsdErrorInfo tblIsdErrorInfo : errorList) {
			if(tblIsdErrorInfo.getGstin() != null && !tblIsdErrorInfo.getGstin().isEmpty()){
				gstinList.add(tblIsdErrorInfo.getGstin());
			}	
		}
		if(!gstinList.isEmpty()){	
			status = invoiceDao.saveMailStatusDetailsInfo(gstinList, Constant.MAILSTATUS_RETURNTYPE_GSTR6);
		}
		
		return status;
	}

	/*
	 * validateGST6Rules.
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public void validateGSTR6Rules(InwardInvoiceGstr6DTO inwardInvoiceDTO, Class<?> clsEntity, String docNum, String docDate) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : validateGSTR6Rules");
		try {
			if (inwardInvoiceDTO != null) {
				// Rule : BR_RAW_IF_28
				List<?> invoiceList ;
				invoiceList = validateOriginalDocNoDocDate(inwardInvoiceDTO, clsEntity.getSimpleName(), docNum, docDate);

				if(invoiceList != null && !invoiceList.isEmpty()) {
					Class<?> noparams[] = {};
					for(Object invoiceDetail : invoiceList){                                    
						Method method = clsEntity.getDeclaredMethod("getTaxPeriod", noparams);
						String taxPeriod = (String)method.invoke(invoiceDetail, null);
						validateInvoiceDate(inwardInvoiceDTO, taxPeriod);
					}
				}

				//Rule : BR_RAW_IF_30
				isValidITCDate(inwardInvoiceDTO);
			}
		}catch (Exception e) {
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : validateGSTR2Rules", e);
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : validateGSTR2Rules");
	}

	public <T> List<T> validateOriginalDocNoDocDate(InwardInvoiceGstr6DTO inwardInvoiceDTO, String entityName,
			String column1, String column2) {

		List<T> entityList = null;

		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : validateOriginalDocNoDocDate()");

		if (inwardInvoiceDTO.getLineItemList() != null
				&& !inwardInvoiceDTO.getLineItemList().isEmpty()) {
			InwardInvoiceModel lineItem = inwardInvoiceDTO.getLineItemList()
					.get(0);
       
			try {
				  SimpleDateFormat dateString = new SimpleDateFormat();
			     java.util.Date docDate =  dateString.parse(lineItem.getDocumentDateStr());
				if(lineItem.getDocumentDate() != null && lineItem.getDocumentDateStr()!=null){   
					entityList = gstr6Dao.validateOriginalDocNoDocDate(lineItem.getOriginalDocumentNo(),
							docDate, entityName, column1, column2);
				}
			} catch (Exception e) {
				LOGGER.info(
						Constant.LOGGER_ERROR
						+ CLASS_NAME
						+ " Method : validateOriginalDocNoDocDate(). Unable to validate Original Doc Num for Invoice: "
						+ lineItem.getId(), e);
			}
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : validateOriginalDocNoDocDate()");

		return entityList;

	}


	public void validateInvoiceDate(InwardInvoiceGstr6DTO inwardInvoiceDTO, String taxperiod){
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : validateInvoiceDate()");

		Date annualFilingDate = null;
		InwardInvoiceModel lineItem = inwardInvoiceDTO.getLineItemList().get(0);
		Date documentDate = null;
		if(lineItem.getDocumentDate() != null){
			documentDate = (Date) lineItem.getDocumentDate();
		}

		Date cutOffStartDate = getCutOffStartDate(documentDate);
		Date cutOffEndDate = getCutOffEndDate(documentDate);
		Date taxPeriodDate = null;
		try {
			taxPeriodDate = (Date) CommonUtillity.getDateByPattern(taxperiod);
			annualFilingDate = (Date) returnFilingDao.getReturnFilingDate(getFY(documentDate),
					lineItem.getSGSTIN(), Constant.GSTR9);
		} catch (Exception e) {
			LOGGER.info(
					Constant.LOGGER_ERROR
					+ CLASS_NAME
					+ " Method : validateInvoiceDate(). Unable to validate Date for Invoice: "
					+ lineItem.getId(), e);
		}

		if(annualFilingDate != null && annualFilingDate.before(cutOffEndDate)){
			cutOffEndDate = annualFilingDate;
		}

		if(taxPeriodDate!=null && taxPeriodDate.after(cutOffStartDate) && taxPeriodDate.before(cutOffEndDate)){
			inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
			lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
			if(lineItem.getDocumentType().equals(Constant.CR)) {
				setErrorList(inwardInvoiceDTO,lineItem, "ER0011", "Document No, Document Date","Business Rule", Boolean.FALSE);
			} else if(lineItem.getDocumentType().equals(Constant.DR)) {
				setErrorList(inwardInvoiceDTO,lineItem, "ER0012", "Document No, Document Date","Business Rule", Boolean.FALSE);
			} else{
				setErrorList(inwardInvoiceDTO,lineItem, "ER007", "Document No, Document Date","Business Rule", Boolean.FALSE);
			}
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+ " Method : validateInvoiceDate()");
	}


	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public InwardInvoiceGstr6DTO isValidITCDate(InwardInvoiceGstr6DTO inwardInvoiceDTO) {
		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : isValidITCDate()");
		Date annualFilingDate = null;
		InwardInvoiceModel lineItem = inwardInvoiceDTO.getLineItemList().get(0);
		Date cutOffdate = getCutOffdateForITC((Date) lineItem.getOriginalDocumentDate());
		Date documentDate = null;

		if(lineItem.getDocumentDate() != null){
			documentDate = (Date) lineItem.getDocumentDate();
		}

		Date itcDate = documentDate;

		try {
			annualFilingDate = (Date) returnFilingDao.getReturnFilingDate(
					getFY((Date) lineItem.getOriginalDocumentDate()),
					lineItem.getCGSTIN(), Constant.GSTR9);
		} catch (Exception e) {
			LOGGER.info(
					Constant.LOGGER_ERROR
					+ CLASS_NAME
					+ " Method : isValidITCDate(). Unable to validate Input Tax Credit for Invoice: "
					+ lineItem.getId(), e);
		}

		if (cutOffdate != null) {
			if (annualFilingDate != null && annualFilingDate.before(cutOffdate)) {
				cutOffdate = annualFilingDate;
			}
			if (itcDate!=null && itcDate.after(cutOffdate)) {
				inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
				lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
				setErrorList(inwardInvoiceDTO, lineItem, "ER044", "Input Tax credit","Business Rule", Boolean.FALSE);
			}
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : isValidITCDate()");

		return inwardInvoiceDTO;
	}


	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public <T> List<T> validateOriginalDocumentNoAndDate(InwardInvoiceGstr6DTO inwardInvoiceDTO,
			String entityName, String columnName1, String columnName2) {

		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+Constant.LOGGER_METHOD+" validateOriginalDocumentNo()");

		List<T> entityList = null;
		if (inwardInvoiceDTO.getLineItemList() != null
				&& !inwardInvoiceDTO.getLineItemList().isEmpty()) {
			InwardInvoiceModel lineItem = inwardInvoiceDTO.getLineItemList()
					.get(0);


			try {
				String docType = lineItem.getDocumentType();
				if(docType.equals(Constant.CR)||docType.equals(Constant.DR)||docType.equals(Constant.RNV)||docType.equals(Constant.RCR)||docType.equals(Constant.RDR)){
					entityList = gstr6Dao.validateOriginalDocNoDocDate(
							lineItem.getOriginalDocumentNo(),lineItem.getOriginalDocumentDate(), entityName,
							columnName1,columnName2);

					if (entityList == null || entityList.isEmpty()) {
					/*	if((lineItem.getDocumentType().equals(Constant.CR) || lineItem.getDocumentType().equals(Constant.DR)) && 
								lineItem.getcRDRPreGST()!=null && (lineItem.getcRDRPreGST().equalsIgnoreCase(Constant.Y) || lineItem.getcRDRPreGST().equalsIgnoreCase(Constant.YES))){
							outwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "IN023", Constant.ORG_DOC_NO, Constant.BUSINESS_RULE, Boolean.TRUE, Constant.INVOICE));
						} else {*/
						inwardInvoiceDTO.setInvStatus(Constant.BUS_RULE_ERROR);
							lineItem.setItemStatus(Constant.BUS_RULE_ERROR);
							
							//errorActionUtility.getIsdTblErrorInfo(isdStagingId, errorInfoCode, errorColumnName, processStatus, isProcessed, invoiceNum, gstin, incidenceLevel)
							inwardInvoiceDTO.getErrorList().add(errorActionUtility.getIsdTblErrorInfo(lineItem, "ERR227", Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE, Constant.INVOICE));
							/*if(lineItem.getDocumentType().equals(Constant.RCR)) {
								inwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER011", Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
							} else if(lineItem.getDocumentType().equals(Constant.RDR)) {
								inwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER012", Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE,Constant.INVOICE));
							} 
							else{
								inwardInvoiceDTO.getErrorList().add(errorActionUtility.getSalesTblErrorInfo(lineItem, "ER007", Constant.ORG_DOC_NO,Constant.BUSINESS_RULE, Boolean.FALSE, Constant.INVOICE));
							}*/
						}
					
				}
		
				}
			 catch (Exception e) {
				LOGGER.info(
						Constant.LOGGER_ERROR
						+ CLASS_NAME
						+Constant.LOGGER_METHOD+" validateOriginalDocumentNo(). Unable to validate Original Doc Num for Invoice: "
						+ lineItem.getId(), e);
			}
		}
		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
				+Constant.LOGGER_METHOD+" validateOriginalDocumentNo()");

		return entityList;

	}

	private Date getCutOffStartDate(Date documentDate) {
		if(documentDate != null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(documentDate);
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);

			if(month < Calendar.OCTOBER){
				cal.set(year-1, Constant.CUTOFF_START_MONTH, Constant.CUTOFF_START_DATE);
			}else{
				cal.set(year, Constant.CUTOFF_START_MONTH, Constant.CUTOFF_START_DATE);
			}
			return (Date) cal.getTime();
		}
		return null;
	}

	private Date getCutOffEndDate(Date documentDate){
		if(documentDate != null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(documentDate);
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			cal.set(year, month-1, 1);
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			return (Date) cal.getTime();
		}
		return null;
	}

	private String getFY(Date originalDocumentDate) {
		String fy = null;
		if(originalDocumentDate != null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(originalDocumentDate);
			int month = cal.get(Calendar.MONTH);
			int year = cal.get(Calendar.YEAR);
			if(month < Calendar.APRIL){
				fy = String.valueOf(year - 1)+String.valueOf(year);
			}else{
				fy = String.valueOf(year)+String.valueOf(year+1);
			}
		}
		return fy;
	}

	public void setErrorList(InwardInvoiceGstr6DTO inwardInvoiceDTO, InwardInvoiceModel lineItem, String errorInfoCode,
			String errorColumnName, String processStatus, boolean isProcessed) {
		if(inwardInvoiceDTO.getErrorList() == null){
			inwardInvoiceDTO.setErrorList(new HashSet<TblIsdErrorInfo>());
		}

//		inwardInvoiceDTO.getErrorList().add(errorActionUtility.getPurchaseTblErrorInfo(lineItem.getId(), errorInfoCode, errorColumnName, 
//				processStatus, isProcessed,lineItem.getDocumentNo(), lineItem.getCompanyGSTIN(),Constant.INVOICE));

	}


	private Date getCutOffdateForITC(Date documentDate) {
		if(documentDate != null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(documentDate);
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			if(month < Calendar.APRIL){
				cal.set(year, Constant.CUTOFF_END_MONTH, Constant.CUTOFF_END_DATE);
			}else{
				cal.set(year+1,Constant.CUTOFF_END_MONTH, Constant.CUTOFF_END_DATE);
			}
			return (Date) (cal.getTime());
		}
		return null;
	}


	public boolean isValidTaxPeriod(String origTaxPeriod, String amendTaxPeriod) throws java.text.ParseException {
		if(origTaxPeriod != null && !origTaxPeriod.isEmpty() && amendTaxPeriod != null && !amendTaxPeriod.isEmpty()){
			Calendar orig = Calendar.getInstance();
			Calendar amend = Calendar.getInstance();

			orig.setTime(CommonUtillity.getDateByPattern(origTaxPeriod));
			amend.setTime(CommonUtillity.getDateByPattern(amendTaxPeriod));

			if((orig.get(Calendar.YEAR) + 1 == amend.get(Calendar.YEAR) && orig.get(Calendar.MONTH) > Calendar.APRIL)
					|| (orig.get(Calendar.YEAR) == amend.get(Calendar.YEAR) && orig.get(Calendar.MONTH) < amend.get(Calendar.MONTH))){
				return true;
			}
		}
		return false;
	}


	private boolean valideITCEligibility(final GSTR6CDNInvoiceDetail cdnDetail) {

		if((cdnDetail.getItcCessAmt() == null || cdnDetail.getItcCessAmt() == 0) &&
				(cdnDetail.getItcCgstAmt() == null || cdnDetail.getItcCgstAmt() == 0) &&
				(cdnDetail.getItcSgstAmt() == null || cdnDetail.getItcSgstAmt() == 0) &&
				(cdnDetail.getItcIgstAmt() == null || cdnDetail.getItcIgstAmt() == 0)) {
			return false;
		}
		return true;
	}

	@Override
	public List<Object> getHSNSACDetailsfromMaster(String key) {

		MasterTable masterTable= new MasterTable();
		masterTable.setKey(key);
		return masterTableService.getMasterTableDetails(masterTable);
	}

	@Override
	public ItemMaster getSpecifcHSNSACDetails(String hsnSac) {
		return gstr6Dao.fetchHsnSacDetails(hsnSac);
	}



	@Override
	public GlobalGSTRatesMasterI getSpecifcHSNSACDetailsfromglobal(String hsnSac) {
		// TODO Auto-generated method stub
		return gstr6Dao.fetchHsnSacDetailsFromGlobal(hsnSac);
	}

	@Override
	@Transactional
	public boolean updateReconFilingStatus(Set<ReconciliationStatusDTO> reconStatusSet) {/*

		LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : updateReconFilingStatus()");

		try{
			for(ReconciliationStatusDTO dto : reconStatusSet) {
				if(dto.getTableType() != null && !dto.getTableType().isEmpty()){
					String entityName  = dto.getTableType();

					switch (entityName) {
					case Constant.B2B:
						GSTR6FB2BInvoiceDetailsModel b2bInvoice = gstr6Dao.getReconInvoice(Constant.ENTITY_GSTR6FB2B_InvoiceDetail, "invoiceDetailsId",dto.getInvoiceDetailsId());
						if(b2bInvoice != null){
							b2bInvoice.setFilingStatus(dto.getFilingStatus());
							gstr6Dao.updateReconFilingStatus(b2bInvoice);
						}
						if(dto.getDistributionRegister() !=null ){
							for(ReconciliationDetailsDrDTO detailsDrDto : dto.getDistributionRegister()){
								GSTR6FDRB2BInvoiceDetails b2bInvoiceDR = gstr6Dao.getDRInvoice(Constant.ENTITY_GSTR6FB2B_InvoiceDetail_DR, "isdInvoices_DocNo",detailsDrDto.getIsdInvoices_DocNo(),"gstinOfReceiver",detailsDrDto.getGstinOfReceiver());
								if(b2bInvoiceDR != null){
									b2bInvoiceDR.setItcIGST(detailsDrDto.getItcIGST());
									b2bInvoiceDR.setItcCGST(detailsDrDto.getItcCGST());
									b2bInvoiceDR.setItcSGST_UTGST(detailsDrDto.getItcSGST_UTGST());
									b2bInvoiceDR.setItcCESS(detailsDrDto.getItcCGST());

									gstr6Dao.updateReconFilingStatus(b2bInvoiceDR);
								}
							}
						}
						break;

					case Constant.B2BA:
						GSTR6FB2BAInvoiceDetail b2baInvoice = gstr6Dao.getReconInvoice(Constant.ENTITY_GSTR6FB2BA_InvoiceDetail, "invoiceDetailsId",dto.getInvoiceDetailsId());
						if(b2baInvoice != null){
							b2baInvoice.setFilingStatus(dto.getFilingStatus());
							gstr6Dao.updateReconFilingStatus(b2baInvoice);
						}

						if(dto.getDistributionRegister() !=null ){
							for(ReconciliationDetailsDrDTO detailsDrDto : dto.getDistributionRegister()){
								GSTR6FDRB2BAInvoiceDetail b2bAInvoiceDR = gstr6Dao.getDRInvoice(Constant.ENTITY_GSTR6FB2BA_InvoiceDetail_DR, "isdInvoices_DocNo",detailsDrDto.getIsdInvoices_DocNo(),"gstinOfReceiver",detailsDrDto.getGstinOfReceiver());
								if(b2bAInvoiceDR != null){
									b2bAInvoiceDR.setItcIGST(detailsDrDto.getItcIGST());
									b2bAInvoiceDR.setItcCGST(detailsDrDto.getItcCGST());
									b2bAInvoiceDR.setItcSGST_UTGST(detailsDrDto.getItcSGST_UTGST());
									b2bAInvoiceDR.setItcCESS(detailsDrDto.getItcCGST());
									gstr6Dao.updateReconFilingStatus(b2bAInvoiceDR);
								}
							}
						}

						break;
					case Constant.CDN:
						GSTR6FCDNInvoiceDetail cdnInvoice = gstr6Dao.getReconInvoice(Constant.ENTITY_GSTR6FCDN_InvoiceDetail, "id", dto.getInvoiceDetailsId());
						if(cdnInvoice != null){
							cdnInvoice.setFilingStatus(dto.getFilingStatus());
							gstr6Dao.updateReconFilingStatus(cdnInvoice);
						}

						if(dto.getDistributionRegister() !=null ){
							for(ReconciliationDetailsDrDTO detailsDrDto : dto.getDistributionRegister()){
								GSTR6FDRCDNInvoiceDetail cdnInvoiceDR = gstr6Dao.getDRInvoice(Constant.ENTITY_GSTR6FCDN_InvoiceDetail_DR, "isdInvoices_DocNo",detailsDrDto.getIsdInvoices_DocNo(),"gstinOfReceiver",detailsDrDto.getGstinOfReceiver());
								if(cdnInvoiceDR != null){
									cdnInvoiceDR.setItcIGST(detailsDrDto.getItcIGST());
									cdnInvoiceDR.setItcCGST(detailsDrDto.getItcCGST());
									cdnInvoiceDR.setItcSGST_UTGST(detailsDrDto.getItcSGST_UTGST());
									cdnInvoiceDR.setItcCESS(detailsDrDto.getItcCGST());
									gstr6Dao.updateReconFilingStatus(cdnInvoiceDR);
								}
							}
						}

						break;
					case Constant.CDNA:
						GSTR6FCDNAInvoiceDetail cdnaInvoice = gstr6Dao.getReconInvoice(Constant.ENTITY_GSTR6FCDNA_InvoiceDetail, "id", dto.getInvoiceDetailsId());
						if(cdnaInvoice != null){
							cdnaInvoice.setFilingStatus(dto.getFilingStatus());
							gstr6Dao.updateReconFilingStatus(cdnaInvoice);
						}

						if(dto.getDistributionRegister() !=null ){
							for(ReconciliationDetailsDrDTO detailsDrDto : dto.getDistributionRegister()){
								GSTR6FDRCDNAInvoiceDetail cdnaInvoiceDR = gstr6Dao.getDRInvoice(Constant.ENTITY_GSTR6FCDNA_InvoiceDetail_DR, "isdInvoices_DocNo",detailsDrDto.getIsdInvoices_DocNo(),"gstinOfReceiver",detailsDrDto.getGstinOfReceiver());
								if(cdnaInvoiceDR != null){
									cdnaInvoiceDR.setItcIGST(detailsDrDto.getItcIGST());
									cdnaInvoiceDR.setItcCGST(detailsDrDto.getItcCGST());
									cdnaInvoiceDR.setItcSGST_UTGST(detailsDrDto.getItcSGST_UTGST());
									cdnaInvoiceDR.setItcCESS(detailsDrDto.getItcCGST());
									gstr6Dao.updateReconFilingStatus(cdnaInvoiceDR);
								}
							}
						}

						break;	
					default:
						break;
					}

				}
			}

		}catch(Exception e){
			LOGGER.info(Constant.LOGGER_ERROR + CLASS_NAME + " Method : updateReconFilingStatus()" ,e);
			return false;
		}

		LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME + " Method : updateReconFilingStatus()");
		return true;
	*/
		return false;}


	@Override
	public Object[] getFileGstr6Status(Gstr6Dto gstr6Dto) {
		List<FIleSubmissionStatusDetailsGstr6> fIleSubmissionStatusList= gstr6Dao.getFileGstr6Status(gstr6Dto);

		return fIleSubmissionStatusList.toArray(); 
	}

	public String getGstr6InvoiceMapping(String gstinId,String taxPeriod){
		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getGstr6InvoiceMapping");
		try{
			return (String) gstr6Dao.getInvoiceMappingDetails(gstinId,taxPeriod);
		}catch(Exception e){
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getGstr6InvoiceMapping" , e);
			return null;
		}
	}

	public List<String> fetchISDDistributionListForGstin(JSONObject jsonObj){
		try{
			return gstr6Dao.fetchISDDistributionListForGstin(jsonObj);
		}catch(Exception e){
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " fetchISDDistributionListForGstin" , e);
			return null;
		}
	}
	
	@Override
	public List<String> getErrorReportDetails(JSONObject jsonObj) {
		Object[] errorData= (Object[])gstr6Dao.getErrorReportDetails(jsonObj);
		List<String> errorDtls=new ArrayList<String>();			
		for(Object ob:errorData){
			if(ob!=null){			
				for(int i=0; i<errorData.length; i++)
					errorDtls.add(errorData[i].toString());
			}
		} 

		return	errorDtls;
	}
public List<InwardInvoiceModel> getInvoiceDocumentDetails(Set<InvoiceProcessDto> invoiceList){
		
   		return invoiceDao.getInvoiceDocumentDetail(invoiceList);
   		
   	}
   	
   	public List<InwardInvoiceModel> getCRTaxableDetails(Set<InvoiceProcessDto> invoiceList){
		
   		return invoiceDao.getCRTaxableDetail(invoiceList);
   		
   	}
   	
   	
   	public Integer getDocumentDetails(Set<InvoiceProcessDto> invoiceList){
		return invoiceDao.getDocumentDetails(invoiceList);
		
	}
   	
   	public Integer getDocumentDetails_CrDrInvDtl(Set<InvoiceProcessDto> invoiceList){
		return invoiceDao.getDocumentDetails_CrDrInvDtl(invoiceList);
		
	}
 	
 	public Integer getDocumentDetails_ITCDInvDtl(Set<InvoiceProcessDto> invoiceList){
		return invoiceDao.getDocumentDetails_ITCDInvDtl(invoiceList);
		
	}
 	
	public Object getGstr6RectifiedReportXml(JSONObject jsonObj){
   		try{
   			return reportDao.getRectifiedReportDetails(jsonObj);
   		}catch(Exception e){
   			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getGstr6RectifiedReportXml" , e);
   			return null;
   		}
   	}
	@Override
	public void setErrorList(Set<TblIsdErrorInfo> errorList, InwardInvoiceModel inwardInvoiceModel, String errorInfoCode,
			String errorColumnNames, String processStatus, boolean isProcessed, String incidenceLevel) {
		if(errorList == null){
			errorList = new HashSet<>();
		}

		errorList.add(errorActionUtility.getIsdTblErrorInfo(inwardInvoiceModel, errorInfoCode, errorColumnNames, processStatus, isProcessed,incidenceLevel));

	}	
   	public Object getDeterminationRegisterXml(String taxPeriod){
		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getDeterminationRegisterXml");
		try{
			BufferedReader br = new BufferedReader(new FileReader(new File("C:\\gst\\docs\\GSTR6\\determination\\Rev_Format_Determination_v.1.1.xml")));
			String line;
			StringBuilder sb = new StringBuilder();

			while((line=br.readLine())!= null){
				sb.append(line.trim());
			}
			System.out.println(sb.toString());
			
			return sb;
		}catch(Exception e){
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getDeterminationRegisterXml" , e);
			return null;
		}
	}
   	
   	public List<String> updateInvoiceMappedRows(JSONObject jsonObj){
   		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : updateInvoiceMappedRows");
   		try{
   			return gstr6Dao.updateInvoiceMappedRows(jsonObj);
   		}catch(Exception e){
   			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " updateInvoiceMappedRows" , e);
			return null;
   		}
   	}
   	
   	public int checkFinalInvUploadCompleted(String taxperiod,String gstin){
   		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : checkFinalInvUploadCompleted");
   		try{
   			return gstr6Dao.checkFinalInvUploadCompleted(taxperiod, gstin);
   		}catch(Exception e){
   			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " checkFinalInvUploadCompleted" , e);
			return 0;
   		}
   	}
   	
   	@Override
	public String saveTblTypeErrLstAndRoute(String key) throws Exception {
   		if (LOGGER.isInfoEnabled()) {
   			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " routing()");
		}
	
		String result = Constant.SUCCESS;
		try {
			LOGGER.info("key " + key);
			Integer fileId = Integer.parseInt(key.split("_")[1]);
			String invCountKey= key + "_" + Constant.INVOICE_COUNT;
			String invStatusKey = key + "_" + Constant.INVOICE_STATUS;
			String invErrKey = key + "_" + Constant.INVOICE_ERROR_DETAILS;
			String invPsdKey=key + "_" +Constant.INVOICE_PSD_COUNT;
			

			LOGGER.info("Before fetching from redis for file key : " + key);
			LOGGER.info("invStatusKey of redis  " + invStatusKey);
			LOGGER.info("invErrKey of redis  " + invErrKey);
			
			Integer origInvCount=(Integer) redisTemplate.opsForValue().get(invCountKey);
			Long invPsdCnt=redisTemplate.opsForHash().size(invPsdKey);
			
			List<FileUploadMasterClient> fileList=invoiceDao.getFileFromClientMaster(fileId.longValue());
			if(fileList!=null && !fileList.isEmpty()){
				FileUploadMasterClient clientFile=fileList.get(0);
				if(clientFile.getStage().equalsIgnoreCase(Constant.FILE_BIFURCATION_FLAG)){
					return Constant.DUPLICATE;
				}
			} 
			
			List<Set<InvoiceProcessDto>> invoiceListTemp=  redisTemplate.opsForHash().values(invStatusKey);
			 
			 Set<InvoiceProcessDto> invoiceList=new HashSet<InvoiceProcessDto>();
			 
			 for(Set<InvoiceProcessDto> invoiceSet : invoiceListTemp){
				 invoiceList.addAll(invoiceSet);
			 }
			
			/*Set<InvoiceProcessDto> invoiceList = (Set<InvoiceProcessDto>) redisTemplate
					.opsForHash().get(key, invStatusKey);
			Set<TblSalesErrorInfo> errorInfoList = (Set<TblSalesErrorInfo>) redisTemplate
					.opsForHash().get(key, invErrKey);*/
			 
			 List<Set<TblIsdErrorInfo>> errorList=  redisTemplate.opsForHash().values(invErrKey);
			 Set<TblIsdErrorInfo> errorInfoList=new HashSet<TblIsdErrorInfo>();
		        for(Set<TblIsdErrorInfo> errSet:errorList){
		        	errorInfoList.addAll(errSet);
		        }
		        
		        LOGGER.info("InvoiceList " + invoiceList);
		        LOGGER.info("ErrorList " + errorInfoList);

			if (errorInfoList == null && invoiceList == null) {
				LOGGER.info("Business Stage 1 Failed:");
				clientFileUploadService.updateStageOneFailStatus(key);
			} else {
				try {
					if (invoiceList != null && !invoiceList.isEmpty()) {
						LOGGER.info("InvoiceList Size" + invoiceList.size());
						saveGstr6InvoiceStatus(invoiceList, fileId);
					}
					if (errorInfoList != null && !errorInfoList.isEmpty()) {
						LOGGER.info("Error Size" + errorInfoList.size());
						if(saveIsdErrorInfo(errorInfoList)){
							if(origInvCount.equals(invPsdCnt.intValue())){
								doGSTR6Bifurcation(fileId,key);
							}else{
								timeoutAndDoGSTR6Bifurcation(fileId,key);
							}
						}	
					}else{
						if(origInvCount.equals(invPsdCnt.intValue())){
							doGSTR6Bifurcation(fileId,key);
						}else{
							timeoutAndDoGSTR6Bifurcation(fileId,key);
						}
					}
					
					
					
					/*List<String> inputParams = new ArrayList<String>();
					inputParams.add(fileId.toString());
					routingResult = clientSpCallService.executeStoredProcedure(
							Constant.Schema, Constant.Gstr1RoutingProcName,
							String.valueOf(inputParams.size()), inputParams);
					if (Constant.zero.equals(routingResult)) {
						logger.info("Routing Success:" + routingResult);
						clientFileUploadService.updateBifurcationjobStatus(key);
					}else{
						//TODO : Custom DBException
						throw new Exception("Routing procedure has an issue");
					}*/
					redisTemplate.delete(key);
					redisTemplate.delete(invStatusKey);
					redisTemplate.delete(invErrKey);
					redisTemplate.delete(invPsdKey);
					redisTemplate.delete(invCountKey);
					
					//redisTemplate.opsForHash().delete(key, invStatusKey);
					//redisTemplate.opsForHash().delete(key, invErrKey);

				} catch (Exception e) {
					LOGGER.info("Routing Failed:" + result);
					result = Constant.FAILED;
					clientFileUploadService.updateBifurcationjobFailStatus(key);
				}
			}
		}catch(JedisConnectionException jce){
			result = Constant.FAILED;
			LOGGER.error("Error fecthing the redis Connection for GSTR6--"+key, jce);
			clientFileUploadService.updateStageOneFailStatus(key); //Yet to finalise - temp fix
		}catch (Exception e) {
			result = Constant.FAILED;
			LOGGER.error("Error saving Invoice details for GSTR6--"+key, e);
			throw new Exception("Database Connection exception"); //TODO : Custom DBException
		}

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD + " saveTblTypeErrLstAndRoute()");
		}
		return result;
	}
   	
   	private void doGSTR6Bifurcation(Integer fileId,String redisKey) throws Exception{
		String routingResult = "";
		List<String> inputParams = new ArrayList<String>();
		String fileChunkId = redisKey.split("_")[2];
		inputParams.add(fileId.toString());
		inputParams.add(fileChunkId);
		routingResult = clientSpCallService.executeStoredProcedure(
				Constant.Schema, Constant.Gstr2RoutingChunkProcName,
				String.valueOf(inputParams.size()), inputParams);
		LOGGER.info("Timeout doGSTR6Bifurcation:" + routingResult);
		if (Constant.zero.equals(routingResult)) {
			LOGGER.info("Routing Success:" + routingResult);
			//clientFileUploadService.updateBifurcationjobStatus(redisKey);
		}else{
			//TODO : Custom DBException
			throw new Exception("Routing procedure has an issue");
		}
	}
	
	/**
	 * this method is used to update the Invoice status to TECH_ERROR
	 * 
	 * @param InvoiceList
	 * @param fileId
	 * 
	 * @return save status
	 */
	@Override
	public boolean timeoutAndMarkInvoiceStatusTechError(Integer fileId) throws Exception{

		return invoiceDao.markTechErrorInvoiceStatus(fileId);
	}
	
	private void timeoutAndDoGSTR6Bifurcation(Integer fileId,String redisKey) throws Exception  {
		String routingResult = "";
		String fileChunkId = redisKey.split("_")[2];
		List<String> inputParams = new ArrayList<String>();
		inputParams.add(fileId.toString());
		inputParams.add(fileChunkId);	
		routingResult = clientSpCallService.executeStoredProcedure(
		Constant.Schema, Constant.Gstr2RoutingChunkProcName,
		String.valueOf(inputParams.size()), inputParams);
		LOGGER.info("Timeout timeoutAndDoGSTR6Bifurcation Success:" + routingResult);
		if (Constant.zero.equals(routingResult)) {
			LOGGER.info("Timeout Routing Success:" + routingResult);
			invoiceService.markTechErrorInvoiceStatus(fileId);
			//clientFileUploadService.timeoutAndUpdateBifurcationjobStatus(redisKey);
			
		}else{
			throw new Exception("GSTR 6 Timeout Routing procedure has an issue");
		}

	}
	

	@Override
	public void validateOriginalDocumentNo(InwardInvoiceGstr6DTO inwardInvoiceDTO, String entityName,
			String columnName) {
		// TODO Auto-generated method stub
		
	}
		@Override
	public Object getGSTR6DeterminationSummaryfromDB(String gstn, String taxPeriod) {	
			//String result="";
			List<?> result = null;
			Object[] obj = new Object[2];
			obj[0] = gstn;
			obj[1] = taxPeriod;
			try {
				result = hibernateDao.executeNativeSql(
						" exec dbo.uspgstr6DistributionSummary ?,?",obj);
				if(result!=null){
					 return result.get(0);
				}
		    }catch(Exception e){
		    	LOGGER.error("Error in fetching determination details from DB . Method:getGSTR6DeterminationSummaryfromDB" , e);
		    	 return null;
		    }
			return null;
		}
		
	public String getGstr6DeterminationReport(String gstinId,String taxPeriod){
		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getGstr6DeterminationReport");
		try{
			return (String) gstr6Dao.getDeterminationReport(gstinId, taxPeriod);
		}catch(Exception e){
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getGstr6DeterminationReport" , e);
			return null;
		}
	}

	@Override
	public int checkHsnSac(String hsnSac) {

		return gstr6Dao.checkHsnSac(hsnSac);
	}
	
	public  List<String> saveDeterminationRowsData(JSONObject jsonObj){
   		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : saveDeterminationRowsData");
   		try{
   			return gstr6Dao.saveDeterminationRowsData(jsonObj);
   		}catch(Exception e){
   			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " saveDeterminationRowsData" , e);
			return null;
   		}
   	}
	public  List<String> submitDeterminationRowsData(JSONObject jsonObj){
   		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : submitDeterminationRowsData");
   		try{
   			return gstr6Dao.submitDeterminationRowsData(jsonObj);
   		}catch(Exception e){
   			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " submitDeterminationRowsData" , e);
			return null;
   		}
   	} 
	
	@Override
	public String getDetSummaryDownload(JSONObject jsonObj) {
		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getDetSummaryDownload");
		try{
			return (String) gstr6Dao.getDetSummaryDownload(jsonObj);			 
		}catch(Exception e){
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getDetSummaryDownload" , e);
			return null;
		}
	}
	
	@Override
	public String gstr6Reconciliation(String gstin, String taxPeriod,String groupCode,String masterId) {
		String resourceURL = env.getProperty(Constant.BATCH_API_HOST) + env.getProperty(Constant.SCHEDULE_TENANT_SIMPLE_TRIGGER);
		String responsePOSTRestCall = restClientUtility.executePOSTRestCall(resourceURL, getHeaders(),getInputData(groupCode,gstin,taxPeriod,masterId), HttpMethod.POST);
		if(!responsePOSTRestCall.trim().isEmpty() && responsePOSTRestCall.equalsIgnoreCase("Success")){
            return "Success";
     }
     else{
  	    reconStatusService.updateReconStatus(gstin, taxPeriod, Integer.valueOf(masterId),"Recon_Failed");
     }
     return Constant.STATUS_RECON_FAILED;
	}
	
	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		return headers;
	}
	
	@SuppressWarnings("unchecked")
	private String getInputData(String groupCode, String gstin,String taxPeriod,String masterId) {
		String params = "jobName,groupCode,gstin,taxPeriod,masterId";
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("jobName", Constant.GSTR6RECON_JOB);
		jsonObject.put("groupCode", groupCode);
		jsonObject.put("taxPeriod", taxPeriod);
		jsonObject.put("gstin", gstin);
		jsonObject.put("priority", 5);
		jsonObject.put("repeatCount", 0);
		jsonObject.put("params", params);
		jsonObject.put("timeInterval", 1);
		jsonObject.put("masterId", masterId);
		return jsonObject.toString();
	}
	
	
	@Override
	public String getPreGSTTurnOverData(String gstinId, String finYear){
		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getPreGSTTurnOverData");
		try{
			return (String) gstr6Dao.getPreGSTTurnOverDataFromDB(gstinId, finYear);			 
		}catch(Exception e){
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getPreGSTTurnOverData" , e);
			return null;
		}
	}
	
	@Override
	public String getDistributionTuroverTab1(String gstinId, String taxPeriod){
		if(LOGGER.isInfoEnabled())	
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : getDistributionTuroverTab1");
		try{
			return (String) gstr6Dao.getDistributionTuroverTab1FromDB(gstinId, taxPeriod);			 
		}catch(Exception e){
			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " getDistributionTuroverTab1" , e);
			return null;
		}
	}
	
	
	@Override
	@Transactional
	public  List<String> savePreGSTTurnOverData(List<GSTR6TurnoverDetailsPriorFY> listobj){
		ArrayList<String> responseList = new ArrayList<String>();
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : savePreGSTTurnOverData");
			 String result = "";
   		try{
   			/*for(PreGSTTurnOverDto turnOverDto : preGSTData.getDataRows()){
   				gstr6Dao.savePreGSTTurnOverData(turnOverDto,Constant.ENTITY_GSTR6TurnoverDetailsPriorFY);
				}*/

				List<GSTR6TurnoverDetailsPriorFY> toBeUpdatedList=new ArrayList<>();
					for(GSTR6TurnoverDetailsPriorFY tblTurnoverDetails : listobj){
						if(tblTurnoverDetails.getId() == 0){
								GSTR6TurnoverDetailsPriorFY newCell=new GSTR6TurnoverDetailsPriorFY();
								newCell.setAmount(tblTurnoverDetails.getAmount());	
								newCell.setTurnoverMasterID(tblTurnoverDetails.getTurnoverMasterID());
								newCell.setFy(tblTurnoverDetails.getFy());
								toBeUpdatedList.add(newCell);
							
						}else{
							List<GSTR6TurnoverDetailsPriorFY> objList=(List<GSTR6TurnoverDetailsPriorFY>) hibernateDao.find("from GSTR6TurnoverDetailsPriorFY where id=?" , tblTurnoverDetails.getId());
							if(objList!=null && !objList.isEmpty()){
								GSTR6TurnoverDetailsPriorFY status=objList.get(0);
								status.setAmount(tblTurnoverDetails.getAmount());					
								toBeUpdatedList.add(status);
							}
						}
					}
					if(!toBeUpdatedList.isEmpty())
						hibernateDao.saveOrUpdateAll(toBeUpdatedList);
   			
   			
   			result = Constant.SUCCESS;
   		}catch(Exception e){
   			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " savePreGSTTurnOverData" , e);
   			result = Constant.FAILED;
   		}
   		responseList.add(result);
   		return responseList;
   	}
	
	@Override
	public  String saveGSTTurnOverData(List<TblTurnoverDetails> obj){
			LOGGER.info(Constant.LOGGER_ENTERING + CLASS_NAME + " Method : saveGSTTurnOverData");
			 //String result = "";
			 String response="";
   		try{
   				
   				List<TblTurnoverDetails> toBeUpdatedList=new ArrayList<>();
   					for(TblTurnoverDetails tblTurnoverDetails : obj){
   						List<TblTurnoverDetails> objList=(List<TblTurnoverDetails>) hibernateDao.find("from TblTurnoverDetails where id=?" , tblTurnoverDetails.getId());
   						if(objList!=null && !objList.isEmpty()){
   							TblTurnoverDetails status=objList.get(0);
   							status.setAmount(tblTurnoverDetails.getAmount());					
   							toBeUpdatedList.add(status);
   						}
   					}
   					if(!toBeUpdatedList.isEmpty())
   						hibernateDao.saveOrUpdateAll(toBeUpdatedList);
   					    //response="success";
				
   			response = Constant.SUCCESS;
   		}catch(Exception e){
   			LOGGER.error(Constant.LOGGER_ERROR + CLASS_NAME + Constant.LOGGER_METHOD + " saveGSTTurnOverData" , e);
   			response = Constant.FAILED;
   		}
   		return response;
   	}
	
	@Override
	public void disableSelectedRow(JSONObject jsonObj) throws Exception{
		if(LOGGER.isInfoEnabled())	
			LOGGER.info("Entering "+Constant.LOGGER_ENTERING + CLASS_NAME + " Method : disableSelectedRow");
		TblTurnoverMaster tblTurnoverMaster= new TblTurnoverMaster();
		tblTurnoverMaster.setId(Integer.parseInt((String) jsonObj.get("Id")));
		tblTurnoverMaster.setGstin((String)jsonObj.get("entityName"));
		
		try{
			List<TblTurnoverMaster> statusList=(List<TblTurnoverMaster>) hibernateDao.find("from TblTurnoverMaster where id=? and GSTN=?" , tblTurnoverMaster.getId(),tblTurnoverMaster.getGstin());
				if(statusList!=null && !statusList.isEmpty()){
					TblTurnoverMaster status=statusList.get(0);
					status.setActive(Boolean.FALSE);
					hibernateDao.saveOrUpdate(status);
				}
		}
		catch(Exception e){
			LOGGER.error(Constant.LOGGER_EXITING + CLASS_NAME
					+Constant.LOGGER_METHOD+" disableSelectedRow",e);
		}
	}
	
	@Override
	public String saveEntityDetailsTab1(List<TblTurnoverMaster> tblTurnoverMasterList) {
		if(LOGGER.isInfoEnabled())	
			LOGGER.info("Entering "+Constant.LOGGER_ENTERING + CLASS_NAME + " Method : saveEntityDetailsTab1");
				
			String response="";
			List<TblTurnoverMaster> toBeUpdatedList=new ArrayList<>();
			try{
				for(TblTurnoverMaster tblTurnoverMaster : tblTurnoverMasterList){
					List<TblTurnoverMaster> statusList=(List<TblTurnoverMaster>) hibernateDao.find("from TblTurnoverMaster where id=?" , tblTurnoverMaster.getId());
					if(statusList!=null && !statusList.isEmpty()){
						TblTurnoverMaster status=statusList.get(0);
						status.setGstin(tblTurnoverMaster.getGstin());
						status.setEmail(tblTurnoverMaster.getEmail());
						status.setStateCode(tblTurnoverMaster.getStateCode());						
						toBeUpdatedList.add(status);
					}
				}
				if(!toBeUpdatedList.isEmpty())
					hibernateDao.saveOrUpdateAll(toBeUpdatedList);
				    response="success";
			}
			catch(Exception e){
				LOGGER.error(Constant.LOGGER_EXITING + CLASS_NAME
						+Constant.LOGGER_METHOD+" saveEntityDetailsTab1",e);
			}
			return response;
			
	}
	
	@Override
	public String saveNewEntityDetailsTab1(List<TblTurnoverMaster> tblTurnoverMasterList) {
		if(LOGGER.isInfoEnabled())	
			LOGGER.info("Entering "+Constant.LOGGER_ENTERING + CLASS_NAME + " Method : saveEntityDetailsTab1");
				
			String response="";
			List<TblTurnoverMaster> toBeUpdatedList=new ArrayList<>();
			try{
				for(TblTurnoverMaster tblTurnoverMaster : tblTurnoverMasterList){
					
					gstr6Dao.saveNewEntityDetails(tblTurnoverMaster);
				}
				response = Constant.SUCCESS;
			}
			catch(Exception e){
				LOGGER.error(Constant.LOGGER_EXITING + CLASS_NAME
						+Constant.LOGGER_METHOD+" saveEntityDetailsTab1",e);
				response = Constant.FAILED;
			}
			return response;
			
	}
	
	@Override
	public String insertGSTTurnoverData(List<TblTurnoverDetails> tblTurnoverDetails) {
		if(LOGGER.isInfoEnabled())	
			LOGGER.info("Entering "+Constant.LOGGER_ENTERING + CLASS_NAME + " Method : insertGSTTurnoverData");
				
			String response="";
			List<TblTurnoverDetails> toBeUpdatedList=new ArrayList<>();
			try{
				for(TblTurnoverDetails tblTurnoverData : tblTurnoverDetails){
					
					gstr6Dao.saveNewTurnoverData(tblTurnoverData);
				}
				response = Constant.SUCCESS;
			}
			catch(Exception e){
				LOGGER.error(Constant.LOGGER_EXITING + CLASS_NAME
						+Constant.LOGGER_METHOD+" insertGSTTurnoverData",e);
				response = Constant.FAILED;
			}
			return response;
			
	}
}