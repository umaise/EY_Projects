package com.ey.advisory.asp.client.service;

import java.util.Map;

@FunctionalInterface
public interface DataFlowStageService {
    
    Map<String, String> getStageInfo(String type);

}
