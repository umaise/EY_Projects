package com.ey.advisory.asp.client.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.log4j.Logger;

/**
 * The primary key class for the tblGstinRetutnFilingStatus database table.
 * @author  Siddharth Pahuja
 * @version 1.0
 * @since   23-03-2017
 * 
 */
@Embeddable
public class TblGstinRetutnFilingStatusPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(TblGstinRetutnFilingStatusPK.class);

	@Column(name="GstinId", unique=true, nullable=false, length=15,insertable=true,updatable=true )
	private String gstinId;

	@Column(name="TaxPeriod", unique=true, nullable=false, length=8,insertable=true,updatable=true )
	private String taxPeriod;

	@Column(name="ReturnType", unique=true, nullable=false, length=10,insertable=true,updatable=true )
	private String returnType;

	public TblGstinRetutnFilingStatusPK() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in TblGstinRetutnFilingStatusPK ");
			}
	}
	public String getGstinId() {
		return this.gstinId;
	}
	public void setGstinId(String gstinId) {
		this.gstinId = gstinId;
	}
	public String getTaxPeriod() {
		return this.taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	public String getReturnType() {
		return this.returnType;
	}
	public void setReturnType(String returnName) {
		this.returnType = returnName;
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TblGstinRetutnFilingStatusPK)) {
			return false;
		}
		TblGstinRetutnFilingStatusPK castOther = (TblGstinRetutnFilingStatusPK)other;
		return 
			this.gstinId.equals(castOther.gstinId)
			&& this.taxPeriod.equals(castOther.taxPeriod)
			&& this.returnType.equals(castOther.returnType);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.gstinId.hashCode();
		hash = hash * prime + this.taxPeriod.hashCode();
		hash = hash * prime + this.returnType.hashCode();
		
		return hash;
	}
}