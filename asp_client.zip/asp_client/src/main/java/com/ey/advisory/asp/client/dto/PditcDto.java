package com.ey.advisory.asp.client.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

public class PditcDto {
	
	private BigDecimal i_pdi;
	private BigDecimal i_pdc;
	private BigDecimal i_pds;
	private BigDecimal c_pdi;
	private BigDecimal c_pdc;
	private BigDecimal s_pdi;
	private BigDecimal s_pds;
	private BigDecimal cs_pdcs;
	public BigDecimal getI_pdi() {
		return i_pdi;
	}
	public BigDecimal getI_pdc() {
		return i_pdc;
	}
	public void setI_pdc(BigDecimal i_pdc) {
		this.i_pdc = i_pdc;
	}
	public BigDecimal getI_pds() {
		return i_pds;
	}
	public void setI_pds(BigDecimal i_pds) {
		this.i_pds = i_pds;
	}
	public BigDecimal getC_pdi() {
		return c_pdi;
	}
	public void setC_pdi(BigDecimal c_pdi) {
		this.c_pdi = c_pdi;
	}
	public BigDecimal getC_pdc() {
		return c_pdc;
	}
	public void setC_pdc(BigDecimal c_pdc) {
		this.c_pdc = c_pdc;
	}
	public BigDecimal getS_pdi() {
		return s_pdi;
	}
	public void setS_pdi(BigDecimal s_pdi) {
		this.s_pdi = s_pdi;
	}
	public BigDecimal getS_pds() {
		return s_pds;
	}
	public void setS_pds(BigDecimal s_pds) {
		this.s_pds = s_pds;
	}
	public BigDecimal getCs_pdcs() {
		return cs_pdcs;
	}
	public void setCs_pdcs(BigDecimal cs_pdcs) {
		this.cs_pdcs = cs_pdcs;
	}
	public void setI_pdi(BigDecimal i_pdi) {
		this.i_pdi = i_pdi;
	}	
}
