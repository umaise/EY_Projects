package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;

/**
 * The persistent class for the tblTaxPaidData database table.
 * 
 */
@Entity
@Table(name="tblTaxPaidData", schema=Constant.GSTR2_SCHEMA)
public class GSTR2TaxPaidData implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR2TaxPaidData.class);

	@Id
	@Column(name="ID")
	private long id;

	@Column(name="CessAmt")
	private Double cessAmt;

	@Column(name="CessRt")
	private Double cessRt;

	@Column(name="CGSTAmt")
	private Double CGSTAmt;

	@Column(name="CGSTRt")
	private Double CGSTRt;

	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="DocDate")
	private Date docDate;

	@Column(name="DocNum")
	private String docNum;

	@Column(name="FileId")
	private long fileId;

	@Column(name="Flag")
	private String flag;

	@Column(name="Gstin")
	private String gstin;

	@Column(name="IGSTAmt")
	private Double IGSTAmt;

	@Column(name="IGSTRt")
	private Double IGSTRt;

	@Column(name="InvDt")
	private Date invDt;

	@Column(name="InvNum")
	private String invNum;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="SGSTAmt")
	private Double SGSTAmt;

	@Column(name="SGSTRt")
	private Double SGSTRt;

	@Column(name="TaxableValue")
	private Double taxableValue;

	@Column(name="TaxPeriod")
	private String taxPeriod;

	public GSTR2TaxPaidData() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR2TaxPaidData ");
			}
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Double getCessAmt() {
		return this.cessAmt;
	}

	public void setCessAmt(Double cessAmt) {
		this.cessAmt = cessAmt;
	}

	public Double getCessRt() {
		return this.cessRt;
	}

	public void setCessRt(Double cessRt) {
		this.cessRt = cessRt;
	}

	public Double getCGSTAmt() {
		return this.CGSTAmt;
	}

	public void setCGSTAmt(Double CGSTAmt) {
		this.CGSTAmt = CGSTAmt;
	}

	public Double getCGSTRt() {
		return this.CGSTRt;
	}

	public void setCGSTRt(Double CGSTRt) {
		this.CGSTRt = CGSTRt;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public Date getDocDate() {
		return this.docDate;
	}

	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}

	public String getDocNum() {
		return this.docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	public long getFileId() {
		return this.fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Double getIGSTAmt() {
		return this.IGSTAmt;
	}

	public void setIGSTAmt(Double IGSTAmt) {
		this.IGSTAmt = IGSTAmt;
	}

	public Double getIGSTRt() {
		return this.IGSTRt;
	}

	public void setIGSTRt(Double IGSTRt) {
		this.IGSTRt = IGSTRt;
	}

	public Date getInvDt() {
		return this.invDt;
	}

	public void setInvDt(Date invDt) {
		this.invDt = invDt;
	}

	public String getInvNum() {
		return this.invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public Double getSGSTAmt() {
		return this.SGSTAmt;
	}

	public void setSGSTAmt(Double SGSTAmt) {
		this.SGSTAmt = SGSTAmt;
	}

	public Double getSGSTRt() {
		return this.SGSTRt;
	}

	public void setSGSTRt(Double SGSTRt) {
		this.SGSTRt = SGSTRt;
	}

	public Double getTaxableValue() {
		return this.taxableValue;
	}

	public void setTaxableValue(Double taxableValue) {
		this.taxableValue = taxableValue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

}