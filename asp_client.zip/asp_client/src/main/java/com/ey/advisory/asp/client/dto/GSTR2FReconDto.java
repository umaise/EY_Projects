package com.ey.advisory.asp.client.dto;

import java.util.List;

import com.google.gson.annotations.SerializedName;

/**
 * This is GSTR2F Recon DTO.
 * 
 * @author Prakash.Naik
 *
 */
public class GSTR2FReconDto {

	@SerializedName("InvoiceList")
	private List<GSTR2FInvoiceDto> b2bInvoices;

	public List<GSTR2FInvoiceDto> getB2bInvoices() {
		return b2bInvoices;
	}

	public void setB2bInvoices(List<GSTR2FInvoiceDto> b2bInvoices) {
		this.b2bInvoices = b2bInvoices;
	}

}
