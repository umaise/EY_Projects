package com.ey.advisory.asp.client.service.gstr6;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;

import com.ey.advisory.asp.client.domain.FIleSubmissionStatusDetails;
import com.ey.advisory.asp.client.domain.GSTR6TurnoverDetailsPriorFY;
import com.ey.advisory.asp.client.domain.GlobalGSTRatesMasterI;
import com.ey.advisory.asp.client.domain.ItemMaster;
import com.ey.advisory.asp.client.domain.ReconciliationStatusDTO;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblIsdErrorInfo;
import com.ey.advisory.asp.client.domain.TblPurchaseErrorInfo;
import com.ey.advisory.asp.client.domain.TblTurnoverDetails;
import com.ey.advisory.asp.client.domain.TblTurnoverMaster;
import com.ey.advisory.asp.client.dto.GSTTurnoverWrapper;
import com.ey.advisory.asp.client.dto.Gstr6Dto;
import com.ey.advisory.asp.client.domain.InwardInvoiceModel;
import com.ey.advisory.asp.client.dto.InwardInvoiceGstr6DTO;
import com.ey.advisory.asp.client.dto.PreGSTTurnOverDto;
import com.ey.advisory.asp.client.dto.PreGSTTurnOverWrapper;
import com.ey.advisory.asp.client.dto.SummaryDto;
import com.ey.advisory.asp.dto.InvoiceProcessDto;

/**
 * Service contains all the methods related to GSTR1 form
 *
 */
public interface Gstr6Service {

	public Map testServiceMethod(List<Object> GSTIN);

	public String signfileGstr6(String gstin, String month, String year);
	
	public String fileGSTR6(SummaryDto summarydto);
	
	public String getReturnFilingSuccess(String gstinId, String rtPeriod);

	public String GSTR6Summary(String gstinId, String month, String year);

	//public String getGSTR6SummaryfromDB(String gstinId, String rtPeriod);

	public TblGstinRetutnFilingStatus getGStrReturnFilingDetails(String gstinId, String rtPeriod, String gstr3);
	
	boolean saveGstr6InvoiceStatus(Set<InvoiceProcessDto> invoiceList, Integer fileId);
    
    boolean saveIsdErrorInfo(Set<TblIsdErrorInfo> errorInfoList);
    
    public void validateGSTR6Rules(InwardInvoiceGstr6DTO inwardInvoiceDTO, Class<?> clsEntity, String docNum, String docDate);
    
    public void validateOriginalDocumentNo(InwardInvoiceGstr6DTO inwardInvoiceDTO, String entityName, String columnName);

    public InwardInvoiceGstr6DTO isValidITCDate(InwardInvoiceGstr6DTO inwardInvoiceDTO);
    
    public List<Object> getHSNSACDetailsfromMaster(String key) ;
	public ItemMaster getSpecifcHSNSACDetails(String hsnSac) ;
	public GlobalGSTRatesMasterI getSpecifcHSNSACDetailsfromglobal(String hsnSac) ;
	
	public boolean updateReconFilingStatus(Set<ReconciliationStatusDTO> reconStatusSet);
	
	public Object[] getFileGstr6Status(Gstr6Dto gstr6Dto);

	public Object getGstr6InvoiceMapping(String gstinId,String taxPeriod);
	
	public List<String> fetchISDDistributionListForGstin(JSONObject jsonObj);
	
	public Object getGstr6RectifiedReportXml(JSONObject jsonObj);
	
	public List<InwardInvoiceModel> getInvoiceDocumentDetails(Set<InvoiceProcessDto> invoiceList);
	
	public List<InwardInvoiceModel> getCRTaxableDetails(Set<InvoiceProcessDto> invoiceList);
	
	public Integer getDocumentDetails(Set<InvoiceProcessDto> invoiceList);
	public Integer getDocumentDetails_CrDrInvDtl(Set<InvoiceProcessDto> invoiceList);
	public Integer getDocumentDetails_ITCDInvDtl(Set<InvoiceProcessDto> invoiceList);
	
	public List<String> getErrorReportDetails(JSONObject obj);

	boolean timeoutAndMarkInvoiceStatusTechError(Integer fileId) throws Exception;
	public Object getDeterminationRegisterXml(String taxPeriod);
	
	public List<String> updateInvoiceMappedRows(JSONObject jsonObj);
	public int checkFinalInvUploadCompleted(String taxperiod,String gstin);

	public <T> List<T> validateOriginalDocumentNoAndDate(InwardInvoiceGstr6DTO inwardInvoiceDTO,
			String entityName, String columnName1, String columnName2);
	public void setErrorList(Set<TblIsdErrorInfo> errorList, InwardInvoiceModel inwardInvoiceModel, String errorInfoCode,
			String errorColumnNames, String processStatus, boolean isProcessed, String incidenceLevel);
	
	public String saveTblTypeErrLstAndRoute(String key) throws Exception;
	
	public Object getGstr6DeterminationReport(String gstinId,String taxPeriod);
	public Object getGSTR6DeterminationSummaryfromDB(String gstn, String taxPeriod) ;
	public int checkHsnSac(String hsnSac);	
	public  List<String> saveDeterminationRowsData(JSONObject jsonObj);
	public  List<String> submitDeterminationRowsData(JSONObject jsonObj);

	public String getDetSummaryDownload(JSONObject jsonObj); 
	public String getPreGSTTurnOverData(String gstinId, String finYear);
	public  List<String> savePreGSTTurnOverData(List<GSTR6TurnoverDetailsPriorFY> listobj);
	public String gstr6Reconciliation(String gstin, String taxPeriod,String groupCode,String masterId);
	public String saveEntityDetailsTab1(
			List<TblTurnoverMaster> tblTurnoverMasterList);

	public void disableSelectedRow(JSONObject jsonObj) throws Exception;

	public String saveGSTTurnOverData(List<TblTurnoverDetails> obj);

	public String getDistributionTuroverTab1(String gstinId, String finYear);

	public String saveNewEntityDetailsTab1(List<TblTurnoverMaster> listobj);
	
	Object getGSTR6SummaryfromDB(String gstn, String taxPeriod);
	public String insertGSTTurnoverData(List<TblTurnoverDetails> newTurnoverlist);
}
