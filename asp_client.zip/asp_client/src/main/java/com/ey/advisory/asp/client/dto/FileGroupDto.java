package com.ey.advisory.asp.client.dto;

import java.util.List;

public class FileGroupDto {
	private int groupId;
	

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	private String groupCode;
	
	private List<FileDto> fileId;

	public List<FileDto> getFileId() {
		return fileId;
	}

	public void setFileId(List<FileDto> fileId) {
		this.fileId = fileId;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	
	
	

}
