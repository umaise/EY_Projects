package com.ey.advisory.asp.client.service.gstr1;

import com.ey.advisory.asp.client.dto.OutwardInvoiceDTO;

public interface Gstr1AdvTaxValidationService {

}
