package com.ey.advisory.asp.client.dao;

import java.util.List;

import com.ey.advisory.asp.client.domain.DueDateMaster;


public interface DueDateMasterDao {

	public List<DueDateMaster> getGstinDueDateMaster(List<String> returnTypeList, String gstin);
	public String getGstinReturnType(String gstin);
}
