package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.ey.advisory.asp.client.util.CommonUtillity;

@Entity
@Table(name="tblGSTR2ITCReversal", schema="etl")
@NamedQuery(name = "TblGSTR2ItcReversal.findAll", query = "SELECT t FROM TblGSTR2ItcReversal t")
public class TblGSTR2ItcReversal implements Serializable {
	
	private static final long serialVersionUID = 1;

	@Id
	@Column(name="ITCRevID")
	private Long itcRevID;
	
	@Column(name="GSTIN")
	private String gSTIN;
	
	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="Description")
	private String description;
	
	@Column(name="OrgDetailsMonth")
	private String orgDetailsMonth;
	
	@Column(name="SummaryFileID")
	private Long summaryFileID;
	
	@Column(name="OrgDetailsAmtIGST")
	private BigDecimal orgDetailsAmtIGST;
	
	
	@Column(name="OrgDetailsAmtCGST")
	private BigDecimal orgDetailsAmtCGST;
	
	@Column(name="OrgDetailsAmtSGST")
	private BigDecimal orgDetailsAmtSGST;
	
	@Column(name="OrgDetailsAmtCess")
	private BigDecimal orgDetailsAmtCess;
	
	@Column(name="NewDetailsAmtIGST")
	private BigDecimal newDetailsAmtIGST;
	
	@Column(name="NewDetailsAmtCGST")
	private BigDecimal newDetailsAmtCGST;
	
	@Column(name="NewDetailsAmtSGST")
	private BigDecimal newDetailsAmtSGST; 
	
	@Column(name="NewDetailsAmtCess")
	private BigDecimal newDetailsAmtCess;
	
	@Column(name="IsActive")
	private Boolean isActive;
	


	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Long getSummaryFileID() {
		return summaryFileID;
	}

	public void setSummaryFileID(Long summaryFileID) {
		this.summaryFileID = summaryFileID;
	}

	public String getTaxPeriod() {
		return taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getOrgDetailsMonth() {
		return orgDetailsMonth;
	}

	public void setOrgDetailsMonth(String orgDetailsMonth) {
		this.orgDetailsMonth = orgDetailsMonth;
	}

	public Long getItcRevID() {
		return itcRevID;
	}

	public void setItcRevID(Long itcRevID) {
		this.itcRevID = itcRevID;
	}

	public String getgSTIN() {
		return gSTIN;
	}

	public void setgSTIN(String gSTIN) {
		this.gSTIN = gSTIN;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getOrgDetailsAmtIGST() {
		return orgDetailsAmtIGST;
	}

	public void setOrgDetailsAmtIGST(BigDecimal orgDetailsAmtIGST) {
		this.orgDetailsAmtIGST = orgDetailsAmtIGST;
	}

	public BigDecimal getOrgDetailsAmtCGST() {
		return orgDetailsAmtCGST;
	}

	public void setOrgDetailsAmtCGST(BigDecimal orgDetailsAmtCGST) {
		this.orgDetailsAmtCGST = orgDetailsAmtCGST;
	}

	public BigDecimal getOrgDetailsAmtSGST() {
		return orgDetailsAmtSGST;
	}

	public void setOrgDetailsAmtSGST(BigDecimal orgDetailsAmtSGST) {
		this.orgDetailsAmtSGST = orgDetailsAmtSGST;
	}

	public BigDecimal getOrgDetailsAmtCess() {
		return orgDetailsAmtCess;
	}

	public void setOrgDetailsAmtCess(BigDecimal orgDetailsAmtCess) {
		this.orgDetailsAmtCess = orgDetailsAmtCess;
	}

	public BigDecimal getNewDetailsAmtIGST() {
		return newDetailsAmtIGST;
	}

	public void setNewDetailsAmtIGST(BigDecimal newDetailsAmtIGST) {
		this.newDetailsAmtIGST = newDetailsAmtIGST;
	}

	public BigDecimal getNewDetailsAmtCGST() {
		return newDetailsAmtCGST;
	}

	public void setNewDetailsAmtCGST(BigDecimal newDetailsAmtCGST) {
		this.newDetailsAmtCGST = newDetailsAmtCGST;
	}

	public BigDecimal getNewDetailsAmtSGST() {
		return newDetailsAmtSGST;
	}

	public void setNewDetailsAmtSGST(BigDecimal newDetailsAmtSGST) {
		this.newDetailsAmtSGST = newDetailsAmtSGST;
	}

	public BigDecimal getNewDetailsAmtCess() {
		return newDetailsAmtCess;
	}

	public void setNewDetailsAmtCess(BigDecimal newDetailsAmtCess) {
		this.newDetailsAmtCess = newDetailsAmtCess;
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
		
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (itcRevID ^ (itcRevID >>> 32));
		return result;
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TblGSTR2ItcReversal other = (TblGSTR2ItcReversal) obj;
		if (itcRevID == null) {
			if (other.itcRevID != null)
				return false;
		} else if (!itcRevID.equals(other.itcRevID))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return (gSTIN != null ? gSTIN : "") + ", "
				+ (taxPeriod != null ? taxPeriod : "") + ", "
				+ (description != null ? CommonUtillity.formatCommasWithSpaces(description) : "") + ", "
				+ (orgDetailsMonth != null ? orgDetailsMonth : "") + ", "
				+ (orgDetailsAmtIGST != null ? orgDetailsAmtIGST : "") + ", "
				+ (orgDetailsAmtCGST != null ? orgDetailsAmtCGST : "") + ", "
				+ (orgDetailsAmtSGST != null ? orgDetailsAmtSGST : "") + ", "
				+ (orgDetailsAmtCess != null ? orgDetailsAmtCess : "") + ", "
				+ (newDetailsAmtIGST != null ? newDetailsAmtIGST : "") + ", "
				+ (newDetailsAmtCGST != null ? newDetailsAmtCGST : "") + ", "
				+ (newDetailsAmtSGST != null ? newDetailsAmtSGST : "") + ", "
				+ (newDetailsAmtCess != null ? newDetailsAmtCess : "");
	}
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	/*@Override
	public String toString() {
		return gSTIN + "," + taxPeriod + "," + description + "," + orgDetailsMonth + "," + orgDetailsAmtIGST + ","
				+ orgDetailsAmtCGST + "," + orgDetailsAmtSGST + "," + orgDetailsAmtCess + "," + newDetailsAmtIGST
				+ "," + newDetailsAmtCGST + "," + newDetailsAmtSGST + "," + newDetailsAmtCess;
	}*/

	
}
