package com.ey.advisory.asp.client.dto;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Id;

public class PreGSTTurnOverDto {

	private int id;
	private String financialYear;
	private BigDecimal turnOverAmount;
	private int masterId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFinancialYear() {
		return financialYear;
	}
	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}
	public BigDecimal getTurnOverAmount() {
		return turnOverAmount;
	}
	public void setTurnOverAmount(BigDecimal turnOverAmount) {
		this.turnOverAmount = turnOverAmount;
	}
	public int getMasterId() {
		return masterId;
	}
	public void setMasterId(int masterId) {
		this.masterId = masterId;
	}
}
