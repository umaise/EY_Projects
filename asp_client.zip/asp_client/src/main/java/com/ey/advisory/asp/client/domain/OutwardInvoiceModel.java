package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Where;
import org.hibernate.validator.constraints.Length;

import com.ey.advisory.asp.client.util.CommonUtillity;
import com.google.gson.annotations.SerializedName;


/**
 * The persistent class for the tblSalesStaging database table.
 * 
 */
@Entity
@Table(name="tblSalesStaging", schema="etl")

@NamedQueries({ 
    @NamedQuery(name = "OutwardInvoiceModel.updateStatus",  query = "update OutwardInvoiceModel set "
            + "itemStatus=:STATUS , tableType=:TYPE, subCategory=:SUBCATEGORY where fileID= :FILEID and invOrder= :INVORDER") ,
        @NamedQuery(name="OutwardInvoiceModel.findAll", query="SELECT t FROM OutwardInvoiceModel t") ,
        @NamedQuery(name="OutwardInvoiceModel.markTechError", query="update OutwardInvoiceModel set itemStatus='BATCH_TECH_ERROR' where fileID=:FILEID and itemStatus is null and tableType is null and isError=0")})


public class OutwardInvoiceModel implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="ID")
    @SerializedName("Id")
    private int id;

    @SerializedName("FileID")
    @Column(name="FileID")
    private int fileID;

    @SerializedName("PlantCode")
    @Column(name="PlantCode")@Length(max = 10)
    private String plantCode;

    @SerializedName("SGSTIN")
    @Column(name="SGSTIN")@Length(max = 100)
    private String sGSTIN ;

    @SerializedName("TaxPeriod")
    @Column(name="TaxPeriod")@Length(max = 8)
    private String taxperiod;

    @SerializedName("DocumentType")
    @Column(name="DocumentType")@Length(max = 5)
    private String documentType;

    @SerializedName("SupplyType")
    @Column(name="SupplyType")@Length(max = 5)
    private String supplyType;

    @SerializedName("DocumentNo")
    @Column(name="DocumentNo")@Length(max = 50)
    private String documentNo ;

    @Temporal(TemporalType.DATE)
    @Column(name="DocumentDate")
    private Date documentDate;

    @Transient
    @SerializedName("DocumentDate")
    private String documentDateStr;

    @Temporal(TemporalType.DATE)
    @SerializedName("OriginalDocumentDate")
    @Column(name="OriginalDocumentDate")
    private Date originalDocumentDate;

    @SerializedName("OriginalDocumentNo")
    @Column(name="OriginalDocumentNo")@Length(max = 50)
    private String originalDocumentNo;

    @SerializedName("LineNumber")
    @Column(name="LineNumber")@Length(max = 1)
    private String lineNumber ;

    @SerializedName("CGSTIN")
    @Column(name="CGSTIN")@Length(max = 15)
    private String cGSTIN ;

    @SerializedName("CustomerCode")
    @Column(name="CustomerCode")@Length(max = 10)
    private String customerCode;

    @SerializedName("CustomerName")
    @Column(name="CustomerName")@Length(max = 40)
    private String customerName;

    @SerializedName("BillToState")
    @Column(name="BillToState")@Length(max = 2)
    private String billToState ;

    @SerializedName("ShipToState")
    @Column(name="ShipToState")@Length(max = 2)
    private String shipToState ;

    @SerializedName("POS")
    @Column(name="POS")@Length(max = 2)
    private String pos;

    @SerializedName("ShippingBillNo")
    @Column(name="ShippingBillNo")@Length(max = 50)
    private String shippingBillNo;

    @Temporal(TemporalType.DATE)
    @SerializedName("ShippingBillDate")
    @Column(name="ShippingBillDate")
    private Date shippingBillDate;

    @SerializedName("HSNSAC")
    @Column(name="HSNSAC")@Length(max = 10)
    private String hsnsac;

    @SerializedName("IGSTAmount")
    @Column(name="IGSTAmount")
    private Double igstAmount;

    @SerializedName("IGSTRate")
    @Column(name="IGSTRate")
    private Double igstRate;

    @SerializedName("ItemCode")
    @Column(name="ItemCode")@Length(max = 10)
    private String itemCode;

    @SerializedName("ItemDescription")
    @Column(name="ItemDescription")@Length(max = 30)
    private String itemDescription;

    @SerializedName("ItemCategory")
    @Column(name="ItemCategory")@Length(max = 30)
    private String itemCategory;

    @SerializedName("UnitofMeasurement")
    @Column(name="UnitofMeasurement")@Length(max = 30)
    private String unitofMeasurement ;

    @SerializedName("QtySupplied")
    @Column(name="QtySupplied")
    private BigDecimal qtySupplied ;

    @SerializedName("TaxableValue")
    @Column(name="TaxableValue")
    private Double taxableValue;

    @SerializedName("CGSTAmount")
    @Column(name="CGSTAmount")
    private Double cgstAmount;

    @SerializedName("CGSTRate")
    @Column(name="CGSTRate")
    private Double cgstRate;

    @SerializedName("SGSTAmount")
    @Column(name="SGSTAmount")
    private Double sgstAmount;

    @SerializedName("SGSTRate")
    @Column(name="SGSTRate")
    private Double sgstRate;

    @SerializedName("ReverseCharge")
    @Column(name="ReverseCharge")@Length(max = 1)
    private String reverseCharge ;

    @SerializedName("EGSTIN")
    @Column(name="EGSTIN")@Length(max = 15)
    private String eGSTIN;

   /* @SerializedName("SupplierERN")
    @Column(name="SupplierERN")@Length(max = 50)
    private String supplierERN;*/

   /* @Temporal(TemporalType.DATE)
    @SerializedName("ERNDate")
    @Column(name="ERNDate")
    private Date eRNDate;*/

   /* @SerializedName("TransportName")
    @Column(name="TransportName")@Length(max = 40)
    private String transportName;*/
    
    /*@SerializedName("LorryReceiptNo")
    @Column(name="LorryReceiptNo")@Length(max = 40)
    private String lorryReceiptNo;*/

    /*@SerializedName("LorryReceiptDate")
    @Column(name="LorryReceiptDate")
    private String lorryReceiptDate;*/

    @SerializedName("AggInvoice")
    @Column(name="AggInvoice")
    private BigDecimal aggInvoice;

    @SerializedName("AggTaxableValue")
    @Column(name="AggTaxableValue")
    private BigDecimal aggTaxableValue;

    @SerializedName("InvOrder")
    @Column(name="InvOrder")
    private Integer invOrder;

    @SerializedName("itemStatus")
    @Column(name="Status")@Length(max = 20)
    private String itemStatus;

    @SerializedName("RecordType")
    @Column(name="RecordType")@Length(max = 10)
    private String tableType;

    @SerializedName("AccountingVoucherNumber")
    @Column(name="AccountingVoucherNumber")@Length(max = 50)
    private String accountingVoucherNumber ;

    @Temporal(TemporalType.DATE)
    @SerializedName("AccountingVoucherDate")
    @Column(name="AccountingVoucherDate")
    private Date accountingVoucherDate;
    
    @SerializedName("CessAmountAdvalorem")
    @Column(name="CessAmountAdvalorem")
    private Double cessAmountAdvalorem;
    
    @SerializedName("CessAmountSpecific")
    @Column(name="CessAmountSpecific")
    private Double cessAmountSpecific;
    
    @SerializedName("CessRateAdvalorem")
    @Column(name="CessRateAdvalorem")
    private Double cessRateAdvalorem;

    @SerializedName("CessRateSpecific")
    @Column(name="CessRateSpecific")
    private Double cessRateSpecific;
    
    @SerializedName("Division")
    @Column(name="Division")@Length(max = 20)
    private String division;

    @SerializedName("ExportDuty")
    @Column(name="ExportDuty")
    private Double exportDuty;

    @SerializedName("FOB")
    @Column(name="FOB")
    private Double fob;
    
    /*@Temporal(TemporalType.DATE)
    @SerializedName("GoodsReceiptDate")
    @Column(name="GoodsReceiptDate")
    private Date goodsReceiptDate;*/

    @SerializedName("InvoiceValue")
    @Column(name="InvoiceValue")
    private Double invoiceValue;

    @SerializedName("IsPreStageError")
    @Column(name="IsPreStageError")
    private boolean isPreStageError;

    @SerializedName("ITCFlag")
    @Column(name="ITCFlag")@Length(max = 2)
    private String itcFlag;

    /*@SerializedName("MaterialSentForJobwork")
    @Column(name="MaterialSentForJobwork")@Length(max = 2)
    private String materialSentForJobwork;*/

    @SerializedName("OriginalCGSTIN")
    @Column(name="OriginalCGSTIN")@Length(max = 15)
    private String OriginalCGSTIN;

    @SerializedName("ProfitCentre1")
    @Column(name="ProfitCentre1")@Length(max = 20)
    private String ProfitCentre1;
    
    @SerializedName("ProfitCentre2")
    @Column(name="ProfitCentre2")@Length(max = 20)
    private String ProfitCentre2;

    @SerializedName("ReasonForCreditDebitNote")
    @Column(name="ReasonForCreditDebitNote")
    private String reasonForCreditDebitNote;

    @SerializedName("SubDivision")
    @Column(name="SubDivision")@Length(max = 20)
    private String subDivision;
    
    @SerializedName("TCSFlag")
    @Column(name="TCSFlag")@Length(max = 1)
    private String tcsFlag;

    @SerializedName("SubCategory")
    @Column(name="SubCategory")
    private String subCategory;
    
    @SerializedName("InvoiceKey")
    @Column(name="InvoiceKey")
    private String invoiceKey;

    public String getSupplyCategory() {
        return supplyCategory;
    }

    public void setSupplyCategory(String supplyCategory) {
        this.supplyCategory = supplyCategory;
    }

    @SerializedName("SupplyCategory")
    @Column(name="SupplyCategory")@Length(max = 11)
    private String supplyCategory;


    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SalesStagingID", referencedColumnName="ID")
    private Set<TblSalesErrorInfo> tblErrorInfo;


    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SalesStagingID", referencedColumnName="ID")
    @Where(clause = "incidenceLevel = 'Invoice'")
    private Set<TblSalesErrorInfo> tblInvoiceErrorInfo;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SalesStagingID", referencedColumnName="ID")
    @Where(clause = "incidenceLevel = 'Line-Item'")
    private Set<TblSalesErrorInfo> tblLineItemErrorInfo;
    
    @SerializedName("SourceIdentifier")
    @Column(name="SourceIdentifier")
    private String sourceIdentifier;
    
    @SerializedName("SourceFileName")
    @Column(name="SourceFileName")
    private String sourceFileName;
    
    @SerializedName("GLAccountCode")
    @Column(name="GLAccountCode")
    private String glAccountCode;
    
    @SerializedName("CRDRPreGST")
    @Column(name="CRDRPreGST")
    private String cRDRPreGST;
    
    @SerializedName("UINorComposition")
    @Column(name="UINorComposition")
    private String uinORComposition;
    
    @SerializedName("PortCode")
    @Column(name="PortCode")
    private String portCode;
    
    @SerializedName("Userdefinedfield1")
    @Column(name="Userdefinedfield1")
    private String userdefinedfield1;
    
    @SerializedName("Userdefinedfield2")
    @Column(name="Userdefinedfield2")
    private String userdefinedfield2;
    
    @SerializedName("Userdefinedfield3")
    @Column(name="Userdefinedfield3")
    private String userdefinedfield3;

    @Column(name = "IsError")
	Boolean isError;
    
    @Column(name = "IsDuplicate")
	Boolean isDuplicate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns(
    		{ @JoinColumn(name = "InvoiceKey", referencedColumnName = "InvoiceKey",nullable = false, insertable=false, updatable=false),
    		  @JoinColumn(name = "FileID", referencedColumnName = "FileID",nullable = false,insertable=false, updatable=false)
    		}
    )
    private InvoiceKeyDetail invoiceKeyDetail;

    public Set<TblSalesErrorInfo> getTblInvoiceErrorInfo() {
        return tblInvoiceErrorInfo;
    }


    public void setTblInvoiceErrorInfo(Set<TblSalesErrorInfo> tblInvoiceErrorInfo) {
        this.tblInvoiceErrorInfo = tblInvoiceErrorInfo;
    }


    public Set<TblSalesErrorInfo> getTblLineItemErrorInfo() {
        return tblLineItemErrorInfo;
    }


    public void setTblLineItemErrorInfo(Set<TblSalesErrorInfo> tblLineItemErrorInfo) {
        this.tblLineItemErrorInfo = tblLineItemErrorInfo;
    }


    public Set<TblSalesErrorInfo> getTblErrorInfo() {
        return tblErrorInfo;
    }


    public void setTblErrorInfo(Set<TblSalesErrorInfo> tblErrorInfo) {
        this.tblErrorInfo = tblErrorInfo;
    }


    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public int getFileID() {
        return fileID;
    }


    public void setFileID(int fileID) {
        this.fileID = fileID;
    }


    public String getPlantCode() {
        return plantCode;
    }


    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }


    public String getsGSTIN() {
        return sGSTIN;
    }


    public void setsGSTIN(String sGSTIN) {
        this.sGSTIN = sGSTIN;
    }


    public String getTaxperiod() {
        return taxperiod;
    }


    public void setTaxperiod(String taxperiod) {
        this.taxperiod = taxperiod;
    }


    public String getDocumentType() {
        return documentType;
    }


    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }


    public String getSupplyType() {
        return supplyType;
    }


    public void setSupplyType(String supplyType) {
        this.supplyType = supplyType;
    }

    public String getDocumentNo() {
        return documentNo;
    }


    public void setDocumentNo(String documentNo) {
        this.documentNo = documentNo;
    }


    public Date getDocumentDate() {
        return documentDate;
    }


    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }


    public String getDocumentDateStr() {
        if(documentDate!=null){
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            documentDateStr=formatter.format(documentDate);
        }
        return documentDateStr;
    }


    public void setDocumentDateStr(String documentDateStr) {
        this.documentDateStr = documentDateStr;
    }


    public Date getOriginalDocumentDate() {
        return originalDocumentDate;
    }


    public void setOriginalDocumentDate(Date originalDocumentDate) {
        this.originalDocumentDate = originalDocumentDate;
    }


    public String getOriginalDocumentNo() {
        return originalDocumentNo;
    }


    public void setOriginalDocumentNo(String originalDocumentNo) {
        this.originalDocumentNo = originalDocumentNo;
    }


    public String getLineNumber() {
        return lineNumber;
    }


    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }


    public String getcGSTIN() {
        return cGSTIN;
    }


    public void setcGSTIN(String cGSTIN) {
        this.cGSTIN = cGSTIN;
    }


    public String getCustomerCode() {
        return customerCode;
    }


    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }


    public String getCustomerName() {
        return customerName;
    }


    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }


    public String getBillToState() {
        return billToState;
    }


    public void setBillToState(String billToState) {
        this.billToState = billToState;
    }


    public String getShipToState() {
        return shipToState;
    }


    public void setShipToState(String shipToState) {
        this.shipToState = shipToState;
    }

    public String getPos() {
        return pos;
    }


    public void setPos(String pos) {
        this.pos = pos;
    }


    public String getShippingBillNo() {
        return shippingBillNo;
    }


    public void setShippingBillNo(String shippingBillNo) {
        this.shippingBillNo = shippingBillNo;
    }


    public Date getShippingBillDate() {
        return shippingBillDate;
    }


    public void setShippingBillDate(Date shippingBillDate) {
        this.shippingBillDate = shippingBillDate;
    }

    public String getHsnsac() {
        return hsnsac;
    }


    public void setHsnsac(String hsnsac) {
        this.hsnsac = hsnsac;
    }


    public Double getIgstAmount() {
        return igstAmount;
    }


    public void setIgstAmount(Double igstAmount) {
        this.igstAmount = igstAmount;
    }


    public Double getIgstRate() {
        return igstRate;
    }


    public void setIgstRate(Double igstRate) {
        this.igstRate = igstRate;
    }


    public String getItemCode() {
        return itemCode;
    }


    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }


    public String getItemDescription() {
        return itemDescription;
    }


    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }


    public String getItemCategory() {
        return itemCategory;
    }


    public void setItemCategory(String itemCategory) {
        this.itemCategory = itemCategory;
    }


    public String getUnitofMeasurement() {
        return unitofMeasurement;
    }


    public void setUnitofMeasurement(String unitofMeasurement) {
        this.unitofMeasurement = unitofMeasurement;
    }


    public BigDecimal getQtySupplied() {
        return qtySupplied;
    }


    public void setQtySupplied(BigDecimal qtySupplied) {
        this.qtySupplied = qtySupplied;
    }


    public Double getTaxableValue() {
        return taxableValue;
    }


    public void setTaxableValue(Double taxableValue) {
        this.taxableValue = taxableValue;
    }

    public Double getCgstAmount() {
        return cgstAmount;
    }


    public void setCgstAmount(Double cgstAmount) {
        this.cgstAmount = cgstAmount;
    }


    public Double getCgstRate() {
        return cgstRate;
    }


    public void setCgstRate(Double cgstRate) {
        this.cgstRate = cgstRate;
    }


    public Double getSgstAmount() {
        return sgstAmount;
    }


    public void setSgstAmount(Double sgstAmount) {
        this.sgstAmount = sgstAmount;
    }


    public Double getSgstRate() {
        return sgstRate;
    }


    public void setSgstRate(Double sgstRate) {
        this.sgstRate = sgstRate;
    }


    public String getReverseCharge() {
        return reverseCharge;
    }


    public void setReverseCharge(String reverseCharge) {
        this.reverseCharge = reverseCharge;
    }

    public String geteGSTIN() {
        return eGSTIN;
    }


    public void seteGSTIN(String eGSTIN) {
        this.eGSTIN = eGSTIN;
    }

    /*public String getSupplierERN() {
        return supplierERN;
    }


    public void setSupplierERN(String supplierERN) {
        this.supplierERN = supplierERN;
    }*/


    /*public Date geteRNDate() {
        return eRNDate;
    }


    public void seteRNDate(Date eRNDate) {
        this.eRNDate = eRNDate;
    }*/


   /* public String getTransportName() {
        return transportName;
    }


    public void setTransportName(String transportName) {
        this.transportName = transportName;
    }*/


    /*public String getLorryReceiptNo() {
        return lorryReceiptNo;
    }


    public void setLorryReceiptNo(String lorryReceiptNo) {
        this.lorryReceiptNo = lorryReceiptNo;
    }*/


    /*public String getLorryReceiptDate() {
        return lorryReceiptDate;
    }


    public void setLorryReceiptDate(String lorryReceiptDate) {
        this.lorryReceiptDate = lorryReceiptDate;
    }*/


    public BigDecimal getAggInvoice() {
        return aggInvoice;
    }


    public void setAggInvoice(BigDecimal aggInvoice) {
        this.aggInvoice = aggInvoice;
    }


    public BigDecimal getAggTaxableValue() {
        return aggTaxableValue;
    }


    public void setAggTaxableValue(BigDecimal aggTaxableValue) {
        this.aggTaxableValue = aggTaxableValue;
    }


    public Integer getInvOrder() {
        return invOrder;
    }


    public void setInvOrder(Integer invOrder) {
        this.invOrder = invOrder;
    }


    public String getItemStatus() {
        return itemStatus;
    }


    public void setItemStatus(String itemStatus) {
        this.itemStatus = itemStatus;
    }


    public String getTableType() {
        return tableType;
    }


    public void setTableType(String tableType) {
        this.tableType = tableType;
    }


    public String getInvoiceKey() {
        return invoiceKey;
    }


    public void setInvoiceKey(String invoiceKey) {
        this.invoiceKey = invoiceKey;
    }

    public String getAccountingVoucherNumber() {
        return accountingVoucherNumber;
    }

    public void setAccountingVoucherNumber(String accountingVoucherNumber) {
        this.accountingVoucherNumber = accountingVoucherNumber;
    }

    public Date getAccountingVoucherDate() {
        return accountingVoucherDate;
    }

    public void setAccountingVoucherDate(Date accountingVoucherDate) {
        this.accountingVoucherDate = accountingVoucherDate;
    }

    public Double getCessAmountAdvalorem() {
        return cessAmountAdvalorem;
    }

    public void setCessAmountAdvalorem(Double cessAmountAdvalorem) {
        this.cessAmountAdvalorem = cessAmountAdvalorem;
    }

    public Double getCessAmountSpecific() {
        return cessAmountSpecific;
    }

    public void setCessAmountSpecific(Double cessAmountSpecific) {
        this.cessAmountSpecific = cessAmountSpecific;
    }

    public Double getCessRateAdvalorem() {
        return cessRateAdvalorem;
    }

    public void setCessRateAdvalorem(Double cessRateAdvalorem) {
        this.cessRateAdvalorem = cessRateAdvalorem;
    }

    public Double getCessRateSpecific() {
        return cessRateSpecific;
    }

    public void setCessRateSpecific(Double cessRateSpecific) {
        this.cessRateSpecific = cessRateSpecific;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public Double getExportDuty() {
        return exportDuty;
    }

    public void setExportDuty(Double exportDuty) {
        this.exportDuty = exportDuty;
    }

    public Double getFob() {
        return fob;
    }

    public void setFob(Double fob) {
        this.fob = fob;
    }

   /* public Date getGoodsReceiptDate() {
        return goodsReceiptDate;
    }

    public void setGoodsReceiptDate(Date goodsReceiptDate) {
        this.goodsReceiptDate = goodsReceiptDate;
    }*/

    public Double getInvoiceValue() {
        return invoiceValue;
    }

    public void setInvoiceValue(Double invoiceValue) {
        this.invoiceValue = invoiceValue;
    }

    public boolean isPreStageError() {
        return isPreStageError;
    }

    public void setPreStageError(boolean isPreStageError) {
        this.isPreStageError = isPreStageError;
    }

    public String getItcFlag() {
        return itcFlag;
    }

    public void setItcFlag(String itcFlag) {
        this.itcFlag = itcFlag;
    }

   /* public String getMaterialSentForJobwork() {
        return materialSentForJobwork;
    }

    public void setMaterialSentForJobwork(String materialSentForJobwork) {
        this.materialSentForJobwork = materialSentForJobwork;
    }*/

    public String getOriginalCGSTIN() {
        return OriginalCGSTIN;
    }

    public void setOriginalCGSTIN(String originalCGSTIN) {
        OriginalCGSTIN = originalCGSTIN;
    }

    public String getProfitCentre1() {
        return ProfitCentre1;
    }

    public void setProfitCentre1(String profitCentre1) {
        ProfitCentre1 = profitCentre1;
    }

    public String getProfitCentre2() {
        return ProfitCentre2;
    }

    public void setProfitCentre2(String profitCentre2) {
        ProfitCentre2 = profitCentre2;
    }

    public String getReasonForCreditDebitNote() {
        return reasonForCreditDebitNote;
    }

    public void setReasonForCreditDebitNote(String reasonForCreditDebitNote) {
        this.reasonForCreditDebitNote = reasonForCreditDebitNote;
    }

    public String getSubDivision() {
        return subDivision;
    }

    public void setSubDivision(String subDivision) {
        this.subDivision = subDivision;
    }

    public String getTcsFlag() {
        return tcsFlag;
    }

    public void setTcsFlag(String tcsFlag) {
        this.tcsFlag = tcsFlag;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

	public String getSourceIdentifier() {
		return sourceIdentifier;
	}

	public void setSourceIdentifier(String sourceIdentifier) {
		this.sourceIdentifier = sourceIdentifier;
	}

	public String getSourceFileName() {
		return sourceFileName;
	}

	public void setSourceFileName(String sourceFileName) {
		this.sourceFileName = sourceFileName;
	}

	public String getGlAccountCode() {
		return glAccountCode;
	}

	public void setGlAccountCode(String glAccountCode) {
		this.glAccountCode = glAccountCode;
	}

	public String getcRDRPreGST() {
		return cRDRPreGST;
	}

	public void setcRDRPreGST(String cRDRPreGST) {
		this.cRDRPreGST = cRDRPreGST;
	}

	public String getUinORComposition() {
		return uinORComposition;
	}

	public void setUinORComposition(String uinORComposition) {
		this.uinORComposition = uinORComposition;
	}

	public String getPortCode() {
		return portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getUserdefinedfield1() {
		return userdefinedfield1;
	}

	public void setUserdefinedfield1(String userdefinedfield1) {
		this.userdefinedfield1 = userdefinedfield1;
	}

	public String getUserdefinedfield2() {
		return userdefinedfield2;
	}

	public void setUserdefinedfield2(String userdefinedfield2) {
		this.userdefinedfield2 = userdefinedfield2;
	}

	public String getUserdefinedfield3() {
		return userdefinedfield3;
	}

	public void setUserdefinedfield3(String userdefinedfield3) {
		this.userdefinedfield3 = userdefinedfield3;
	}
	
	public Boolean getIsError() {
		return isError;
	}

	public void setIsError(Boolean isError) {
		this.isError = isError;
	}

	public Boolean getIsDuplicate() {
		return isDuplicate;
	}

	public void setIsDuplicate(Boolean isDuplicate) {
		this.isDuplicate = isDuplicate;
	}
	
	
	public InvoiceKeyDetail getInvoiceKeyDetail() {
		return invoiceKeyDetail;
	}

	public void setInvoiceKeyDetail(InvoiceKeyDetail invoiceKeyDetail) {
		this.invoiceKeyDetail = invoiceKeyDetail;
	}

	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}
	
	
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OutwardInvoiceModel other = (OutwardInvoiceModel) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
	
	
	/**
	 * Please don't remove this method as it is being used for Dump report download functionality
	 */
	@Override
	public String toString() {
		return (sourceIdentifier != null ? CommonUtillity.formatCommasWithSpaces(sourceIdentifier) : "") + "," + (sourceFileName != null ? CommonUtillity.formatCommasWithSpaces(sourceFileName) : "") + ","
				+ (glAccountCode != null ? glAccountCode : "") + "," + (division != null ? CommonUtillity.formatCommasWithSpaces(division) : "") + ","
				+ (subDivision != null ? CommonUtillity.formatCommasWithSpaces(subDivision) : "") + "," + (ProfitCentre1 != null ? ProfitCentre1 : "") + ","
				+ (ProfitCentre2 != null ? ProfitCentre2 : "") + "," + (plantCode != null ? plantCode : "") + "," 
				+ (taxperiod != null ? taxperiod : "") + "," + (sGSTIN != null ? sGSTIN : "") + ","
				+ (documentType != null ? documentType : "") + "," + (supplyType != null ? supplyType : "") + ","
				+ (documentNo != null ? documentNo : "") + "," + (documentDate != null ? documentDate : "") + ","
				+ (originalDocumentNo != null ? originalDocumentNo : "") + "," + (originalDocumentDate != null ? originalDocumentDate : "") + ","
				+ (cRDRPreGST != null ? cRDRPreGST : "") + "," + (lineNumber != null ? lineNumber : "") + "," 
				+ (cGSTIN != null ? cGSTIN : "") + "," + (uinORComposition != null ? uinORComposition : "") + "," 
				+ (OriginalCGSTIN != null ? OriginalCGSTIN : "") + "," + (customerName != null ? CommonUtillity.formatCommasWithSpaces(customerName) : "") + ","
				+ (customerCode != null ? customerCode : "") + "," + (billToState != null ? billToState : "") + "," 
				+ (shipToState != null ? shipToState : "") + "," + (pos != null ? pos : "") + ","
				+ (portCode != null ? portCode : "") + "," + (shippingBillNo != null ? shippingBillNo : "") + ","
				+ (shippingBillDate != null ? shippingBillDate : "") + "," + (fob != null ? fob : "") + ","
				+ (exportDuty != null ? exportDuty : "") + "," + (hsnsac != null ? hsnsac : "") + ","
				+ (itemCode != null ? CommonUtillity.formatCommasWithSpaces(itemCode) : "") + "," + (itemDescription != null ? CommonUtillity.formatCommasWithSpaces(itemDescription) : "") + ","
				+ (itemCategory != null ? CommonUtillity.formatCommasWithSpaces(itemCategory) : "") + "," + (unitofMeasurement != null ? unitofMeasurement : "") + ","
				+ (qtySupplied != null ? qtySupplied : "") + "," + (taxableValue != null ? taxableValue : "") + ","
				+ (igstRate != null ? igstRate : "") + "," + (igstAmount != null ? igstAmount : "") + "," 
				+ (cgstRate != null ? cgstRate : "") + "," + (cgstAmount != null ? cgstAmount : "") + "," 
				+ (sgstRate != null ? sgstRate : "") + "," + (sgstAmount != null ? sgstAmount : "") + "," 
				+ (cessRateAdvalorem != null ? cessRateAdvalorem : "") + "," + (cessAmountAdvalorem != null ? cessAmountAdvalorem : "") + ","
				+ (cessRateSpecific != null ? cessRateSpecific : "") + "," + (cessAmountSpecific != null ? cessAmountSpecific : "") + ","
				+ (invoiceValue != null ? invoiceValue : "") + "," + (reverseCharge != null ? reverseCharge : "") + "," 
				+ (tcsFlag != null ? tcsFlag : "") + "," + (eGSTIN != null ? eGSTIN : "") + ","
				+ (itcFlag != null ? itcFlag : "") + "," + (reasonForCreditDebitNote != null ? CommonUtillity.formatCommasWithSpaces(reasonForCreditDebitNote) : "") + ","
				+ (accountingVoucherNumber != null ? accountingVoucherNumber : "") + "," + (accountingVoucherDate != null ? accountingVoucherDate : "") + ","
				+ (userdefinedfield1 != null ? userdefinedfield1 : "") + "," + (userdefinedfield2 != null ? userdefinedfield2 : "") + ","
				+ (userdefinedfield3 != null ? userdefinedfield3 : "");
	}
	
	
	
	/*@Override
    public String toString() {
           return  sourceIdentifier + "," + sourceFileName + ","
                        + glAccountCode + "," + division + "," + subDivision + ","
                        + ProfitCentre1 + "," + ProfitCentre2 + "," + plantCode + ","
                        + taxperiod + "," + sGSTIN + "," + documentType + ","
                        + supplyType + "," + documentNo + "," + documentDate + ","
                        + originalDocumentNo + "," + originalDocumentDate + ","
                        + cRDRPreGST + "," + lineNumber + "," + cGSTIN + ","
                        + uinORComposition + "," + OriginalCGSTIN + "," + customerName
                        + "," + customerCode + "," + billToState + "," + shipToState
                        + "," + pos + "," + portCode + "," + shippingBillNo + ","
                        + shippingBillDate + "," + fob + "," + exportDuty + ","
                        + hsnsac + "," + itemCode + "," + itemDescription + ","
                        + itemCategory + "," + unitofMeasurement + "," + qtySupplied
                        + "," + taxableValue + "," + igstRate + "," + igstAmount + ","
                        + cgstRate + "," + cgstAmount + "," + sgstRate + ","
                        + sgstAmount + "," + cessRateAdvalorem + ","
                        + cessAmountAdvalorem + "," + cessRateSpecific + ","
                        + cessAmountSpecific + "," + invoiceValue + "," + reverseCharge
                        + "," + tcsFlag + "," + eGSTIN + "," + itcFlag + ","
                        + reasonForCreditDebitNote + "," + accountingVoucherNumber
                        + "," + accountingVoucherDate + "," + userdefinedfield1 + ","
                        + userdefinedfield2 + "," + userdefinedfield3 ;
    }*/


}