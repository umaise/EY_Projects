package com.ey.advisory.asp.client.dao;

public interface GstinFinancialsDetailsDao {

	public Double getTurnOverforEntity(String entityId);
	
}
