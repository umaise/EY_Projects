package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblClientsalesRepository", schema="etl")
public class ClientSalesDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int id;
	String fileId;
	String isProcessed;
	Date createdOn;
	String legalEntity;
	String division;
	String documentType;
	String orgDocType;
	String supplyType;
	String sGSTIN;
	String cGSTIN;
	String custCd;
	String custAddr;
	String supplierPlantCd;
	String billToState;
	String shipToState;
	String shBillNo;
	Date shBillDate;
	String docNum;
	Date docDate;
	String orgDocNum;
	Date orgDocDate;
	String unitOfMeasure;
	String billQty;
	BigDecimal unitValue;
	BigDecimal value;
	String discount;
	BigDecimal advance;
	BigDecimal taxableValue;
	String jvnum;
	String transIdAdv;
	String goodsNServices;
	String hsnsac;
	String itemCode;
	String itemDescription;
	BigDecimal iGSTRt;
	BigDecimal iGSTAmt;
	BigDecimal cGSTRt;
	BigDecimal cGSTAmt;
	BigDecimal sGSTRt;
	BigDecimal sGSTAmt;
	BigDecimal cess;
	BigDecimal valueIncTax;
	String pos;
	String reverseCharge;
	String provAsses;
	String gSTINECOM;
	String merchantIDbyECOM;
	String tDS;
	String custRdPermitNum;
	Date custRdPermitDate;
	String transporterName;
	String lorryNumber;
	String suplrRdPermitNum;
	Date suplrRdPermitDate;
	String errorDetail;
	String errorCodes;
	
	

	
	
	
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getErrorCodes() {
		return errorCodes;
	}
	public void setErrorCodes(String errorCodes) {
		this.errorCodes = errorCodes;
	}
	@Column(name="ErrorDetail")
	public String getErrorDetail() {
		return errorDetail;
	}
	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}
	@Column(name="IsProcessed")
	public String getIsProcessed() {
		return isProcessed;
	}
	public void setIsProcessed(String isProcessed) {
		this.isProcessed = isProcessed;
	}
	@Column(name="LegalEntity")
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	@Column(name="Division")
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	@Column(name="DocumentType")
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	@Column(name="OrgDocType")
	public String getOrgDocType() {
		return orgDocType;
	}
	public void setOrgDocType(String orgDocType) {
		this.orgDocType = orgDocType;
	}
	@Column(name="SupplyType")
	public String getSupplyType() {
		return supplyType;
	}
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	@Column(name="CustCd")
	public String getCustCd() {
		return custCd;
	}
	public void setCustCd(String custCd) {
		this.custCd = custCd;
	}
	@Column(name="CustAddr")
	public String getCustAddr() {
		return custAddr;
	}
	public void setCustAddr(String custAddr) {
		this.custAddr = custAddr;
	}
	@Column(name="SupplierPlantCd")
	public String getSupplierPlantCd() {
		return supplierPlantCd;
	}
	public void setSupplierPlantCd(String supplierPlantCd) {
		this.supplierPlantCd = supplierPlantCd;
	}
	@Column(name="BillToState")
	public String getBillToState() {
		return billToState;
	}
	public void setBillToState(String billToState) {
		this.billToState = billToState;
	}
	@Column(name="ShipToState")
	public String getShipToState() {
		return shipToState;
	}
	public void setShipToState(String shipToState) {
		this.shipToState = shipToState;
	}
	@Column(name="ShBillNo")
	public String getShBillNo() {
		return shBillNo;
	}
	public void setShBillNo(String shBillNo) {
		this.shBillNo = shBillNo;
	}
	@Column(name="OrgDocNum")
	public String getOrgDocNum() {
		return orgDocNum;
	}
	public void setOrgDocNum(String orgDocNum) {
		this.orgDocNum = orgDocNum;
	}
	@Column(name="UnitOfMeasure")
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}
	@Column(name="BillQty")
	public String getBillQty() {
		return billQty;
	}
	
	public void setBillQty(String billQty) {
		this.billQty = billQty;
	}
	@Column(name="Discount")
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	@Column(name="JVNum")
	public String getJvnum() {
		return jvnum;
	}
	public void setJvnum(String jvnum) {
		this.jvnum = jvnum;
	}
	@Column(name="TransIdAdv")
	public String getTransIdAdv() {
		return transIdAdv;
	}
	public void setTransIdAdv(String transIdAdv) {
		this.transIdAdv = transIdAdv;
	}
	@Column(name="GoodsNServices")
	public String getGoodsNServices() {
		return goodsNServices;
	}
	public void setGoodsNServices(String goodsNServices) {
		this.goodsNServices = goodsNServices;
	}
	@Column(name="HSNSAC")
	public String getHsnsac() {
		return hsnsac;
	}
	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}
	@Column(name="ItemCode")
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	@Column(name="ItemDescription")
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	
	public String getsGSTIN() {
		return sGSTIN;
	}
	public void setsGSTIN(String sGSTIN) {
		this.sGSTIN = sGSTIN;
	}
	public String getcGSTIN() {
		return cGSTIN;
	}
	public void setcGSTIN(String cGSTIN) {
		this.cGSTIN = cGSTIN;
	}
	
	@Id
	 @GeneratedValue(strategy=GenerationType.AUTO)
	 @Column(name="id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="fileId")
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	@Column(name="docNum")
	public String getDocNum() {
		return docNum;
	}
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getShBillDate() {
		return shBillDate;
	}
	public void setShBillDate(Date shBillDate) {
		this.shBillDate = shBillDate;
	}
	public Date getDocDate() {
		return docDate;
	}
	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}
	public Date getOrgDocDate() {
		return orgDocDate;
	}
	public void setOrgDocDate(Date orgDocDate) {
		this.orgDocDate = orgDocDate;
	}
	public BigDecimal getUnitValue() {
		return unitValue;
	}
	public void setUnitValue(BigDecimal unitValue) {
		this.unitValue = unitValue;
	}
	public BigDecimal getValue() {
		return value;
	}
	public void setValue(BigDecimal value) {
		this.value = value;
	}
	public BigDecimal getAdvance() {
		return advance;
	}
	public void setAdvance(BigDecimal advance) {
		this.advance = advance;
	}
	public BigDecimal getTaxableValue() {
		return taxableValue;
	}
	public void setTaxableValue(BigDecimal taxableValue) {
		this.taxableValue = taxableValue;
	}
	public BigDecimal getiGSTRt() {
		return iGSTRt;
	}
	public void setiGSTRt(BigDecimal iGSTRt) {
		this.iGSTRt = iGSTRt;
	}
	public BigDecimal getiGSTAmt() {
		return iGSTAmt;
	}
	public void setiGSTAmt(BigDecimal iGSTAmt) {
		this.iGSTAmt = iGSTAmt;
	}
	public BigDecimal getcGSTRt() {
		return cGSTRt;
	}
	public void setcGSTRt(BigDecimal cGSTRt) {
		this.cGSTRt = cGSTRt;
	}
	public BigDecimal getcGSTAmt() {
		return cGSTAmt;
	}
	public void setcGSTAmt(BigDecimal cGSTAmt) {
		this.cGSTAmt = cGSTAmt;
	}
	public BigDecimal getsGSTRt() {
		return sGSTRt;
	}
	public void setsGSTRt(BigDecimal sGSTRt) {
		this.sGSTRt = sGSTRt;
	}
	public BigDecimal getsGSTAmt() {
		return sGSTAmt;
	}
	public void setsGSTAmt(BigDecimal sGSTAmt) {
		this.sGSTAmt = sGSTAmt;
	}
	public BigDecimal getCess() {
		return cess;
	}
	public void setCess(BigDecimal cess) {
		this.cess = cess;
	}
	public BigDecimal getValueIncTax() {
		return valueIncTax;
	}
	public void setValueIncTax(BigDecimal valueIncTax) {
		this.valueIncTax = valueIncTax;
	}
	public String getReverseCharge() {
		return reverseCharge;
	}
	public void setReverseCharge(String reverseCharge) {
		this.reverseCharge = reverseCharge;
	}
	public String getProvAsses() {
		return provAsses;
	}
	public void setProvAsses(String provAsses) {
		this.provAsses = provAsses;
	}
	public String getgSTINECOM() {
		return gSTINECOM;
	}
	public void setgSTINECOM(String gSTINECOM) {
		this.gSTINECOM = gSTINECOM;
	}
	public String getMerchantIDbyECOM() {
		return merchantIDbyECOM;
	}
	public void setMerchantIDbyECOM(String merchantIDbyECOM) {
		this.merchantIDbyECOM = merchantIDbyECOM;
	}
	public String gettDS() {
		return tDS;
	}
	public void settDS(String tDS) {
		this.tDS = tDS;
	}
	public String getCustRdPermitNum() {
		return custRdPermitNum;
	}
	public void setCustRdPermitNum(String custRdPermitNum) {
		this.custRdPermitNum = custRdPermitNum;
	}
	public Date getCustRdPermitDate() {
		return custRdPermitDate;
	}
	public void setCustRdPermitDate(Date custRdPermitDate) {
		this.custRdPermitDate = custRdPermitDate;
	}
	public String getTransporterName() {
		return transporterName;
	}
	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}
	public String getLorryNumber() {
		return lorryNumber;
	}
	public void setLorryNumber(String lorryNumber) {
		this.lorryNumber = lorryNumber;
	}
	public String getSuplrRdPermitNum() {
		return suplrRdPermitNum;
	}
	public void setSuplrRdPermitNum(String suplrRdPermitNum) {
		this.suplrRdPermitNum = suplrRdPermitNum;
	}
	public Date getSuplrRdPermitDate() {
		return suplrRdPermitDate;
	}
	public void setSuplrRdPermitDate(Date suplrRdPermitDate) {
		this.suplrRdPermitDate = suplrRdPermitDate;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

}
