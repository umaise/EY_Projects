/*package com.ey.advisory.asp.client.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Sample {
	public static Map<String, List<Map<String, String>>> groupByTableType(List<Map<String, String>> list) {
		Map<String, List<Map<String, String>>> mapGrpBytABLEtYPE = new HashMap<String, List<Map<String,String>>>();
		for (Map<String, String> map : list) {
			if (mapGrpBytABLEtYPE.containsKey(map.get("TableType"))) {
				List<Map<String, String>> list2 = mapGrpBytABLEtYPE.get(map.get("TableType"));
				list2.add(map);
			} else {
				List<Map<String, String>> list2 = new ArrayList<Map<String,String>>();
				list2.add(map);
				mapGrpBytABLEtYPE.put(map.get("TableType"), list2);	
			}
		}
		return mapGrpBytABLEtYPE;
	}
	public static void main(String[] args) {
		String gSTN = "yugewyu";
		String taxPeriod = "012017";
		String sqlSelect = "SELECT from gstr3.tblgstr3TurnOverDetails  WHERE [GSTIN] = "
				+ gSTN + " and [TaxPeriod] = " + taxPeriod;
		List<Map<String, String>> list = hib.select(sqlSelect);
		Map<String, List<Map<String, String>>> mapGrpBytABLEtYPE = groupByTableType(list);
		GSTR3RootDTO dto = new GSTR3RootDTO();
		dto.populateRootDTO(mapGrpBytABLEtYPE);
		
		String sqlSelect = "SELECT * from gstr3.tilemaster";
		List<Map<Grp+SubGrp, String>> list = hib.select(sqlSelect);
		Map<String, Integer> map = MagetAllGrpdbyGrp+SubGrp(list)
		
		map("t.4.1t.4.1.a", 1);
		
		List<String> list2 = dto.getinsertStmnts(map);
	}
}
*/