package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

@SuppressWarnings("serial")
@Entity
@Table(name="tblB2BInvoiceDetails", schema="gstr2F")
public class Gstr2B2BInvoiceDetailsModel implements Serializable{
    
    @Id
    @Column(name="ID")
    private Long invoiceDetailsId;
    
    @Column(name="CustGSTIN")
    private String cust_GSTIN;

    @Column(name="InvDate")
    private Date doc_Date;

    @Column(name="InvNum")
    private String doc_Num;
    
    @Column(name="POS")
    private String placeOfSupply;
    
    @Column(name="RevChrg")
    private String reverseCharge;
    
    @Column(name="Status")
    private String status;
    
    @Column(name="IsAccepted")
    private Integer isAccepted;
    
    @Column(name="Gstin")
    private String gstin;
    
    @Column(name="TaxPeriod")
    private String taxPeriod;
    
    @Column(name="FilingStatus")
    private String filingStatus;
    
    @OneToMany(cascade = CascadeType.REFRESH, mappedBy="gstr2B2BItemDetailsPK.invoiceDetails", fetch = FetchType.EAGER)
    @OrderBy("gstr2B2BItemDetailsPK.lineNo")
    private Set<Gstr2B2BItemDetailsModel> itemDetails = new HashSet<>();
    
    @Transient
    private Set<TblPurchaseErrorInfo> errorInfo = new HashSet<>();

    public Long getInvoiceDetailsId() {
        return invoiceDetailsId;
    }

    public void setInvoiceDetailsId(Long invoiceDetailsId) {
        this.invoiceDetailsId = invoiceDetailsId;
    }

    public String getCust_GSTIN() {
        return cust_GSTIN;
    }

    public void setCust_GSTIN(String cust_GSTIN) {
        this.cust_GSTIN = cust_GSTIN;
    }

    public Date getDoc_Date() {
        return doc_Date;
    }

    public void setDoc_Date(Date doc_Date) {
        this.doc_Date = doc_Date;
    }

    public String getDoc_Num() {
        return doc_Num;
    }

    public void setDoc_Num(String doc_Num) {
        this.doc_Num = doc_Num;
    }

    public String getPlaceOfSupply() {
        return placeOfSupply;
    }

    public void setPlaceOfSupply(String placeOfSupply) {
        this.placeOfSupply = placeOfSupply;
    }

    public String getReverseCharge() {
        return reverseCharge;
    }

    public void setReverseCharge(String reverseCharge) {
        this.reverseCharge = reverseCharge;
    }

    public Set<Gstr2B2BItemDetailsModel> getItemDetails() {
        return itemDetails;
    }

    public void setItemDetails(Set<Gstr2B2BItemDetailsModel> itemDetails) {
        this.itemDetails = itemDetails;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getIsAccepted() {
        return isAccepted;
    }

    public void setIsAccepted(Integer isAccepted) {
        this.isAccepted = isAccepted;
    }

    public String getGstin() {
        return gstin;
    }

    public void setGstin(String gstin) {
        this.gstin = gstin;
    }

    public String getTaxPeriod() {
        return taxPeriod;
    }

    public void setTaxPeriod(String taxPeriod) {
        this.taxPeriod = taxPeriod;
    }

	public String getFilingStatus() {
		return filingStatus;
	}

	public void setFilingStatus(String filingStatus) {
		this.filingStatus = filingStatus;
	}

    public Set<TblPurchaseErrorInfo> getErrorInfo() {
        return errorInfo;
    }

    public void setErrorInfo(Set<TblPurchaseErrorInfo> errorInfo) {
        this.errorInfo = errorInfo;
    }

            
}
