package com.ey.advisory.asp.client.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.TblFileUploadStatusDao;
import com.ey.advisory.asp.client.domain.TblFileUploadStatus;
import com.ey.advisory.asp.client.dto.FileSearchDTO;
import com.ey.advisory.asp.common.Constant;

@Service
@Transactional
public class TblFileUploadStatusServiceImpl implements TblFileUploadStatusService{

	@Autowired
	TblFileUploadStatusDao tblFileUploadStatusDao;
	
	private static final Logger logger = Logger.getLogger(TblFileUploadStatusServiceImpl.class);
	private static final String CLASS_NAME = TblFileUploadStatusServiceImpl.class.getName();
	/* (non-Javadoc)
	 * @see com.ey.advisory.asp.client.service.ClientSpCallService#getFileUploadStatusDetails(java.lang.String)
	 * This method is used to get TblFileUploadStatus list from the database
	 */
	@Override
	public List<TblFileUploadStatus> getFileUploadStatusDetails(String fileId) {
		List<TblFileUploadStatus> loadstatusDetails = new ArrayList<>();
		try {
			loadstatusDetails=tblFileUploadStatusDao.getFileUploadStatusDetails(fileId);
		} catch (Exception exec) {
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME
					+ " Method : getFileUploadStatusDetails()" ,exec);
		}
		return loadstatusDetails;
	}
	
	@Override
	public List<TblFileUploadStatus> getUploadedFiles(FileSearchDTO fileDTO) {
		
		if(fileDTO.getFromDate()!=null && fileDTO.getFromDate().length()!=0)
   			return getFilesByDate(fileDTO);
   		else
   			return getFilesByMonth(fileDTO);
	}
	private List<TblFileUploadStatus> getFilesByDate(FileSearchDTO fileDTO)
	{
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getFilesByDate()");
		}
		List<TblFileUploadStatus> resultList=null;
		try{
		resultList=tblFileUploadStatusDao.getFilesByDate(fileDTO);
		}catch(Exception exec)
		{
		logger.error(Constant.LOGGER_ERROR + CLASS_NAME
				+ " Method : getFilesByDate()" ,exec);
		}
		return resultList;
	}
	
	private List<TblFileUploadStatus> getFilesByMonth(FileSearchDTO fileDTO)
	{
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
				+ " Method : getFilesByMonth()");
		}
		List<TblFileUploadStatus> resultList=null;
		try{
		resultList=tblFileUploadStatusDao.getFilesByMonth(fileDTO);
		}catch(Exception exec)
		{
		logger.error(Constant.LOGGER_ERROR + CLASS_NAME
				+ " Method : getFilesByMonth()" ,exec);
		}
		return resultList;
	}

	@Override
	public String getLastUploadedDate() {
		if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
					+ " Method : getLastUploadedDate()");
			}
		String uploadedDate=tblFileUploadStatusDao.getLastUploadedDate();
		return uploadedDate;
	}
	
	
}
