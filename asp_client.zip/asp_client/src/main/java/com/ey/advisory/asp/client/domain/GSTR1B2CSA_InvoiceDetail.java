package com.ey.advisory.asp.client.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;

import com.ey.advisory.asp.common.Constant;


/**
 * The persistent class for the tblB2CSAInvoiceDetails database table.
 * 
 */
@Entity
@Table(name="tblB2CSAInvoiceDetails", schema=Constant.GSTR1_SCHEMA)
public class GSTR1B2CSA_InvoiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(GSTR1B2CSA_InvoiceDetail.class);

	@Id
	@Column(name="ID")
	private long id;
	
	@Column(name="InvNum")
    private String invNum;
	
	@Column(name="InvDate")
    private Date invDate;
	
	@Column(name="InvValue")
	private BigDecimal invValue;

	@Column(name="CessAmt")
	private BigDecimal cessAmt;

	@Column(name="CessRt")
	private BigDecimal cessRt;

	@Column(name="CGSTAmt")
	private BigDecimal CGSTAmt;

	@Column(name="CGSTRt")
	private BigDecimal CGSTRt;

	@Column(name="ChkSum")
	private String chkSum;

	@Column(name="Etin")
	private String etin;

	@Column(name="FileID")
	private long fileID;

	@Column(name="Flag")
	private String flag;

	@Column(name="Gstin")
	private String gstin;

	@Column(name="HSNSC")
	private String hsnsc;

	@Column(name="IGSTAmt")
	private BigDecimal IGSTAmt;

	@Column(name="IGSTRt")
	private BigDecimal IGSTRt;

	@Column(name="IsDelete")
	private boolean isDelete;

	@Column(name="ItemTaxVal")
	private BigDecimal itemTaxVal;

	@Column(name="ItemType")
	private String itemType;

	@Column(name="OrderDt")
	private Date orderDt;

	@Column(name="OrderNo")
	private String orderNo;

	@Column(name="OrgHSNSC")
	private String orgHSNSC;

	@Column(name="Category")
	private String category;
	
	@Column(name="SubCategory")
	private String subCategory;
	
	@Column(name="OrgItemTyp")
	private String orgItemTyp;

	@Column(name="OrgMonth")
	private String orgMonth;

	@Column(name="OrgStateCd")
	private String orgStateCd;

	@Column(name="ProvAsses")
	private String provAsses;

	@Column(name="SGSTAmt")
	private BigDecimal SGSTAmt;

	@Column(name="SGSTRt")
	private BigDecimal SGSTRt;

	@Column(name="StateCd")
	private String stateCd;
	
	@Column(name="OrgInvDate")
	private Date orgInvDate;

	@Column(name="OrgInvNum")
	private String orgInvNum;

	@Column(name="Taxablevalue")
	private BigDecimal taxablevalue;

	@Column(name="TaxPeriod")
	private String taxPeriod;
	
	@Column(name="InvoiceKey")
	private String invoiceKey;
	
	public String getInvoiceKey() {
		return invoiceKey;
	}

	public void setInvoiceKey(String invoiceKey) {
		this.invoiceKey = invoiceKey;
	}

	public GSTR1B2CSA_InvoiceDetail() {
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("in GSTR1B2CSA_InvoiceDetail ");
			}
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	
	public String getInvNum() {
		return invNum;
	}

	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	public Date getInvDate() {
		return invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public BigDecimal getInvValue() {
		return invValue;
	}

	public void setInvValue(BigDecimal invValue) {
		this.invValue = invValue;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public BigDecimal getCessAmt() {
		return this.cessAmt;
	}

	public void setCessAmt(BigDecimal cessAmt) {
		this.cessAmt = cessAmt;
	}

	public BigDecimal getCessRt() {
		return this.cessRt;
	}

	public void setCessRt(BigDecimal cessRt) {
		this.cessRt = cessRt;
	}

	public BigDecimal getCGSTAmt() {
		return this.CGSTAmt;
	}

	public void setCGSTAmt(BigDecimal CGSTAmt) {
		this.CGSTAmt = CGSTAmt;
	}

	public BigDecimal getCGSTRt() {
		return this.CGSTRt;
	}

	public void setCGSTRt(BigDecimal CGSTRt) {
		this.CGSTRt = CGSTRt;
	}

	public String getChkSum() {
		return this.chkSum;
	}

	public void setChkSum(String chkSum) {
		this.chkSum = chkSum;
	}

	public String getEtin() {
		return this.etin;
	}

	public void setEtin(String etin) {
		this.etin = etin;
	}

	public long getFileID() {
		return this.fileID;
	}

	public void setFileID(long fileID) {
		this.fileID = fileID;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getHsnsc() {
		return this.hsnsc;
	}

	public void setHsnsc(String hsnsc) {
		this.hsnsc = hsnsc;
	}

	public BigDecimal getIGSTAmt() {
		return this.IGSTAmt;
	}

	public void setIGSTAmt(BigDecimal IGSTAmt) {
		this.IGSTAmt = IGSTAmt;
	}

	public BigDecimal getIGSTRt() {
		return this.IGSTRt;
	}

	public void setIGSTRt(BigDecimal IGSTRt) {
		this.IGSTRt = IGSTRt;
	}

	public boolean getIsDelete() {
		return this.isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public BigDecimal getItemTaxVal() {
		return this.itemTaxVal;
	}

	public void setItemTaxVal(BigDecimal itemTaxVal) {
		this.itemTaxVal = itemTaxVal;
	}

	public String getItemType() {
		return this.itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public Date getOrderDt() {
		return this.orderDt;
	}

	public void setOrderDt(Date orderDt) {
		this.orderDt = orderDt;
	}

	public String getOrderNo() {
		return this.orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getOrgHSNSC() {
		return this.orgHSNSC;
	}

	public void setOrgHSNSC(String orgHSNSC) {
		this.orgHSNSC = orgHSNSC;
	}

	public String getOrgItemTyp() {
		return this.orgItemTyp;
	}

	public void setOrgItemTyp(String orgItemTyp) {
		this.orgItemTyp = orgItemTyp;
	}

	public String getOrgMonth() {
		return this.orgMonth;
	}

	public void setOrgMonth(String orgMonth) {
		this.orgMonth = orgMonth;
	}

	public String getOrgStateCd() {
		return this.orgStateCd;
	}

	public void setOrgStateCd(String orgStateCd) {
		this.orgStateCd = orgStateCd;
	}

	public String getProvAsses() {
		return this.provAsses;
	}

	public void setProvAsses(String provAsses) {
		this.provAsses = provAsses;
	}

	public BigDecimal getSGSTAmt() {
		return this.SGSTAmt;
	}

	public void setSGSTAmt(BigDecimal SGSTAmt) {
		this.SGSTAmt = SGSTAmt;
	}

	public BigDecimal getSGSTRt() {
		return this.SGSTRt;
	}

	public void setSGSTRt(BigDecimal SGSTRt) {
		this.SGSTRt = SGSTRt;
	}

	public String getStateCd() {
		return this.stateCd;
	}

	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}

	public BigDecimal getTaxablevalue() {
		return this.taxablevalue;
	}

	public void setTaxablevalue(BigDecimal taxablevalue) {
		this.taxablevalue = taxablevalue;
	}

	public String getTaxPeriod() {
		return this.taxPeriod;
	}

	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public Date getOrgInvDate() {
		return orgInvDate;
	}

	public void setOrgInvDate(Date orgInvDate) {
		this.orgInvDate = orgInvDate;
	}

	public String getOrgInvNum() {
		return orgInvNum;
	}

	public void setOrgInvNum(String orgInvNum) {
		this.orgInvNum = orgInvNum;
	}

	
}