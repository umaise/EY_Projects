package com.ey.advisory.asp.client.dao;

import com.ey.advisory.asp.client.domain.ReconStatus;

public interface ReconStatusDao {
	
	public ReconStatus getReconStatus(String gstin,String taxPeriod,Integer masterId);
	
	public String getMatchedReconRecords(String gstin,String taxPeriod,int offset,int pageSize);
	
	public String getMatchedAspReconRecords(String gstin,String taxPeriod,int offset,int pageSize);
	
	public String getMisMatchedReconRecords(String gstin,String taxPeriod,int offset,int pageSize);
	
	public String getAdditionalReconRecords(String gstin,String taxPeriod,int offset,int pageSize);
	
	public String getReconMissingRecords(String gstin,String taxPeriod,int offset,int pageSize);

	public void saveReconStatus(String gstin,String taxPeriod,Integer masterId);
	
	public void updateReconStatus(String gstin, String taxPeriod,Integer masterId);
	
	public ReconStatus getActiveReconStatus(String gstin,String taxPeriod);
	
	public ReconStatus getReconStatus(String gstin,String taxPeriod);

	public void updateReconReportStatus(String gstin, String taxPeriod, String missingReport, String inProgress);

	public ReconStatus getReconReportStatus(String gstin, String taxPeriod);
	
	public void updateReconCompletedDate(String gstin, String taxPeriod,Integer masterId);
	
	public void updateReconStatus(String gstin, String taxPeriod,Integer masterId,String status); 
}
