package com.ey.advisory.asp.client.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.advisory.asp.client.dao.GSTR1FFDao;
import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.common.Constant;

@Service
@Transactional
public class TblGstinRetutnFilingStatusServiceImpl implements TblGstinRetutnFilingStatusService{
	@Autowired
	ReturnFilingDao returnFilingDao;
	private static final Logger logger = Logger.getLogger(TblGSTINSummaryListServiceImpl.class);
	
	@Autowired
	GSTR1FFDao gstr1ffdao;
	
	@Override
    public String insertGstr2AFilingStatus(List<String> outputParamList) {
		
         logger.info("*********** entering Job insertGstr2AFilingStatus " +outputParamList.get(0));
          try{
        	 returnFilingDao.insertGstr2AReconFilingStatus(outputParamList);
           
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job insertGstr2AFilingStatus ",e);
		} 
         return "Success";
    }


	@Override
	public List<TblGstinRetutnFilingStatus> loadDataFromTblGSTinReturnFillingStatus() {
		List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatusList = null;
		try
		{
			tblGstinRetutnFilingStatusList=loadDataFromTblGSTinReturnFillingStatus();
		 }
		catch(Exception ex)
		{
			logger.error("*********** ERROR in Job loadDataFromTblGSTinReturnFillingStatus ",ex);
		}
		return tblGstinRetutnFilingStatusList;
	}


	@Override
	public String validateSavedStatus(String gstinId, String tax, String returnType) {
		return returnFilingDao.validateSavedStatus(gstinId, tax, returnType);
	}


	@Override
	public boolean insertGstr3BSubmitStatus(String gstin, String taxPeriod) {
		logger.info("*********** entering Job insertGstr3BSubmitStatus gstin = " +gstin+" taxPeriod = "+taxPeriod);
		boolean status = false;
		  try{
			  status = returnFilingDao.insertGstr3BSubmitStatus(gstin, taxPeriod);
			} catch (Exception e) {
				 logger.error("*********** ERROR in Job insertGstr3BSubmitStatus ",e);
			} 
		return status;
	}


	@Override
	public boolean getGstr3BStatus(String gstin, String taxPeriod) {
		logger.info("*********** entering Job getGstr3BStatus gstin = " +gstin+" taxPeriod = "+taxPeriod);
		boolean status = false;
		  try{
			  status = returnFilingDao.getGstr3BStatus(gstin, taxPeriod);
			} catch (Exception e) {
				 logger.error("*********** ERROR in Job getGstr3BStatus ",e);
			} 
		return status;
	}


	@Override
	public boolean saveAllGstinReturnFilingStatus(
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatusList) {
		return returnFilingDao.saveAllGstinReturnFilingStatus(gstinRetutnFilingStatusList);		
	}


	@Override
	public TblGstinRetutnFilingStatus getStatusFor2A(String gstinId, String taxPeriod, String status) {

        logger.info("*********** entering Job getStatusFor2A " +gstinId);
         try{
        	 return returnFilingDao.getStatusFor2A(gstinId, taxPeriod, status);
          
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job getStatusFor2A ",e);
		} 
        return null;
	}
	@Override
    public String updateGstr2AStatus(List<String> outputParamList) {
		
         logger.info("*********** entering Job insertGstr2AFilingStatus " +outputParamList.get(0));
          try{
        	 returnFilingDao.insertGstr2AStatus(outputParamList);
           
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job insertGstr2AFilingStatus ",e);
		} 
         return "Success";
    }
	
/*	@Override
	public String findGstr1FFStatus(List<String> outputParamList) {
		String status = Constant.IN_PROGRESS;
		logger.info("*********** entering Job insertGstr2AFilingStatus " +outputParamList.get(0));
		try{
			TblGstinRetutnFilingStatus returnFilingStatus = gstr1ffdao.getGSTR1FFEntry(outputParamList);
			if(returnFilingStatus == null)
				status = Constant.FAILED;
			else 
				status = returnFilingStatus.getStatus();
			
		} catch (Exception e) {
			logger.error("*********** ERROR in Job insertGstr2AFilingStatus ",e);
		} 
		return status;
	}
	*/
	@Override
	public String updateGstr1FFStatus(List<String> outputParamList) {
		
		logger.info("*********** entering Job insertGstr2AFilingStatus " +outputParamList.get(0));
		try{
			gstr1ffdao.insertGSTR1FFStatus(outputParamList);
			
		} catch (Exception e) {
			logger.error("*********** ERROR in Job insertGstr2AFilingStatus ",e);
		} 
		return "Success";
	}
	
	@Override
    public String insertGstr2AEntry(List<String> outputParamList) {
		
         logger.info("*********** entering Job insertGstr2AFilingStatus " +outputParamList.get(0));
          try{
        	 TblGstinRetutnFilingStatus filingStatus =  returnFilingDao.checkGSTR2AEntry(outputParamList.get(1), outputParamList.get(0));
        	 if(filingStatus==null)
        	 returnFilingDao.insertGstr2AStatus(outputParamList);
           
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job insertGstr2AFilingStatus ",e);
		} 
         return "Success";
    }
	
	
	@Override
	public String insertGstr1FFEntry( List<String> outputParamList) {
		
		logger.info("*********** entering Job insertGstr1FFFilingStatus " +outputParamList.get(0));
		try{
			TblGstinRetutnFilingStatus filingStatus =  gstr1ffdao.checkGSTR1FFEntry(outputParamList.get(1), outputParamList.get(0));
			if(filingStatus==null)
				gstr1ffdao.insertGSTR1FFStatus(outputParamList);
			
		} catch (Exception e) {
			logger.error("*********** ERROR in Job insertGstr1FFFilingStatus ",e);
		} 
		return "Success";
	}
	
	
	@Override
	public String getStatusFor1FF(String gstinId, String taxPeriod, String api) {
		String status = null;
        logger.info("*********** entering Job getStatusFor1FF " +gstinId);
         try{
        	 status =  returnFilingDao.getStatusFor1FF(gstinId, taxPeriod, api);
          
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job getStatusFor1FF ",e);
		} 
        return status;
	}

	@Override
	public TblGstinRetutnFilingStatus fetchGstrReturnDetails(String gstinId, String taxPeriod, String returnType) {

        logger.info("*********** entering Job fetchGstrReturnDetails " +gstinId);
        TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus = null;
         try{
        	 tblGstinRetutnFilingStatus = returnFilingDao.fetchGstrReturnDetails(gstinId,taxPeriod,returnType);
          
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job fetchGstrReturnDetails ",e);
		} 
        return tblGstinRetutnFilingStatus;
	}
	
	@Override
	public TblGstinRetutnFilingStatus getStatusForReconReport(String gstinId, String taxPeriod, String status) {
		 logger.info("*********** entering Job getStatusFor2A " +gstinId);
         try{
        	 return returnFilingDao.getStatusForReconReport(gstinId, taxPeriod, status);
          
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job getStatusFor2A ",e);
		} 
        return null;
	}
	
	@Override
	public TblGstinRetutnFilingStatus getStatusFor6A(String gstinId, String taxPeriod, String status) {

        logger.info("*********** entering Job getStatusFor6A " +gstinId);
         try{
        	 return returnFilingDao.getStatusFor6A(gstinId, taxPeriod, status);
          
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job getStatusFor6A ",e);
		} 
        return null;
	}
	
	@Override
    public String insertGstr6AEntry(List<String> outputParamList) {
		
         logger.info("*********** entering Job insertGstr6AFilingStatus " +outputParamList.get(0));
          try{
        	 TblGstinRetutnFilingStatus filingStatus =  returnFilingDao.checkGSTR6AEntry(outputParamList.get(1), outputParamList.get(0));
        	 if(filingStatus==null)
        	 returnFilingDao.insertGstr6AStatus(outputParamList);
           
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job insertGstr6AFilingStatus ",e);
		} 
         return "Success";
    }
	
	@Override
    public String updateGstr6AStatus(List<String> outputParamList) {
		
         logger.info("*********** entering Job insertGstr6AFilingStatus " +outputParamList.get(0));
          try{
        	 returnFilingDao.insertGstr6AStatus(outputParamList);
           
		} catch (Exception e) {
			 logger.error("*********** ERROR in Job insertGstr6AFilingStatus ",e);
		} 
         return "Success";
    }
}
