package com.ey.advisory.asp.client.util;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.ey.advisory.asp.common.Constant;

@Component
@PropertySource("classpath:RestConfig.properties")
public class StubUtility {
	private static final Logger LOGGER = Logger.getLogger(StubUtility.class);

	@Autowired
	RestTemplate restTemplatewithoutProxy;

	@Autowired
	private Environment env;

	// POST
	public String executeRestCall(String uri, HttpHeaders httpHeaders, String inputData, HttpMethod httpMethod) {
		String result = "";
		HttpEntity<String> entity = new HttpEntity<>(inputData, httpHeaders);
		try {
			ResponseEntity<String> response = restTemplatewithoutProxy.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpClientErrorException hcee) {
			LOGGER.error("Inside Batch Client Util: HttpClientErrorException",hcee);
				return hcee.getMessage();
		}catch (HttpServerErrorException hsee) {
			LOGGER.error("Inside Batch Client Util: HttpServerErrorException",hsee);
			return hsee.getMessage();
		}catch (HttpStatusCodeException hsce) {
			LOGGER.error("Inside Batch Client Util: HttpStatusCodeException",hsce);
				return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error("Inside Batch Client Util: RestClientException",rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error("Inside Batch Client Util: Exception",e);
			return e.getMessage();
		}
		return result;
	}

	public String executeRestCall(String uri, HttpHeaders httpHeaders, HttpMethod httpMethod) {
		String result = "";
		HttpEntity<Object> entity = new HttpEntity<>(httpHeaders);
		try {
			ResponseEntity<String> response = restTemplatewithoutProxy.exchange(uri, httpMethod, entity, String.class);
			result = response.getBody();
		} catch (HttpClientErrorException hcee) {
			LOGGER.error("Inside Batch Client Util: HttpClientErrorException",hcee);
				return hcee.getMessage();
		}catch (HttpStatusCodeException hsce) {
			LOGGER.error("Inside Batch Client Util: HttpStatusCodeException",hsce);
				return hsce.getResponseBodyAsString();
		} catch (RestClientException rce) {
			LOGGER.error("Inside Batch Client Util: RestClientException",rce);
			return rce.getMessage();
		} catch (Exception e) {
			LOGGER.error("Inside Batch Client Util: Exception",e);
			return e.getMessage();
		}

		return result;
	}

}
