package com.ey.advisory.asp.client.dao;

import com.ey.advisory.asp.client.domain.SummaryFileLoadMaster;

public interface SummaryFileUploadDao {

	public String insertSummaryFileUploadDetails(
			SummaryFileLoadMaster summaryFileLoadMaster);

	public String updateSummaryFileLoadMaster(String status, int summaryFileId,int recordCount);
}
