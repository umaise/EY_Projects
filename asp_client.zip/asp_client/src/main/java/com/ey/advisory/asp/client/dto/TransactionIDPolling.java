package com.ey.advisory.asp.client.dto;

public class TransactionIDPolling {

	private Long filingId;
	private String trxId;
	private String gstinId;
	private String taxPeriod;
	private String refId;
	private Long loadId;
	private String returnType;
	private String groupCode;
	private String gstnStatus;
	private String errorDesc;
	
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public String getGstnStatus() {
		return gstnStatus;
	}
	public void setGstnStatus(String gstnStatus) {
		this.gstnStatus = gstnStatus;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public Long getFilingId() {
		return filingId;
	}
	public void setFilingId(Long filingId) {
		this.filingId = filingId;
	}
	public String getTrxId() {
		return trxId;
	}
	public void setTrxId(String trxId) {
		this.trxId = trxId;
	}
	public String getGstinId() {
		return gstinId;
	}
	public void setGstinId(String gstinId) {
		this.gstinId = gstinId;
	}
	public String getTaxPeriod() {
		return taxPeriod;
	}
	public void setTaxPeriod(String taxPeriod) {
		this.taxPeriod = taxPeriod;
	}
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	public Long getLoadId() {
		return loadId;
	}
	public void setLoadId(Long loadId) {
		this.loadId = loadId;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	
	@Override
	public String toString() {
		return "TransactionIDPolling [filingId=" + filingId + ", trxId=" + trxId + ", gstinId=" + gstinId
				+ ", taxPeriod=" + taxPeriod + ", refId=" + refId + ", loadId=" + loadId + ", returnType=" + returnType
				+ ", groupCode=" + groupCode + "]";
	}
	
	
}
