package com.ey.advisory.asp.client.dao.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ey.advisory.asp.client.dao.HibernateDao;
import com.ey.advisory.asp.client.dao.ReturnFilingDao;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatus;
import com.ey.advisory.asp.client.domain.TblGstinRetutnFilingStatusPK;
import com.ey.advisory.asp.common.Constant;

@Repository
public class  ReturnFilingDaoImpl implements  ReturnFilingDao {

	@Autowired
	private HibernateDao  hibernateDao;

	private static final Logger logger = Logger.getLogger(ReturnFilingDaoImpl.class);
	private static final String CLASS_NAME = ReturnFilingDaoImpl.class.getName();


	@Override
	public TblGstinRetutnFilingStatus fetchGstrReturnDetails(String gstinId, String taxPeriod, String returnType) {		     
		DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
		
		detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
		detachedCriteria.add(Restrictions.eq("id.returnType", returnType));
		      
		if(returnType.equalsIgnoreCase(Constant.GSTR_1) || returnType.equalsIgnoreCase(Constant.GSTR_2) || returnType.equalsIgnoreCase(Constant.GSTR_7)){
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
		}
		if(returnType.equalsIgnoreCase(Constant.GSTR_3)){
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat dateFormat = new SimpleDateFormat("MMyyyy");
			cal.set(Integer
					.parseInt(taxPeriod.substring(2, taxPeriod.length())),
					Integer.parseInt(taxPeriod.substring(0, 2)) - 2, Integer
							.parseInt("1"));	

			detachedCriteria.add(Restrictions.eq("status", Constant.FILED));
			detachedCriteria.add(Restrictions.eq("isSuccess", true));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod",
					dateFormat.format(cal.getTime())));
		}
		
		if(returnType.equalsIgnoreCase(Constant.GSTR_6)){
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat dateFormat = new SimpleDateFormat("MMyyyy");
			cal.set(Integer.parseInt(taxPeriod.substring(2, taxPeriod.length())),Integer.parseInt(taxPeriod.substring(0, 2)) - 2, Integer.parseInt("1"));

			detachedCriteria.add(Restrictions.eq("status", Constant.FILED));
			detachedCriteria.add(Restrictions.eq("isSuccess", true));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod",dateFormat.format(cal.getTime())));
		}
		
		if(returnType.equalsIgnoreCase(Constant.GSTR2A)){
			detachedCriteria.add(Restrictions.eq("status", "DATA_RECEIVED"));
			detachedCriteria.add(Restrictions.eq("isSuccess", true));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod",taxPeriod));
		}
		List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = null;
		try{
			gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
		}
		catch(Exception ex){
			logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"fetchGstrReturnDetails" +ex);
		}
		      
		if(gstinRetutnFilingStatus!=null && !gstinRetutnFilingStatus.isEmpty()){
			return gstinRetutnFilingStatus.get(0);
		}
		return null;
	}

	@Override
	public Date getReturnFilingDate(String fy, String sGSTIN, String returnName) {
		DetachedCriteria detachedCriteria = hibernateDao
				.createCriteria(TblGstinRetutnFilingStatus.class);
		detachedCriteria
				.add(Restrictions.eq("id.gstinId", sGSTIN));
		detachedCriteria.add(Restrictions.eq("id.taxPeriod", fy));
		detachedCriteria.add(Restrictions.eq("id.returnType", returnName));

		Date returnFilingDate = null;
		
		List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
		if(!gstinRetutnFilingStatus.isEmpty()){
			returnFilingDate = gstinRetutnFilingStatus.get(0).getFileDate();
		}
		return returnFilingDate;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<TblGstinRetutnFilingStatus> getReturnFilingDetails(List<String> returnPeriodList, List<String> returnType,String  gstin,String status, boolean eFiled ) {
		DetachedCriteria detachedCriteria = hibernateDao
				.createCriteria(TblGstinRetutnFilingStatus.class);
		detachedCriteria
				.add(Restrictions.eq("id.gstinId", gstin));
		detachedCriteria.add(Restrictions.in("id.taxPeriod",  returnPeriodList));
		detachedCriteria.add(Restrictions.in("id.returnType", returnType));
		if(eFiled){
			detachedCriteria.add(Restrictions.eq("status", status));
			detachedCriteria.add(Restrictions.eq("isSuccess", true));

		}else{
			detachedCriteria.add(Restrictions.ne("status", status));
		}
		
		detachedCriteria.addOrder(Order.desc("id.taxPeriod"));
		
		List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
		return gstinRetutnFilingStatus;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<TblGstinRetutnFilingStatus> getReturnFilingDetails(List<String> returnType,String  gstin,String status, boolean eFiled ) {
		Session session = null;
		String sql = null;
		Query query;
		List<TblGstinRetutnFilingStatus> result = null;
		
		try {
			session = hibernateDao.getSession();
			if(eFiled){
				sql= "select * from [master].[tblGstinReturnFilingStatus]" 
						  +" where GstinId=:gstinid and Status =:status and IsSuccess=:isSuccess and ReturnType in :returnType  order by SUBSTRING([TaxPeriod],3,4) DESC,"
							+" SUBSTRING([TaxPeriod],1,2) DESC" ;
				query = session.createSQLQuery(sql)
						.addEntity(TblGstinRetutnFilingStatus.class)
						.setParameter("gstinid", gstin).setParameter("status", status).setParameter("isSuccess", true).setParameterList("returnType", returnType);
				result = query.list();
			}else{
				sql= "select * from [master].[tblGstinReturnFilingStatus]" 
						  +" where GstinId=:gstinid and Status !=:status and ReturnType in :returnType  order by SUBSTRING([TaxPeriod],3,4) ASC,"
							+" SUBSTRING([TaxPeriod],1,2) ASC" ;
				query = session.createSQLQuery(sql)
						.addEntity(TblGstinRetutnFilingStatus.class)
						.setParameter("gstinid", gstin).setParameter("status", status).setParameterList("returnType", returnType);
				result = query.list();
			}
		} catch (Exception e) {
			logger.error(e);
		} finally {
			if(session!=null && session.isOpen()) {
				session.close();
			}
		}
		return result;	
	}
	
	
	@Override
	public TblGstinRetutnFilingStatus getReturnFilingDetails(String returnPeriod, String sGSTIN, String returnName, String status) {
		DetachedCriteria detachedCriteria = hibernateDao
				.createCriteria(TblGstinRetutnFilingStatus.class);
		detachedCriteria
				.add(Restrictions.eq("id.gstinId", sGSTIN));
		detachedCriteria.add(Restrictions.eq("id.taxPeriod", returnPeriod));
		detachedCriteria.add(Restrictions.eq("id.returnType", returnName));
		detachedCriteria.add(Restrictions.eq("status", status));

		TblGstinRetutnFilingStatus returnFilingDetails = null;
		
		List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
		if(null!=gstinRetutnFilingStatus && !gstinRetutnFilingStatus.isEmpty()){
			returnFilingDetails = gstinRetutnFilingStatus.get(0);
		}
		return returnFilingDetails;
	}
	
	@Override
	public TblGstinRetutnFilingStatus getEFilingSummary(String returnPeriod, String sGSTIN, String returnName, String fileStatus, boolean isSuccess) {
		DetachedCriteria detachedCriteria = hibernateDao
				.createCriteria(TblGstinRetutnFilingStatus.class);
		detachedCriteria
				.add(Restrictions.eq("id.gstinId", sGSTIN));
		detachedCriteria.add(Restrictions.eq("id.taxPeriod", returnPeriod));
		detachedCriteria.add(Restrictions.eq("id.returnType", returnName));
		detachedCriteria.add(Restrictions.eq("status", fileStatus));
		detachedCriteria.add(Restrictions.eq("isSuccess", isSuccess));
		TblGstinRetutnFilingStatus returnFilingDetails = null;
		
		List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
		if(null!=gstinRetutnFilingStatus && !gstinRetutnFilingStatus.isEmpty()){
			returnFilingDetails = gstinRetutnFilingStatus.get(0);
		}
		return returnFilingDetails;
	}

	@Override
	public String insertGstr2AFilingStatus(List<String> outputParamList) {
		if(logger.isInfoEnabled()){
		logger.info("*********** entering Job insertGstr2AFilingStatus " +outputParamList.get(0));
		}
		TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
		
		TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
		tblGstinRetutnFilingStatusPK.setGstinId(outputParamList.get(0));
		tblGstinRetutnFilingStatusPK.setReturnType(Constant.FILING_RECORD_TYPE_GSTR2A);
		tblGstinRetutnFilingStatusPK.setTaxPeriod(outputParamList.get(1));
		tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
		tblGstinRetutnFilingStatus.setStatus(Constant.FILING_RECORD_TYPE_GSTR2A_DONE);
		hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
		if(logger.isInfoEnabled()){
		logger.info("*********** exiting Job insertGstr2AFilingStatus " +outputParamList.get(0));
		}
		return "success";
	}
	
	@Override
	public void insertReturnFilingData(String gstnId, String gstr1Filing,
			String taxPeriod, String acknowledge) {
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+"insertReturnFilingData");
		}
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject; 
		try {
			jsonObject = (JSONObject) jsonParser
					.parse(acknowledge); 
		
		String ackNum = (String) jsonObject.get(Constant.ACK_NUM);
		
		TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
		
		TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
		tblGstinRetutnFilingStatusPK.setGstinId(gstnId);
		tblGstinRetutnFilingStatusPK.setReturnType(gstr1Filing);
		tblGstinRetutnFilingStatusPK.setTaxPeriod(taxPeriod);
		tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
		tblGstinRetutnFilingStatus.setFileAckNum(ackNum);
		tblGstinRetutnFilingStatus.setStatus(Constant.FILED);
		tblGstinRetutnFilingStatus.setIsSuccess(false);
		tblGstinRetutnFilingStatus.setFileDate(new Timestamp(System.currentTimeMillis()));
			hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
		} catch (Exception e) {
			if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"insertReturnFilingData" +e);
			}
		}
		if(logger.isInfoEnabled())
		logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+"insertReturnFilingData");
	}
	
    @Override
    public void saveGstinReturnFillingStatus(Set<String> custGSTINTaxPeriod) {
        
        for (String customerGSTINTaxPeriod : custGSTINTaxPeriod) {
            String[] custGstin = StringUtils.split(customerGSTINTaxPeriod, Constant.FIELD_SEPERATOR);
            
            TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
            
            TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
            tblGstinRetutnFilingStatusPK.setGstinId(custGstin[0]);
            tblGstinRetutnFilingStatusPK.setReturnType(Constant.GSTR2_Filing);
            tblGstinRetutnFilingStatusPK.setTaxPeriod(custGstin[1]);            
            tblGstinRetutnFilingStatus.setStatus(Constant.STATUS_RECON_COMPLETE);
            tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
            hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);            
        }
    }
    
    @Override
    public String getReturnFilingSuccess(String gstinId, String returnType,String taxPeriod) {
    	if(logger.isInfoEnabled()){
    	logger.info(Constant.LOGGER_ENTERING + CLASS_NAME +Constant.LOGGER_METHOD+"getReturnFilingSuccess");
    	}
    	
    	DetachedCriteria detachedCriteria = hibernateDao
				.createCriteria(TblGstinRetutnFilingStatus.class);
    	ProjectionList projList = Projections.projectionList();
		detachedCriteria
				.add(Restrictions.eq("id.gstinId", gstinId));
		detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
		detachedCriteria.add(Restrictions.eq("id.returnType", returnType));
		projList.add(Projections.property("isSuccess"));
		detachedCriteria.setProjection(projList);
		
		List<?> successList = null;
		try {
			successList = hibernateDao.find(detachedCriteria);
		} catch (Exception e) {
			if(logger.isInfoEnabled()){
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"getReturnFilingSuccess" +e);
			}
		}
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"getReturnFilingSuccess");

		}


		if(successList!=null && !successList.isEmpty()){

			return successList.get(0).toString();
		}
		else
		{
			return "true";
		}
    }
	
    @Override
	public List<TblGstinRetutnFilingStatus> getReturnFilingDetailsForGSTR1A(String returnPeriod, String returnName, String retFilingStatus, boolean status) {
		DetachedCriteria detachedCriteria = hibernateDao
				.createCriteria(TblGstinRetutnFilingStatus.class);
		
		detachedCriteria.add(Restrictions.eq("id.taxPeriod", returnPeriod));
		detachedCriteria.add(Restrictions.eq("id.returnType", returnName));
		detachedCriteria.add(Restrictions.eq("status", retFilingStatus));
		detachedCriteria.add(Restrictions.eq("isSuccess", status));
		
		List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
		
		return gstinRetutnFilingStatus;
	}
	
	
	@Override
	public TblGstinRetutnFilingStatus gstr7FilingReturnDetails(String gstinId, String taxPeriod, String returnType) {
		// TODO Auto-generated method stub
		DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
		
		detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
		detachedCriteria.add(Restrictions.eq("id.returnType", returnType));
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMyyyy");
		cal.set(Integer.parseInt(taxPeriod.substring(2, taxPeriod.length())),Integer.parseInt(taxPeriod.substring(0, 2)) - 2, Integer.parseInt("1"));
		detachedCriteria.add(Restrictions.eq("status", Constant.FILED));
		detachedCriteria.add(Restrictions.eq("isSuccess", true));
		detachedCriteria.add(Restrictions.eq("id.taxPeriod",
		dateFormat.format(cal.getTime())));
		List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
		if(gstinRetutnFilingStatus!=null && !gstinRetutnFilingStatus.isEmpty()){
			return gstinRetutnFilingStatus.get(0);
		}
		return null;
	}

	@Override
	public void updateReturnFilingDetailsForSubmit(String gstin, String txprd, String ref_id,
			String submitted) throws Exception{
		
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"upDateReturnFilingDetailsForSubmit");
		}
		TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
		  TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
          tblGstinRetutnFilingStatusPK.setGstinId(gstin);
          tblGstinRetutnFilingStatusPK.setReturnType(Constant.GSTR1_Filing);
          tblGstinRetutnFilingStatusPK.setTaxPeriod(txprd);            
          tblGstinRetutnFilingStatus.setStatus(Constant.SUBMITTED);
          tblGstinRetutnFilingStatus.setSubmitRefId(ref_id);
          tblGstinRetutnFilingStatus.setIsSuccess(true);
          tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
          hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus); 
		
		
	}
	
	
	@Override
	public void updateReturnFilingDetailsForSubmitGstr2(String gstin, String txprd, String ref_id,
			String submitted) throws Exception{
		
		if(logger.isInfoEnabled()){
		logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"upDateReturnFilingDetailsForSubmitGstr2");
		}
		TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
		  TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
          tblGstinRetutnFilingStatusPK.setGstinId(gstin);
          tblGstinRetutnFilingStatusPK.setReturnType(Constant.GSTR2_Filing);
          tblGstinRetutnFilingStatusPK.setTaxPeriod(txprd);            
          tblGstinRetutnFilingStatus.setStatus(Constant.SUBMITTED);
          tblGstinRetutnFilingStatus.setSubmitRefId(ref_id);
          tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
          hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus); 
	}
	
	@Override
    public String insertGstr2AReconFilingStatus(List<String> outputParamList) {
		
		if(logger.isInfoEnabled()){
         logger.info("*********** entering Job insertGstr2AFilingStatus " +outputParamList.get(0));
		}
         
         try{
           TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
         
         TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
         tblGstinRetutnFilingStatusPK.setGstinId(outputParamList.get(0));
         tblGstinRetutnFilingStatusPK.setReturnType(Constant.GSTR2A);
         tblGstinRetutnFilingStatusPK.setTaxPeriod(outputParamList.get(1));            
         tblGstinRetutnFilingStatus.setStatus(Constant.RECONSTATE);
         tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
         tblGstinRetutnFilingStatus.setIsSuccess(Boolean.TRUE);
         hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if(logger.isInfoEnabled()){
			 logger.error("*********** ERROR in Job insertGstr2AFilingStatus "+e);
			}
		} 
         return "Success";
    }
	
	@Override
	public List<TblGstinRetutnFilingStatus> loadDataFromTblGSTinReturnFillingStatus() {
		List<TblGstinRetutnFilingStatus> tblGstinRetutnFilingStatusList = null;
		try
		{
		
		    DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
		    detachedCriteria.add(Restrictions.eq("id.returnType", "gstr2").ignoreCase());
		    detachedCriteria.add(Restrictions.eq("status", "FILED").ignoreCase());
		    tblGstinRetutnFilingStatusList = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
		}
		catch(Exception ex)
		{
			if(logger.isInfoEnabled()){
			logger.error("*********** ERROR in Job loadDataFromTblGSTinReturnFillingStatus "+ex);
			}
		}
		return tblGstinRetutnFilingStatusList;
	}
	
	//Trnsaction ID Polling starts 
		@Override
		public void updateReturnFilingStatus(Long filingId, String status) {
			TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus = null;
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("filingId", filingId));
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
			if(null !=gstinRetutnFilingStatus && !gstinRetutnFilingStatus.isEmpty()){
				tblGstinRetutnFilingStatus = gstinRetutnFilingStatus.get(0);
			} 
			if(tblGstinRetutnFilingStatus!=null){
			tblGstinRetutnFilingStatus.setStatus(status);
			//tblGstinRetutnFilingStatus.setSummaryStatus(status);
			hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
			}
		}
		
		
		
		@Override
		public void updateReturnFilingStatusForSave(Long filingId, String status) {
			try{
				logger.info("Executing updateReturnFilingStatusForSave "+CLASS_NAME);
			TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus = null;
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("filingId", filingId));
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
			if(null !=gstinRetutnFilingStatus && !gstinRetutnFilingStatus.isEmpty()){
				tblGstinRetutnFilingStatus = gstinRetutnFilingStatus.get(0);
			} 
			if(tblGstinRetutnFilingStatus!=null){
			tblGstinRetutnFilingStatus.setStatus(status);
			hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
			}}
			catch(Exception e){
				logger.info(" Exception in updateReturnFilingStatusForSave while updating status column" + e);
			}
		}
		//Trnsaction ID Polling ends 

		@Override
		public String validateSavedStatus(String gstinId, String tax,String returnType) {
			
			String  status="";
			// TODO Auto-generated method stub
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class,"tblGstinRetutnStatus");
			detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", tax));
			detachedCriteria.add(Restrictions.eq("id.returnType", returnType));
			detachedCriteria.setProjection(Projections.property("status"));
			List<String> tblFilereturnUploadList = (List<String>) hibernateDao.find(detachedCriteria);
			
			if(tblFilereturnUploadList!=null && !tblFilereturnUploadList.isEmpty()){
			
			 status = tblFilereturnUploadList.get(0);

					return status;
					
			}
			
			return status;
		}

		@Override
		public boolean insertGstr3BSubmitStatus(String gstin, String taxPeriod) {
			if(logger.isInfoEnabled()){
				logger.info("*********** entering Job insertGstr3BSubmitStatus gstin = " +gstin+" taxPeriod = "+taxPeriod);
			}
			boolean submitStatus = false;
			try{
			TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
			
			TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
			tblGstinRetutnFilingStatusPK.setGstinId(gstin);
			tblGstinRetutnFilingStatusPK.setReturnType(Constant.SUBMIT_RECORD_TYPE_GSTR3B);
			tblGstinRetutnFilingStatusPK.setTaxPeriod(taxPeriod);
			tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
			tblGstinRetutnFilingStatus.setStatus(Constant.RECORD_TYPE_GSTR3B_FILED);
			tblGstinRetutnFilingStatus.setSubmitDate(new Timestamp(System.currentTimeMillis()));
			tblGstinRetutnFilingStatus.setIsSuccess(true);
			hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
			submitStatus = true;
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" insertGstr3BSubmitStatus submitStatus " +submitStatus);
			}catch(Exception e){
				if(logger.isInfoEnabled()){
					logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"insertGstr3BSubmitStatus" +e);
				}
			}
			if(logger.isInfoEnabled()){
				logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"insertGstr3BSubmitStatus");
			}
			return submitStatus;
		}
		
		@SuppressWarnings("unchecked")
		@Override
		public boolean getGstr3BStatus(String gstin, String taxPeriod) {
			if(logger.isInfoEnabled()){
				logger.info("*********** entering Job getGstr3BStatus gstin = " +gstin+" taxPeriod = "+taxPeriod);
			}
			boolean submitStatus = false;
			try{
			DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("id.gstinId", gstin));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
			detachedCriteria.add(Restrictions.eq("id.returnType", Constant.SUBMIT_RECORD_TYPE_GSTR3B));
			//detachedCriteria.add(Restrictions.eq("isSuccess", true));
			detachedCriteria.add(Restrictions.ne("status", Constant.RECORD_TYPE_GSTR3B_FILED));
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
			if(gstinRetutnFilingStatus!=null && !gstinRetutnFilingStatus.isEmpty()){
				TblGstinRetutnFilingStatus statusObj = gstinRetutnFilingStatus.get(0);
				if(statusObj != null){
					submitStatus = true;
				}
			}
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME +Constant.LOGGER_METHOD+" getGstr3BStatus submitStatus " +submitStatus);
			}catch(Exception e){
				if(logger.isInfoEnabled()){
					logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"getGstr3BStatus" +e);
				}
			}
			if(logger.isInfoEnabled()){
				logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"getGstr3BStatus");
			}
			return submitStatus;
		}

		@SuppressWarnings("unchecked")
		@Override
		public boolean saveAllGstinReturnFilingStatus(
				List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatusList) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD+"saveAllGstinReturnFilingStatus");
			boolean status=true;
			try{
				DetachedCriteria detachedCriteria = hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			for(TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus:gstinRetutnFilingStatusList)	{
				detachedCriteria =
			            hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class, "returnFilingStatus")
			            .add(Restrictions
			            .and(Restrictions.eq("returnFilingStatus.id.gstinId", tblGstinRetutnFilingStatus.getId().getGstinId()),
			            	 Restrictions.eq("returnFilingStatus.id.taxPeriod", tblGstinRetutnFilingStatus.getId().getTaxPeriod()),
			            	 Restrictions.eq("returnFilingStatus.id.returnType", tblGstinRetutnFilingStatus.getId().getReturnType())))
			            .setProjection(Projections.countDistinct("returnFilingStatus.filingId"));
				 List<Long> returnFilingCountList=(List<Long>) hibernateDao.find(detachedCriteria);
				 if(returnFilingCountList.get(0)==0){
				hibernateDao.save(tblGstinRetutnFilingStatus);	
				}	
			}
			}catch(Exception e){
				logger.error("Error while executing saveAllGstinReturnFilingStatus"+e);
				status=false;
			}
			return status;
		}
		
		@SuppressWarnings({ "unchecked" })
		@Override
		public TblGstinRetutnFilingStatus getStatusFor2A(String gstinId,String taxPeriod, String status) {
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
			detachedCriteria.add(Restrictions.eq("id.returnType", "GSTR2A"));
			if(!status.isEmpty()){
				detachedCriteria.add(Restrictions.eq("status", status));
			}
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = null;
			try{
				gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
				if(gstinRetutnFilingStatus!=null && !gstinRetutnFilingStatus.isEmpty()){
					return gstinRetutnFilingStatus.get(0);
				}
			}
			catch(Exception ex){
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getStatusFor2A" +ex);
			}
			return null;
		}

		@SuppressWarnings({ "unchecked" })
		@Override
		public TblGstinRetutnFilingStatus checkGSTR2AEntry (String gstinId, String taxPeriod) {
			
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
			detachedCriteria.add(Restrictions.eq("id.returnType", "GSTR2A"));
			List<TblGstinRetutnFilingStatus> gstinRetutnFiling = null;
			try{
				gstinRetutnFiling = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
				if(gstinRetutnFiling!=null && !gstinRetutnFiling.isEmpty()){
					return gstinRetutnFiling.get(0);
				}
			}
			catch(Exception ex){
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getStatusFor2A" +ex);
			}
			return null;
		}
		
		@Override
	    public String insertGstr2AStatus(List<String> outputParamList) {
			
			if(logger.isInfoEnabled()){
	         logger.info("*********** entering Job insertGstr2AStatus() :  " + outputParamList.get(0));
			}
	         
	         try{
	        	 Date now = new Date(); 
	        	 Timestamp ts = new Timestamp(now.getTime());
	           TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
	         
	         TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
	         tblGstinRetutnFilingStatusPK.setGstinId(outputParamList.get(1));
	         tblGstinRetutnFilingStatusPK.setReturnType(Constant.GSTR2A);
	         tblGstinRetutnFilingStatusPK.setTaxPeriod(outputParamList.get(0));            
	         tblGstinRetutnFilingStatus.setStatus(outputParamList.get(2));
	         tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
	         tblGstinRetutnFilingStatus.setIsSuccess(Boolean.TRUE);
	         tblGstinRetutnFilingStatus.setUpdatedDate(ts);
	         hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
	        
			} catch (Exception e) {
				 logger.error("*********** ERROR in insertGstr2AStatus() : "+ e);
			} 
	         return "Success";
	    }
		
		@SuppressWarnings({ "unchecked" })
		@Override
		public TblGstinRetutnFilingStatus getStatusForReconReport(String gstinId,String taxPeriod, String status) {
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
			detachedCriteria.add(Restrictions.eq("id.returnType", status));
			
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = null;
			try{
				gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
				if(gstinRetutnFilingStatus!=null && !gstinRetutnFilingStatus.isEmpty()){
					return gstinRetutnFilingStatus.get(0);
				}
			}
			catch(Exception ex){
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getStatusFor2A" +ex);
			}
			return null;
		}

		@Override
		public void updateReturnFilingDetailsForFiling(String gstinId,
				String taxPeriod, String gstrType, String acknowledge,
				String filed) {
		if (logger.isInfoEnabled()) {
			logger.info(Constant.LOGGER_ENTERING + CLASS_NAME
					+ Constant.LOGGER_METHOD
					+ "updateReturnFilingDetailsForFiling");
		}
		try {
			 Date now = new Date(); 
        	 Timestamp ts = new Timestamp(now.getTime());
			
		TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus = new TblGstinRetutnFilingStatus();
		TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK = new TblGstinRetutnFilingStatusPK();
		tblGstinRetutnFilingStatusPK.setGstinId(gstinId);
		tblGstinRetutnFilingStatusPK.setReturnType(gstrType);
		tblGstinRetutnFilingStatusPK.setTaxPeriod(taxPeriod);
		tblGstinRetutnFilingStatus.setStatus(filed);
		tblGstinRetutnFilingStatus.setFileAckNum(acknowledge);
		tblGstinRetutnFilingStatus.setIsSuccess(true);
		tblGstinRetutnFilingStatus.setFileDate(ts);
		tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
		
			hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
		} catch (Exception e) {
			logger.info(Constant.LOGGER_ERROR + CLASS_NAME
					+ Constant.LOGGER_METHOD
					+ "updateReturnFilingDetailsForFiling " +  e);
		}
		if (logger.isInfoEnabled()) {
			logger.info(Constant.LOGGER_EXITING + CLASS_NAME
					+ Constant.LOGGER_METHOD
					+ "updateReturnFilingDetailsForFiling");
		}
				
		}
		
		@SuppressWarnings({ "unchecked" })
		@Override
		public String getStatusFor1FF(String gstinId,String taxPeriod, String api) {
			String status = null;
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
			detachedCriteria.add(Restrictions.eq("id.returnType", api));
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = null;
			try{
				gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
				if(gstinRetutnFilingStatus!=null && !gstinRetutnFilingStatus.isEmpty()){
					TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus = (TblGstinRetutnFilingStatus) gstinRetutnFilingStatus.get(0);
					status = tblGstinRetutnFilingStatus.getStatus();
				}
			}
			catch(Exception ex){
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getStatusFor1FF" +ex);
			}
			return status;
		}
		
		@SuppressWarnings({ "unchecked" })
		@Override
		public TblGstinRetutnFilingStatus getStatusFor6A(String gstinId,String taxPeriod, String status) {
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
			detachedCriteria.add(Restrictions.eq("id.returnType", "GSTR2A"));
			if(!status.isEmpty()){
				detachedCriteria.add(Restrictions.eq("status", status));
			}
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = null;
			try{
				gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
				if(gstinRetutnFilingStatus!=null && !gstinRetutnFilingStatus.isEmpty()){
					return gstinRetutnFilingStatus.get(0);
				}
			}
			catch(Exception ex){
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getStatusFor6A" +ex);
			}
			return null;
		}
		
		@SuppressWarnings({ "unchecked" })
		@Override
		public TblGstinRetutnFilingStatus checkGSTR6AEntry (String gstinId, String taxPeriod) {
			
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("id.gstinId", gstinId));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
			detachedCriteria.add(Restrictions.eq("id.returnType", "GSTR2A"));
			List<TblGstinRetutnFilingStatus> gstinRetutnFiling = null;
			try{
				gstinRetutnFiling = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
				if(gstinRetutnFiling!=null && !gstinRetutnFiling.isEmpty()){
					return gstinRetutnFiling.get(0);
				}
			}
			catch(Exception ex){
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getStatusFor6A" +ex);
			}
			return null;
		}
		
		@Override
	    public String insertGstr6AStatus(List<String> outputParamList) {
			
			if(logger.isInfoEnabled()){
	         logger.info("*********** entering Job insertGstr6AStatus() :  " + outputParamList.get(0));
			}
	         
	         try{
	        	 Date now = new Date(); 
	        	 Timestamp ts = new Timestamp(now.getTime());
	           TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus=new TblGstinRetutnFilingStatus();
	         
	         TblGstinRetutnFilingStatusPK tblGstinRetutnFilingStatusPK=new TblGstinRetutnFilingStatusPK();
	         tblGstinRetutnFilingStatusPK.setGstinId(outputParamList.get(1));
	         tblGstinRetutnFilingStatusPK.setReturnType(Constant.GSTR2A);
	         tblGstinRetutnFilingStatusPK.setTaxPeriod(outputParamList.get(0));            
	         tblGstinRetutnFilingStatus.setStatus(outputParamList.get(2));
	         tblGstinRetutnFilingStatus.setId(tblGstinRetutnFilingStatusPK);
	         tblGstinRetutnFilingStatus.setIsSuccess(Boolean.TRUE);
	         tblGstinRetutnFilingStatus.setUpdatedDate(ts);
	         hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
	        
			} catch (Exception e) {
				 logger.error("*********** ERROR in insertGstr6AStatus() : "+ e);
			} 
	         return "Success";
	    }
		
		@Override
        public boolean getReturnFilingStatusForSaveGstrToGstn(String gstin, String taxPeriod, String returnType) {
               logger.info("Inside "+"getReturnFilingStatusForSaveGstrToGstn method");
               List<String> status = new java.util.ArrayList();
               status.add(Constant.SUBMITTED);
               status.add(Constant.SAVESTATE);
               DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
               detachedCriteria.add(Restrictions.eq("id.gstinId", gstin));
               detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
               detachedCriteria.add(Restrictions.eq("id.returnType", returnType));
               detachedCriteria.add(Restrictions.in("status", status));
               List<TblGstinRetutnFilingStatus> gstinRetutnFiling = null;
               try{
                     gstinRetutnFiling = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
                     if(gstinRetutnFiling!=null && !gstinRetutnFiling.isEmpty()){
                            logger.info("getReturnFilingStatusForSaveGstrToGstn method returning True");
                            return true;
                     }
               }
               catch(Exception ex){
                     logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getReturnFilingStatusForSaveGstrToGstn" +ex);
               }
               logger.info("getReturnFilingStatusForSaveGstrToGstn method returning False");
               return false;
        }

		@Override
		public void updateReturnFilingStatus(String gstin, String taxPeriod, String returnType) {
			DetachedCriteria detachedCriteria =hibernateDao.createCriteria(TblGstinRetutnFilingStatus.class);
			detachedCriteria.add(Restrictions.eq("id.gstinId", gstin));
			detachedCriteria.add(Restrictions.eq("id.taxPeriod", taxPeriod));
			detachedCriteria.add(Restrictions.eq("id.returnType", returnType));
			
			List<TblGstinRetutnFilingStatus> gstinRetutnFilingStatus = null;
			try{
				gstinRetutnFilingStatus = (List<TblGstinRetutnFilingStatus>) hibernateDao.find(detachedCriteria);
				if(gstinRetutnFilingStatus!=null && !gstinRetutnFilingStatus.isEmpty()){
					TblGstinRetutnFilingStatus tblGstinRetutnFilingStatus = gstinRetutnFilingStatus.get(0);
					tblGstinRetutnFilingStatus.setStatus("SAVE_FAILED");
					hibernateDao.saveOrUpdate(tblGstinRetutnFilingStatus);
				}
			}
			catch(Exception ex){
				logger.error(Constant.LOGGER_ERROR + CLASS_NAME +Constant.LOGGER_METHOD +"getStatusFor2A" +ex);
			}
		}
}
