package com.asp.eutil.config;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import com.sun.jersey.core.util.Base64;

public class CryptoUtil {

	public static final String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	
	public static final String[] paddings={
			"AES/CBC/NoPadding",
			"AES/CBC/PKCS5Padding",
			"AES/ECB/NoPadding",
			"AES/ECB/PKCS5Padding",
			"DES/CBC/NoPadding",
			"DES/CBC/PKCS5Padding",
			"DES/ECB/NoPadding",
			"DES/ECB/PKCS5Padding",
			"DESede/CBC/NoPadding",
			"DESede/CBC/PKCS5Padding",
			"DESede/ECB/NoPadding",
			"DESede/ECB/PKCS5Padding",
			"RSA/ECB/PKCS1Padding",
			"RSA/ECB/OAEPWithSHA-1AndMGF1Padding",
			"RSA/ECB/OAEPWithSHA-256AndMGF1Padding"
	};
	
	public static final String AES_ALGORITHM = "AES";
	public static final int ENC_BITS = 256;
	public static final String CHARACTER_ENCODING = "UTF-8";

	private static Cipher ENCRYPT_CIPHER;
	private static Cipher DECRYPT_CIPHER;
	private static KeyGenerator KEYGEN;
	

	static {
		try {
			ENCRYPT_CIPHER = Cipher.getInstance(AES_TRANSFORMATION);
			DECRYPT_CIPHER = Cipher.getInstance(AES_TRANSFORMATION);
			KEYGEN = KeyGenerator.getInstance(AES_ALGORITHM);
			KEYGEN.init(ENC_BITS);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @param filename
	 * @return
	 * @throws Exception
	 */

	/**
	 * This method is used to encrypt the string , passed to it using a public
	 * key provided
	 * 
	 * @param planTextToEncrypt
	 *            : Text to encrypt
	 * @return :encrypted string
	 */
	
	/**
	 * @param key
	 * @return
	 */
	public static byte[] decodeBase64StringTOByte(String stringData)
			throws UnsupportedEncodingException {
		return Base64.decode(stringData.getBytes(CHARACTER_ENCODING));
	}
	
	

	/**
	 * This method is used to encode bytes[] to base64 string.
	 * 
	 * @param bytes
	 *            : Bytes to encode
	 * @return : Encoded Base64 String
	 */
	public static String encodeBase64String(byte[] bytes) {
		return new String(Base64.encode(bytes));
	}

	/**
	 * This method is used to decode the base64 encoded string to byte[]
	 * 
	 * @param stringData
	 *            : String to decode
	 * @return : decoded String
	 * @throws UnsupportedEncodingException
	 */

	/**
	 * This method is used to generate the base64 encoded secure AES 256 key *
	 * 
	 * @return : base64 encoded secure Key
	 * @throws NoSuchAlgorithmException
	 * @throws IOException
	 */
	public static String generateSecureKey() throws Exception {
		SecretKey secretKey = KEYGEN.generateKey();
		return encodeBase64String(secretKey.getEncoded());
	}

	
	
	/**
	 * This method is used to generate the base64 encoded secure AES 256 key *
	 * 
	 * @return : base64 encoded secure Key
	 * @throws NoSuchAlgorithmException
	 * @throws IOException
	 */
	public static byte[] generateSecureKeyByte() throws Exception {
		SecretKey secretKey = KEYGEN.generateKey();
		return secretKey.getEncoded();
	}

	/**
	 * This method is used to encrypt the string which is passed to it as byte[]
	 * and return base64 encoded encrypted String
	 * 
	 * @param plainText
	 *            : byte[]
	 * @param secret
	 *            : Key using for encrypt
	 * @return : base64 encoded of encrypted string.
	 * @throws Exception 
	 * 
	 */

	public static String encryptEK(byte[] plainText, byte[] secret) throws Exception {
		try {
			SecretKeySpec sk = new SecretKeySpec(secret, AES_ALGORITHM);
			ENCRYPT_CIPHER.init(Cipher.ENCRYPT_MODE, sk);
			return new String(Base64.encode(ENCRYPT_CIPHER.doFinal(plainText)));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	

	/**
	 * This method is used to decrypt base64 encoded string using an AES 256 bit
	 * key.
	 * 
	 * @param plainText
	 *            : plain text to decrypt
	 * @param secret
	 *            : key to decrypt
	 * @return : Decrypted String
	 * @throws IOException
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 */
	public static byte[] decrypt(String plainText, byte[] secret)
			throws InvalidKeyException, IOException, IllegalBlockSizeException, BadPaddingException {
		SecretKeySpec sk = new SecretKeySpec(secret, AES_ALGORITHM);
		DECRYPT_CIPHER.init(Cipher.DECRYPT_MODE, sk);
		return DECRYPT_CIPHER.doFinal(Base64.decode(plainText.getBytes()));
	}

	/**
	 * This method generates encoded and encrypted appkey
	 * @param AuthDetailsDto
	 *            dto
	 * @return
	 */


	public static byte[] encryptData(String input, byte[] pkey)
			throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		SecretKeySpec sk = new SecretKeySpec(pkey, AES_ALGORITHM);
		ENCRYPT_CIPHER.init(Cipher.ENCRYPT_MODE, sk);
		byte[] inputBytes = input.getBytes();
		return ENCRYPT_CIPHER.doFinal(inputBytes);
	}
	

	public static String hmacSHA256(String data, String key) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(key.getBytes("UTF-8"), "HmacSHA256");
		Mac mac = Mac.getInstance("HmacSHA256");
		mac.init(secretKey);
		byte[] hmacData = mac.doFinal(data.getBytes("UTF-8"));
		return new String(Base64.encode(hmacData));
	}


	
	/**
	 * @param gotrek
	 * @param sessionKey
	 * @return
	 */
	public static byte[] getapiEK(String gotrek, byte[] sessionKey) {
		byte[] apiEK = null;
		try {
			apiEK = decrypt(gotrek, sessionKey);
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return apiEK;

	}

	/**
	 * @param data
	 * @param apikey
	 * @return
	 */
	public static String getJsonData(String data, byte[] apikey) {
		String jsonData = null;
		
		try {
			jsonData = new String(CryptoUtil.decodeBase64StringTOByte(new String(CryptoUtil.decrypt(data, apikey))));

		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonData;
	}

	/**
	 * @param result
	 * @param authDetails
	 * @return
	 * @throws ParseException
	 */



	/**
	 * @param appkey
	 * @param receivedSEK
	 * @param data
	 * @param dto
	 * @return
	 */
	

	/**
	 * @param dataBytes
	 * @param authEK
	 * @return
	 */
	public static String encryptDataForSubmit(byte[] dataBytes, byte[] authEK) {
		String encryptedDataSubmit = "";
		try {
			encryptedDataSubmit = CryptoUtil
					.encodeBase64String(CryptoUtil.encryptData(CryptoUtil.encodeBase64String(dataBytes), authEK));
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
			e.printStackTrace();
		}
		return encryptedDataSubmit;
	}
}
