package com.asp.eutil.model;

public class Payload {

	
	private String key;
	private String data;

	
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Payload(String data) {
		super();
		this.data = data;
	}

	public Payload() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}