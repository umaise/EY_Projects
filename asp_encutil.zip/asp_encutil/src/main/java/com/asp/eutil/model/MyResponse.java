package com.asp.eutil.model;

public class MyResponse {

	private String data;

	public MyResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public MyResponse(String data) {
		super();
		this.data = data;
	}
	
	
	
}
