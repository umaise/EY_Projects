package com.asp.eutil.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.asp.eutil.config.CryptoUtil;
import com.asp.eutil.model.Payload;
import com.sun.jersey.core.util.Base64;

@RestController
@RequestMapping(value = "/refreshToken")
public class RefreshTokenController {

	@RequestMapping(value = "/decrypt", method = RequestMethod.POST, produces = {	MediaType.APPLICATION_JSON_UTF8_VALUE })
	public ResponseEntity<Payload> decrypt(@RequestBody  Payload  payload,  @RequestHeader HttpHeaders header) throws Exception {
		
		byte[] decodedAppKey = CryptoUtil.decodeBase64StringTOByte(payload.getKey());
		payload.setData(new String(Base64.encode(CryptoUtil.decrypt( payload.getData(), decodedAppKey))));
		payload.setKey( CryptoUtil.encodeBase64String(CryptoUtil.generateSecureKeyByte()));
		return new  ResponseEntity<Payload>(payload, HttpStatus.OK) ;
	}
	
	@RequestMapping(value = "/encrypt", method = RequestMethod.POST, produces = {	MediaType.APPLICATION_JSON_UTF8_VALUE })
	public ResponseEntity<Payload> encrypt(@RequestBody  Payload  payload, @RequestHeader HttpHeaders header ) throws Exception {
		payload.setData(CryptoUtil.encryptEK( CryptoUtil.decodeBase64StringTOByte(payload.getData()), CryptoUtil.decodeBase64StringTOByte(payload.getKey())));
		return new  ResponseEntity<Payload>(payload, HttpStatus.OK) ;
	}
}
