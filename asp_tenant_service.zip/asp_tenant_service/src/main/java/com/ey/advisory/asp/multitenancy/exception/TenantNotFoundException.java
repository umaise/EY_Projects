package com.ey.advisory.asp.multitenancy.exception;

/**
 * @author Yamini.Priya
 * Exception when the tenant is not available in the DB
 * 
 * TODO: Place the loggers
 * 
 */
public class TenantNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	public String message;


	public TenantNotFoundException(String message) {
		 this.message = message;
	}

	@Override
	public String getMessage() {

		return message;

	}
}
