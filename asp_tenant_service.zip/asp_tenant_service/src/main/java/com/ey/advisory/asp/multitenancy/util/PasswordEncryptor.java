package com.ey.advisory.asp.multitenancy.util;

import org.apache.commons.codec.binary.Base64;

/**
 * @author Nilanjan.Karmakar 
 * 			This class is not invoked but used to generate the
 *         encrypted password to be placed in [ASPDB_MASTER_AZURE].[master].[tblGroupConfig]
 *
 */
public class PasswordEncryptor {

	public static void main(String[] args) throws Exception {
		
		String pwd = args[0];
		String encryptedPwdText = new PasswordUtil().pwdEncrypt(pwd);

		System.out.println("Encrypted base64 Password :" + encryptedPwdText);

	}

}
