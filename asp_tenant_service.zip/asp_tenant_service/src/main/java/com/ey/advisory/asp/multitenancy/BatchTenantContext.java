package com.ey.advisory.asp.multitenancy;

import org.springframework.stereotype.Component;

/**
 * @author Yamini.Priya
 * Class that stores the current tenant for the batch
 * 
 * TODO: Place the loggers
 * 
 */
@Component
public class BatchTenantContext {
	
	private static final ThreadLocal<String> batchTenant = new ThreadLocal<>();	
	
	public static void setTenantId(String tenantId) {
		batchTenant.set(tenantId);
	}

	public static String getTenantId() {

		return batchTenant.get();
	}
	
	public static void clearTenant() {
		batchTenant.remove();
	}
	
}
