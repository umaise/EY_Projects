package com.ey.advisory.asp.multitenancy.aspect;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.multitenancy.BatchTenantContext;
import com.ey.advisory.asp.multitenancy.TenantContext;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;
/**
 * @author Yamini.Priya
 * Aspect used to switch between the tenants
 * 
 * TODO: Place the loggers
 * 
 */
@Aspect
@Order(1)
@Component
@EnableAspectJAutoProxy
public class TenantAspect {

	@Autowired
	private HttpServletRequest request;

	private static final String MASTER_TENANT = "MASTER";
	private static final String ETL_TENANT = "ETL";

	@Before("execution(* com.ey.advisory.asp.master.service..*.*(..)) || execution(* com.ey.advisory.asp.master.repository..*.*(..)) || execution(* com.ey.advisory.asp.etl.service..*.*(..))")
	public void injectTenant(JoinPoint jp) {
		TenantContext.setTenantId(MASTER_TENANT);
	}

	@Before("execution(* com.ey.advisory.asp.etl.service..*.*(..))")
	public void injectTenantETL(JoinPoint jp) {
		TenantContext.setTenantId(ETL_TENANT);
	}

	@Before("execution(* com.ey.advisory.asp.client.service..*.*(..))")
	public void injectTenantClient(JoinPoint jp) {
		
		if (BatchTenantContext.getTenantId()!= null) {
			TenantContext.setTenantId(BatchTenantContext.getTenantId());
			
		}else if(request != null && request.getHeader(TenantConstant.REQUEST_TENANT_HEADER) != null)
			TenantContext.setTenantId(request.getHeader(TenantConstant.REQUEST_TENANT_HEADER).toString());
	}

	@After("execution(* com.ey.advisory.asp.master.service..*.*(..)) || execution(* com.ey.advisory.asp.master.repository..*.*(..)) || execution(* com.ey.advisory.asp.etl.service..*.*(..)) || execution(* com.ey.advisory.asp.client.service..*.*(..))")
	public void removeTenant(JoinPoint jp) {
		TenantContext.clearTenant();

	}
	

	@Before("execution(* org.springframework.batch.item.support..*.*(..))")
	public void injectTenantClientForBatch(JoinPoint jp) {
		
		if (BatchTenantContext.getTenantId()!= null) {
			TenantContext.setTenantId(BatchTenantContext.getTenantId());
			
		}
	}
	@After("execution(* org.springframework.batch.item.support..*.*(..))")
	public void cleanTenantClient(JoinPoint jp) {
		
		TenantContext.clearTenant();
	}


}
