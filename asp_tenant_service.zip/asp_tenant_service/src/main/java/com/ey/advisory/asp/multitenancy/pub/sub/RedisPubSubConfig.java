package com.ey.advisory.asp.multitenancy.pub.sub;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;

import com.ey.advisory.asp.multitenancy.TenantDataSource;

/**
 * This is redis pub sub configuration class.
 * 
 * 
 * @author Prakash.Naik
 *
 */
@Configuration
public class RedisPubSubConfig {

	/**
	 * Jedis connection factory
	 */
	@Autowired(required = false)
	private JedisConnectionFactory jedisConnectionFactory;

	/**
	 * Tenant data source
	 */
	@Autowired
	private TenantDataSource tenantDataSource;

	/**
	 * Message listner i.e. RedisMessageSubscriber with tenantDataSource object.
	 * 
	 * @return
	 */
	@Bean
	MessageListenerAdapter messageListener() {
		return new MessageListenerAdapter(new RedisMessageSubscriber(tenantDataSource));
	}

	/**
	 * Redis pub sub topic with channel : pubsub:messageQueue
	 * 
	 * @return
	 */
	@Bean
	ChannelTopic topic() {
		return new ChannelTopic(RedisPubSubConstant.REDIS_PUB_SUB_CHANNEL);
	}

	/**
	 * Redis container
	 * 
	 * @return
	 */
	@Bean
	RedisMessageListenerContainer redisContainer() {
		final RedisMessageListenerContainer container = new RedisMessageListenerContainer();
		container.setConnectionFactory(jedisConnectionFactory);
		container.addMessageListener(messageListener(), topic());

		return container;
	}

	
	 @PostConstruct 
	public void dispMessage() {
		//System.out.println("-----------------RedisPubSubConfig intialization done -----------------");
	}
	 

}
