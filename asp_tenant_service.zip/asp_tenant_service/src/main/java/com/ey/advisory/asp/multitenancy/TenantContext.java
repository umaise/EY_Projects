package com.ey.advisory.asp.multitenancy;

import org.springframework.stereotype.Component;
/**
 * @author Yamini.Priya
 * Class that stores the current tenant
 * 
 * TODO: Place the loggers
 */
@Component
public class TenantContext {
	
	private static final ThreadLocal<String> context = new ThreadLocal<>();	
	
	public static void setTenantId(String tenantId) {
		context.set(tenantId);
	}

	public static String getTenantId() {

		return context.get();
	}
	
	public static void clearTenant() {
		//context.set(null);
		context.remove();
	}
	
}
