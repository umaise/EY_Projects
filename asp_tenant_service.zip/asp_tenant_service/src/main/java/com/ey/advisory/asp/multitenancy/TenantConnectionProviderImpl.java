package com.ey.advisory.asp.multitenancy;

import javax.sql.DataSource;

import org.hibernate.engine.jdbc.connections.spi.AbstractDataSourceBasedMultiTenantConnectionProviderImpl;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This class returns the data source of a tenant (groupname).
 * 
 * Data source creation is happening in TenantDataSource class.
 * 
 * @author Yamini
 */
public class TenantConnectionProviderImpl extends AbstractDataSourceBasedMultiTenantConnectionProviderImpl {

	private static final long serialVersionUID = 1L;

	/**
	 * Tenant data source object.
	 */
	@Autowired
	TenantDataSource tenantDataSource;

	/**
	 * Default data source name.
	 */
	private static final String DEFAULT_DATA_SOURCE = "MASTER";

	/**
	 * This method is to select by default master data source.
	 * 
	 */
	@Override
	protected DataSource selectAnyDataSource() {
		return tenantDataSource.getDataSource(DEFAULT_DATA_SOURCE);
	}

	/**
	 * This method is to select given tenant(group) data source.
	 */
	@Override
	protected DataSource selectDataSource(String tenantIdentifier) {

		return tenantDataSource.getDataSource(tenantIdentifier);
	}
}
