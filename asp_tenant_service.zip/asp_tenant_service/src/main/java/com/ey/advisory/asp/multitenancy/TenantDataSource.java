package com.ey.advisory.asp.multitenancy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ey.advisory.asp.master.domain.Group;
import com.ey.advisory.asp.master.domain.GroupConfig;
import com.ey.advisory.asp.master.service.GroupService;
import com.ey.advisory.asp.multitenancy.exception.TenantNotFoundException;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;

/**
 * This is a datasource creation class.
 * 
 * The responsible methods are getDataSource and addDynamicGroupDS.
 * 
 * getDataSource() method creates and returns the given data source.
 * 
 * addDynamicGroupDS() dynamically adds the group into data source.
 * 
 * @author Prakash.Naik
 *
 */
@Transactional(value = "transactionManager", readOnly = true)
@Service("tenantDataSource")
public class TenantDataSource implements InitializingBean {

	protected static final Logger LOGGER = Logger.getLogger(TenantDataSource.class);
	private static final String CLASS_NAME = TenantDataSource.class.getName();
	private static final long serialVersionUID = 1L;

	/**
	 * dataSourceMap is to hold the dynamic datasource map.
	 */
	// TODO: Think in context of threads: ConcurrentHashMap
	@Autowired
	private Map<String, DataSource> dataSourceMap = new HashMap<>();

	/**
	 * Data source information hash map.
	 */
	private Map<String, Group> dataSourceInfo;

	/**
	 * Group service object.
	 */
	@Autowired
	GroupService groupService;

	/**
	 * Basic data source object.
	 * 
	 */
	@Autowired
	BasicDataSource basicDataSource;

	/**
	 * This is after property set method. It gets all the groups and based on it
	 * creates dynamic data source. Dynamic data source will be placed into
	 * dataSourceMap map.
	 */
	@Override
	public void afterPropertiesSet() throws Exception {

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Start of " + CLASS_NAME + " afterPropertiesSet method");
		}

		dataSourceInfo = groupService.getAllGroupsByGroupCodeMap();
		if(dataSourceInfo!=null && !dataSourceInfo.isEmpty() ){
		for (Map.Entry<String, Group> entry : dataSourceInfo.entrySet()) {
			DataSource dynaDS = null;
			dynaDS = createTenantDataSource(entry.getValue());
			if (dynaDS != null)
				dataSourceMap.put(entry.getKey(), dynaDS);
			else {
				if (LOGGER.isDebugEnabled())
					LOGGER.error("Tenant DB details not available: " + entry.getKey());
			}
		}
		}else{
			throw new TenantNotFoundException("None of the tenants are found in DB; you may foresee issues while logging in");
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("End of " + CLASS_NAME + " afterPropertiesSet method");
		}
	}

	/**
	 * This method is to get the datasource for a givne tenant identifier
	 * (group).
	 * 
	 * @param tenantIdentifier
	 * @return
	 */
	public DataSource getDataSource(String tenantIdentifier) {

		if (tenantIdentifier != null && !tenantIdentifier.equals("")) {
			final DataSource dataSource = dataSourceMap.get(tenantIdentifier);
			if (dataSource != null) {
				return dataSource;
			} else {
				if (dataSourceInfo.containsKey(tenantIdentifier)) {
					DataSource dynaDS = createTenantDataSource(dataSourceInfo.get(tenantIdentifier));
					if (dynaDS != null) {
						dataSourceMap.put(tenantIdentifier, dynaDS);
						return dynaDS;
					} else {
						if (LOGGER.isDebugEnabled())
							LOGGER.error("Tenant DB details not available: " + tenantIdentifier);
						// TODO: TenantDetailsNotFoundException
						throw new TenantNotFoundException("Tenant DB details not available: " + tenantIdentifier);
					}

				} else
					throw new TenantNotFoundException("No datasource available for the tenant " + tenantIdentifier);
			}
		} else {
			throw new TenantNotFoundException("No datasource available for the tenant " + tenantIdentifier);
		}

	}

	// TODO: Yet to test
	@PostPersist
	public void addGroupDataSource(Group group) {
		dataSourceInfo.put(group.getGroupCode(), group);
	}

	// TODO: Yet to test
	@PostUpdate
	public void updateGroupDataSource(Group group) {
		dataSourceInfo.put(group.getGroupCode(), group);
		DataSource dynaDS = createTenantDataSource(group);
		dataSourceMap.put(group.getGroupCode(), dynaDS);
	}

	/**
	 * This method is to create tenant data source for given group.
	 * 
	 * @param group
	 * @return
	 */
	private BasicDataSource createTenantDataSource(Group group) {

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Start of " + CLASS_NAME + " createTenantDataSource method");
		}

		BasicDataSource customDataSource = null;

		// url, username and password must be unique per tenant so there is not
		// default value
		List<GroupConfig> groupConfigList = groupService.getGroupConfigvalues(group.getGroupCode());
		if (groupConfigList != null && groupConfigList.size() > 0) {
			customDataSource = new BasicDataSource();
			for (GroupConfig groupConfig : groupConfigList) {
				if (groupConfig.getConfigCode().equalsIgnoreCase(TenantConstant.DATASOURCE_CLASS)) {
					customDataSource.setDriverClassName(groupConfig.getConfigValue());
				} else if (groupConfig.getConfigCode().equalsIgnoreCase(TenantConstant.DB_USER_NAME)) {
					customDataSource.setUsername(groupConfig.getConfigValue());
				} else if (groupConfig.getConfigCode().equalsIgnoreCase(TenantConstant.DB_PASSWORD)) {
					// Decrypting DB password and setting it to DataSource
					/*
					 * String encryptedpwd = groupConfig.getConfigValue();
					 * String pwd=null; try { byte[] encryptedText =
					 * Base64.decodeBase64(encryptedpwd.getBytes(EncryptConstant
					 * .UTF)); pwd = new PasswordUtil().decrypt(encryptedText);
					 * } catch (UnsupportedEncodingException e) {
					 * if(LOGGER.isInfoEnabled()) LOGGER.info("Error " +
					 * CLASS_NAME + " Method : createTenantDataSource"
					 * +e.getMessage()); } catch (Exception e) {
					 * if(LOGGER.isInfoEnabled()) LOGGER.info("Error " +
					 * CLASS_NAME + " Method : createTenantDataSource"
					 * +e.getMessage()); } customDataSource.setPassword(pwd);
					 */
					customDataSource.setPassword(groupConfig.getConfigValue());
				} else if (groupConfig.getConfigCode().equalsIgnoreCase(TenantConstant.DB_URL)) {
					customDataSource.setUrl(groupConfig.getConfigValue());

				}

			}
			customDataSource.setTestOnBorrow(basicDataSource.getTestOnBorrow());
			customDataSource.setValidationQuery(basicDataSource.getValidationQuery());
			customDataSource.setMaxActive(basicDataSource.getMaxActive());
			customDataSource.setInitialSize(basicDataSource.getInitialSize());
			customDataSource.setMaxIdle(basicDataSource.getMaxIdle());
			customDataSource.setMinIdle(basicDataSource.getMinIdle());
			customDataSource.setLogAbandoned(basicDataSource.getLogAbandoned());

		}

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("End of " + CLASS_NAME + " createTenantDataSource method");
		}

		return customDataSource;
	}

	/**
	 * This method is to add the dynamic group data source.
	 * 
	 * It is called from redis pub sub group management listner.
	 * 
	 * @param groupCode
	 */
	public void addDynamicGroupDS(String groupCode) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Start of " + CLASS_NAME + " addDynamicGroupDS method");
		}
		Group group = getGroupbyGroupCode(groupCode);

		if (null != group) {
			dataSourceInfo.put(group.getGroupCode(), group);
			DataSource dynaDS = createTenantDataSource(group);
			dataSourceMap.put(group.getGroupCode(), dynaDS);
		}

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("End of " + CLASS_NAME + " addDynamicGroupDS method");
		}
	}

	/**
	 * This method is to get the group by passing group code.
	 * 
	 * @param groupCode
	 * @return
	 */
	private Group getGroupbyGroupCode(String groupCode) {

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Start of " + CLASS_NAME + " getGroupbyGroupCode method");
		}

		Group selectedGroup = null;

		List<Group> allGroups = groupService.getAllGroups();

		for (Group group : allGroups) {
			if (group.getGroupCode().equals(groupCode)) {
				selectedGroup = group;
				break;
			}
		}

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("End of " + CLASS_NAME + " getGroupbyGroupCode method");
		}

		return selectedGroup;
	}

	/**
	 * This getter method for basicDataSource.
	 * 
	 * @return
	 */
	public BasicDataSource getBasicDataSource() {
		return basicDataSource;
	}

	/**
	 * This is setter method for basicDataSource.
	 * 
	 * @param basicDataSource
	 */
	public void setBasicDataSource(BasicDataSource basicDataSource) {
		this.basicDataSource = basicDataSource;
	}

	/**
	 * This is getter method for dataSourceMap.
	 * 
	 * @return
	 */
	public Map<String, DataSource> getDataSourceMap() {
		return dataSourceMap;
	}

	/**
	 * This is setter method for dataSourceMap.
	 * 
	 * @param dataSourceMap
	 */
	public void setDataSourceMap(Map<String, DataSource> dataSourceMap) {
		this.dataSourceMap = dataSourceMap;
	}

}
