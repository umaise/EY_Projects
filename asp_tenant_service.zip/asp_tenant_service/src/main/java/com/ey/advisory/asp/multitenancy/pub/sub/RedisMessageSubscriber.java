package com.ey.advisory.asp.multitenancy.pub.sub;

import org.apache.log4j.Logger;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;

import com.ey.advisory.asp.multitenancy.TenantDataSource;

/**
 * This is redis pub sub message listner.
 * 
 * This class is used to listen from the group management screen.
 * 
 * @author Prakash.Naik
 *
 */
public class RedisMessageSubscriber implements MessageListener {

	/**
	 * Logger object.
	 */
	private static final Logger LOGGER = Logger.getLogger(RedisMessageSubscriber.class);

	/**
	 * Tenant data source object.
	 */
	private TenantDataSource tenantDataSource;

	public RedisMessageSubscriber(TenantDataSource tenantDataSource) {
		this.tenantDataSource = tenantDataSource;
	}

	@Override
	public void onMessage(final Message message, final byte[] pattern) {

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("RedisMessageSubscriber onMessage() method started");
			LOGGER.info("Message received: " + message.toString());
			LOGGER.info("Byte Array : " + new String(pattern));
		}

		String groupCode = message.toString();

		/*
		 * Add the dynamic group data source for given group code
		 */
		tenantDataSource.addDynamicGroupDS(groupCode);

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("End of RedisMessageSubscriber onMessage() method");
		}
	}

}