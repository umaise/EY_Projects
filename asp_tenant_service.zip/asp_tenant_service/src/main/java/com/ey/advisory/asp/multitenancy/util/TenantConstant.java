package com.ey.advisory.asp.multitenancy.util;
/**
 * @author Yamini.Priya
 */
public class TenantConstant {
	public static final String BATCH_TENANT_CONTEXT = "BATCH_TENANT_CONTEXT";
	public static final String REQUEST_TENANT_HEADER = "X-TENANT-ID";
	public static final String DB_NAME = "DB_NAME";
	public static final String DB_URL = "DB_URL";
	public static final String DB_PASSWORD = "DB_PASSWORD";
	public static final String DB_USER_NAME = "USER_NAME";
	public static final String DATASOURCE_CLASS = "DATASOURCE_CLASS";
}
