package com.ey.advisory.asp.multitenancy.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.ey.advisory.asp.multitenancy.TenantContext;
import com.ey.advisory.asp.multitenancy.util.TenantConstant;
/**
 * @author Yamini.Priya
 * Web Interceptor to get the tenant from the request header
 * 
 * TODO: Place the loggers
 * 
 */
public class TenantInterceptor extends HandlerInterceptorAdapter {


	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		if(request.getHeader(TenantConstant.REQUEST_TENANT_HEADER)!=null){
			TenantContext.setTenantId(request.getHeader(TenantConstant.REQUEST_TENANT_HEADER).toString());	
		}

		return true;
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		
		TenantContext.clearTenant();	
		
	}
}
