package com.ey.advisory.asp.multitenancy.util;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * @author Nilanjan.Karmakar
 *
 */
public class PasswordUtil {

	public String decrypt(byte[] message) throws Exception {

		final MessageDigest md = MessageDigest.getInstance(EncryptConstant.md5);
		final byte[] digestOfPassword = md.digest(EncryptConstant.hexString.getBytes(EncryptConstant.UTF));
		final byte[] keyBytes = Arrays.copyOf(digestOfPassword, EncryptConstant.length);
		for (int j = 0, k = 16; j < 8;) {
			keyBytes[k++] = keyBytes[j++];
		}

		final SecretKey key = new SecretKeySpec(keyBytes, EncryptConstant.DESede);
		final IvParameterSpec iv = new IvParameterSpec(new byte[EncryptConstant.size]);
		final Cipher decipher = Cipher.getInstance(EncryptConstant.padding);
		decipher.init(Cipher.DECRYPT_MODE, key, iv);

		final byte[] plainText = decipher.doFinal(message);

		return new String(plainText, EncryptConstant.UTF);

	}

	public byte[] encrypt(String message) throws Exception {
		final MessageDigest md = MessageDigest.getInstance(EncryptConstant.md5);
		final byte[] digestOfPassword = md.digest(EncryptConstant.hexString.getBytes(EncryptConstant.UTF));
		final byte[] keyBytes = Arrays.copyOf(digestOfPassword, EncryptConstant.length);
		for (int j = 0, k = 16; j < 8;) {
			keyBytes[k++] = keyBytes[j++];
		}

		final SecretKey key = new SecretKeySpec(keyBytes, EncryptConstant.DESede);
		final IvParameterSpec iv = new IvParameterSpec(new byte[EncryptConstant.size]);
		final Cipher cipher = Cipher.getInstance(EncryptConstant.padding);
		cipher.init(Cipher.ENCRYPT_MODE, key, iv);

		final byte[] plainTextBytes = message.getBytes(EncryptConstant.UTF);
		final byte[] cipherText = cipher.doFinal(plainTextBytes);
	
		return cipherText;
	}
	
	public String pwdEncrypt(String pwd) throws Exception {
	
		byte[] encryptedPwd = encrypt(pwd);
		String encryptedPwdText = new String(Base64.encodeBase64(encryptedPwd));
		return encryptedPwdText;
	}

}
