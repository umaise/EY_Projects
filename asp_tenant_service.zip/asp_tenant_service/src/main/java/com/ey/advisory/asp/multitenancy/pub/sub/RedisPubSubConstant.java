package com.ey.advisory.asp.multitenancy.pub.sub;

/**
 * This is redis pub sub constant file.
 * 
 * @author Prakash.Naik
 *
 */
public class RedisPubSubConstant {

	/**
	 * This is redis pub sub channel name which is used for group management.
	 */
	public static final String REDIS_PUB_SUB_CHANNEL = "pubsub:messageQueue";

}
