package com.ey.advisory.asp.multitenancy;

import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
/**
 * @author Yamini.Priya
 * Class that identifies the tenant
 * 
 * TODO: Place the loggers
 * 
 */
public class TenantIdentifierResolverImpl implements CurrentTenantIdentifierResolver {

	private static String DEFAULT_TENANT_ID = "MASTER";

	@Override
	public String resolveCurrentTenantIdentifier() {
	
		String currentTenantId = TenantContext.getTenantId();
		//System.out.println("Current Tenant:"+currentTenantId);
		//TODO: Check if default tenant is required
		return (currentTenantId != null) ? currentTenantId : DEFAULT_TENANT_ID; 
			
	}

	@Override
	public boolean validateExistingCurrentSessions() {
		//return false;
		String currentTenantId = TenantContext.getTenantId();
		if (currentTenantId != null) {
			return true;
		} else {
			return false;
		}
	}
}
