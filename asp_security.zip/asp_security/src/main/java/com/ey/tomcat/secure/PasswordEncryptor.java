package com.ey.tomcat.secure;

import org.apache.commons.codec.binary.Base64;

/**
 * @author Nilanjan.Karmakar 
 * 			This class is not invoked but used to generate the
 *         encrypted password to be placed in tomcat's context.xml
 *
 */
public class PasswordEncryptor {

	public static void main(String[] args) throws Exception {
		
		String pwd = "Sql@1234";
		String pwd1 ="P@99word1";
		String pwd2 ="7XOKf@ss";
		
		String encryptedPwdText = new PasswordUtil().pwdEncrypt(pwd);

		System.out.println("Encrypted base64 Password :" + encryptedPwdText);
		
		///Decript
		String decryptPwdText = new PasswordUtil().decrypt(new PasswordUtil().encrypt(pwd));
		System.out.println("Decrypted base64 Password :" + decryptPwdText);
		
		
		String encryptedPwdText1 = new PasswordUtil().pwdEncrypt(pwd1);

		System.out.println("Encrypted base64 Password :" + encryptedPwdText1);
		
		///Decript
		String decryptPwdText1 = new PasswordUtil().decrypt(new PasswordUtil().encrypt(pwd1));
		System.out.println("Decrypted base64 Password :" + decryptPwdText1);
		
		String encryptedPwdText2 = new PasswordUtil().pwdEncrypt(pwd2);

		System.out.println("Encrypted base64 Password :" + encryptedPwdText2);
		
		///Decript
		String decryptPwdText2 = new PasswordUtil().decrypt(new PasswordUtil().encrypt(pwd2));
		System.out.println("Decrypted base64 Password :" + decryptPwdText2);
	}

}
