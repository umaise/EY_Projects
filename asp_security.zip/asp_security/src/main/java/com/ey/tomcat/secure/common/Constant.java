package com.ey.tomcat.secure.common;

/**
 * @author Nilanjan.Karmakar
 *
 */
public class Constant {
	
	public static final String UTF = "utf-8";
	public static final String md5 = "md5";
	public static final String DESede = "DESede";
	public static final String padding = "DESede/CBC/PKCS5Padding";
	public static final String hexString = "HG58YZ3CR9";
	public static final Integer size = 8;
	public static final Integer length = 24;


}
