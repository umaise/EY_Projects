package com.ey.tomcat.secure;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Properties;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.naming.Context;
import javax.naming.Name;
import javax.sql.DataSource;

import org.apache.tomcat.jdbc.pool.DataSourceFactory;
import org.apache.tomcat.jdbc.pool.PoolConfiguration;
import org.apache.tomcat.jdbc.pool.XADataSource;

import com.ey.tomcat.secure.common.Constant;

import org.apache.commons.codec.binary.Base64;
import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;
import org.apache.tomcat.dbcp.dbcp2.BasicDataSourceFactory;

/*import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.dbcp.BasicDataSourceFactory;
*/

/**
 * @author Nilanjan.Karmakar
 *
 */
public class EncryptedDataSourceFactory extends DataSourceFactory {

	public DataSource createDataSource(Properties properties, Context context, boolean XA) throws Exception {
		// Here we decrypt our password.
		PoolConfiguration poolProperties = EncryptedDataSourceFactory.parsePoolProperties(properties);

		byte[] decryptedText = Base64.decodeBase64(poolProperties.getPassword().getBytes(Constant.UTF));

		String decodedtext = new PasswordUtil().decrypt(decryptedText);

		System.out.println("decodedtext"+decodedtext+"check space");
		poolProperties.setPassword(decodedtext);

		if (poolProperties.getDataSourceJNDI() != null && poolProperties.getDataSource() == null) {
			performJNDILookup(context, poolProperties);
		}
		org.apache.tomcat.jdbc.pool.DataSource dataSource = XA ? new XADataSource(poolProperties)
				: new org.apache.tomcat.jdbc.pool.DataSource(poolProperties);
		dataSource.createPool();

		return dataSource;
	}

}
