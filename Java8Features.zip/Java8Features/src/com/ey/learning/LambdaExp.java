/**
 * 
 */
package com.ey.learning;

/**
 * @author Uma.Chandranaik
 *
 */
public class LambdaExp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
