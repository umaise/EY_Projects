/*package org.asp_gstn_service;

import java.io.IOException;
import java.security.InvalidKeyException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.json.simple.parser.ParseException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.service.second.AuthGSTNAPIServiceImpl;
import com.ey.advisory.asp.gstn.service.second.IAPIService;
import com.ey.advisory.asp.gstn.util.CryptoUtil;

//import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/asp-gstn-service-context.xml" })
public class TestGSTNApisVersion2 {

	@Autowired
	@Qualifier("GSTNService")
	IAPIService gstnServiceImpl;

	@Autowired
	AuthGSTNAPIServiceImpl apiServiceImpl;

	// assigning the values
	protected void setUp() throws JsonGenerationException, JsonMappingException, IOException, ParseException {

	}

	@Test
	public void testsaveDataInAuthDetailsVO()
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, Exception {

		AuthDetailsDto dto = new AuthDetailsDto();
		dto = CryptoUtil.getAppKeyEncodedEncrypted(dto);
		dto.setUserName("EnY.TN.1");
		dto = apiServiceImpl.getOTP(dto);
		dto = apiServiceImpl.getAuthToken(dto);
		String dataJson = "{\"gstin\":\"33GSPTN0481G1ZA\",\"fp\":\"122016\",\"gt\":782969.00,\"b2b\":[{\"ctin\":\"33GSPTN0482G1Z9\",\"inv\":[{\"inum\":\"SFEB1231223\",\"idt\":\"01-09-2016\",\"val\":29248.16,\"pos\":\"27\",\"rchrg\":\"N\",\"prs\":\"Y\",\"itms\":[{\"num\":1,\"itm_det\":{\"ty\":\"G\",\"hsn_sc\":\"G1221\",\"txval\":833.33,\"irt\":3,\"iamt\":833.33}}]}]}]}";
		dto = apiServiceImpl.testDataForPut(dto.getAppKey(), dto.getSek(), dataJson, dto);
		System.out.println(dto);

	}

	@Test
	public void testSaveData() throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, Exception {

		AuthDetailsDto dto = new AuthDetailsDto();

		dto = gstnServiceImpl.saveDataInAuthDetailsVO("33GSPTN0481G1ZA", "122016", "EnY.TN.1", "", "v0.2");
		
		String dataJson = "{\"gstin\":\"33GSPTN0481G1ZA\",\"fp\":\"122016\",\"gt\":782969.00,\"b2b\":[{\"ctin\":\"33GSPTN0482G1Z9\",\"inv\":[{\"inum\":\"SFEB1231223\",\"idt\":\"01-09-2016\",\"val\":29248.16,\"pos\":\"27\",\"rchrg\":\"N\",\"prs\":\"Y\",\"itms\":[{\"num\":1,\"itm_det\":{\"ty\":\"G\",\"hsn_sc\":\"G1221\",\"txval\":833.33,\"irt\":3,\"iamt\":833.33}}]}]}]}";
		dto = apiServiceImpl.testDataForPut(dto.getAppKey(), dto.getSek(), dataJson, dto);
		System.out.println(dto);
		
		String getDataResp = gstnServiceImpl.saveData(dto, "v0.2", dataJson, "eny.tn.1", "33GSPTN0481G1ZA", "122016",
				"gstn-restapi.host", "gstn-restapi.return", "/gstr1", "RETSAVE", true);
		System.out.println("Unit test result saveData" + getDataResp);

	}

	@Test
	public void testSubmitData() {
		
		AuthDetailsDto dto = new AuthDetailsDto();
		String dataJson = "{\"gstin\":\"33GSPTN0481G1ZA\",\"fp\":\"122016\",\"gt\":782969.00,\"b2b\":[{\"ctin\":\"33GSPTN0482G1Z9\",\"inv\":[{\"inum\":\"SFEB1231223\",\"idt\":\"01-09-2016\",\"val\":29248.16,\"pos\":\"27\",\"rchrg\":\"N\",\"prs\":\"Y\",\"itms\":[{\"num\":1,\"itm_det\":{\"ty\":\"G\",\"hsn_sc\":\"G1221\",\"txval\":833.33,\"irt\":3,\"iamt\":833.33}}]}]}]}";
		dto = gstnServiceImpl.saveDataInAuthDetailsVO("33GSPTN0481G1ZA", "122016", "EnY.TN.1", "", "v0.2");
		
		String submitDataResp = gstnServiceImpl.submitData
				(dto, "v0.2", dataJson,  "EnY.TN.1", "33GSPTN0481G1ZA", "122016", "gstn-restapi.host", "gstn-restapi.return", "/gstr1", "B2B", true);
		System.out.println(submitDataResp);
	}

	@Test
	public void testGetData() throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, Exception {
		
		AuthDetailsDto dto = new AuthDetailsDto();
		dto = gstnServiceImpl.saveDataInAuthDetailsVO("33GSPTN0481G1ZA", "122016", "EnY.TN.1", "", "v0.2");
		String getDataResp = gstnServiceImpl.getData(dto, "v0.2", "EnY.TN.1", "33GSPTN0481G1ZA", "122016", "gstn-restapi.host", "gstn-restapi.return", "/gstr1", "B2B", true);
		System.out.println(getDataResp);

	}

	@Test
	public void testGetTransStatus() {
		
		AuthDetailsDto dto = new AuthDetailsDto();
		dto = gstnServiceImpl.saveDataInAuthDetailsVO("33GSPTN0481G1ZA", "122016", "EnY.TN.1", "", "v0.2");
		String transId = "";//TODO
		String retStatusDataResp = gstnServiceImpl.getTransactionStatus
				(dto, "v0.2", "EnY.TN.1", "33GSPTN0481G1ZA", "122016", "gstn-restapi.host", "gstn-restapi.return", "/gstr1", "B2B", transId,true);
		System.out.println(retStatusDataResp);
	}

	@Test
	public void testFileGSTR() {

		// GspServiceImpl gspServiceImpl = new GspServiceImpl();
		// not yet implemented for GSP

	}

}
*/