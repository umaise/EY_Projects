package com.ey.advisory.asp.gstn.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
 
@Provider
public class RestClientUtilException extends Exception /*implements
                ExceptionMapper<RestClientUtilException> */
{
    private static final long serialVersionUID = 1L;
 
    public RestClientUtilException() {
        super("Exceptio in Rest Client Util : ");
    }
 
    public RestClientUtilException(String message, Throwable throwable) {
    	super(message, throwable);
	}
 
    public RestClientUtilException(String string) {
        super(string);
    }
 /*
    @Override
    public Response toResponse(RestClientUtilException exception) 
    {
        return Response.status(404).entity(exception.getMessage())
                                    .type("text/plain").build();
    }*/
    
    
}