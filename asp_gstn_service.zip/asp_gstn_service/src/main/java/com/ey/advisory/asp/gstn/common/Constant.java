/**
 * 
 */
package com.ey.advisory.asp.gstn.common;

public class Constant {

	/*public static final String GSTN_HOST = "gstn-restAPI-host";
	public static final String OTP_REQUEST_RESOURCE_v2 = "/taxpayerapi/v0.2/authenticate";
	public static final String OTP_REQUEST_RESOURCE_v1 = "/taxpayerapi/v0.1/authenticate";
	public static final String RESOURCE_AUTH = "/taxpayerapi/v0.2/authenticate";
	public static final String RESOURCE_RETURNS = "/taxpayerapi/v0.2/returns";
	public static final String FORM_TYPE = "/gstr1";
	public static final String HOST = "http://devapi.gstsystem.co.in";
	public static final String HOST_prop = "restapi.host";
	public static final String INVOICE_B2B = "B2B";
	public static final String GSTN = "GSTN";*/
	
	public static final String ACTION= "action";
	public static final String DATA= "data";
	public static final String HMAC= "hmac";
	
	public static final String ACTION_RETSAVE = "RETSAVE";

	//GSP headers
	public static final String GSP_CLIENT_SECRET = "eygspclientsecret";
	public static final String GSP_USER = "eygspuser";
	public static final String GSP_AUTH_TOKEN = "auth-token";
	public static final String GSP_USERNAME = "username";
	public static final String GSP_IP_USER = "ip-usr";
	public static final String GSP_STATE_CD = "state-cd";
	public static final String GSP_TXN = "txn";
	public static final String GSP_CONTENT_TYPE = "content-Type";
	public static final String GSP_CLIENT_ID = "eygspclientid";

	
	//GSTN headers
	public static final String GSTN_CLIENT_ID = "clientid";
	public static final String GSTN_CLIENT_SECRET = "client-secret";
	public static final String GSTN_IP_USER = "ip-usr";
	public static final String GSTN_STATE_CD = "state-cd";
	public static final String GSTN_TXN = "txn";
	public static final String GSTN_CONTENT_TYPE = "Content-Type";
	public static final String GSTN_USERNAME = "username";
	public static final String GSTN_RET_PERIOD = "ret_period";
	public static final String GSTN_GSTIN = "gstin";
	public static final String GSTN_AUTH_TOKEN = "auth-token";
	
	public static final String HOST_GSTN = "gstn-restapi.host";
	public static final String RESOURCE_RETURNS_GSTN = "gstn-restapi.return";
	public static final String RESOURCE_AUTH_GSTN = "gstn-restapi.auth";
	public static final String RESOURCE_LEDGERS_GSTN = "gstn-restapi.ledgers";

	public static final String HOST_GSP = "gsp-restapi.host";
	public static final String RESOURCE_RETURNS_GSP = "gsp-restapi.return";
	public static final String RESOURCE_AUTH_GSP = "gsp-restapi.auth";
	public static final String RESOURCE_LEDGERS_GSP = "gsp-restapi.ledgers";

	public static final String API_VERSION_1 = "v0.1";
	public static final String API_VERSION_2 = "v0.2";
	
	//redis properties file
	public static final String REDIS_HOST = "redis.hostName";
	public static final String REDIS_PORT = "redis.port";
	
	public static final String REDIS_POOL_MAX_ACTIVE="redis.pool.maxActive";
	public static final String REDIS_POOL_MAX_IDLE="redis.pool.maxIdle";
	public static final String REDIS_POOL_MAX_WAIT="redis.pool.maxWait";
	public static final String REDIS_POOL_TEST_ON_BORROW="redis.pool.testOnBorrow";
	public static final String REDIS_TIME_OUT="redis.pool.timeout";
	public static final String REDIS_PASSWORD="redis.password";
	public static final String REDIS_CACHE = "REDIS_CACHE";
	public final static String GSP_USERDETAILS="GSP_USERDETAILS"; 
	public final static String API_KEY="api_key";
	public final static String DIGIGST_USERNAME="digist_username";  
	
    public static final String GSP_OTP= "GSP_OTP";
	public static final String APIGW_USERNAME="APIGW_USERNAME";
	public static final String APIGW_PASSWORD="APIGW_PASSWORD";
	public static final String APIGW_APIKEY="APIGW_APIKEY";
	public final static String EXPIRES_IN="expires_in";
	public final static String GSP_DIGIGST_USERNAME="digigst_username"; 
	public final static String REFRESH_TOKEN="refresh_token";
	public final static String ACCESS_TOKEN="access_token";
	public static final String GROUP_CODE= "groupCode";
	public static final String GSP_AUTHTOKEN="GSP_AUTHTOKEN";
	public static final String GSP_REFRESH_TOKEN = "GSP_REFRESH_TOKEN";
	
	public static final String STATECD = "state-cd";
	public static final String USERNAME = "username";
	public static final String TXN = "txn";
	public static final String GSTIN_HDR = "gstin";
	public static final String RET_PRD = "ret_period";
	public static final String GET_INITIAL = "?";
	public static final String PARAM_OAUTH = "auth-token";
	public static final String PARAM_GSTIN = "gstin=";
	public static final String PARAM_MONTH = "month=";
	public static final String PARAM_YEAR = "year=";
	public static final String IP_USR = "ip-usr";
	public static final String FILEDETAIL_API = "FILEDET";
	public static final String FILEDOWNLOAD_API = "FILE_DOWNLOAD";
	public static final String FILEDOWNLAOD = "/filedownload";
	public static final String PROXY_REQUIRED="proxy_Required";
	public static final Object GSP_STATE_USER_CD = "gsp_status_cd";
	public static final Object MOBILE_NUMBER = "mobile_number";
	public static final Object OTP = "otp";
	public static final String ZER0 = "0";

	public static final String GSTR3_GET = "RETSUM";
	public static final String GSTR3_STUBSRERVICE = "/stubservices"; 
	
	public static final String LEDGER_API = "BAL";
	public static final String GSTR3_GENERATE = "GENERATE";
}
