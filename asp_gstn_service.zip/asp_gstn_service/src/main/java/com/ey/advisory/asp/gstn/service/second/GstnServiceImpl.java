package com.ey.advisory.asp.gstn.service.second;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.common.Constant;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;
import com.ey.advisory.asp.gstn.util.CryptoUtil;
import com.ey.advisory.asp.gstn.util.PropertySourceUtil;
import com.ey.advisory.asp.gstn.util.RedisTemplateUtils;
import com.ey.advisory.asp.gstn.util.RestClientUtility;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

/**
 * Implementation class for GSTN API calls
 *
 */
@Component("GSTNService")
@PropertySource("classpath:GSTNConfig.properties")
public class GstnServiceImpl implements IAPIService {

	private static final Logger LOGGER = Logger.getLogger(GstnServiceImpl.class);

	@Autowired
	private PropertySourceUtil propertyUtil;

	@Autowired
	private RestClientUtility restClientUtil;

	@Autowired
	private AuthGSTNAPIServiceImpl authServiceVersion;
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#getData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public String getData(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin, String taxPrd,
			String hostName, String resourceName, String formType, String action, boolean proxyRequired)
					throws RestClientUtilException {

		LOGGER.info("GSTN api Service called... ");

		String host;
		String resource;
		String decryptedGetDataRes = "";
		String getDataRes;
		try {
		
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);
			
			String resourseUrl = host + resource + formType + "?gstin=" + gstin + "&ret_period=" + taxPrd + "&action="
					+ action;

			Client client = restClientUtil.getClient(proxyRequired);
			WebResource webResource = client.resource(resourseUrl);
			LOGGER.info("URI for api call : " + webResource.getURI());

			Builder builder = headerForGETReq(webResource, authDetails, gstin, taxPrd, userName,"");
			getDataRes = restClientUtil.executeGETRestCalls(builder);

			LOGGER.info(
					"Get data api call response for : " + gstin + "for tax period : " + taxPrd + " is : " + getDataRes);
			boolean resStatus = getResponseStatus(getDataRes);

			if (resStatus) {
				decryptedGetDataRes = CryptoUtil.getPayloadForGSTN(getDataRes, authDetails);
				LOGGER.info("Decrypted response for Get data api call for : " + gstin + "for tax period : " + taxPrd
						+ " is : " + decryptedGetDataRes);
			} else {
				throw new RestClientUtilException("API call unsuccessful : Response status = 0 ");
			}

		} catch (ParseException|RestClientUtilException e) {
			LOGGER.error("Exception in getData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in getData() in  GstnServiceImpl : " + e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in getData() in  GstnServiceImpl : " + e.getMessage(), e);
		}
		return decryptedGetDataRes;
	}

	private boolean getResponseStatus(String getDataRes) throws ParseException {

		JSONObject jsonObjectVal = null;
		jsonObjectVal = (JSONObject) new JSONParser().parse(getDataRes);
		String status = (String) jsonObjectVal.get("status_cd");
		return (("1").equals(status)) ? true : false;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#saveData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String saveData(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {

		String decryptedSaveDataRes = "";
		String retSaveResponse;
		String host;
		String resource;

		try {

			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);

			authDetailsDto = CryptoUtil.encryptDataForSave(authDetailsDto.getAppKey(), authDetailsDto.getSek(),
					dataJson, authDetailsDto);
			Client client = restClientUtil.getClient(proxyRequired);

			WebResource webResource = client.resource(host + resource + formType);
			LOGGER.info("URI for api call : " + webResource.getURI());

			// get header info
			Builder builder = headerForPUTReq(webResource, authDetailsDto, gstin, taxPrd, userName, apiVersion);
			retSaveResponse = restClientUtil.executePUTRestCalls(gstrReqPayload(authDetailsDto, action), builder);

			LOGGER.info("Save API response for " + gstin + "tax period: " + taxPrd + " is : " + retSaveResponse);
			boolean resStatus = getResponseStatus(retSaveResponse);
			if (resStatus) {
				decryptedSaveDataRes = CryptoUtil.getPayloadForGSTN(retSaveResponse, authDetailsDto);
				LOGGER.info("Decrypted response for Save data api call for : " + gstin + "for tax period : " + taxPrd
						+ " is : " + decryptedSaveDataRes);
			} else {
				throw new RestClientUtilException("API call unsuccessful : Response status_cd = 0 ");
			}

		} catch (RestClientUtilException|ParseException|JsonGenerationException|JsonMappingException e) {
			LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
		}  catch (IOException e) {
			LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
		}
		return decryptedSaveDataRes;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.gstn.service.second.IAPIService#getTransactionStatus(
	 * com.ey.advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String getTransactionStatus (AuthDetailsDto authDetails, String apiVersion, String userName, String gstin,
			String taxPrd, String hostName, String resourceName, String formType, String action, String transID,
			boolean proxyRequired) throws RestClientUtilException {

		String decryptedGetStatusRes = "";
		String host;
		String resource;
		String getDataRes;
		try {
			
			
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);

			String resourseUrl = host + resource + formType +"?action=" + action + "&gstin=" + gstin + "&ret_period=" + taxPrd + "&trans_id="
					+ transID;
			Client client = restClientUtil.getClient(proxyRequired);
			WebResource webResource = client.resource(resourseUrl);
			LOGGER.info("URI for api call : " + webResource.getURI());

			Builder builder = headerForGETReq(webResource, authDetails, gstin, taxPrd, userName, transID);
			getDataRes = restClientUtil.executeGETRestCalls(builder);

			LOGGER.info("Get status api call response for: " + gstin + "for tax period : " + taxPrd + " is:  "
					+ getDataRes);
			boolean resStatus = getResponseStatus(getDataRes);
			if (resStatus) {
				decryptedGetStatusRes = CryptoUtil.getPayloadForGSTN(getDataRes, authDetails);
				LOGGER.info("Decrypted response for Get data api call for : " + gstin + "for tax period : " + taxPrd
						+ " is: " + decryptedGetStatusRes);
			} else {
				throw new RestClientUtilException("API call unsuccessful : Response status_cd = 0 ");
			}

		} catch (ParseException e) {
			LOGGER.error("Exception in getTransactionStatus() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException(
					"Exception in getTransactionStatus() in  GstnServiceImpl : " + e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error("Exception in getTransactionStatus() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException(
					"Exception in getTransactionStatus() in  GstnServiceImpl : " + e.getMessage(), e);
		}
		return decryptedGetStatusRes;
	}

	@Override
	public AuthDetailsDto saveDataInAuthDetailsVO(String gstin, String taxPrd, String userName, String data,
			String version) throws RestClientUtilException {
		// method to be replaced by session/authentication management calls,
		// temporary
		AuthDetailsDto dto = new AuthDetailsDto();
		dto.setUserName(userName);
		LOGGER.info("Initial process of auth is done : " + dto.toString());
		try {
			dto = CryptoUtil.getAppKeyEncodedEncrypted(dto);
			dto = authServiceVersion.getOTP(dto);
			dto = authServiceVersion.getAuthToken(dto);

		} catch (IOException | ParseException|InvalidKeyException|IllegalBlockSizeException|BadPaddingException e) {
			LOGGER.error("Exception in saveDataInAuthDetailsVO() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException(
					"Exception in saveDataInAuthDetailsVO() in  GstnServiceImpl : " + e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error("Exception in saveDataInAuthDetailsVO() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException(
					"Exception in saveDataInAuthDetailsVO() in  GstnServiceImpl : " + e.getMessage(), e);
		}

		return dto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.gstn.service.second.IAPIService#submitData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String submitData(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {

		String encryptedDataSubmit;
		String retSubmitResponse;
		String retSubmitResponsedec = "";
		try {
			encryptedDataSubmit = CryptoUtil.encryptDataForSubmit(dataJson.getBytes(), authDetailsDto.getAuthEK());
			authDetailsDto.setEncryptedDataSubmit(encryptedDataSubmit);
			   String base64Data = CryptoUtil.encodeBase64String(dataJson.getBytes());
	              String hmac = CryptoUtil.hmacSHA256(base64Data, authDetailsDto.getAuthEK());

			LOGGER.info("encryptedDataSubmit  : " + encryptedDataSubmit);
			hostName = propertyUtil.getValue(hostName, apiVersion);
			resourceName = propertyUtil.getValue(resourceName, apiVersion);
			resourceName=resourceName+formType;
			

			Client client = restClientUtil.getClient(proxyRequired);
			WebResource webResource = client.resource(hostName + resourceName);
			LOGGER.info("URI for api call : " + webResource.getURI());
			// get header info
			Builder builder = headerForPOSTReq(webResource, authDetailsDto, gstin, taxPrd, userName);
			retSubmitResponse = restClientUtil.executePOSTRestCalls(gstrRETSUBMITPayload(encryptedDataSubmit, action,hmac),
					builder);
			LOGGER.info("retSubmitResponsedec  :::: - " + retSubmitResponse);
			boolean resStatus = getResponseStatus(retSubmitResponse);
			if (resStatus) {
				retSubmitResponsedec = CryptoUtil.getPayloadForGSTN(retSubmitResponse, authDetailsDto);
				LOGGER.info("Decrypted response for Submit data api call for : " + gstin + "for tax period : " + taxPrd
						+ " is: " + retSubmitResponsedec);
			} else {
              	  JSONObject jsonObjectVal;
            			jsonObjectVal = (JSONObject) new JSONParser().parse(retSubmitResponse);
            			Object status =  jsonObjectVal.get("error");
                      throw new RestClientUtilException(status.toString());
                } 

		} catch (ParseException|JsonGenerationException|JsonMappingException|InvalidKeyException|NoSuchAlgorithmException|IllegalStateException e) {
			LOGGER.error("Exception in submitData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in submitData() in  GstnServiceImpl : " + e.getMessage(), e);
		} catch (IOException e) {
			LOGGER.error("Exception in submitData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in submitData() in  GstnServiceImpl : " + e.getMessage(), e);
		}  
		return retSubmitResponsedec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#fileGSTR(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String fileGSTR(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String signedData, String st, String sid,
			String userName,String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {

		String encryptedDataSubmit;
		String host;
		String resource;
		String retSubmitResponse;
		String retSubmitResponsedec;
			encryptedDataSubmit = CryptoUtil.encryptDataForSubmit(dataJson.getBytes(), authDetailsDto.getAuthEK());
			authDetailsDto.setEncryptedDataSubmit(encryptedDataSubmit);
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("encryptedDataSubmit  : " + encryptedDataSubmit);
			}

			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);
			Client client = restClientUtil.getClient(proxyRequired);
			WebResource webResource = client.resource(host + resource+formType);
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("URI for api call : " + webResource.getURI());
			}
			Builder builder = setCustomHeaders(webResource, authDetailsDto, gstin, taxPrd, userName, apiVersion);
			//Builder builder = headerForPOSTReq(webResource, authDetailsDto,"","","");
			
			try {
				retSubmitResponse = restClientUtil.executePOSTRestCalls(gstrRETFILEPayload(encryptedDataSubmit, "RETFILE",signedData, st, sid),
						builder);
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("retSubmitResponsedec  :::: - " + retSubmitResponse);
				}
				retSubmitResponsedec = CryptoUtil.getPayloadForGSTN(retSubmitResponse, authDetailsDto);
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("Decrypted payload retSubmitResponsedec::  " + retSubmitResponsedec);
				}
				
			} catch (IOException|ParseException e1) {
				LOGGER.error("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage(), e1);
				throw new RestClientUtilException("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage(), e1);
				
			} 
		return retSubmitResponsedec;
	}


	/**
	 * @param authDetailsDto
	 * @param action
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public String gstrReqPayload(AuthDetailsDto authDetailsDto, String action)
			throws JsonGenerationException, JsonMappingException, IOException {
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put(Constant.ACTION, action);
		paramMap.put(Constant.DATA, authDetailsDto.getEncryptedData());
		paramMap.put(Constant.HMAC, authDetailsDto.getHmac());

		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		LOGGER.info("Request Payload Data: " + mapAsJson);
		return mapAsJson;
	}

	/**
	 * @param encryptedDataSubmit
	 * @param action
	 * @param hmac 
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public String gstrRETSUBMITPayload(String encryptedDataSubmit, String action, String hmac)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", action);
		paramMap.put("data", encryptedDataSubmit);
		paramMap.put(Constant.HMAC, hmac);
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	/**
	 * @param dto
	 * @param encryptedSummData
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public String fileGSTR1RequestBody(AuthDetailsDto dto, String encryptedSummData)
			throws JsonGenerationException, JsonMappingException, IOException {

		String sign = "MIIFzgYJKoZIhvcNAQcCoIIFvzCCBbsCAQExDzANBglghkgBZQMEAgEFADALBgkqhkiG9w0BBwGg\nggOXMIIDkzCCAnugAwIBAgIEfC1KTDANBgkqhkiG9w0BAQsFADB6MQswCQYDVQQGEwJJTjESMBAG\nA1UECBMJS2FybmF0YWthMRIwEAYDVQQHEwlCYW5nYWxvcmUxETAPBgNVBAoTCFNpZ25iYXNlMR4w\nHAYDVQQLExVTaWduYmFzZSBUZWNobm9sb2dpZXMxEDAOBgNVBAMTB0FiaGluYXYwHhcNMTYwMjIw\nMTY1NDM4WhcNMTcwMjE5MTY1NDM4WjB6MQswCQYDVQQGEwJJTjESMBAGA1UECBMJS2FybmF0YWth\nMRIwEAYDVQQHEwlCYW5nYWxvcmUxETAPBgNVBAoTCFNpZ25iYXNlMR4wHAYDVQQLExVTaWduYmFz\nZSBUZWNobm9sb2dpZXMxEDAOBgNVBAMTB0FiaGluYXYwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw\nggEKAoIBAQCqv0C8h7VnjCkLC8h0T+r5KnJ8sXu0aJ0IUTYBBCxTIzB/DUHiRQ71RHf98Bb0SFOD\n9Tyndo/YRwcduEmhgn3YgxuM9EL+p0uI2ovNQRYQAIy20TIZA83AAmWC1M7YXfmbX+sJmIo0Jg1A\nmPT7ta0Gh5S5UdvAtzRc1laPsP7qtSKlfNtbdDNwFSFkix9E9Tta19SgguFbwmFfe3402GqbNK8l\ns0BYuCihFC6/f9jwpfgxxf8LCKIPn7hvROG+9SYXJrH01kRj39tc8hU9TVNpMFQxAmuwmLgcQFj5\naU2OI7jZ2LX5v4ZAMicZZDnvLH5HSIbHFhkR6T5m12IY/7PjAgMBAAGjITAfMB0GA1UdDgQWBBS1\n5Wv9oKaQMJATHSuk2b9BEINUJTANBgkqhkiG9w0BAQsFAAOCAQEAclljnj5Xk5C/oThlYLZuhi0V\n8jTHdAWjFaTU5yeKPLcQS9SNPYyGsFeeau1uIMkVQSmztWb4PDnDPx0a2AICUscBScIUskRuYlgX\nNpzhbJHiil592fH0qQ+da9skwFmednVJfaSt1FNR+anGj+Z9jsCFsTnep7qtwPUC1pknANlpR/4D\nCcZpdDrwvfZsN+pNA0n8KPcyxY3RabH5hJEaCi88YMzlNPnQzRi0qj7EpuXtZyNdGxx9mxcUKNCr\nJEhb2OvJIIcoIMKxeG2sf9vHsrgHniVtPHXmyVftkeZzBbVm10HMzvxfUPdo4qSdAqXICJKF/7Q/\n8rYkSZ9fjiuvKTGCAfswggH3AgEBMIGCMHoxCzAJBgNVBAYTAklOMRIwEAYDVQQIEwlLYXJuYXRh\na2ExEjAQBgNVBAcTCUJhbmdhbG9yZTERMA8GA1UEChMIU2lnbmJhc2UxHjAcBgNVBAsTFVNpZ25i\nYXNlIFRlY2hub2xvZ2llczEQMA4GA1UEAxMHQWJoaW5hdgIEfC1KTDANBglghkgBZQMEAgEFAKBL\nMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwLwYJKoZIhvcNAQkEMSIEIISfN+Xi6A+nmTfF4JQw\nn/E2+hp/q08S6NAaocqZCAtHMA0GCSqGSIb3DQEBAQUABIIBAKZdhL9EaBO/xg77kfpNNZLesc/D\nvvwe3C+UQ7S4+tfaR+TajdvBhG9xI9Ftog4M+ZrHF+d1e1ATQE5mhcXsdBJVoRVhffZb3RLEgMgi\nxoXIYiu2r6VWz0VChTiBQJIWasntOTKPF0H79Ka2mSKgwPPNyb+6cC7ppgPX57XRVpx4/sZN++3F\nbMqEma10lNGUB5kNlyKHcP14RVpOeihQyNZVHt6cUY8LzXOrARXJc24CiipaqTvEGhPZVhZXXWJE\nNU7rYRBBdUC0E9Xzej8qvkTxFFVh9WH5PmbHlv9EHTy4kBwj6hIFLqKYIxbeOUeKTmZMYNbhVY7w\nYii28SRWIvU=";
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", "RETFILE");
		paramMap.put("data", encryptedSummData);
		paramMap.put("sign", sign);
		paramMap.put("st", "DSC");
		paramMap.put("sid", "gfgftrtr");

		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	/**
	 * @param webResource
	 * @param authDetails
	 * @param gstn
	 * @param taxPrd
	 * @param userName
	 * @return
	 */
	private Builder headerForGETReq(WebResource webResource, AuthDetailsDto authDetails, String gstin, String taxPrd,
			String userName, String transID) {
		Builder builder = webResource.header("clientid", "l7xxb80f74e32f3846cea73b7acdb62491dc")
				.header("client-secret", "2870611482b74016b15b25a6e229a740").header("ip-usr", "12.8.9l.80")
				.header("state-cd", authDetails.getStateCode()).header("txn", transID)
				.header("Content-Type", "application/json;charset=UTF-8").header("username", userName)
				.header("ret_period", taxPrd).header("gstin", gstin).header("auth-token", authDetails.getAuthToken());
		return builder;
	}

	/**
	 * @param webResource
	 * @param authDetailsDto
	 * @param gstin
	 * @param taxPrd
	 * @param userName
	 * @return
	 */
	private Builder headerForPOSTReq(WebResource webResource, AuthDetailsDto authDetailsDto, String gstin,
			String taxPrd, String userName) {
		Builder builder = webResource.header("clientid", "l7xxb80f74e32f3846cea73b7acdb62491dc")
				.header("client-secret", "2870611482b74016b15b25a6e229a740").header("ip-usr", "12.8.9l.80")
				.header("state-cd", authDetailsDto.getStateCode()).header("txn", "returns")
				.header("Content-Type", "application/json;charset=UTF-8").header("username", userName)
				.header("ret_period", taxPrd).header("gstin", gstin)
				.header("auth-token", authDetailsDto.getAuthToken());
		return builder;
	}

	/**
	 * @param webResource
	 * @param authDetailsDto
	 * @param gstin
	 * @param taxPrd
	 * @param userName
	 * @return
	 */
	private Builder headerForPUTReq(WebResource webResource, AuthDetailsDto authDetailsDto, String gstin, String taxPrd,
			String userName, String version) {
		
		Builder builder = webResource.header("clientid", "l7xxb80f74e32f3846cea73b7acdb62491dc")
				.header("client-secret", "2870611482b74016b15b25a6e229a740").header("ip-usr", "12.8.9l.80")
				.header("state-cd", authDetailsDto.getStateCode()).header("txn", "returns")
				.header("Content-Type", "application/json;charset=UTF-8").header("username", userName)
				.header("ret_period", taxPrd).header("gstin", gstin)
				.header("auth-token", authDetailsDto.getAuthToken());
		return builder;

	}
	
	private Builder headerForPUTReqForGSP(WebResource webResource, AuthDetailsDto authDetailsDto, String gstin, String taxPrd,
			String userName, String version) {
		
		Builder builder = webResource.header("ip-usr", "12.8.9l.80")
				.header("state-cd", authDetailsDto.getStateCode()).header("txn", "returns")
				.header("Content-Type", "application/json;charset=UTF-8").header("username", userName)
				.header("ret_period", taxPrd).header("gstin", gstin)
				.header("auth-token", authDetailsDto.getAuthToken())
				.header("access_token", authDetailsDto.getAccessToken())
				.header("api_key", authDetailsDto.getGspApiKey())
				.header("digigst_username", authDetailsDto.getDigigstUserName());
		return builder;

	}
	
	public AuthDetailsDto getRedisData(String gstinId) {
        RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<>();
        RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
        redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.afterPropertiesSet();
        AuthDetailsDto dto=new AuthDetailsDto();
        try{
        	Map<Object, Object> entries = redisIntegertemplate.opsForHash().entries(gstinId);
        	for(Object key : entries.keySet()){
        		if(entries.get("status").equals("Y") && entries.get(key)!=null)
        		{
        			dto.setSek(entries.get("sk").toString());
        			dto.setErrorcode(entries.get("errorCode").toString());
        			dto.setUserName(entries.get("userName").toString());
        			dto.setAuthToken(entries.get("auth-token").toString());

        		}

        	}
        }
        catch(Exception ex)
        {
        	LOGGER.error(ex);
        }
		return dto;
	}

	@Override
	public String saveDataViaGSP(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {
		String decryptedSaveDataRes = "";
		String retSaveResponse;
		String host;
		String resource;

		try {

			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);
			authDetailsDto = CryptoUtil.encryptDataForSave(authDetailsDto.getAppKey(), authDetailsDto.getSek(),
					dataJson, authDetailsDto);
			Client client = restClientUtil.getClient(proxyRequired);
			if (null != host && !host.isEmpty() && null != resource && !resource.isEmpty() && null != formType
					&& !formType.isEmpty()) {
				WebResource webResource = client.resource(host + resource + formType);
				LOGGER.info("URI for api call : " + webResource.getURI());

				// get header info
				Builder builder = headerForPUTReqForGSP(webResource, authDetailsDto, gstin, taxPrd, userName,
						apiVersion);
				retSaveResponse = restClientUtil.executePUTRestCalls(gstrReqPayload(authDetailsDto, action), builder);

				LOGGER.info("Save API response for " + gstin + "tax period: " + taxPrd + " is : " + retSaveResponse);
				boolean resStatus = getResponseStatus(retSaveResponse);
				if (resStatus) {
					decryptedSaveDataRes = CryptoUtil.getPayloadForGSTN(retSaveResponse, authDetailsDto);
					LOGGER.info("Decrypted response for Save data api call for : " + gstin + "for tax period : "
							+ taxPrd + " is : " + decryptedSaveDataRes);
				} else {
					throw new RestClientUtilException("API call unsuccessful : Response status_cd = 0 ");
				}

			} else {
				LOGGER.error("host or resource or  formType is/are empty ");
			}
		} catch (RestClientUtilException|ParseException|JsonGenerationException|JsonMappingException e) {
			LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
		}  catch (IOException e) {
			LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
		}
		return decryptedSaveDataRes;

	}

	@Override
	public String getSummaryData(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin,
			String taxPrd, String hostName, String resourceName, String formType, String action, boolean proxyRequired)
					throws RestClientUtilException {
		
		LOGGER.info("GSTN api Service called... ");
		String host;
		String resource;
		String decryptedGetDataRes = "";
		String getDataRes;
		
		try {
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);
			
			String resourseUrl = host + resource + formType + "?gstin=" + gstin + "&ret_period=" + taxPrd + "&action="
					+ action;

			Client client = restClientUtil.getClient(proxyRequired);
			WebResource webResource = client.resource(resourseUrl);
			LOGGER.info("URI for api call : " + webResource.getURI());

			Builder builder = headerForGETReq(webResource, authDetails, gstin, taxPrd, userName,"");
			getDataRes = restClientUtil.executeGETRestCalls(builder);

			LOGGER.info(
					"Get data api call response for : " + gstin + "for tax period : " + taxPrd + " is : " + getDataRes);
			boolean resStatus = getResponseStatus(getDataRes);

			if (resStatus) {
				decryptedGetDataRes = CryptoUtil.getPayloadForGSTN(getDataRes, authDetails);
				LOGGER.info("Decrypted response for Get summary data api call for : " + gstin + "for tax period : " + taxPrd
						+ " is : " + decryptedGetDataRes);
			} else {
				throw new RestClientUtilException("API call unsuccessful : Response status = 0 ");
			}

		} catch (ParseException|RestClientUtilException e) {
			LOGGER.error("Exception in getSummaryData() in  GstnServiceImpl : " + e.getMessage() ,e);
			throw new RestClientUtilException("Exception in getSummaryData() in  GstnServiceImpl : " + e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error("Exception in getSummaryData() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in getSummaryData() in  GstnServiceImpl : " + e.getMessage(), e);
		}
		return decryptedGetDataRes;
	}
	/**
	 * @param encryptedDataSubmit
	 * @param action
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private String gstrRETFILEPayload(String encryptedDataSubmit, String action, String signedData, String st, String pan)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", "RETFILE");
		paramMap.put("data", encryptedDataSubmit);
		paramMap.put("sign", signedData);
		paramMap.put("st", st);
		paramMap.put("sid", pan);

		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}
	private Builder setCustomHeaders(WebResource webResource, AuthDetailsDto authDetailsDto, String gstin, String taxPrd,
			String userName, String version) {
		
		
		Builder builder = null;
		try {
			InetAddress IP = InetAddress.getLocalHost();
			LOGGER.info("user IP" + IP.getHostAddress());
			builder = webResource.
			    	header("digigst_username", authDetailsDto.getDigigstUserName()).
					header("access_token", authDetailsDto.getAccessToken()).
			    	header("api_key", new String(authDetailsDto.getApiKey())).
			    	header("api_secret", authDetailsDto.getApiSecret()).
			    // required for gstn
					header(Constant.IP_USR, "198.134.56.85").
					header("Content-Type", "application/json;charset=UTF-8").
					header(Constant.PARAM_OAUTH, authDetailsDto.getAuthToken()).
					header(Constant.STATECD, authDetailsDto.getStateCode()).
					header(Constant.USERNAME, authDetailsDto.getUserName()).
					header(Constant.TXN, propertyUtil.getValue("rest.txn")).
			    	header(Constant.GSTIN_HDR, gstin).
			    	header(Constant.RET_PRD, taxPrd);
			
			
			
			
		} catch (RestClientUtilException | UnknownHostException e) {
			LOGGER.error(e.getMessage(), e);
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
		    	
		    	
				return builder;

	}

	@Override
	public byte[] getDataFileDownload(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin,
			String taxPrd, String hostName, String resourceName, String formType, String action, boolean proxyRequired)
					throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getOTP(String mobNo, String appKey, String userName,
			String URI,String apiKey, String apiSecret) throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}

	

	@Override
	public String getEncryptedApiKeySecret(String appKey, String apikey, String apiSecret) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String verifyOTP(String userName, String apiKey, String apiSecret,
			String otp, String signedData, String URI)
			throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String submitGSTR3Data(AuthDetailsDto authDetailsDto,
			String apiVersion, String dataJson, String userName, String gstin,
			String taxPrd, String hostName, String resourceName,
			String formType, String action, boolean proxyRequired)
			throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getGSTR3Data(AuthDetailsDto authDetails, String apiVersion,
			String userName, String gstin, String taxPrd, String hostName,
			String resourceName, String formTypeorToken, String action,
			String getFinal, boolean proxyRequired)
			throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public boolean isCAGateWayByPassEnabled() {
		return false;
	}
}