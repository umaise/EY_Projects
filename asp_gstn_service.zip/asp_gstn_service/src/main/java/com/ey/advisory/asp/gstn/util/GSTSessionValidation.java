package com.ey.advisory.asp.gstn.util;

public class GSTSessionValidation {/*

	 // Method to see if the user has the valid session by reading from the redis
	
	 //if not call the web service to create the session and make an entry in the redis as well as the table
	
	// TODO later : get for now get session and auth-token from APIs directly
	
	AuthDetailsDto dto = new AuthDetailsDto();
	RestClientAPIUtil restUtil= new RestClientAPIUtil();
	
	dto = AESEncryptionAPIUtil.getAppKeyEncodedEncrypted(dto);
	String gstin = "33GSPTN0481G1ZA";
	String taxPrd = "022017";
	
	try {
		dto = restUtil.getOTP(dto);
		dto = restUtil.getAuthToken(dto);
		dto = Gstr1APIService.getTestData(dto);
		
	} catch (Exception e){
		e.printStackTrace();
	}
*/
	}
