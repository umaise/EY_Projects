package com.ey.advisory.asp.gstn.service.second;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;
import com.ey.advisory.asp.gstn.util.CryptoUtil;
import com.ey.advisory.asp.gstn.util.RestClientUtility;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

@Configuration
@PropertySource(value = "classpath:GSTNConfig.properties", ignoreResourceNotFound = true)
public class AuthGSTNAPIServiceImpl {

	private static final Logger LOGGER = Logger.getLogger(AuthGSTNAPIServiceImpl.class);

	@Autowired
	private RestClientUtility restClientUtil;

	/**
	 * @param dto
	 * @return
	 * @throws RestClientUtilException
	 */
	public AuthDetailsDto getOTP(AuthDetailsDto dto) throws RestClientUtilException {

		try {
			dto.setAction("OTPREQUEST");
			
			byte[] decodedAppKey = CryptoUtil.decodeBase64StringTOByte(dto.getAppKey());

			String otp = "682696";// change OTP runtime, received in mail

			String encryptedOtp = CryptoUtil.encryptEK(otp.getBytes(), decodedAppKey);

			dto.setEncryptedOTP(encryptedOtp);

		} catch (UnsupportedEncodingException e) {
			LOGGER.error("Exception in AuthGSTNAPIServiceImpl : getOTP() " + e.getMessage());
			throw new RestClientUtilException("Exception in AuthGSTNAPIServiceImpl : getOTP() " + e.getMessage());

		} catch (Exception e) {
			LOGGER.error("Exception in AuthGSTNAPIServiceImpl : getOTP() " + e.getMessage());
			throw new RestClientUtilException("Exception in AuthGSTNAPIServiceImpl : getOTP() " + e.getMessage());
		}
		return dto;
	}

	/**
	 * @param dto
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public String reqParamsOTPReq(AuthDetailsDto dto)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", dto.getAction());
		paramMap.put("username", dto.getUserName());
		paramMap.put("app_key", dto.getEncryptedAppKey());
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	/**
	 * @param dto
	 * @return
	 * @throws InvalidKeyException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws Exception
	 */
	public AuthDetailsDto getAuthToken(AuthDetailsDto dto)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, Exception {

		dto.setAction("AUTHTOKEN");
		Client client = restClientUtil.getClient(true);

		WebResource webResource = client.resource("http://devapi.gstsystem.co.in" + "/taxpayerapi/v0.2/authenticate");
		Builder builder = headerForPUTReq(webResource, dto);
		String authTokenResp = restClientUtil.executePUTRestCalls(authTokenReqBody(dto), builder);

		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject;
		jsonObject = (JSONObject) jsonParser.parse(authTokenResp);
		String authToken = (String) jsonObject.get("auth_token");
		String sek = (String) jsonObject.get("sek");
		dto.setSek(sek);
		dto.setSessionKey(sek.getBytes());
		dto.setAuthToken(authToken);

		byte[] authEK = CryptoUtil.decrypt(sek, CryptoUtil.decodeBase64StringTOByte(dto.getAppKey()));
		dto.setAuthEK(authEK);

		return dto;
	}

	/**
	 * @param dto
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public String authTokenReqBody(AuthDetailsDto dto)
			throws JsonGenerationException, JsonMappingException, IOException {
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", "AUTHTOKEN");
		paramMap.put("username", dto.getUserName());
		paramMap.put("app_key", dto.getEncryptedAppKey());
		paramMap.put("otp", dto.getEncryptedOTP());
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	/**
	 * @param appkey
	 * @param receivedSEK
	 * @param data
	 * @param dto
	 * @return
	 */
	public AuthDetailsDto testDataForPut(String appkey, String receivedSEK, String data, AuthDetailsDto dto) throws RestClientUtilException {

		AuthDetailsDto authDetails = dto;
		byte[] authEK = null;
		String hmac = null;
		String encryptedData = null;

		try {
			authEK = CryptoUtil.decrypt(receivedSEK, CryptoUtil.decodeBase64StringTOByte(appkey));
			dto.setAuthEK(authEK);
			String base64Data = CryptoUtil.encodeBase64String(data.getBytes());
			hmac = CryptoUtil.hmacSHA256(base64Data, authEK);
			authDetails.setHmac(hmac);
			encryptedData = CryptoUtil
						.encodeBase64String(CryptoUtil.encryptData(CryptoUtil.encodeBase64String(data.getBytes()), authEK));
		} catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException | IOException e2) {
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Exception in AuthGSTNAPIServiceImpl : testDataForPut() " + e2.getMessage());
			}
			throw new RestClientUtilException("Exception in AuthGSTNAPIServiceImpl : testDataForPut() " + e2.getMessage());
		} catch ( NoSuchAlgorithmException | IllegalStateException e1) {
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Exception in AuthGSTNAPIServiceImpl : testDataForPut() " + e1.getMessage());
			}
			throw new RestClientUtilException("Exception in AuthGSTNAPIServiceImpl : testDataForPut() " + e1.getMessage());
		}
		authDetails.setEncryptedData(encryptedData);
		return authDetails;
	}

	/**
	 * @param webResource
	 * @param authDetailsDto
	 * @return
	 */
	private Builder headerForPUTReq(WebResource webResource, AuthDetailsDto authDetailsDto) {

		Builder builder = webResource.header("clientid", "l7xxb80f74e32f3846cea73b7acdb62491dc")
				.header("client-secret", "2870611482b74016b15b25a6e229a740").header("ip-usr", "12.8.9l.80")
				.header("state-cd", authDetailsDto.getStateCode()).header("txn", "returns")
				.header("Content-Type", "application/json;charset=UTF-8");

		return builder;
	}

}
