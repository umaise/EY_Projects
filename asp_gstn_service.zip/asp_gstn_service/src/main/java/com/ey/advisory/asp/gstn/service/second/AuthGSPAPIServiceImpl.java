package com.ey.advisory.asp.gstn.service.second;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;
import com.ey.advisory.asp.gstn.util.CryptoUtilMock;
import com.ey.advisory.asp.gstn.util.RestClientUtility;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

@Configuration
@PropertySource(value = "classpath:GSTNConfig.properties", ignoreResourceNotFound = true)
public class AuthGSPAPIServiceImpl {

	@Autowired
	private RestClientUtility restClientUtil;

	private static final Logger LOGGER = Logger.getLogger(AuthGSPAPIServiceImpl.class);
	/**
	 * @return
	 * @throws RestClientUtilException 
	 */
	public  AuthDetailsDto produceSampleData() throws RestClientUtilException {
		
		String encryptedAppkey = null;
		String encryptedOtp = null;
		String appkey = null;
		AuthDetailsDto dto = null;
		try {
			appkey = CryptoUtilMock.generateSecureKey();
			encryptedAppkey = CryptoUtilMock.generateEncAppkey(CryptoUtilMock
					.decodeBase64StringTOByte(appkey));
			String otp = "102030";
			encryptedOtp = CryptoUtilMock.encryptEK(otp.getBytes(),
					CryptoUtilMock.decodeBase64StringTOByte(appkey));
			dto = new AuthDetailsDto();
			dto.setAppKey(appkey);
			dto.setEncryptedAppKey(encryptedAppkey);
			dto.setEncryptedOTP(encryptedOtp);
		} catch (Exception e) {
			throw new RestClientUtilException("Exception in AuthGSPAPIServiceImpl.produceSampleData()" + e.getMessage());
		}
		return dto;
	}
	
	/**
	 * @param dto
	 * @return
	 */
	public AuthDetailsDto getOTP(AuthDetailsDto dto) throws RestClientUtilException {
		
		
		try {
			dto = produceSampleData();
			dto.setAction("OTPREQUEST");
			dto.setUserName("EnY.TN.1");

			Client client = restClientUtil.getClient(false);

			WebResource webResource = client
					.resource("http://INBANVMDCDTFS03.mea.ey.net:8181/gsp" + "/gspTaxPayerApi/authenticate");
			if(LOGGER.isInfoEnabled()){
			 LOGGER.info("URI for api call : " + webResource.getURI());
			}
			// get header info
			Builder builder = headerForOTPReq(webResource, dto);
			String OTPresponse = restClientUtil.executePOSTRestCalls(reqParamsOTPReq(dto), builder);
			
			byte[] decodedAppKey = CryptoUtilMock.decodeBase64StringTOByte(dto.getAppKey());
			String otp = "102030";// change OTP runtime, received in mail

			String encryptedOtp = CryptoUtilMock.encryptEK(otp.getBytes(), decodedAppKey);
			
			dto.setEncryptedOTP(encryptedOtp);

		} catch (UnsupportedEncodingException|JsonGenerationException|JsonMappingException e) {
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Exception in AuthGSPAPIServiceImpl.getOTP() " + e.getMessage());
			}
			throw new RestClientUtilException("Exception in AuthGSPAPIServiceImpl.getOTP() " + e.getMessage());
		
		} catch (IOException e) {
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Exception in AuthGSPAPIServiceImpl.getOTP() " + e.getMessage());
			}
			throw new RestClientUtilException("Exception in AuthGSPAPIServiceImpl.getOTP() " + e.getMessage());
		
		} catch (Exception e) {
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Exception in AuthGSPAPIServiceImpl.getOTP() " + e.getMessage());
			}
			throw new RestClientUtilException("Exception in AuthGSPAPIServiceImpl.getOTP() " + e.getMessage());
		
		}  
		return dto;
	}

	/**
	 * @param dto
	 * @return
	 *//*
	public AuthDetailsDto getAppKey(AuthDetailsDto dto) {
		try {
			String appkey = CryptoUtilMock.generateSecureKey();

			String encryptedAppkey = CryptoUtilMock.generateEncAppkey(CryptoUtilMock.decodeBase64StringTOByte(appkey));
			dto.setAppKey(appkey);
			dto.setEncryptedAppKey(encryptedAppkey);
			System.out.println("appkey :" + appkey);
			System.out.println("encry : " + encryptedAppkey);
			LOGGER.info("appkey :" + appkey);
			LOGGER.info("encry : " + encryptedAppkey);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in AuthGSPAPIServiceImpl.getAppKey() " + e.getMessage());
			throw new RestClientUtilException("Exception in AuthGSPAPIServiceImpl.getAppKey() " + e.getMessage());
		}

		return dto;
	}*/

	/**
	 * @param dto
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public String reqParamsOTPReq(AuthDetailsDto dto)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", "OTPREQUEST");
		paramMap.put("username", "EYGSPTESTUSER");
		paramMap.put("appkey", dto.getEncryptedAppKey());
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;

	}

	/**
	 * @param dto
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @throws ParseException
	 * @throws RestClientUtilException 
	 */
	public AuthDetailsDto getAuthToken(AuthDetailsDto dto)
			throws JsonGenerationException, JsonMappingException, IOException, ParseException, RestClientUtilException {

		Client client = restClientUtil.getClient(false);

		WebResource webResource = client.resource("http://INBANVMDCDTFS03.mea.ey.net:8181/gsp" + "/gspTaxPayerApi/authenticate");
		Builder builder = headerForAuthReq(webResource, dto);
		
		String authTokenResp = restClientUtil.executePOSTRestCalls(authTokenReqBody(dto), builder);
		
		 JSONParser jsonParser = new JSONParser(); JSONObject jsonObject;
		 jsonObject = (JSONObject) jsonParser.parse(authTokenResp); String
		 authToken = (String) jsonObject.get("auth_token"); 
		 String sek =  (String) jsonObject.get("sek");
		
		dto.setSek(sek);
		dto.setSessionKey(sek.getBytes());
		dto.setAuthToken(authToken);

		return dto;
	}

	/**
	 * @param dto
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public String authTokenReqBody(AuthDetailsDto dto)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", "AUTHTOKEN");
		paramMap.put("username", "EYGSPTESTUSER");
		paramMap.put("appkey",dto.getEncryptedAppKey());// TODO
		paramMap.put("otp",dto.getEncryptedOTP());
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	/**
	 * @param decryptedAppkey
	 * @param receivedSEK
	 * @param data
	 * @return
	 */
	public AuthDetailsDto testDataForPut(String decryptedAppkey,
			String receivedSEK, String data, AuthDetailsDto authDetails) {
		byte[] authEK = null;
		String hmac = null;
		String encryptedData = null;
		try {
			if (data.isEmpty()) {
				data = "[{\"gstin\":\"06AAMFS3061K1Z7\",\"fp\":\"052017\",\"gt\":0,\"b2cl\":[{\"state_cd\":\"19\",\"inv\":[{\"cname\":\"Basana Ceramics\",\"inum\":\"UD01600007\",\"idt\":\"2016-04-24\",\"val\":271360.00,\"pos\":\"We\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":28320.00,\"irt\":0.18,\"iamt\":4320.00,\"camt\":0.00,\"samt\":0.00},{\"num\":2,\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":243040.00,\"irt\":0.12,\"iamt\":26040.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"19\",\"inv\":[{\"cname\":\"Manuj Electricals\",\"inum\":\"BP01800013\",\"idt\":\"2017-04-19\",\"val\":295000.00,\"pos\":\"We\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"20\",\"inv\":[{\"cname\":\"Manuj Electricals\",\"inum\":\"UD01600002\",\"idt\":\"2016-04-12\",\"val\":277360.00,\"pos\":\"Jh\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":146320.00,\"irt\":0.18,\"iamt\":22320.00,\"camt\":0.00,\"samt\":0.00},{\"num\":2,\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":131040.00,\"irt\":0.12,\"iamt\":14040.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"28\",\"inv\":[{\"cname\":\"Vijaynagar Realtors\",\"inum\":\"BP01800012\",\"idt\":\"2017-04-23\",\"val\":295000.00,\"pos\":\"An\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"28\",\"inv\":[{\"cname\":\"Vijaynagar Realtors\",\"inum\":\"UD01600001\",\"idt\":\"2017-04-18\",\"val\":403560.00,\"pos\":\"An\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":141600.00,\"irt\":0.18,\"iamt\":21600.00,\"camt\":0.00,\"samt\":0.00},{\"num\":2,\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":261960.00,\"irt\":0.18,\"iamt\":39960.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"7 \",\"inv\":[{\"cname\":\"Everex Enterprises\",\"inum\":\"BP01800020\",\"idt\":\"2017-04-24\",\"val\":295000.00,\"pos\":\"De\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]}],\"b2cla\":[{\"state_cd\":\"19\",\"inv\":[{\"cname\":\"Manuj Electricals\",\"num\":\"UD01500362\",\"dt\":\"2016-03-11\",\"val\":368160.00,\"pos\":\"We\",\"onum\":\"UD01500362\",\"odt\":\"2016-03-11\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":169920.00,\"irt\":0.18,\"iamt\":25920.00,\"camt\":0.00,\"samt\":0.00},{\"num\":2,\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":198240.00,\"irt\":0.12,\"iamt\":21240.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"9 \",\"inv\":[{\"cname\":\"Mahalaxmi Enterprise\",\"num\":\"BP01900008\",\"dt\":\"2017-04-30\",\"val\":295000.00,\"pos\":\"Ut\",\"onum\":\"BP01400008\",\"odt\":\"2017-03-23\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]},{\"state_cd\":\"9 \",\"inv\":[{\"cname\":\"Mahalaxmi Enterprise\",\"num\":\"BP01900009\",\"dt\":\"2017-04-30\",\"val\":295000.00,\"pos\":\"Ut\",\"onum\":\"BP01900009\",\"odt\":\"2017-03-24\",\"itms\":[{\"num\":1,\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"irt\":0.18,\"iamt\":45000.00,\"camt\":0.00,\"samt\":0.00}]}]}],\"b2cs\":[{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":18000.00,\"srt\":0.09,\"samt\":18000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":59000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":4500.00,\"srt\":0.09,\"samt\":4500.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"irt\":0.18,\"iamt\":36000.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":147500.00,\"irt\":0.18,\"iamt\":22500.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"irt\":0.18,\"iamt\":36000.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":236000.00,\"irt\":0.18,\"iamt\":36000.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"19\",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":241900.00,\"irt\":0.18,\"iamt\":36900.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":206500.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":15750.00,\"srt\":0.09,\"samt\":15750.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":236000.00,\"irt\":0.18,\"iamt\":36000.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"29\",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":206500.00,\"irt\":0.18,\"iamt\":31500.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"29\",\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":238360.00,\"irt\":0.18,\"iamt\":36360.00,\"camt\":0.00,\"samt\":0.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":280000.00,\"iamt\":0.00,\"crt\":0.06,\"camt\":15000.00,\"srt\":0.06,\"samt\":15000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":280000.00,\"iamt\":0.00,\"crt\":0.06,\"camt\":15000.00,\"srt\":0.06,\"samt\":15000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":280000.00,\"iamt\":0.00,\"crt\":0.06,\"camt\":15000.00,\"srt\":0.06,\"samt\":15000.00},{\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":104720.00,\"iamt\":0.00,\"crt\":0.06,\"camt\":5610.00,\"srt\":0.06,\"samt\":5610.00},{\"state_cd\":\"7 \",\"ty\":\"G\",\"hsn_sc\":\"23021010\",\"txval\":236320.00,\"irt\":0.12,\"iamt\":25320.00,\"camt\":0.00,\"samt\":0.00}],\"b2csa\":[{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"6 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":295000.00,\"iamt\":0.00,\"crt\":0.09,\"camt\":22500.00,\"srt\":0.09,\"samt\":22500.00},{\"osupst_cd\":\"6 \",\"omon\":\"32017\",\"oty\":\"G\",\"ohsn_sc\":\"82011000\",\"state_cd\":\"9 \",\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":147500.00,\"irt\":0.18,\"iamt\":22500.00,\"camt\":0.00,\"samt\":0.00}],\"exp\":[{\"ex_tp\":\"With payment of GST\",\"inv\":[{\"num\":\"EX01600058\",\"dt\":\"2016-04-17\",\"val\":596624.00,\"sbnum\":\"31117500455\",\"sbdt\":\"2016-04-20\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":913320.00,\"irt\":0.18,\"iamt\":139320.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":596624.00,\"irt\":0.12,\"iamt\":63924.00,\"samt\":0.00}]}]},{\"ex_tp\":\"With payment of GST\",\"inv\":[{\"num\":\"EX01600058\",\"dt\":\"2016-04-17\",\"val\":913320.00,\"sbnum\":\"31117500455\",\"sbdt\":\"2016-04-20\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":913320.00,\"irt\":0.18,\"iamt\":139320.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":596624.00,\"irt\":0.12,\"iamt\":63924.00,\"samt\":0.00}]}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01600057\",\"dt\":\"2017-04-11\",\"val\":762300.00,\"sbnum\":\"12145363293\",\"sbdt\":\"2016-04-14\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":1350000.00,\"iamt\":0.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":762300.00,\"iamt\":0.00,\"samt\":0.00}]}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01600057\",\"dt\":\"2017-04-11\",\"val\":1350000.00,\"sbnum\":\"12145363293\",\"sbdt\":\"2016-04-14\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":1350000.00,\"iamt\":0.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":762300.00,\"iamt\":0.00,\"samt\":0.00}]}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01600067\",\"dt\":\"2016-04-23\",\"val\":532700.00,\"sbnum\":\"20519150788\",\"sbdt\":\"2016-04-24\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":774000.00,\"iamt\":0.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":532700.00,\"iamt\":0.00,\"samt\":0.00}]}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01600067\",\"dt\":\"2016-04-23\",\"val\":774000.00,\"sbnum\":\"20519150788\",\"sbdt\":\"2016-04-24\",\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"txval\":774000.00,\"iamt\":0.00,\"samt\":0.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"txval\":532700.00,\"iamt\":0.00,\"samt\":0.00}]}]}],\"expa\":[{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01500166\",\"dt\":\"2016-01-14\",\"val\":460000.00,\"sbnum\":\"13445363293\",\"sbdt\":\"2016-01-18\"}]},{\"ex_tp\":\"Without payment of GST\",\"inv\":[{\"num\":\"EX01500166\",\"dt\":\"2016-01-14\",\"val\":1550000.00,\"sbnum\":\"13445363293\",\"sbdt\":\"2016-01-18\"}]}],\"ata\":[{\"octin\":\"06AECPG5123Q0Z1\",\"ocname\":\"Lakshi Sales Enterprise\",\"odoc_num\":\"AD01500133\",\"odoc_dt\":\"2017-03-07\",\"ctin\":\"06AECPG5123Q0Z1\",\"cname\":\"Lakshi Sales Enterprise\",\"supst_cd\":\"6 \",\"doc_num\":\"AD01600133\",\"doc_dt\":\"2017-03-07\",\"adamt\":177000.00,\"itms\":[{\"ty\":\"G\",\"hsn_sc\":\"82011000\",\"crt\":0.09,\"camt\":2700.00,\"srt\":0.09,\"samt\":2700.00},{\"ty\":\"G\",\"hsn_sc\":\"23069021\",\"crt\":0.09,\"camt\":10800.00,\"srt\":0.09,\"samt\":10800.00}]}],\"txpd\":[{\"num\":\"BP01600002\",\"doc_num\":\"7912562323\",\"doc_dt\":\"2017-03-19\",\"crt\":0.09,\"camt\":5000.00,\"srt\":0.09,\"samt\":5000.00},{\"num\":\"BP01600002\",\"doc_num\":\"7912562323\",\"doc_dt\":\"2017-03-19\",\"crt\":0.09,\"camt\":8000.00,\"srt\":0.09,\"samt\":8000.00}],\"ecom_invocies\":[{\"ecom_ty\":\"INTER\",\"eInvoices\":[{\"txprd\":\"052017\",\"grsval\":360760.00,\"ctin\":\"29AQUPM3403D2Z4\"}]},{\"ecom_ty\":\"INTER\",\"eInvoices\":[{\"txprd\":\"052017\",\"mid\":\"HR231982\",\"grsval\":1760560.00,\"ctin\":\"NA\"}]},{\"ecom_ty\":\"INTRA\",\"eInvoices\":[{\"txprd\":\"052017\",\"mid\":\"HR231982\",\"grsval\":146320.00,\"ctin\":\"NA\"}]},{\"ecom_ty\":\"INTER\",\"eInvoices\":[{\"flag\":\"M\",\"txprd\":\"052017\",\"mid\":\"HR231982\",\"grsval\":1760560.00,\"ctin\":\"NA\"}]}]},{\"gstin\":\"06AAMFS3061K1Z7\",\"fp\":\"112016\",\"gt\":0}]";
			}
			authEK = CryptoUtilMock.decrypt(receivedSEK,
					CryptoUtilMock.decodeBase64StringTOByte(decryptedAppkey));
			
			encryptedData = CryptoUtilMock.encodeBase64String(CryptoUtilMock
					.encryptData(data, authEK));
			hmac = CryptoUtilMock.hmacSHA256(encryptedData,
					CryptoUtilMock.encodeBase64String(authEK));
			authDetails.setEncryptedData(encryptedData);
			authDetails.setHmac(hmac);
			authDetails.setSessionKey(authEK);
			authDetails.setAuthEK(authEK);
		} catch (Exception e) {
			if(LOGGER.isInfoEnabled()){
				LOGGER.info("Exception in AuthGSPAPIServiceImpl.testDataForPut() " + e.getMessage());
			}
		}
	
		return authDetails;

	}

	private Builder headerForOTPReq(WebResource webResource, AuthDetailsDto authDetailsDto) {
		
		Builder builder = webResource.
				 header("eygspclientid", "aspAdmin")
				.header("eygspclientsecret", "Password1")
				.header("state-cd", "11")
				.header("txn", "returns").
				header("eygspuser", "EYASPAdmin@ey.com")
				.header("Content-Type", "application/json;charset=UTF-8")
				.header("username", "EYGSPTESTUSER").
				header("appkey", authDetailsDto.getAppKey());
		
		return builder;
	}
	
	private Builder headerForAuthReq(WebResource webResource, AuthDetailsDto authDetailsDto) {
		
		Builder builder = webResource.
				 header("eygspclientid", "aspAdmin")
				.header("eygspclientsecret", "Password1")
				.header("state-cd", "11")
				.header("txn", "returns").
				header("eygspuser", "EYASPAdmin@ey.com")
				.header("Content-Type", "application/json;charset=UTF-8");
		
		return builder;
	}
}
