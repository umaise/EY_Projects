package com.ey.advisory.asp.gstn.service.second;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.web.client.RestClientException;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.common.Constant;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;
import com.ey.advisory.asp.gstn.util.CryptoUtil;
import com.ey.advisory.asp.gstn.util.PropertySourceUtil;
import com.ey.advisory.asp.gstn.util.RestClientUtility;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

@Configuration
@ComponentScan(basePackages = { "com.ey.*" })

@PropertySources({  @PropertySource("classpath:GSPAuthentication.properties"),
	@PropertySource("classpath:ASPGSPIntegeration.properties") })
public class AuthGSPServiceImpl {

    private static final Logger LOGGER = Logger.getLogger(AuthGSPServiceImpl.class);

    @Autowired
    private RestClientUtility restClientUtil;
   
    @Autowired
    Environment env;
    
    
    public static final String CHARACTER_ENCODING = "UTF-8";
	
    /**
     * @param otpReceived,mobileno
     * @return
     * @throws RestClientException
     */    
    @SuppressWarnings("unchecked")
	public String validateOTP(JSONObject jsonObject) throws RestClientUtilException{
    	String response = "";
        if (LOGGER.isDebugEnabled())
            LOGGER.info("Starting validateOTP() method ");
    	try{
            Client client = restClientUtil.getClient(true);
            String endPoint =env.getProperty("endpoint.asp.context.validateOTP");
            //String resource=env.getProperty("gsp-restapi.auth_v0.2");
            if(endPoint!=null && !endPoint.isEmpty()){
                WebResource webResource = client.resource(endPoint);
                LOGGER.debug("CI GATEWAY API URL for validateOTP " + webResource);
                Builder builder = webResource.header("Content-Type", "application/json");//getHeadersOTPGSP(webResource, dto);
                LOGGER.debug("Header used for validateOTP() method " + builder);
                String requestBody = jsonObject.toJSONString();//reqParamsOTPReqGsp(dto);
                LOGGER.debug("body used for validateOTP() method " + requestBody);
                response = restClientUtil.executePOSTRestCalls(requestBody, builder);
                JSONObject jsonResponse = (JSONObject) new JSONParser().parse(response);
                LOGGER.debug("validateOTP() json Response" + response);
                LOGGER.info("validateOTP response : " + jsonResponse);
                response = (String) jsonResponse.get(Constant.GSP_STATE_USER_CD);
                LOGGER.info("validateOTP() response status : " + response);
            }
        } catch (Exception e) {
            LOGGER.error("Exception in AuthGSPServiceImpl : getOTP() " + e.getMessage(),e);
            throw new RestClientUtilException("Exception in AuthGSPServiceImpl : getOTP() " + e);
        }
    	return response;
    }
    

	/**
     * @param JSONObject
     * @return
     * @throws RestClientException
     */
    public String generateOTP(JSONObject object) throws RestClientUtilException{
    	String OTPresponse = Constant.ZER0;
        if (LOGGER.isDebugEnabled())
            LOGGER.info("Starting generateOTP() method ");
    	try{
            Client client = restClientUtil.getClient(true);
            String endPoint =env.getProperty("endpoint.asp.context.generateOTP");
            //String resource=env.getProperty("gsp-restapi.auth_v0.2");
            if(endPoint!=null && !endPoint.isEmpty() && object != null){
                WebResource webResource = client.resource(endPoint);
                LOGGER.debug("CI GATEWAY API URL for generateOTP() " + webResource);
                Builder builder = webResource.header("Content-Type", "application/json");//getHeadersOTPGSP(webResource, dto);
                LOGGER.debug("Header used for generateOTP() method" + builder);
                String requestBody = object.toJSONString();//reqParamsOTPReqGsp(dto);
                LOGGER.debug("body used for generateOTP() method " + requestBody);
                OTPresponse = restClientUtil.executePOSTRestCalls(requestBody, builder);
                JSONObject response = (JSONObject) new JSONParser().parse(OTPresponse);
                LOGGER.debug("generateOTP() json Response" + response);
                LOGGER.info("OTP request output : " + response);
                OTPresponse = (String) response.get(Constant.GSP_STATE_USER_CD); 
                LOGGER.info("generateOTP() response code : " + response);
            }
    	} catch (Exception e) {
            LOGGER.error("Exception in AuthGSPServiceImpl : getnerateOTP() " + e.getMessage(),e);
            throw new RestClientUtilException("Exception in AuthGSPServiceImpl : generateOTP() " + e , e);
        }
    	return OTPresponse;
    }
  
	/**
     * @param dto
     * @return
     * @throws RestClientException
     */
    public boolean getOTP(AuthDetailsDto dto) throws RestClientUtilException {
        boolean OTPStatus=Boolean.FALSE;
        if (LOGGER.isDebugEnabled())
        LOGGER.info("Starting getOTP() method ");
        try {
            dto.setAction("OTPREQUEST");
            Client client = restClientUtil.getClient(true);
            
            String endPoint =env.getProperty("endpoint.gsp.context.root");
            String resource=env.getProperty("gsp-restapi.auth_v0.2");
            if(endPoint!=null && !endPoint.isEmpty() && resource!=null && !resource.isEmpty()){
            WebResource webResource = client
                    .resource(endPoint + resource);
            LOGGER.debug("URI in the getOTP() " + webResource);
            Builder builder = getHeadersOTPGSP(webResource, dto);
            LOGGER.debug("Header used in the getOTP() " + builder);
            String Body = reqParamsOTPReqGsp(dto);
            LOGGER.debug("body used in the getOTP() " + Body);
            String OTPresponse = restClientUtil.executePOSTRestCalls(Body, builder);
            LOGGER.debug("Resonse in getOTP() " + OTPresponse);
            LOGGER.info("OTP request output : " + OTPresponse);
            OTPStatus = getResponseStatus(OTPresponse);
            }

        } catch (UnsupportedEncodingException|JsonGenerationException|JsonMappingException e) {
            LOGGER.error("Exception in AuthGSPServiceImpl : getOTP() " + e);
            throw new RestClientUtilException("Exception in AuthGSPServiceImpl : getOTP() " + e);

        } catch (IOException e) {
            LOGGER.error("Exception in AuthGSPServiceImpl : getOTP() " + e.getMessage());
            throw new RestClientUtilException("Exception in AuthGSPServiceImpl : getOTP() " + e);

        } catch (Exception e) {
            LOGGER.error("Exception in AuthGSPServiceImpl : getOTP() " + e.getMessage());
            throw new RestClientUtilException("Exception in AuthGSPServiceImpl : getOTP() " + e);
        }
        return OTPStatus;
    }

    private boolean getResponseStatus(String getDataRes) throws ParseException {
        JSONObject jsonObjectVal;
        String status="";
        if(getDataRes != null && !getDataRes.isEmpty()){
        	 jsonObjectVal = (JSONObject) new JSONParser().parse(getDataRes);
        	 status= ((String) jsonObjectVal.get("status_cd"));
        }
       
        return ("1").equals(status) ? true : false;

    }

    /**
     * @param dto
     * @return
     * @throws JsonGenerationException
     * @throws JsonMappingException
     * @throws IOException
     */
    public String reqParamsOTPReq(AuthDetailsDto dto)
            throws JsonGenerationException, JsonMappingException, IOException {

        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("action", dto.getAction());
        paramMap.put("username", dto.getUserName().toLowerCase());
        paramMap.put("app_key", dto.getEncryptedAppKey());
        String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
        return mapAsJson;
    }
    
    
    /**
     * @param dto
     * @return
     * @throws JsonGenerationException
     * @throws JsonMappingException
     * @throws IOException
     */
    public String reqParamsOTPReqGsp(AuthDetailsDto dto)
            throws JsonGenerationException, JsonMappingException, IOException {

        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("action", dto.getAction());
        paramMap.put("username", dto.getUserName().toLowerCase());
        paramMap.put("app_key", dto.getEncryptedAppKey());
        String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
        return mapAsJson;
        
       
    }
    /**
     * @param dto
     * @return
     * @throws InvalidKeyException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     * @throws Exception
     */
    public String getAuthTokenNumber(AuthDetailsDto dto, String otpRecieved, String gstin)
            throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, Exception {
    	if(LOGGER.isDebugEnabled())
    	 LOGGER.info("Starting getAuthTokenNumber() method ");
    	 String authTokenResp="";
        byte[] decodedAppKey = CryptoUtil.decodeBase64StringTOByte(dto.getAppKey());
        String encryptedOtp = CryptoUtil.encryptEK(otpRecieved.getBytes(), decodedAppKey);
        dto.setEncryptedOTP(encryptedOtp);
        dto.setAction("AUTHTOKEN");
        Client client = restClientUtil.getClient(true);
        String endPoint =env.getProperty("endpoint.gsp.context.root");
        String resource=env.getProperty("gsp-restapi.auth_v0.2");
        if(endPoint!=null && !endPoint.isEmpty() && resource != null && !resource.isEmpty() ){
        	WebResource webResource = client.resource(endPoint + resource);
            LOGGER.debug("URI in the getAuthTokenNumber()" + webResource);
            Builder builder = getHeadersOTPGSP(webResource, dto);
            LOGGER.debug("Header used in the getAuthTokenNumber() " + builder);
            String authTokenReqBodyGsp=authTokenReqBodyGsp(dto);
            LOGGER.debug("body used in the getAuthTokenNumber() " +authTokenReqBodyGsp );
            authTokenResp = restClientUtil.executePOSTRestCalls(authTokenReqBodyGsp, builder);
            LOGGER.debug("Response in the getAuthTokenNumber()" + authTokenResp);
            updateAuthToken(dto, authTokenResp);
            if(dto.getSek() !=null && dto.getAppKey() != null && dto.getExpiry() != null && gstin!=null && !gstin.isEmpty() ){
     		byte[] authEK = getAuthEK(dto.getSek(), dto.getAppKey());
     		dto.setAuthEK(authEK);
     		// make node JS refresh token call
     		refreshAuthToken(dto, gstin,dto.getStateCode());
            }
     		
        }
        
        return authTokenResp;
    }

    private byte[] getAuthEK(String sek, String appKey) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, IOException {
    	
		byte[] authEK = CryptoUtil.decrypt(sek, CryptoUtil.decodeBase64StringTOByte(appKey));
		
		return authEK;
	}
	/**
	 * @param dto
	 * @param authTokenResp
	 * @throws ParseException
	 * @throws InvalidKeyException
	 * @throws IOException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws UnsupportedEncodingException
	 */
	private void updateAuthToken(AuthDetailsDto dto, String authTokenResp) throws ParseException, InvalidKeyException,
			IOException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject;
		if(authTokenResp != null && !authTokenResp.isEmpty()){
		jsonObject = (JSONObject) jsonParser.parse(authTokenResp);
		String authToken = (String)  (jsonObject.get("auth_token")!=null?jsonObject.get("auth_token"):"");
		String sek = (String)  (jsonObject.get("sek")!=null?jsonObject.get("sek"):"");
		Long expTime = (Long) jsonObject.get("expiry");
		if(authToken!=null &&  !authToken.isEmpty() && sek!=null &&  !sek.isEmpty() && expTime!=null ){
		dto.setExpiry(String.valueOf(expTime));
		dto.setSek(sek);
		dto.setSessionKey(sek.getBytes());
		dto.setAuthToken(authToken);
		}
	}
	}
	private void refreshAuthToken(AuthDetailsDto dto, String gstin,String stateCode)
	
			throws JsonGenerationException, JsonMappingException, IOException,
			InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException, ParseException {
		if (LOGGER.isDebugEnabled())
			 LOGGER.info("Starting refreshAuthToken() method ");
			try {
				// to be generated in node JS now

				//Fix for proxy issue in Auth token generation: Bug#1213
				Client client = Client.create();//restClientUtil.getClient(false);
				dto.setAction("REFRESHTOKEN");
			
				String endPoint =env.getProperty("restapi.gspRefToken-host");
		        String resource=env.getProperty("gsp-restapi.refreshToken");
				WebResource webResource = client
						.resource(endPoint + resource);
				LOGGER.debug("URI in the RefreshToken" + webResource);
				Builder builder = getHeadersOTPGSP(webResource, dto);
				LOGGER.debug("Header used in the refreshAuthToken() " + builder);
		        
				String body = refreshTokenReqBody(dto, gstin, stateCode);
				LOGGER.debug("body used in the refreshAuthToken() " + body);
				String refreshTokenResp = restClientUtil.executePOSTRestCalls(body,
						builder);
				LOGGER.debug("Status in the redis refreshAuthToken() " + refreshTokenResp);
				if(LOGGER.isInfoEnabled())
				LOGGER.info("Refresh Token called");
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("Auth Token refreshed..");
				}
			} catch (Exception e) {
				LOGGER.error("Error in Refresh Token API call ...");
			}

}

	/**
	 * @param dto
	 * @return
	 * @throws Exception 
	 */
	public String refreshTokenReqBody(AuthDetailsDto dto, String gstin, String stateCode)
			throws Exception {
		
		Map<String, String> paramMap = new HashMap<>();
		
		byte[] appkey = CryptoUtil.generateSecureKeyByte();
        String appkeyStr =  CryptoUtil.encodeBase64String(appkey);

		paramMap.put("action", dto.getAction());
		paramMap.put("username", dto.getUserName().toLowerCase());
		paramMap.put("auth_token", dto.getAuthToken());
		paramMap.put("gstin", gstin);
		paramMap.put("state-cd", stateCode);
		paramMap.put("expiry",dto.getExpiry());
		paramMap.put("app_key", appkeyStr);
		paramMap.put("sk", new String(Base64.encode(dto.getAuthEK())));
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}
    /**
     * @param dto
     * @return
     * @throws JsonGenerationException
     * @throws JsonMappingException
     * @throws IOException
     */
    public String authTokenReqBody(AuthDetailsDto dto)
            throws JsonGenerationException, JsonMappingException, IOException {
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("action", "AUTHTOKEN");
        paramMap.put("username", dto.getUserName().toLowerCase());
        paramMap.put("app_key", dto.getEncryptedAppKey());
        paramMap.put("otp", dto.getEncryptedOTP());
        String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
        return mapAsJson;
    }
    
    /**
     * @param dto
     * @return
     * @throws JsonGenerationException
     * @throws JsonMappingException
     * @throws IOException
     */
    public String authTokenReqBodyGsp(AuthDetailsDto dto)
            throws JsonGenerationException, JsonMappingException, IOException {
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("action", "AUTHTOKEN");
        paramMap.put("username", dto.getUserName().toLowerCase());
        paramMap.put("app_key", dto.getEncryptedAppKey());
        paramMap.put("otp", dto.getEncryptedOTP());
        String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
        return mapAsJson;
    }

    /**
     * @param dto
     * @return
     * @throws JsonGenerationException
     * @throws JsonMappingException
     * @throws IOException
     */
    public String refreshTokenReqBody(AuthDetailsDto dto, String gstin)
            throws JsonGenerationException, JsonMappingException, IOException {
        
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("action", dto.getAction());
        paramMap.put("username", dto.getUserName().toLowerCase());
        paramMap.put("app_key", dto.getEncryptedAppKey());
        paramMap.put("auth_token", dto.getAuthToken());
        paramMap.put("gstin", gstin);
        paramMap.put("expiry",dto.getExpiry() );
        paramMap.put("sek",dto.getSek());
        
        String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
        return mapAsJson;
    }

    /**
     * @param appkey
     * @param receivedSEK
     * @param data
     * @param dto
     * @return
     */
    public AuthDetailsDto testDataForPut(String appkey, String receivedSEK, String data, AuthDetailsDto dto)
            throws RestClientUtilException {

        AuthDetailsDto authDetails = dto;
        byte[] authEK = null;
        String hmac = null;
        String encryptedData = null;

        try {
            authEK = CryptoUtil.decrypt(receivedSEK, CryptoUtil.decodeBase64StringTOByte(appkey));
            dto.setAuthEK(authEK);
            String base64Data = CryptoUtil.encodeBase64String(data.getBytes());
            hmac = CryptoUtil.hmacSHA256(base64Data, authEK);
            authDetails.setHmac(hmac);
            encryptedData = CryptoUtil
                    .encodeBase64String(CryptoUtil.encryptData(CryptoUtil.encodeBase64String(data.getBytes()), authEK));
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException | IOException e2) {
            if(LOGGER.isInfoEnabled()){
            LOGGER.info("Exception in AuthGSPServiceImpl : testDataForPut() " + e2.getMessage());
            }
            throw new RestClientUtilException("Exception in AuthGSPServiceImpl : testDataForPut() " + e2.getMessage());
        } catch (NoSuchAlgorithmException | IllegalStateException e1) {
        	if(LOGGER.isInfoEnabled()){
            LOGGER.info("Exception in AuthGSPServiceImpl : testDataForPut() " + e1.getMessage());
        	}
            throw new RestClientUtilException("Exception in AuthGSPServiceImpl : testDataForPut() " + e1.getMessage());
        }
        authDetails.setEncryptedData(encryptedData);
        return authDetails;
    }

   /* *//**
     * @param webResource
     * @param authDetailsDto
     * @return
     *//*
    private Builder headerForPOSTReq(WebResource webResource, AuthDetailsDto authDetailsDto) {

        Builder builder = webResource.header("clientid", env.getProperty("gsp-clientid"))
                .header("client-secret", env.getProperty("gsp-client-secret"))
                .header("ip-usr", env.getProperty("ip.usr"))
                .header("state-cd", authDetailsDto.getStateCode())
                .header("txn", env.getProperty("gsp-txn"))
                .header("Content-Type", env.getProperty("Content-Type"));
        return builder;
    }
*/
private Builder headerForOTPRequire(WebResource webResource, AuthDetailsDto authDetailsDto) {
		
		Builder builder = webResource.
				 header("eygspclientid", env.getProperty("gsp-eygspclientid"))
				.header("eygspclientsecret", env.getProperty("gsp-eygspclientsecret"))
				.header("state-cd",authDetailsDto.getStateCode())
				.header("txn", env.getProperty("gsp-txn"))
				.header("eygspuser", env.getProperty("gsp-user"))
				.header("Content-Type", env.getProperty("Content-Type"))
				.header("digigst_username", authDetailsDto.getDigigstUserName())
				.header("appkey", authDetailsDto.getAppKey());
		
		return builder;
	}
    
    
    /**
     * @param webResource
     * @param authDetailsDto
     * @return
     */
    private Builder getHeadersOTPGSP(WebResource webResource, AuthDetailsDto authDetailsDto) {

    	Builder builder = null;
    	
    	if (authDetailsDto != null && authDetailsDto.getAction() != null && !authDetailsDto.getAction().isEmpty()) {
			if ("GSP_OTP".equals(authDetailsDto.getAction())) {
				builder = webResource.header("digigst_username", authDetailsDto.getDigigstUserName()).header("accept", "*/*")
						.header("Content-Type", "application/x-www-form-urlencoded")
						.header("api_secret", authDetailsDto.getApiSecret())
						.header("api_key", new String(authDetailsDto.getApiKey()));

				return builder;
			} else if ("GSP_AUTHTOKEN".equals(authDetailsDto.getAction())) {
				builder = webResource.header("digigst_username", authDetailsDto.getDigigstUserName())
						.header("api_key", new String(authDetailsDto.getApiKey()))
						.header("Content-Type", "application/x-www-form-urlencoded").header("accept", "*/*")
						.header("api_secret", authDetailsDto.getApiSecret())
						.header("digigst_pwdotp", new String(authDetailsDto.getPassword()));
				return builder;
			} else if ("GSP_REFRESH_TOKEN".equals(authDetailsDto.getAction())) {
				builder = webResource.header("digigst_username", authDetailsDto.getDigigstUserName())
						.header("api_key", new String(authDetailsDto.getApiKey()))
						.header("Content-Type", "application/json;charset=UTF-8")
						//.header("accept", "*/*")
						.header("api_secret", authDetailsDto.getApiSecret())
				        .header("access_token", authDetailsDto.getAccessToken());
						//.header("refresh_token", authDetailsDto.getAuthToken());
				return builder;
			} else if ("OTPREQUEST".equals(authDetailsDto.getAction())||"AUTHTOKEN".equals(authDetailsDto.getAction())|| "REFRESHTOKEN".equals(authDetailsDto.getAction())) {
				//required for gsp
			     builder = webResource.
			    	header("digigst_username", authDetailsDto.getDigigstUserName()).
					header("api_key", new String(authDetailsDto.getApiKey())).
					header("api_secret", authDetailsDto.getApiSecret()).
			    	header("access_token", authDetailsDto.getAccessToken()).
			    // required for gstn
					header("ip-usr", env.getProperty("ip.usr")).
					header("state-cd", authDetailsDto.getStateCode()).
					header("txn", "returns").
					header("username",authDetailsDto.getUserName().toLowerCase()).
					header("group_code",authDetailsDto.getGroupCode()).
			    	header("Content-Type", "application/json;charset=UTF-8");
			    	
			    	
					return builder;
			}else if(authDetailsDto.getAction() == null){
				
			}
		}

		return null;
    }
    
    /**
     * @param dto
     * @return
     * @throws RestClientException
     */
	public JSONObject getGspAuthDetails(AuthDetailsDto dto) throws RestClientUtilException {
		if (LOGGER.isDebugEnabled())
			LOGGER.info("Starting getGspAuthDetails() method ");
		try {
			Client client = null;
			String endPoint = null;
			String resource = null;
			Map<String, String> body = new HashMap<>();
			if (dto != null && dto.getAction() != null) {
				endPoint = env.getProperty("endpoint.gsp.context.root");
				if ("GSP_OTP".equals(dto.getAction())) {
					client = restClientUtil.getClient(true);
					resource = env.getProperty("endpoint.gsp.otp");
				} else if ("GSP_AUTHTOKEN".equals(dto.getAction())) {
					client = restClientUtil.getClient(true);
					resource = env.getProperty("endpoint.gsp.authtoken");
				} else if ("GSP_REFRESH_TOKEN".equals(dto.getAction())) {
					//Fix for proxy issue in Auth token generation: Bug#1213
					client = Client.create();//restClientUtil.getClient(false); 
					body.put("refresh_token", dto.getRefreshToken());
					body.put("api_key", new String(dto.getApiKey()));
					body.put("api_secret", dto.getApiSecret());
					body.put("groupCode", dto.getGroupCode());
					body.put("expiry", dto.getExpiry());
					body.put("access_token", dto.getAccessToken());
					endPoint = env.getProperty("restapi.gspRefToken-host");
					resource = env.getProperty("gsp-restapi.gspRefreshToken");
				}
			}
			if (null != endPoint && null != resource) {
				WebResource webResource = client.resource(endPoint.trim() + resource.trim());

				LOGGER.debug("URI in the getOTP() " + webResource);

				if (webResource != null) {
					Builder builder = getHeadersOTPGSP(webResource, dto);
					if (builder != null) {
						String OTPresponse = restClientUtil
								.executePOSTRestCalls(new ObjectMapper().writeValueAsString(body), builder);
						return "GSP_REFRESH_TOKEN".equals(dto==null?null:dto.getAction()) ? null
								: (JSONObject) new JSONParser().parse(OTPresponse);
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception in AuthGSPServiceImpl : getGspAuthDetails() " + e.getMessage());
			throw new RestClientUtilException("Exception in AuthGSPServiceImpl : getOTP() " + e);
		}
		return null;

	}
	
}
