package com.ey.advisory.asp.gstn.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.security.crypto.codec.Base64;


import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;

public class CryptoUtilMock {

	private static final Logger LOGGER = Logger.getLogger(CryptoUtilMock.class);
	public static final String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	public static final String RSA_TRANSFORMATION = "RSA/ECB/PKCS1Padding";
	public static final String AES_ALGORITHM = "AES";
	public static final int ENC_BITS = 256;
	public static final String HMAC_SHA_ALGORITHM = "HmacSHA256";
	public static final String CHARACTER_ENCODING = "UTF-8";
	public static final String GSTN_CERTIFICATE="GSTN_PublicKey.cer";
	public static final String X509 = "X.509";

	private static Cipher encryptCipher;
	private static Cipher decryptCipher;
	private static KeyGenerator keygen;

	static {
		try {
			encryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
			decryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
			keygen = KeyGenerator.getInstance(AES_ALGORITHM);
			keygen.init(ENC_BITS);
			
		} catch (NoSuchAlgorithmException|NoSuchPaddingException e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
			try {
				throw new RestClientUtilException("Exception in CrypticUtility.class" + e.getMessage());
			} catch (RestClientUtilException e1) {
				LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
			}
		} 
	}

	/**
	 * This method is used to encode bytes[] to base64 string.
	 * 
	 * @param bytes
	 *            : Bytes to encode
	 * @return : Encoded Base64 String
	 */
	public static String encodeBase64String(byte[] bytes) {
		return new String(Base64.encode(bytes));
	}

	/**
	 * This method is used to decode the base64 encoded string to byte[]
	 * 
	 * @param stringData
	 *            : String to decode
	 * @return : decoded String
	 * @throws UnsupportedEncodingException
	 */
	public static byte[] decodeBase64StringTOByte(String stringData)
			throws Exception {
		return Base64.decode(stringData.getBytes(CHARACTER_ENCODING));
	}

	/**
	 * This method is used to generate the base64 encoded secure AES 256 key *
	 * 
	 * @return : base64 encoded secure Key
	 * @throws NoSuchAlgorithmException
	 * @throws IOException
	 */
	public static String generateSecureKey() throws Exception {
		SecretKey secretKey = keygen.generateKey();
		return encodeBase64String(secretKey.getEncoded());
	}

	/**
	 * This method is used to encrypt the string which is passed to it as byte[]
	 * and return base64 encoded encrypted String
	 * 
	 * @param plainText
	 *            : byte[]
	 * @param secret
	 *            : Key using for encrypt
	 * @return : base64 encoded of encrypted string.
	 * 
	 */

	public static String encryptEK(byte[] plainText, byte[] secret) {
		try {

			SecretKeySpec sk = new SecretKeySpec(secret, AES_ALGORITHM);
			encryptCipher.init(Cipher.ENCRYPT_MODE, sk);
			return new String(Base64.encode(encryptCipher.doFinal(plainText)));

		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
			return "";
		}
	}

	/**
	 * This method is used to decrypt base64 encoded string using an AES 256 bit
	 * key.
	 * 
	 * @param plainText
	 *            : plain text to decrypt
	 * @param secret
	 *            : key to decrypt
	 * @return : Decrypted String
	 * @throws IOException
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 */
	public static byte[] decrypt(String plainText, byte[] secret)
			throws InvalidKeyException, IOException, IllegalBlockSizeException,
			BadPaddingException, Exception {
		SecretKeySpec sk = new SecretKeySpec(secret, AES_ALGORITHM);
		decryptCipher.init(Cipher.DECRYPT_MODE, sk);

		return decryptCipher.doFinal(Base64.decode(plainText.getBytes()));
	}

	/**
	 * @param input
	 * @param pkey
	 * @return
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 */
	public static byte[] encryptData(String input, byte[] pkey)
			throws InvalidKeyException, BadPaddingException,
			IllegalBlockSizeException {
		SecretKeySpec sk = new SecretKeySpec(pkey, AES_ALGORITHM);
		encryptCipher.init(Cipher.ENCRYPT_MODE, sk);

		byte[] inputBytes = input.getBytes();

		return encryptCipher.doFinal(inputBytes);
	}

	/**
	 * @param data
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String hmacSHA256(String data, String key) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(CHARACTER_ENCODING),
				HMAC_SHA_ALGORITHM);
		Mac mac = Mac.getInstance(HMAC_SHA_ALGORITHM);
		mac.init(secretKey);
		byte[] hmacData = mac.doFinal(data.getBytes(CHARACTER_ENCODING));
		return new String(Base64.encode(hmacData), CHARACTER_ENCODING);
	}

	public static InputStream getPublicKey() {
		InputStream result = null;
		ClassLoader classLoader = CryptoUtilMock.class.getClassLoader();

		try {
			result = IOUtils.toBufferedInputStream((classLoader
					.getResourceAsStream(GSTN_CERTIFICATE)));
		} catch (IOException e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
		}
		return result;
	}

	private static PublicKey readPublicKey(InputStream filename)
			throws Exception {

		CertificateFactory f = CertificateFactory.getInstance(X509);
		X509Certificate certificate = (X509Certificate) f
				.generateCertificate(filename);
		PublicKey pk = certificate.getPublicKey();
		return pk;

	}

	/**
	 * This method is used to encrypt the string , passed to it using a public
	 * key provided
	 * 
	 * @param planTextToEncrypt
	 *            : Text to encrypt
	 * @return :encrypted string
	 */
	public static String encrypt(byte[] plaintext) throws Exception,
			NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		PublicKey key = readPublicKey(getPublicKey());
		Cipher cipher = Cipher.getInstance(RSA_TRANSFORMATION);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] encryptedByte = cipher.doFinal(plaintext);
		String encodedString = new String(Base64.encode(encryptedByte));
		return encodedString;
	}

	public static String generateEncAppkey(byte[] key) throws RestClientUtilException {
		try {
			return encrypt(key);
		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
			throw new RestClientUtilException("Exception in CrypticUtility.generateEncAppkey()" + e.getMessage());
		}
	}
	/**
	 * @param result
	 * @param authDetailsDto
	 * @return
	 * @throws ParseException
	 */
	public static AuthDetailsDto getRek(String result, AuthDetailsDto authDetailsDto)
			throws ParseException {

		JSONObject jsonObjectVal;
		jsonObjectVal = (JSONObject) new JSONParser().parse(result);
		authDetailsDto.setEncryptedData((String) jsonObjectVal.get("data"));
		authDetailsDto.setRek((String) jsonObjectVal.get("rek"));
		authDetailsDto.setHmac((String) jsonObjectVal.get("hmac"));

		return authDetailsDto;
	}

	
	/**
	 * @param result
	 * @param authDetails
	 * @return
	 * @throws Exception
	 */
	public static String getPayloadForGSTN(String result, AuthDetailsDto authDetails)
			throws Exception {
		
		byte[] apiek;
		String resultVal;
		authDetails = getRek(result, authDetails);
		apiek = getJsonData(authDetails.getRek(),
				decodeBase64StringTOByte(encodeBase64String(authDetails.getSessionKey())));
		authDetails.setApiKey(apiek);
		resultVal = getJsonDataFinal(authDetails.getEncryptedData(),
				authDetails.getApiKey());
	
		return resultVal;
	}
	/**
	 * @param data
	 * @param apikey
	 * @return
	 */
	private static String getJsonDataFinal(String data, byte[] apikey) {
		String jsonData = null;
		try {
			jsonData = new String(
					decodeBase64StringTOByte(new String(
							decrypt(data, apikey))));
			LOGGER.info("json string " + jsonData);
		} catch (InvalidKeyException|IllegalBlockSizeException|BadPaddingException e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
		} catch (IOException e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
		}
		LOGGER.info(jsonData);
		return jsonData;

	}
	/**
	 * @param gotrek
	 * @param authKey
	 * @return
	 */
	private static byte[] getJsonData(String gotrek, byte[] authKey) {
		byte[] apiEK = null;
		try {
			apiEK = decrypt(gotrek, authKey);
		} catch (InvalidKeyException|IllegalBlockSizeException|BadPaddingException e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
		}catch (IOException e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtilMock : " + e.getMessage());
		}
		
		return apiEK;
	}

}
