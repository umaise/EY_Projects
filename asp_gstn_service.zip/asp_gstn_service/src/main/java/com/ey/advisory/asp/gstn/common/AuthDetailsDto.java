package com.ey.advisory.asp.gstn.common;

import java.io.Serializable;
import java.util.Arrays;

/**
 * @author Deepa.Parashar
 *
 */
public class AuthDetailsDto implements Serializable {
    
    private byte[] authEK;
    public String getExpiry() {
        return expiry;
    }
    public void setExpiry(String expiry) {
        this.expiry = expiry;
    }
    
    private static final long serialVersionUID = 1L;

    private String expiry;
    private String authEKStr;
    private byte[] sessionKey;
    private String sek;// TODO remove
    private String hmac;
    private String encryptedData;
    private String rek;
    private byte[] apiKey;
    private String originalAppKey;
    private String action;
    private String userName;
    private String appKey;
    private String otp;
    private String encryptedAppKey;
    private String encryptedOTP;
    private String encryptedDataSubmit;
    private String stateCode;
    private String errorcode;
    private String digigstUserName;
    private String password;
    private String gspApiKey;
    private String groupCode;
    private String accessToken;
    private String refreshToken;
    private String apiSecret;
    private String ipUsr;
    
    
    public String getDigigstUserName() {
		return digigstUserName;
	}
	public void setDigigstUserName(String digigstUserName) {
		this.digigstUserName = digigstUserName;
	}
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getEncryptedDataSubmit() {
        return encryptedDataSubmit;
    }
    public void setEncryptedDataSubmit(String encryptedDataSubmit) {
        this.encryptedDataSubmit = encryptedDataSubmit;
    }
    public String getAuthEKStr() {
        return authEKStr;
    }
    public void setAuthEKStr(String authEKStr) {
        this.authEKStr = authEKStr;
    }
    public String getSek() {
        return sek;
    }
    public void setSek(String sek) {
        this.sek = sek;
    }

    private String authToken;
    
    public byte[] getAuthEK() {
        return authEK;
    }
    public void setAuthEK(byte[] authEK) {
        this.authEK = authEK;
    }
    public String getAuthToken() {
        return authToken;
    }
    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }
    public String getOriginalAppKey() {
        return originalAppKey;
    }
    public void setOriginalAppKey(String originalAppKey) {
        this.originalAppKey = originalAppKey;
    }
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getAppKey() {
        return appKey;
    }
    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }
    public String getOtp() {
        return otp;
    }
    public void setOtp(String otp) {
        this.otp = otp;
    }
    public String getEncryptedAppKey() {
        return encryptedAppKey;
    }
    public void setEncryptedAppKey(String encryptedAppKey) {
        this.encryptedAppKey = encryptedAppKey;
    }
    public String getEncryptedOTP() {
        return encryptedOTP;
    }
    public void setEncryptedOTP(String encryptedOTP) {
        this.encryptedOTP = encryptedOTP;
    }
    public byte[] getApiKey() {
        return apiKey;
    }
    public void setApiKey(byte[] apiKey) {
        this.apiKey = apiKey;
    }
    public String getRek() {
        return rek;
    }
    public void setRek(String rek) {
        this.rek = rek;
    }
    public byte[] getSessionKey() {
        return sessionKey;
    }
    public void setSessionKey(byte[] sessionKey) {
        this.sessionKey = sessionKey;
    }
    public String getHmac() {
        return hmac;
    }
    public void setHmac(String hmac) {
        this.hmac = hmac;
    }
    public String getEncryptedData() {
        return encryptedData;
    }
    public void setEncryptedData(String encryptedData) {
        this.encryptedData = encryptedData;
    }
    public String getOriginalAppapiKey() {
        return originalAppKey;
    }
    public void setOriginalAppapiKey(String originalAppapiKey) {
        this.originalAppKey = originalAppapiKey;
    }
    public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGspApiKey() {
		return gspApiKey;
	}
	public void setGspApiKey(String gspApiKey) {
		this.gspApiKey = gspApiKey;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
	public String getRefreshToken() {
		return refreshToken;
	}
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	
	public String getApiSecret() {
		return apiSecret;
	}
	public void setApiSecret(String apiSecret) {
		this.apiSecret = apiSecret;
	}
	public String getIpUsr() {
		return ipUsr;
	}
	public void setIpUsr(String ipUsr) {
		this.ipUsr = ipUsr;
	}
	@Override
    public String toString() {
        return "AuthDetailsDto [authEK=" + Arrays.toString(authEK) + ", authEKStr=" + authEKStr + ", sessionKey="
                + Arrays.toString(sessionKey) + ", sek=" + sek + ", hmac=" + hmac + ", encryptedData=" + encryptedData
                + ", rek=" + rek + ", apiKey=" + Arrays.toString(apiKey) + ", originalAppKey=" + originalAppKey
                + ", action=" + action + ", userName=" + userName + ", appKey=" + appKey + ", otp=" + otp
                + ", encryptedAppKey=" + encryptedAppKey + ", encryptedOTP=" + encryptedOTP + ", authToken=" + authToken
                + "]";
    }
    
}
