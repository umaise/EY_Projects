package com.ey.advisory.asp.gstn.util;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.common.Constant;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource.Builder;
import com.sun.jersey.client.urlconnection.HttpURLConnectionFactory;
import com.sun.jersey.client.urlconnection.URLConnectionClientHandler;

@Configuration
@ComponentScan(basePackages = { "com.ey.*" })


@PropertySources({  @PropertySource("classpath:GSTNConfig.properties"),@PropertySource("classpath:GSPConfig.properties"),
	@PropertySource("classpath:ASPGSPIntegeration.properties") })
public class RestClientUtility {

	@Autowired
	private PropertySourceUtil propertyUtil;

	private static final Logger LOGGER = Logger.getLogger(RestClientUtility.class);

	/**
	 * @param builder
	 * @return
	 */
	public String executeGETRestCalls(Builder builder) throws RestClientUtilException {
		//System.setProperty("javax.net.ssl.trustStore", "C:/Program Files/Java/jdk1.8.0_121/jre/lib/security/cacerts");
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Start Rest Service : execute get call ");
		}

		ClientResponse response = builder.get(ClientResponse.class);
		if (response.getStatus() != 200) {
			throw new RestClientUtilException("Exception in executeGETRestCalls(), HTTP error code : " + response.getStatus());
		}
		String output = response.getEntity(String.class);
		
		return output;
	}
  
	/**
	 * @param builder
	 * @return
	 */
	public byte[] executeGETRestCallsFileDownload(Builder builder) throws RestClientUtilException {
		//System.setProperty("javax.net.ssl.trustStore", "C:/Program Files/Java/jdk1.8.0_121/jre/lib/security/cacerts");
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Start Rest Service : execute get call ");
		}

		ClientResponse response = builder.get(ClientResponse.class);
		if (response.getStatus() != 200) {
			throw new RestClientUtilException("Exception in executeGETRestCalls(), HTTP error code : " + response.getStatus());
		}
		byte[] output = response.getEntity(byte[].class);
		return output;
	}
  
	/**
	 * @param body
	 * @param builder
	 * @return
	 * @throws RestClientUtilException 
	 */
	public String executePOSTRestCalls(String body, Builder builder) throws RestClientUtilException {
		//System.setProperty("javax.net.ssl.trustStore", "C:/Program Files/Java/jdk1.8.0_121/jre/lib/security/cacerts");
	//	HttpsURLConnection.setDefaultHostnameVerifier ((hostname, session) -> true);
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Start Rest Service : execute post call ");
		}

		ClientResponse response = builder.post(ClientResponse.class, body);
		if (response.getStatus() != 200) {
			throw new RestClientUtilException("Exception in executePOSTRestCalls(), HTTP error code : " + response.getStatus() + " message : " );
		}
		String output = response.getEntity(String.class);
		return output;
	}

	/**
	 * @param body
	 * @param builder
	 * @return
	 * @throws RestClientUtilException 
	 */
	public String executePUTRestCalls(String body, Builder builder) throws RestClientUtilException {

		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Start Rest Service : execute put call");
		}
		//builder.
		
		ClientResponse response = builder.put(ClientResponse.class, body);
		
		if (response.getStatus() != 200) {
			
			throw new RestClientUtilException("Exception in executePUTRestCalls(), HTTP error code : " + response.getStatus());
		}
		String output = response.getEntity(String.class);
		return output;
	}

	/**
	 * This method provide Client object on basis of whether proxy is required
	 * or not for the call
	 * 
	 * @param proxyRequired
	 * @return
	 */
	public Client getClient(boolean proxyRequired) {
		Client client;
		try{
		proxyRequired=propertyUtil.getProxy(Constant.PROXY_REQUIRED);
		}catch(RestClientUtilException e){
			LOGGER.error("Exception while calling getProxy()" + e);}
		if (proxyRequired) {
			HttpURLConnectionFactory connectionFactory = new HttpURLConnectionFactory() {
				Proxy proxy;
				private void initializeProxy() throws NumberFormatException, RestClientUtilException {
					proxy = new Proxy(Proxy.Type.HTTP,
							new InetSocketAddress(propertyUtil.getValue("proxy.host"),
									Integer.valueOf(propertyUtil.getValue("proxy.port"))));
				}
				@Override
				public HttpURLConnection getHttpURLConnection(URL url) throws IOException {
					try {
						initializeProxy();
					} catch (NumberFormatException | RestClientUtilException e) {
						LOGGER.error("Exception in getData() in  RestClientUtility : " + e.getMessage());
					}
					return (HttpURLConnection) url.openConnection(proxy);
				}
			};
			URLConnectionClientHandler ch = new URLConnectionClientHandler(connectionFactory);
			client = new Client(ch);
		} else {
			client = Client.create();
		}
		return client;
	}
	
	public static AuthDetailsDto getRedisData(String gstinId)
	{
        RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<>();
        RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
        redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.afterPropertiesSet();
        AuthDetailsDto dto=null;
        
        try{
        	Map<Object, Object> entries = redisIntegertemplate.opsForHash().entries(gstinId);
        	if(null != entries)
        	{
        		 dto=new AuthDetailsDto();
        		if(entries.get("sk")!=null)
        		{
        			dto.setSek(entries.get("sk").toString());
        		}
        		if(entries.get("errorCode")!=null)
        		{
        			dto.setErrorcode(entries.get("errorCode").toString());
        		}
        		if(entries.get("userName")!=null)
        		{
        			dto.setUserName(entries.get("userName").toString());
        		}
        		if(entries.get("auth-token")!=null)
        		{
        			dto.setAuthToken(entries.get("auth-token").toString());	
        		}
        		if(entries.get("state-cd")!=null)
        		{
        			dto.setStateCode(entries.get("state-cd").toString());	
        		}
        		
        		LOGGER.info("in getRedisData ==>"+entries.toString());
        	}else{
        		LOGGER.info("No data in redis for gstin ==>"+gstinId);
        	}
        	
        }
        catch(Exception ex)
        {
        	LOGGER.error(ex);
        }
		return dto;
	}
	
	public static Map<Object, Object> getRedisDataForGSP(String groupCode)
	{
        RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<>();
        RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
        redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.afterPropertiesSet();
        Map<Object, Object> gspDetailsMap = null;
       try{
   			gspDetailsMap =redisIntegertemplate.opsForHash().entries(groupCode.toLowerCase()+"_"+Constant.GSP_USERDETAILS); 
        }
        catch(Exception ex)
        {
        	LOGGER.error(ex);
        }
       if(null!=gspDetailsMap){
       LOGGER.info("in getRedisDataForGSP ==>"+gspDetailsMap.toString());
		return gspDetailsMap;
		
       }else{
    	   LOGGER.info("no GSP data in redis ");
    	   return null;
       }
	}
	
	public static String getRedisConnection(String gstinId)
	{
		String status;
		RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<>();
        RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
        redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.afterPropertiesSet();
        Map<Object, Object> entries = redisIntegertemplate.opsForHash().entries(gstinId);
        status=(String) entries.get("status");
        return status;
	}
	
	public static void saveRedisDataGSTN(String gstinId, AuthDetailsDto dto)
	{
        RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<>();
        RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
        redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.afterPropertiesSet();
        
        Map<String, String> gstnDetails = new HashMap<String, String>();
        
        gstnDetails.put("userName", dto.getUserName());
        gstnDetails.put("appkey", dto.getAppKey());
        gstnDetails.put("encAppkey", dto.getEncryptedAppKey());
        redisIntegertemplate.opsForHash().putAll(gstinId, gstnDetails);
        
		//return dto;
	}
	
	public static AuthDetailsDto getRedisDataBeforeOTP(String gstinId)
	{
        RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<>();
        RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
        redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
        redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
        redisIntegertemplate.afterPropertiesSet();
        AuthDetailsDto dto=null;
        
        try{
        	Map<Object, Object> entries = redisIntegertemplate.opsForHash().entries(gstinId);
        	if(null != entries)
        	{
        		 dto=new AuthDetailsDto();
        		
        		if(entries.get("userName")!=null)
        		{
        			dto.setUserName(entries.get("userName").toString());
        		}
        		if(entries.get("appkey")!=null)
        		{
        			dto.setAppKey(entries.get("appkey").toString());	
        		}
        		if(entries.get("encAppkey")!=null)
        		{
        			dto.setEncryptedAppKey(entries.get("encAppkey").toString());	
        		}
        		
        		LOGGER.info("in getRedisDataBeforeOTP ==>"+entries.toString());
        	}else{
        		LOGGER.info("No data in redis for gstin getRedisDataBeforeOTP call ==>"+gstinId);
        	}
        	
        }
        catch(Exception ex)
        {
        	LOGGER.error(ex);
        }
		return dto;
	}
	
public  HashMap<String, String> validateGspGstnAuthTokens(String groupCode, String gstin) throws ParseException, NumberFormatException, RestClientUtilException {
		
		String dateModifiedForGSP = getDateModifiedFromRedisfortheGSP(groupCode);
		String gspValidationReq = propertyUtil.getValue("isGSPValReq");
		HashMap<String, String> statusMap = new HashMap<String, String>();
		statusMap.put("GSP", "Active");
		statusMap.put("GSTN", "Active");
		
		if(null !=dateModifiedForGSP && !dateModifiedForGSP.isEmpty()){
			Date gspDateMod = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateModifiedForGSP);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(gspDateMod); 
			cal.add(Calendar.HOUR_OF_DAY, Integer.parseInt(propertyUtil.getValue("expiryTimeGSP")));
			Date gspDateModExpiry = cal.getTime();
			Date currentDate = new Date();
			if("true".equalsIgnoreCase(gspValidationReq) && gspDateModExpiry.compareTo(currentDate) <= 0 ){
				statusMap.put("GSP", "InActive");
			}else{
				String dateModifiedForGSTN = getDateModifiedFromRedisfortheGstin(gstin);
				
				if(null !=dateModifiedForGSTN && !dateModifiedForGSTN.isEmpty()){
					Date gstnDateMod = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateModifiedForGSTN);
					
					Calendar calGstn = Calendar.getInstance();
					calGstn.setTime(gstnDateMod); 
					calGstn.add(Calendar.HOUR_OF_DAY, Integer.parseInt(propertyUtil.getValue("expiryTimeGSTIN")));
					Date gstnDateModExpiry = calGstn.getTime();
					Date currentDateGstn = new Date();
					if(gstnDateModExpiry.compareTo(currentDateGstn) <= 0 ){
						statusMap.put("GSTN", "InActive");
					}
				}else{
					statusMap.put("GSTN", "InActive");
				}
			}
		}else{
			statusMap.put("GSP", "InActive");
		}
		
	return statusMap;
	
}

public static String getDateModifiedFromRedisfortheGstin(String gstinId)
{
	String dateModified=null;
	RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<>();
    RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
    redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
    redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
    redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
    redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
    redisIntegertemplate.afterPropertiesSet();
    Map<Object, Object> entries = redisIntegertemplate.opsForHash().entries(gstinId);
    if(null!=entries && null != entries.get("dateModified")){
    	dateModified=(String) entries.get("dateModified");
    }
    return dateModified;
}

public static String getDateModifiedFromRedisfortheGSP(String groupCode)
{
	String dateModified=null;
	RedisTemplateUtils<String, String> redisIntegertemplateUtil= new RedisTemplateUtils<>();
    RedisTemplate<String, String> redisIntegertemplate=redisIntegertemplateUtil.getRedisTemplate();
    redisIntegertemplate.setKeySerializer(new StringRedisSerializer());
    redisIntegertemplate.setValueSerializer(new StringRedisSerializer());
    redisIntegertemplate.setHashValueSerializer(new StringRedisSerializer());
    redisIntegertemplate.setHashKeySerializer(new StringRedisSerializer());
    redisIntegertemplate.afterPropertiesSet();
    Map<Object, Object> entries = redisIntegertemplate.opsForHash().entries(groupCode.toLowerCase()+"_"+Constant.GSP_USERDETAILS);
    if(null!=entries && null != entries.get("dateModified")){
    	dateModified=(String) entries.get("dateModified");
    }
    return dateModified;
}

}
