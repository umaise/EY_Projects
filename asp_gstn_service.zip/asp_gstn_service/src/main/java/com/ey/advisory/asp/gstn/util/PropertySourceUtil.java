package com.ey.advisory.asp.gstn.util;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;

import com.ey.advisory.asp.gstn.exception.RestClientUtilException;


@Configuration
@ComponentScan(basePackages = { "com.ey.*" })
@PropertySources({
	@PropertySource("classpath:GSTNConfig.properties"),
	@PropertySource("classpath:GSPConfig.properties")
})
public class PropertySourceUtil {
		
	@Autowired
	private Environment env;
	
	
	/**
	 * @param property
	 * @return
	 * @throws PropertyNotFoundException
	 */
	public String getValue(String property) throws RestClientUtilException {
		if( env.getProperty(property) != null || env.getProperty(property).isEmpty()){
			return env.getProperty(property);
		} else {
			throw new RestClientUtilException(property + "not found.");
		}
	}
	
	/**
	 * @param property
	 * @param version
	 * @return
	 */
	public String getValue(String property, String version) throws RestClientUtilException {
		if( env.getProperty(property) != null || env.getProperty(property)!=""){
			if(version !=null && !version.trim().isEmpty())
				return env.getProperty(property+"_"+version);
			else
				return env.getProperty(property+"_v0.1");
		} else {
			throw new RestClientUtilException(property + "not found.");
		}
	}

	
	public boolean getProxy(String property) throws RestClientUtilException {
		if( !(env.getProperty(property) == null || env.getProperty(property).isEmpty())){
			String proxy=env.getProperty(property);
			if(proxy.equalsIgnoreCase("true")){
				return true;}	
			else{
				return false;}
		} else {
			throw new RestClientUtilException(property + "not found.");
		}
	}
}
