package com.ey.advisory.asp.gstn.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Properties;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;
import com.sun.jersey.core.util.Base64;


//@PropertySource("classpath:ASPGSPIntegeration.properties")
public class CryptoUtil {


	private static final Logger LOGGER = Logger.getLogger(CryptoUtil.class);
	public static final String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	public static final String AES_ALGORITHM = "AES";
	public static final int ENC_BITS = 256;
	public static final String CHARACTER_ENCODING = "UTF-8";

	private static Cipher ENCRYPT_CIPHER;
	private static Cipher DECRYPT_CIPHER;
	private static KeyGenerator KEYGEN;
	
	/*@Autowired
	private PropertySourceUtil propertyUtil;
	
	@Autowired
	private Environment env;*/
	

	static {
		try {
			ENCRYPT_CIPHER = Cipher.getInstance(AES_TRANSFORMATION);
			DECRYPT_CIPHER = Cipher.getInstance(AES_TRANSFORMATION);
			KEYGEN = KeyGenerator.getInstance(AES_ALGORITHM);
			KEYGEN.init(ENC_BITS);
		} catch (NoSuchAlgorithmException|NoSuchPaddingException e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		} 
	}
	
	/**
	 * @return
	 * @throws IOException 
	 
	 */
	public  InputStream getPublicKey(AuthDetailsDto dto) throws IOException {
		Properties properties = new Properties();
		InputStream result = null;
		ClassLoader classLoader = CryptoUtil.class.getClassLoader();
		properties.load(CryptoUtil.class.getResourceAsStream("/ASPGSPIntegeration.properties"));
		InputStream in = null;
		try {
		if(dto != null && dto.getAction()!= null && "GSP_OTP".equals(dto.getAction())){
			String value = properties.getProperty("certificatePathForGSP");
			in = IOUtils.toBufferedInputStream((classLoader.getResourceAsStream(value)));
		}else{
			in = IOUtils.toBufferedInputStream((classLoader.getResourceAsStream(properties.getProperty("certificatePath"))));
		}
		
			result = IOUtils.toBufferedInputStream(in);//(classLoader.getResourceAsStream("GSTN_public.cer"))); // EY
			
		} catch (IOException e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		} finally {
			in.close();
		}
		return result;
	} 

	/**
	 * @param filename
	 * @return
	 * @throws Exception
	 */
	private static PublicKey readPublicKey(InputStream filename) throws Exception {

		CertificateFactory f = CertificateFactory.getInstance("X.509");
		X509Certificate certificate = (X509Certificate) f.generateCertificate(filename);
		PublicKey pk = certificate.getPublicKey();
		return pk;

	}

	/**
	 * This method is used to encrypt the string , passed to it using a public
	 * key provided
	 * 
	 * @param planTextToEncrypt
	 *            : Text to encrypt
	 * @return :encrypted string
	 */
	public static String encrypt(byte[] plaintext,AuthDetailsDto dto) throws Exception, NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		PublicKey key = readPublicKey(new CryptoUtil().getPublicKey(dto));
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] encryptedByte = cipher.doFinal(plaintext);
		String encodedString = new String(Base64.encode(encryptedByte));
		return encodedString;
	}

	/**
	 * @param key
	 * @return
	 */
	public static String generateEncAppkey(byte[] key) {
		try {
			return encrypt(key,null);
		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
			return null;
		}
	}

	/**
	 * This method is used to encode bytes[] to base64 string.
	 * 
	 * @param bytes
	 *            : Bytes to encode
	 * @return : Encoded Base64 String
	 */
	public static String encodeBase64String(byte[] bytes) {
		return new String(Base64.encode(bytes));
	}

	/**
	 * This method is used to decode the base64 encoded string to byte[]
	 * 
	 * @param stringData
	 *            : String to decode
	 * @return : decoded String
	 * @throws UnsupportedEncodingException
	 */
	public static byte[] decodeBase64StringTOByte(String stringData)
			throws UnsupportedEncodingException {
		//String data is Appkey
		return Base64.decode(stringData.getBytes(CHARACTER_ENCODING));
	}
	/**
	 * This method is used to generate the base64 encoded secure AES 256 key *
	 * 
	 * @return : base64 encoded secure Key
	 * @throws NoSuchAlgorithmException
	 * @throws IOException
	 */
	public static String generateSecureKey() throws Exception {
		SecretKey secretKey = KEYGEN.generateKey();
		return encodeBase64String(secretKey.getEncoded());
	}

	
	
	/**
	 * This method is used to generate the base64 encoded secure AES 256 key *
	 * 
	 * @return : base64 encoded secure Key
	 * @throws NoSuchAlgorithmException
	 * @throws IOException
	 */
	public static byte[] generateSecureKeyByte() throws Exception {
		SecretKey secretKey = KEYGEN.generateKey();
		return secretKey.getEncoded();
	}

	/**
	 * This method is used to encrypt the string which is passed to it as byte[]
	 * and return base64 encoded encrypted String
	 * 
	 * @param plainText
	 *            : byte[]
	 * @param secret
	 *            : Key using for encrypt
	 * @return : base64 encoded of encrypted string.
	 * 
	 */
	static {
		try {
			Field field = Class.forName("javax.crypto.JceSecurity").getDeclaredField("isRestricted");
			field.setAccessible(true);
			field.set(null, java.lang.Boolean.FALSE);
		} catch (Exception ex) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + ex.getMessage());
		}
	} 

	public static String encryptEK(byte[] plainText, byte[] secret) {
		try {

			SecretKeySpec sk = new SecretKeySpec(secret, AES_ALGORITHM);

			ENCRYPT_CIPHER.init(Cipher.ENCRYPT_MODE, sk);

			return new String(Base64.encode(ENCRYPT_CIPHER.doFinal(plainText)));

		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
			return "";
		}
	}
	

	/**
	 * This method is used to decrypt base64 encoded string using an AES 256 bit
	 * key.
	 * 
	 * @param plainText
	 *            : plain text to decrypt
	 * @param secret
	 *            : key to decrypt
	 * @return : Decrypted String
	 * @throws IOException
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 */
	public static byte[] decrypt(String plainText, byte[] secret)
			throws InvalidKeyException, IOException, IllegalBlockSizeException, BadPaddingException {
		SecretKeySpec sk = new SecretKeySpec(secret, AES_ALGORITHM);
		DECRYPT_CIPHER.init(Cipher.DECRYPT_MODE, sk);
		return DECRYPT_CIPHER.doFinal(Base64.decode(plainText.getBytes()));
	}

	/**
	 * This method generates encoded and encrypted appkey
	 * @param AuthDetailsDto
	 *            dto
	 * @return
	 */
	public static AuthDetailsDto getAppKeyEncodedEncrypted(AuthDetailsDto dto) {
		String encryptedAppkey = null;
		String appkey = null;
		try {
			appkey = generateSecureKey();
			encryptedAppkey = CryptoUtil.generateEncAppkey(decodeBase64StringTOByte(appkey));
			dto.setAppKey(appkey);
			dto.setEncryptedAppKey(encryptedAppkey);
		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		}
		return dto;
	}

	public static byte[] encryptData(String input, byte[] pkey)
			throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		SecretKeySpec sk = new SecretKeySpec(pkey, AES_ALGORITHM);
		ENCRYPT_CIPHER.init(Cipher.ENCRYPT_MODE, sk);
		byte[] inputBytes = input.getBytes();
		return ENCRYPT_CIPHER.doFinal(inputBytes);
	}
	

	public static String hmacSHA256(String data, String key) throws Exception {

		SecretKeySpec secretKey = new SecretKeySpec(key.getBytes("UTF-8"), "HmacSHA256");
		Mac mac = Mac.getInstance("HmacSHA256");
		mac.init(secretKey);
		byte[] hmacData = mac.doFinal(data.getBytes("UTF-8"));
		return new String(Base64.encode(hmacData));
	}

	public static String hmacSHA256(String data, byte[] key) throws NoSuchAlgorithmException, InvalidKeyException, IllegalStateException, UnsupportedEncodingException {

		SecretKeySpec secretKey = new SecretKeySpec(key, "HmacSHA256");
		Mac mac = Mac.getInstance("HmacSHA256");
		mac.init(secretKey);
		byte[] hmacData = mac.doFinal(data.getBytes("UTF-8"));
		return new String(Base64.encode(hmacData));
	}

	
	/**
	 * @param gotrek
	 * @param sessionKey
	 * @return
	 */
	public static byte[] getapiEK(String gotrek, byte[] sessionKey) {
		byte[] apiEK = null;

		try {
			apiEK = decrypt(gotrek, sessionKey);
		} catch (InvalidKeyException|IllegalBlockSizeException|BadPaddingException e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		}catch (IOException e) {
			 LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		}
		return apiEK;

	}

	/**
	 * @param data
	 * @param apikey
	 * @return
	 */
	public static String getJsonData(String data, byte[] apikey) {
		String jsonData = null;
		if(LOGGER.isInfoEnabled())
		LOGGER.info("In method : getJsonData() in : RestClientUtility ");
		
		try {
			jsonData = new String(CryptoUtil.decodeBase64StringTOByte(new String(CryptoUtil.decrypt(data, apikey))));

		} catch (InvalidKeyException|IllegalBlockSizeException|BadPaddingException e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		}catch (IOException e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		}
		return jsonData;
	}

	/**
	 * @param result
	 * @param authDetails
	 * @return
	 * @throws ParseException
	 */
	public static String getPayloadForGSTN(String result, AuthDetailsDto authDetails) throws ParseException {

		byte[] apiek;
		String resultVal;
		authDetails = getRek(result, authDetails);
		apiek = CryptoUtil.getapiEK(authDetails.getRek(), authDetails.getAuthEK());
		authDetails.setApiKey(apiek);
		resultVal = getJsonData(authDetails.getEncryptedData(), authDetails.getApiKey());
		return resultVal;
	}

	
	/**
	 * @param result
	 * @param authDetailsDto
	 * @return
	 * @throws ParseException
	 */
	public static AuthDetailsDto getRek(String result, AuthDetailsDto authDetailsDto) throws ParseException {

		JSONObject jsonObjectVal;
		jsonObjectVal = (JSONObject) new JSONParser().parse(result);
		authDetailsDto.setEncryptedData((String) jsonObjectVal.get("data"));
		authDetailsDto.setRek((String) jsonObjectVal.get("rek"));
		authDetailsDto.setHmac((String) jsonObjectVal.get("hmac"));
		return authDetailsDto;
	}

	/**
	 * @param appkey
	 * @param receivedSEK
	 * @param data
	 * @param dto
	 * @return
	 */
	public static AuthDetailsDto encryptDataForSave(String appkey, String receivedSEK, String data, AuthDetailsDto dto) {

		AuthDetailsDto authDetails = dto;
		byte[] authEK = null;
		String hmac = null;
		String encryptedData = null;
		try {
			authEK = CryptoUtil.decodeBase64StringTOByte(receivedSEK);
			dto.setAuthEK(authEK);
			String base64Data = CryptoUtil.encodeBase64String(data.getBytes());
			hmac = CryptoUtil.hmacSHA256(base64Data, authEK);
			authDetails.setHmac(hmac);
			encryptedData = CryptoUtil
					.encodeBase64String(CryptoUtil.encryptData(CryptoUtil.encodeBase64String(data.getBytes()), authEK));
			authDetails.setEncryptedData(encryptedData);

		} catch (Exception e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		}
		return authDetails;
	}

	/**
	 * @param dataBytes
	 * @param authEK
	 * @return
	 */
	public static String encryptDataForSubmit(byte[] dataBytes, byte[] authEK) {

		String encryptedDataSubmit = "";
		try {
			encryptedDataSubmit = CryptoUtil
					.encodeBase64String(CryptoUtil.encryptData(CryptoUtil.encodeBase64String(dataBytes), authEK));
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		}
		return encryptedDataSubmit;
	}
	
	/**
	 * @param data
	 * @param keyencoded
	 * @return
	 */
	public static String encryptDataForkeySecret(String data, String keyencoded) {

		String encryptedDataSubmit = "";
		try {
			encryptedDataSubmit = CryptoUtil
					.encodeBase64String(CryptoUtil.encryptData(data, keyencoded.getBytes())) ;
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
			LOGGER.error("Exception in getData() in  CryptoUtil : " + e.getMessage());
		}
		return encryptedDataSubmit;
	}
	
}
