package com.ey.advisory.asp.gstn.service.second;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.common.Constant;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;
import com.ey.advisory.asp.gstn.util.CryptoUtil;
import com.ey.advisory.asp.gstn.util.CryptoUtilMock;
import com.ey.advisory.asp.gstn.util.PropertySourceUtil;
import com.ey.advisory.asp.gstn.util.RestClientUtility;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

@Component("GSTNServiceMock")
@PropertySource("classpath:GSPConfig.properties")
public class GstnServiceImplMock implements IAPIService {

	private static final Logger LOGGER = Logger.getLogger(GstnServiceImpl.class);

	@Autowired
	private PropertySourceUtil propertyUtil;

	@Autowired
	private RestClientUtility restClientUtil;

	@Autowired
	private AuthGSTNAPIServiceImplMock authService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#getData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public String getData(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin, String taxPrd,
			String hostName, String resourceName, String formType, String action, boolean proxyRequired) {
		if(LOGGER.isInfoEnabled())
		LOGGER.info("GSP api getData() service called...");

		String host = "";
		String resource = "";
		String decryptedGetDataRes = "";
		String getDataRes = "";
		try {
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);

			String resourseUrl = host + resource + formType + "?gstin=" + gstin + "&ret_period=" + taxPrd + "&action="
					+ action+"&action_required=Y";
			if(LOGGER.isInfoEnabled())
			LOGGER.info("REsurce URL in getData : " + resourseUrl);
			Client client = restClientUtil.getClient(proxyRequired);
			WebResource webResource = client.resource(resourseUrl);
			if(LOGGER.isInfoEnabled())
			LOGGER.info("URI for api call : " + webResource.getURI());

			Builder builder = headerForGETReq(webResource, authDetails);
			getDataRes = restClientUtil.executeGETRestCalls(builder);

			if(LOGGER.isInfoEnabled())
			LOGGER.info("Get data api call response for : " + gstin + "for tax period : " + taxPrd + " is --> "
					+ getDataRes);
			// decrypt the response received for the above call
			decryptedGetDataRes = CryptoUtilMock.getPayloadForGSTN(getDataRes, authDetails);
			if(LOGGER.isInfoEnabled())
			LOGGER.info("Decrypted response for Get data api call for : " + gstin + "for tax period : " + taxPrd
					+ " is : " + decryptedGetDataRes);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return decryptedGetDataRes;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#
	 * saveDataInAuthDetailsVO(java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public AuthDetailsDto saveDataInAuthDetailsVO(String gstin, String taxPrd, String userName, String data,  String version) {

		AuthDetailsDto dto = new AuthDetailsDto();
		try {

			dto = authService.getOTP(dto);
			dto = authService.getAuthToken(dto);
			dto = authService.testDataForPut(dto.getAppKey(), dto.getSek(), data, dto);
			if(LOGGER.isInfoEnabled())
			LOGGER.info("Initial process of auth is done : " + dto.toString());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#saveData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String saveData(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) {
		// TODO Auto-generated method stub

		if(LOGGER.isInfoEnabled())
		LOGGER.info("GSP api saveData() service called...");

		String host = "";
		String resource = "";
		String decryptedGetDataRes = "";
		String getDataRes = "";
		try {
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);
			authDetailsDto = authService.testDataForPut(authDetailsDto.getAppKey(), authDetailsDto.getSek(), dataJson, authDetailsDto);
			
			Client client = restClientUtil.getClient(proxyRequired);
			
			//client.getProperties().put(ClientConfig.PROPERTY_READ_TIMEOUT,30000);
			WebResource webResource = client.resource(host + resource+formType);
			if(LOGGER.isInfoEnabled())
			LOGGER.info("URI for api call : " + webResource.getURI());
			// get header info
			Builder builder = headerForPUTReq(webResource, authDetailsDto);
			getDataRes = restClientUtil.executePUTRestCalls(gstrReqPayload(authDetailsDto, action),builder);

			if(LOGGER.isInfoEnabled())
			LOGGER.info("Save data api call response for : " + gstin + "for tax period : " + taxPrd + " is --> "
					+ getDataRes);
			
			// decrypt the response received for the above call
			decryptedGetDataRes = CryptoUtilMock.getPayloadForGSTN(getDataRes, authDetailsDto);
			if(LOGGER.isInfoEnabled())
			LOGGER.info("Decrypted response for Save data api call for : " + gstin + "for tax period : " + taxPrd
					+ " is : " + decryptedGetDataRes);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return decryptedGetDataRes;

	}

	public String gstrReqPayload(AuthDetailsDto authDetailsDto, String action)
			throws JsonGenerationException, JsonMappingException, IOException {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(Constant.ACTION, action);
		paramMap.put(Constant.DATA, authDetailsDto.getEncryptedData());
		paramMap.put(Constant.HMAC, authDetailsDto.getHmac());

		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		if(LOGGER.isInfoEnabled())
		LOGGER.info("Request Payload Data: " + mapAsJson);
		return mapAsJson;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.gstn.service.second.IAPIService#getTransactionStatus(
	 * com.ey.advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String getTransactionStatus(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin,
			String taxPrd, String hostName, String resourceName, String formType, String action, String transID,
			boolean proxyRequired) {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.gstn.service.second.IAPIService#submitData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String submitData(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) {
		String host = "";
		String resource = "";
		String retSubmitResponse = "";
		String retSubmitResponsedec = "";
		try {
			//encryptedDataSubmit = CryptoUtilMock.encryptDataForSubmit(dataJson.getBytes(), authDetailsDto.getAuthEK());
		//	authDetailsDto.setEncryptedDataSubmit(encryptedDataSubmit);
			authDetailsDto = authService.testDataForPut(authDetailsDto.getAppKey(), authDetailsDto.getSek(), dataJson, authDetailsDto);

			if(LOGGER.isInfoEnabled())
			LOGGER.info("encryptedDataSubmit  : " + authDetailsDto.getEncryptedData());

			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);

			Client client = restClientUtil.getClient(proxyRequired);

			WebResource webResource = client.resource(host + resource+formType);
			if(LOGGER.isInfoEnabled())
			LOGGER.info("URI for api call : " + webResource.getURI());
			// get header info
			Builder builder = headerForPOSTReq(webResource, authDetailsDto);

			retSubmitResponse = restClientUtil.executePOSTRestCalls(gstrRETSUBMITPayload(authDetailsDto.getEncryptedData(), "RETSUM"),
					builder);

			if(LOGGER.isInfoEnabled())
			LOGGER.info("retSubmitResponsedec  :::: - " + retSubmitResponse);
			retSubmitResponsedec = CryptoUtilMock.getPayloadForGSTN(retSubmitResponse, authDetailsDto);
			if(LOGGER.isInfoEnabled())
			LOGGER.info("Decrypted payload retSubmitResponsedec::  " + retSubmitResponsedec);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return retSubmitResponsedec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#fileGSTR(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String fileGSTR(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String signedData, String st, String sid,
			String userName,String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {

		String encryptedDataSubmit;
		String host;
		String resource;
		String retSubmitResponse;
		String retSubmitResponsedec;
			encryptedDataSubmit = CryptoUtil.encryptDataForSubmit(dataJson.getBytes(), authDetailsDto.getAuthEK());
			authDetailsDto.setEncryptedDataSubmit(encryptedDataSubmit);
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("encryptedDataSubmit  : " + encryptedDataSubmit);
			}

			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);
			Client client = restClientUtil.getClient(proxyRequired);
			WebResource webResource = client.resource(host + resource);
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("URI for api call : " + webResource.getURI());
			}
			Builder builder = headerForPOSTReq(webResource, authDetailsDto);
			
			try {
				retSubmitResponse = restClientUtil.executePOSTRestCalls(gstrRETFILEPayload(encryptedDataSubmit, "RETFILE",signedData, st, sid),
						builder);
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("retSubmitResponsedec  :::: - " + retSubmitResponse);
				}
				retSubmitResponsedec = CryptoUtil.getPayloadForGSTN(retSubmitResponse, authDetailsDto);
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("Decrypted payload retSubmitResponsedec::  " + retSubmitResponsedec);
				}
				
			} catch (IOException|ParseException e1) {
				LOGGER.error("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage());
				throw new RestClientUtilException("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage());
				
			} 
		return retSubmitResponsedec;
	}

	/**
	 * @param encryptedDataSubmit
	 * @param action
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private String gstrRETSUBMITPayload(String encryptedDataSubmit, String action)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("action", "RETSUBMIT");
		paramMap.put("data", encryptedDataSubmit);

		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	/**
	 * @param webResource
	 * @param authDetailsDto
	 * @return
	 */
	public Builder headerForGETReq(WebResource webResource, AuthDetailsDto authDetailsDto) {
		
		Builder builder = webResource.
				 header("auth-token", "8a227e0ba56042a0acdf98b3477d2c03")
				.header("eygspclientid", "aspAdmin")
				.header("txn", "returns")
				.header("state-cd", "11")
				.header("Content-Type", "application/json;charset=UTF-8")
				.header("username", "EYGSPTESTUSER")
				.header("eygspuser", "EYASPAdmin@ey.com")
				.header("eygspclientsecret", "Password1")
				.header("ip-usr", "12.8.9l.80");
		
		

		return builder;
	}

	/**
	 * @param webResource
	 * @param authDetailsDto
	 * @return
	 */

	public Builder headerForPUTReq(WebResource webResource, AuthDetailsDto authDetailsDto) {
		
		Builder builder = webResource.
				 header("auth-token", "8a227e0ba56042a0acdf98b3477d2c03")
				.header("clientid", "l7xxdf2b47b7d728426699a05c8d1ec33a60")
				.header("txn", "returns")
				.header("state-cd", "11")
				.header("Content-Type", "application/json;charset=UTF-8")
				.header("username", "G2BTESTUSER")
				.header("client-secret", "30a28162eb024f6e859a12bbb9c31725")
				.header("ip-usr", "12.8.9l.80");
		
		return builder;
	
	}

	/**
	 * @param webResource
	 * @param authDetailsDto
	 * @return
	 */
	public Builder headerForPOSTReq(WebResource webResource, AuthDetailsDto authDetailsDto) {
		Builder builder = webResource.
				 header("auth-token", "8a227e0ba56042a0acdf98b3477d2c03")
				.header("eygspclientid", "aspAdmin")
				.header("txn", "returns")
				.header("state-cd", "11")
				.header("Content-Type", "application/json;charset=UTF-8")
				.header("username", "EYGSPTESTUSER")
				.header("eygspuser", "EYASPAdmin@ey.com")
				.header("eygspclientsecret", "Password1")
				.header("ip-usr", "12.8.9l.80");

		return builder;
	}

	@Override
	public String saveDataViaGSP(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSummaryData(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin,
			String taxPrd, String hostName, String resourceName, String formType, String action, boolean proxyRequired)
					throws RestClientUtilException {
		// NOT USING THIS ANYMORE
		return null;
	}
	/**
	 * @param encryptedDataSubmit
	 * @param action
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private String gstrRETFILEPayload(String encryptedDataSubmit, String action, String signedData, String st, String pan)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", "RETFILE");
		paramMap.put("data", encryptedDataSubmit);
		paramMap.put("sign", signedData);
		paramMap.put("st", st);
		paramMap.put("sid", pan);

		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	@Override
	public byte[] getDataFileDownload(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin,
			String taxPrd, String hostName, String resourceName, String formType, String action, boolean proxyRequired)
					throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getOTP(String mobNo, String appKey, String userName,
			String URI,String apiKey, String apiSecret) throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getEncryptedApiKeySecret(String appKey, String apikey, String apiSecret) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String verifyOTP(String userName, String apiKey, String apiSecret,
			String otp, String signedData, String URI)
			throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String submitGSTR3Data(AuthDetailsDto authDetailsDto,
			String apiVersion, String dataJson, String userName, String gstin,
			String taxPrd, String hostName, String resourceName,
			String formType, String action, boolean proxyRequired)
			throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getGSTR3Data(AuthDetailsDto authDetails, String apiVersion,
			String userName, String gstin, String taxPrd, String hostName,
			String resourceName, String formTypeorToken, String action,
			String getFinal, boolean proxyRequired)
			throws RestClientUtilException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean isCAGateWayByPassEnabled() {
		return false;
	}
}
