package com.ey.advisory.asp.gstn.service.second;

import org.json.simple.parser.ParseException;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;

/**
 * Contains methods for API calls
 *
 */
public interface IAPIService {
	
	/**
	 * @param gstin
	 * @param taxPrd
	 * @param userName
	 * @return
	 */
	public AuthDetailsDto saveDataInAuthDetailsVO(String gstin, String taxPrd,  String userName, String data,  String version) throws RestClientUtilException ;// temporary method
	
	/**
	 * @param authDetails
	 * @param apiVersion
	 * @param userName
	 * @param gstin
	 * @param taxPrd
	 * @param hostName
	 * @param resourceName
	 * @param formType
	 * @param action
	 * @param proxyRequired
	 * @return
	 * @throws ParseException 
	 */
	public String getData(AuthDetailsDto authDetails, String apiVersion,String userName, String gstin, String taxPrd, String hostName, String resourceName,
			String formType, String action, boolean proxyRequired) throws RestClientUtilException ;
			/**
			 * @param authDetails
			 * @param apiVersion
			 * @param userName
			 * @param gstin
			 * @param taxPrd
			 * @param hostName
			 * @param resourceName
			 * @param formType
			 * @param action
			 * @param proxyRequired
			 * @return
			 * @throws ParseException 
			 */
	public byte[] getDataFileDownload(AuthDetailsDto authDetails, String apiVersion,String userName, String gstin, String taxPrd, String hostName, String resourceName,
					String formType, String action, boolean proxyRequired) throws RestClientUtilException ;
	/**
	 * @param authDetails
	 * @param apiVersion
	 * @param userName
	 * @param gstin
	 * @param taxPrd
	 * @param hostName
	 * @param resourceName
	 * @param formType
	 * @param action
	 * @param proxyRequired
	 * @return
	 * @throws ParseException 
	 */

	public String getSummaryData(AuthDetailsDto authDetails, String apiVersion,String userName, String gstin, String taxPrd, String hostName, String resourceName,
			String formType, String action, boolean proxyRequired) throws RestClientUtilException ;
	
	/**
	 * @param authDetailsDto
	 * @param apiVersion
	 * @param dataJson
	 * @param userName
	 * @param gstin
	 * @param taxPrd
	 * @param hostName
	 * @param resourceName
	 * @param formType
	 * @param action
	 * @param proxyRequired
	 * @return
	 */
	public String saveData(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName, String gstin, String taxPrd, String hostName,
			String resourceName, String formType,String action, boolean proxyRequired) throws RestClientUtilException;
	
	/**
	 * @param authDetails
	 * @param apiVersion
	 * @param userName
	 * @param gstin
	 * @param taxPrd
	 * @param hostName
	 * @param resourceName
	 * @param formType
	 * @param action
	 * @param transID
	 * @param proxyRequired
	 * @return
	 * @throws Exception 
	 */
	public String getTransactionStatus(AuthDetailsDto authDetails, String apiVersion, String userName,String gstin, String taxPrd, String hostName, String resourceName,
			String formType, String action,String transID , boolean proxyRequired) throws  Exception;
	
	
	/**
	 * @param authDetailsDto
	 * @param apiVersion
	 * @param dataJson
	 * @param userName
	 * @param gstin
	 * @param taxPrd
	 * @param hostName
	 * @param resourceName
	 * @param formType
	 * @param action
	 * @param proxyRequired
	 * @return
	 */
	public String submitData(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName, String gstin, String taxPrd, String hostName,
			String resourceName, String formType, String action, boolean proxyRequired) throws RestClientUtilException;
	
	/**
	 * @param authDetailsDto
	 * @param apiVersion
	 * @param dataJson
	 * @param userName
	 * @param gstin
	 * @param taxPrd
	 * @param hostName
	 * @param resourceName
	 * @param formType
	 * @param action
	 * @param proxyRequired
	 * @return
	 */
	public String fileGSTR(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String signedData, String st, String sid, String userName, String gstin, String taxPrd,  
			String hostName, String resourceName, String formType, String action, boolean proxyRequired) throws RestClientUtilException;

	public String saveDataViaGSP(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException,Exception ;
	
	public String getOTP(String mobNo, String appKey, String userName, String URI, String apiKey, String apiSecret)
			throws RestClientUtilException;
	
	public String verifyOTP(String userName, String apiKey, String apiSecret ,String otp, String signedData,
			String URI) throws RestClientUtilException;

	public String getEncryptedApiKeySecret(String appKey, String apikey, String apiSecret);
	
	public String submitGSTR3Data(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName, String gstin, String taxPrd, String hostName,
			String resourceName, String formType, String action, boolean proxyRequired) throws RestClientUtilException;
	
	public String getGSTR3Data(AuthDetailsDto authDetails, String apiVersion,String userName, String gstin, String taxPrd, String hostName,	String resourceName, String formTypeorToken, String action,
			String getFinal, boolean proxyRequired) throws RestClientUtilException;
	
	public boolean isCAGateWayByPassEnabled();
}