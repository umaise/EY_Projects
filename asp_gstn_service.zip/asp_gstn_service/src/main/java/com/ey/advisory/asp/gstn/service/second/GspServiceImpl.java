package com.ey.advisory.asp.gstn.service.second;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

import com.ey.advisory.asp.gstn.common.AuthDetailsDto;
import com.ey.advisory.asp.gstn.common.Constant;
import com.ey.advisory.asp.gstn.exception.RestClientUtilException;
import com.ey.advisory.asp.gstn.util.CryptoUtil;
import com.ey.advisory.asp.gstn.util.PropertySourceUtil;
import com.ey.advisory.asp.gstn.util.RestClientUtility;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

@Component("GSPService")
@PropertySources({  @PropertySource("classpath:GSPConfig.properties"),
	@PropertySource("classpath:ASPGSPIntegeration.properties") })
public class GspServiceImpl implements IAPIService {

	private static final Logger LOGGER = Logger.getLogger(GstnServiceImpl.class);

	@Autowired
	private PropertySourceUtil propertyUtil;

	@Autowired
	private RestClientUtility restClientUtil;

	@Autowired
	private AuthGSPAPIServiceImpl authService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#getData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public String getData(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin, String taxPrd,
			String hostName, String resourceName, String formTypeorToken, String action, boolean proxyRequired) throws RestClientUtilException {
		//System.setProperty("javax.net.ssl.trustStore", "C:/Program Files/Java/jdk1.8.0_60/jre/lib/security/cacerts");
		if(LOGGER.isInfoEnabled())
		LOGGER.info("GSP api getData() service called...");

		String host;
		String resource;
		String decryptedGetDataRes;
		String getDataRes;
		String resourseUrl ;
		try {
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);

			if(action.equalsIgnoreCase(Constant.FILEDETAIL_API)){
				 resourseUrl = host + resource + "?gstin=" + gstin + "&ret_period=" + taxPrd + "&action="+ action+ "&token="+ formTypeorToken;
			} else {
				 resourseUrl = host + resource + formTypeorToken +"?gstin=" + gstin + "&ret_period=" + taxPrd + "&action="+ action;
			}
			
			//String resourseUrl  = "http://localhost:9010/taxpayerapi/v0.3/returns/gstr2a?gstin=" + gstin + "&ret_period=" + taxPrd + "&action="+action;
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("REsurce URL in getData : " + resourseUrl);
			}
			Client client = restClientUtil.getClient(proxyRequired);

			WebResource webResource = client.resource(resourseUrl);
			LOGGER.info("URI for api call : " + webResource.getURI());

			Builder builder = setCustomHeaders(webResource, authDetails, gstin, taxPrd, userName, apiVersion);
					//headerForGETReq(webResource, authDetails);
			getDataRes = restClientUtil.executeGETRestCalls(builder);

			LOGGER.info("Get data api call response for : " + gstin + "for tax period : " + taxPrd + " is --> "
					+ getDataRes);
			boolean resStatus = getResponseStatus(getDataRes);
			if (resStatus) {
				decryptedGetDataRes = CryptoUtil.getPayloadForGSTN(getDataRes, authDetails);
				LOGGER.info("Decrypted response for Save data api call for : " + gstin + "for tax period : "
						+ taxPrd + " is : " + decryptedGetDataRes);
			} else {
			/*	JSONObject jsonResp = 	getErrorResponse(getDataRes);
				LOGGER.info("Decrypted response for Get data api call for : " + gstin + "for tax period : " + taxPrd + " is : "
						+ jsonResp);*/
				 decryptedGetDataRes = getDataRes;
				//throw new RestClientUtilException("API call unsuccessful : Response status_cd = 0 ");
			}
			
		} catch (ParseException e) {
			LOGGER.error("Exception in GspServiceImpl.getData() " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in GspServiceImpl.getData() " + e.getMessage(), e);
		}

		return decryptedGetDataRes;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#getData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public byte[] getDataFileDownload(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin, String taxPrd,
			String hostName, String resourceName, String resourceParams, String action, boolean proxyRequired) throws RestClientUtilException {
		
		if(LOGGER.isInfoEnabled())
		LOGGER.info("GSP api getData() service called...");

		String host;
		String resource;
		String decryptedGetDataRes;
		byte[] getDataRes;
		String resourseUrl ;
		try {
			host = propertyUtil.getValue(hostName, apiVersion);
			resourseUrl = host + Constant.FILEDOWNLAOD+ resourceParams ;
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("REsurce URL in getData : " + resourseUrl);
			}
			Client client = restClientUtil.getClient(proxyRequired);

			WebResource webResource = client.resource(resourseUrl);
			LOGGER.info("URI for api call : " + webResource.getURI());

			Builder builder = setCustomHeaders(webResource, authDetails, gstin, taxPrd, userName, apiVersion);
			getDataRes = restClientUtil.executeGETRestCallsFileDownload(builder);
			LOGGER.info("Get data api call response for : " + gstin + "for tax period : " + taxPrd + " is --> "
					+ getDataRes);
			
		} catch (Exception e) {
			LOGGER.error("Exception in GspServiceImpl.getData() " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in GspServiceImpl.getData() " + e.getMessage(), e);
		}
		
		LOGGER.info("File download call ");

		return getDataRes;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#getData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public String getSummaryData(AuthDetailsDto authDetails, String apiVersion, String userName, String gstin, String taxPrd,
			String hostName, String resourceName, String formType, String action, boolean proxyRequired) throws RestClientUtilException {
		if(LOGGER.isInfoEnabled())
		LOGGER.info("GSP api getData() service called...");

		String host;
		String resource;
		String decryptedGetDataRes;
		String getDataRes;
		try {
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);

			String resourseUrl = host + resource + formType + "?gstin=" + gstin + "&ret_period=" + taxPrd + "&action="
					+ action ;

			if(LOGGER.isInfoEnabled()){
			LOGGER.info("REsurce URL in getData : " + resourseUrl);
			}
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("REsurce URL in getData : " + resourseUrl);
				}
			Client client = restClientUtil.getClient(proxyRequired);

			WebResource webResource = client.resource(resourseUrl);
			LOGGER.info("URI for api call : " + webResource.getURI());
			Builder builder = setCustomHeaders(webResource, authDetails, gstin, taxPrd, userName, apiVersion);
			getDataRes = restClientUtil.executeGETRestCalls(builder);
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("REsurce URL in getData : " + resourseUrl);
			}
			LOGGER.info("Get data api call response for : " + gstin + "for tax period : " + taxPrd + " is --> "
					+ getDataRes);

			decryptedGetDataRes = CryptoUtil.getPayloadForGSTN(getDataRes, authDetails);
		} catch (ParseException e) {
			LOGGER.error("Exception in GspServiceImpl.getData() " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in GspServiceImpl.getData() " + e.getMessage(), e);
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Decrypted response for Get data api call for : " + gstin + "for tax period : " + taxPrd + " is : "
				+ decryptedGetDataRes);
		}
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Decrypted response for Get data api call for : " + gstin + "for tax period : " + taxPrd + " is : "
					+ decryptedGetDataRes);
		}

		return decryptedGetDataRes;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#
	 * saveDataInAuthDetailsVO(java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public AuthDetailsDto saveDataInAuthDetailsVO(String gstin, String taxPrd, String userName, String data,
			String version) throws RestClientUtilException {

		AuthDetailsDto dto = new AuthDetailsDto();
		try {
			dto = authService.getOTP(dto);
			dto = authService.getAuthToken(dto);
			dto = authService.testDataForPut(dto.getAppKey(), dto.getSek(), data, dto);
		} catch (IOException | ParseException e) {
			LOGGER.error("Exception in GspServiceImpl.saveDataInAuthDetailsVO() " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in GspServiceImpl.saveDataInAuthDetailsVO() " + e.getMessage(), e);
		}
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Initial process of auth is done : " + dto.toString());
		}
		return dto;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#saveData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String saveData(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {

		if(LOGGER.isInfoEnabled())
		LOGGER.info("GSP api saveData() service called...");

		String host;
		String resource;
		String decryptedGetDataRes;
		String getDataRes;
		try {
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);
			authDetailsDto = authService.testDataForPut(authDetailsDto.getAppKey(), authDetailsDto.getSek(), dataJson,
					authDetailsDto);

			Client client = restClientUtil.getClient(proxyRequired);
			WebResource webResource = client.resource(host + resource + formType);
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("URI for api call : " + webResource.getURI());
			}
			// get header info
			Builder builder = headerForPUTReq(webResource, authDetailsDto);
			getDataRes = restClientUtil.executePUTRestCalls(gstrReqPayload(authDetailsDto, action), builder);
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Save data api call response for : " + gstin + "for tax period : " + taxPrd + " is --> "
					+ getDataRes);
			}
			decryptedGetDataRes = CryptoUtil.getPayloadForGSTN(getDataRes, authDetailsDto);
			
		} catch (IOException|ParseException e) {
			LOGGER.error("Exception in GspServiceImpl.saveData() " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in GspServiceImpl.saveData() " + e.getMessage(), e);

		} 
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Decrypted response for Save data api call for : " + gstin + "for tax period : " + taxPrd + " is : "
				+ decryptedGetDataRes);
		}

		return decryptedGetDataRes;

	}

	public String gstrReqPayload(AuthDetailsDto authDetailsDto, String action)
			throws JsonGenerationException, JsonMappingException, IOException {
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put(Constant.ACTION, action);
		paramMap.put(Constant.DATA, authDetailsDto.getEncryptedData());
		paramMap.put(Constant.HMAC, authDetailsDto.getHmac());

		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		if(LOGGER.isInfoEnabled()){
		LOGGER.info("Request Payload Data: " + mapAsJson);
		}
		return mapAsJson;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.gstn.service.second.IAPIService#getTransactionStatus(
	 * com.ey.advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String getTransactionStatus (AuthDetailsDto authDetails, String apiVersion, String userName, String gstin,
			String taxPrd, String hostName, String resourceName, String formType, String action, String transID,
					boolean proxyRequired) throws Exception{

		String decryptedGetStatusRes = "";
		String host;
		String resource;
		String getDataRes;
		try {
			
			
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);

			String resourseUrl = host + resource +"?action=" + action + "&gstin=" + gstin + "&ret_period=" + taxPrd + "&ref_id="
					+ transID;
			Client client = restClientUtil.getClient(proxyRequired);
			WebResource webResource = client.resource(resourseUrl);
			LOGGER.info("URI for api call : " + webResource.getURI());

			Builder builder = setCustomHeaders(webResource, authDetails, gstin, taxPrd, userName, apiVersion);//headerForGETReq(webResource, authDetails, gstin, taxPrd, userName, transID);
			getDataRes = restClientUtil.executeGETRestCalls(builder);

			LOGGER.info("Get status api call response for: " + gstin + "for tax period : " + taxPrd + " is:  "
					+ getDataRes);
			boolean resStatus = getResponseStatus(getDataRes);
			if (resStatus) {
				decryptedGetStatusRes = CryptoUtil.getPayloadForGSTN(getDataRes, authDetails);
				LOGGER.info("Decrypted response for Get data api call for : " + gstin + "for tax period : " + taxPrd
						+ " is: " + decryptedGetStatusRes);
			} else {
				LOGGER.error("RestClientUtilException in getTransactionStatus() in  GSPServiceImpl");
				throw new RestClientUtilException("API call unsuccessful : Response status_cd = 0 ");
			}

		}
		catch (Exception e) {
			LOGGER.error("Exception in getTransactionStatus() in  GSPServiceImpl : " + e.getMessage());
			throw new Exception(e);
		}
		return decryptedGetStatusRes;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ey.advisory.asp.gstn.service.second.IAPIService#submitData(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String submitData(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {
		String host;
		String resource;
		String retSubmitResponse;
		String retSubmitResponsedec = "";
//			authDetailsDto = authService.testDataForPut(authDetailsDto.getAppKey(), authDetailsDto.getSek(), dataJson,
//					authDetailsDto);
			authDetailsDto = CryptoUtil.encryptDataForSave(authDetailsDto.getAppKey(), authDetailsDto.getSek(),
					dataJson, authDetailsDto);


			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);

			Client client = restClientUtil.getClient(proxyRequired);

			WebResource webResource = client.resource(host + resource + formType);
			if(LOGGER.isInfoEnabled())
			LOGGER.info("URI for api call : " + webResource.getURI());
			// get header info
			Builder builder =setCustomHeaders(webResource, authDetailsDto,gstin,taxPrd,userName,apiVersion);

			try {
				retSubmitResponse = restClientUtil
						.executePOSTRestCalls(gstrReqPayload(authDetailsDto, "RETSUBMIT"), builder);
//				retSubmitResponse = restClientUtil
//						.executePOSTRestCalls(gstrRETSUBMITPayload(authDetailsDto.getEncryptedData(), "RETSUM"), builder);
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("retSubmitResponsedec  :::: - " + retSubmitResponse);
				}
				
				boolean resStatus = getResponseStatus(retSubmitResponse);
				if (resStatus) {
					retSubmitResponsedec = CryptoUtil.getPayloadForGSTN(retSubmitResponse, authDetailsDto);
				}else{
					return retSubmitResponse;
				}
			} catch (IOException|ParseException e) {
				LOGGER.error("Exception in GspServiceImpl.submitData() " + e.getMessage(), e);
				throw new RestClientUtilException("Exception in GspServiceImpl.submitData() " + e.getMessage(), e);
			} 
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("Decrypted payload retSubmitResponsedec::  " + retSubmitResponsedec);
			}
		return retSubmitResponsedec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#fileGSTR(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String fileGSTR(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String signedData, String st, String sid,
			String userName,String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {
		//System.setProperty("javax.net.ssl.trustStore", "C:/Program Files/Java/jdk1.8.0_60/jre/lib/security/cacerts");
		String encryptedDataSubmit;
		String host;
		String resource;
		String retSubmitResponse;
		String retSubmitResponsedec = null;
			encryptedDataSubmit = CryptoUtil.encryptDataForSubmit(dataJson.getBytes(), authDetailsDto.getAuthEK());
			authDetailsDto.setEncryptedDataSubmit(encryptedDataSubmit);
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("encryptedDataSubmit  : " + encryptedDataSubmit);
			}

			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);
			Client client = restClientUtil.getClient(proxyRequired);
			String resourseUrl = host + resource + formType;

			WebResource webResource = client.resource(resourseUrl);
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("URI for api call : " + webResource.getURI());
			}
			Builder builder = setCustomHeaders(webResource, authDetailsDto, gstin, taxPrd, userName, apiVersion);
			//Builder builder = headerForPOSTReq(webResource, authDetailsDto);
			
			try {
				retSubmitResponse = restClientUtil.executePOSTRestCalls(gstrRETFILEPayload(encryptedDataSubmit, "RETFILE",signedData, st, sid),
						builder);
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("retSubmitResponsedec  :::: - " + retSubmitResponse);
				}
				boolean resStatus = getResponseStatus(retSubmitResponse);
				if(resStatus)
					retSubmitResponsedec = CryptoUtil.getPayloadForGSTN(retSubmitResponse, authDetailsDto);
				else{
					retSubmitResponsedec=retSubmitResponse;
				}
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("Decrypted payload retSubmitResponsedec::  " + retSubmitResponsedec);
				}
				
			} catch (IOException|ParseException e1) {
				LOGGER.error("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage(), e1);
				throw new RestClientUtilException("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage(), e1);
				
			} 
		return retSubmitResponsedec;
	}

	/**
	 * @param encryptedDataSubmit
	 * @param action
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private String gstrRETSUBMITPayload(String encryptedDataSubmit, String action)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", "RETSUBMIT");
		paramMap.put("data", encryptedDataSubmit);

		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	/**
	 * @param encryptedDataSubmit
	 * @param action
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private String gstrRETFILEPayload(String encryptedDataSubmit, String action, String signedData, String st, String pan)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("action", "RETFILE");
		paramMap.put("data", encryptedDataSubmit);
		paramMap.put("sign", signedData);
		paramMap.put("st", st);
		paramMap.put("sid", pan);

		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}
	/**
	 * @param webResource
	 * @param authDetailsDto
	 * @return
	 */
	public Builder headerForGETReq(WebResource webResource, AuthDetailsDto authDetailsDto) {
		Builder builder = webResource.header("auth-token", "8a227e0ba56042a0acdf98b3477d2c03")
				.header("eygspclientid", "aspAdmin").header("txn", "returns").header("state-cd", "11")
				.header("Content-Type", "application/json;charset=UTF-8").header("username", "EYGSPTESTUSER")
				.header("eygspuser", "EYASPAdmin@ey.com").header("eygspclientsecret", "Password1")
				.header("ip-usr", "12.8.9l.80");

		return builder;
	}

	/**
	 * @param webResource
	 * @param authDetailsDto
	 * @return
	 */

	public Builder headerForPUTReq(WebResource webResource, AuthDetailsDto authDetailsDto) {
		Builder builder = webResource.header("auth-token", "8a227e0ba56042a0acdf98b3477d2c03")
				.header("eygspclientid", "aspAdmin").header("txn", "returns").header("state-cd", "11")
				.header("Content-Type", "application/json;charset=UTF-8").header("username", "EYGSPTESTUSER")
				.header("eygspuser", "EYASPAdmin@ey.com").header("eygspclientsecret", "Password1")
				.header("ip-usr", "12.8.9l.80");

		return builder;

	}

	/**
	 * @param webResource
	 * @param authDetailsDto
	 * @return
	 */
	public Builder headerForPOSTReq(WebResource webResource, AuthDetailsDto authDetailsDto) {
		Builder builder = webResource.header("auth-token", "8a227e0ba56042a0acdf98b3477d2c03")
				.header("eygspclientid", "aspAdmin").header("txn", "returns").header("state-cd", "11")
				.header("Content-Type", "application/json;charset=UTF-8").header("username", "EYGSPTESTUSER")
				.header("eygspuser", "EYASPAdmin@ey.com").header("eygspclientsecret", "Password1")
				.header("ip-usr", "12.8.9l.80");

		return builder;
	}

/*	@Override
	public String saveDataViaGSP(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException {
		String decryptedSaveDataRes = "";
		String retSaveResponse;
		String host;
		String resource;

		try {

			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);
			authDetailsDto = CryptoUtil.encryptDataForSave(authDetailsDto.getAppKey(), authDetailsDto.getSek(),
					dataJson, authDetailsDto);
			Client client = restClientUtil.getClient(proxyRequired);
			if (null != host && !host.isEmpty() && null != resource && !resource.isEmpty() && null != formType
					&& !formType.isEmpty()) {
				WebResource webResource = client.resource(host + resource + formType);
				LOGGER.info("URI for api call : " + webResource.getURI());

				// get header info
				Builder builder = setCustomHeaders(webResource, authDetailsDto, gstin, taxPrd, userName,
						apiVersion);
				retSaveResponse = restClientUtil.executePUTRestCalls(gstrReqPayload(authDetailsDto, action), builder);

				LOGGER.info("Save API response for " + gstin + "tax period: " + taxPrd + " is : " + retSaveResponse);
				boolean resStatus = getResponseStatus(retSaveResponse);
				if (resStatus) {
					decryptedSaveDataRes = CryptoUtil.getPayloadForGSTN(retSaveResponse, authDetailsDto);
					LOGGER.info("Decrypted response for Save data api call for : " + gstin + "for tax period : "
							+ taxPrd + " is : " + decryptedSaveDataRes);
				} else {
					throw new RestClientUtilException("API call unsuccessful : Response status_cd = 0 ");
				}

			} else {
				LOGGER.error("host or resource or  formType is/are empty ");
			}
		} catch (RestClientUtilException|ParseException|JsonGenerationException|JsonMappingException e) {
			LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage());
			throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage());
		}  catch (IOException e) {
			LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage());
			throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage());
			throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage());
		}
		return decryptedSaveDataRes;

	}*/
	
	
	
	@Override
	public String saveDataViaGSP(AuthDetailsDto authDetailsDto, String apiVersion, String dataJson, String userName,
			String gstin, String taxPrd, String hostName, String resourceName, String formType, String action,
			boolean proxyRequired) throws RestClientUtilException,Exception  {
		//System.setProperty("javax.net.ssl.trustStore", "C:\\softwares\\jdk1.8.0_101\\jre\\lib\\security/cacerts");
			String decryptedSaveDataRes = "";
			String retSaveResponse;
			String host;
			String resource;

			try {

				host = propertyUtil.getValue(hostName, apiVersion);
				resource = propertyUtil.getValue(resourceName, apiVersion);
				authDetailsDto = CryptoUtil.encryptDataForSave(authDetailsDto.getAppKey(), authDetailsDto.getSek(),
						dataJson, authDetailsDto);
				Client client = restClientUtil.getClient(proxyRequired);
				/*if (null != host && !host.isEmpty() && null != resource && !resource.isEmpty() && null != formType
						&& !formType.isEmpty()) {*/
					WebResource webResource = client.resource(host + resource + formType);
					LOGGER.info("URI for api call : " + webResource.getURI());

					// get header info
					Builder builder = setCustomHeaders(webResource, authDetailsDto, gstin, taxPrd, userName,
							apiVersion);
					retSaveResponse = restClientUtil.executePUTRestCalls(gstrReqPayload(authDetailsDto, action), builder);

					LOGGER.info("Save API response for " + gstin + "tax period: " + taxPrd + " is : " + retSaveResponse);
					boolean resStatus = getResponseStatus(retSaveResponse);
					if (resStatus) {
						decryptedSaveDataRes = CryptoUtil.getPayloadForGSTN(retSaveResponse, authDetailsDto);
						LOGGER.info("Decrypted response for Save data api call for : " + gstin + "for tax period : "
								+ taxPrd + " is : " + decryptedSaveDataRes);
					} else {
						throw new Exception("API call unsuccessful : Response status_cd = 0 ");
					}

				/*} else {
					throw new Exception("host or resource or  formType is/are empty ");
				}*/
			//} catch (RestClientUtilException|ParseException|JsonGenerationException|JsonMappingException e) {
			} catch (RestClientUtilException e) {
				LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
				throw new RestClientUtilException("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
			} catch (Exception e) {
				LOGGER.error("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
				throw new Exception("Exception in saveData() in  GstnServiceImpl : " + e.getMessage(), e);
			}
			return decryptedSaveDataRes;

		}
	
	
	
	
	
	private Builder setCustomHeaders(WebResource webResource, AuthDetailsDto authDetailsDto, String gstin, String taxPrd,
			String userName, String version) throws RestClientUtilException {
		Builder builder = null;
		try {
			builder = webResource.
			    	header("digigst_username", authDetailsDto.getDigigstUserName()).
					header("access_token", authDetailsDto.getAccessToken()).
			    	header("api_key", new String(authDetailsDto.getApiKey())).
			    	header("api_secret", authDetailsDto.getApiSecret()).
			     // required for gstn
					header(Constant.IP_USR, propertyUtil.getValue("ip.usr")).
					header("Content-Type", "application/json;charset=UTF-8").
					header(Constant.PARAM_OAUTH, authDetailsDto.getAuthToken()).
					header(Constant.STATECD, authDetailsDto.getStateCode()).
					header(Constant.USERNAME, authDetailsDto.getUserName()).
					header(Constant.TXN, propertyUtil.getValue("rest.txn")).
			    	header(Constant.GSTIN_HDR, gstin).
			    	header(Constant.RET_PRD, taxPrd);
			
		} catch (RestClientUtilException e) {
			LOGGER.error("Exception in setCustomHeaders() in  GstnServiceImpl : " + e.getMessage(), e);
			throw new RestClientUtilException();
		}
				return builder;
	}
	
	private boolean getResponseStatus(String getDataRes) throws ParseException {

		JSONObject jsonObjectVal = null;
		jsonObjectVal = (JSONObject) new JSONParser().parse(getDataRes);
		String status = (String) jsonObjectVal.get("status_cd");
		if(null != status){
			return (("0").equals(status)) ? false : true;
		}
		return false;

	}
	private JSONObject getErrorResponse(String getDataRes) throws ParseException {

		JSONObject jsonObjectVal = null;
		jsonObjectVal = (JSONObject) new JSONParser().parse(getDataRes);
		jsonObjectVal.put("status_cd", (String) jsonObjectVal.get("status_cd"));
		jsonObjectVal.put("error", (String) jsonObjectVal.get("error"));
		return jsonObjectVal;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ey.advisory.asp.gstn.service.second.IAPIService#fileGSTR(com.ey.
	 * advisory.asp.gstn.common.AuthDetailsDto, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	@Override
	public String getOTP(String mobileNumber,String appKey,String userName,String resourseUrl, 
			String apiKey, String apiSecret) throws RestClientUtilException {
		//System.setProperty("javax.net.ssl.trustStore", "C:/Program Files/Java/jdk1.8.0_60/jre/lib/security/cacerts");
		String retSubmitResponse;
		
			Client client = restClientUtil.getClient(Boolean.TRUE);
			apiKey = propertyUtil.getValue("sign.api.key");
			apiSecret = propertyUtil.getValue("sign.api.secret");
			WebResource webResource = client.resource(propertyUtil.getValue(resourseUrl));
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("URI for api call : " + webResource.getURI());
			}
			Builder builder = setOtpHeaders(webResource, userName, apiKey,
					apiSecret, propertyUtil.getValue("ip.usr"),
					propertyUtil.getValue("rest.txn"));
			try {
				retSubmitResponse = restClientUtil.executePOSTRestCalls(gstrOTPPayload(mobileNumber, appKey),
						builder);
				if(LOGGER.isInfoEnabled()){
				LOGGER.info("retSubmitResponse  :::: - " + retSubmitResponse);
				}
			} catch (IOException e1) {
				LOGGER.error("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage(), e1);
				throw new RestClientUtilException("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage(), e1);
				
			} 
		return retSubmitResponse;
	}
	private Builder setOtpHeaders(WebResource webResource,
			String userName, String apikey, String apiSecret,
			String ipUsr, String txn) {
		
		Builder builder = null;
		try {
			builder = webResource.
			    	header("digigst_username", userName).
			    	header("api_key",apikey ).
			    	header("api_secret",apiSecret).
					header("ip_usr", ipUsr).
					header("Content-Type", "application/json").
					header(Constant.TXN, txn);
			    	
		} catch (Exception e) {
			LOGGER.error("Exception in setOtpHeaders() in  GspServiceImpl : " + e);
		}
		return builder;
	}
	
	/**
	 * @param encryptedDataSubmit
	 * @param action
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private String gstrOTPPayload(String mobile, String randomId)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("mobile_number",mobile);
		paramMap.put("app_key", randomId);
	
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	@Override
	public String verifyOTP(String username, String apiKey, String apiSecret, String otp, String signedData,
			String URI) throws RestClientUtilException {
		//System.setProperty("javax.net.ssl.trustStore", "C:/Program Files/Java/jdk1.8.0_60/jre/lib/security/cacerts");
		
		String verifyResponse;
		
		Client client = restClientUtil.getClient(Boolean.TRUE);
		
		WebResource webResource = client.resource(propertyUtil.getValue(URI));
		
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("URI for api call : " + webResource.getURI());
			}
		
		
		Builder builder = setOtpHeaders(webResource, username,
				apiKey,apiSecret,propertyUtil.getValue("ip.usr"),
				propertyUtil.getValue("rest.txn"));
		
		try {
			verifyResponse = restClientUtil.executePOSTRestCalls(gstrOTPVerificationPayload
					(otp, signedData),builder);
			if(LOGGER.isInfoEnabled()){
			LOGGER.info("retSubmitResponse  :::: - " + verifyResponse);
			}
		} catch (IOException e1) {
			LOGGER.error("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage(), e1);
			throw new RestClientUtilException("Exception in GspServiceImpl.fileGSTR() " + e1.getMessage(), e1);
			
		} 
		return verifyResponse;
	}
	
	private String gstrOTPVerificationPayload(String otp, String signedData)
			throws JsonGenerationException, JsonMappingException, IOException {

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("otp", otp);
		paramMap.put("data", signedData);
	
		String mapAsJson = new ObjectMapper().writeValueAsString(paramMap);
		return mapAsJson;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getEncryptedApiKeySecret(String appKey, String apikey, String apiSecret) {
		JSONObject jObj= new JSONObject();
		String encryptedApiKey = null;
		String encryptedApiSecret = null;
		try {
			apikey = propertyUtil.getValue("sign.api.key");
			apiSecret = propertyUtil.getValue("sign.api.secret");
			encryptedApiKey =  CryptoUtil.encryptDataForkeySecret(apikey, appKey);
			encryptedApiSecret =CryptoUtil.encryptDataForkeySecret(apiSecret, appKey);
		} catch (Exception e) {
			LOGGER.error("Exception in GspServiceImpl.getEncryptedApiKeySecret() " + e);
		}
		jObj.put("api_key", encryptedApiKey);
		jObj.put("api_secret", encryptedApiSecret);
		return jObj.toString();
	}

	@Override
    public String submitGSTR3Data(AuthDetailsDto authDetailsDto,
                  String apiVersion, String dataJson, String userName, String gstin,
                  String taxPrd, String hostName, String resourceName,
                  String formType, String action, boolean proxyRequired)
                  throws RestClientUtilException {
           String host;
           String resource;
           String retSubmitResponse;
           String retSubmitResponsedec = "";

           authDetailsDto = CryptoUtil.encryptDataForSave(
                        authDetailsDto.getAppKey(), authDetailsDto.getSek(), dataJson,
                        authDetailsDto);

           host = propertyUtil.getValue(hostName, apiVersion);
           resource = propertyUtil.getValue(resourceName, apiVersion);

           String isStubCall = propertyUtil.getValue("gsp-stub-enabled");

           if (isStubCall != null && isStubCall.equalsIgnoreCase("true"))
                  resource = Constant.GSTR3_STUBSRERVICE+resource; 

           Client client = restClientUtil.getClient(proxyRequired);

           WebResource webResource = client.resource(host + resource + formType);
           if (LOGGER.isInfoEnabled())
                  LOGGER.info("URI for api call : " + webResource.getURI());
           // get header info
           Builder builder = setCustomHeaders(webResource, authDetailsDto, gstin,
                        taxPrd, userName, apiVersion);

           try {
                  retSubmitResponse = restClientUtil.executePOSTRestCalls(
                               gstrReqPayload(authDetailsDto, action), builder);

                  if (LOGGER.isInfoEnabled()) {
                        LOGGER.info("retSubmitResponsedec  :::: - " + retSubmitResponse);
                  }

                  boolean resStatus = getResponseStatus(retSubmitResponse);
                  if (resStatus) {
                        if (isStubCall != null && isStubCall.equalsIgnoreCase("true")) {
                               return retSubmitResponse;
                        } else
                               retSubmitResponsedec = CryptoUtil.getPayloadForGSTN(
                                             retSubmitResponse, authDetailsDto);
                  } else {
                        return retSubmitResponse;
                  }
           } catch (IOException | ParseException e) {
                  LOGGER.error("Exception in GspServiceImpl.submitData() "
                               + e.getMessage());
                  throw new RestClientUtilException(
                               "Exception in GspServiceImpl.submitData() "
                                             + e.getMessage(), e);
           }
           if (LOGGER.isInfoEnabled()) {
                  LOGGER.info("Decrypted payload retSubmitResponsedec::  "
                               + retSubmitResponsedec);
           }
           return retSubmitResponsedec;
    }

	@Override
    public String getGSTR3Data(AuthDetailsDto authDetails, String apiVersion,
                  String userName, String gstin, String taxPrd, String hostName,
                  String resourceName, String formTypeorToken, String action,
                  String getFinal, boolean proxyRequired)
 throws RestClientUtilException {
		// System.setProperty("javax.net.ssl.trustStore",
		// "C:/Program Files/Java/jdk1.8.0_60/jre/lib/security/cacerts");
		if (LOGGER.isInfoEnabled())
			LOGGER.info("GSP api getGSTR3Data() service called...");

		String host;
		String resource;
		String decryptedGetDataRes;
		String getDataRes;
		String resourseUrl;
		try {
			host = propertyUtil.getValue(hostName, apiVersion);
			resource = propertyUtil.getValue(resourceName, apiVersion);

			String isStubCall = propertyUtil.getValue("gsp-stub-enabled");

			if (isStubCall != null && isStubCall.equalsIgnoreCase("true")
					&& !action.equalsIgnoreCase(Constant.LEDGER_API)
					&& !action.equalsIgnoreCase(Constant.GSTR3_GENERATE))
				resource = Constant.GSTR3_STUBSRERVICE + resource;

			if (action.equalsIgnoreCase(Constant.GSTR3_GET)) {
				resourseUrl = host + resource + formTypeorToken + "?gstin=" + gstin + "&ret_period=" + taxPrd
						+ "&final=" + getFinal + "&action=" + action;
			} else if (action.equalsIgnoreCase(Constant.LEDGER_API)) {

				resourseUrl = host + resource + "?gstin=" + gstin + "&ret_period=" + taxPrd + "&action=" + action;
			} else {
				resourseUrl = host + resource + formTypeorToken + "?gstin=" + gstin + "&ret_period=" + taxPrd
						+ "&action=" + action;
			}

			
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("REsurce URL in getData : " + resourseUrl);
			}
			Client client = restClientUtil.getClient(proxyRequired);

			WebResource webResource = client.resource(resourseUrl);
			LOGGER.info("URI for api call : " + webResource.getURI());

			Builder builder = setCustomHeaders(webResource, authDetails, gstin, taxPrd, userName, apiVersion);
			getDataRes = restClientUtil.executeGETRestCalls(builder);

			LOGGER.info("Get data api call response for : " + gstin + "for tax period : " + taxPrd + " is --> "
					+ getDataRes);
			boolean resStatus = getResponseStatus(getDataRes);
			if (resStatus) {

				if (isStubCall != null && isStubCall.equalsIgnoreCase("true")
						&& !action.equalsIgnoreCase(Constant.LEDGER_API)
						&& !action.equalsIgnoreCase(Constant.GSTR3_GENERATE)) {
					decryptedGetDataRes = getDataRes;
				} else
					decryptedGetDataRes = CryptoUtil.getPayloadForGSTN(getDataRes, authDetails);
				LOGGER.info("Decrypted response for Save data api call for : " + gstin + "for tax period : " + taxPrd
						+ " is : " + decryptedGetDataRes);
			} else {
				decryptedGetDataRes = getDataRes;
			}

		} catch (ParseException e) {
			LOGGER.error("Exception in GspServiceImpl.getData() " + e.getMessage(), e);
			throw new RestClientUtilException("Exception in GspServiceImpl.getData() " + e.getMessage(), e);
		}

		return decryptedGetDataRes;
	}

	@Override
	public boolean isCAGateWayByPassEnabled() {
		boolean bFlag = false;
		String is_ca_bypassenabled = null;
		try {
			is_ca_bypassenabled = propertyUtil.getValue("is.ca.bypassenabled");
			if (is_ca_bypassenabled != null) {
				if (LOGGER.isInfoEnabled())
					LOGGER.info("Value for [is.ca.bypassenabled] = [" + is_ca_bypassenabled +"]");
				bFlag = Boolean.parseBoolean(propertyUtil.getValue("is.ca.bypassenabled"));
			}
		} catch (RestClientUtilException e) {
			LOGGER.error("Exception while parsing value of property value of [is.ca.bypassenabled] [ "+ is_ca_bypassenabled +"] ", e);
		}
		return bFlag;
	}	

}
